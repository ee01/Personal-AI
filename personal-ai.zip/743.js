(self["webpackChunkpersonal_ai"] = self["webpackChunkpersonal_ai"] || []).push([[743,143],{

/***/ 1929:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   zP: () => (/* binding */ getEmbeddingViaOffscreen)
/* harmony export */ });
/* unused harmony exports createOffscreenDocument, getEmbeddingInBackground, handleEmbeddingResult */
// 创建新文件处理嵌入相关功能
const pendingEmbeddingRequests = new Map();

// 创建离屏文档
async function createOffscreenDocument() {
  try {
    // 检查是否已经存在离屏文档
    const existingContexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT']
    });
    if (existingContexts.length > 0) {
      // console.log('离屏文档已存在');
      return;
    }
    console.log('创建离屏文档...');
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['WORKERS'],
      justification: '需要使用 WebAssembly 来运行嵌入模型'
    });
    console.log('离屏文档创建成功');
  } catch (error) {
    console.error('创建离屏文档失败:', error);
  }
}

// 通过离屏文档获取嵌入向量
async function getEmbeddingViaOffscreen(text) {
  const isBackground = typeof ServiceWorkerGlobalScope !== 'undefined' && self instanceof ServiceWorkerGlobalScope;
  if (isBackground) {
    return await getEmbeddingInBackground(text);
  } else {
    const result = await chrome.runtime.sendMessage({
      type: 'EXEC_EMBEDDING_REQUEST',
      text
    });
    return result;
  }
}
async function getEmbeddingInBackground(text) {
  try {
    await createOffscreenDocument();

    // 生成唯一请求ID
    const requestId = Date.now().toString() + Math.random().toString().slice(2);

    // 创建Promise并存储
    const resultPromise = new Promise((resolve, reject) => {
      pendingEmbeddingRequests.set(requestId, {
        resolve,
        reject
      });

      // 设置超时
      setTimeout(() => {
        if (pendingEmbeddingRequests.has(requestId)) {
          pendingEmbeddingRequests.delete(requestId);
          reject(new Error('获取嵌入向量超时'));
        }
      }, 30000); // 30秒超时
    });

    // 发送消息到离屏文档
    chrome.runtime.sendMessage({
      type: 'GET_EMBEDDING',
      requestId,
      text
    });
    return resultPromise;
  } catch (error) {
    console.error('通过离屏文档获取嵌入向量失败:', error);
    return new Array(384).fill(0);
  }
}

// 处理嵌入结果
function handleEmbeddingResult(message) {
  if (message.type === 'EMBEDDING_RESULT') {
    const requestId = message.requestId;
    const pendingRequest = pendingEmbeddingRequests.get(requestId);
    if (pendingRequest) {
      pendingEmbeddingRequests.delete(requestId);
      pendingRequest.resolve(message.embedding);
    }
  }
}

/***/ }),

/***/ 1995:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  sc: () => (/* binding */ callLLMJsonAPI),
  handleLLMRequest: () => (/* binding */ handleLLMRequest)
});

// UNUSED EXPORTS: DifyChat, GroqChat, OllamaChat, OpenAIChat, generateAutoReply, isContentSimilar, knowledgeQuery, knowledgeQueryOld_DEPRECATED

;// CONCATENATED MODULE: ./node_modules/openai/internal/qs/formats.mjs
const default_format = 'RFC3986';
const formatters = {
    RFC1738: (v) => String(v).replace(/%20/g, '+'),
    RFC3986: (v) => String(v),
};
const RFC1738 = 'RFC1738';
const RFC3986 = 'RFC3986';
//# sourceMappingURL=formats.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/internal/qs/utils.mjs

const has = Object.prototype.hasOwnProperty;
const is_array = Array.isArray;
const hex_table = (() => {
    const array = [];
    for (let i = 0; i < 256; ++i) {
        array.push('%' + ((i < 16 ? '0' : '') + i.toString(16)).toUpperCase());
    }
    return array;
})();
function compact_queue(queue) {
    while (queue.length > 1) {
        const item = queue.pop();
        if (!item)
            continue;
        const obj = item.obj[item.prop];
        if (is_array(obj)) {
            const compacted = [];
            for (let j = 0; j < obj.length; ++j) {
                if (typeof obj[j] !== 'undefined') {
                    compacted.push(obj[j]);
                }
            }
            // @ts-ignore
            item.obj[item.prop] = compacted;
        }
    }
}
function array_to_object(source, options) {
    const obj = options && options.plainObjects ? Object.create(null) : {};
    for (let i = 0; i < source.length; ++i) {
        if (typeof source[i] !== 'undefined') {
            obj[i] = source[i];
        }
    }
    return obj;
}
function merge(target, source, options = {}) {
    if (!source) {
        return target;
    }
    if (typeof source !== 'object') {
        if (is_array(target)) {
            target.push(source);
        }
        else if (target && typeof target === 'object') {
            if ((options && (options.plainObjects || options.allowPrototypes)) ||
                !has.call(Object.prototype, source)) {
                target[source] = true;
            }
        }
        else {
            return [target, source];
        }
        return target;
    }
    if (!target || typeof target !== 'object') {
        return [target].concat(source);
    }
    let mergeTarget = target;
    if (is_array(target) && !is_array(source)) {
        // @ts-ignore
        mergeTarget = array_to_object(target, options);
    }
    if (is_array(target) && is_array(source)) {
        source.forEach(function (item, i) {
            if (has.call(target, i)) {
                const targetItem = target[i];
                if (targetItem && typeof targetItem === 'object' && item && typeof item === 'object') {
                    target[i] = merge(targetItem, item, options);
                }
                else {
                    target.push(item);
                }
            }
            else {
                target[i] = item;
            }
        });
        return target;
    }
    return Object.keys(source).reduce(function (acc, key) {
        const value = source[key];
        if (has.call(acc, key)) {
            acc[key] = merge(acc[key], value, options);
        }
        else {
            acc[key] = value;
        }
        return acc;
    }, mergeTarget);
}
function assign_single_source(target, source) {
    return Object.keys(source).reduce(function (acc, key) {
        acc[key] = source[key];
        return acc;
    }, target);
}
function decode(str, _, charset) {
    const strWithoutPlus = str.replace(/\+/g, ' ');
    if (charset === 'iso-8859-1') {
        // unescape never throws, no try...catch needed:
        return strWithoutPlus.replace(/%[0-9a-f]{2}/gi, unescape);
    }
    // utf-8
    try {
        return decodeURIComponent(strWithoutPlus);
    }
    catch (e) {
        return strWithoutPlus;
    }
}
const limit = 1024;
const encode = (str, _defaultEncoder, charset, _kind, format) => {
    // This code was originally written by Brian White for the io.js core querystring library.
    // It has been adapted here for stricter adherence to RFC 3986
    if (str.length === 0) {
        return str;
    }
    let string = str;
    if (typeof str === 'symbol') {
        string = Symbol.prototype.toString.call(str);
    }
    else if (typeof str !== 'string') {
        string = String(str);
    }
    if (charset === 'iso-8859-1') {
        return escape(string).replace(/%u[0-9a-f]{4}/gi, function ($0) {
            return '%26%23' + parseInt($0.slice(2), 16) + '%3B';
        });
    }
    let out = '';
    for (let j = 0; j < string.length; j += limit) {
        const segment = string.length >= limit ? string.slice(j, j + limit) : string;
        const arr = [];
        for (let i = 0; i < segment.length; ++i) {
            let c = segment.charCodeAt(i);
            if (c === 0x2d || // -
                c === 0x2e || // .
                c === 0x5f || // _
                c === 0x7e || // ~
                (c >= 0x30 && c <= 0x39) || // 0-9
                (c >= 0x41 && c <= 0x5a) || // a-z
                (c >= 0x61 && c <= 0x7a) || // A-Z
                (format === RFC1738 && (c === 0x28 || c === 0x29)) // ( )
            ) {
                arr[arr.length] = segment.charAt(i);
                continue;
            }
            if (c < 0x80) {
                arr[arr.length] = hex_table[c];
                continue;
            }
            if (c < 0x800) {
                arr[arr.length] = hex_table[0xc0 | (c >> 6)] + hex_table[0x80 | (c & 0x3f)];
                continue;
            }
            if (c < 0xd800 || c >= 0xe000) {
                arr[arr.length] =
                    hex_table[0xe0 | (c >> 12)] + hex_table[0x80 | ((c >> 6) & 0x3f)] + hex_table[0x80 | (c & 0x3f)];
                continue;
            }
            i += 1;
            c = 0x10000 + (((c & 0x3ff) << 10) | (segment.charCodeAt(i) & 0x3ff));
            arr[arr.length] =
                hex_table[0xf0 | (c >> 18)] +
                    hex_table[0x80 | ((c >> 12) & 0x3f)] +
                    hex_table[0x80 | ((c >> 6) & 0x3f)] +
                    hex_table[0x80 | (c & 0x3f)];
        }
        out += arr.join('');
    }
    return out;
};
function compact(value) {
    const queue = [{ obj: { o: value }, prop: 'o' }];
    const refs = [];
    for (let i = 0; i < queue.length; ++i) {
        const item = queue[i];
        // @ts-ignore
        const obj = item.obj[item.prop];
        const keys = Object.keys(obj);
        for (let j = 0; j < keys.length; ++j) {
            const key = keys[j];
            const val = obj[key];
            if (typeof val === 'object' && val !== null && refs.indexOf(val) === -1) {
                queue.push({ obj: obj, prop: key });
                refs.push(val);
            }
        }
    }
    compact_queue(queue);
    return value;
}
function is_regexp(obj) {
    return Object.prototype.toString.call(obj) === '[object RegExp]';
}
function is_buffer(obj) {
    if (!obj || typeof obj !== 'object') {
        return false;
    }
    return !!(obj.constructor && obj.constructor.isBuffer && obj.constructor.isBuffer(obj));
}
function combine(a, b) {
    return [].concat(a, b);
}
function maybe_map(val, fn) {
    if (is_array(val)) {
        const mapped = [];
        for (let i = 0; i < val.length; i += 1) {
            mapped.push(fn(val[i]));
        }
        return mapped;
    }
    return fn(val);
}
//# sourceMappingURL=utils.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/internal/qs/stringify.mjs


const stringify_has = Object.prototype.hasOwnProperty;
const array_prefix_generators = {
    brackets(prefix) {
        return String(prefix) + '[]';
    },
    comma: 'comma',
    indices(prefix, key) {
        return String(prefix) + '[' + key + ']';
    },
    repeat(prefix) {
        return String(prefix);
    },
};
const stringify_is_array = Array.isArray;
const push = Array.prototype.push;
const push_to_array = function (arr, value_or_array) {
    push.apply(arr, stringify_is_array(value_or_array) ? value_or_array : [value_or_array]);
};
const to_ISO = Date.prototype.toISOString;
const defaults = {
    addQueryPrefix: false,
    allowDots: false,
    allowEmptyArrays: false,
    arrayFormat: 'indices',
    charset: 'utf-8',
    charsetSentinel: false,
    delimiter: '&',
    encode: true,
    encodeDotInKeys: false,
    encoder: encode,
    encodeValuesOnly: false,
    format: default_format,
    formatter: formatters[default_format],
    /** @deprecated */
    indices: false,
    serializeDate(date) {
        return to_ISO.call(date);
    },
    skipNulls: false,
    strictNullHandling: false,
};
function is_non_nullish_primitive(v) {
    return (typeof v === 'string' ||
        typeof v === 'number' ||
        typeof v === 'boolean' ||
        typeof v === 'symbol' ||
        typeof v === 'bigint');
}
const sentinel = {};
function inner_stringify(object, prefix, generateArrayPrefix, commaRoundTrip, allowEmptyArrays, strictNullHandling, skipNulls, encodeDotInKeys, encoder, filter, sort, allowDots, serializeDate, format, formatter, encodeValuesOnly, charset, sideChannel) {
    let obj = object;
    let tmp_sc = sideChannel;
    let step = 0;
    let find_flag = false;
    while ((tmp_sc = tmp_sc.get(sentinel)) !== void undefined && !find_flag) {
        // Where object last appeared in the ref tree
        const pos = tmp_sc.get(object);
        step += 1;
        if (typeof pos !== 'undefined') {
            if (pos === step) {
                throw new RangeError('Cyclic object value');
            }
            else {
                find_flag = true; // Break while
            }
        }
        if (typeof tmp_sc.get(sentinel) === 'undefined') {
            step = 0;
        }
    }
    if (typeof filter === 'function') {
        obj = filter(prefix, obj);
    }
    else if (obj instanceof Date) {
        obj = serializeDate?.(obj);
    }
    else if (generateArrayPrefix === 'comma' && stringify_is_array(obj)) {
        obj = maybe_map(obj, function (value) {
            if (value instanceof Date) {
                return serializeDate?.(value);
            }
            return value;
        });
    }
    if (obj === null) {
        if (strictNullHandling) {
            return encoder && !encodeValuesOnly ?
                // @ts-expect-error
                encoder(prefix, defaults.encoder, charset, 'key', format)
                : prefix;
        }
        obj = '';
    }
    if (is_non_nullish_primitive(obj) || is_buffer(obj)) {
        if (encoder) {
            const key_value = encodeValuesOnly ? prefix
                // @ts-expect-error
                : encoder(prefix, defaults.encoder, charset, 'key', format);
            return [
                formatter?.(key_value) +
                    '=' +
                    // @ts-expect-error
                    formatter?.(encoder(obj, defaults.encoder, charset, 'value', format)),
            ];
        }
        return [formatter?.(prefix) + '=' + formatter?.(String(obj))];
    }
    const values = [];
    if (typeof obj === 'undefined') {
        return values;
    }
    let obj_keys;
    if (generateArrayPrefix === 'comma' && stringify_is_array(obj)) {
        // we need to join elements in
        if (encodeValuesOnly && encoder) {
            // @ts-expect-error values only
            obj = maybe_map(obj, encoder);
        }
        obj_keys = [{ value: obj.length > 0 ? obj.join(',') || null : void undefined }];
    }
    else if (stringify_is_array(filter)) {
        obj_keys = filter;
    }
    else {
        const keys = Object.keys(obj);
        obj_keys = sort ? keys.sort(sort) : keys;
    }
    const encoded_prefix = encodeDotInKeys ? String(prefix).replace(/\./g, '%2E') : String(prefix);
    const adjusted_prefix = commaRoundTrip && stringify_is_array(obj) && obj.length === 1 ? encoded_prefix + '[]' : encoded_prefix;
    if (allowEmptyArrays && stringify_is_array(obj) && obj.length === 0) {
        return adjusted_prefix + '[]';
    }
    for (let j = 0; j < obj_keys.length; ++j) {
        const key = obj_keys[j];
        const value = 
        // @ts-ignore
        typeof key === 'object' && typeof key.value !== 'undefined' ? key.value : obj[key];
        if (skipNulls && value === null) {
            continue;
        }
        // @ts-ignore
        const encoded_key = allowDots && encodeDotInKeys ? key.replace(/\./g, '%2E') : key;
        const key_prefix = stringify_is_array(obj) ?
            typeof generateArrayPrefix === 'function' ?
                generateArrayPrefix(adjusted_prefix, encoded_key)
                : adjusted_prefix
            : adjusted_prefix + (allowDots ? '.' + encoded_key : '[' + encoded_key + ']');
        sideChannel.set(object, step);
        const valueSideChannel = new WeakMap();
        valueSideChannel.set(sentinel, sideChannel);
        push_to_array(values, inner_stringify(value, key_prefix, generateArrayPrefix, commaRoundTrip, allowEmptyArrays, strictNullHandling, skipNulls, encodeDotInKeys, 
        // @ts-ignore
        generateArrayPrefix === 'comma' && encodeValuesOnly && stringify_is_array(obj) ? null : encoder, filter, sort, allowDots, serializeDate, format, formatter, encodeValuesOnly, charset, valueSideChannel));
    }
    return values;
}
function normalize_stringify_options(opts = defaults) {
    if (typeof opts.allowEmptyArrays !== 'undefined' && typeof opts.allowEmptyArrays !== 'boolean') {
        throw new TypeError('`allowEmptyArrays` option can only be `true` or `false`, when provided');
    }
    if (typeof opts.encodeDotInKeys !== 'undefined' && typeof opts.encodeDotInKeys !== 'boolean') {
        throw new TypeError('`encodeDotInKeys` option can only be `true` or `false`, when provided');
    }
    if (opts.encoder !== null && typeof opts.encoder !== 'undefined' && typeof opts.encoder !== 'function') {
        throw new TypeError('Encoder has to be a function.');
    }
    const charset = opts.charset || defaults.charset;
    if (typeof opts.charset !== 'undefined' && opts.charset !== 'utf-8' && opts.charset !== 'iso-8859-1') {
        throw new TypeError('The charset option must be either utf-8, iso-8859-1, or undefined');
    }
    let format = default_format;
    if (typeof opts.format !== 'undefined') {
        if (!stringify_has.call(formatters, opts.format)) {
            throw new TypeError('Unknown format option provided.');
        }
        format = opts.format;
    }
    const formatter = formatters[format];
    let filter = defaults.filter;
    if (typeof opts.filter === 'function' || stringify_is_array(opts.filter)) {
        filter = opts.filter;
    }
    let arrayFormat;
    if (opts.arrayFormat && opts.arrayFormat in array_prefix_generators) {
        arrayFormat = opts.arrayFormat;
    }
    else if ('indices' in opts) {
        arrayFormat = opts.indices ? 'indices' : 'repeat';
    }
    else {
        arrayFormat = defaults.arrayFormat;
    }
    if ('commaRoundTrip' in opts && typeof opts.commaRoundTrip !== 'boolean') {
        throw new TypeError('`commaRoundTrip` must be a boolean, or absent');
    }
    const allowDots = typeof opts.allowDots === 'undefined' ?
        !!opts.encodeDotInKeys === true ?
            true
            : defaults.allowDots
        : !!opts.allowDots;
    return {
        addQueryPrefix: typeof opts.addQueryPrefix === 'boolean' ? opts.addQueryPrefix : defaults.addQueryPrefix,
        // @ts-ignore
        allowDots: allowDots,
        allowEmptyArrays: typeof opts.allowEmptyArrays === 'boolean' ? !!opts.allowEmptyArrays : defaults.allowEmptyArrays,
        arrayFormat: arrayFormat,
        charset: charset,
        charsetSentinel: typeof opts.charsetSentinel === 'boolean' ? opts.charsetSentinel : defaults.charsetSentinel,
        commaRoundTrip: !!opts.commaRoundTrip,
        delimiter: typeof opts.delimiter === 'undefined' ? defaults.delimiter : opts.delimiter,
        encode: typeof opts.encode === 'boolean' ? opts.encode : defaults.encode,
        encodeDotInKeys: typeof opts.encodeDotInKeys === 'boolean' ? opts.encodeDotInKeys : defaults.encodeDotInKeys,
        encoder: typeof opts.encoder === 'function' ? opts.encoder : defaults.encoder,
        encodeValuesOnly: typeof opts.encodeValuesOnly === 'boolean' ? opts.encodeValuesOnly : defaults.encodeValuesOnly,
        filter: filter,
        format: format,
        formatter: formatter,
        serializeDate: typeof opts.serializeDate === 'function' ? opts.serializeDate : defaults.serializeDate,
        skipNulls: typeof opts.skipNulls === 'boolean' ? opts.skipNulls : defaults.skipNulls,
        // @ts-ignore
        sort: typeof opts.sort === 'function' ? opts.sort : null,
        strictNullHandling: typeof opts.strictNullHandling === 'boolean' ? opts.strictNullHandling : defaults.strictNullHandling,
    };
}
function stringify(object, opts = {}) {
    let obj = object;
    const options = normalize_stringify_options(opts);
    let obj_keys;
    let filter;
    if (typeof options.filter === 'function') {
        filter = options.filter;
        obj = filter('', obj);
    }
    else if (stringify_is_array(options.filter)) {
        filter = options.filter;
        obj_keys = filter;
    }
    const keys = [];
    if (typeof obj !== 'object' || obj === null) {
        return '';
    }
    const generateArrayPrefix = array_prefix_generators[options.arrayFormat];
    const commaRoundTrip = generateArrayPrefix === 'comma' && options.commaRoundTrip;
    if (!obj_keys) {
        obj_keys = Object.keys(obj);
    }
    if (options.sort) {
        obj_keys.sort(options.sort);
    }
    const sideChannel = new WeakMap();
    for (let i = 0; i < obj_keys.length; ++i) {
        const key = obj_keys[i];
        if (options.skipNulls && obj[key] === null) {
            continue;
        }
        push_to_array(keys, inner_stringify(obj[key], key, 
        // @ts-expect-error
        generateArrayPrefix, commaRoundTrip, options.allowEmptyArrays, options.strictNullHandling, options.skipNulls, options.encodeDotInKeys, options.encode ? options.encoder : null, options.filter, options.sort, options.allowDots, options.serializeDate, options.format, options.formatter, options.encodeValuesOnly, options.charset, sideChannel));
    }
    const joined = keys.join(options.delimiter);
    let prefix = options.addQueryPrefix === true ? '?' : '';
    if (options.charsetSentinel) {
        if (options.charset === 'iso-8859-1') {
            // encodeURIComponent('&#10003;'), the "numeric entity" representation of a checkmark
            prefix += 'utf8=%26%2310003%3B&';
        }
        else {
            // encodeURIComponent('✓')
            prefix += 'utf8=%E2%9C%93&';
        }
    }
    return joined.length > 0 ? prefix + joined : '';
}
//# sourceMappingURL=stringify.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/version.mjs
const VERSION = '4.91.0'; // x-release-please-version
//# sourceMappingURL=version.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/_shims/registry.mjs
let auto = false;
let kind = undefined;
let registry_fetch = undefined;
let registry_Request = (/* unused pure expression or super */ null && (undefined));
let registry_Response = (/* unused pure expression or super */ null && (undefined));
let registry_Headers = (/* unused pure expression or super */ null && (undefined));
let registry_FormData = undefined;
let registry_Blob = (/* unused pure expression or super */ null && (undefined));
let registry_File = undefined;
let registry_ReadableStream = undefined;
let registry_getMultipartRequestOptions = undefined;
let getDefaultAgent = undefined;
let fileFromPath = undefined;
let isFsReadStream = undefined;
function setShims(shims, options = { auto: false }) {
    if (auto) {
        throw new Error(`you must \`import 'openai/shims/${shims.kind}'\` before importing anything else from openai`);
    }
    if (kind) {
        throw new Error(`can't \`import 'openai/shims/${shims.kind}'\` after \`import 'openai/shims/${kind}'\``);
    }
    auto = options.auto;
    kind = shims.kind;
    registry_fetch = shims.fetch;
    registry_Request = shims.Request;
    registry_Response = shims.Response;
    registry_Headers = shims.Headers;
    registry_FormData = shims.FormData;
    registry_Blob = shims.Blob;
    registry_File = shims.File;
    registry_ReadableStream = shims.ReadableStream;
    registry_getMultipartRequestOptions = shims.getMultipartRequestOptions;
    getDefaultAgent = shims.getDefaultAgent;
    fileFromPath = shims.fileFromPath;
    isFsReadStream = shims.isFsReadStream;
}
//# sourceMappingURL=registry.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/_shims/MultipartBody.mjs
/**
 * Disclaimer: modules in _shims aren't intended to be imported by SDK users.
 */
class MultipartBody {
    constructor(body) {
        this.body = body;
    }
    get [Symbol.toStringTag]() {
        return 'MultipartBody';
    }
}
//# sourceMappingURL=MultipartBody.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/_shims/web-runtime.mjs

function getRuntime({ manuallyImported } = {}) {
    const recommendation = manuallyImported ?
        `You may need to use polyfills`
        : `Add one of these imports before your first \`import … from 'openai'\`:
- \`import 'openai/shims/node'\` (if you're running on Node)
- \`import 'openai/shims/web'\` (otherwise)
`;
    let _fetch, _Request, _Response, _Headers;
    try {
        // @ts-ignore
        _fetch = fetch;
        // @ts-ignore
        _Request = Request;
        // @ts-ignore
        _Response = Response;
        // @ts-ignore
        _Headers = Headers;
    }
    catch (error) {
        throw new Error(`this environment is missing the following Web Fetch API type: ${error.message}. ${recommendation}`);
    }
    return {
        kind: 'web',
        fetch: _fetch,
        Request: _Request,
        Response: _Response,
        Headers: _Headers,
        FormData: 
        // @ts-ignore
        typeof FormData !== 'undefined' ? FormData : (class FormData {
            // @ts-ignore
            constructor() {
                throw new Error(`file uploads aren't supported in this environment yet as 'FormData' is undefined. ${recommendation}`);
            }
        }),
        Blob: typeof Blob !== 'undefined' ? Blob : (class Blob {
            constructor() {
                throw new Error(`file uploads aren't supported in this environment yet as 'Blob' is undefined. ${recommendation}`);
            }
        }),
        File: 
        // @ts-ignore
        typeof File !== 'undefined' ? File : (class File {
            // @ts-ignore
            constructor() {
                throw new Error(`file uploads aren't supported in this environment yet as 'File' is undefined. ${recommendation}`);
            }
        }),
        ReadableStream: 
        // @ts-ignore
        typeof ReadableStream !== 'undefined' ? ReadableStream : (class ReadableStream {
            // @ts-ignore
            constructor() {
                throw new Error(`streaming isn't supported in this environment yet as 'ReadableStream' is undefined. ${recommendation}`);
            }
        }),
        getMultipartRequestOptions: async (
        // @ts-ignore
        form, opts) => ({
            ...opts,
            body: new MultipartBody(form),
        }),
        getDefaultAgent: (url) => undefined,
        fileFromPath: () => {
            throw new Error('The `fileFromPath` function is only supported in Node. See the README for more details: https://www.github.com/openai/openai-node#file-uploads');
        },
        isFsReadStream: (value) => false,
    };
}
//# sourceMappingURL=web-runtime.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/_shims/index.mjs
/**
 * Disclaimer: modules in _shims aren't intended to be imported by SDK users.
 */


const init = () => {
  if (!kind) setShims(getRuntime(), { auto: true });
};


init();

;// CONCATENATED MODULE: ./node_modules/openai/error.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class error_OpenAIError extends Error {
}
class APIError extends error_OpenAIError {
    constructor(status, error, message, headers) {
        super(`${APIError.makeMessage(status, error, message)}`);
        this.status = status;
        this.headers = headers;
        this.request_id = headers?.['x-request-id'];
        this.error = error;
        const data = error;
        this.code = data?.['code'];
        this.param = data?.['param'];
        this.type = data?.['type'];
    }
    static makeMessage(status, error, message) {
        const msg = error?.message ?
            typeof error.message === 'string' ?
                error.message
                : JSON.stringify(error.message)
            : error ? JSON.stringify(error)
                : message;
        if (status && msg) {
            return `${status} ${msg}`;
        }
        if (status) {
            return `${status} status code (no body)`;
        }
        if (msg) {
            return msg;
        }
        return '(no status code or body)';
    }
    static generate(status, errorResponse, message, headers) {
        if (!status || !headers) {
            return new APIConnectionError({ message, cause: castToError(errorResponse) });
        }
        const error = errorResponse?.['error'];
        if (status === 400) {
            return new BadRequestError(status, error, message, headers);
        }
        if (status === 401) {
            return new AuthenticationError(status, error, message, headers);
        }
        if (status === 403) {
            return new PermissionDeniedError(status, error, message, headers);
        }
        if (status === 404) {
            return new NotFoundError(status, error, message, headers);
        }
        if (status === 409) {
            return new ConflictError(status, error, message, headers);
        }
        if (status === 422) {
            return new UnprocessableEntityError(status, error, message, headers);
        }
        if (status === 429) {
            return new RateLimitError(status, error, message, headers);
        }
        if (status >= 500) {
            return new InternalServerError(status, error, message, headers);
        }
        return new APIError(status, error, message, headers);
    }
}
class APIUserAbortError extends APIError {
    constructor({ message } = {}) {
        super(undefined, undefined, message || 'Request was aborted.', undefined);
    }
}
class APIConnectionError extends APIError {
    constructor({ message, cause }) {
        super(undefined, undefined, message || 'Connection error.', undefined);
        // in some environments the 'cause' property is already declared
        // @ts-ignore
        if (cause)
            this.cause = cause;
    }
}
class APIConnectionTimeoutError extends APIConnectionError {
    constructor({ message } = {}) {
        super({ message: message ?? 'Request timed out.' });
    }
}
class BadRequestError extends APIError {
}
class AuthenticationError extends APIError {
}
class PermissionDeniedError extends APIError {
}
class NotFoundError extends APIError {
}
class ConflictError extends APIError {
}
class UnprocessableEntityError extends APIError {
}
class RateLimitError extends APIError {
}
class InternalServerError extends APIError {
}
class LengthFinishReasonError extends error_OpenAIError {
    constructor() {
        super(`Could not parse response content as the length limit was reached`);
    }
}
class ContentFilterFinishReasonError extends error_OpenAIError {
    constructor() {
        super(`Could not parse response content as the request was rejected by the content filter`);
    }
}
//# sourceMappingURL=error.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/internal/decoders/line.mjs
/* provided dependency */ var Buffer = __webpack_require__(8287)["hp"];
var __classPrivateFieldSet = (undefined && undefined.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var __classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _LineDecoder_carriageReturnIndex;

/**
 * A re-implementation of httpx's `LineDecoder` in Python that handles incrementally
 * reading lines from text.
 *
 * https://github.com/encode/httpx/blob/920333ea98118e9cf617f246905d7b202510941c/httpx/_decoders.py#L258
 */
class LineDecoder {
    constructor() {
        _LineDecoder_carriageReturnIndex.set(this, void 0);
        this.buffer = new Uint8Array();
        __classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, null, "f");
    }
    decode(chunk) {
        if (chunk == null) {
            return [];
        }
        const binaryChunk = chunk instanceof ArrayBuffer ? new Uint8Array(chunk)
            : typeof chunk === 'string' ? new TextEncoder().encode(chunk)
                : chunk;
        let newData = new Uint8Array(this.buffer.length + binaryChunk.length);
        newData.set(this.buffer);
        newData.set(binaryChunk, this.buffer.length);
        this.buffer = newData;
        const lines = [];
        let patternIndex;
        while ((patternIndex = findNewlineIndex(this.buffer, __classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f"))) != null) {
            if (patternIndex.carriage && __classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") == null) {
                // skip until we either get a corresponding `\n`, a new `\r` or nothing
                __classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, patternIndex.index, "f");
                continue;
            }
            // we got double \r or \rtext\n
            if (__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") != null &&
                (patternIndex.index !== __classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") + 1 || patternIndex.carriage)) {
                lines.push(this.decodeText(this.buffer.slice(0, __classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") - 1)));
                this.buffer = this.buffer.slice(__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f"));
                __classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, null, "f");
                continue;
            }
            const endIndex = __classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") !== null ? patternIndex.preceding - 1 : patternIndex.preceding;
            const line = this.decodeText(this.buffer.slice(0, endIndex));
            lines.push(line);
            this.buffer = this.buffer.slice(patternIndex.index);
            __classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, null, "f");
        }
        return lines;
    }
    decodeText(bytes) {
        if (bytes == null)
            return '';
        if (typeof bytes === 'string')
            return bytes;
        // Node:
        if (typeof Buffer !== 'undefined') {
            if (bytes instanceof Buffer) {
                return bytes.toString();
            }
            if (bytes instanceof Uint8Array) {
                return Buffer.from(bytes).toString();
            }
            throw new error_OpenAIError(`Unexpected: received non-Uint8Array (${bytes.constructor.name}) stream chunk in an environment with a global "Buffer" defined, which this library assumes to be Node. Please report this error.`);
        }
        // Browser
        if (typeof TextDecoder !== 'undefined') {
            if (bytes instanceof Uint8Array || bytes instanceof ArrayBuffer) {
                this.textDecoder ?? (this.textDecoder = new TextDecoder('utf8'));
                return this.textDecoder.decode(bytes);
            }
            throw new error_OpenAIError(`Unexpected: received non-Uint8Array/ArrayBuffer (${bytes.constructor.name}) in a web platform. Please report this error.`);
        }
        throw new error_OpenAIError(`Unexpected: neither Buffer nor TextDecoder are available as globals. Please report this error.`);
    }
    flush() {
        if (!this.buffer.length) {
            return [];
        }
        return this.decode('\n');
    }
}
_LineDecoder_carriageReturnIndex = new WeakMap();
// prettier-ignore
LineDecoder.NEWLINE_CHARS = new Set(['\n', '\r']);
LineDecoder.NEWLINE_REGEXP = /\r\n|[\n\r]/g;
/**
 * This function searches the buffer for the end patterns, (\r or \n)
 * and returns an object with the index preceding the matched newline and the
 * index after the newline char. `null` is returned if no new line is found.
 *
 * ```ts
 * findNewLineIndex('abc\ndef') -> { preceding: 2, index: 3 }
 * ```
 */
function findNewlineIndex(buffer, startIndex) {
    const newline = 0x0a; // \n
    const carriage = 0x0d; // \r
    for (let i = startIndex ?? 0; i < buffer.length; i++) {
        if (buffer[i] === newline) {
            return { preceding: i, index: i + 1, carriage: false };
        }
        if (buffer[i] === carriage) {
            return { preceding: i, index: i + 1, carriage: true };
        }
    }
    return null;
}
function findDoubleNewlineIndex(buffer) {
    // This function searches the buffer for the end patterns (\r\r, \n\n, \r\n\r\n)
    // and returns the index right after the first occurrence of any pattern,
    // or -1 if none of the patterns are found.
    const newline = 0x0a; // \n
    const carriage = 0x0d; // \r
    for (let i = 0; i < buffer.length - 1; i++) {
        if (buffer[i] === newline && buffer[i + 1] === newline) {
            // \n\n
            return i + 2;
        }
        if (buffer[i] === carriage && buffer[i + 1] === carriage) {
            // \r\r
            return i + 2;
        }
        if (buffer[i] === carriage &&
            buffer[i + 1] === newline &&
            i + 3 < buffer.length &&
            buffer[i + 2] === carriage &&
            buffer[i + 3] === newline) {
            // \r\n\r\n
            return i + 4;
        }
    }
    return -1;
}
//# sourceMappingURL=line.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/internal/stream-utils.mjs
/**
 * Most browsers don't yet have async iterable support for ReadableStream,
 * and Node has a very different way of reading bytes from its "ReadableStream".
 *
 * This polyfill was pulled from https://github.com/MattiasBuelens/web-streams-polyfill/pull/122#issuecomment-1627354490
 */
function ReadableStreamToAsyncIterable(stream) {
    if (stream[Symbol.asyncIterator])
        return stream;
    const reader = stream.getReader();
    return {
        async next() {
            try {
                const result = await reader.read();
                if (result?.done)
                    reader.releaseLock(); // release lock when stream becomes closed
                return result;
            }
            catch (e) {
                reader.releaseLock(); // release lock when stream becomes errored
                throw e;
            }
        },
        async return() {
            const cancelPromise = reader.cancel();
            reader.releaseLock();
            await cancelPromise;
            return { done: true, value: undefined };
        },
        [Symbol.asyncIterator]() {
            return this;
        },
    };
}
//# sourceMappingURL=stream-utils.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/streaming.mjs






class Stream {
    constructor(iterator, controller) {
        this.iterator = iterator;
        this.controller = controller;
    }
    static fromSSEResponse(response, controller) {
        let consumed = false;
        async function* iterator() {
            if (consumed) {
                throw new Error('Cannot iterate over a consumed stream, use `.tee()` to split the stream.');
            }
            consumed = true;
            let done = false;
            try {
                for await (const sse of _iterSSEMessages(response, controller)) {
                    if (done)
                        continue;
                    if (sse.data.startsWith('[DONE]')) {
                        done = true;
                        continue;
                    }
                    if (sse.event === null ||
                        sse.event.startsWith('response.') ||
                        sse.event.startsWith('transcript.')) {
                        let data;
                        try {
                            data = JSON.parse(sse.data);
                        }
                        catch (e) {
                            console.error(`Could not parse message into JSON:`, sse.data);
                            console.error(`From chunk:`, sse.raw);
                            throw e;
                        }
                        if (data && data.error) {
                            throw new APIError(undefined, data.error, undefined, createResponseHeaders(response.headers));
                        }
                        yield data;
                    }
                    else {
                        let data;
                        try {
                            data = JSON.parse(sse.data);
                        }
                        catch (e) {
                            console.error(`Could not parse message into JSON:`, sse.data);
                            console.error(`From chunk:`, sse.raw);
                            throw e;
                        }
                        // TODO: Is this where the error should be thrown?
                        if (sse.event == 'error') {
                            throw new APIError(undefined, data.error, data.message, undefined);
                        }
                        yield { event: sse.event, data: data };
                    }
                }
                done = true;
            }
            catch (e) {
                // If the user calls `stream.controller.abort()`, we should exit without throwing.
                if (e instanceof Error && e.name === 'AbortError')
                    return;
                throw e;
            }
            finally {
                // If the user `break`s, abort the ongoing request.
                if (!done)
                    controller.abort();
            }
        }
        return new Stream(iterator, controller);
    }
    /**
     * Generates a Stream from a newline-separated ReadableStream
     * where each item is a JSON value.
     */
    static fromReadableStream(readableStream, controller) {
        let consumed = false;
        async function* iterLines() {
            const lineDecoder = new LineDecoder();
            const iter = ReadableStreamToAsyncIterable(readableStream);
            for await (const chunk of iter) {
                for (const line of lineDecoder.decode(chunk)) {
                    yield line;
                }
            }
            for (const line of lineDecoder.flush()) {
                yield line;
            }
        }
        async function* iterator() {
            if (consumed) {
                throw new Error('Cannot iterate over a consumed stream, use `.tee()` to split the stream.');
            }
            consumed = true;
            let done = false;
            try {
                for await (const line of iterLines()) {
                    if (done)
                        continue;
                    if (line)
                        yield JSON.parse(line);
                }
                done = true;
            }
            catch (e) {
                // If the user calls `stream.controller.abort()`, we should exit without throwing.
                if (e instanceof Error && e.name === 'AbortError')
                    return;
                throw e;
            }
            finally {
                // If the user `break`s, abort the ongoing request.
                if (!done)
                    controller.abort();
            }
        }
        return new Stream(iterator, controller);
    }
    [Symbol.asyncIterator]() {
        return this.iterator();
    }
    /**
     * Splits the stream into two streams which can be
     * independently read from at different speeds.
     */
    tee() {
        const left = [];
        const right = [];
        const iterator = this.iterator();
        const teeIterator = (queue) => {
            return {
                next: () => {
                    if (queue.length === 0) {
                        const result = iterator.next();
                        left.push(result);
                        right.push(result);
                    }
                    return queue.shift();
                },
            };
        };
        return [
            new Stream(() => teeIterator(left), this.controller),
            new Stream(() => teeIterator(right), this.controller),
        ];
    }
    /**
     * Converts this stream to a newline-separated ReadableStream of
     * JSON stringified values in the stream
     * which can be turned back into a Stream with `Stream.fromReadableStream()`.
     */
    toReadableStream() {
        const self = this;
        let iter;
        const encoder = new TextEncoder();
        return new registry_ReadableStream({
            async start() {
                iter = self[Symbol.asyncIterator]();
            },
            async pull(ctrl) {
                try {
                    const { value, done } = await iter.next();
                    if (done)
                        return ctrl.close();
                    const bytes = encoder.encode(JSON.stringify(value) + '\n');
                    ctrl.enqueue(bytes);
                }
                catch (err) {
                    ctrl.error(err);
                }
            },
            async cancel() {
                await iter.return?.();
            },
        });
    }
}
async function* _iterSSEMessages(response, controller) {
    if (!response.body) {
        controller.abort();
        throw new error_OpenAIError(`Attempted to iterate over a response with no body`);
    }
    const sseDecoder = new SSEDecoder();
    const lineDecoder = new LineDecoder();
    const iter = ReadableStreamToAsyncIterable(response.body);
    for await (const sseChunk of iterSSEChunks(iter)) {
        for (const line of lineDecoder.decode(sseChunk)) {
            const sse = sseDecoder.decode(line);
            if (sse)
                yield sse;
        }
    }
    for (const line of lineDecoder.flush()) {
        const sse = sseDecoder.decode(line);
        if (sse)
            yield sse;
    }
}
/**
 * Given an async iterable iterator, iterates over it and yields full
 * SSE chunks, i.e. yields when a double new-line is encountered.
 */
async function* iterSSEChunks(iterator) {
    let data = new Uint8Array();
    for await (const chunk of iterator) {
        if (chunk == null) {
            continue;
        }
        const binaryChunk = chunk instanceof ArrayBuffer ? new Uint8Array(chunk)
            : typeof chunk === 'string' ? new TextEncoder().encode(chunk)
                : chunk;
        let newData = new Uint8Array(data.length + binaryChunk.length);
        newData.set(data);
        newData.set(binaryChunk, data.length);
        data = newData;
        let patternIndex;
        while ((patternIndex = findDoubleNewlineIndex(data)) !== -1) {
            yield data.slice(0, patternIndex);
            data = data.slice(patternIndex);
        }
    }
    if (data.length > 0) {
        yield data;
    }
}
class SSEDecoder {
    constructor() {
        this.event = null;
        this.data = [];
        this.chunks = [];
    }
    decode(line) {
        if (line.endsWith('\r')) {
            line = line.substring(0, line.length - 1);
        }
        if (!line) {
            // empty line and we didn't previously encounter any messages
            if (!this.event && !this.data.length)
                return null;
            const sse = {
                event: this.event,
                data: this.data.join('\n'),
                raw: this.chunks,
            };
            this.event = null;
            this.data = [];
            this.chunks = [];
            return sse;
        }
        this.chunks.push(line);
        if (line.startsWith(':')) {
            return null;
        }
        let [fieldname, _, value] = partition(line, ':');
        if (value.startsWith(' ')) {
            value = value.substring(1);
        }
        if (fieldname === 'event') {
            this.event = value;
        }
        else if (fieldname === 'data') {
            this.data.push(value);
        }
        return null;
    }
}
function partition(str, delimiter) {
    const index = str.indexOf(delimiter);
    if (index !== -1) {
        return [str.substring(0, index), delimiter, str.substring(index + delimiter.length)];
    }
    return [str, '', ''];
}
//# sourceMappingURL=streaming.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/uploads.mjs
/* provided dependency */ var uploads_Buffer = __webpack_require__(8287)["hp"];


const isResponseLike = (value) => value != null &&
    typeof value === 'object' &&
    typeof value.url === 'string' &&
    typeof value.blob === 'function';
const isFileLike = (value) => value != null &&
    typeof value === 'object' &&
    typeof value.name === 'string' &&
    typeof value.lastModified === 'number' &&
    isBlobLike(value);
/**
 * The BlobLike type omits arrayBuffer() because @types/node-fetch@^2.6.4 lacks it; but this check
 * adds the arrayBuffer() method type because it is available and used at runtime
 */
const isBlobLike = (value) => value != null &&
    typeof value === 'object' &&
    typeof value.size === 'number' &&
    typeof value.type === 'string' &&
    typeof value.text === 'function' &&
    typeof value.slice === 'function' &&
    typeof value.arrayBuffer === 'function';
const isUploadable = (value) => {
    return isFileLike(value) || isResponseLike(value) || isFsReadStream(value);
};
/**
 * Helper for creating a {@link File} to pass to an SDK upload method from a variety of different data formats
 * @param value the raw content of the file.  Can be an {@link Uploadable}, {@link BlobLikePart}, or {@link AsyncIterable} of {@link BlobLikePart}s
 * @param {string=} name the name of the file. If omitted, toFile will try to determine a file name from bits if possible
 * @param {Object=} options additional properties
 * @param {string=} options.type the MIME type of the content
 * @param {number=} options.lastModified the last modified timestamp
 * @returns a {@link File} with the given properties
 */
async function toFile(value, name, options) {
    // If it's a promise, resolve it.
    value = await value;
    // If we've been given a `File` we don't need to do anything
    if (isFileLike(value)) {
        return value;
    }
    if (isResponseLike(value)) {
        const blob = await value.blob();
        name || (name = new URL(value.url).pathname.split(/[\\/]/).pop() ?? 'unknown_file');
        // we need to convert the `Blob` into an array buffer because the `Blob` class
        // that `node-fetch` defines is incompatible with the web standard which results
        // in `new File` interpreting it as a string instead of binary data.
        const data = isBlobLike(blob) ? [(await blob.arrayBuffer())] : [blob];
        return new registry_File(data, name, options);
    }
    const bits = await getBytes(value);
    name || (name = getName(value) ?? 'unknown_file');
    if (!options?.type) {
        const type = bits[0]?.type;
        if (typeof type === 'string') {
            options = { ...options, type };
        }
    }
    return new registry_File(bits, name, options);
}
async function getBytes(value) {
    let parts = [];
    if (typeof value === 'string' ||
        ArrayBuffer.isView(value) || // includes Uint8Array, Buffer, etc.
        value instanceof ArrayBuffer) {
        parts.push(value);
    }
    else if (isBlobLike(value)) {
        parts.push(await value.arrayBuffer());
    }
    else if (isAsyncIterableIterator(value) // includes Readable, ReadableStream, etc.
    ) {
        for await (const chunk of value) {
            parts.push(chunk); // TODO, consider validating?
        }
    }
    else {
        throw new Error(`Unexpected data type: ${typeof value}; constructor: ${value?.constructor
            ?.name}; props: ${propsForError(value)}`);
    }
    return parts;
}
function propsForError(value) {
    const props = Object.getOwnPropertyNames(value);
    return `[${props.map((p) => `"${p}"`).join(', ')}]`;
}
function getName(value) {
    return (getStringFromMaybeBuffer(value.name) ||
        getStringFromMaybeBuffer(value.filename) ||
        // For fs.ReadStream
        getStringFromMaybeBuffer(value.path)?.split(/[\\/]/).pop());
}
const getStringFromMaybeBuffer = (x) => {
    if (typeof x === 'string')
        return x;
    if (typeof uploads_Buffer !== 'undefined' && x instanceof uploads_Buffer)
        return String(x);
    return undefined;
};
const isAsyncIterableIterator = (value) => value != null && typeof value === 'object' && typeof value[Symbol.asyncIterator] === 'function';
const isMultipartBody = (body) => body && typeof body === 'object' && body.body && body[Symbol.toStringTag] === 'MultipartBody';
/**
 * Returns a multipart/form-data request if any part of the given request body contains a File / Blob value.
 * Otherwise returns the request as is.
 */
const maybeMultipartFormRequestOptions = async (opts) => {
    if (!hasUploadableValue(opts.body))
        return opts;
    const form = await createForm(opts.body);
    return getMultipartRequestOptions(form, opts);
};
const multipartFormRequestOptions = async (opts) => {
    const form = await createForm(opts.body);
    return registry_getMultipartRequestOptions(form, opts);
};
const createForm = async (body) => {
    const form = new registry_FormData();
    await Promise.all(Object.entries(body || {}).map(([key, value]) => addFormValue(form, key, value)));
    return form;
};
const hasUploadableValue = (value) => {
    if (isUploadable(value))
        return true;
    if (Array.isArray(value))
        return value.some(hasUploadableValue);
    if (value && typeof value === 'object') {
        for (const k in value) {
            if (hasUploadableValue(value[k]))
                return true;
        }
    }
    return false;
};
const addFormValue = async (form, key, value) => {
    if (value === undefined)
        return;
    if (value == null) {
        throw new TypeError(`Received null for "${key}"; to pass null in FormData, you must use the string 'null'`);
    }
    // TODO: make nested formats configurable
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
        form.append(key, String(value));
    }
    else if (isUploadable(value)) {
        const file = await toFile(value);
        form.append(key, file);
    }
    else if (Array.isArray(value)) {
        await Promise.all(value.map((entry) => addFormValue(form, key + '[]', entry)));
    }
    else if (typeof value === 'object') {
        await Promise.all(Object.entries(value).map(([name, prop]) => addFormValue(form, `${key}[${name}]`, prop)));
    }
    else {
        throw new TypeError(`Invalid value given to form, expected a string, number, boolean, object, Array, File or Blob but got ${value} instead`);
    }
};
//# sourceMappingURL=uploads.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/core.mjs
/* provided dependency */ var core_Buffer = __webpack_require__(8287)["hp"];
/* provided dependency */ var process = __webpack_require__(5606);
var core_classPrivateFieldSet = (undefined && undefined.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var core_classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _AbstractPage_client;




// try running side effects outside of _shims/index to workaround https://github.com/vercel/next.js/issues/76881
init();


async function defaultParseResponse(props) {
    const { response } = props;
    if (props.options.stream) {
        debug('response', response.status, response.url, response.headers, response.body);
        // Note: there is an invariant here that isn't represented in the type system
        // that if you set `stream: true` the response type must also be `Stream<T>`
        if (props.options.__streamClass) {
            return props.options.__streamClass.fromSSEResponse(response, props.controller);
        }
        return Stream.fromSSEResponse(response, props.controller);
    }
    // fetch refuses to read the body when the status code is 204.
    if (response.status === 204) {
        return null;
    }
    if (props.options.__binaryResponse) {
        return response;
    }
    const contentType = response.headers.get('content-type');
    const mediaType = contentType?.split(';')[0]?.trim();
    const isJSON = mediaType?.includes('application/json') || mediaType?.endsWith('+json');
    if (isJSON) {
        const json = await response.json();
        debug('response', response.status, response.url, response.headers, json);
        return _addRequestID(json, response);
    }
    const text = await response.text();
    debug('response', response.status, response.url, response.headers, text);
    // TODO handle blob, arraybuffer, other content types, etc.
    return text;
}
function _addRequestID(value, response) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
        return value;
    }
    return Object.defineProperty(value, '_request_id', {
        value: response.headers.get('x-request-id'),
        enumerable: false,
    });
}
/**
 * A subclass of `Promise` providing additional helper methods
 * for interacting with the SDK.
 */
class APIPromise extends Promise {
    constructor(responsePromise, parseResponse = defaultParseResponse) {
        super((resolve) => {
            // this is maybe a bit weird but this has to be a no-op to not implicitly
            // parse the response body; instead .then, .catch, .finally are overridden
            // to parse the response
            resolve(null);
        });
        this.responsePromise = responsePromise;
        this.parseResponse = parseResponse;
    }
    _thenUnwrap(transform) {
        return new APIPromise(this.responsePromise, async (props) => _addRequestID(transform(await this.parseResponse(props), props), props.response));
    }
    /**
     * Gets the raw `Response` instance instead of parsing the response
     * data.
     *
     * If you want to parse the response body but still get the `Response`
     * instance, you can use {@link withResponse()}.
     *
     * 👋 Getting the wrong TypeScript type for `Response`?
     * Try setting `"moduleResolution": "NodeNext"` if you can,
     * or add one of these imports before your first `import … from 'openai'`:
     * - `import 'openai/shims/node'` (if you're running on Node)
     * - `import 'openai/shims/web'` (otherwise)
     */
    asResponse() {
        return this.responsePromise.then((p) => p.response);
    }
    /**
     * Gets the parsed response data, the raw `Response` instance and the ID of the request,
     * returned via the X-Request-ID header which is useful for debugging requests and reporting
     * issues to OpenAI.
     *
     * If you just want to get the raw `Response` instance without parsing it,
     * you can use {@link asResponse()}.
     *
     *
     * 👋 Getting the wrong TypeScript type for `Response`?
     * Try setting `"moduleResolution": "NodeNext"` if you can,
     * or add one of these imports before your first `import … from 'openai'`:
     * - `import 'openai/shims/node'` (if you're running on Node)
     * - `import 'openai/shims/web'` (otherwise)
     */
    async withResponse() {
        const [data, response] = await Promise.all([this.parse(), this.asResponse()]);
        return { data, response, request_id: response.headers.get('x-request-id') };
    }
    parse() {
        if (!this.parsedPromise) {
            this.parsedPromise = this.responsePromise.then(this.parseResponse);
        }
        return this.parsedPromise;
    }
    then(onfulfilled, onrejected) {
        return this.parse().then(onfulfilled, onrejected);
    }
    catch(onrejected) {
        return this.parse().catch(onrejected);
    }
    finally(onfinally) {
        return this.parse().finally(onfinally);
    }
}
class APIClient {
    constructor({ baseURL, maxRetries = 2, timeout = 600000, // 10 minutes
    httpAgent, fetch: overriddenFetch, }) {
        this.baseURL = baseURL;
        this.maxRetries = validatePositiveInteger('maxRetries', maxRetries);
        this.timeout = validatePositiveInteger('timeout', timeout);
        this.httpAgent = httpAgent;
        this.fetch = overriddenFetch ?? registry_fetch;
    }
    authHeaders(opts) {
        return {};
    }
    /**
     * Override this to add your own default headers, for example:
     *
     *  {
     *    ...super.defaultHeaders(),
     *    Authorization: 'Bearer 123',
     *  }
     */
    defaultHeaders(opts) {
        return {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            'User-Agent': this.getUserAgent(),
            ...getPlatformHeaders(),
            ...this.authHeaders(opts),
        };
    }
    /**
     * Override this to add your own headers validation:
     */
    validateHeaders(headers, customHeaders) { }
    defaultIdempotencyKey() {
        return `stainless-node-retry-${uuid4()}`;
    }
    get(path, opts) {
        return this.methodRequest('get', path, opts);
    }
    post(path, opts) {
        return this.methodRequest('post', path, opts);
    }
    patch(path, opts) {
        return this.methodRequest('patch', path, opts);
    }
    put(path, opts) {
        return this.methodRequest('put', path, opts);
    }
    delete(path, opts) {
        return this.methodRequest('delete', path, opts);
    }
    methodRequest(method, path, opts) {
        return this.request(Promise.resolve(opts).then(async (opts) => {
            const body = opts && isBlobLike(opts?.body) ? new DataView(await opts.body.arrayBuffer())
                : opts?.body instanceof DataView ? opts.body
                    : opts?.body instanceof ArrayBuffer ? new DataView(opts.body)
                        : opts && ArrayBuffer.isView(opts?.body) ? new DataView(opts.body.buffer)
                            : opts?.body;
            return { method, path, ...opts, body };
        }));
    }
    getAPIList(path, Page, opts) {
        return this.requestAPIList(Page, { method: 'get', path, ...opts });
    }
    calculateContentLength(body) {
        if (typeof body === 'string') {
            if (typeof core_Buffer !== 'undefined') {
                return core_Buffer.byteLength(body, 'utf8').toString();
            }
            if (typeof TextEncoder !== 'undefined') {
                const encoder = new TextEncoder();
                const encoded = encoder.encode(body);
                return encoded.length.toString();
            }
        }
        else if (ArrayBuffer.isView(body)) {
            return body.byteLength.toString();
        }
        return null;
    }
    buildRequest(options, { retryCount = 0 } = {}) {
        options = { ...options };
        const { method, path, query, headers: headers = {} } = options;
        const body = ArrayBuffer.isView(options.body) || (options.__binaryRequest && typeof options.body === 'string') ?
            options.body
            : isMultipartBody(options.body) ? options.body.body
                : options.body ? JSON.stringify(options.body, null, 2)
                    : null;
        const contentLength = this.calculateContentLength(body);
        const url = this.buildURL(path, query);
        if ('timeout' in options)
            validatePositiveInteger('timeout', options.timeout);
        options.timeout = options.timeout ?? this.timeout;
        const httpAgent = options.httpAgent ?? this.httpAgent ?? getDefaultAgent(url);
        const minAgentTimeout = options.timeout + 1000;
        if (typeof httpAgent?.options?.timeout === 'number' &&
            minAgentTimeout > (httpAgent.options.timeout ?? 0)) {
            // Allow any given request to bump our agent active socket timeout.
            // This may seem strange, but leaking active sockets should be rare and not particularly problematic,
            // and without mutating agent we would need to create more of them.
            // This tradeoff optimizes for performance.
            httpAgent.options.timeout = minAgentTimeout;
        }
        if (this.idempotencyHeader && method !== 'get') {
            if (!options.idempotencyKey)
                options.idempotencyKey = this.defaultIdempotencyKey();
            headers[this.idempotencyHeader] = options.idempotencyKey;
        }
        const reqHeaders = this.buildHeaders({ options, headers, contentLength, retryCount });
        const req = {
            method,
            ...(body && { body: body }),
            headers: reqHeaders,
            ...(httpAgent && { agent: httpAgent }),
            // @ts-ignore node-fetch uses a custom AbortSignal type that is
            // not compatible with standard web types
            signal: options.signal ?? null,
        };
        return { req, url, timeout: options.timeout };
    }
    buildHeaders({ options, headers, contentLength, retryCount, }) {
        const reqHeaders = {};
        if (contentLength) {
            reqHeaders['content-length'] = contentLength;
        }
        const defaultHeaders = this.defaultHeaders(options);
        applyHeadersMut(reqHeaders, defaultHeaders);
        applyHeadersMut(reqHeaders, headers);
        // let builtin fetch set the Content-Type for multipart bodies
        if (isMultipartBody(options.body) && kind !== 'node') {
            delete reqHeaders['content-type'];
        }
        // Don't set theses headers if they were already set or removed through default headers or by the caller.
        // We check `defaultHeaders` and `headers`, which can contain nulls, instead of `reqHeaders` to account
        // for the removal case.
        if (getHeader(defaultHeaders, 'x-stainless-retry-count') === undefined &&
            getHeader(headers, 'x-stainless-retry-count') === undefined) {
            reqHeaders['x-stainless-retry-count'] = String(retryCount);
        }
        if (getHeader(defaultHeaders, 'x-stainless-timeout') === undefined &&
            getHeader(headers, 'x-stainless-timeout') === undefined &&
            options.timeout) {
            reqHeaders['x-stainless-timeout'] = String(options.timeout);
        }
        this.validateHeaders(reqHeaders, headers);
        return reqHeaders;
    }
    /**
     * Used as a callback for mutating the given `FinalRequestOptions` object.
     */
    async prepareOptions(options) { }
    /**
     * Used as a callback for mutating the given `RequestInit` object.
     *
     * This is useful for cases where you want to add certain headers based off of
     * the request properties, e.g. `method` or `url`.
     */
    async prepareRequest(request, { url, options }) { }
    parseHeaders(headers) {
        return (!headers ? {}
            : Symbol.iterator in headers ?
                Object.fromEntries(Array.from(headers).map((header) => [...header]))
                : { ...headers });
    }
    makeStatusError(status, error, message, headers) {
        return APIError.generate(status, error, message, headers);
    }
    request(options, remainingRetries = null) {
        return new APIPromise(this.makeRequest(options, remainingRetries));
    }
    async makeRequest(optionsInput, retriesRemaining) {
        const options = await optionsInput;
        const maxRetries = options.maxRetries ?? this.maxRetries;
        if (retriesRemaining == null) {
            retriesRemaining = maxRetries;
        }
        await this.prepareOptions(options);
        const { req, url, timeout } = this.buildRequest(options, { retryCount: maxRetries - retriesRemaining });
        await this.prepareRequest(req, { url, options });
        debug('request', url, options, req.headers);
        if (options.signal?.aborted) {
            throw new APIUserAbortError();
        }
        const controller = new AbortController();
        const response = await this.fetchWithTimeout(url, req, timeout, controller).catch(castToError);
        if (response instanceof Error) {
            if (options.signal?.aborted) {
                throw new APIUserAbortError();
            }
            if (retriesRemaining) {
                return this.retryRequest(options, retriesRemaining);
            }
            if (response.name === 'AbortError') {
                throw new APIConnectionTimeoutError();
            }
            throw new APIConnectionError({ cause: response });
        }
        const responseHeaders = createResponseHeaders(response.headers);
        if (!response.ok) {
            if (retriesRemaining && this.shouldRetry(response)) {
                const retryMessage = `retrying, ${retriesRemaining} attempts remaining`;
                debug(`response (error; ${retryMessage})`, response.status, url, responseHeaders);
                return this.retryRequest(options, retriesRemaining, responseHeaders);
            }
            const errText = await response.text().catch((e) => castToError(e).message);
            const errJSON = safeJSON(errText);
            const errMessage = errJSON ? undefined : errText;
            const retryMessage = retriesRemaining ? `(error; no more retries left)` : `(error; not retryable)`;
            debug(`response (error; ${retryMessage})`, response.status, url, responseHeaders, errMessage);
            const err = this.makeStatusError(response.status, errJSON, errMessage, responseHeaders);
            throw err;
        }
        return { response, options, controller };
    }
    requestAPIList(Page, options) {
        const request = this.makeRequest(options, null);
        return new PagePromise(this, request, Page);
    }
    buildURL(path, query) {
        const url = isAbsoluteURL(path) ?
            new URL(path)
            : new URL(this.baseURL + (this.baseURL.endsWith('/') && path.startsWith('/') ? path.slice(1) : path));
        const defaultQuery = this.defaultQuery();
        if (!isEmptyObj(defaultQuery)) {
            query = { ...defaultQuery, ...query };
        }
        if (typeof query === 'object' && query && !Array.isArray(query)) {
            url.search = this.stringifyQuery(query);
        }
        return url.toString();
    }
    stringifyQuery(query) {
        return Object.entries(query)
            .filter(([_, value]) => typeof value !== 'undefined')
            .map(([key, value]) => {
            if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
                return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
            }
            if (value === null) {
                return `${encodeURIComponent(key)}=`;
            }
            throw new error_OpenAIError(`Cannot stringify type ${typeof value}; Expected string, number, boolean, or null. If you need to pass nested query parameters, you can manually encode them, e.g. { query: { 'foo[key1]': value1, 'foo[key2]': value2 } }, and please open a GitHub issue requesting better support for your use case.`);
        })
            .join('&');
    }
    async fetchWithTimeout(url, init, ms, controller) {
        const { signal, ...options } = init || {};
        if (signal)
            signal.addEventListener('abort', () => controller.abort());
        const timeout = setTimeout(() => controller.abort(), ms);
        const fetchOptions = {
            signal: controller.signal,
            ...options,
        };
        if (fetchOptions.method) {
            // Custom methods like 'patch' need to be uppercased
            // See https://github.com/nodejs/undici/issues/2294
            fetchOptions.method = fetchOptions.method.toUpperCase();
        }
        return (
        // use undefined this binding; fetch errors if bound to something else in browser/cloudflare
        this.fetch.call(undefined, url, fetchOptions).finally(() => {
            clearTimeout(timeout);
        }));
    }
    shouldRetry(response) {
        // Note this is not a standard header.
        const shouldRetryHeader = response.headers.get('x-should-retry');
        // If the server explicitly says whether or not to retry, obey.
        if (shouldRetryHeader === 'true')
            return true;
        if (shouldRetryHeader === 'false')
            return false;
        // Retry on request timeouts.
        if (response.status === 408)
            return true;
        // Retry on lock timeouts.
        if (response.status === 409)
            return true;
        // Retry on rate limits.
        if (response.status === 429)
            return true;
        // Retry internal errors.
        if (response.status >= 500)
            return true;
        return false;
    }
    async retryRequest(options, retriesRemaining, responseHeaders) {
        let timeoutMillis;
        // Note the `retry-after-ms` header may not be standard, but is a good idea and we'd like proactive support for it.
        const retryAfterMillisHeader = responseHeaders?.['retry-after-ms'];
        if (retryAfterMillisHeader) {
            const timeoutMs = parseFloat(retryAfterMillisHeader);
            if (!Number.isNaN(timeoutMs)) {
                timeoutMillis = timeoutMs;
            }
        }
        // About the Retry-After header: https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Retry-After
        const retryAfterHeader = responseHeaders?.['retry-after'];
        if (retryAfterHeader && !timeoutMillis) {
            const timeoutSeconds = parseFloat(retryAfterHeader);
            if (!Number.isNaN(timeoutSeconds)) {
                timeoutMillis = timeoutSeconds * 1000;
            }
            else {
                timeoutMillis = Date.parse(retryAfterHeader) - Date.now();
            }
        }
        // If the API asks us to wait a certain amount of time (and it's a reasonable amount),
        // just do what it says, but otherwise calculate a default
        if (!(timeoutMillis && 0 <= timeoutMillis && timeoutMillis < 60 * 1000)) {
            const maxRetries = options.maxRetries ?? this.maxRetries;
            timeoutMillis = this.calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries);
        }
        await sleep(timeoutMillis);
        return this.makeRequest(options, retriesRemaining - 1);
    }
    calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries) {
        const initialRetryDelay = 0.5;
        const maxRetryDelay = 8.0;
        const numRetries = maxRetries - retriesRemaining;
        // Apply exponential backoff, but not more than the max.
        const sleepSeconds = Math.min(initialRetryDelay * Math.pow(2, numRetries), maxRetryDelay);
        // Apply some jitter, take up to at most 25 percent of the retry time.
        const jitter = 1 - Math.random() * 0.25;
        return sleepSeconds * jitter * 1000;
    }
    getUserAgent() {
        return `${this.constructor.name}/JS ${VERSION}`;
    }
}
class AbstractPage {
    constructor(client, response, body, options) {
        _AbstractPage_client.set(this, void 0);
        core_classPrivateFieldSet(this, _AbstractPage_client, client, "f");
        this.options = options;
        this.response = response;
        this.body = body;
    }
    hasNextPage() {
        const items = this.getPaginatedItems();
        if (!items.length)
            return false;
        return this.nextPageInfo() != null;
    }
    async getNextPage() {
        const nextInfo = this.nextPageInfo();
        if (!nextInfo) {
            throw new error_OpenAIError('No next page expected; please check `.hasNextPage()` before calling `.getNextPage()`.');
        }
        const nextOptions = { ...this.options };
        if ('params' in nextInfo && typeof nextOptions.query === 'object') {
            nextOptions.query = { ...nextOptions.query, ...nextInfo.params };
        }
        else if ('url' in nextInfo) {
            const params = [...Object.entries(nextOptions.query || {}), ...nextInfo.url.searchParams.entries()];
            for (const [key, value] of params) {
                nextInfo.url.searchParams.set(key, value);
            }
            nextOptions.query = undefined;
            nextOptions.path = nextInfo.url.toString();
        }
        return await core_classPrivateFieldGet(this, _AbstractPage_client, "f").requestAPIList(this.constructor, nextOptions);
    }
    async *iterPages() {
        // eslint-disable-next-line @typescript-eslint/no-this-alias
        let page = this;
        yield page;
        while (page.hasNextPage()) {
            page = await page.getNextPage();
            yield page;
        }
    }
    async *[(_AbstractPage_client = new WeakMap(), Symbol.asyncIterator)]() {
        for await (const page of this.iterPages()) {
            for (const item of page.getPaginatedItems()) {
                yield item;
            }
        }
    }
}
/**
 * This subclass of Promise will resolve to an instantiated Page once the request completes.
 *
 * It also implements AsyncIterable to allow auto-paginating iteration on an unawaited list call, eg:
 *
 *    for await (const item of client.items.list()) {
 *      console.log(item)
 *    }
 */
class PagePromise extends APIPromise {
    constructor(client, request, Page) {
        super(request, async (props) => new Page(client, props.response, await defaultParseResponse(props), props.options));
    }
    /**
     * Allow auto-paginating iteration on an unawaited list call, eg:
     *
     *    for await (const item of client.items.list()) {
     *      console.log(item)
     *    }
     */
    async *[Symbol.asyncIterator]() {
        const page = await this;
        for await (const item of page) {
            yield item;
        }
    }
}
const createResponseHeaders = (headers) => {
    return new Proxy(Object.fromEntries(
    // @ts-ignore
    headers.entries()), {
        get(target, name) {
            const key = name.toString();
            return target[key.toLowerCase()] || target[key];
        },
    });
};
// This is required so that we can determine if a given object matches the RequestOptions
// type at runtime. While this requires duplication, it is enforced by the TypeScript
// compiler such that any missing / extraneous keys will cause an error.
const requestOptionsKeys = {
    method: true,
    path: true,
    query: true,
    body: true,
    headers: true,
    maxRetries: true,
    stream: true,
    timeout: true,
    httpAgent: true,
    signal: true,
    idempotencyKey: true,
    __metadata: true,
    __binaryRequest: true,
    __binaryResponse: true,
    __streamClass: true,
};
const isRequestOptions = (obj) => {
    return (typeof obj === 'object' &&
        obj !== null &&
        !isEmptyObj(obj) &&
        Object.keys(obj).every((k) => hasOwn(requestOptionsKeys, k)));
};
const getPlatformProperties = () => {
    if (typeof Deno !== 'undefined' && Deno.build != null) {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': VERSION,
            'X-Stainless-OS': normalizePlatform(Deno.build.os),
            'X-Stainless-Arch': normalizeArch(Deno.build.arch),
            'X-Stainless-Runtime': 'deno',
            'X-Stainless-Runtime-Version': typeof Deno.version === 'string' ? Deno.version : Deno.version?.deno ?? 'unknown',
        };
    }
    if (typeof EdgeRuntime !== 'undefined') {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': VERSION,
            'X-Stainless-OS': 'Unknown',
            'X-Stainless-Arch': `other:${EdgeRuntime}`,
            'X-Stainless-Runtime': 'edge',
            'X-Stainless-Runtime-Version': process.version,
        };
    }
    // Check if Node.js
    if (Object.prototype.toString.call(typeof process !== 'undefined' ? process : 0) === '[object process]') {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': VERSION,
            'X-Stainless-OS': normalizePlatform(process.platform),
            'X-Stainless-Arch': normalizeArch(process.arch),
            'X-Stainless-Runtime': 'node',
            'X-Stainless-Runtime-Version': process.version,
        };
    }
    const browserInfo = getBrowserInfo();
    if (browserInfo) {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': VERSION,
            'X-Stainless-OS': 'Unknown',
            'X-Stainless-Arch': 'unknown',
            'X-Stainless-Runtime': `browser:${browserInfo.browser}`,
            'X-Stainless-Runtime-Version': browserInfo.version,
        };
    }
    // TODO add support for Cloudflare workers, etc.
    return {
        'X-Stainless-Lang': 'js',
        'X-Stainless-Package-Version': VERSION,
        'X-Stainless-OS': 'Unknown',
        'X-Stainless-Arch': 'unknown',
        'X-Stainless-Runtime': 'unknown',
        'X-Stainless-Runtime-Version': 'unknown',
    };
};
// Note: modified from https://github.com/JS-DevTools/host-environment/blob/b1ab79ecde37db5d6e163c050e54fe7d287d7c92/src/isomorphic.browser.ts
function getBrowserInfo() {
    if (typeof navigator === 'undefined' || !navigator) {
        return null;
    }
    // NOTE: The order matters here!
    const browserPatterns = [
        { key: 'edge', pattern: /Edge(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'ie', pattern: /MSIE(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'ie', pattern: /Trident(?:.*rv\:(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'chrome', pattern: /Chrome(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'firefox', pattern: /Firefox(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'safari', pattern: /(?:Version\W+(\d+)\.(\d+)(?:\.(\d+))?)?(?:\W+Mobile\S*)?\W+Safari/ },
    ];
    // Find the FIRST matching browser
    for (const { key, pattern } of browserPatterns) {
        const match = pattern.exec(navigator.userAgent);
        if (match) {
            const major = match[1] || 0;
            const minor = match[2] || 0;
            const patch = match[3] || 0;
            return { browser: key, version: `${major}.${minor}.${patch}` };
        }
    }
    return null;
}
const normalizeArch = (arch) => {
    // Node docs:
    // - https://nodejs.org/api/process.html#processarch
    // Deno docs:
    // - https://doc.deno.land/deno/stable/~/Deno.build
    if (arch === 'x32')
        return 'x32';
    if (arch === 'x86_64' || arch === 'x64')
        return 'x64';
    if (arch === 'arm')
        return 'arm';
    if (arch === 'aarch64' || arch === 'arm64')
        return 'arm64';
    if (arch)
        return `other:${arch}`;
    return 'unknown';
};
const normalizePlatform = (platform) => {
    // Node platforms:
    // - https://nodejs.org/api/process.html#processplatform
    // Deno platforms:
    // - https://doc.deno.land/deno/stable/~/Deno.build
    // - https://github.com/denoland/deno/issues/14799
    platform = platform.toLowerCase();
    // NOTE: this iOS check is untested and may not work
    // Node does not work natively on IOS, there is a fork at
    // https://github.com/nodejs-mobile/nodejs-mobile
    // however it is unknown at the time of writing how to detect if it is running
    if (platform.includes('ios'))
        return 'iOS';
    if (platform === 'android')
        return 'Android';
    if (platform === 'darwin')
        return 'MacOS';
    if (platform === 'win32')
        return 'Windows';
    if (platform === 'freebsd')
        return 'FreeBSD';
    if (platform === 'openbsd')
        return 'OpenBSD';
    if (platform === 'linux')
        return 'Linux';
    if (platform)
        return `Other:${platform}`;
    return 'Unknown';
};
let _platformHeaders;
const getPlatformHeaders = () => {
    return (_platformHeaders ?? (_platformHeaders = getPlatformProperties()));
};
const safeJSON = (text) => {
    try {
        return JSON.parse(text);
    }
    catch (err) {
        return undefined;
    }
};
// https://url.spec.whatwg.org/#url-scheme-string
const startsWithSchemeRegexp = /^[a-z][a-z0-9+.-]*:/i;
const isAbsoluteURL = (url) => {
    return startsWithSchemeRegexp.test(url);
};
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const validatePositiveInteger = (name, n) => {
    if (typeof n !== 'number' || !Number.isInteger(n)) {
        throw new error_OpenAIError(`${name} must be an integer`);
    }
    if (n < 0) {
        throw new error_OpenAIError(`${name} must be a positive integer`);
    }
    return n;
};
const castToError = (err) => {
    if (err instanceof Error)
        return err;
    if (typeof err === 'object' && err !== null) {
        try {
            return new Error(JSON.stringify(err));
        }
        catch { }
    }
    return new Error(err);
};
const ensurePresent = (value) => {
    if (value == null)
        throw new OpenAIError(`Expected a value to be given but received ${value} instead.`);
    return value;
};
/**
 * Read an environment variable.
 *
 * Trims beginning and trailing whitespace.
 *
 * Will return undefined if the environment variable doesn't exist or cannot be accessed.
 */
const readEnv = (env) => {
    if (typeof process !== 'undefined') {
        return {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}?.[env]?.trim() ?? undefined;
    }
    if (typeof Deno !== 'undefined') {
        return Deno.env?.get?.(env)?.trim();
    }
    return undefined;
};
const coerceInteger = (value) => {
    if (typeof value === 'number')
        return Math.round(value);
    if (typeof value === 'string')
        return parseInt(value, 10);
    throw new OpenAIError(`Could not coerce ${value} (type: ${typeof value}) into a number`);
};
const coerceFloat = (value) => {
    if (typeof value === 'number')
        return value;
    if (typeof value === 'string')
        return parseFloat(value);
    throw new OpenAIError(`Could not coerce ${value} (type: ${typeof value}) into a number`);
};
const coerceBoolean = (value) => {
    if (typeof value === 'boolean')
        return value;
    if (typeof value === 'string')
        return value === 'true';
    return Boolean(value);
};
const maybeCoerceInteger = (value) => {
    if (value === undefined) {
        return undefined;
    }
    return coerceInteger(value);
};
const maybeCoerceFloat = (value) => {
    if (value === undefined) {
        return undefined;
    }
    return coerceFloat(value);
};
const maybeCoerceBoolean = (value) => {
    if (value === undefined) {
        return undefined;
    }
    return coerceBoolean(value);
};
// https://stackoverflow.com/a/34491287
function isEmptyObj(obj) {
    if (!obj)
        return true;
    for (const _k in obj)
        return false;
    return true;
}
// https://eslint.org/docs/latest/rules/no-prototype-builtins
function hasOwn(obj, key) {
    return Object.prototype.hasOwnProperty.call(obj, key);
}
/**
 * Copies headers from "newHeaders" onto "targetHeaders",
 * using lower-case for all properties,
 * ignoring any keys with undefined values,
 * and deleting any keys with null values.
 */
function applyHeadersMut(targetHeaders, newHeaders) {
    for (const k in newHeaders) {
        if (!hasOwn(newHeaders, k))
            continue;
        const lowerKey = k.toLowerCase();
        if (!lowerKey)
            continue;
        const val = newHeaders[k];
        if (val === null) {
            delete targetHeaders[lowerKey];
        }
        else if (val !== undefined) {
            targetHeaders[lowerKey] = val;
        }
    }
}
const SENSITIVE_HEADERS = new Set(['authorization', 'api-key']);
function debug(action, ...args) {
    if (typeof process !== 'undefined' && {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}?.['DEBUG'] === 'true') {
        const modifiedArgs = args.map((arg) => {
            if (!arg) {
                return arg;
            }
            // Check for sensitive headers in request body 'headers' object
            if (arg['headers']) {
                // clone so we don't mutate
                const modifiedArg = { ...arg, headers: { ...arg['headers'] } };
                for (const header in arg['headers']) {
                    if (SENSITIVE_HEADERS.has(header.toLowerCase())) {
                        modifiedArg['headers'][header] = 'REDACTED';
                    }
                }
                return modifiedArg;
            }
            let modifiedArg = null;
            // Check for sensitive headers in headers object
            for (const header in arg) {
                if (SENSITIVE_HEADERS.has(header.toLowerCase())) {
                    // avoid making a copy until we need to
                    modifiedArg ?? (modifiedArg = { ...arg });
                    modifiedArg[header] = 'REDACTED';
                }
            }
            return modifiedArg ?? arg;
        });
        console.log(`OpenAI:DEBUG:${action}`, ...modifiedArgs);
    }
}
/**
 * https://stackoverflow.com/a/2117523
 */
const uuid4 = () => {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = (Math.random() * 16) | 0;
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    });
};
const isRunningInBrowser = () => {
    return (
    // @ts-ignore
    typeof window !== 'undefined' &&
        // @ts-ignore
        typeof window.document !== 'undefined' &&
        // @ts-ignore
        typeof navigator !== 'undefined');
};
const isHeadersProtocol = (headers) => {
    return typeof headers?.get === 'function';
};
const getRequiredHeader = (headers, header) => {
    const foundHeader = getHeader(headers, header);
    if (foundHeader === undefined) {
        throw new Error(`Could not find ${header} header`);
    }
    return foundHeader;
};
const getHeader = (headers, header) => {
    const lowerCasedHeader = header.toLowerCase();
    if (isHeadersProtocol(headers)) {
        // to deal with the case where the header looks like Stainless-Event-Id
        const intercapsHeader = header[0]?.toUpperCase() +
            header.substring(1).replace(/([^\w])(\w)/g, (_m, g1, g2) => g1 + g2.toUpperCase());
        for (const key of [header, lowerCasedHeader, header.toUpperCase(), intercapsHeader]) {
            const value = headers.get(key);
            if (value) {
                return value;
            }
        }
    }
    for (const [key, value] of Object.entries(headers)) {
        if (key.toLowerCase() === lowerCasedHeader) {
            if (Array.isArray(value)) {
                if (value.length <= 1)
                    return value[0];
                console.warn(`Received ${value.length} entries for the ${header} header, using the first entry.`);
                return value[0];
            }
            return value;
        }
    }
    return undefined;
};
/**
 * Encodes a string to Base64 format.
 */
const toBase64 = (str) => {
    if (!str)
        return '';
    if (typeof core_Buffer !== 'undefined') {
        return core_Buffer.from(str).toString('base64');
    }
    if (typeof btoa !== 'undefined') {
        return btoa(str);
    }
    throw new OpenAIError('Cannot generate b64 string; Expected `Buffer` or `btoa` to be defined');
};
/**
 * Converts a Base64 encoded string to a Float32Array.
 * @param base64Str - The Base64 encoded string.
 * @returns An Array of numbers interpreted as Float32 values.
 */
const toFloat32Array = (base64Str) => {
    if (typeof core_Buffer !== 'undefined') {
        // for Node.js environment
        return Array.from(new Float32Array(core_Buffer.from(base64Str, 'base64').buffer));
    }
    else {
        // for legacy web platform APIs
        const binaryStr = atob(base64Str);
        const len = binaryStr.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binaryStr.charCodeAt(i);
        }
        return Array.from(new Float32Array(bytes.buffer));
    }
};
function isObj(obj) {
    return obj != null && typeof obj === 'object' && !Array.isArray(obj);
}
//# sourceMappingURL=core.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resource.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
class APIResource {
    constructor(client) {
        this._client = client;
    }
}
//# sourceMappingURL=resource.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/completions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class Completions extends APIResource {
    create(body, options) {
        return this._client.post('/completions', { body, ...options, stream: body.stream ?? false });
    }
}
//# sourceMappingURL=completions.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/chat/completions/messages.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class Messages extends APIResource {
    list(completionId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(completionId, {}, query);
        }
        return this._client.getAPIList(`/chat/completions/${completionId}/messages`, ChatCompletionStoreMessagesPage, { query, ...options });
    }
}

//# sourceMappingURL=messages.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/pagination.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

/**
 * Note: no pagination actually occurs yet, this is for forwards-compatibility.
 */
class Page extends AbstractPage {
    constructor(client, response, body, options) {
        super(client, response, body, options);
        this.data = body.data || [];
        this.object = body.object;
    }
    getPaginatedItems() {
        return this.data ?? [];
    }
    // @deprecated Please use `nextPageInfo()` instead
    /**
     * This page represents a response that isn't actually paginated at the API level
     * so there will never be any next page params.
     */
    nextPageParams() {
        return null;
    }
    nextPageInfo() {
        return null;
    }
}
class CursorPage extends AbstractPage {
    constructor(client, response, body, options) {
        super(client, response, body, options);
        this.data = body.data || [];
        this.has_more = body.has_more || false;
    }
    getPaginatedItems() {
        return this.data ?? [];
    }
    hasNextPage() {
        if (this.has_more === false) {
            return false;
        }
        return super.hasNextPage();
    }
    // @deprecated Please use `nextPageInfo()` instead
    nextPageParams() {
        const info = this.nextPageInfo();
        if (!info)
            return null;
        if ('params' in info)
            return info.params;
        const params = Object.fromEntries(info.url.searchParams);
        if (!Object.keys(params).length)
            return null;
        return params;
    }
    nextPageInfo() {
        const data = this.getPaginatedItems();
        if (!data.length) {
            return null;
        }
        const id = data[data.length - 1]?.id;
        if (!id) {
            return null;
        }
        return { params: { after: id } };
    }
}
//# sourceMappingURL=pagination.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/chat/completions/completions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.





class completions_Completions extends APIResource {
    constructor() {
        super(...arguments);
        this.messages = new Messages(this._client);
    }
    create(body, options) {
        return this._client.post('/chat/completions', { body, ...options, stream: body.stream ?? false });
    }
    /**
     * Get a stored chat completion. Only Chat Completions that have been created with
     * the `store` parameter set to `true` will be returned.
     */
    retrieve(completionId, options) {
        return this._client.get(`/chat/completions/${completionId}`, options);
    }
    /**
     * Modify a stored chat completion. Only Chat Completions that have been created
     * with the `store` parameter set to `true` can be modified. Currently, the only
     * supported modification is to update the `metadata` field.
     */
    update(completionId, body, options) {
        return this._client.post(`/chat/completions/${completionId}`, { body, ...options });
    }
    list(query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list({}, query);
        }
        return this._client.getAPIList('/chat/completions', ChatCompletionsPage, { query, ...options });
    }
    /**
     * Delete a stored chat completion. Only Chat Completions that have been created
     * with the `store` parameter set to `true` can be deleted.
     */
    del(completionId, options) {
        return this._client.delete(`/chat/completions/${completionId}`, options);
    }
}
class ChatCompletionsPage extends CursorPage {
}
class ChatCompletionStoreMessagesPage extends CursorPage {
}
completions_Completions.ChatCompletionsPage = ChatCompletionsPage;
completions_Completions.Messages = Messages;
//# sourceMappingURL=completions.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/chat/chat.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class Chat extends APIResource {
    constructor() {
        super(...arguments);
        this.completions = new completions_Completions(this._client);
    }
}
Chat.Completions = completions_Completions;
Chat.ChatCompletionsPage = ChatCompletionsPage;
//# sourceMappingURL=chat.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/embeddings.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class Embeddings extends APIResource {
    /**
     * Creates an embedding vector representing the input text.
     */
    create(body, options) {
        const hasUserProvidedEncodingFormat = !!body.encoding_format;
        // No encoding_format specified, defaulting to base64 for performance reasons
        // See https://github.com/openai/openai-node/pull/1312
        let encoding_format = hasUserProvidedEncodingFormat ? body.encoding_format : 'base64';
        if (hasUserProvidedEncodingFormat) {
            debug('Request', 'User defined encoding_format:', body.encoding_format);
        }
        const response = this._client.post('/embeddings', {
            body: {
                ...body,
                encoding_format: encoding_format,
            },
            ...options,
        });
        // if the user specified an encoding_format, return the response as-is
        if (hasUserProvidedEncodingFormat) {
            return response;
        }
        // in this stage, we are sure the user did not specify an encoding_format
        // and we defaulted to base64 for performance reasons
        // we are sure then that the response is base64 encoded, let's decode it
        // the returned result will be a float32 array since this is OpenAI API's default encoding
        debug('response', 'Decoding base64 embeddings to float32 array');
        return response._thenUnwrap((response) => {
            if (response && response.data) {
                response.data.forEach((embeddingBase64Obj) => {
                    const embeddingBase64Str = embeddingBase64Obj.embedding;
                    embeddingBase64Obj.embedding = toFloat32Array(embeddingBase64Str);
                });
            }
            return response;
        });
    }
}
//# sourceMappingURL=embeddings.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/files.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.






class Files extends APIResource {
    /**
     * Upload a file that can be used across various endpoints. Individual files can be
     * up to 512 MB, and the size of all files uploaded by one organization can be up
     * to 100 GB.
     *
     * The Assistants API supports files up to 2 million tokens and of specific file
     * types. See the
     * [Assistants Tools guide](https://platform.openai.com/docs/assistants/tools) for
     * details.
     *
     * The Fine-tuning API only supports `.jsonl` files. The input also has certain
     * required formats for fine-tuning
     * [chat](https://platform.openai.com/docs/api-reference/fine-tuning/chat-input) or
     * [completions](https://platform.openai.com/docs/api-reference/fine-tuning/completions-input)
     * models.
     *
     * The Batch API only supports `.jsonl` files up to 200 MB in size. The input also
     * has a specific required
     * [format](https://platform.openai.com/docs/api-reference/batch/request-input).
     *
     * Please [contact us](https://help.openai.com/) if you need to increase these
     * storage limits.
     */
    create(body, options) {
        return this._client.post('/files', multipartFormRequestOptions({ body, ...options }));
    }
    /**
     * Returns information about a specific file.
     */
    retrieve(fileId, options) {
        return this._client.get(`/files/${fileId}`, options);
    }
    list(query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list({}, query);
        }
        return this._client.getAPIList('/files', FileObjectsPage, { query, ...options });
    }
    /**
     * Delete a file.
     */
    del(fileId, options) {
        return this._client.delete(`/files/${fileId}`, options);
    }
    /**
     * Returns the contents of the specified file.
     */
    content(fileId, options) {
        return this._client.get(`/files/${fileId}/content`, {
            ...options,
            headers: { Accept: 'application/binary', ...options?.headers },
            __binaryResponse: true,
        });
    }
    /**
     * Returns the contents of the specified file.
     *
     * @deprecated The `.content()` method should be used instead
     */
    retrieveContent(fileId, options) {
        return this._client.get(`/files/${fileId}/content`, options);
    }
    /**
     * Waits for the given file to be processed, default timeout is 30 mins.
     */
    async waitForProcessing(id, { pollInterval = 5000, maxWait = 30 * 60 * 1000 } = {}) {
        const TERMINAL_STATES = new Set(['processed', 'error', 'deleted']);
        const start = Date.now();
        let file = await this.retrieve(id);
        while (!file.status || !TERMINAL_STATES.has(file.status)) {
            await sleep(pollInterval);
            file = await this.retrieve(id);
            if (Date.now() - start > maxWait) {
                throw new APIConnectionTimeoutError({
                    message: `Giving up on waiting for file ${id} to finish processing after ${maxWait} milliseconds.`,
                });
            }
        }
        return file;
    }
}
class FileObjectsPage extends CursorPage {
}
Files.FileObjectsPage = FileObjectsPage;
//# sourceMappingURL=files.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/images.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class Images extends APIResource {
    /**
     * Creates a variation of a given image.
     */
    createVariation(body, options) {
        return this._client.post('/images/variations', multipartFormRequestOptions({ body, ...options }));
    }
    /**
     * Creates an edited or extended image given an original image and a prompt.
     */
    edit(body, options) {
        return this._client.post('/images/edits', multipartFormRequestOptions({ body, ...options }));
    }
    /**
     * Creates an image given a prompt.
     */
    generate(body, options) {
        return this._client.post('/images/generations', { body, ...options });
    }
}
//# sourceMappingURL=images.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/audio/speech.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class Speech extends APIResource {
    /**
     * Generates audio from the input text.
     */
    create(body, options) {
        return this._client.post('/audio/speech', {
            body,
            ...options,
            headers: { Accept: 'application/octet-stream', ...options?.headers },
            __binaryResponse: true,
        });
    }
}
//# sourceMappingURL=speech.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/audio/transcriptions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class Transcriptions extends APIResource {
    create(body, options) {
        return this._client.post('/audio/transcriptions', multipartFormRequestOptions({
            body,
            ...options,
            stream: body.stream ?? false,
            __metadata: { model: body.model },
        }));
    }
}
//# sourceMappingURL=transcriptions.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/audio/translations.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class Translations extends APIResource {
    create(body, options) {
        return this._client.post('/audio/translations', multipartFormRequestOptions({ body, ...options, __metadata: { model: body.model } }));
    }
}
//# sourceMappingURL=translations.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/audio/audio.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.







class Audio extends APIResource {
    constructor() {
        super(...arguments);
        this.transcriptions = new Transcriptions(this._client);
        this.translations = new Translations(this._client);
        this.speech = new Speech(this._client);
    }
}
Audio.Transcriptions = Transcriptions;
Audio.Translations = Translations;
Audio.Speech = Speech;
//# sourceMappingURL=audio.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/moderations.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class Moderations extends APIResource {
    /**
     * Classifies if text and/or image inputs are potentially harmful. Learn more in
     * the [moderation guide](https://platform.openai.com/docs/guides/moderation).
     */
    create(body, options) {
        return this._client.post('/moderations', { body, ...options });
    }
}
//# sourceMappingURL=moderations.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/models.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class Models extends APIResource {
    /**
     * Retrieves a model instance, providing basic information about the model such as
     * the owner and permissioning.
     */
    retrieve(model, options) {
        return this._client.get(`/models/${model}`, options);
    }
    /**
     * Lists the currently available models, and provides basic information about each
     * one such as the owner and availability.
     */
    list(options) {
        return this._client.getAPIList('/models', ModelsPage, options);
    }
    /**
     * Delete a fine-tuned model. You must have the Owner role in your organization to
     * delete a model.
     */
    del(model, options) {
        return this._client.delete(`/models/${model}`, options);
    }
}
/**
 * Note: no pagination actually occurs yet, this is for forwards-compatibility.
 */
class ModelsPage extends Page {
}
Models.ModelsPage = ModelsPage;
//# sourceMappingURL=models.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/fine-tuning/jobs/checkpoints.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class Checkpoints extends APIResource {
    list(fineTuningJobId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(fineTuningJobId, {}, query);
        }
        return this._client.getAPIList(`/fine_tuning/jobs/${fineTuningJobId}/checkpoints`, FineTuningJobCheckpointsPage, { query, ...options });
    }
}
class FineTuningJobCheckpointsPage extends CursorPage {
}
Checkpoints.FineTuningJobCheckpointsPage = FineTuningJobCheckpointsPage;
//# sourceMappingURL=checkpoints.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/fine-tuning/jobs/jobs.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.





class Jobs extends APIResource {
    constructor() {
        super(...arguments);
        this.checkpoints = new Checkpoints(this._client);
    }
    /**
     * Creates a fine-tuning job which begins the process of creating a new model from
     * a given dataset.
     *
     * Response includes details of the enqueued job including job status and the name
     * of the fine-tuned models once complete.
     *
     * [Learn more about fine-tuning](https://platform.openai.com/docs/guides/fine-tuning)
     */
    create(body, options) {
        return this._client.post('/fine_tuning/jobs', { body, ...options });
    }
    /**
     * Get info about a fine-tuning job.
     *
     * [Learn more about fine-tuning](https://platform.openai.com/docs/guides/fine-tuning)
     */
    retrieve(fineTuningJobId, options) {
        return this._client.get(`/fine_tuning/jobs/${fineTuningJobId}`, options);
    }
    list(query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list({}, query);
        }
        return this._client.getAPIList('/fine_tuning/jobs', FineTuningJobsPage, { query, ...options });
    }
    /**
     * Immediately cancel a fine-tune job.
     */
    cancel(fineTuningJobId, options) {
        return this._client.post(`/fine_tuning/jobs/${fineTuningJobId}/cancel`, options);
    }
    listEvents(fineTuningJobId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.listEvents(fineTuningJobId, {}, query);
        }
        return this._client.getAPIList(`/fine_tuning/jobs/${fineTuningJobId}/events`, FineTuningJobEventsPage, {
            query,
            ...options,
        });
    }
}
class FineTuningJobsPage extends CursorPage {
}
class FineTuningJobEventsPage extends CursorPage {
}
Jobs.FineTuningJobsPage = FineTuningJobsPage;
Jobs.FineTuningJobEventsPage = FineTuningJobEventsPage;
Jobs.Checkpoints = Checkpoints;
Jobs.FineTuningJobCheckpointsPage = FineTuningJobCheckpointsPage;
//# sourceMappingURL=jobs.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/fine-tuning/fine-tuning.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class FineTuning extends APIResource {
    constructor() {
        super(...arguments);
        this.jobs = new Jobs(this._client);
    }
}
FineTuning.Jobs = Jobs;
FineTuning.FineTuningJobsPage = FineTuningJobsPage;
FineTuning.FineTuningJobEventsPage = FineTuningJobEventsPage;
//# sourceMappingURL=fine-tuning.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/Util.mjs
/**
 * Like `Promise.allSettled()` but throws an error if any promises are rejected.
 */
const allSettledWithThrow = async (promises) => {
    const results = await Promise.allSettled(promises);
    const rejected = results.filter((result) => result.status === 'rejected');
    if (rejected.length) {
        for (const result of rejected) {
            console.error(result.reason);
        }
        throw new Error(`${rejected.length} promise(s) failed - see the above errors`);
    }
    // Note: TS was complaining about using `.filter().map()` here for some reason
    const values = [];
    for (const result of results) {
        if (result.status === 'fulfilled') {
            values.push(result.value);
        }
    }
    return values;
};
//# sourceMappingURL=Util.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/vector-stores/files.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class files_Files extends APIResource {
    /**
     * Create a vector store file by attaching a
     * [File](https://platform.openai.com/docs/api-reference/files) to a
     * [vector store](https://platform.openai.com/docs/api-reference/vector-stores/object).
     */
    create(vectorStoreId, body, options) {
        return this._client.post(`/vector_stores/${vectorStoreId}/files`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Retrieves a vector store file.
     */
    retrieve(vectorStoreId, fileId, options) {
        return this._client.get(`/vector_stores/${vectorStoreId}/files/${fileId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Update attributes on a vector store file.
     */
    update(vectorStoreId, fileId, body, options) {
        return this._client.post(`/vector_stores/${vectorStoreId}/files/${fileId}`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    list(vectorStoreId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(vectorStoreId, {}, query);
        }
        return this._client.getAPIList(`/vector_stores/${vectorStoreId}/files`, VectorStoreFilesPage, {
            query,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Delete a vector store file. This will remove the file from the vector store but
     * the file itself will not be deleted. To delete the file, use the
     * [delete file](https://platform.openai.com/docs/api-reference/files/delete)
     * endpoint.
     */
    del(vectorStoreId, fileId, options) {
        return this._client.delete(`/vector_stores/${vectorStoreId}/files/${fileId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Attach a file to the given vector store and wait for it to be processed.
     */
    async createAndPoll(vectorStoreId, body, options) {
        const file = await this.create(vectorStoreId, body, options);
        return await this.poll(vectorStoreId, file.id, options);
    }
    /**
     * Wait for the vector store file to finish processing.
     *
     * Note: this will return even if the file failed to process, you need to check
     * file.last_error and file.status to handle these cases
     */
    async poll(vectorStoreId, fileId, options) {
        const headers = { ...options?.headers, 'X-Stainless-Poll-Helper': 'true' };
        if (options?.pollIntervalMs) {
            headers['X-Stainless-Custom-Poll-Interval'] = options.pollIntervalMs.toString();
        }
        while (true) {
            const fileResponse = await this.retrieve(vectorStoreId, fileId, {
                ...options,
                headers,
            }).withResponse();
            const file = fileResponse.data;
            switch (file.status) {
                case 'in_progress':
                    let sleepInterval = 5000;
                    if (options?.pollIntervalMs) {
                        sleepInterval = options.pollIntervalMs;
                    }
                    else {
                        const headerInterval = fileResponse.response.headers.get('openai-poll-after-ms');
                        if (headerInterval) {
                            const headerIntervalMs = parseInt(headerInterval);
                            if (!isNaN(headerIntervalMs)) {
                                sleepInterval = headerIntervalMs;
                            }
                        }
                    }
                    await sleep(sleepInterval);
                    break;
                case 'failed':
                case 'completed':
                    return file;
            }
        }
    }
    /**
     * Upload a file to the `files` API and then attach it to the given vector store.
     *
     * Note the file will be asynchronously processed (you can use the alternative
     * polling helper method to wait for processing to complete).
     */
    async upload(vectorStoreId, file, options) {
        const fileInfo = await this._client.files.create({ file: file, purpose: 'assistants' }, options);
        return this.create(vectorStoreId, { file_id: fileInfo.id }, options);
    }
    /**
     * Add a file to a vector store and poll until processing is complete.
     */
    async uploadAndPoll(vectorStoreId, file, options) {
        const fileInfo = await this.upload(vectorStoreId, file, options);
        return await this.poll(vectorStoreId, fileInfo.id, options);
    }
    /**
     * Retrieve the parsed contents of a vector store file.
     */
    content(vectorStoreId, fileId, options) {
        return this._client.getAPIList(`/vector_stores/${vectorStoreId}/files/${fileId}/content`, FileContentResponsesPage, { ...options, headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers } });
    }
}
class VectorStoreFilesPage extends CursorPage {
}
/**
 * Note: no pagination actually occurs yet, this is for forwards-compatibility.
 */
class FileContentResponsesPage extends Page {
}
files_Files.VectorStoreFilesPage = VectorStoreFilesPage;
files_Files.FileContentResponsesPage = FileContentResponsesPage;
//# sourceMappingURL=files.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/vector-stores/file-batches.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.





class FileBatches extends APIResource {
    /**
     * Create a vector store file batch.
     */
    create(vectorStoreId, body, options) {
        return this._client.post(`/vector_stores/${vectorStoreId}/file_batches`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Retrieves a vector store file batch.
     */
    retrieve(vectorStoreId, batchId, options) {
        return this._client.get(`/vector_stores/${vectorStoreId}/file_batches/${batchId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Cancel a vector store file batch. This attempts to cancel the processing of
     * files in this batch as soon as possible.
     */
    cancel(vectorStoreId, batchId, options) {
        return this._client.post(`/vector_stores/${vectorStoreId}/file_batches/${batchId}/cancel`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Create a vector store batch and poll until all files have been processed.
     */
    async createAndPoll(vectorStoreId, body, options) {
        const batch = await this.create(vectorStoreId, body);
        return await this.poll(vectorStoreId, batch.id, options);
    }
    listFiles(vectorStoreId, batchId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.listFiles(vectorStoreId, batchId, {}, query);
        }
        return this._client.getAPIList(`/vector_stores/${vectorStoreId}/file_batches/${batchId}/files`, VectorStoreFilesPage, { query, ...options, headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers } });
    }
    /**
     * Wait for the given file batch to be processed.
     *
     * Note: this will return even if one of the files failed to process, you need to
     * check batch.file_counts.failed_count to handle this case.
     */
    async poll(vectorStoreId, batchId, options) {
        const headers = { ...options?.headers, 'X-Stainless-Poll-Helper': 'true' };
        if (options?.pollIntervalMs) {
            headers['X-Stainless-Custom-Poll-Interval'] = options.pollIntervalMs.toString();
        }
        while (true) {
            const { data: batch, response } = await this.retrieve(vectorStoreId, batchId, {
                ...options,
                headers,
            }).withResponse();
            switch (batch.status) {
                case 'in_progress':
                    let sleepInterval = 5000;
                    if (options?.pollIntervalMs) {
                        sleepInterval = options.pollIntervalMs;
                    }
                    else {
                        const headerInterval = response.headers.get('openai-poll-after-ms');
                        if (headerInterval) {
                            const headerIntervalMs = parseInt(headerInterval);
                            if (!isNaN(headerIntervalMs)) {
                                sleepInterval = headerIntervalMs;
                            }
                        }
                    }
                    await sleep(sleepInterval);
                    break;
                case 'failed':
                case 'cancelled':
                case 'completed':
                    return batch;
            }
        }
    }
    /**
     * Uploads the given files concurrently and then creates a vector store file batch.
     *
     * The concurrency limit is configurable using the `maxConcurrency` parameter.
     */
    async uploadAndPoll(vectorStoreId, { files, fileIds = [] }, options) {
        if (files == null || files.length == 0) {
            throw new Error(`No \`files\` provided to process. If you've already uploaded files you should use \`.createAndPoll()\` instead`);
        }
        const configuredConcurrency = options?.maxConcurrency ?? 5;
        // We cap the number of workers at the number of files (so we don't start any unnecessary workers)
        const concurrencyLimit = Math.min(configuredConcurrency, files.length);
        const client = this._client;
        const fileIterator = files.values();
        const allFileIds = [...fileIds];
        // This code is based on this design. The libraries don't accommodate our environment limits.
        // https://stackoverflow.com/questions/40639432/what-is-the-best-way-to-limit-concurrency-when-using-es6s-promise-all
        async function processFiles(iterator) {
            for (let item of iterator) {
                const fileObj = await client.files.create({ file: item, purpose: 'assistants' }, options);
                allFileIds.push(fileObj.id);
            }
        }
        // Start workers to process results
        const workers = Array(concurrencyLimit).fill(fileIterator).map(processFiles);
        // Wait for all processing to complete.
        await allSettledWithThrow(workers);
        return await this.createAndPoll(vectorStoreId, {
            file_ids: allFileIds,
        });
    }
}

//# sourceMappingURL=file-batches.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/vector-stores/vector-stores.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.







class VectorStores extends APIResource {
    constructor() {
        super(...arguments);
        this.files = new files_Files(this._client);
        this.fileBatches = new FileBatches(this._client);
    }
    /**
     * Create a vector store.
     */
    create(body, options) {
        return this._client.post('/vector_stores', {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Retrieves a vector store.
     */
    retrieve(vectorStoreId, options) {
        return this._client.get(`/vector_stores/${vectorStoreId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Modifies a vector store.
     */
    update(vectorStoreId, body, options) {
        return this._client.post(`/vector_stores/${vectorStoreId}`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    list(query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list({}, query);
        }
        return this._client.getAPIList('/vector_stores', VectorStoresPage, {
            query,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Delete a vector store.
     */
    del(vectorStoreId, options) {
        return this._client.delete(`/vector_stores/${vectorStoreId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Search a vector store for relevant chunks based on a query and file attributes
     * filter.
     */
    search(vectorStoreId, body, options) {
        return this._client.getAPIList(`/vector_stores/${vectorStoreId}/search`, VectorStoreSearchResponsesPage, {
            body,
            method: 'post',
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
}
class VectorStoresPage extends CursorPage {
}
/**
 * Note: no pagination actually occurs yet, this is for forwards-compatibility.
 */
class VectorStoreSearchResponsesPage extends Page {
}
VectorStores.VectorStoresPage = VectorStoresPage;
VectorStores.VectorStoreSearchResponsesPage = VectorStoreSearchResponsesPage;
VectorStores.Files = files_Files;
VectorStores.VectorStoreFilesPage = VectorStoreFilesPage;
VectorStores.FileContentResponsesPage = FileContentResponsesPage;
VectorStores.FileBatches = FileBatches;
//# sourceMappingURL=vector-stores.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/assistants.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class Assistants extends APIResource {
    /**
     * Create an assistant with a model and instructions.
     */
    create(body, options) {
        return this._client.post('/assistants', {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Retrieves an assistant.
     */
    retrieve(assistantId, options) {
        return this._client.get(`/assistants/${assistantId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Modifies an assistant.
     */
    update(assistantId, body, options) {
        return this._client.post(`/assistants/${assistantId}`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    list(query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list({}, query);
        }
        return this._client.getAPIList('/assistants', AssistantsPage, {
            query,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Delete an assistant.
     */
    del(assistantId, options) {
        return this._client.delete(`/assistants/${assistantId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
}
class AssistantsPage extends CursorPage {
}
Assistants.AssistantsPage = AssistantsPage;
//# sourceMappingURL=assistants.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/RunnableFunction.mjs
function isRunnableFunctionWithParse(fn) {
    return typeof fn.parse === 'function';
}
/**
 * This is helper class for passing a `function` and `parse` where the `function`
 * argument type matches the `parse` return type.
 *
 * @deprecated - please use ParsingToolFunction instead.
 */
class ParsingFunction {
    constructor(input) {
        this.function = input.function;
        this.parse = input.parse;
        this.parameters = input.parameters;
        this.description = input.description;
        this.name = input.name;
    }
}
/**
 * This is helper class for passing a `function` and `parse` where the `function`
 * argument type matches the `parse` return type.
 */
class ParsingToolFunction {
    constructor(input) {
        this.type = 'function';
        this.function = input;
    }
}
//# sourceMappingURL=RunnableFunction.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/chatCompletionUtils.mjs
const isAssistantMessage = (message) => {
    return message?.role === 'assistant';
};
const isFunctionMessage = (message) => {
    return message?.role === 'function';
};
const isToolMessage = (message) => {
    return message?.role === 'tool';
};
function isPresent(obj) {
    return obj != null;
}
//# sourceMappingURL=chatCompletionUtils.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/EventStream.mjs
var EventStream_classPrivateFieldSet = (undefined && undefined.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var EventStream_classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _EventStream_instances, _EventStream_connectedPromise, _EventStream_resolveConnectedPromise, _EventStream_rejectConnectedPromise, _EventStream_endPromise, _EventStream_resolveEndPromise, _EventStream_rejectEndPromise, _EventStream_listeners, _EventStream_ended, _EventStream_errored, _EventStream_aborted, _EventStream_catchingPromiseCreated, _EventStream_handleError;

class EventStream {
    constructor() {
        _EventStream_instances.add(this);
        this.controller = new AbortController();
        _EventStream_connectedPromise.set(this, void 0);
        _EventStream_resolveConnectedPromise.set(this, () => { });
        _EventStream_rejectConnectedPromise.set(this, () => { });
        _EventStream_endPromise.set(this, void 0);
        _EventStream_resolveEndPromise.set(this, () => { });
        _EventStream_rejectEndPromise.set(this, () => { });
        _EventStream_listeners.set(this, {});
        _EventStream_ended.set(this, false);
        _EventStream_errored.set(this, false);
        _EventStream_aborted.set(this, false);
        _EventStream_catchingPromiseCreated.set(this, false);
        EventStream_classPrivateFieldSet(this, _EventStream_connectedPromise, new Promise((resolve, reject) => {
            EventStream_classPrivateFieldSet(this, _EventStream_resolveConnectedPromise, resolve, "f");
            EventStream_classPrivateFieldSet(this, _EventStream_rejectConnectedPromise, reject, "f");
        }), "f");
        EventStream_classPrivateFieldSet(this, _EventStream_endPromise, new Promise((resolve, reject) => {
            EventStream_classPrivateFieldSet(this, _EventStream_resolveEndPromise, resolve, "f");
            EventStream_classPrivateFieldSet(this, _EventStream_rejectEndPromise, reject, "f");
        }), "f");
        // Don't let these promises cause unhandled rejection errors.
        // we will manually cause an unhandled rejection error later
        // if the user hasn't registered any error listener or called
        // any promise-returning method.
        EventStream_classPrivateFieldGet(this, _EventStream_connectedPromise, "f").catch(() => { });
        EventStream_classPrivateFieldGet(this, _EventStream_endPromise, "f").catch(() => { });
    }
    _run(executor) {
        // Unfortunately if we call `executor()` immediately we get runtime errors about
        // references to `this` before the `super()` constructor call returns.
        setTimeout(() => {
            executor().then(() => {
                this._emitFinal();
                this._emit('end');
            }, EventStream_classPrivateFieldGet(this, _EventStream_instances, "m", _EventStream_handleError).bind(this));
        }, 0);
    }
    _connected() {
        if (this.ended)
            return;
        EventStream_classPrivateFieldGet(this, _EventStream_resolveConnectedPromise, "f").call(this);
        this._emit('connect');
    }
    get ended() {
        return EventStream_classPrivateFieldGet(this, _EventStream_ended, "f");
    }
    get errored() {
        return EventStream_classPrivateFieldGet(this, _EventStream_errored, "f");
    }
    get aborted() {
        return EventStream_classPrivateFieldGet(this, _EventStream_aborted, "f");
    }
    abort() {
        this.controller.abort();
    }
    /**
     * Adds the listener function to the end of the listeners array for the event.
     * No checks are made to see if the listener has already been added. Multiple calls passing
     * the same combination of event and listener will result in the listener being added, and
     * called, multiple times.
     * @returns this ChatCompletionStream, so that calls can be chained
     */
    on(event, listener) {
        const listeners = EventStream_classPrivateFieldGet(this, _EventStream_listeners, "f")[event] || (EventStream_classPrivateFieldGet(this, _EventStream_listeners, "f")[event] = []);
        listeners.push({ listener });
        return this;
    }
    /**
     * Removes the specified listener from the listener array for the event.
     * off() will remove, at most, one instance of a listener from the listener array. If any single
     * listener has been added multiple times to the listener array for the specified event, then
     * off() must be called multiple times to remove each instance.
     * @returns this ChatCompletionStream, so that calls can be chained
     */
    off(event, listener) {
        const listeners = EventStream_classPrivateFieldGet(this, _EventStream_listeners, "f")[event];
        if (!listeners)
            return this;
        const index = listeners.findIndex((l) => l.listener === listener);
        if (index >= 0)
            listeners.splice(index, 1);
        return this;
    }
    /**
     * Adds a one-time listener function for the event. The next time the event is triggered,
     * this listener is removed and then invoked.
     * @returns this ChatCompletionStream, so that calls can be chained
     */
    once(event, listener) {
        const listeners = EventStream_classPrivateFieldGet(this, _EventStream_listeners, "f")[event] || (EventStream_classPrivateFieldGet(this, _EventStream_listeners, "f")[event] = []);
        listeners.push({ listener, once: true });
        return this;
    }
    /**
     * This is similar to `.once()`, but returns a Promise that resolves the next time
     * the event is triggered, instead of calling a listener callback.
     * @returns a Promise that resolves the next time given event is triggered,
     * or rejects if an error is emitted.  (If you request the 'error' event,
     * returns a promise that resolves with the error).
     *
     * Example:
     *
     *   const message = await stream.emitted('message') // rejects if the stream errors
     */
    emitted(event) {
        return new Promise((resolve, reject) => {
            EventStream_classPrivateFieldSet(this, _EventStream_catchingPromiseCreated, true, "f");
            if (event !== 'error')
                this.once('error', reject);
            this.once(event, resolve);
        });
    }
    async done() {
        EventStream_classPrivateFieldSet(this, _EventStream_catchingPromiseCreated, true, "f");
        await EventStream_classPrivateFieldGet(this, _EventStream_endPromise, "f");
    }
    _emit(event, ...args) {
        // make sure we don't emit any events after end
        if (EventStream_classPrivateFieldGet(this, _EventStream_ended, "f")) {
            return;
        }
        if (event === 'end') {
            EventStream_classPrivateFieldSet(this, _EventStream_ended, true, "f");
            EventStream_classPrivateFieldGet(this, _EventStream_resolveEndPromise, "f").call(this);
        }
        const listeners = EventStream_classPrivateFieldGet(this, _EventStream_listeners, "f")[event];
        if (listeners) {
            EventStream_classPrivateFieldGet(this, _EventStream_listeners, "f")[event] = listeners.filter((l) => !l.once);
            listeners.forEach(({ listener }) => listener(...args));
        }
        if (event === 'abort') {
            const error = args[0];
            if (!EventStream_classPrivateFieldGet(this, _EventStream_catchingPromiseCreated, "f") && !listeners?.length) {
                Promise.reject(error);
            }
            EventStream_classPrivateFieldGet(this, _EventStream_rejectConnectedPromise, "f").call(this, error);
            EventStream_classPrivateFieldGet(this, _EventStream_rejectEndPromise, "f").call(this, error);
            this._emit('end');
            return;
        }
        if (event === 'error') {
            // NOTE: _emit('error', error) should only be called from #handleError().
            const error = args[0];
            if (!EventStream_classPrivateFieldGet(this, _EventStream_catchingPromiseCreated, "f") && !listeners?.length) {
                // Trigger an unhandled rejection if the user hasn't registered any error handlers.
                // If you are seeing stack traces here, make sure to handle errors via either:
                // - runner.on('error', () => ...)
                // - await runner.done()
                // - await runner.finalChatCompletion()
                // - etc.
                Promise.reject(error);
            }
            EventStream_classPrivateFieldGet(this, _EventStream_rejectConnectedPromise, "f").call(this, error);
            EventStream_classPrivateFieldGet(this, _EventStream_rejectEndPromise, "f").call(this, error);
            this._emit('end');
        }
    }
    _emitFinal() { }
}
_EventStream_connectedPromise = new WeakMap(), _EventStream_resolveConnectedPromise = new WeakMap(), _EventStream_rejectConnectedPromise = new WeakMap(), _EventStream_endPromise = new WeakMap(), _EventStream_resolveEndPromise = new WeakMap(), _EventStream_rejectEndPromise = new WeakMap(), _EventStream_listeners = new WeakMap(), _EventStream_ended = new WeakMap(), _EventStream_errored = new WeakMap(), _EventStream_aborted = new WeakMap(), _EventStream_catchingPromiseCreated = new WeakMap(), _EventStream_instances = new WeakSet(), _EventStream_handleError = function _EventStream_handleError(error) {
    EventStream_classPrivateFieldSet(this, _EventStream_errored, true, "f");
    if (error instanceof Error && error.name === 'AbortError') {
        error = new APIUserAbortError();
    }
    if (error instanceof APIUserAbortError) {
        EventStream_classPrivateFieldSet(this, _EventStream_aborted, true, "f");
        return this._emit('abort', error);
    }
    if (error instanceof error_OpenAIError) {
        return this._emit('error', error);
    }
    if (error instanceof Error) {
        const openAIError = new error_OpenAIError(error.message);
        // @ts-ignore
        openAIError.cause = error;
        return this._emit('error', openAIError);
    }
    return this._emit('error', new error_OpenAIError(String(error)));
};
//# sourceMappingURL=EventStream.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/parser.mjs

function makeParseableResponseFormat(response_format, parser) {
    const obj = { ...response_format };
    Object.defineProperties(obj, {
        $brand: {
            value: 'auto-parseable-response-format',
            enumerable: false,
        },
        $parseRaw: {
            value: parser,
            enumerable: false,
        },
    });
    return obj;
}
function makeParseableTextFormat(response_format, parser) {
    const obj = { ...response_format };
    Object.defineProperties(obj, {
        $brand: {
            value: 'auto-parseable-response-format',
            enumerable: false,
        },
        $parseRaw: {
            value: parser,
            enumerable: false,
        },
    });
    return obj;
}
function isAutoParsableResponseFormat(response_format) {
    return response_format?.['$brand'] === 'auto-parseable-response-format';
}
function makeParseableTool(tool, { parser, callback, }) {
    const obj = { ...tool };
    Object.defineProperties(obj, {
        $brand: {
            value: 'auto-parseable-tool',
            enumerable: false,
        },
        $parseRaw: {
            value: parser,
            enumerable: false,
        },
        $callback: {
            value: callback,
            enumerable: false,
        },
    });
    return obj;
}
function isAutoParsableTool(tool) {
    return tool?.['$brand'] === 'auto-parseable-tool';
}
function maybeParseChatCompletion(completion, params) {
    if (!params || !hasAutoParseableInput(params)) {
        return {
            ...completion,
            choices: completion.choices.map((choice) => ({
                ...choice,
                message: {
                    ...choice.message,
                    parsed: null,
                    ...(choice.message.tool_calls ?
                        {
                            tool_calls: choice.message.tool_calls,
                        }
                        : undefined),
                },
            })),
        };
    }
    return parseChatCompletion(completion, params);
}
function parseChatCompletion(completion, params) {
    const choices = completion.choices.map((choice) => {
        if (choice.finish_reason === 'length') {
            throw new LengthFinishReasonError();
        }
        if (choice.finish_reason === 'content_filter') {
            throw new ContentFilterFinishReasonError();
        }
        return {
            ...choice,
            message: {
                ...choice.message,
                ...(choice.message.tool_calls ?
                    {
                        tool_calls: choice.message.tool_calls?.map((toolCall) => parseToolCall(params, toolCall)) ?? undefined,
                    }
                    : undefined),
                parsed: choice.message.content && !choice.message.refusal ?
                    parseResponseFormat(params, choice.message.content)
                    : null,
            },
        };
    });
    return { ...completion, choices };
}
function parseResponseFormat(params, content) {
    if (params.response_format?.type !== 'json_schema') {
        return null;
    }
    if (params.response_format?.type === 'json_schema') {
        if ('$parseRaw' in params.response_format) {
            const response_format = params.response_format;
            return response_format.$parseRaw(content);
        }
        return JSON.parse(content);
    }
    return null;
}
function parseToolCall(params, toolCall) {
    const inputTool = params.tools?.find((inputTool) => inputTool.function?.name === toolCall.function.name);
    return {
        ...toolCall,
        function: {
            ...toolCall.function,
            parsed_arguments: isAutoParsableTool(inputTool) ? inputTool.$parseRaw(toolCall.function.arguments)
                : inputTool?.function.strict ? JSON.parse(toolCall.function.arguments)
                    : null,
        },
    };
}
function shouldParseToolCall(params, toolCall) {
    if (!params) {
        return false;
    }
    const inputTool = params.tools?.find((inputTool) => inputTool.function?.name === toolCall.function.name);
    return isAutoParsableTool(inputTool) || inputTool?.function.strict || false;
}
function hasAutoParseableInput(params) {
    if (isAutoParsableResponseFormat(params.response_format)) {
        return true;
    }
    return (params.tools?.some((t) => isAutoParsableTool(t) || (t.type === 'function' && t.function.strict === true)) ?? false);
}
function validateInputTools(tools) {
    for (const tool of tools ?? []) {
        if (tool.type !== 'function') {
            throw new error_OpenAIError(`Currently only \`function\` tool types support auto-parsing; Received \`${tool.type}\``);
        }
        if (tool.function.strict !== true) {
            throw new error_OpenAIError(`The \`${tool.function.name}\` tool is not marked with \`strict: true\`. Only strict function tools can be auto-parsed`);
        }
    }
}
//# sourceMappingURL=parser.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/AbstractChatCompletionRunner.mjs
var AbstractChatCompletionRunner_classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _AbstractChatCompletionRunner_instances, _AbstractChatCompletionRunner_getFinalContent, _AbstractChatCompletionRunner_getFinalMessage, _AbstractChatCompletionRunner_getFinalFunctionCall, _AbstractChatCompletionRunner_getFinalFunctionCallResult, _AbstractChatCompletionRunner_calculateTotalUsage, _AbstractChatCompletionRunner_validateParams, _AbstractChatCompletionRunner_stringifyFunctionCallResult;





const DEFAULT_MAX_CHAT_COMPLETIONS = 10;
class AbstractChatCompletionRunner extends EventStream {
    constructor() {
        super(...arguments);
        _AbstractChatCompletionRunner_instances.add(this);
        this._chatCompletions = [];
        this.messages = [];
    }
    _addChatCompletion(chatCompletion) {
        this._chatCompletions.push(chatCompletion);
        this._emit('chatCompletion', chatCompletion);
        const message = chatCompletion.choices[0]?.message;
        if (message)
            this._addMessage(message);
        return chatCompletion;
    }
    _addMessage(message, emit = true) {
        if (!('content' in message))
            message.content = null;
        this.messages.push(message);
        if (emit) {
            this._emit('message', message);
            if ((isFunctionMessage(message) || isToolMessage(message)) && message.content) {
                // Note, this assumes that {role: 'tool', content: …} is always the result of a call of tool of type=function.
                this._emit('functionCallResult', message.content);
            }
            else if (isAssistantMessage(message) && message.function_call) {
                this._emit('functionCall', message.function_call);
            }
            else if (isAssistantMessage(message) && message.tool_calls) {
                for (const tool_call of message.tool_calls) {
                    if (tool_call.type === 'function') {
                        this._emit('functionCall', tool_call.function);
                    }
                }
            }
        }
    }
    /**
     * @returns a promise that resolves with the final ChatCompletion, or rejects
     * if an error occurred or the stream ended prematurely without producing a ChatCompletion.
     */
    async finalChatCompletion() {
        await this.done();
        const completion = this._chatCompletions[this._chatCompletions.length - 1];
        if (!completion)
            throw new error_OpenAIError('stream ended without producing a ChatCompletion');
        return completion;
    }
    /**
     * @returns a promise that resolves with the content of the final ChatCompletionMessage, or rejects
     * if an error occurred or the stream ended prematurely without producing a ChatCompletionMessage.
     */
    async finalContent() {
        await this.done();
        return AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalContent).call(this);
    }
    /**
     * @returns a promise that resolves with the the final assistant ChatCompletionMessage response,
     * or rejects if an error occurred or the stream ended prematurely without producing a ChatCompletionMessage.
     */
    async finalMessage() {
        await this.done();
        return AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalMessage).call(this);
    }
    /**
     * @returns a promise that resolves with the content of the final FunctionCall, or rejects
     * if an error occurred or the stream ended prematurely without producing a ChatCompletionMessage.
     */
    async finalFunctionCall() {
        await this.done();
        return AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalFunctionCall).call(this);
    }
    async finalFunctionCallResult() {
        await this.done();
        return AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalFunctionCallResult).call(this);
    }
    async totalUsage() {
        await this.done();
        return AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_calculateTotalUsage).call(this);
    }
    allChatCompletions() {
        return [...this._chatCompletions];
    }
    _emitFinal() {
        const completion = this._chatCompletions[this._chatCompletions.length - 1];
        if (completion)
            this._emit('finalChatCompletion', completion);
        const finalMessage = AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalMessage).call(this);
        if (finalMessage)
            this._emit('finalMessage', finalMessage);
        const finalContent = AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalContent).call(this);
        if (finalContent)
            this._emit('finalContent', finalContent);
        const finalFunctionCall = AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalFunctionCall).call(this);
        if (finalFunctionCall)
            this._emit('finalFunctionCall', finalFunctionCall);
        const finalFunctionCallResult = AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalFunctionCallResult).call(this);
        if (finalFunctionCallResult != null)
            this._emit('finalFunctionCallResult', finalFunctionCallResult);
        if (this._chatCompletions.some((c) => c.usage)) {
            this._emit('totalUsage', AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_calculateTotalUsage).call(this));
        }
    }
    async _createChatCompletion(client, params, options) {
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_validateParams).call(this, params);
        const chatCompletion = await client.chat.completions.create({ ...params, stream: false }, { ...options, signal: this.controller.signal });
        this._connected();
        return this._addChatCompletion(parseChatCompletion(chatCompletion, params));
    }
    async _runChatCompletion(client, params, options) {
        for (const message of params.messages) {
            this._addMessage(message, false);
        }
        return await this._createChatCompletion(client, params, options);
    }
    async _runFunctions(client, params, options) {
        const role = 'function';
        const { function_call = 'auto', stream, ...restParams } = params;
        const singleFunctionToCall = typeof function_call !== 'string' && function_call?.name;
        const { maxChatCompletions = DEFAULT_MAX_CHAT_COMPLETIONS } = options || {};
        const functionsByName = {};
        for (const f of params.functions) {
            functionsByName[f.name || f.function.name] = f;
        }
        const functions = params.functions.map((f) => ({
            name: f.name || f.function.name,
            parameters: f.parameters,
            description: f.description,
        }));
        for (const message of params.messages) {
            this._addMessage(message, false);
        }
        for (let i = 0; i < maxChatCompletions; ++i) {
            const chatCompletion = await this._createChatCompletion(client, {
                ...restParams,
                function_call,
                functions,
                messages: [...this.messages],
            }, options);
            const message = chatCompletion.choices[0]?.message;
            if (!message) {
                throw new error_OpenAIError(`missing message in ChatCompletion response`);
            }
            if (!message.function_call)
                return;
            const { name, arguments: args } = message.function_call;
            const fn = functionsByName[name];
            if (!fn) {
                const content = `Invalid function_call: ${JSON.stringify(name)}. Available options are: ${functions
                    .map((f) => JSON.stringify(f.name))
                    .join(', ')}. Please try again`;
                this._addMessage({ role, name, content });
                continue;
            }
            else if (singleFunctionToCall && singleFunctionToCall !== name) {
                const content = `Invalid function_call: ${JSON.stringify(name)}. ${JSON.stringify(singleFunctionToCall)} requested. Please try again`;
                this._addMessage({ role, name, content });
                continue;
            }
            let parsed;
            try {
                parsed = isRunnableFunctionWithParse(fn) ? await fn.parse(args) : args;
            }
            catch (error) {
                this._addMessage({
                    role,
                    name,
                    content: error instanceof Error ? error.message : String(error),
                });
                continue;
            }
            // @ts-expect-error it can't rule out `never` type.
            const rawContent = await fn.function(parsed, this);
            const content = AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_stringifyFunctionCallResult).call(this, rawContent);
            this._addMessage({ role, name, content });
            if (singleFunctionToCall)
                return;
        }
    }
    async _runTools(client, params, options) {
        const role = 'tool';
        const { tool_choice = 'auto', stream, ...restParams } = params;
        const singleFunctionToCall = typeof tool_choice !== 'string' && tool_choice?.function?.name;
        const { maxChatCompletions = DEFAULT_MAX_CHAT_COMPLETIONS } = options || {};
        // TODO(someday): clean this logic up
        const inputTools = params.tools.map((tool) => {
            if (isAutoParsableTool(tool)) {
                if (!tool.$callback) {
                    throw new error_OpenAIError('Tool given to `.runTools()` that does not have an associated function');
                }
                return {
                    type: 'function',
                    function: {
                        function: tool.$callback,
                        name: tool.function.name,
                        description: tool.function.description || '',
                        parameters: tool.function.parameters,
                        parse: tool.$parseRaw,
                        strict: true,
                    },
                };
            }
            return tool;
        });
        const functionsByName = {};
        for (const f of inputTools) {
            if (f.type === 'function') {
                functionsByName[f.function.name || f.function.function.name] = f.function;
            }
        }
        const tools = 'tools' in params ?
            inputTools.map((t) => t.type === 'function' ?
                {
                    type: 'function',
                    function: {
                        name: t.function.name || t.function.function.name,
                        parameters: t.function.parameters,
                        description: t.function.description,
                        strict: t.function.strict,
                    },
                }
                : t)
            : undefined;
        for (const message of params.messages) {
            this._addMessage(message, false);
        }
        for (let i = 0; i < maxChatCompletions; ++i) {
            const chatCompletion = await this._createChatCompletion(client, {
                ...restParams,
                tool_choice,
                tools,
                messages: [...this.messages],
            }, options);
            const message = chatCompletion.choices[0]?.message;
            if (!message) {
                throw new error_OpenAIError(`missing message in ChatCompletion response`);
            }
            if (!message.tool_calls?.length) {
                return;
            }
            for (const tool_call of message.tool_calls) {
                if (tool_call.type !== 'function')
                    continue;
                const tool_call_id = tool_call.id;
                const { name, arguments: args } = tool_call.function;
                const fn = functionsByName[name];
                if (!fn) {
                    const content = `Invalid tool_call: ${JSON.stringify(name)}. Available options are: ${Object.keys(functionsByName)
                        .map((name) => JSON.stringify(name))
                        .join(', ')}. Please try again`;
                    this._addMessage({ role, tool_call_id, content });
                    continue;
                }
                else if (singleFunctionToCall && singleFunctionToCall !== name) {
                    const content = `Invalid tool_call: ${JSON.stringify(name)}. ${JSON.stringify(singleFunctionToCall)} requested. Please try again`;
                    this._addMessage({ role, tool_call_id, content });
                    continue;
                }
                let parsed;
                try {
                    parsed = isRunnableFunctionWithParse(fn) ? await fn.parse(args) : args;
                }
                catch (error) {
                    const content = error instanceof Error ? error.message : String(error);
                    this._addMessage({ role, tool_call_id, content });
                    continue;
                }
                // @ts-expect-error it can't rule out `never` type.
                const rawContent = await fn.function(parsed, this);
                const content = AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_stringifyFunctionCallResult).call(this, rawContent);
                this._addMessage({ role, tool_call_id, content });
                if (singleFunctionToCall) {
                    return;
                }
            }
        }
        return;
    }
}
_AbstractChatCompletionRunner_instances = new WeakSet(), _AbstractChatCompletionRunner_getFinalContent = function _AbstractChatCompletionRunner_getFinalContent() {
    return AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalMessage).call(this).content ?? null;
}, _AbstractChatCompletionRunner_getFinalMessage = function _AbstractChatCompletionRunner_getFinalMessage() {
    let i = this.messages.length;
    while (i-- > 0) {
        const message = this.messages[i];
        if (isAssistantMessage(message)) {
            const { function_call, ...rest } = message;
            // TODO: support audio here
            const ret = {
                ...rest,
                content: message.content ?? null,
                refusal: message.refusal ?? null,
            };
            if (function_call) {
                ret.function_call = function_call;
            }
            return ret;
        }
    }
    throw new error_OpenAIError('stream ended without producing a ChatCompletionMessage with role=assistant');
}, _AbstractChatCompletionRunner_getFinalFunctionCall = function _AbstractChatCompletionRunner_getFinalFunctionCall() {
    for (let i = this.messages.length - 1; i >= 0; i--) {
        const message = this.messages[i];
        if (isAssistantMessage(message) && message?.function_call) {
            return message.function_call;
        }
        if (isAssistantMessage(message) && message?.tool_calls?.length) {
            return message.tool_calls.at(-1)?.function;
        }
    }
    return;
}, _AbstractChatCompletionRunner_getFinalFunctionCallResult = function _AbstractChatCompletionRunner_getFinalFunctionCallResult() {
    for (let i = this.messages.length - 1; i >= 0; i--) {
        const message = this.messages[i];
        if (isFunctionMessage(message) && message.content != null) {
            return message.content;
        }
        if (isToolMessage(message) &&
            message.content != null &&
            typeof message.content === 'string' &&
            this.messages.some((x) => x.role === 'assistant' &&
                x.tool_calls?.some((y) => y.type === 'function' && y.id === message.tool_call_id))) {
            return message.content;
        }
    }
    return;
}, _AbstractChatCompletionRunner_calculateTotalUsage = function _AbstractChatCompletionRunner_calculateTotalUsage() {
    const total = {
        completion_tokens: 0,
        prompt_tokens: 0,
        total_tokens: 0,
    };
    for (const { usage } of this._chatCompletions) {
        if (usage) {
            total.completion_tokens += usage.completion_tokens;
            total.prompt_tokens += usage.prompt_tokens;
            total.total_tokens += usage.total_tokens;
        }
    }
    return total;
}, _AbstractChatCompletionRunner_validateParams = function _AbstractChatCompletionRunner_validateParams(params) {
    if (params.n != null && params.n > 1) {
        throw new error_OpenAIError('ChatCompletion convenience helpers only support n=1 at this time. To use n>1, please use chat.completions.create() directly.');
    }
}, _AbstractChatCompletionRunner_stringifyFunctionCallResult = function _AbstractChatCompletionRunner_stringifyFunctionCallResult(rawContent) {
    return (typeof rawContent === 'string' ? rawContent
        : rawContent === undefined ? 'undefined'
            : JSON.stringify(rawContent));
};
//# sourceMappingURL=AbstractChatCompletionRunner.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/ChatCompletionRunner.mjs


class ChatCompletionRunner extends AbstractChatCompletionRunner {
    /** @deprecated - please use `runTools` instead. */
    static runFunctions(client, params, options) {
        const runner = new ChatCompletionRunner();
        const opts = {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'runFunctions' },
        };
        runner._run(() => runner._runFunctions(client, params, opts));
        return runner;
    }
    static runTools(client, params, options) {
        const runner = new ChatCompletionRunner();
        const opts = {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'runTools' },
        };
        runner._run(() => runner._runTools(client, params, opts));
        return runner;
    }
    _addMessage(message, emit = true) {
        super._addMessage(message, emit);
        if (isAssistantMessage(message) && message.content) {
            this._emit('content', message.content);
        }
    }
}
//# sourceMappingURL=ChatCompletionRunner.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/_vendor/partial-json-parser/parser.mjs
const STR = 0b000000001;
const NUM = 0b000000010;
const ARR = 0b000000100;
const OBJ = 0b000001000;
const NULL = 0b000010000;
const BOOL = 0b000100000;
const NAN = 0b001000000;
const INFINITY = 0b010000000;
const MINUS_INFINITY = 0b100000000;
const INF = INFINITY | MINUS_INFINITY;
const SPECIAL = NULL | BOOL | INF | NAN;
const ATOM = STR | NUM | SPECIAL;
const COLLECTION = ARR | OBJ;
const ALL = ATOM | COLLECTION;
const Allow = {
    STR,
    NUM,
    ARR,
    OBJ,
    NULL,
    BOOL,
    NAN,
    INFINITY,
    MINUS_INFINITY,
    INF,
    SPECIAL,
    ATOM,
    COLLECTION,
    ALL,
};
// The JSON string segment was unable to be parsed completely
class PartialJSON extends Error {
}
class MalformedJSON extends Error {
}
/**
 * Parse incomplete JSON
 * @param {string} jsonString Partial JSON to be parsed
 * @param {number} allowPartial Specify what types are allowed to be partial, see {@link Allow} for details
 * @returns The parsed JSON
 * @throws {PartialJSON} If the JSON is incomplete (related to the `allow` parameter)
 * @throws {MalformedJSON} If the JSON is malformed
 */
function parseJSON(jsonString, allowPartial = Allow.ALL) {
    if (typeof jsonString !== 'string') {
        throw new TypeError(`expecting str, got ${typeof jsonString}`);
    }
    if (!jsonString.trim()) {
        throw new Error(`${jsonString} is empty`);
    }
    return _parseJSON(jsonString.trim(), allowPartial);
}
const _parseJSON = (jsonString, allow) => {
    const length = jsonString.length;
    let index = 0;
    const markPartialJSON = (msg) => {
        throw new PartialJSON(`${msg} at position ${index}`);
    };
    const throwMalformedError = (msg) => {
        throw new MalformedJSON(`${msg} at position ${index}`);
    };
    const parseAny = () => {
        skipBlank();
        if (index >= length)
            markPartialJSON('Unexpected end of input');
        if (jsonString[index] === '"')
            return parseStr();
        if (jsonString[index] === '{')
            return parseObj();
        if (jsonString[index] === '[')
            return parseArr();
        if (jsonString.substring(index, index + 4) === 'null' ||
            (Allow.NULL & allow && length - index < 4 && 'null'.startsWith(jsonString.substring(index)))) {
            index += 4;
            return null;
        }
        if (jsonString.substring(index, index + 4) === 'true' ||
            (Allow.BOOL & allow && length - index < 4 && 'true'.startsWith(jsonString.substring(index)))) {
            index += 4;
            return true;
        }
        if (jsonString.substring(index, index + 5) === 'false' ||
            (Allow.BOOL & allow && length - index < 5 && 'false'.startsWith(jsonString.substring(index)))) {
            index += 5;
            return false;
        }
        if (jsonString.substring(index, index + 8) === 'Infinity' ||
            (Allow.INFINITY & allow && length - index < 8 && 'Infinity'.startsWith(jsonString.substring(index)))) {
            index += 8;
            return Infinity;
        }
        if (jsonString.substring(index, index + 9) === '-Infinity' ||
            (Allow.MINUS_INFINITY & allow &&
                1 < length - index &&
                length - index < 9 &&
                '-Infinity'.startsWith(jsonString.substring(index)))) {
            index += 9;
            return -Infinity;
        }
        if (jsonString.substring(index, index + 3) === 'NaN' ||
            (Allow.NAN & allow && length - index < 3 && 'NaN'.startsWith(jsonString.substring(index)))) {
            index += 3;
            return NaN;
        }
        return parseNum();
    };
    const parseStr = () => {
        const start = index;
        let escape = false;
        index++; // skip initial quote
        while (index < length && (jsonString[index] !== '"' || (escape && jsonString[index - 1] === '\\'))) {
            escape = jsonString[index] === '\\' ? !escape : false;
            index++;
        }
        if (jsonString.charAt(index) == '"') {
            try {
                return JSON.parse(jsonString.substring(start, ++index - Number(escape)));
            }
            catch (e) {
                throwMalformedError(String(e));
            }
        }
        else if (Allow.STR & allow) {
            try {
                return JSON.parse(jsonString.substring(start, index - Number(escape)) + '"');
            }
            catch (e) {
                // SyntaxError: Invalid escape sequence
                return JSON.parse(jsonString.substring(start, jsonString.lastIndexOf('\\')) + '"');
            }
        }
        markPartialJSON('Unterminated string literal');
    };
    const parseObj = () => {
        index++; // skip initial brace
        skipBlank();
        const obj = {};
        try {
            while (jsonString[index] !== '}') {
                skipBlank();
                if (index >= length && Allow.OBJ & allow)
                    return obj;
                const key = parseStr();
                skipBlank();
                index++; // skip colon
                try {
                    const value = parseAny();
                    Object.defineProperty(obj, key, { value, writable: true, enumerable: true, configurable: true });
                }
                catch (e) {
                    if (Allow.OBJ & allow)
                        return obj;
                    else
                        throw e;
                }
                skipBlank();
                if (jsonString[index] === ',')
                    index++; // skip comma
            }
        }
        catch (e) {
            if (Allow.OBJ & allow)
                return obj;
            else
                markPartialJSON("Expected '}' at end of object");
        }
        index++; // skip final brace
        return obj;
    };
    const parseArr = () => {
        index++; // skip initial bracket
        const arr = [];
        try {
            while (jsonString[index] !== ']') {
                arr.push(parseAny());
                skipBlank();
                if (jsonString[index] === ',') {
                    index++; // skip comma
                }
            }
        }
        catch (e) {
            if (Allow.ARR & allow) {
                return arr;
            }
            markPartialJSON("Expected ']' at end of array");
        }
        index++; // skip final bracket
        return arr;
    };
    const parseNum = () => {
        if (index === 0) {
            if (jsonString === '-' && Allow.NUM & allow)
                markPartialJSON("Not sure what '-' is");
            try {
                return JSON.parse(jsonString);
            }
            catch (e) {
                if (Allow.NUM & allow) {
                    try {
                        if ('.' === jsonString[jsonString.length - 1])
                            return JSON.parse(jsonString.substring(0, jsonString.lastIndexOf('.')));
                        return JSON.parse(jsonString.substring(0, jsonString.lastIndexOf('e')));
                    }
                    catch (e) { }
                }
                throwMalformedError(String(e));
            }
        }
        const start = index;
        if (jsonString[index] === '-')
            index++;
        while (jsonString[index] && !',]}'.includes(jsonString[index]))
            index++;
        if (index == length && !(Allow.NUM & allow))
            markPartialJSON('Unterminated number literal');
        try {
            return JSON.parse(jsonString.substring(start, index));
        }
        catch (e) {
            if (jsonString.substring(start, index) === '-' && Allow.NUM & allow)
                markPartialJSON("Not sure what '-' is");
            try {
                return JSON.parse(jsonString.substring(start, jsonString.lastIndexOf('e')));
            }
            catch (e) {
                throwMalformedError(String(e));
            }
        }
    };
    const skipBlank = () => {
        while (index < length && ' \n\r\t'.includes(jsonString[index])) {
            index++;
        }
    };
    return parseAny();
};
// using this function with malformed JSON is undefined behavior
const partialParse = (input) => parseJSON(input, Allow.ALL ^ Allow.NUM);

//# sourceMappingURL=parser.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/ChatCompletionStream.mjs
var ChatCompletionStream_classPrivateFieldSet = (undefined && undefined.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var ChatCompletionStream_classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _ChatCompletionStream_instances, _ChatCompletionStream_params, _ChatCompletionStream_choiceEventStates, _ChatCompletionStream_currentChatCompletionSnapshot, _ChatCompletionStream_beginRequest, _ChatCompletionStream_getChoiceEventState, _ChatCompletionStream_addChunk, _ChatCompletionStream_emitToolCallDoneEvent, _ChatCompletionStream_emitContentDoneEvents, _ChatCompletionStream_endRequest, _ChatCompletionStream_getAutoParseableResponseFormat, _ChatCompletionStream_accumulateChatCompletion;





class ChatCompletionStream extends AbstractChatCompletionRunner {
    constructor(params) {
        super();
        _ChatCompletionStream_instances.add(this);
        _ChatCompletionStream_params.set(this, void 0);
        _ChatCompletionStream_choiceEventStates.set(this, void 0);
        _ChatCompletionStream_currentChatCompletionSnapshot.set(this, void 0);
        ChatCompletionStream_classPrivateFieldSet(this, _ChatCompletionStream_params, params, "f");
        ChatCompletionStream_classPrivateFieldSet(this, _ChatCompletionStream_choiceEventStates, [], "f");
    }
    get currentChatCompletionSnapshot() {
        return ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_currentChatCompletionSnapshot, "f");
    }
    /**
     * Intended for use on the frontend, consuming a stream produced with
     * `.toReadableStream()` on the backend.
     *
     * Note that messages sent to the model do not appear in `.on('message')`
     * in this context.
     */
    static fromReadableStream(stream) {
        const runner = new ChatCompletionStream(null);
        runner._run(() => runner._fromReadableStream(stream));
        return runner;
    }
    static createChatCompletion(client, params, options) {
        const runner = new ChatCompletionStream(params);
        runner._run(() => runner._runChatCompletion(client, { ...params, stream: true }, { ...options, headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'stream' } }));
        return runner;
    }
    async _createChatCompletion(client, params, options) {
        super._createChatCompletion;
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_beginRequest).call(this);
        const stream = await client.chat.completions.create({ ...params, stream: true }, { ...options, signal: this.controller.signal });
        this._connected();
        for await (const chunk of stream) {
            ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_addChunk).call(this, chunk);
        }
        if (stream.controller.signal?.aborted) {
            throw new APIUserAbortError();
        }
        return this._addChatCompletion(ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_endRequest).call(this));
    }
    async _fromReadableStream(readableStream, options) {
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_beginRequest).call(this);
        this._connected();
        const stream = Stream.fromReadableStream(readableStream, this.controller);
        let chatId;
        for await (const chunk of stream) {
            if (chatId && chatId !== chunk.id) {
                // A new request has been made.
                this._addChatCompletion(ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_endRequest).call(this));
            }
            ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_addChunk).call(this, chunk);
            chatId = chunk.id;
        }
        if (stream.controller.signal?.aborted) {
            throw new APIUserAbortError();
        }
        return this._addChatCompletion(ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_endRequest).call(this));
    }
    [(_ChatCompletionStream_params = new WeakMap(), _ChatCompletionStream_choiceEventStates = new WeakMap(), _ChatCompletionStream_currentChatCompletionSnapshot = new WeakMap(), _ChatCompletionStream_instances = new WeakSet(), _ChatCompletionStream_beginRequest = function _ChatCompletionStream_beginRequest() {
        if (this.ended)
            return;
        ChatCompletionStream_classPrivateFieldSet(this, _ChatCompletionStream_currentChatCompletionSnapshot, undefined, "f");
    }, _ChatCompletionStream_getChoiceEventState = function _ChatCompletionStream_getChoiceEventState(choice) {
        let state = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_choiceEventStates, "f")[choice.index];
        if (state) {
            return state;
        }
        state = {
            content_done: false,
            refusal_done: false,
            logprobs_content_done: false,
            logprobs_refusal_done: false,
            done_tool_calls: new Set(),
            current_tool_call_index: null,
        };
        ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_choiceEventStates, "f")[choice.index] = state;
        return state;
    }, _ChatCompletionStream_addChunk = function _ChatCompletionStream_addChunk(chunk) {
        if (this.ended)
            return;
        const completion = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_accumulateChatCompletion).call(this, chunk);
        this._emit('chunk', chunk, completion);
        for (const choice of chunk.choices) {
            const choiceSnapshot = completion.choices[choice.index];
            if (choice.delta.content != null &&
                choiceSnapshot.message?.role === 'assistant' &&
                choiceSnapshot.message?.content) {
                this._emit('content', choice.delta.content, choiceSnapshot.message.content);
                this._emit('content.delta', {
                    delta: choice.delta.content,
                    snapshot: choiceSnapshot.message.content,
                    parsed: choiceSnapshot.message.parsed,
                });
            }
            if (choice.delta.refusal != null &&
                choiceSnapshot.message?.role === 'assistant' &&
                choiceSnapshot.message?.refusal) {
                this._emit('refusal.delta', {
                    delta: choice.delta.refusal,
                    snapshot: choiceSnapshot.message.refusal,
                });
            }
            if (choice.logprobs?.content != null && choiceSnapshot.message?.role === 'assistant') {
                this._emit('logprobs.content.delta', {
                    content: choice.logprobs?.content,
                    snapshot: choiceSnapshot.logprobs?.content ?? [],
                });
            }
            if (choice.logprobs?.refusal != null && choiceSnapshot.message?.role === 'assistant') {
                this._emit('logprobs.refusal.delta', {
                    refusal: choice.logprobs?.refusal,
                    snapshot: choiceSnapshot.logprobs?.refusal ?? [],
                });
            }
            const state = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_getChoiceEventState).call(this, choiceSnapshot);
            if (choiceSnapshot.finish_reason) {
                ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_emitContentDoneEvents).call(this, choiceSnapshot);
                if (state.current_tool_call_index != null) {
                    ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_emitToolCallDoneEvent).call(this, choiceSnapshot, state.current_tool_call_index);
                }
            }
            for (const toolCall of choice.delta.tool_calls ?? []) {
                if (state.current_tool_call_index !== toolCall.index) {
                    ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_emitContentDoneEvents).call(this, choiceSnapshot);
                    // new tool call started, the previous one is done
                    if (state.current_tool_call_index != null) {
                        ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_emitToolCallDoneEvent).call(this, choiceSnapshot, state.current_tool_call_index);
                    }
                }
                state.current_tool_call_index = toolCall.index;
            }
            for (const toolCallDelta of choice.delta.tool_calls ?? []) {
                const toolCallSnapshot = choiceSnapshot.message.tool_calls?.[toolCallDelta.index];
                if (!toolCallSnapshot?.type) {
                    continue;
                }
                if (toolCallSnapshot?.type === 'function') {
                    this._emit('tool_calls.function.arguments.delta', {
                        name: toolCallSnapshot.function?.name,
                        index: toolCallDelta.index,
                        arguments: toolCallSnapshot.function.arguments,
                        parsed_arguments: toolCallSnapshot.function.parsed_arguments,
                        arguments_delta: toolCallDelta.function?.arguments ?? '',
                    });
                }
                else {
                    assertNever(toolCallSnapshot?.type);
                }
            }
        }
    }, _ChatCompletionStream_emitToolCallDoneEvent = function _ChatCompletionStream_emitToolCallDoneEvent(choiceSnapshot, toolCallIndex) {
        const state = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_getChoiceEventState).call(this, choiceSnapshot);
        if (state.done_tool_calls.has(toolCallIndex)) {
            // we've already fired the done event
            return;
        }
        const toolCallSnapshot = choiceSnapshot.message.tool_calls?.[toolCallIndex];
        if (!toolCallSnapshot) {
            throw new Error('no tool call snapshot');
        }
        if (!toolCallSnapshot.type) {
            throw new Error('tool call snapshot missing `type`');
        }
        if (toolCallSnapshot.type === 'function') {
            const inputTool = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_params, "f")?.tools?.find((tool) => tool.type === 'function' && tool.function.name === toolCallSnapshot.function.name);
            this._emit('tool_calls.function.arguments.done', {
                name: toolCallSnapshot.function.name,
                index: toolCallIndex,
                arguments: toolCallSnapshot.function.arguments,
                parsed_arguments: isAutoParsableTool(inputTool) ? inputTool.$parseRaw(toolCallSnapshot.function.arguments)
                    : inputTool?.function.strict ? JSON.parse(toolCallSnapshot.function.arguments)
                        : null,
            });
        }
        else {
            assertNever(toolCallSnapshot.type);
        }
    }, _ChatCompletionStream_emitContentDoneEvents = function _ChatCompletionStream_emitContentDoneEvents(choiceSnapshot) {
        const state = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_getChoiceEventState).call(this, choiceSnapshot);
        if (choiceSnapshot.message.content && !state.content_done) {
            state.content_done = true;
            const responseFormat = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_getAutoParseableResponseFormat).call(this);
            this._emit('content.done', {
                content: choiceSnapshot.message.content,
                parsed: responseFormat ? responseFormat.$parseRaw(choiceSnapshot.message.content) : null,
            });
        }
        if (choiceSnapshot.message.refusal && !state.refusal_done) {
            state.refusal_done = true;
            this._emit('refusal.done', { refusal: choiceSnapshot.message.refusal });
        }
        if (choiceSnapshot.logprobs?.content && !state.logprobs_content_done) {
            state.logprobs_content_done = true;
            this._emit('logprobs.content.done', { content: choiceSnapshot.logprobs.content });
        }
        if (choiceSnapshot.logprobs?.refusal && !state.logprobs_refusal_done) {
            state.logprobs_refusal_done = true;
            this._emit('logprobs.refusal.done', { refusal: choiceSnapshot.logprobs.refusal });
        }
    }, _ChatCompletionStream_endRequest = function _ChatCompletionStream_endRequest() {
        if (this.ended) {
            throw new error_OpenAIError(`stream has ended, this shouldn't happen`);
        }
        const snapshot = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_currentChatCompletionSnapshot, "f");
        if (!snapshot) {
            throw new error_OpenAIError(`request ended without sending any chunks`);
        }
        ChatCompletionStream_classPrivateFieldSet(this, _ChatCompletionStream_currentChatCompletionSnapshot, undefined, "f");
        ChatCompletionStream_classPrivateFieldSet(this, _ChatCompletionStream_choiceEventStates, [], "f");
        return finalizeChatCompletion(snapshot, ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_params, "f"));
    }, _ChatCompletionStream_getAutoParseableResponseFormat = function _ChatCompletionStream_getAutoParseableResponseFormat() {
        const responseFormat = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_params, "f")?.response_format;
        if (isAutoParsableResponseFormat(responseFormat)) {
            return responseFormat;
        }
        return null;
    }, _ChatCompletionStream_accumulateChatCompletion = function _ChatCompletionStream_accumulateChatCompletion(chunk) {
        var _a, _b, _c, _d;
        let snapshot = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_currentChatCompletionSnapshot, "f");
        const { choices, ...rest } = chunk;
        if (!snapshot) {
            snapshot = ChatCompletionStream_classPrivateFieldSet(this, _ChatCompletionStream_currentChatCompletionSnapshot, {
                ...rest,
                choices: [],
            }, "f");
        }
        else {
            Object.assign(snapshot, rest);
        }
        for (const { delta, finish_reason, index, logprobs = null, ...other } of chunk.choices) {
            let choice = snapshot.choices[index];
            if (!choice) {
                choice = snapshot.choices[index] = { finish_reason, index, message: {}, logprobs, ...other };
            }
            if (logprobs) {
                if (!choice.logprobs) {
                    choice.logprobs = Object.assign({}, logprobs);
                }
                else {
                    const { content, refusal, ...rest } = logprobs;
                    assertIsEmpty(rest);
                    Object.assign(choice.logprobs, rest);
                    if (content) {
                        (_a = choice.logprobs).content ?? (_a.content = []);
                        choice.logprobs.content.push(...content);
                    }
                    if (refusal) {
                        (_b = choice.logprobs).refusal ?? (_b.refusal = []);
                        choice.logprobs.refusal.push(...refusal);
                    }
                }
            }
            if (finish_reason) {
                choice.finish_reason = finish_reason;
                if (ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_params, "f") && hasAutoParseableInput(ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_params, "f"))) {
                    if (finish_reason === 'length') {
                        throw new LengthFinishReasonError();
                    }
                    if (finish_reason === 'content_filter') {
                        throw new ContentFilterFinishReasonError();
                    }
                }
            }
            Object.assign(choice, other);
            if (!delta)
                continue; // Shouldn't happen; just in case.
            const { content, refusal, function_call, role, tool_calls, ...rest } = delta;
            assertIsEmpty(rest);
            Object.assign(choice.message, rest);
            if (refusal) {
                choice.message.refusal = (choice.message.refusal || '') + refusal;
            }
            if (role)
                choice.message.role = role;
            if (function_call) {
                if (!choice.message.function_call) {
                    choice.message.function_call = function_call;
                }
                else {
                    if (function_call.name)
                        choice.message.function_call.name = function_call.name;
                    if (function_call.arguments) {
                        (_c = choice.message.function_call).arguments ?? (_c.arguments = '');
                        choice.message.function_call.arguments += function_call.arguments;
                    }
                }
            }
            if (content) {
                choice.message.content = (choice.message.content || '') + content;
                if (!choice.message.refusal && ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_getAutoParseableResponseFormat).call(this)) {
                    choice.message.parsed = partialParse(choice.message.content);
                }
            }
            if (tool_calls) {
                if (!choice.message.tool_calls)
                    choice.message.tool_calls = [];
                for (const { index, id, type, function: fn, ...rest } of tool_calls) {
                    const tool_call = ((_d = choice.message.tool_calls)[index] ?? (_d[index] = {}));
                    Object.assign(tool_call, rest);
                    if (id)
                        tool_call.id = id;
                    if (type)
                        tool_call.type = type;
                    if (fn)
                        tool_call.function ?? (tool_call.function = { name: fn.name ?? '', arguments: '' });
                    if (fn?.name)
                        tool_call.function.name = fn.name;
                    if (fn?.arguments) {
                        tool_call.function.arguments += fn.arguments;
                        if (shouldParseToolCall(ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_params, "f"), tool_call)) {
                            tool_call.function.parsed_arguments = partialParse(tool_call.function.arguments);
                        }
                    }
                }
            }
        }
        return snapshot;
    }, Symbol.asyncIterator)]() {
        const pushQueue = [];
        const readQueue = [];
        let done = false;
        this.on('chunk', (chunk) => {
            const reader = readQueue.shift();
            if (reader) {
                reader.resolve(chunk);
            }
            else {
                pushQueue.push(chunk);
            }
        });
        this.on('end', () => {
            done = true;
            for (const reader of readQueue) {
                reader.resolve(undefined);
            }
            readQueue.length = 0;
        });
        this.on('abort', (err) => {
            done = true;
            for (const reader of readQueue) {
                reader.reject(err);
            }
            readQueue.length = 0;
        });
        this.on('error', (err) => {
            done = true;
            for (const reader of readQueue) {
                reader.reject(err);
            }
            readQueue.length = 0;
        });
        return {
            next: async () => {
                if (!pushQueue.length) {
                    if (done) {
                        return { value: undefined, done: true };
                    }
                    return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((chunk) => (chunk ? { value: chunk, done: false } : { value: undefined, done: true }));
                }
                const chunk = pushQueue.shift();
                return { value: chunk, done: false };
            },
            return: async () => {
                this.abort();
                return { value: undefined, done: true };
            },
        };
    }
    toReadableStream() {
        const stream = new Stream(this[Symbol.asyncIterator].bind(this), this.controller);
        return stream.toReadableStream();
    }
}
function finalizeChatCompletion(snapshot, params) {
    const { id, choices, created, model, system_fingerprint, ...rest } = snapshot;
    const completion = {
        ...rest,
        id,
        choices: choices.map(({ message, finish_reason, index, logprobs, ...choiceRest }) => {
            if (!finish_reason) {
                throw new error_OpenAIError(`missing finish_reason for choice ${index}`);
            }
            const { content = null, function_call, tool_calls, ...messageRest } = message;
            const role = message.role; // this is what we expect; in theory it could be different which would make our types a slight lie but would be fine.
            if (!role) {
                throw new error_OpenAIError(`missing role for choice ${index}`);
            }
            if (function_call) {
                const { arguments: args, name } = function_call;
                if (args == null) {
                    throw new error_OpenAIError(`missing function_call.arguments for choice ${index}`);
                }
                if (!name) {
                    throw new error_OpenAIError(`missing function_call.name for choice ${index}`);
                }
                return {
                    ...choiceRest,
                    message: {
                        content,
                        function_call: { arguments: args, name },
                        role,
                        refusal: message.refusal ?? null,
                    },
                    finish_reason,
                    index,
                    logprobs,
                };
            }
            if (tool_calls) {
                return {
                    ...choiceRest,
                    index,
                    finish_reason,
                    logprobs,
                    message: {
                        ...messageRest,
                        role,
                        content,
                        refusal: message.refusal ?? null,
                        tool_calls: tool_calls.map((tool_call, i) => {
                            const { function: fn, type, id, ...toolRest } = tool_call;
                            const { arguments: args, name, ...fnRest } = fn || {};
                            if (id == null) {
                                throw new error_OpenAIError(`missing choices[${index}].tool_calls[${i}].id\n${str(snapshot)}`);
                            }
                            if (type == null) {
                                throw new error_OpenAIError(`missing choices[${index}].tool_calls[${i}].type\n${str(snapshot)}`);
                            }
                            if (name == null) {
                                throw new error_OpenAIError(`missing choices[${index}].tool_calls[${i}].function.name\n${str(snapshot)}`);
                            }
                            if (args == null) {
                                throw new error_OpenAIError(`missing choices[${index}].tool_calls[${i}].function.arguments\n${str(snapshot)}`);
                            }
                            return { ...toolRest, id, type, function: { ...fnRest, name, arguments: args } };
                        }),
                    },
                };
            }
            return {
                ...choiceRest,
                message: { ...messageRest, content, role, refusal: message.refusal ?? null },
                finish_reason,
                index,
                logprobs,
            };
        }),
        created,
        model,
        object: 'chat.completion',
        ...(system_fingerprint ? { system_fingerprint } : {}),
    };
    return maybeParseChatCompletion(completion, params);
}
function str(x) {
    return JSON.stringify(x);
}
/**
 * Ensures the given argument is an empty object, useful for
 * asserting that all known properties on an object have been
 * destructured.
 */
function assertIsEmpty(obj) {
    return;
}
function assertNever(_x) { }
//# sourceMappingURL=ChatCompletionStream.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/ChatCompletionStreamingRunner.mjs

class ChatCompletionStreamingRunner extends ChatCompletionStream {
    static fromReadableStream(stream) {
        const runner = new ChatCompletionStreamingRunner(null);
        runner._run(() => runner._fromReadableStream(stream));
        return runner;
    }
    /** @deprecated - please use `runTools` instead. */
    static runFunctions(client, params, options) {
        const runner = new ChatCompletionStreamingRunner(null);
        const opts = {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'runFunctions' },
        };
        runner._run(() => runner._runFunctions(client, params, opts));
        return runner;
    }
    static runTools(client, params, options) {
        const runner = new ChatCompletionStreamingRunner(
        // @ts-expect-error TODO these types are incompatible
        params);
        const opts = {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'runTools' },
        };
        runner._run(() => runner._runTools(client, params, opts));
        return runner;
    }
}
//# sourceMappingURL=ChatCompletionStreamingRunner.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/chat/completions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.









class chat_completions_Completions extends APIResource {
    parse(body, options) {
        validateInputTools(body.tools);
        return this._client.chat.completions
            .create(body, {
            ...options,
            headers: {
                ...options?.headers,
                'X-Stainless-Helper-Method': 'beta.chat.completions.parse',
            },
        })
            ._thenUnwrap((completion) => parseChatCompletion(completion, body));
    }
    runFunctions(body, options) {
        if (body.stream) {
            return ChatCompletionStreamingRunner.runFunctions(this._client, body, options);
        }
        return ChatCompletionRunner.runFunctions(this._client, body, options);
    }
    runTools(body, options) {
        if (body.stream) {
            return ChatCompletionStreamingRunner.runTools(this._client, body, options);
        }
        return ChatCompletionRunner.runTools(this._client, body, options);
    }
    /**
     * Creates a chat completion stream
     */
    stream(body, options) {
        return ChatCompletionStream.createChatCompletion(this._client, body, options);
    }
}
//# sourceMappingURL=completions.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/chat/chat.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class chat_Chat extends APIResource {
    constructor() {
        super(...arguments);
        this.completions = new chat_completions_Completions(this._client);
    }
}
(function (Chat) {
    Chat.Completions = chat_completions_Completions;
})(chat_Chat || (chat_Chat = {}));
//# sourceMappingURL=chat.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/realtime/sessions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class Sessions extends APIResource {
    /**
     * Create an ephemeral API token for use in client-side applications with the
     * Realtime API. Can be configured with the same session parameters as the
     * `session.update` client event.
     *
     * It responds with a session object, plus a `client_secret` key which contains a
     * usable ephemeral API token that can be used to authenticate browser clients for
     * the Realtime API.
     */
    create(body, options) {
        return this._client.post('/realtime/sessions', {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
}
//# sourceMappingURL=sessions.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/realtime/transcription-sessions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class TranscriptionSessions extends APIResource {
    /**
     * Create an ephemeral API token for use in client-side applications with the
     * Realtime API specifically for realtime transcriptions. Can be configured with
     * the same session parameters as the `transcription_session.update` client event.
     *
     * It responds with a session object, plus a `client_secret` key which contains a
     * usable ephemeral API token that can be used to authenticate browser clients for
     * the Realtime API.
     */
    create(body, options) {
        return this._client.post('/realtime/transcription_sessions', {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
}
//# sourceMappingURL=transcription-sessions.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/realtime/realtime.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.





class Realtime extends APIResource {
    constructor() {
        super(...arguments);
        this.sessions = new Sessions(this._client);
        this.transcriptionSessions = new TranscriptionSessions(this._client);
    }
}
Realtime.Sessions = Sessions;
Realtime.TranscriptionSessions = TranscriptionSessions;
//# sourceMappingURL=realtime.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/AssistantStream.mjs
var AssistantStream_classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var AssistantStream_classPrivateFieldSet = (undefined && undefined.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var _AssistantStream_instances, _AssistantStream_events, _AssistantStream_runStepSnapshots, _AssistantStream_messageSnapshots, _AssistantStream_messageSnapshot, _AssistantStream_finalRun, _AssistantStream_currentContentIndex, _AssistantStream_currentContent, _AssistantStream_currentToolCallIndex, _AssistantStream_currentToolCall, _AssistantStream_currentEvent, _AssistantStream_currentRunSnapshot, _AssistantStream_currentRunStepSnapshot, _AssistantStream_addEvent, _AssistantStream_endRequest, _AssistantStream_handleMessage, _AssistantStream_handleRunStep, _AssistantStream_handleEvent, _AssistantStream_accumulateRunStep, _AssistantStream_accumulateMessage, _AssistantStream_accumulateContent, _AssistantStream_handleRun;




class AssistantStream extends EventStream {
    constructor() {
        super(...arguments);
        _AssistantStream_instances.add(this);
        //Track all events in a single list for reference
        _AssistantStream_events.set(this, []);
        //Used to accumulate deltas
        //We are accumulating many types so the value here is not strict
        _AssistantStream_runStepSnapshots.set(this, {});
        _AssistantStream_messageSnapshots.set(this, {});
        _AssistantStream_messageSnapshot.set(this, void 0);
        _AssistantStream_finalRun.set(this, void 0);
        _AssistantStream_currentContentIndex.set(this, void 0);
        _AssistantStream_currentContent.set(this, void 0);
        _AssistantStream_currentToolCallIndex.set(this, void 0);
        _AssistantStream_currentToolCall.set(this, void 0);
        //For current snapshot methods
        _AssistantStream_currentEvent.set(this, void 0);
        _AssistantStream_currentRunSnapshot.set(this, void 0);
        _AssistantStream_currentRunStepSnapshot.set(this, void 0);
    }
    [(_AssistantStream_events = new WeakMap(), _AssistantStream_runStepSnapshots = new WeakMap(), _AssistantStream_messageSnapshots = new WeakMap(), _AssistantStream_messageSnapshot = new WeakMap(), _AssistantStream_finalRun = new WeakMap(), _AssistantStream_currentContentIndex = new WeakMap(), _AssistantStream_currentContent = new WeakMap(), _AssistantStream_currentToolCallIndex = new WeakMap(), _AssistantStream_currentToolCall = new WeakMap(), _AssistantStream_currentEvent = new WeakMap(), _AssistantStream_currentRunSnapshot = new WeakMap(), _AssistantStream_currentRunStepSnapshot = new WeakMap(), _AssistantStream_instances = new WeakSet(), Symbol.asyncIterator)]() {
        const pushQueue = [];
        const readQueue = [];
        let done = false;
        //Catch all for passing along all events
        this.on('event', (event) => {
            const reader = readQueue.shift();
            if (reader) {
                reader.resolve(event);
            }
            else {
                pushQueue.push(event);
            }
        });
        this.on('end', () => {
            done = true;
            for (const reader of readQueue) {
                reader.resolve(undefined);
            }
            readQueue.length = 0;
        });
        this.on('abort', (err) => {
            done = true;
            for (const reader of readQueue) {
                reader.reject(err);
            }
            readQueue.length = 0;
        });
        this.on('error', (err) => {
            done = true;
            for (const reader of readQueue) {
                reader.reject(err);
            }
            readQueue.length = 0;
        });
        return {
            next: async () => {
                if (!pushQueue.length) {
                    if (done) {
                        return { value: undefined, done: true };
                    }
                    return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((chunk) => (chunk ? { value: chunk, done: false } : { value: undefined, done: true }));
                }
                const chunk = pushQueue.shift();
                return { value: chunk, done: false };
            },
            return: async () => {
                this.abort();
                return { value: undefined, done: true };
            },
        };
    }
    static fromReadableStream(stream) {
        const runner = new AssistantStream();
        runner._run(() => runner._fromReadableStream(stream));
        return runner;
    }
    async _fromReadableStream(readableStream, options) {
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        this._connected();
        const stream = Stream.fromReadableStream(readableStream, this.controller);
        for await (const event of stream) {
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_addEvent).call(this, event);
        }
        if (stream.controller.signal?.aborted) {
            throw new APIUserAbortError();
        }
        return this._addRun(AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_endRequest).call(this));
    }
    toReadableStream() {
        const stream = new Stream(this[Symbol.asyncIterator].bind(this), this.controller);
        return stream.toReadableStream();
    }
    static createToolAssistantStream(threadId, runId, runs, params, options) {
        const runner = new AssistantStream();
        runner._run(() => runner._runToolAssistantStream(threadId, runId, runs, params, {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'stream' },
        }));
        return runner;
    }
    async _createToolAssistantStream(run, threadId, runId, params, options) {
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        const body = { ...params, stream: true };
        const stream = await run.submitToolOutputs(threadId, runId, body, {
            ...options,
            signal: this.controller.signal,
        });
        this._connected();
        for await (const event of stream) {
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_addEvent).call(this, event);
        }
        if (stream.controller.signal?.aborted) {
            throw new APIUserAbortError();
        }
        return this._addRun(AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_endRequest).call(this));
    }
    static createThreadAssistantStream(params, thread, options) {
        const runner = new AssistantStream();
        runner._run(() => runner._threadAssistantStream(params, thread, {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'stream' },
        }));
        return runner;
    }
    static createAssistantStream(threadId, runs, params, options) {
        const runner = new AssistantStream();
        runner._run(() => runner._runAssistantStream(threadId, runs, params, {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'stream' },
        }));
        return runner;
    }
    currentEvent() {
        return AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentEvent, "f");
    }
    currentRun() {
        return AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentRunSnapshot, "f");
    }
    currentMessageSnapshot() {
        return AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshot, "f");
    }
    currentRunStepSnapshot() {
        return AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentRunStepSnapshot, "f");
    }
    async finalRunSteps() {
        await this.done();
        return Object.values(AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f"));
    }
    async finalMessages() {
        await this.done();
        return Object.values(AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshots, "f"));
    }
    async finalRun() {
        await this.done();
        if (!AssistantStream_classPrivateFieldGet(this, _AssistantStream_finalRun, "f"))
            throw Error('Final run was not received.');
        return AssistantStream_classPrivateFieldGet(this, _AssistantStream_finalRun, "f");
    }
    async _createThreadAssistantStream(thread, params, options) {
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        const body = { ...params, stream: true };
        const stream = await thread.createAndRun(body, { ...options, signal: this.controller.signal });
        this._connected();
        for await (const event of stream) {
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_addEvent).call(this, event);
        }
        if (stream.controller.signal?.aborted) {
            throw new APIUserAbortError();
        }
        return this._addRun(AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_endRequest).call(this));
    }
    async _createAssistantStream(run, threadId, params, options) {
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        const body = { ...params, stream: true };
        const stream = await run.create(threadId, body, { ...options, signal: this.controller.signal });
        this._connected();
        for await (const event of stream) {
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_addEvent).call(this, event);
        }
        if (stream.controller.signal?.aborted) {
            throw new APIUserAbortError();
        }
        return this._addRun(AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_endRequest).call(this));
    }
    static accumulateDelta(acc, delta) {
        for (const [key, deltaValue] of Object.entries(delta)) {
            if (!acc.hasOwnProperty(key)) {
                acc[key] = deltaValue;
                continue;
            }
            let accValue = acc[key];
            if (accValue === null || accValue === undefined) {
                acc[key] = deltaValue;
                continue;
            }
            // We don't accumulate these special properties
            if (key === 'index' || key === 'type') {
                acc[key] = deltaValue;
                continue;
            }
            // Type-specific accumulation logic
            if (typeof accValue === 'string' && typeof deltaValue === 'string') {
                accValue += deltaValue;
            }
            else if (typeof accValue === 'number' && typeof deltaValue === 'number') {
                accValue += deltaValue;
            }
            else if (isObj(accValue) && isObj(deltaValue)) {
                accValue = this.accumulateDelta(accValue, deltaValue);
            }
            else if (Array.isArray(accValue) && Array.isArray(deltaValue)) {
                if (accValue.every((x) => typeof x === 'string' || typeof x === 'number')) {
                    accValue.push(...deltaValue); // Use spread syntax for efficient addition
                    continue;
                }
                for (const deltaEntry of deltaValue) {
                    if (!isObj(deltaEntry)) {
                        throw new Error(`Expected array delta entry to be an object but got: ${deltaEntry}`);
                    }
                    const index = deltaEntry['index'];
                    if (index == null) {
                        console.error(deltaEntry);
                        throw new Error('Expected array delta entry to have an `index` property');
                    }
                    if (typeof index !== 'number') {
                        throw new Error(`Expected array delta entry \`index\` property to be a number but got ${index}`);
                    }
                    const accEntry = accValue[index];
                    if (accEntry == null) {
                        accValue.push(deltaEntry);
                    }
                    else {
                        accValue[index] = this.accumulateDelta(accEntry, deltaEntry);
                    }
                }
                continue;
            }
            else {
                throw Error(`Unhandled record type: ${key}, deltaValue: ${deltaValue}, accValue: ${accValue}`);
            }
            acc[key] = accValue;
        }
        return acc;
    }
    _addRun(run) {
        return run;
    }
    async _threadAssistantStream(params, thread, options) {
        return await this._createThreadAssistantStream(thread, params, options);
    }
    async _runAssistantStream(threadId, runs, params, options) {
        return await this._createAssistantStream(runs, threadId, params, options);
    }
    async _runToolAssistantStream(threadId, runId, runs, params, options) {
        return await this._createToolAssistantStream(runs, threadId, runId, params, options);
    }
}
_AssistantStream_addEvent = function _AssistantStream_addEvent(event) {
    if (this.ended)
        return;
    AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentEvent, event, "f");
    AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_handleEvent).call(this, event);
    switch (event.event) {
        case 'thread.created':
            //No action on this event.
            break;
        case 'thread.run.created':
        case 'thread.run.queued':
        case 'thread.run.in_progress':
        case 'thread.run.requires_action':
        case 'thread.run.completed':
        case 'thread.run.incomplete':
        case 'thread.run.failed':
        case 'thread.run.cancelling':
        case 'thread.run.cancelled':
        case 'thread.run.expired':
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_handleRun).call(this, event);
            break;
        case 'thread.run.step.created':
        case 'thread.run.step.in_progress':
        case 'thread.run.step.delta':
        case 'thread.run.step.completed':
        case 'thread.run.step.failed':
        case 'thread.run.step.cancelled':
        case 'thread.run.step.expired':
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_handleRunStep).call(this, event);
            break;
        case 'thread.message.created':
        case 'thread.message.in_progress':
        case 'thread.message.delta':
        case 'thread.message.completed':
        case 'thread.message.incomplete':
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_handleMessage).call(this, event);
            break;
        case 'error':
            //This is included for completeness, but errors are processed in the SSE event processing so this should not occur
            throw new Error('Encountered an error event in event processing - errors should be processed earlier');
        default:
            AssistantStream_assertNever(event);
    }
}, _AssistantStream_endRequest = function _AssistantStream_endRequest() {
    if (this.ended) {
        throw new error_OpenAIError(`stream has ended, this shouldn't happen`);
    }
    if (!AssistantStream_classPrivateFieldGet(this, _AssistantStream_finalRun, "f"))
        throw Error('Final run has not been received');
    return AssistantStream_classPrivateFieldGet(this, _AssistantStream_finalRun, "f");
}, _AssistantStream_handleMessage = function _AssistantStream_handleMessage(event) {
    const [accumulatedMessage, newContent] = AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_accumulateMessage).call(this, event, AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshot, "f"));
    AssistantStream_classPrivateFieldSet(this, _AssistantStream_messageSnapshot, accumulatedMessage, "f");
    AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshots, "f")[accumulatedMessage.id] = accumulatedMessage;
    for (const content of newContent) {
        const snapshotContent = accumulatedMessage.content[content.index];
        if (snapshotContent?.type == 'text') {
            this._emit('textCreated', snapshotContent.text);
        }
    }
    switch (event.event) {
        case 'thread.message.created':
            this._emit('messageCreated', event.data);
            break;
        case 'thread.message.in_progress':
            break;
        case 'thread.message.delta':
            this._emit('messageDelta', event.data.delta, accumulatedMessage);
            if (event.data.delta.content) {
                for (const content of event.data.delta.content) {
                    //If it is text delta, emit a text delta event
                    if (content.type == 'text' && content.text) {
                        let textDelta = content.text;
                        let snapshot = accumulatedMessage.content[content.index];
                        if (snapshot && snapshot.type == 'text') {
                            this._emit('textDelta', textDelta, snapshot.text);
                        }
                        else {
                            throw Error('The snapshot associated with this text delta is not text or missing');
                        }
                    }
                    if (content.index != AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentContentIndex, "f")) {
                        //See if we have in progress content
                        if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentContent, "f")) {
                            switch (AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentContent, "f").type) {
                                case 'text':
                                    this._emit('textDone', AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentContent, "f").text, AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshot, "f"));
                                    break;
                                case 'image_file':
                                    this._emit('imageFileDone', AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentContent, "f").image_file, AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshot, "f"));
                                    break;
                            }
                        }
                        AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentContentIndex, content.index, "f");
                    }
                    AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentContent, accumulatedMessage.content[content.index], "f");
                }
            }
            break;
        case 'thread.message.completed':
        case 'thread.message.incomplete':
            //We emit the latest content we were working on on completion (including incomplete)
            if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentContentIndex, "f") !== undefined) {
                const currentContent = event.data.content[AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentContentIndex, "f")];
                if (currentContent) {
                    switch (currentContent.type) {
                        case 'image_file':
                            this._emit('imageFileDone', currentContent.image_file, AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshot, "f"));
                            break;
                        case 'text':
                            this._emit('textDone', currentContent.text, AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshot, "f"));
                            break;
                    }
                }
            }
            if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshot, "f")) {
                this._emit('messageDone', event.data);
            }
            AssistantStream_classPrivateFieldSet(this, _AssistantStream_messageSnapshot, undefined, "f");
    }
}, _AssistantStream_handleRunStep = function _AssistantStream_handleRunStep(event) {
    const accumulatedRunStep = AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_accumulateRunStep).call(this, event);
    AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentRunStepSnapshot, accumulatedRunStep, "f");
    switch (event.event) {
        case 'thread.run.step.created':
            this._emit('runStepCreated', event.data);
            break;
        case 'thread.run.step.delta':
            const delta = event.data.delta;
            if (delta.step_details &&
                delta.step_details.type == 'tool_calls' &&
                delta.step_details.tool_calls &&
                accumulatedRunStep.step_details.type == 'tool_calls') {
                for (const toolCall of delta.step_details.tool_calls) {
                    if (toolCall.index == AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCallIndex, "f")) {
                        this._emit('toolCallDelta', toolCall, accumulatedRunStep.step_details.tool_calls[toolCall.index]);
                    }
                    else {
                        if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f")) {
                            this._emit('toolCallDone', AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f"));
                        }
                        AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentToolCallIndex, toolCall.index, "f");
                        AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentToolCall, accumulatedRunStep.step_details.tool_calls[toolCall.index], "f");
                        if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f"))
                            this._emit('toolCallCreated', AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f"));
                    }
                }
            }
            this._emit('runStepDelta', event.data.delta, accumulatedRunStep);
            break;
        case 'thread.run.step.completed':
        case 'thread.run.step.failed':
        case 'thread.run.step.cancelled':
        case 'thread.run.step.expired':
            AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentRunStepSnapshot, undefined, "f");
            const details = event.data.step_details;
            if (details.type == 'tool_calls') {
                if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f")) {
                    this._emit('toolCallDone', AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f"));
                    AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentToolCall, undefined, "f");
                }
            }
            this._emit('runStepDone', event.data, accumulatedRunStep);
            break;
        case 'thread.run.step.in_progress':
            break;
    }
}, _AssistantStream_handleEvent = function _AssistantStream_handleEvent(event) {
    AssistantStream_classPrivateFieldGet(this, _AssistantStream_events, "f").push(event);
    this._emit('event', event);
}, _AssistantStream_accumulateRunStep = function _AssistantStream_accumulateRunStep(event) {
    switch (event.event) {
        case 'thread.run.step.created':
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f")[event.data.id] = event.data;
            return event.data;
        case 'thread.run.step.delta':
            let snapshot = AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f")[event.data.id];
            if (!snapshot) {
                throw Error('Received a RunStepDelta before creation of a snapshot');
            }
            let data = event.data;
            if (data.delta) {
                const accumulated = AssistantStream.accumulateDelta(snapshot, data.delta);
                AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f")[event.data.id] = accumulated;
            }
            return AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f")[event.data.id];
        case 'thread.run.step.completed':
        case 'thread.run.step.failed':
        case 'thread.run.step.cancelled':
        case 'thread.run.step.expired':
        case 'thread.run.step.in_progress':
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f")[event.data.id] = event.data;
            break;
    }
    if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f")[event.data.id])
        return AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f")[event.data.id];
    throw new Error('No snapshot available');
}, _AssistantStream_accumulateMessage = function _AssistantStream_accumulateMessage(event, snapshot) {
    let newContent = [];
    switch (event.event) {
        case 'thread.message.created':
            //On creation the snapshot is just the initial message
            return [event.data, newContent];
        case 'thread.message.delta':
            if (!snapshot) {
                throw Error('Received a delta with no existing snapshot (there should be one from message creation)');
            }
            let data = event.data;
            //If this delta does not have content, nothing to process
            if (data.delta.content) {
                for (const contentElement of data.delta.content) {
                    if (contentElement.index in snapshot.content) {
                        let currentContent = snapshot.content[contentElement.index];
                        snapshot.content[contentElement.index] = AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_accumulateContent).call(this, contentElement, currentContent);
                    }
                    else {
                        snapshot.content[contentElement.index] = contentElement;
                        // This is a new element
                        newContent.push(contentElement);
                    }
                }
            }
            return [snapshot, newContent];
        case 'thread.message.in_progress':
        case 'thread.message.completed':
        case 'thread.message.incomplete':
            //No changes on other thread events
            if (snapshot) {
                return [snapshot, newContent];
            }
            else {
                throw Error('Received thread message event with no existing snapshot');
            }
    }
    throw Error('Tried to accumulate a non-message event');
}, _AssistantStream_accumulateContent = function _AssistantStream_accumulateContent(contentElement, currentContent) {
    return AssistantStream.accumulateDelta(currentContent, contentElement);
}, _AssistantStream_handleRun = function _AssistantStream_handleRun(event) {
    AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentRunSnapshot, event.data, "f");
    switch (event.event) {
        case 'thread.run.created':
            break;
        case 'thread.run.queued':
            break;
        case 'thread.run.in_progress':
            break;
        case 'thread.run.requires_action':
        case 'thread.run.cancelled':
        case 'thread.run.failed':
        case 'thread.run.completed':
        case 'thread.run.expired':
            AssistantStream_classPrivateFieldSet(this, _AssistantStream_finalRun, event.data, "f");
            if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f")) {
                this._emit('toolCallDone', AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f"));
                AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentToolCall, undefined, "f");
            }
            break;
        case 'thread.run.cancelling':
            break;
    }
};
function AssistantStream_assertNever(_x) { }
//# sourceMappingURL=AssistantStream.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/threads/messages.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class messages_Messages extends APIResource {
    /**
     * Create a message.
     */
    create(threadId, body, options) {
        return this._client.post(`/threads/${threadId}/messages`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Retrieve a message.
     */
    retrieve(threadId, messageId, options) {
        return this._client.get(`/threads/${threadId}/messages/${messageId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Modifies a message.
     */
    update(threadId, messageId, body, options) {
        return this._client.post(`/threads/${threadId}/messages/${messageId}`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    list(threadId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(threadId, {}, query);
        }
        return this._client.getAPIList(`/threads/${threadId}/messages`, MessagesPage, {
            query,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Deletes a message.
     */
    del(threadId, messageId, options) {
        return this._client.delete(`/threads/${threadId}/messages/${messageId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
}
class MessagesPage extends CursorPage {
}
messages_Messages.MessagesPage = MessagesPage;
//# sourceMappingURL=messages.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/threads/runs/steps.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class Steps extends APIResource {
    retrieve(threadId, runId, stepId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.retrieve(threadId, runId, stepId, {}, query);
        }
        return this._client.get(`/threads/${threadId}/runs/${runId}/steps/${stepId}`, {
            query,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    list(threadId, runId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(threadId, runId, {}, query);
        }
        return this._client.getAPIList(`/threads/${threadId}/runs/${runId}/steps`, RunStepsPage, {
            query,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
}
class RunStepsPage extends CursorPage {
}
Steps.RunStepsPage = RunStepsPage;
//# sourceMappingURL=steps.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/threads/runs/runs.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.







class Runs extends APIResource {
    constructor() {
        super(...arguments);
        this.steps = new Steps(this._client);
    }
    create(threadId, params, options) {
        const { include, ...body } = params;
        return this._client.post(`/threads/${threadId}/runs`, {
            query: { include },
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
            stream: params.stream ?? false,
        });
    }
    /**
     * Retrieves a run.
     */
    retrieve(threadId, runId, options) {
        return this._client.get(`/threads/${threadId}/runs/${runId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Modifies a run.
     */
    update(threadId, runId, body, options) {
        return this._client.post(`/threads/${threadId}/runs/${runId}`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    list(threadId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(threadId, {}, query);
        }
        return this._client.getAPIList(`/threads/${threadId}/runs`, RunsPage, {
            query,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Cancels a run that is `in_progress`.
     */
    cancel(threadId, runId, options) {
        return this._client.post(`/threads/${threadId}/runs/${runId}/cancel`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * A helper to create a run an poll for a terminal state. More information on Run
     * lifecycles can be found here:
     * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
     */
    async createAndPoll(threadId, body, options) {
        const run = await this.create(threadId, body, options);
        return await this.poll(threadId, run.id, options);
    }
    /**
     * Create a Run stream
     *
     * @deprecated use `stream` instead
     */
    createAndStream(threadId, body, options) {
        return AssistantStream.createAssistantStream(threadId, this._client.beta.threads.runs, body, options);
    }
    /**
     * A helper to poll a run status until it reaches a terminal state. More
     * information on Run lifecycles can be found here:
     * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
     */
    async poll(threadId, runId, options) {
        const headers = { ...options?.headers, 'X-Stainless-Poll-Helper': 'true' };
        if (options?.pollIntervalMs) {
            headers['X-Stainless-Custom-Poll-Interval'] = options.pollIntervalMs.toString();
        }
        while (true) {
            const { data: run, response } = await this.retrieve(threadId, runId, {
                ...options,
                headers: { ...options?.headers, ...headers },
            }).withResponse();
            switch (run.status) {
                //If we are in any sort of intermediate state we poll
                case 'queued':
                case 'in_progress':
                case 'cancelling':
                    let sleepInterval = 5000;
                    if (options?.pollIntervalMs) {
                        sleepInterval = options.pollIntervalMs;
                    }
                    else {
                        const headerInterval = response.headers.get('openai-poll-after-ms');
                        if (headerInterval) {
                            const headerIntervalMs = parseInt(headerInterval);
                            if (!isNaN(headerIntervalMs)) {
                                sleepInterval = headerIntervalMs;
                            }
                        }
                    }
                    await sleep(sleepInterval);
                    break;
                //We return the run in any terminal state.
                case 'requires_action':
                case 'incomplete':
                case 'cancelled':
                case 'completed':
                case 'failed':
                case 'expired':
                    return run;
            }
        }
    }
    /**
     * Create a Run stream
     */
    stream(threadId, body, options) {
        return AssistantStream.createAssistantStream(threadId, this._client.beta.threads.runs, body, options);
    }
    submitToolOutputs(threadId, runId, body, options) {
        return this._client.post(`/threads/${threadId}/runs/${runId}/submit_tool_outputs`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
            stream: body.stream ?? false,
        });
    }
    /**
     * A helper to submit a tool output to a run and poll for a terminal run state.
     * More information on Run lifecycles can be found here:
     * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
     */
    async submitToolOutputsAndPoll(threadId, runId, body, options) {
        const run = await this.submitToolOutputs(threadId, runId, body, options);
        return await this.poll(threadId, run.id, options);
    }
    /**
     * Submit the tool outputs from a previous run and stream the run to a terminal
     * state. More information on Run lifecycles can be found here:
     * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
     */
    submitToolOutputsStream(threadId, runId, body, options) {
        return AssistantStream.createToolAssistantStream(threadId, runId, this._client.beta.threads.runs, body, options);
    }
}
class RunsPage extends CursorPage {
}
Runs.RunsPage = RunsPage;
Runs.Steps = Steps;
Runs.RunStepsPage = RunStepsPage;
//# sourceMappingURL=runs.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/threads/threads.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.







class Threads extends APIResource {
    constructor() {
        super(...arguments);
        this.runs = new Runs(this._client);
        this.messages = new messages_Messages(this._client);
    }
    create(body = {}, options) {
        if (isRequestOptions(body)) {
            return this.create({}, body);
        }
        return this._client.post('/threads', {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Retrieves a thread.
     */
    retrieve(threadId, options) {
        return this._client.get(`/threads/${threadId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Modifies a thread.
     */
    update(threadId, body, options) {
        return this._client.post(`/threads/${threadId}`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Delete a thread.
     */
    del(threadId, options) {
        return this._client.delete(`/threads/${threadId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    createAndRun(body, options) {
        return this._client.post('/threads/runs', {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
            stream: body.stream ?? false,
        });
    }
    /**
     * A helper to create a thread, start a run and then poll for a terminal state.
     * More information on Run lifecycles can be found here:
     * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
     */
    async createAndRunPoll(body, options) {
        const run = await this.createAndRun(body, options);
        return await this.runs.poll(run.thread_id, run.id, options);
    }
    /**
     * Create a thread and stream the run back
     */
    createAndRunStream(body, options) {
        return AssistantStream.createThreadAssistantStream(body, this._client.beta.threads, options);
    }
}
Threads.Runs = Runs;
Threads.RunsPage = RunsPage;
Threads.Messages = messages_Messages;
Threads.MessagesPage = MessagesPage;
//# sourceMappingURL=threads.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/beta.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.









class Beta extends APIResource {
    constructor() {
        super(...arguments);
        this.realtime = new Realtime(this._client);
        this.chat = new chat_Chat(this._client);
        this.assistants = new Assistants(this._client);
        this.threads = new Threads(this._client);
    }
}
Beta.Realtime = Realtime;
Beta.Assistants = Assistants;
Beta.AssistantsPage = AssistantsPage;
Beta.Threads = Threads;
//# sourceMappingURL=beta.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/batches.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class Batches extends APIResource {
    /**
     * Creates and executes a batch from an uploaded file of requests
     */
    create(body, options) {
        return this._client.post('/batches', { body, ...options });
    }
    /**
     * Retrieves a batch.
     */
    retrieve(batchId, options) {
        return this._client.get(`/batches/${batchId}`, options);
    }
    list(query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list({}, query);
        }
        return this._client.getAPIList('/batches', BatchesPage, { query, ...options });
    }
    /**
     * Cancels an in-progress batch. The batch will be in status `cancelling` for up to
     * 10 minutes, before changing to `cancelled`, where it will have partial results
     * (if any) available in the output file.
     */
    cancel(batchId, options) {
        return this._client.post(`/batches/${batchId}/cancel`, options);
    }
}
class BatchesPage extends CursorPage {
}
Batches.BatchesPage = BatchesPage;
//# sourceMappingURL=batches.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/uploads/parts.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class Parts extends APIResource {
    /**
     * Adds a
     * [Part](https://platform.openai.com/docs/api-reference/uploads/part-object) to an
     * [Upload](https://platform.openai.com/docs/api-reference/uploads/object) object.
     * A Part represents a chunk of bytes from the file you are trying to upload.
     *
     * Each Part can be at most 64 MB, and you can add Parts until you hit the Upload
     * maximum of 8 GB.
     *
     * It is possible to add multiple Parts in parallel. You can decide the intended
     * order of the Parts when you
     * [complete the Upload](https://platform.openai.com/docs/api-reference/uploads/complete).
     */
    create(uploadId, body, options) {
        return this._client.post(`/uploads/${uploadId}/parts`, multipartFormRequestOptions({ body, ...options }));
    }
}
//# sourceMappingURL=parts.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/uploads/uploads.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class Uploads extends APIResource {
    constructor() {
        super(...arguments);
        this.parts = new Parts(this._client);
    }
    /**
     * Creates an intermediate
     * [Upload](https://platform.openai.com/docs/api-reference/uploads/object) object
     * that you can add
     * [Parts](https://platform.openai.com/docs/api-reference/uploads/part-object) to.
     * Currently, an Upload can accept at most 8 GB in total and expires after an hour
     * after you create it.
     *
     * Once you complete the Upload, we will create a
     * [File](https://platform.openai.com/docs/api-reference/files/object) object that
     * contains all the parts you uploaded. This File is usable in the rest of our
     * platform as a regular File object.
     *
     * For certain `purpose` values, the correct `mime_type` must be specified. Please
     * refer to documentation for the
     * [supported MIME types for your use case](https://platform.openai.com/docs/assistants/tools/file-search#supported-files).
     *
     * For guidance on the proper filename extensions for each purpose, please follow
     * the documentation on
     * [creating a File](https://platform.openai.com/docs/api-reference/files/create).
     */
    create(body, options) {
        return this._client.post('/uploads', { body, ...options });
    }
    /**
     * Cancels the Upload. No Parts may be added after an Upload is cancelled.
     */
    cancel(uploadId, options) {
        return this._client.post(`/uploads/${uploadId}/cancel`, options);
    }
    /**
     * Completes the
     * [Upload](https://platform.openai.com/docs/api-reference/uploads/object).
     *
     * Within the returned Upload object, there is a nested
     * [File](https://platform.openai.com/docs/api-reference/files/object) object that
     * is ready to use in the rest of the platform.
     *
     * You can specify the order of the Parts by passing in an ordered list of the Part
     * IDs.
     *
     * The number of bytes uploaded upon completion must match the number of bytes
     * initially specified when creating the Upload object. No Parts may be added after
     * an Upload is completed.
     */
    complete(uploadId, body, options) {
        return this._client.post(`/uploads/${uploadId}/complete`, { body, ...options });
    }
}
Uploads.Parts = Parts;
//# sourceMappingURL=uploads.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/ResponsesParser.mjs


function maybeParseResponse(response, params) {
    if (!params || !ResponsesParser_hasAutoParseableInput(params)) {
        return {
            ...response,
            output_parsed: null,
            output: response.output.map((item) => {
                if (item.type === 'function_call') {
                    return {
                        ...item,
                        parsed_arguments: null,
                    };
                }
                if (item.type === 'message') {
                    return {
                        ...item,
                        content: item.content.map((content) => ({
                            ...content,
                            parsed: null,
                        })),
                    };
                }
                else {
                    return item;
                }
            }),
        };
    }
    return parseResponse(response, params);
}
function parseResponse(response, params) {
    const output = response.output.map((item) => {
        if (item.type === 'function_call') {
            return {
                ...item,
                parsed_arguments: ResponsesParser_parseToolCall(params, item),
            };
        }
        if (item.type === 'message') {
            const content = item.content.map((content) => {
                if (content.type === 'output_text') {
                    return {
                        ...content,
                        parsed: parseTextFormat(params, content.text),
                    };
                }
                return content;
            });
            return {
                ...item,
                content,
            };
        }
        return item;
    });
    const parsed = Object.assign({}, response, { output });
    if (!Object.getOwnPropertyDescriptor(response, 'output_text')) {
        addOutputText(parsed);
    }
    Object.defineProperty(parsed, 'output_parsed', {
        enumerable: true,
        get() {
            for (const output of parsed.output) {
                if (output.type !== 'message') {
                    continue;
                }
                for (const content of output.content) {
                    if (content.type === 'output_text' && content.parsed !== null) {
                        return content.parsed;
                    }
                }
            }
            return null;
        },
    });
    return parsed;
}
function parseTextFormat(params, content) {
    if (params.text?.format?.type !== 'json_schema') {
        return null;
    }
    if ('$parseRaw' in params.text?.format) {
        const text_format = params.text?.format;
        return text_format.$parseRaw(content);
    }
    return JSON.parse(content);
}
function ResponsesParser_hasAutoParseableInput(params) {
    if (isAutoParsableResponseFormat(params.text?.format)) {
        return true;
    }
    return false;
}
function makeParseableResponseTool(tool, { parser, callback, }) {
    const obj = { ...tool };
    Object.defineProperties(obj, {
        $brand: {
            value: 'auto-parseable-tool',
            enumerable: false,
        },
        $parseRaw: {
            value: parser,
            enumerable: false,
        },
        $callback: {
            value: callback,
            enumerable: false,
        },
    });
    return obj;
}
function ResponsesParser_isAutoParsableTool(tool) {
    return tool?.['$brand'] === 'auto-parseable-tool';
}
function getInputToolByName(input_tools, name) {
    return input_tools.find((tool) => tool.type === 'function' && tool.name === name);
}
function ResponsesParser_parseToolCall(params, toolCall) {
    const inputTool = getInputToolByName(params.tools ?? [], toolCall.name);
    return {
        ...toolCall,
        ...toolCall,
        parsed_arguments: ResponsesParser_isAutoParsableTool(inputTool) ? inputTool.$parseRaw(toolCall.arguments)
            : inputTool?.strict ? JSON.parse(toolCall.arguments)
                : null,
    };
}
function ResponsesParser_shouldParseToolCall(params, toolCall) {
    if (!params) {
        return false;
    }
    const inputTool = getInputToolByName(params.tools ?? [], toolCall.name);
    return ResponsesParser_isAutoParsableTool(inputTool) || inputTool?.strict || false;
}
function ResponsesParser_validateInputTools(tools) {
    for (const tool of tools ?? []) {
        if (tool.type !== 'function') {
            throw new OpenAIError(`Currently only \`function\` tool types support auto-parsing; Received \`${tool.type}\``);
        }
        if (tool.function.strict !== true) {
            throw new OpenAIError(`The \`${tool.function.name}\` tool is not marked with \`strict: true\`. Only strict function tools can be auto-parsed`);
        }
    }
}
function addOutputText(rsp) {
    const texts = [];
    for (const output of rsp.output) {
        if (output.type !== 'message') {
            continue;
        }
        for (const content of output.content) {
            if (content.type === 'output_text') {
                texts.push(content.text);
            }
        }
    }
    rsp.output_text = texts.join('');
}
//# sourceMappingURL=ResponsesParser.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/responses/input-items.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class InputItems extends APIResource {
    list(responseId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(responseId, {}, query);
        }
        return this._client.getAPIList(`/responses/${responseId}/input_items`, ResponseItemsPage, {
            query,
            ...options,
        });
    }
}

//# sourceMappingURL=input-items.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/responses/ResponseStream.mjs
var ResponseStream_classPrivateFieldSet = (undefined && undefined.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var ResponseStream_classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _ResponseStream_instances, _ResponseStream_params, _ResponseStream_currentResponseSnapshot, _ResponseStream_finalResponse, _ResponseStream_beginRequest, _ResponseStream_addEvent, _ResponseStream_endRequest, _ResponseStream_accumulateResponse;



class ResponseStream extends EventStream {
    constructor(params) {
        super();
        _ResponseStream_instances.add(this);
        _ResponseStream_params.set(this, void 0);
        _ResponseStream_currentResponseSnapshot.set(this, void 0);
        _ResponseStream_finalResponse.set(this, void 0);
        ResponseStream_classPrivateFieldSet(this, _ResponseStream_params, params, "f");
    }
    static createResponse(client, params, options) {
        const runner = new ResponseStream(params);
        runner._run(() => runner._createResponse(client, params, {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'stream' },
        }));
        return runner;
    }
    async _createResponse(client, params, options) {
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        ResponseStream_classPrivateFieldGet(this, _ResponseStream_instances, "m", _ResponseStream_beginRequest).call(this);
        const stream = await client.responses.create({ ...params, stream: true }, { ...options, signal: this.controller.signal });
        this._connected();
        for await (const event of stream) {
            ResponseStream_classPrivateFieldGet(this, _ResponseStream_instances, "m", _ResponseStream_addEvent).call(this, event);
        }
        if (stream.controller.signal?.aborted) {
            throw new APIUserAbortError();
        }
        return ResponseStream_classPrivateFieldGet(this, _ResponseStream_instances, "m", _ResponseStream_endRequest).call(this);
    }
    [(_ResponseStream_params = new WeakMap(), _ResponseStream_currentResponseSnapshot = new WeakMap(), _ResponseStream_finalResponse = new WeakMap(), _ResponseStream_instances = new WeakSet(), _ResponseStream_beginRequest = function _ResponseStream_beginRequest() {
        if (this.ended)
            return;
        ResponseStream_classPrivateFieldSet(this, _ResponseStream_currentResponseSnapshot, undefined, "f");
    }, _ResponseStream_addEvent = function _ResponseStream_addEvent(event) {
        if (this.ended)
            return;
        const response = ResponseStream_classPrivateFieldGet(this, _ResponseStream_instances, "m", _ResponseStream_accumulateResponse).call(this, event);
        this._emit('event', event);
        switch (event.type) {
            case 'response.output_text.delta': {
                const output = response.output[event.output_index];
                if (!output) {
                    throw new error_OpenAIError(`missing output at index ${event.output_index}`);
                }
                if (output.type === 'message') {
                    const content = output.content[event.content_index];
                    if (!content) {
                        throw new error_OpenAIError(`missing content at index ${event.content_index}`);
                    }
                    if (content.type !== 'output_text') {
                        throw new error_OpenAIError(`expected content to be 'output_text', got ${content.type}`);
                    }
                    this._emit('response.output_text.delta', {
                        ...event,
                        snapshot: content.text,
                    });
                }
                break;
            }
            case 'response.function_call_arguments.delta': {
                const output = response.output[event.output_index];
                if (!output) {
                    throw new error_OpenAIError(`missing output at index ${event.output_index}`);
                }
                if (output.type === 'function_call') {
                    this._emit('response.function_call_arguments.delta', {
                        ...event,
                        snapshot: output.arguments,
                    });
                }
                break;
            }
            default:
                // @ts-ignore
                this._emit(event.type, event);
                break;
        }
    }, _ResponseStream_endRequest = function _ResponseStream_endRequest() {
        if (this.ended) {
            throw new error_OpenAIError(`stream has ended, this shouldn't happen`);
        }
        const snapshot = ResponseStream_classPrivateFieldGet(this, _ResponseStream_currentResponseSnapshot, "f");
        if (!snapshot) {
            throw new error_OpenAIError(`request ended without sending any events`);
        }
        ResponseStream_classPrivateFieldSet(this, _ResponseStream_currentResponseSnapshot, undefined, "f");
        const parsedResponse = finalizeResponse(snapshot, ResponseStream_classPrivateFieldGet(this, _ResponseStream_params, "f"));
        ResponseStream_classPrivateFieldSet(this, _ResponseStream_finalResponse, parsedResponse, "f");
        return parsedResponse;
    }, _ResponseStream_accumulateResponse = function _ResponseStream_accumulateResponse(event) {
        let snapshot = ResponseStream_classPrivateFieldGet(this, _ResponseStream_currentResponseSnapshot, "f");
        if (!snapshot) {
            if (event.type !== 'response.created') {
                throw new error_OpenAIError(`When snapshot hasn't been set yet, expected 'response.created' event, got ${event.type}`);
            }
            snapshot = ResponseStream_classPrivateFieldSet(this, _ResponseStream_currentResponseSnapshot, event.response, "f");
            return snapshot;
        }
        switch (event.type) {
            case 'response.output_item.added': {
                snapshot.output.push(event.item);
                break;
            }
            case 'response.content_part.added': {
                const output = snapshot.output[event.output_index];
                if (!output) {
                    throw new error_OpenAIError(`missing output at index ${event.output_index}`);
                }
                if (output.type === 'message') {
                    output.content.push(event.part);
                }
                break;
            }
            case 'response.output_text.delta': {
                const output = snapshot.output[event.output_index];
                if (!output) {
                    throw new error_OpenAIError(`missing output at index ${event.output_index}`);
                }
                if (output.type === 'message') {
                    const content = output.content[event.content_index];
                    if (!content) {
                        throw new error_OpenAIError(`missing content at index ${event.content_index}`);
                    }
                    if (content.type !== 'output_text') {
                        throw new error_OpenAIError(`expected content to be 'output_text', got ${content.type}`);
                    }
                    content.text += event.delta;
                }
                break;
            }
            case 'response.function_call_arguments.delta': {
                const output = snapshot.output[event.output_index];
                if (!output) {
                    throw new error_OpenAIError(`missing output at index ${event.output_index}`);
                }
                if (output.type === 'function_call') {
                    output.arguments += event.delta;
                }
                break;
            }
            case 'response.completed': {
                ResponseStream_classPrivateFieldSet(this, _ResponseStream_currentResponseSnapshot, event.response, "f");
                break;
            }
        }
        return snapshot;
    }, Symbol.asyncIterator)]() {
        const pushQueue = [];
        const readQueue = [];
        let done = false;
        this.on('event', (event) => {
            const reader = readQueue.shift();
            if (reader) {
                reader.resolve(event);
            }
            else {
                pushQueue.push(event);
            }
        });
        this.on('end', () => {
            done = true;
            for (const reader of readQueue) {
                reader.resolve(undefined);
            }
            readQueue.length = 0;
        });
        this.on('abort', (err) => {
            done = true;
            for (const reader of readQueue) {
                reader.reject(err);
            }
            readQueue.length = 0;
        });
        this.on('error', (err) => {
            done = true;
            for (const reader of readQueue) {
                reader.reject(err);
            }
            readQueue.length = 0;
        });
        return {
            next: async () => {
                if (!pushQueue.length) {
                    if (done) {
                        return { value: undefined, done: true };
                    }
                    return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((event) => (event ? { value: event, done: false } : { value: undefined, done: true }));
                }
                const event = pushQueue.shift();
                return { value: event, done: false };
            },
            return: async () => {
                this.abort();
                return { value: undefined, done: true };
            },
        };
    }
    /**
     * @returns a promise that resolves with the final Response, or rejects
     * if an error occurred or the stream ended prematurely without producing a REsponse.
     */
    async finalResponse() {
        await this.done();
        const response = ResponseStream_classPrivateFieldGet(this, _ResponseStream_finalResponse, "f");
        if (!response)
            throw new error_OpenAIError('stream ended without producing a ChatCompletion');
        return response;
    }
}
function finalizeResponse(snapshot, params) {
    return maybeParseResponse(snapshot, params);
}
//# sourceMappingURL=ResponseStream.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/responses/responses.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.







class Responses extends APIResource {
    constructor() {
        super(...arguments);
        this.inputItems = new InputItems(this._client);
    }
    create(body, options) {
        return this._client.post('/responses', { body, ...options, stream: body.stream ?? false })._thenUnwrap((rsp) => {
            if ('object' in rsp && rsp.object === 'response') {
                addOutputText(rsp);
            }
            return rsp;
        });
    }
    retrieve(responseId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.retrieve(responseId, {}, query);
        }
        return this._client.get(`/responses/${responseId}`, { query, ...options });
    }
    /**
     * Deletes a model response with the given ID.
     */
    del(responseId, options) {
        return this._client.delete(`/responses/${responseId}`, {
            ...options,
            headers: { Accept: '*/*', ...options?.headers },
        });
    }
    parse(body, options) {
        return this._client.responses
            .create(body, options)
            ._thenUnwrap((response) => parseResponse(response, body));
    }
    /**
     * Creates a chat completion stream
     */
    stream(body, options) {
        return ResponseStream.createResponse(this._client, body, options);
    }
}
class ResponseItemsPage extends CursorPage {
}
Responses.InputItems = InputItems;
//# sourceMappingURL=responses.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/index.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
var _a;





















/**
 * API Client for interfacing with the OpenAI API.
 */
class openai_OpenAI extends APIClient {
    /**
     * API Client for interfacing with the OpenAI API.
     *
     * @param {string | undefined} [opts.apiKey=process.env['OPENAI_API_KEY'] ?? undefined]
     * @param {string | null | undefined} [opts.organization=process.env['OPENAI_ORG_ID'] ?? null]
     * @param {string | null | undefined} [opts.project=process.env['OPENAI_PROJECT_ID'] ?? null]
     * @param {string} [opts.baseURL=process.env['OPENAI_BASE_URL'] ?? https://api.openai.com/v1] - Override the default base URL for the API.
     * @param {number} [opts.timeout=10 minutes] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {number} [opts.httpAgent] - An HTTP agent used to manage HTTP(s) connections.
     * @param {Core.Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {Core.Headers} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Core.DefaultQuery} opts.defaultQuery - Default query parameters to include with every request to the API.
     * @param {boolean} [opts.dangerouslyAllowBrowser=false] - By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
     */
    constructor({ baseURL = readEnv('OPENAI_BASE_URL'), apiKey = readEnv('OPENAI_API_KEY'), organization = readEnv('OPENAI_ORG_ID') ?? null, project = readEnv('OPENAI_PROJECT_ID') ?? null, ...opts } = {}) {
        if (apiKey === undefined) {
            throw new error_OpenAIError("The OPENAI_API_KEY environment variable is missing or empty; either provide it, or instantiate the OpenAI client with an apiKey option, like new OpenAI({ apiKey: 'My API Key' }).");
        }
        const options = {
            apiKey,
            organization,
            project,
            ...opts,
            baseURL: baseURL || `https://api.openai.com/v1`,
        };
        if (!options.dangerouslyAllowBrowser && isRunningInBrowser()) {
            throw new error_OpenAIError("It looks like you're running in a browser-like environment.\n\nThis is disabled by default, as it risks exposing your secret API credentials to attackers.\nIf you understand the risks and have appropriate mitigations in place,\nyou can set the `dangerouslyAllowBrowser` option to `true`, e.g.,\n\nnew OpenAI({ apiKey, dangerouslyAllowBrowser: true });\n\nhttps://help.openai.com/en/articles/5112595-best-practices-for-api-key-safety\n");
        }
        super({
            baseURL: options.baseURL,
            timeout: options.timeout ?? 600000 /* 10 minutes */,
            httpAgent: options.httpAgent,
            maxRetries: options.maxRetries,
            fetch: options.fetch,
        });
        this.completions = new Completions(this);
        this.chat = new Chat(this);
        this.embeddings = new Embeddings(this);
        this.files = new Files(this);
        this.images = new Images(this);
        this.audio = new Audio(this);
        this.moderations = new Moderations(this);
        this.models = new Models(this);
        this.fineTuning = new FineTuning(this);
        this.vectorStores = new VectorStores(this);
        this.beta = new Beta(this);
        this.batches = new Batches(this);
        this.uploads = new Uploads(this);
        this.responses = new Responses(this);
        this._options = options;
        this.apiKey = apiKey;
        this.organization = organization;
        this.project = project;
    }
    defaultQuery() {
        return this._options.defaultQuery;
    }
    defaultHeaders(opts) {
        return {
            ...super.defaultHeaders(opts),
            'OpenAI-Organization': this.organization,
            'OpenAI-Project': this.project,
            ...this._options.defaultHeaders,
        };
    }
    authHeaders(opts) {
        return { Authorization: `Bearer ${this.apiKey}` };
    }
    stringifyQuery(query) {
        return stringify(query, { arrayFormat: 'brackets' });
    }
}
_a = openai_OpenAI;
openai_OpenAI.OpenAI = _a;
openai_OpenAI.DEFAULT_TIMEOUT = 600000; // 10 minutes
openai_OpenAI.OpenAIError = error_OpenAIError;
openai_OpenAI.APIError = APIError;
openai_OpenAI.APIConnectionError = APIConnectionError;
openai_OpenAI.APIConnectionTimeoutError = APIConnectionTimeoutError;
openai_OpenAI.APIUserAbortError = APIUserAbortError;
openai_OpenAI.NotFoundError = NotFoundError;
openai_OpenAI.ConflictError = ConflictError;
openai_OpenAI.RateLimitError = RateLimitError;
openai_OpenAI.BadRequestError = BadRequestError;
openai_OpenAI.AuthenticationError = AuthenticationError;
openai_OpenAI.InternalServerError = InternalServerError;
openai_OpenAI.PermissionDeniedError = PermissionDeniedError;
openai_OpenAI.UnprocessableEntityError = UnprocessableEntityError;
openai_OpenAI.toFile = toFile;
openai_OpenAI.fileFromPath = fileFromPath;
openai_OpenAI.Completions = Completions;
openai_OpenAI.Chat = Chat;
openai_OpenAI.ChatCompletionsPage = ChatCompletionsPage;
openai_OpenAI.Embeddings = Embeddings;
openai_OpenAI.Files = Files;
openai_OpenAI.FileObjectsPage = FileObjectsPage;
openai_OpenAI.Images = Images;
openai_OpenAI.Audio = Audio;
openai_OpenAI.Moderations = Moderations;
openai_OpenAI.Models = Models;
openai_OpenAI.ModelsPage = ModelsPage;
openai_OpenAI.FineTuning = FineTuning;
openai_OpenAI.VectorStores = VectorStores;
openai_OpenAI.VectorStoresPage = VectorStoresPage;
openai_OpenAI.VectorStoreSearchResponsesPage = VectorStoreSearchResponsesPage;
openai_OpenAI.Beta = Beta;
openai_OpenAI.Batches = Batches;
openai_OpenAI.BatchesPage = BatchesPage;
openai_OpenAI.Uploads = Uploads;
openai_OpenAI.Responses = Responses;
/** API Client for interfacing with the Azure OpenAI API. */
class AzureOpenAI extends openai_OpenAI {
    /**
     * API Client for interfacing with the Azure OpenAI API.
     *
     * @param {string | undefined} [opts.apiVersion=process.env['OPENAI_API_VERSION'] ?? undefined]
     * @param {string | undefined} [opts.endpoint=process.env['AZURE_OPENAI_ENDPOINT'] ?? undefined] - Your Azure endpoint, including the resource, e.g. `https://example-resource.azure.openai.com/`
     * @param {string | undefined} [opts.apiKey=process.env['AZURE_OPENAI_API_KEY'] ?? undefined]
     * @param {string | undefined} opts.deployment - A model deployment, if given, sets the base client URL to include `/deployments/{deployment}`.
     * @param {string | null | undefined} [opts.organization=process.env['OPENAI_ORG_ID'] ?? null]
     * @param {string} [opts.baseURL=process.env['OPENAI_BASE_URL']] - Sets the base URL for the API, e.g. `https://example-resource.azure.openai.com/openai/`.
     * @param {number} [opts.timeout=10 minutes] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {number} [opts.httpAgent] - An HTTP agent used to manage HTTP(s) connections.
     * @param {Core.Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {Core.Headers} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Core.DefaultQuery} opts.defaultQuery - Default query parameters to include with every request to the API.
     * @param {boolean} [opts.dangerouslyAllowBrowser=false] - By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
     */
    constructor({ baseURL = readEnv('OPENAI_BASE_URL'), apiKey = readEnv('AZURE_OPENAI_API_KEY'), apiVersion = readEnv('OPENAI_API_VERSION'), endpoint, deployment, azureADTokenProvider, dangerouslyAllowBrowser, ...opts } = {}) {
        if (!apiVersion) {
            throw new error_OpenAIError("The OPENAI_API_VERSION environment variable is missing or empty; either provide it, or instantiate the AzureOpenAI client with an apiVersion option, like new AzureOpenAI({ apiVersion: 'My API Version' }).");
        }
        if (typeof azureADTokenProvider === 'function') {
            dangerouslyAllowBrowser = true;
        }
        if (!azureADTokenProvider && !apiKey) {
            throw new error_OpenAIError('Missing credentials. Please pass one of `apiKey` and `azureADTokenProvider`, or set the `AZURE_OPENAI_API_KEY` environment variable.');
        }
        if (azureADTokenProvider && apiKey) {
            throw new error_OpenAIError('The `apiKey` and `azureADTokenProvider` arguments are mutually exclusive; only one can be passed at a time.');
        }
        // define a sentinel value to avoid any typing issues
        apiKey ?? (apiKey = API_KEY_SENTINEL);
        opts.defaultQuery = { ...opts.defaultQuery, 'api-version': apiVersion };
        if (!baseURL) {
            if (!endpoint) {
                endpoint = {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}['AZURE_OPENAI_ENDPOINT'];
            }
            if (!endpoint) {
                throw new error_OpenAIError('Must provide one of the `baseURL` or `endpoint` arguments, or the `AZURE_OPENAI_ENDPOINT` environment variable');
            }
            baseURL = `${endpoint}/openai`;
        }
        else {
            if (endpoint) {
                throw new error_OpenAIError('baseURL and endpoint are mutually exclusive');
            }
        }
        super({
            apiKey,
            baseURL,
            ...opts,
            ...(dangerouslyAllowBrowser !== undefined ? { dangerouslyAllowBrowser } : {}),
        });
        this.apiVersion = '';
        this._azureADTokenProvider = azureADTokenProvider;
        this.apiVersion = apiVersion;
        this.deploymentName = deployment;
    }
    buildRequest(options, props = {}) {
        if (_deployments_endpoints.has(options.path) && options.method === 'post' && options.body !== undefined) {
            if (!isObj(options.body)) {
                throw new Error('Expected request body to be an object');
            }
            const model = this.deploymentName || options.body['model'] || options.__metadata?.['model'];
            if (model !== undefined && !this.baseURL.includes('/deployments')) {
                options.path = `/deployments/${model}${options.path}`;
            }
        }
        return super.buildRequest(options, props);
    }
    async _getAzureADToken() {
        if (typeof this._azureADTokenProvider === 'function') {
            const token = await this._azureADTokenProvider();
            if (!token || typeof token !== 'string') {
                throw new error_OpenAIError(`Expected 'azureADTokenProvider' argument to return a string but it returned ${token}`);
            }
            return token;
        }
        return undefined;
    }
    authHeaders(opts) {
        return {};
    }
    async prepareOptions(opts) {
        /**
         * The user should provide a bearer token provider if they want
         * to use Azure AD authentication. The user shouldn't set the
         * Authorization header manually because the header is overwritten
         * with the Azure AD token if a bearer token provider is provided.
         */
        if (opts.headers?.['api-key']) {
            return super.prepareOptions(opts);
        }
        const token = await this._getAzureADToken();
        opts.headers ?? (opts.headers = {});
        if (token) {
            opts.headers['Authorization'] = `Bearer ${token}`;
        }
        else if (this.apiKey !== API_KEY_SENTINEL) {
            opts.headers['api-key'] = this.apiKey;
        }
        else {
            throw new error_OpenAIError('Unable to handle auth');
        }
        return super.prepareOptions(opts);
    }
}
const _deployments_endpoints = new Set([
    '/completions',
    '/chat/completions',
    '/embeddings',
    '/audio/transcriptions',
    '/audio/translations',
    '/audio/speech',
    '/images/generations',
]);
const API_KEY_SENTINEL = '<Missing Key>';


/* harmony default export */ const node_modules_openai = (openai_OpenAI);
//# sourceMappingURL=index.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/version.mjs
const version_VERSION = '0.15.0'; // x-release-please-version
//# sourceMappingURL=version.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/_shims/registry.mjs
let registry_auto = false;
let registry_kind = undefined;
let _shims_registry_fetch = undefined;
let _shims_registry_Request = (/* unused pure expression or super */ null && (undefined));
let _shims_registry_Response = (/* unused pure expression or super */ null && (undefined));
let _shims_registry_Headers = (/* unused pure expression or super */ null && (undefined));
let _shims_registry_FormData = undefined;
let _shims_registry_Blob = (/* unused pure expression or super */ null && (undefined));
let _shims_registry_File = undefined;
let _shims_registry_ReadableStream = undefined;
let _shims_registry_getMultipartRequestOptions = undefined;
let registry_getDefaultAgent = undefined;
let registry_fileFromPath = undefined;
let registry_isFsReadStream = undefined;
function registry_setShims(shims, options = { auto: false }) {
    if (registry_auto) {
        throw new Error(`you must \`import 'groq-sdk/shims/${shims.kind}'\` before importing anything else from groq-sdk`);
    }
    if (registry_kind) {
        throw new Error(`can't \`import 'groq-sdk/shims/${shims.kind}'\` after \`import 'groq-sdk/shims/${registry_kind}'\``);
    }
    registry_auto = options.auto;
    registry_kind = shims.kind;
    _shims_registry_fetch = shims.fetch;
    _shims_registry_Request = shims.Request;
    _shims_registry_Response = shims.Response;
    _shims_registry_Headers = shims.Headers;
    _shims_registry_FormData = shims.FormData;
    _shims_registry_Blob = shims.Blob;
    _shims_registry_File = shims.File;
    _shims_registry_ReadableStream = shims.ReadableStream;
    _shims_registry_getMultipartRequestOptions = shims.getMultipartRequestOptions;
    registry_getDefaultAgent = shims.getDefaultAgent;
    registry_fileFromPath = shims.fileFromPath;
    registry_isFsReadStream = shims.isFsReadStream;
}
//# sourceMappingURL=registry.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/_shims/MultipartBody.mjs
/**
 * Disclaimer: modules in _shims aren't intended to be imported by SDK users.
 */
class MultipartBody_MultipartBody {
    constructor(body) {
        this.body = body;
    }
    get [Symbol.toStringTag]() {
        return 'MultipartBody';
    }
}
//# sourceMappingURL=MultipartBody.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/_shims/web-runtime.mjs

function web_runtime_getRuntime({ manuallyImported } = {}) {
    const recommendation = manuallyImported ?
        `You may need to use polyfills`
        : `Add one of these imports before your first \`import … from 'groq-sdk'\`:
- \`import 'groq-sdk/shims/node'\` (if you're running on Node)
- \`import 'groq-sdk/shims/web'\` (otherwise)
`;
    let _fetch, _Request, _Response, _Headers;
    try {
        // @ts-ignore
        _fetch = fetch;
        // @ts-ignore
        _Request = Request;
        // @ts-ignore
        _Response = Response;
        // @ts-ignore
        _Headers = Headers;
    }
    catch (error) {
        throw new Error(`this environment is missing the following Web Fetch API type: ${error.message}. ${recommendation}`);
    }
    return {
        kind: 'web',
        fetch: _fetch,
        Request: _Request,
        Response: _Response,
        Headers: _Headers,
        FormData: 
        // @ts-ignore
        typeof FormData !== 'undefined' ? FormData : (class FormData {
            // @ts-ignore
            constructor() {
                throw new Error(`file uploads aren't supported in this environment yet as 'FormData' is undefined. ${recommendation}`);
            }
        }),
        Blob: typeof Blob !== 'undefined' ? Blob : (class Blob {
            constructor() {
                throw new Error(`file uploads aren't supported in this environment yet as 'Blob' is undefined. ${recommendation}`);
            }
        }),
        File: 
        // @ts-ignore
        typeof File !== 'undefined' ? File : (class File {
            // @ts-ignore
            constructor() {
                throw new Error(`file uploads aren't supported in this environment yet as 'File' is undefined. ${recommendation}`);
            }
        }),
        ReadableStream: 
        // @ts-ignore
        typeof ReadableStream !== 'undefined' ? ReadableStream : (class ReadableStream {
            // @ts-ignore
            constructor() {
                throw new Error(`streaming isn't supported in this environment yet as 'ReadableStream' is undefined. ${recommendation}`);
            }
        }),
        getMultipartRequestOptions: async (
        // @ts-ignore
        form, opts) => ({
            ...opts,
            body: new MultipartBody_MultipartBody(form),
        }),
        getDefaultAgent: (url) => undefined,
        fileFromPath: () => {
            throw new Error('The `fileFromPath` function is only supported in Node. See the README for more details: https://www.github.com/groq/groq-typescript#file-uploads');
        },
        isFsReadStream: (value) => false,
    };
}
//# sourceMappingURL=web-runtime.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/_shims/index.mjs
/**
 * Disclaimer: modules in _shims aren't intended to be imported by SDK users.
 */


if (!registry_kind) registry_setShims(web_runtime_getRuntime(), { auto: true });


;// CONCATENATED MODULE: ./node_modules/groq-sdk/error.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class error_GroqError extends Error {
}
class error_APIError extends error_GroqError {
    constructor(status, error, message, headers) {
        super(`${error_APIError.makeMessage(status, error, message)}`);
        this.status = status;
        this.headers = headers;
        this.error = error;
    }
    static makeMessage(status, error, message) {
        const msg = error?.message ?
            typeof error.message === 'string' ?
                error.message
                : JSON.stringify(error.message)
            : error ? JSON.stringify(error)
                : message;
        if (status && msg) {
            return `${status} ${msg}`;
        }
        if (status) {
            return `${status} status code (no body)`;
        }
        if (msg) {
            return msg;
        }
        return '(no status code or body)';
    }
    static generate(status, errorResponse, message, headers) {
        if (!status || !headers) {
            return new error_APIConnectionError({ message, cause: core_castToError(errorResponse) });
        }
        const error = errorResponse;
        if (status === 400) {
            return new error_BadRequestError(status, error, message, headers);
        }
        if (status === 401) {
            return new error_AuthenticationError(status, error, message, headers);
        }
        if (status === 403) {
            return new error_PermissionDeniedError(status, error, message, headers);
        }
        if (status === 404) {
            return new error_NotFoundError(status, error, message, headers);
        }
        if (status === 409) {
            return new error_ConflictError(status, error, message, headers);
        }
        if (status === 422) {
            return new error_UnprocessableEntityError(status, error, message, headers);
        }
        if (status === 429) {
            return new error_RateLimitError(status, error, message, headers);
        }
        if (status >= 500) {
            return new error_InternalServerError(status, error, message, headers);
        }
        return new error_APIError(status, error, message, headers);
    }
}
class error_APIUserAbortError extends error_APIError {
    constructor({ message } = {}) {
        super(undefined, undefined, message || 'Request was aborted.', undefined);
    }
}
class error_APIConnectionError extends error_APIError {
    constructor({ message, cause }) {
        super(undefined, undefined, message || 'Connection error.', undefined);
        // in some environments the 'cause' property is already declared
        // @ts-ignore
        if (cause)
            this.cause = cause;
    }
}
class error_APIConnectionTimeoutError extends error_APIConnectionError {
    constructor({ message } = {}) {
        super({ message: message ?? 'Request timed out.' });
    }
}
class error_BadRequestError extends error_APIError {
}
class error_AuthenticationError extends error_APIError {
}
class error_PermissionDeniedError extends error_APIError {
}
class error_NotFoundError extends error_APIError {
}
class error_ConflictError extends error_APIError {
}
class error_UnprocessableEntityError extends error_APIError {
}
class error_RateLimitError extends error_APIError {
}
class error_InternalServerError extends error_APIError {
}
//# sourceMappingURL=error.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/lib/streaming.mjs
/* provided dependency */ var streaming_Buffer = __webpack_require__(8287)["hp"];



class streaming_Stream {
    constructor(iterator, controller) {
        this.iterator = iterator;
        this.controller = controller;
    }
    static fromSSEResponse(response, controller) {
        let consumed = false;
        const decoder = new streaming_SSEDecoder();
        async function* iterMessages() {
            if (!response.body) {
                controller.abort();
                throw new error_GroqError(`Attempted to iterate over a response with no body`);
            }
            const lineDecoder = new streaming_LineDecoder();
            const iter = readableStreamAsyncIterable(response.body);
            for await (const chunk of iter) {
                for (const line of lineDecoder.decode(chunk)) {
                    const sse = decoder.decode(line);
                    if (sse)
                        yield sse;
                }
            }
            for (const line of lineDecoder.flush()) {
                const sse = decoder.decode(line);
                if (sse)
                    yield sse;
            }
        }
        async function* iterator() {
            if (consumed) {
                throw new Error('Cannot iterate over a consumed stream, use `.tee()` to split the stream.');
            }
            consumed = true;
            let done = false;
            try {
                for await (const sse of iterMessages()) {
                    if (done)
                        continue;
                    if (sse.data.startsWith('[DONE]')) {
                        done = true;
                        continue;
                    }
                    if (sse.event === null || sse.event === 'error') {
                        let data;
                        try {
                            data = JSON.parse(sse.data);
                        }
                        catch (e) {
                            console.error(`Could not parse message into JSON:`, sse.data);
                            console.error(`From chunk:`, sse.raw);
                            throw e;
                        }
                        if (data && data.error) {
                            throw new error_APIError(data.error.status_code, data.error, data.error.message, undefined);
                        }
                        yield data;
                    }
                }
                done = true;
            }
            catch (e) {
                // If the user calls `stream.controller.abort()`, we should exit without throwing.
                if (e instanceof Error && e.name === 'AbortError')
                    return;
                throw e;
            }
            finally {
                // If the user `break`s, abort the ongoing request.
                if (!done)
                    controller.abort();
            }
        }
        return new streaming_Stream(iterator, controller);
    }
    /**
     * Generates a Stream from a newline-separated ReadableStream
     * where each item is a JSON value.
     */
    static fromReadableStream(readableStream, controller) {
        let consumed = false;
        async function* iterLines() {
            const lineDecoder = new streaming_LineDecoder();
            const iter = readableStreamAsyncIterable(readableStream);
            for await (const chunk of iter) {
                for (const line of lineDecoder.decode(chunk)) {
                    yield line;
                }
            }
            for (const line of lineDecoder.flush()) {
                yield line;
            }
        }
        async function* iterator() {
            if (consumed) {
                throw new Error('Cannot iterate over a consumed stream, use `.tee()` to split the stream.');
            }
            consumed = true;
            let done = false;
            try {
                for await (const line of iterLines()) {
                    if (done)
                        continue;
                    if (line)
                        yield JSON.parse(line);
                }
                done = true;
            }
            catch (e) {
                // If the user calls `stream.controller.abort()`, we should exit without throwing.
                if (e instanceof Error && e.name === 'AbortError')
                    return;
                throw e;
            }
            finally {
                // If the user `break`s, abort the ongoing request.
                if (!done)
                    controller.abort();
            }
        }
        return new streaming_Stream(iterator, controller);
    }
    [Symbol.asyncIterator]() {
        return this.iterator();
    }
    /**
     * Splits the stream into two streams which can be
     * independently read from at different speeds.
     */
    tee() {
        const left = [];
        const right = [];
        const iterator = this.iterator();
        const teeIterator = (queue) => {
            return {
                next: () => {
                    if (queue.length === 0) {
                        const result = iterator.next();
                        left.push(result);
                        right.push(result);
                    }
                    return queue.shift();
                },
            };
        };
        return [
            new streaming_Stream(() => teeIterator(left), this.controller),
            new streaming_Stream(() => teeIterator(right), this.controller),
        ];
    }
    /**
     * Converts this stream to a newline-separated ReadableStream of
     * JSON stringified values in the stream
     * which can be turned back into a Stream with `Stream.fromReadableStream()`.
     */
    toReadableStream() {
        const self = this;
        let iter;
        const encoder = new TextEncoder();
        return new _shims_registry_ReadableStream({
            async start() {
                iter = self[Symbol.asyncIterator]();
            },
            async pull(ctrl) {
                try {
                    const { value, done } = await iter.next();
                    if (done)
                        return ctrl.close();
                    const bytes = encoder.encode(JSON.stringify(value) + '\n');
                    ctrl.enqueue(bytes);
                }
                catch (err) {
                    ctrl.error(err);
                }
            },
            async cancel() {
                await iter.return?.();
            },
        });
    }
}
class streaming_SSEDecoder {
    constructor() {
        this.event = null;
        this.data = [];
        this.chunks = [];
    }
    decode(line) {
        if (line.endsWith('\r')) {
            line = line.substring(0, line.length - 1);
        }
        if (!line) {
            // empty line and we didn't previously encounter any messages
            if (!this.event && !this.data.length)
                return null;
            const sse = {
                event: this.event,
                data: this.data.join('\n'),
                raw: this.chunks,
            };
            this.event = null;
            this.data = [];
            this.chunks = [];
            return sse;
        }
        this.chunks.push(line);
        if (line.startsWith(':')) {
            return null;
        }
        let [fieldname, _, value] = streaming_partition(line, ':');
        if (value.startsWith(' ')) {
            value = value.substring(1);
        }
        if (fieldname === 'event') {
            this.event = value;
        }
        else if (fieldname === 'data') {
            this.data.push(value);
        }
        return null;
    }
}
/**
 * A re-implementation of httpx's `LineDecoder` in Python that handles incrementally
 * reading lines from text.
 *
 * https://github.com/encode/httpx/blob/920333ea98118e9cf617f246905d7b202510941c/httpx/_decoders.py#L258
 */
class streaming_LineDecoder {
    constructor() {
        this.buffer = [];
        this.trailingCR = false;
    }
    decode(chunk) {
        let text = this.decodeText(chunk);
        if (this.trailingCR) {
            text = '\r' + text;
            this.trailingCR = false;
        }
        if (text.endsWith('\r')) {
            this.trailingCR = true;
            text = text.slice(0, -1);
        }
        if (!text) {
            return [];
        }
        const trailingNewline = streaming_LineDecoder.NEWLINE_CHARS.has(text[text.length - 1] || '');
        let lines = text.split(streaming_LineDecoder.NEWLINE_REGEXP);
        if (lines.length === 1 && !trailingNewline) {
            this.buffer.push(lines[0]);
            return [];
        }
        if (this.buffer.length > 0) {
            lines = [this.buffer.join('') + lines[0], ...lines.slice(1)];
            this.buffer = [];
        }
        if (!trailingNewline) {
            this.buffer = [lines.pop() || ''];
        }
        return lines;
    }
    decodeText(bytes) {
        if (bytes == null)
            return '';
        if (typeof bytes === 'string')
            return bytes;
        // Node:
        if (typeof streaming_Buffer !== 'undefined') {
            if (bytes instanceof streaming_Buffer) {
                return bytes.toString();
            }
            if (bytes instanceof Uint8Array) {
                return streaming_Buffer.from(bytes).toString();
            }
            throw new error_GroqError(`Unexpected: received non-Uint8Array (${bytes.constructor.name}) stream chunk in an environment with a global "Buffer" defined, which this library assumes to be Node. Please report this error.`);
        }
        // Browser
        if (typeof TextDecoder !== 'undefined') {
            if (bytes instanceof Uint8Array || bytes instanceof ArrayBuffer) {
                this.textDecoder ?? (this.textDecoder = new TextDecoder('utf8'));
                return this.textDecoder.decode(bytes);
            }
            throw new error_GroqError(`Unexpected: received non-Uint8Array/ArrayBuffer (${bytes.constructor.name}) in a web platform. Please report this error.`);
        }
        throw new error_GroqError(`Unexpected: neither Buffer nor TextDecoder are available as globals. Please report this error.`);
    }
    flush() {
        if (!this.buffer.length && !this.trailingCR) {
            return [];
        }
        const lines = [this.buffer.join('')];
        this.buffer = [];
        this.trailingCR = false;
        return lines;
    }
}
// prettier-ignore
streaming_LineDecoder.NEWLINE_CHARS = new Set(['\n', '\r', '\x0b', '\x0c', '\x1c', '\x1d', '\x1e', '\x85', '\u2028', '\u2029']);
streaming_LineDecoder.NEWLINE_REGEXP = /\r\n|[\n\r\x0b\x0c\x1c\x1d\x1e\x85\u2028\u2029]/g;
function streaming_partition(str, delimiter) {
    const index = str.indexOf(delimiter);
    if (index !== -1) {
        return [str.substring(0, index), delimiter, str.substring(index + delimiter.length)];
    }
    return [str, '', ''];
}
/**
 * Most browsers don't yet have async iterable support for ReadableStream,
 * and Node has a very different way of reading bytes from its "ReadableStream".
 *
 * This polyfill was pulled from https://github.com/MattiasBuelens/web-streams-polyfill/pull/122#issuecomment-1627354490
 */
function readableStreamAsyncIterable(stream) {
    if (stream[Symbol.asyncIterator])
        return stream;
    const reader = stream.getReader();
    return {
        async next() {
            try {
                const result = await reader.read();
                if (result?.done)
                    reader.releaseLock(); // release lock when stream becomes closed
                return result;
            }
            catch (e) {
                reader.releaseLock(); // release lock when stream becomes errored
                throw e;
            }
        },
        async return() {
            const cancelPromise = reader.cancel();
            reader.releaseLock();
            await cancelPromise;
            return { done: true, value: undefined };
        },
        [Symbol.asyncIterator]() {
            return this;
        },
    };
}
//# sourceMappingURL=streaming.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/uploads.mjs
/* provided dependency */ var groq_sdk_uploads_Buffer = __webpack_require__(8287)["hp"];


const uploads_isResponseLike = (value) => value != null &&
    typeof value === 'object' &&
    typeof value.url === 'string' &&
    typeof value.blob === 'function';
const uploads_isFileLike = (value) => value != null &&
    typeof value === 'object' &&
    typeof value.name === 'string' &&
    typeof value.lastModified === 'number' &&
    uploads_isBlobLike(value);
/**
 * The BlobLike type omits arrayBuffer() because @types/node-fetch@^2.6.4 lacks it; but this check
 * adds the arrayBuffer() method type because it is available and used at runtime
 */
const uploads_isBlobLike = (value) => value != null &&
    typeof value === 'object' &&
    typeof value.size === 'number' &&
    typeof value.type === 'string' &&
    typeof value.text === 'function' &&
    typeof value.slice === 'function' &&
    typeof value.arrayBuffer === 'function';
const uploads_isUploadable = (value) => {
    return uploads_isFileLike(value) || uploads_isResponseLike(value) || registry_isFsReadStream(value);
};
/**
 * Helper for creating a {@link File} to pass to an SDK upload method from a variety of different data formats
 * @param value the raw content of the file.  Can be an {@link Uploadable}, {@link BlobLikePart}, or {@link AsyncIterable} of {@link BlobLikePart}s
 * @param {string=} name the name of the file. If omitted, toFile will try to determine a file name from bits if possible
 * @param {Object=} options additional properties
 * @param {string=} options.type the MIME type of the content
 * @param {number=} options.lastModified the last modified timestamp
 * @returns a {@link File} with the given properties
 */
async function uploads_toFile(value, name, options) {
    // If it's a promise, resolve it.
    value = await value;
    // If we've been given a `File` we don't need to do anything
    if (uploads_isFileLike(value)) {
        return value;
    }
    if (uploads_isResponseLike(value)) {
        const blob = await value.blob();
        name || (name = new URL(value.url).pathname.split(/[\\/]/).pop() ?? 'unknown_file');
        // we need to convert the `Blob` into an array buffer because the `Blob` class
        // that `node-fetch` defines is incompatible with the web standard which results
        // in `new File` interpreting it as a string instead of binary data.
        const data = uploads_isBlobLike(blob) ? [(await blob.arrayBuffer())] : [blob];
        return new _shims_registry_File(data, name, options);
    }
    const bits = await uploads_getBytes(value);
    name || (name = uploads_getName(value) ?? 'unknown_file');
    if (!options?.type) {
        const type = bits[0]?.type;
        if (typeof type === 'string') {
            options = { ...options, type };
        }
    }
    return new _shims_registry_File(bits, name, options);
}
async function uploads_getBytes(value) {
    let parts = [];
    if (typeof value === 'string' ||
        ArrayBuffer.isView(value) || // includes Uint8Array, Buffer, etc.
        value instanceof ArrayBuffer) {
        parts.push(value);
    }
    else if (uploads_isBlobLike(value)) {
        parts.push(await value.arrayBuffer());
    }
    else if (uploads_isAsyncIterableIterator(value) // includes Readable, ReadableStream, etc.
    ) {
        for await (const chunk of value) {
            parts.push(chunk); // TODO, consider validating?
        }
    }
    else {
        throw new Error(`Unexpected data type: ${typeof value}; constructor: ${value?.constructor
            ?.name}; props: ${uploads_propsForError(value)}`);
    }
    return parts;
}
function uploads_propsForError(value) {
    const props = Object.getOwnPropertyNames(value);
    return `[${props.map((p) => `"${p}"`).join(', ')}]`;
}
function uploads_getName(value) {
    return (uploads_getStringFromMaybeBuffer(value.name) ||
        uploads_getStringFromMaybeBuffer(value.filename) ||
        // For fs.ReadStream
        uploads_getStringFromMaybeBuffer(value.path)?.split(/[\\/]/).pop());
}
const uploads_getStringFromMaybeBuffer = (x) => {
    if (typeof x === 'string')
        return x;
    if (typeof groq_sdk_uploads_Buffer !== 'undefined' && x instanceof groq_sdk_uploads_Buffer)
        return String(x);
    return undefined;
};
const uploads_isAsyncIterableIterator = (value) => value != null && typeof value === 'object' && typeof value[Symbol.asyncIterator] === 'function';
const uploads_isMultipartBody = (body) => body && typeof body === 'object' && body.body && body[Symbol.toStringTag] === 'MultipartBody';
/**
 * Returns a multipart/form-data request if any part of the given request body contains a File / Blob value.
 * Otherwise returns the request as is.
 */
const uploads_maybeMultipartFormRequestOptions = async (opts) => {
    if (!uploads_hasUploadableValue(opts.body))
        return opts;
    const form = await uploads_createForm(opts.body);
    return getMultipartRequestOptions(form, opts);
};
const uploads_multipartFormRequestOptions = async (opts) => {
    const form = await uploads_createForm(opts.body);
    return _shims_registry_getMultipartRequestOptions(form, opts);
};
const uploads_createForm = async (body) => {
    const form = new _shims_registry_FormData();
    await Promise.all(Object.entries(body || {}).map(([key, value]) => uploads_addFormValue(form, key, value)));
    return form;
};
const uploads_hasUploadableValue = (value) => {
    if (uploads_isUploadable(value))
        return true;
    if (Array.isArray(value))
        return value.some(uploads_hasUploadableValue);
    if (value && typeof value === 'object') {
        for (const k in value) {
            if (uploads_hasUploadableValue(value[k]))
                return true;
        }
    }
    return false;
};
const uploads_addFormValue = async (form, key, value) => {
    if (value === undefined)
        return;
    if (value == null) {
        throw new TypeError(`Received null for "${key}"; to pass null in FormData, you must use the string 'null'`);
    }
    // TODO: make nested formats configurable
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
        form.append(key, String(value));
    }
    else if (uploads_isUploadable(value)) {
        const file = await uploads_toFile(value);
        form.append(key, file);
    }
    else if (Array.isArray(value)) {
        await Promise.all(value.map((entry) => uploads_addFormValue(form, key + '[]', entry)));
    }
    else if (typeof value === 'object') {
        await Promise.all(Object.entries(value).map(([name, prop]) => uploads_addFormValue(form, `${key}[${name}]`, prop)));
    }
    else {
        throw new TypeError(`Invalid value given to form, expected a string, number, boolean, object, Array, File or Blob but got ${value} instead`);
    }
};
//# sourceMappingURL=uploads.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/core.mjs
/* provided dependency */ var groq_sdk_core_Buffer = __webpack_require__(8287)["hp"];
/* provided dependency */ var core_process = __webpack_require__(5606);
var groq_sdk_core_classPrivateFieldSet = (undefined && undefined.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var groq_sdk_core_classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var core_AbstractPage_client;






async function core_defaultParseResponse(props) {
    const { response } = props;
    if (props.options.stream) {
        core_debug('response', response.status, response.url, response.headers, response.body);
        // Note: there is an invariant here that isn't represented in the type system
        // that if you set `stream: true` the response type must also be `Stream<T>`
        if (props.options.__streamClass) {
            return props.options.__streamClass.fromSSEResponse(response, props.controller);
        }
        return streaming_Stream.fromSSEResponse(response, props.controller);
    }
    // fetch refuses to read the body when the status code is 204.
    if (response.status === 204) {
        return null;
    }
    if (props.options.__binaryResponse) {
        return response;
    }
    const contentType = response.headers.get('content-type');
    const isJSON = contentType?.includes('application/json') || contentType?.includes('application/vnd.api+json');
    if (isJSON) {
        const json = await response.json();
        core_debug('response', response.status, response.url, response.headers, json);
        return json;
    }
    const text = await response.text();
    core_debug('response', response.status, response.url, response.headers, text);
    // TODO handle blob, arraybuffer, other content types, etc.
    return text;
}
/**
 * A subclass of `Promise` providing additional helper methods
 * for interacting with the SDK.
 */
class core_APIPromise extends Promise {
    constructor(responsePromise, parseResponse = core_defaultParseResponse) {
        super((resolve) => {
            // this is maybe a bit weird but this has to be a no-op to not implicitly
            // parse the response body; instead .then, .catch, .finally are overridden
            // to parse the response
            resolve(null);
        });
        this.responsePromise = responsePromise;
        this.parseResponse = parseResponse;
    }
    _thenUnwrap(transform) {
        return new core_APIPromise(this.responsePromise, async (props) => transform(await this.parseResponse(props), props));
    }
    /**
     * Gets the raw `Response` instance instead of parsing the response
     * data.
     *
     * If you want to parse the response body but still get the `Response`
     * instance, you can use {@link withResponse()}.
     *
     * 👋 Getting the wrong TypeScript type for `Response`?
     * Try setting `"moduleResolution": "NodeNext"` if you can,
     * or add one of these imports before your first `import … from 'groq-sdk'`:
     * - `import 'groq-sdk/shims/node'` (if you're running on Node)
     * - `import 'groq-sdk/shims/web'` (otherwise)
     */
    asResponse() {
        return this.responsePromise.then((p) => p.response);
    }
    /**
     * Gets the parsed response data and the raw `Response` instance.
     *
     * If you just want to get the raw `Response` instance without parsing it,
     * you can use {@link asResponse()}.
     *
     *
     * 👋 Getting the wrong TypeScript type for `Response`?
     * Try setting `"moduleResolution": "NodeNext"` if you can,
     * or add one of these imports before your first `import … from 'groq-sdk'`:
     * - `import 'groq-sdk/shims/node'` (if you're running on Node)
     * - `import 'groq-sdk/shims/web'` (otherwise)
     */
    async withResponse() {
        const [data, response] = await Promise.all([this.parse(), this.asResponse()]);
        return { data, response };
    }
    parse() {
        if (!this.parsedPromise) {
            this.parsedPromise = this.responsePromise.then(this.parseResponse);
        }
        return this.parsedPromise;
    }
    then(onfulfilled, onrejected) {
        return this.parse().then(onfulfilled, onrejected);
    }
    catch(onrejected) {
        return this.parse().catch(onrejected);
    }
    finally(onfinally) {
        return this.parse().finally(onfinally);
    }
}
class core_APIClient {
    constructor({ baseURL, maxRetries = 2, timeout = 60000, // 1 minute
    httpAgent, fetch: overriddenFetch, }) {
        this.baseURL = baseURL;
        this.maxRetries = core_validatePositiveInteger('maxRetries', maxRetries);
        this.timeout = core_validatePositiveInteger('timeout', timeout);
        this.httpAgent = httpAgent;
        this.fetch = overriddenFetch ?? _shims_registry_fetch;
    }
    authHeaders(opts) {
        return {};
    }
    /**
     * Override this to add your own default headers, for example:
     *
     *  {
     *    ...super.defaultHeaders(),
     *    Authorization: 'Bearer 123',
     *  }
     */
    defaultHeaders(opts) {
        return {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            'User-Agent': this.getUserAgent(),
            ...core_getPlatformHeaders(),
            ...this.authHeaders(opts),
        };
    }
    /**
     * Override this to add your own headers validation:
     */
    validateHeaders(headers, customHeaders) { }
    defaultIdempotencyKey() {
        return `stainless-node-retry-${core_uuid4()}`;
    }
    get(path, opts) {
        return this.methodRequest('get', path, opts);
    }
    post(path, opts) {
        return this.methodRequest('post', path, opts);
    }
    patch(path, opts) {
        return this.methodRequest('patch', path, opts);
    }
    put(path, opts) {
        return this.methodRequest('put', path, opts);
    }
    delete(path, opts) {
        return this.methodRequest('delete', path, opts);
    }
    methodRequest(method, path, opts) {
        return this.request(Promise.resolve(opts).then(async (opts) => {
            const body = opts && uploads_isBlobLike(opts?.body) ? new DataView(await opts.body.arrayBuffer())
                : opts?.body instanceof DataView ? opts.body
                    : opts?.body instanceof ArrayBuffer ? new DataView(opts.body)
                        : opts && ArrayBuffer.isView(opts?.body) ? new DataView(opts.body.buffer)
                            : opts?.body;
            return { method, path, ...opts, body };
        }));
    }
    getAPIList(path, Page, opts) {
        return this.requestAPIList(Page, { method: 'get', path, ...opts });
    }
    calculateContentLength(body) {
        if (typeof body === 'string') {
            if (typeof groq_sdk_core_Buffer !== 'undefined') {
                return groq_sdk_core_Buffer.byteLength(body, 'utf8').toString();
            }
            if (typeof TextEncoder !== 'undefined') {
                const encoder = new TextEncoder();
                const encoded = encoder.encode(body);
                return encoded.length.toString();
            }
        }
        else if (ArrayBuffer.isView(body)) {
            return body.byteLength.toString();
        }
        return null;
    }
    buildRequest(options, { retryCount = 0 } = {}) {
        const { method, path, query, headers: headers = {} } = options;
        const body = ArrayBuffer.isView(options.body) || (options.__binaryRequest && typeof options.body === 'string') ?
            options.body
            : uploads_isMultipartBody(options.body) ? options.body.body
                : options.body ? JSON.stringify(options.body, null, 2)
                    : null;
        const contentLength = this.calculateContentLength(body);
        const url = this.buildURL(path, query);
        if ('timeout' in options)
            core_validatePositiveInteger('timeout', options.timeout);
        const timeout = options.timeout ?? this.timeout;
        const httpAgent = options.httpAgent ?? this.httpAgent ?? registry_getDefaultAgent(url);
        const minAgentTimeout = timeout + 1000;
        if (typeof httpAgent?.options?.timeout === 'number' &&
            minAgentTimeout > (httpAgent.options.timeout ?? 0)) {
            // Allow any given request to bump our agent active socket timeout.
            // This may seem strange, but leaking active sockets should be rare and not particularly problematic,
            // and without mutating agent we would need to create more of them.
            // This tradeoff optimizes for performance.
            httpAgent.options.timeout = minAgentTimeout;
        }
        if (this.idempotencyHeader && method !== 'get') {
            if (!options.idempotencyKey)
                options.idempotencyKey = this.defaultIdempotencyKey();
            headers[this.idempotencyHeader] = options.idempotencyKey;
        }
        const reqHeaders = this.buildHeaders({ options, headers, contentLength, retryCount });
        const req = {
            method,
            ...(body && { body: body }),
            headers: reqHeaders,
            ...(httpAgent && { agent: httpAgent }),
            // @ts-ignore node-fetch uses a custom AbortSignal type that is
            // not compatible with standard web types
            signal: options.signal ?? null,
        };
        return { req, url, timeout };
    }
    buildHeaders({ options, headers, contentLength, retryCount, }) {
        const reqHeaders = {};
        if (contentLength) {
            reqHeaders['content-length'] = contentLength;
        }
        const defaultHeaders = this.defaultHeaders(options);
        core_applyHeadersMut(reqHeaders, defaultHeaders);
        core_applyHeadersMut(reqHeaders, headers);
        // let builtin fetch set the Content-Type for multipart bodies
        if (uploads_isMultipartBody(options.body) && registry_kind !== 'node') {
            delete reqHeaders['content-type'];
        }
        // Don't set the retry count header if it was already set or removed through default headers or by the
        // caller. We check `defaultHeaders` and `headers`, which can contain nulls, instead of `reqHeaders` to
        // account for the removal case.
        if (core_getHeader(defaultHeaders, 'x-stainless-retry-count') === undefined &&
            core_getHeader(headers, 'x-stainless-retry-count') === undefined) {
            reqHeaders['x-stainless-retry-count'] = String(retryCount);
        }
        this.validateHeaders(reqHeaders, headers);
        return reqHeaders;
    }
    /**
     * Used as a callback for mutating the given `FinalRequestOptions` object.
     */
    async prepareOptions(options) { }
    /**
     * Used as a callback for mutating the given `RequestInit` object.
     *
     * This is useful for cases where you want to add certain headers based off of
     * the request properties, e.g. `method` or `url`.
     */
    async prepareRequest(request, { url, options }) { }
    parseHeaders(headers) {
        return (!headers ? {}
            : Symbol.iterator in headers ?
                Object.fromEntries(Array.from(headers).map((header) => [...header]))
                : { ...headers });
    }
    makeStatusError(status, error, message, headers) {
        return error_APIError.generate(status, error, message, headers);
    }
    request(options, remainingRetries = null) {
        return new core_APIPromise(this.makeRequest(options, remainingRetries));
    }
    async makeRequest(optionsInput, retriesRemaining) {
        const options = await optionsInput;
        const maxRetries = options.maxRetries ?? this.maxRetries;
        if (retriesRemaining == null) {
            retriesRemaining = maxRetries;
        }
        await this.prepareOptions(options);
        const { req, url, timeout } = this.buildRequest(options, { retryCount: maxRetries - retriesRemaining });
        await this.prepareRequest(req, { url, options });
        core_debug('request', url, options, req.headers);
        if (options.signal?.aborted) {
            throw new error_APIUserAbortError();
        }
        const controller = new AbortController();
        const response = await this.fetchWithTimeout(url, req, timeout, controller).catch(core_castToError);
        if (response instanceof Error) {
            if (options.signal?.aborted) {
                throw new error_APIUserAbortError();
            }
            if (retriesRemaining) {
                return this.retryRequest(options, retriesRemaining);
            }
            if (response.name === 'AbortError') {
                throw new error_APIConnectionTimeoutError();
            }
            throw new error_APIConnectionError({ cause: response });
        }
        const responseHeaders = core_createResponseHeaders(response.headers);
        if (!response.ok) {
            if (retriesRemaining && this.shouldRetry(response)) {
                const retryMessage = `retrying, ${retriesRemaining} attempts remaining`;
                core_debug(`response (error; ${retryMessage})`, response.status, url, responseHeaders);
                return this.retryRequest(options, retriesRemaining, responseHeaders);
            }
            const errText = await response.text().catch((e) => core_castToError(e).message);
            const errJSON = core_safeJSON(errText);
            const errMessage = errJSON ? undefined : errText;
            const retryMessage = retriesRemaining ? `(error; no more retries left)` : `(error; not retryable)`;
            core_debug(`response (error; ${retryMessage})`, response.status, url, responseHeaders, errMessage);
            const err = this.makeStatusError(response.status, errJSON, errMessage, responseHeaders);
            throw err;
        }
        return { response, options, controller };
    }
    requestAPIList(Page, options) {
        const request = this.makeRequest(options, null);
        return new core_PagePromise(this, request, Page);
    }
    buildURL(path, query) {
        const url = core_isAbsoluteURL(path) ?
            new URL(path)
            : new URL(this.baseURL + (this.baseURL.endsWith('/') && path.startsWith('/') ? path.slice(1) : path));
        const defaultQuery = this.defaultQuery();
        if (!core_isEmptyObj(defaultQuery)) {
            query = { ...defaultQuery, ...query };
        }
        if (typeof query === 'object' && query && !Array.isArray(query)) {
            url.search = this.stringifyQuery(query);
        }
        return url.toString();
    }
    stringifyQuery(query) {
        return Object.entries(query)
            .filter(([_, value]) => typeof value !== 'undefined')
            .map(([key, value]) => {
            if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
                return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
            }
            if (value === null) {
                return `${encodeURIComponent(key)}=`;
            }
            throw new error_GroqError(`Cannot stringify type ${typeof value}; Expected string, number, boolean, or null. If you need to pass nested query parameters, you can manually encode them, e.g. { query: { 'foo[key1]': value1, 'foo[key2]': value2 } }, and please open a GitHub issue requesting better support for your use case.`);
        })
            .join('&');
    }
    async fetchWithTimeout(url, init, ms, controller) {
        const { signal, ...options } = init || {};
        if (signal)
            signal.addEventListener('abort', () => controller.abort());
        const timeout = setTimeout(() => controller.abort(), ms);
        const fetchOptions = {
            signal: controller.signal,
            ...options,
        };
        if (fetchOptions.method) {
            // Custom methods like 'patch' need to be uppercased
            // See https://github.com/nodejs/undici/issues/2294
            fetchOptions.method = fetchOptions.method.toUpperCase();
        }
        return (
        // use undefined this binding; fetch errors if bound to something else in browser/cloudflare
        this.fetch.call(undefined, url, fetchOptions).finally(() => {
            clearTimeout(timeout);
        }));
    }
    shouldRetry(response) {
        // Note this is not a standard header.
        const shouldRetryHeader = response.headers.get('x-should-retry');
        // If the server explicitly says whether or not to retry, obey.
        if (shouldRetryHeader === 'true')
            return true;
        if (shouldRetryHeader === 'false')
            return false;
        // Retry on request timeouts.
        if (response.status === 408)
            return true;
        // Retry on lock timeouts.
        if (response.status === 409)
            return true;
        // Retry on rate limits.
        if (response.status === 429)
            return true;
        // Retry internal errors.
        if (response.status >= 500)
            return true;
        return false;
    }
    async retryRequest(options, retriesRemaining, responseHeaders) {
        let timeoutMillis;
        // Note the `retry-after-ms` header may not be standard, but is a good idea and we'd like proactive support for it.
        const retryAfterMillisHeader = responseHeaders?.['retry-after-ms'];
        if (retryAfterMillisHeader) {
            const timeoutMs = parseFloat(retryAfterMillisHeader);
            if (!Number.isNaN(timeoutMs)) {
                timeoutMillis = timeoutMs;
            }
        }
        // About the Retry-After header: https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Retry-After
        const retryAfterHeader = responseHeaders?.['retry-after'];
        if (retryAfterHeader && !timeoutMillis) {
            const timeoutSeconds = parseFloat(retryAfterHeader);
            if (!Number.isNaN(timeoutSeconds)) {
                timeoutMillis = timeoutSeconds * 1000;
            }
            else {
                timeoutMillis = Date.parse(retryAfterHeader) - Date.now();
            }
        }
        // If the API asks us to wait a certain amount of time (and it's a reasonable amount),
        // just do what it says, but otherwise calculate a default
        if (!(timeoutMillis && 0 <= timeoutMillis && timeoutMillis < 60 * 1000)) {
            const maxRetries = options.maxRetries ?? this.maxRetries;
            timeoutMillis = this.calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries);
        }
        await core_sleep(timeoutMillis);
        return this.makeRequest(options, retriesRemaining - 1);
    }
    calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries) {
        const initialRetryDelay = 0.5;
        const maxRetryDelay = 8.0;
        const numRetries = maxRetries - retriesRemaining;
        // Apply exponential backoff, but not more than the max.
        const sleepSeconds = Math.min(initialRetryDelay * Math.pow(2, numRetries), maxRetryDelay);
        // Apply some jitter, take up to at most 25 percent of the retry time.
        const jitter = 1 - Math.random() * 0.25;
        return sleepSeconds * jitter * 1000;
    }
    getUserAgent() {
        return `${this.constructor.name}/JS ${version_VERSION}`;
    }
}
class core_AbstractPage {
    constructor(client, response, body, options) {
        core_AbstractPage_client.set(this, void 0);
        groq_sdk_core_classPrivateFieldSet(this, core_AbstractPage_client, client, "f");
        this.options = options;
        this.response = response;
        this.body = body;
    }
    hasNextPage() {
        const items = this.getPaginatedItems();
        if (!items.length)
            return false;
        return this.nextPageInfo() != null;
    }
    async getNextPage() {
        const nextInfo = this.nextPageInfo();
        if (!nextInfo) {
            throw new error_GroqError('No next page expected; please check `.hasNextPage()` before calling `.getNextPage()`.');
        }
        const nextOptions = { ...this.options };
        if ('params' in nextInfo && typeof nextOptions.query === 'object') {
            nextOptions.query = { ...nextOptions.query, ...nextInfo.params };
        }
        else if ('url' in nextInfo) {
            const params = [...Object.entries(nextOptions.query || {}), ...nextInfo.url.searchParams.entries()];
            for (const [key, value] of params) {
                nextInfo.url.searchParams.set(key, value);
            }
            nextOptions.query = undefined;
            nextOptions.path = nextInfo.url.toString();
        }
        return await groq_sdk_core_classPrivateFieldGet(this, core_AbstractPage_client, "f").requestAPIList(this.constructor, nextOptions);
    }
    async *iterPages() {
        // eslint-disable-next-line @typescript-eslint/no-this-alias
        let page = this;
        yield page;
        while (page.hasNextPage()) {
            page = await page.getNextPage();
            yield page;
        }
    }
    async *[(core_AbstractPage_client = new WeakMap(), Symbol.asyncIterator)]() {
        for await (const page of this.iterPages()) {
            for (const item of page.getPaginatedItems()) {
                yield item;
            }
        }
    }
}
/**
 * This subclass of Promise will resolve to an instantiated Page once the request completes.
 *
 * It also implements AsyncIterable to allow auto-paginating iteration on an unawaited list call, eg:
 *
 *    for await (const item of client.items.list()) {
 *      console.log(item)
 *    }
 */
class core_PagePromise extends core_APIPromise {
    constructor(client, request, Page) {
        super(request, async (props) => new Page(client, props.response, await core_defaultParseResponse(props), props.options));
    }
    /**
     * Allow auto-paginating iteration on an unawaited list call, eg:
     *
     *    for await (const item of client.items.list()) {
     *      console.log(item)
     *    }
     */
    async *[Symbol.asyncIterator]() {
        const page = await this;
        for await (const item of page) {
            yield item;
        }
    }
}
const core_createResponseHeaders = (headers) => {
    return new Proxy(Object.fromEntries(
    // @ts-ignore
    headers.entries()), {
        get(target, name) {
            const key = name.toString();
            return target[key.toLowerCase()] || target[key];
        },
    });
};
// This is required so that we can determine if a given object matches the RequestOptions
// type at runtime. While this requires duplication, it is enforced by the TypeScript
// compiler such that any missing / extraneous keys will cause an error.
const core_requestOptionsKeys = {
    method: true,
    path: true,
    query: true,
    body: true,
    headers: true,
    maxRetries: true,
    stream: true,
    timeout: true,
    httpAgent: true,
    signal: true,
    idempotencyKey: true,
    __binaryRequest: true,
    __binaryResponse: true,
    __streamClass: true,
};
const core_isRequestOptions = (obj) => {
    return (typeof obj === 'object' &&
        obj !== null &&
        !core_isEmptyObj(obj) &&
        Object.keys(obj).every((k) => core_hasOwn(core_requestOptionsKeys, k)));
};
const core_getPlatformProperties = () => {
    if (typeof Deno !== 'undefined' && Deno.build != null) {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': version_VERSION,
            'X-Stainless-OS': core_normalizePlatform(Deno.build.os),
            'X-Stainless-Arch': core_normalizeArch(Deno.build.arch),
            'X-Stainless-Runtime': 'deno',
            'X-Stainless-Runtime-Version': typeof Deno.version === 'string' ? Deno.version : Deno.version?.deno ?? 'unknown',
        };
    }
    if (typeof EdgeRuntime !== 'undefined') {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': version_VERSION,
            'X-Stainless-OS': 'Unknown',
            'X-Stainless-Arch': `other:${EdgeRuntime}`,
            'X-Stainless-Runtime': 'edge',
            'X-Stainless-Runtime-Version': core_process.version,
        };
    }
    // Check if Node.js
    if (Object.prototype.toString.call(typeof core_process !== 'undefined' ? core_process : 0) === '[object process]') {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': version_VERSION,
            'X-Stainless-OS': core_normalizePlatform(core_process.platform),
            'X-Stainless-Arch': core_normalizeArch(core_process.arch),
            'X-Stainless-Runtime': 'node',
            'X-Stainless-Runtime-Version': core_process.version,
        };
    }
    const browserInfo = core_getBrowserInfo();
    if (browserInfo) {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': version_VERSION,
            'X-Stainless-OS': 'Unknown',
            'X-Stainless-Arch': 'unknown',
            'X-Stainless-Runtime': `browser:${browserInfo.browser}`,
            'X-Stainless-Runtime-Version': browserInfo.version,
        };
    }
    // TODO add support for Cloudflare workers, etc.
    return {
        'X-Stainless-Lang': 'js',
        'X-Stainless-Package-Version': version_VERSION,
        'X-Stainless-OS': 'Unknown',
        'X-Stainless-Arch': 'unknown',
        'X-Stainless-Runtime': 'unknown',
        'X-Stainless-Runtime-Version': 'unknown',
    };
};
// Note: modified from https://github.com/JS-DevTools/host-environment/blob/b1ab79ecde37db5d6e163c050e54fe7d287d7c92/src/isomorphic.browser.ts
function core_getBrowserInfo() {
    if (typeof navigator === 'undefined' || !navigator) {
        return null;
    }
    // NOTE: The order matters here!
    const browserPatterns = [
        { key: 'edge', pattern: /Edge(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'ie', pattern: /MSIE(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'ie', pattern: /Trident(?:.*rv\:(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'chrome', pattern: /Chrome(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'firefox', pattern: /Firefox(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'safari', pattern: /(?:Version\W+(\d+)\.(\d+)(?:\.(\d+))?)?(?:\W+Mobile\S*)?\W+Safari/ },
    ];
    // Find the FIRST matching browser
    for (const { key, pattern } of browserPatterns) {
        const match = pattern.exec(navigator.userAgent);
        if (match) {
            const major = match[1] || 0;
            const minor = match[2] || 0;
            const patch = match[3] || 0;
            return { browser: key, version: `${major}.${minor}.${patch}` };
        }
    }
    return null;
}
const core_normalizeArch = (arch) => {
    // Node docs:
    // - https://nodejs.org/api/process.html#processarch
    // Deno docs:
    // - https://doc.deno.land/deno/stable/~/Deno.build
    if (arch === 'x32')
        return 'x32';
    if (arch === 'x86_64' || arch === 'x64')
        return 'x64';
    if (arch === 'arm')
        return 'arm';
    if (arch === 'aarch64' || arch === 'arm64')
        return 'arm64';
    if (arch)
        return `other:${arch}`;
    return 'unknown';
};
const core_normalizePlatform = (platform) => {
    // Node platforms:
    // - https://nodejs.org/api/process.html#processplatform
    // Deno platforms:
    // - https://doc.deno.land/deno/stable/~/Deno.build
    // - https://github.com/denoland/deno/issues/14799
    platform = platform.toLowerCase();
    // NOTE: this iOS check is untested and may not work
    // Node does not work natively on IOS, there is a fork at
    // https://github.com/nodejs-mobile/nodejs-mobile
    // however it is unknown at the time of writing how to detect if it is running
    if (platform.includes('ios'))
        return 'iOS';
    if (platform === 'android')
        return 'Android';
    if (platform === 'darwin')
        return 'MacOS';
    if (platform === 'win32')
        return 'Windows';
    if (platform === 'freebsd')
        return 'FreeBSD';
    if (platform === 'openbsd')
        return 'OpenBSD';
    if (platform === 'linux')
        return 'Linux';
    if (platform)
        return `Other:${platform}`;
    return 'Unknown';
};
let core_platformHeaders;
const core_getPlatformHeaders = () => {
    return (core_platformHeaders ?? (core_platformHeaders = core_getPlatformProperties()));
};
const core_safeJSON = (text) => {
    try {
        return JSON.parse(text);
    }
    catch (err) {
        return undefined;
    }
};
// https://url.spec.whatwg.org/#url-scheme-string
const core_startsWithSchemeRegexp = /^[a-z][a-z0-9+.-]*:/i;
const core_isAbsoluteURL = (url) => {
    return core_startsWithSchemeRegexp.test(url);
};
const core_sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const core_validatePositiveInteger = (name, n) => {
    if (typeof n !== 'number' || !Number.isInteger(n)) {
        throw new error_GroqError(`${name} must be an integer`);
    }
    if (n < 0) {
        throw new error_GroqError(`${name} must be a positive integer`);
    }
    return n;
};
const core_castToError = (err) => {
    if (err instanceof Error)
        return err;
    if (typeof err === 'object' && err !== null) {
        try {
            return new Error(JSON.stringify(err));
        }
        catch { }
    }
    return new Error(err);
};
const core_ensurePresent = (value) => {
    if (value == null)
        throw new GroqError(`Expected a value to be given but received ${value} instead.`);
    return value;
};
/**
 * Read an environment variable.
 *
 * Trims beginning and trailing whitespace.
 *
 * Will return undefined if the environment variable doesn't exist or cannot be accessed.
 */
const core_readEnv = (env) => {
    if (typeof core_process !== 'undefined') {
        return {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}?.[env]?.trim() ?? undefined;
    }
    if (typeof Deno !== 'undefined') {
        return Deno.env?.get?.(env)?.trim();
    }
    return undefined;
};
const core_coerceInteger = (value) => {
    if (typeof value === 'number')
        return Math.round(value);
    if (typeof value === 'string')
        return parseInt(value, 10);
    throw new GroqError(`Could not coerce ${value} (type: ${typeof value}) into a number`);
};
const core_coerceFloat = (value) => {
    if (typeof value === 'number')
        return value;
    if (typeof value === 'string')
        return parseFloat(value);
    throw new GroqError(`Could not coerce ${value} (type: ${typeof value}) into a number`);
};
const core_coerceBoolean = (value) => {
    if (typeof value === 'boolean')
        return value;
    if (typeof value === 'string')
        return value === 'true';
    return Boolean(value);
};
const core_maybeCoerceInteger = (value) => {
    if (value === undefined) {
        return undefined;
    }
    return core_coerceInteger(value);
};
const core_maybeCoerceFloat = (value) => {
    if (value === undefined) {
        return undefined;
    }
    return core_coerceFloat(value);
};
const core_maybeCoerceBoolean = (value) => {
    if (value === undefined) {
        return undefined;
    }
    return core_coerceBoolean(value);
};
// https://stackoverflow.com/a/34491287
function core_isEmptyObj(obj) {
    if (!obj)
        return true;
    for (const _k in obj)
        return false;
    return true;
}
// https://eslint.org/docs/latest/rules/no-prototype-builtins
function core_hasOwn(obj, key) {
    return Object.prototype.hasOwnProperty.call(obj, key);
}
/**
 * Copies headers from "newHeaders" onto "targetHeaders",
 * using lower-case for all properties,
 * ignoring any keys with undefined values,
 * and deleting any keys with null values.
 */
function core_applyHeadersMut(targetHeaders, newHeaders) {
    for (const k in newHeaders) {
        if (!core_hasOwn(newHeaders, k))
            continue;
        const lowerKey = k.toLowerCase();
        if (!lowerKey)
            continue;
        const val = newHeaders[k];
        if (val === null) {
            delete targetHeaders[lowerKey];
        }
        else if (val !== undefined) {
            targetHeaders[lowerKey] = val;
        }
    }
}
function core_debug(action, ...args) {
    if (typeof core_process !== 'undefined' && {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}?.['DEBUG'] === 'true') {
        console.log(`Groq:DEBUG:${action}`, ...args);
    }
}
/**
 * https://stackoverflow.com/a/2117523
 */
const core_uuid4 = () => {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = (Math.random() * 16) | 0;
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    });
};
const core_isRunningInBrowser = () => {
    return (
    // @ts-ignore
    typeof window !== 'undefined' &&
        // @ts-ignore
        typeof window.document !== 'undefined' &&
        // @ts-ignore
        typeof navigator !== 'undefined');
};
const core_isHeadersProtocol = (headers) => {
    return typeof headers?.get === 'function';
};
const core_getRequiredHeader = (headers, header) => {
    const foundHeader = core_getHeader(headers, header);
    if (foundHeader === undefined) {
        throw new Error(`Could not find ${header} header`);
    }
    return foundHeader;
};
const core_getHeader = (headers, header) => {
    const lowerCasedHeader = header.toLowerCase();
    if (core_isHeadersProtocol(headers)) {
        // to deal with the case where the header looks like Stainless-Event-Id
        const intercapsHeader = header[0]?.toUpperCase() +
            header.substring(1).replace(/([^\w])(\w)/g, (_m, g1, g2) => g1 + g2.toUpperCase());
        for (const key of [header, lowerCasedHeader, header.toUpperCase(), intercapsHeader]) {
            const value = headers.get(key);
            if (value) {
                return value;
            }
        }
    }
    for (const [key, value] of Object.entries(headers)) {
        if (key.toLowerCase() === lowerCasedHeader) {
            if (Array.isArray(value)) {
                if (value.length <= 1)
                    return value[0];
                console.warn(`Received ${value.length} entries for the ${header} header, using the first entry.`);
                return value[0];
            }
            return value;
        }
    }
    return undefined;
};
/**
 * Encodes a string to Base64 format.
 */
const core_toBase64 = (str) => {
    if (!str)
        return '';
    if (typeof groq_sdk_core_Buffer !== 'undefined') {
        return groq_sdk_core_Buffer.from(str).toString('base64');
    }
    if (typeof btoa !== 'undefined') {
        return btoa(str);
    }
    throw new GroqError('Cannot generate b64 string; Expected `Buffer` or `btoa` to be defined');
};
function core_isObj(obj) {
    return obj != null && typeof obj === 'object' && !Array.isArray(obj);
}
//# sourceMappingURL=core.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resource.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
class resource_APIResource {
    constructor(client) {
        this._client = client;
    }
}
//# sourceMappingURL=resource.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/completions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class resources_completions_Completions extends resource_APIResource {
}
//# sourceMappingURL=completions.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/chat/completions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class resources_chat_completions_Completions extends resource_APIResource {
    create(body, options) {
        return this._client.post('/openai/v1/chat/completions', {
            body,
            ...options,
            stream: body.stream ?? false,
        });
    }
}
//# sourceMappingURL=completions.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/chat/chat.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class chat_chat_Chat extends resource_APIResource {
    constructor() {
        super(...arguments);
        this.completions = new resources_chat_completions_Completions(this._client);
    }
}
chat_chat_Chat.Completions = resources_chat_completions_Completions;
//# sourceMappingURL=chat.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/embeddings.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class embeddings_Embeddings extends resource_APIResource {
    /**
     * Creates an embedding vector representing the input text.
     */
    create(body, options) {
        return this._client.post('/openai/v1/embeddings', { body, ...options });
    }
}
//# sourceMappingURL=embeddings.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/audio/transcriptions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class transcriptions_Transcriptions extends resource_APIResource {
    /**
     * Transcribes audio into the input language.
     */
    create(body, options) {
        return this._client.post('/openai/v1/audio/transcriptions', uploads_multipartFormRequestOptions({ body, ...options }));
    }
}
//# sourceMappingURL=transcriptions.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/audio/translations.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class translations_Translations extends resource_APIResource {
    /**
     * Translates audio into English.
     */
    create(body, options) {
        return this._client.post('/openai/v1/audio/translations', uploads_multipartFormRequestOptions({ body, ...options }));
    }
}
//# sourceMappingURL=translations.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/audio/audio.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.





class audio_Audio extends resource_APIResource {
    constructor() {
        super(...arguments);
        this.transcriptions = new transcriptions_Transcriptions(this._client);
        this.translations = new translations_Translations(this._client);
    }
}
audio_Audio.Transcriptions = transcriptions_Transcriptions;
audio_Audio.Translations = translations_Translations;
//# sourceMappingURL=audio.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/models.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class models_Models extends resource_APIResource {
    /**
     * Get a specific model
     */
    retrieve(model, options) {
        return this._client.get(`/openai/v1/models/${model}`, options);
    }
    /**
     * get all available models
     */
    list(options) {
        return this._client.get('/openai/v1/models', options);
    }
    /**
     * Delete a model
     */
    delete(model, options) {
        return this._client.delete(`/openai/v1/models/${model}`, options);
    }
}
//# sourceMappingURL=models.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/batches.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class batches_Batches extends resource_APIResource {
    /**
     * Creates and executes a batch from an uploaded file of requests
     */
    create(body, options) {
        return this._client.post('/openai/v1/batches', { body, ...options });
    }
    /**
     * Retrieves a batch.
     */
    retrieve(batchId, options) {
        return this._client.get(`/openai/v1/batches/${batchId}`, options);
    }
    /**
     * List your organization's batches.
     */
    list(options) {
        return this._client.get('/openai/v1/batches', options);
    }
}
//# sourceMappingURL=batches.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/files.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class resources_files_Files extends resource_APIResource {
    /**
     * Upload a file that can be used across various endpoints.
     *
     * The Batch API only supports `.jsonl` files up to 100 MB in size. The input also
     * has a specific required [format](/docs/batch).
     *
     * Please contact us if you need to increase these storage limits.
     */
    create(body, options) {
        return this._client.post('/openai/v1/files', uploads_multipartFormRequestOptions({ body, ...options }));
    }
    /**
     * Returns a list of files.
     */
    list(options) {
        return this._client.get('/openai/v1/files', options);
    }
    /**
     * Delete a file.
     */
    delete(fileId, options) {
        return this._client.delete(`/openai/v1/files/${fileId}`, options);
    }
    /**
     * Returns the contents of the specified file.
     */
    content(fileId, options) {
        return this._client.get(`/openai/v1/files/${fileId}/content`, options);
    }
    /**
     * Returns information about a file.
     */
    info(fileId, options) {
        return this._client.get(`/openai/v1/files/${fileId}`, options);
    }
}
//# sourceMappingURL=files.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/index.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
var groq_sdk_a;











/**
 * API Client for interfacing with the Groq API.
 */
class groq_sdk_Groq extends core_APIClient {
    /**
     * API Client for interfacing with the Groq API.
     *
     * @param {string | undefined} [opts.apiKey=process.env['GROQ_API_KEY'] ?? undefined]
     * @param {string} [opts.baseURL=process.env['GROQ_BASE_URL'] ?? https://api.groq.com] - Override the default base URL for the API.
     * @param {number} [opts.timeout=1 minute] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {number} [opts.httpAgent] - An HTTP agent used to manage HTTP(s) connections.
     * @param {Core.Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {Core.Headers} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Core.DefaultQuery} opts.defaultQuery - Default query parameters to include with every request to the API.
     * @param {boolean} [opts.dangerouslyAllowBrowser=false] - By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
     */
    constructor({ baseURL = core_readEnv('GROQ_BASE_URL'), apiKey = core_readEnv('GROQ_API_KEY'), ...opts } = {}) {
        if (apiKey === undefined) {
            throw new error_GroqError("The GROQ_API_KEY environment variable is missing or empty; either provide it, or instantiate the Groq client with an apiKey option, like new Groq({ apiKey: 'My API Key' }).");
        }
        const options = {
            apiKey,
            ...opts,
            baseURL: baseURL || `https://api.groq.com`,
        };
        if (!options.dangerouslyAllowBrowser && core_isRunningInBrowser()) {
            throw new error_GroqError("It looks like you're running in a browser-like environment.\n\nThis is disabled by default, as it risks exposing your secret API credentials to attackers.\nIf you understand the risks and have appropriate mitigations in place,\nyou can set the `dangerouslyAllowBrowser` option to `true`, e.g.,\n\nnew Groq({ apiKey, dangerouslyAllowBrowser: true })");
        }
        super({
            baseURL: options.baseURL,
            timeout: options.timeout ?? 60000 /* 1 minute */,
            httpAgent: options.httpAgent,
            maxRetries: options.maxRetries,
            fetch: options.fetch,
        });
        this.completions = new resources_completions_Completions(this);
        this.chat = new chat_chat_Chat(this);
        this.embeddings = new embeddings_Embeddings(this);
        this.audio = new audio_Audio(this);
        this.models = new models_Models(this);
        this.batches = new batches_Batches(this);
        this.files = new resources_files_Files(this);
        this._options = options;
        this.apiKey = apiKey;
    }
    defaultQuery() {
        return this._options.defaultQuery;
    }
    defaultHeaders(opts) {
        return {
            ...super.defaultHeaders(opts),
            ...this._options.defaultHeaders,
        };
    }
    authHeaders(opts) {
        return { Authorization: `Bearer ${this.apiKey}` };
    }
}
groq_sdk_a = groq_sdk_Groq;
groq_sdk_Groq.Groq = groq_sdk_a;
groq_sdk_Groq.DEFAULT_TIMEOUT = 60000; // 1 minute
groq_sdk_Groq.GroqError = error_GroqError;
groq_sdk_Groq.APIError = error_APIError;
groq_sdk_Groq.APIConnectionError = error_APIConnectionError;
groq_sdk_Groq.APIConnectionTimeoutError = error_APIConnectionTimeoutError;
groq_sdk_Groq.APIUserAbortError = error_APIUserAbortError;
groq_sdk_Groq.NotFoundError = error_NotFoundError;
groq_sdk_Groq.ConflictError = error_ConflictError;
groq_sdk_Groq.RateLimitError = error_RateLimitError;
groq_sdk_Groq.BadRequestError = error_BadRequestError;
groq_sdk_Groq.AuthenticationError = error_AuthenticationError;
groq_sdk_Groq.InternalServerError = error_InternalServerError;
groq_sdk_Groq.PermissionDeniedError = error_PermissionDeniedError;
groq_sdk_Groq.UnprocessableEntityError = error_UnprocessableEntityError;
groq_sdk_Groq.toFile = uploads_toFile;
groq_sdk_Groq.fileFromPath = registry_fileFromPath;
groq_sdk_Groq.Completions = resources_completions_Completions;
groq_sdk_Groq.Chat = chat_chat_Chat;
groq_sdk_Groq.Embeddings = embeddings_Embeddings;
groq_sdk_Groq.Audio = audio_Audio;
groq_sdk_Groq.Models = models_Models;
groq_sdk_Groq.Batches = batches_Batches;
groq_sdk_Groq.Files = resources_files_Files;


/* harmony default export */ const groq_sdk = (groq_sdk_Groq);
//# sourceMappingURL=index.mjs.map
// EXTERNAL MODULE: ./src/utils.ts
var utils = __webpack_require__(3922);
;// CONCATENATED MODULE: ./src/llm.ts




// ==================== 辅助函数：模糊匹配（从 vectorStore.ts 迁移）====================
// 注意: 以下函数暂未使用，保留供将来扩展

/**
 * 模糊匹配人名
 * @param partialName 部分人名
 * @param knownPeople 已知人名列表
 * @returns 匹配的完整人名，如果没有匹配返回 null
 */
function _fuzzyMatchPerson(partialName, knownPeople) {
  if (!partialName || !knownPeople || knownPeople.length === 0) {
    return null;
  }

  // 转换为小写进行比较
  const lowerPartialName = partialName.toLowerCase();

  // 1. 精确匹配（忽略大小写）
  const exactMatch = knownPeople.find(person => person.toLowerCase() === lowerPartialName);
  if (exactMatch) return exactMatch;

  // 2. 开头匹配（例如 "Nelson" 匹配 "Nelson Wu"）
  const startsWithMatch = knownPeople.find(person => person.toLowerCase().startsWith(lowerPartialName));
  if (startsWithMatch) return startsWithMatch;

  // 3. 包含匹配（例如 "Wu" 匹配 "Nelson Wu"）
  const containsMatch = knownPeople.find(person => person.toLowerCase().includes(lowerPartialName));
  if (containsMatch) return containsMatch;

  // 4. 分词匹配（例如 "nelson" 匹配 "Nelson Wu"）
  const wordMatch = knownPeople.find(person => {
    const words = person.toLowerCase().split(/\s+/);
    return words.some(word => word === lowerPartialName);
  });
  if (wordMatch) return wordMatch;

  // 5. 首字母匹配（例如 "NW" 匹配 "Nelson Wu"）
  if (lowerPartialName.length >= 2) {
    const initialsMatch = knownPeople.find(person => {
      const initials = person.split(/\s+/).map(word => word[0]?.toLowerCase()).join('');
      return initials === lowerPartialName;
    });
    if (initialsMatch) return initialsMatch;
  }

  // 没有找到匹配
  return null;
}

/**
 * 模糊匹配实体名称（项目或主题）
 * @param partialName 部分实体名称
 * @param knownNames 已知实体名称列表
 * @returns 匹配的实体名称数组
 */
function _fuzzyMatchEntityName(partialName, knownNames) {
  if (!partialName || !knownNames || knownNames.length === 0) {
    return [];
  }

  // 转换为小写进行比较
  const lowerPartialName = partialName.toLowerCase();
  const matches = [];

  // 1. 精确匹配（忽略大小写）
  const exactMatches = knownNames.filter(name => name.toLowerCase() === lowerPartialName);
  matches.push(...exactMatches);

  // 如果找到精确匹配，直接返回
  if (matches.length > 0) return matches;

  // 2. 开头匹配（例如 "AI note" 匹配 "AI note 相关的规划进度"）
  const startsWithMatches = knownNames.filter(name => name.toLowerCase().startsWith(lowerPartialName));
  matches.push(...startsWithMatches);

  // 3. 包含匹配（例如 "note" 匹配 "AI note 相关的规划进度"）
  const containsMatches = knownNames.filter(name => name.toLowerCase().includes(lowerPartialName) && !matches.includes(name) // 避免重复
  );
  matches.push(...containsMatches);

  // 4. 词语匹配（例如 "AI" 和 "note" 都匹配 "AI note 相关的规划进度"）
  const words = lowerPartialName.split(/\s+/);
  if (words.length > 1) {
    const wordMatches = knownNames.filter(name => {
      const nameWords = name.toLowerCase().split(/\s+/);
      return words.every(word => nameWords.some(nameWord => nameWord.includes(word))) && !matches.includes(name); // 避免重复
    });
    matches.push(...wordMatches);
  }
  return matches;
}

// 根据不同 LLM 服务处理 LLM 请求，并提取 JSON 数据
async function handleLLMRequest(body) {
  const envConfig = await (0,utils/* getEnvConfig */.Un)();
  let handler;
  switch (envConfig.LLM_TYPE) {
    case 'local':
      handler = handleOllamaRequest;
      if (body.type === 'review') body.model = envConfig.OLLAMA_REVIEW_MODEL;
      if (body.type === 'query') body.model = envConfig.OLLAMA_QUERY_MODEL;
      break;
    case 'groq':
      handler = handleGroqRequest;
      if (body.type === 'review') body.model = envConfig.GROQ_REVIEW_MODEL;
      break;
    case 'dify':
      handler = handleDifyRequest;
      if (body.type === 'review') body.apiKey = envConfig.DIFY_REVIEW_API_KEY;
      break;
    default:
      handler = handleOpenAIRequest;
      if (body.type === 'review') body.model = envConfig.OPENAI_REVIEW_MODEL;
  }
  const response = await handler(body);
  return response;
}

// 处理 Ollama 请求。Ollama 安装后需要把 launchctl setenv OLLAMA_ORIGINS "*" 加入到 .bashrc 中
async function handleOllamaRequest(body) {
  const envConfig = await (0,utils/* getEnvConfig */.Un)();
  const response = await fetch(`${envConfig.OLLAMA_BASE_URL}/api/generate`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: body.model || envConfig.OLLAMA_MODEL,
      prompt: body.prompt,
      stream: false,
      temperature: 0.3,
      top_p: 0.9
    })
  });
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  const result = await response.json();
  return result.response;
}

// 处理 OpenAI 请求
async function handleOpenAIRequest(body) {
  const envConfig = await (0,utils/* getEnvConfig */.Un)();
  // 初始化 OpenAI 客户端
  const openai = new node_modules_openai({
    apiKey: envConfig.OPENAI_API_KEY,
    baseURL: envConfig.OPENAI_API_BASE_URL,
    dangerouslyAllowBrowser: true
  });
  const completion = await openai.chat.completions.create({
    model: envConfig.OPENAI_MODEL,
    messages: body.system_prompt ? [{
      role: "system",
      content: body.system_prompt
    }, {
      role: "user",
      content: body.user_prompt
    }] : [{
      role: "user",
      content: body.prompt
    }],
    temperature: 0.3,
    top_p: 0.9
  });
  return completion.choices[0].message.content || '';
}

// 处理 Groq 请求
async function handleGroqRequest(body) {
  const envConfig = await (0,utils/* getEnvConfig */.Un)();
  // 初始化 Groq 客户端
  const groq = new groq_sdk({
    apiKey: envConfig.GROQ_API_KEY,
    dangerouslyAllowBrowser: true
  });
  const completion = await groq.chat.completions.create({
    model: envConfig.GROQ_MODEL || 'mixtral-8x7b-32768',
    messages: body.system_prompt ? [{
      role: "system",
      content: body.system_prompt
    }, {
      role: "user",
      content: body.user_prompt
    }] : [{
      role: "user",
      content: body.prompt
    }],
    temperature: 0.3,
    top_p: 0.9
  });
  return completion.choices[0].message.content || '';
}

// 新增：处理 Dify 请求
async function handleDifyRequest(body) {
  const envConfig = await (0,utils/* getEnvConfig */.Un)();
  // 新增：初始化 Dify API 配置
  const difyConfig = {
    apiKey: envConfig.DIFY_API_KEY,
    reviewApiKey: envConfig.DIFY_REVIEW_API_KEY,
    baseURL: envConfig.DIFY_API_BASE_URL || 'https://api.dify.ai/v1'
  };
  const response = await fetch(`${difyConfig.baseURL}/completion-messages`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${body.apiKey || difyConfig.apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      inputs: {
        query: body.prompt
      },
      // 可选的输入参数
      response_mode: 'blocking',
      // 改为 streaming 模式
      user: body.user || 'default-user' // 可选
    })
  });
  if (!response.ok) {
    throw new Error(`Dify API error! status: ${response.status}`);
  }
  const result = await response.json();
  return result.answer || '';
}

// 新增：从响应文本中提取 JSON 数据
function extractJsonFromResponse(response) {
  let jsonData = [];
  try {
    // 首先尝试直接解析整个响应
    try {
      const directParse = JSON.parse(response.trim());
      return directParse;
    } catch (e) {
      // 如果直接解析失败，继续尝试其他方法
    }

    // 尝试从响应中查找 JSON 代码块
    const jsonMatch = response.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
    if (jsonMatch) {
      const parsedData = JSON.parse(jsonMatch[1].trim());
      jsonData = parsedData;
    } else {
      // 尝试查找可能的 JSON 字符串（方括号或大括号开头和结尾）
      const jsonRegex = /(\[[\s\S]*\]|\{[\s\S]*\})/;
      const potentialJson = response.match(jsonRegex);
      if (potentialJson) {
        const parsedData = JSON.parse(potentialJson[1].trim());
        jsonData = parsedData;
      }
    }
  } catch (e) {
    console.warn('Failed to parse JSON from LLM response:', e);
  }
  return jsonData;
}

/**
 * 知识查询 - 兼容层
 * 
 * 🔄 重构说明：此函数现在是一个兼容层，实际查询逻辑已移至 memorySystem.knowledgeQuery
 * 新的架构中，memorySystem 作为统一的记忆查询路由，负责：
 * 1. 智能决策：选择本地缓存还是云端查询
 * 2. 查询策略：实体搜索 + 消息搜索 + 关系扩展
 * 3. 结果融合：优先使用实体信息，消息作为补充
 * 4. LLM 生成：基于融合后的上下文生成答案
 * 
 * @param question 用户的自然语言问题
 * @returns 查询结果
 */
async function knowledgeQuery(question) {
  console.log('🔄 knowledgeQuery [兼容层] ->', question);
  try {
    // 🆕 调用新的 ask() 接口
    const {
      memorySystem
    } = await __webpack_require__.e(/* import() */ 143).then(__webpack_require__.bind(__webpack_require__, 6939));
    const result = await memorySystem.ask(question);

    // 🔄 转换新格式到旧格式（向后兼容）
    if (!result.success) {
      return {
        success: false,
        message: result.message || '查询时发生错误'
      };
    }

    // 将 entitiesByType 展平为单一数组
    const flatEntities = [];
    if (result.entitiesByType) {
      for (const entities of Object.values(result.entitiesByType)) {
        flatEntities.push(...entities);
      }
    }
    return {
      success: true,
      analysis: result.answer,
      relatedMessages: result.metadata?.totalEntities || 0,
      queryIntent: result.metadata?.queryIntent,
      results: flatEntities
    };
  } catch (error) {
    console.error('💥 知识查询失败:', error);
    return {
      success: false,
      message: '查询时发生错误，请稍后再试。'
    };
  }
}

/**
 * @deprecated 旧的 knowledgeQuery 实现，已废弃
 * 新实现在 memorySystem.knowledgeQuery
 * 
 * 🔄 重构说明：
 * - 此函数的逻辑已完整移植到 memorySystem.knowledgeQuery
 * - 新实现增强了实体直接检索和关系扩展查询
 * - 不再需要直接访问 cloudStorage，所有查询通过 memorySystem 路由
 * 
 * 此函数已不再使用，保留仅供参考
 */
async function knowledgeQueryOld_DEPRECATED(_question) {
  throw new Error('此函数已废弃，请使用 memorySystem.knowledgeQuery 代替');

  /* 旧实现已注释，请参考 memorySystem.knowledgeQuery
  console.log('knowledgeQuery', question, new Date().getTime());
  try {
    // 1. 从问题中识别查询意图和关键实体
    const queryIntent = await extractEntitiesForQuery(question);
    console.log('queryIntent', queryIntent, new Date().getTime());
    
    // 类型安全处理：确保时间范围有效
    if (queryIntent?.query?.filters?.time_range) {
      const timeRange = queryIntent.query.filters.time_range;
      
      // 处理时间疑问词
      if (timeRange.type === 'specific' && typeof timeRange.start === 'string') {
        console.warn(`非法的时间值: ${timeRange.start}，类型: ${typeof timeRange.start}`);
        
        // 检查是否是常见的时间疑问词
        const timeQuestionWords = ["什么时候", "何时", "几点", "哪天", "什么日期", "什么时间", "几号", "什么时段", "几月", "哪一天", "什么季节"];
        
        if (timeQuestionWords.some(word => timeRange.start.includes(word))) {
          console.log(`检测到时间疑问词: "${timeRange.start}"，将time_range.type设为"all"`);
          timeRange.type = "all";
          timeRange.start = null;
          timeRange.end = null;
        }
      }
      
      // 根据时间描述设置具体的时间范围
      if (timeRange.type === 'range' && timeRange.description) {
        const now = new Date();
        const thisYear = now.getFullYear();
        const thisMonth = now.getMonth();
        
        if (/今年|本年|今年度|本年度/.test(timeRange.description)) {
          // 今年范围：从今年1月1日到现在
          const startOfYear = new Date(thisYear, 0, 1).getTime();
          timeRange.start = startOfYear;
          timeRange.end = now.getTime();
          console.log(`设置今年时间范围: ${new Date(startOfYear).toISOString()} 到 ${new Date().toISOString()}`);
        } 
        else if (/这个月|本月|当月/.test(timeRange.description)) {
          // 这个月范围：从本月1日到现在
          const startOfMonth = new Date(thisYear, thisMonth, 1).getTime();
          timeRange.start = startOfMonth;
          timeRange.end = now.getTime();
          console.log(`设置本月时间范围: ${new Date(startOfMonth).toISOString()} 到 ${new Date().toISOString()}`);
        }
        else if (/上个月|上月|前一个月/.test(timeRange.description)) {
          // 上个月范围
          const lastMonth = thisMonth === 0 ? 11 : thisMonth - 1;
          const lastMonthYear = thisMonth === 0 ? thisYear - 1 : thisYear;
          const startOfLastMonth = new Date(lastMonthYear, lastMonth, 1).getTime();
          const endOfLastMonth = new Date(thisYear, thisMonth, 0).getTime();
          timeRange.start = startOfLastMonth;
          timeRange.end = endOfLastMonth;
          console.log(`设置上月时间范围: ${new Date(startOfLastMonth).toISOString()} 到 ${new Date(endOfLastMonth).toISOString()}`);
        }
        else if (/去年|上一年|前一年/.test(timeRange.description)) {
          // 去年范围
          const lastYear = thisYear - 1;
          const startOfLastYear = new Date(lastYear, 0, 1).getTime();
          const endOfLastYear = new Date(lastYear, 11, 31, 23, 59, 59).getTime();
          timeRange.start = startOfLastYear;
          timeRange.end = endOfLastYear;
          console.log(`设置去年时间范围: ${new Date(startOfLastYear).toISOString()} 到 ${new Date(endOfLastYear).toISOString()}`);
        }
        else if (/过去(\d+)天|最近(\d+)天/.test(timeRange.description)) {
          // 过去N天
          const matches = timeRange.description.match(/过去(\d+)天|最近(\d+)天/);
          if (matches) {
            const days = parseInt(matches[1] || matches[2]);
            if (!isNaN(days)) {
              const pastDays = now.getTime() - (days * 24 * 60 * 60 * 1000);
              timeRange.start = pastDays;
              timeRange.end = now.getTime();
              console.log(`设置过去${days}天时间范围: ${new Date(pastDays).toISOString()} 到 ${new Date().toISOString()}`);
            }
          }
        }
      }
      
      // 如果是recent类型，设置默认为过去7天
      if (timeRange.type === 'recent') {
        const now = new Date();
        const sevenDaysAgo = now.getTime() - (7 * 24 * 60 * 60 * 1000);
        timeRange.start = sevenDaysAgo;
        timeRange.end = now.getTime();
        console.log(`设置最近时间范围(7天): ${new Date(sevenDaysAgo).toISOString()} 到 ${new Date().toISOString()}`);
      }
    }
    
    // 1.5 获取所有已知人名、项目和主题进行模糊匹配
    // 1.5.1 人名模糊匹配
    if (queryIntent?.query?.filters?.entities?.people?.length > 0) {
      // 🔄 使用新的 memorySystem API 获取所有已知人名
      await memorySystem.initialize();
      const knownPeople = await memorySystem.cloudStorage.getAllKnownPeople();
      console.log('已知人名列表:', knownPeople);
      
      // 对每个识别出的人名进行模糊匹配
      const matchedPeople = [];
      for (const person of queryIntent.query.filters.entities.people) {
        const matchedPerson = fuzzyMatchPerson(person.name, knownPeople);
        if (matchedPerson) {
          console.log(`人名模糊匹配: "${person.name}" => "${matchedPerson}"`);
          matchedPeople.push({
            name: matchedPerson,
            role: person.role,
            required: person.required
          });
        } else {
          // 如果没有匹配到，保留原始人名
          matchedPeople.push(person);
        }
      }
      
      // 更新查询意图中的人名
      queryIntent.query.filters.entities.people = matchedPeople;
      console.log('更新后的人名列表:', queryIntent.query.filters.entities.people);
    }
    
    // 1.5.2 项目和主题的模糊匹配
    // 🔄 使用新的 memorySystem API 获取所有已知项目和主题
    await memorySystem.initialize();
    const knownProjects = await memorySystem.cloudStorage.getAllKnownProjects();
    const knownTopics = await memorySystem.cloudStorage.getAllKnownTopics();
    console.log('已知项目列表:', knownProjects);
    console.log('已知主题列表:', knownTopics);
    
    // 项目模糊匹配
    if (queryIntent?.query?.filters?.entities?.projects?.length > 0) {
      const matchedProjects = [];
      for (const project of queryIntent.query.filters.entities.projects) {
        const matchedNames = fuzzyMatchEntityName(project.name, knownProjects);
        if (matchedNames.length > 0) {
          console.log(`项目模糊匹配: "${project.name}" => `, matchedNames);
          matchedNames.forEach(name => {
            matchedProjects.push({
              name,
              status: project.status,
              required: project.required
            });
          });
        } else {
          // 如果项目没匹配到，检查是否可以在主题中找到
          const matchedTopics = fuzzyMatchEntityName(project.name, knownTopics);
          if (matchedTopics.length > 0) {
            console.log(`项目在主题中匹配: "${project.name}" => `, matchedTopics);
            // 将匹配到的主题添加到主题列表中
            if (!queryIntent.query.filters.entities.topics) {
              queryIntent.query.filters.entities.topics = [];
            }
            matchedTopics.forEach(name => {
              queryIntent.query.filters.entities.topics.push({
                name,
                category: '',
                required: project.required
              });
            });
          } else {
            matchedProjects.push(project);
          }
        }
      }
      
      // 更新查询意图中的项目
      queryIntent.query.filters.entities.projects = matchedProjects;
    }
    
    // 主题模糊匹配
    if (queryIntent?.query?.filters?.entities?.topics?.length > 0) {
      const matchedTopics = [];
      for (const topic of queryIntent.query.filters.entities.topics) {
        const matchedNames = fuzzyMatchEntityName(topic.name, knownTopics);
        if (matchedNames.length > 0) {
          console.log(`主题模糊匹配: "${topic.name}" => `, matchedNames);
          matchedNames.forEach(name => {
            matchedTopics.push({
              name,
              category: topic.category,
              required: topic.required
            });
          });
        } else {
          // 如果主题没匹配到，检查是否可以在项目中找到
          const matchedProjects = fuzzyMatchEntityName(topic.name, knownProjects);
          if (matchedProjects.length > 0) {
            console.log(`主题在项目中匹配: "${topic.name}" => `, matchedProjects);
            // 将匹配到的项目添加到项目列表中
            if (!queryIntent.query.filters.entities.projects) {
              queryIntent.query.filters.entities.projects = [];
            }
            matchedProjects.forEach(name => {
              queryIntent.query.filters.entities.projects.push({
                name,
                status: '',
                required: topic.required
              });
            });
          } else {
            matchedTopics.push(topic);
          }
        }
      }
      
      // 更新查询意图中的主题
      queryIntent.query.filters.entities.topics = matchedTopics;
    }
    
    // 1.5.3 特殊处理：如果用户查询既没有指定项目也没有指定主题，但问题中含有实体名称，尝试从两者中匹配
    if ((!queryIntent?.query?.filters?.entities?.projects?.length) && 
        (!queryIntent?.query?.filters?.entities?.topics?.length)) {
      
      // 从问题中提取可能的实体名称（简单策略：提取所有名词短语）
      const words = question.split(/\s+/);
      for (let i = 0; i < words.length; i++) {
        // 尝试不同长度的词组
        for (let j = Math.min(i + 3, words.length); j > i; j--) {
          const phrase = words.slice(i, j).join(' ');
          
          // 在项目中查找
          const matchedProjects = fuzzyMatchEntityName(phrase, knownProjects);
          if (matchedProjects.length > 0) {
            console.log(`从问题中提取项目: "${phrase}" => `, matchedProjects);
            if (!queryIntent.query.filters.entities.projects) {
              queryIntent.query.filters.entities.projects = [];
            }
            matchedProjects.forEach(name => {
              queryIntent.query.filters.entities.projects.push({
                name,
                status: '',
                required: true
              });
            });
          }
          
          // 在主题中查找
          const matchedTopics = fuzzyMatchEntityName(phrase, knownTopics);
          if (matchedTopics.length > 0) {
            console.log(`从问题中提取主题: "${phrase}" => `, matchedTopics);
            if (!queryIntent.query.filters.entities.topics) {
              queryIntent.query.filters.entities.topics = [];
            }
            matchedTopics.forEach(name => {
              queryIntent.query.filters.entities.topics.push({
                name,
                category: '',
                required: true
              });
            });
          }
        }
      }
    }
    
    // 去重（基于name字段）
    if (queryIntent?.query?.filters?.entities?.projects) {
      queryIntent.query.filters.entities.projects = Array.from(
        new Map(queryIntent.query.filters.entities.projects.map((item: { name: string }) => [item.name, item])).values()
      );
    }
    if (queryIntent?.query?.filters?.entities?.topics) {
      queryIntent.query.filters.entities.topics = Array.from(
        new Map(queryIntent.query.filters.entities.topics.map((item: { name: string }) => [item.name, item])).values()
      );
    }
    
    console.log('最终查询意图:', queryIntent);
    
    // 2. 构建查询过滤条件
    const filters: any = {};
    
    // 添加安全检查，确保 queryIntent 结构完整
    if (queryIntent?.query?.filters) {
      // 复制实体过滤器
      if (queryIntent.query.filters.entities) {
        filters.entities = queryIntent.query.filters.entities;
      }
      
      // 复制时间范围
      if (queryIntent.query.filters.time_range) {
        filters.time_range = queryIntent.query.filters.time_range;
      }
    }
    
    // 设置输出选项
    const output = queryIntent?.query?.output || {
      format: "list",
      limit: 20,
      sort: {
        field: "timestamp",
        order: "desc" as const
      }
    };
    
    // 4. 🔄 使用新的 memorySystem API 查询消息
    let queryResults;
    try {
      await memorySystem.initialize();
      
      // 转换时间范围格式
      const timeRange = filters.time_range && filters.time_range.start && filters.time_range.end
        ? { start: filters.time_range.start, end: filters.time_range.end }
        : undefined;
      
      // 使用 getSimilarMessages 替代 naturalLanguageQuery
      const messages = await memorySystem.cloudStorage.getSimilarMessages(question, {
        limit: output.limit || 20,
        minRelevanceScore: 0.3,
        timeRange,
        sortBy: output.sort?.field === 'timestamp' ? 'time' : 'relevance',
        sortOrder: output.sort?.order || 'desc',
        filters: {
          source: filters.source,
          teamName: filters.teamName,
          entities: filters.entities,
          metadata: filters.metadata
        }
      });
      
      // 转换为兼容的格式
      queryResults = {
        question: question,
        results: {
          ids: messages.map(m => m.id),
          documents: messages.map(m => m.content),
          metadatas: messages.map(m => ({
            sender: m.sender,
            source: m.sender,
            groupName: m.groupName,
            groupUrl: m.groupUrl,
            datetime: m.datetime,
            summary: m.summary,
            matchedRules: m.matchedRules,
            contextMessages: m.contextMessages
          })),
          distances: messages.map(m => 1 - (m.relevanceScore || 0))
        }
      };
      console.log('queryResults', queryResults, new Date().getTime());
    } catch (error) {
      console.error('向量数据库查询失败:', error);
      queryResults = {
        question: question,
        results: {
          ids: [],
          documents: [],
          metadatas: [],
          distances: []
        }
      };
    }
    
    // 添加空值检查
    if (!queryResults) {
      console.warn('向量数据库查询返回空结果');
      queryResults = {
        question: question,
        results: {
          ids: [],
          documents: [],
          metadatas: [],
          distances: []
        }
      };
    }
    
    const { question: formattedQuestion, results } = queryResults;
    
    if (!results || !results.documents || results.documents.length === 0) {
      return {
        success: false,
        message: `没有找到关于"${question}"的相关信息。`
      };
    }
     console.log('results', !results, !results.documents, results.documents.length === 0, new Date().getTime());
    // 5. 根据查询类型构建不同的提示模板
    let promptTemplate = "";
    
    switch (queryIntent?.query?.intent?.secondary) {
      case "project_status":
        promptTemplate = `
        以下是关于项目的一些信息:
        {{context}}
        
        基于以上信息,请分析并回答关于项目进展的问题:
        ${formattedQuestion}
        
        请包括:
        1. 项目当前进展
        2. 存在的风险和挑战
        3. 下一步计划
        `;
        break;
        
      case "person_info":
        promptTemplate = `
        以下是关于{{person}}的一些信息:
        {{context}}
        
        基于这些信息,请回答:
        ${formattedQuestion}
        
        请分析此人:
        1. 关注的重点话题/项目
        2. 交流和决策风格
        3. 可能的兴趣和关注点
        `;
        break;
        
      case "topic_discussion":
        promptTemplate = `
        以下是关于"{{topic}}"话题的相关信息:
        {{context}}
        
        基于这些信息,请回答:
        ${formattedQuestion}
        
        请分析:
        1. 这个话题的主要讨论点
        2. 不同观点和立场
        3. 最新的发展或决策
        `;
        break;
        
      case "action_items":
        promptTemplate = `
        以下是一些可能包含行动项的消息:
        {{context}}
        
        基于这些信息,请回答:
        ${formattedQuestion}
        
        请列出:
        1. 所有需要注意的行动项
        2. 各项的截止日期(如有提及)
        3. 负责人(如有提及)
        `;
        break;
        
      default:
        promptTemplate = `
        以下是与问题"${formattedQuestion}"相关的信息:
        {{context}}
        
        请基于以上信息提供详细回答。仅使用提供的信息,不要添加额外知识。
        如果信息不足,请明确指出。
        `;
    }
    
    // 6. 插入上下文
    const messagesContext = results.documents
      .map((doc, idx) => {
        const metadata = results.metadatas[idx];
        const source = metadata.source;
        const date = new Date(Number(metadata.timestamp)).toLocaleString();
        return `[${date} - ${source}] ${doc}`;
      })
      .join('\n\n');
      
    let prompt = promptTemplate.replace('{{context}}', messagesContext);
    
    // 替换实体
    if (queryIntent?.query?.intent?.secondary === "person_info" && 
        queryIntent?.query?.filters?.entities?.people?.length > 0) {
      prompt = prompt.replace('{{person}}', queryIntent.query.filters.entities.people[0].name);
    }
    
    if (queryIntent?.query?.intent?.secondary === "topic_discussion" && 
        queryIntent?.query?.filters?.entities?.topics?.length > 0) {
      prompt = prompt.replace('{{topic}}', queryIntent.query.filters.entities.topics[0].name);
    }
    
    // 7. 调用 LLM 生成回答
    const llmResponse = await handleLLMRequest({prompt});
    
    // 8. 构建符合 QueryResult 接口的结果
    const formattedResults = results.documents.map((doc, idx) => {
      const metadata = results.metadatas[idx] as Record<string, string | number | boolean>;
      const id = String(results.ids[idx]);
      const relevance = Math.max(0, 1 - results.distances[idx]); // 余弦距离：1-distance转换为相关性分数 (0-1)
      
      // 解析标签
      let tags: string[] = [];
      try {
        if (metadata.tags) {
          tags = JSON.parse(String(metadata.tags));
        } else if (metadata.category) {
          tags = JSON.parse(String(metadata.category));
        }
      } catch (e) {
        console.error('解析标签失败:', e);
        tags = [];
      }
      
      // 构建群组信息
      const groupInfo = metadata.grName || metadata.groupId ? {
        name: String(metadata.groupName || '未知群组'),
        id: String(metadata.groupId || ''),
        url: metadata.groupId ? `https://app.ringcentral.com/messages/${metadata.groupId}` : ''
      } : undefined;
      
      // 构建 QueryResult 对象
      return {
        id: id,
        summary: String(metadata.summary) || doc.substring(0, 100) + '...',
        details: String(metadata.details || doc),
        timestamp: new Date(Number(metadata.timestamp)).toISOString(),
        source: String(metadata.source),
        relevance: relevance,
        tags: tags,
        team: groupInfo,
        reply_advice: metadata.reply_advice || ''
      };
    });
    
    return {
      success: true,
      analysis: llmResponse,
      relatedMessages: results.documents.length,
      queryIntent: queryIntent,
      results: formattedResults
    };
  } catch (error) {
    console.error('通用查询失败:', error);
    return {
      success: false,
      message: '查询时发生错误,请稍后再试。'
    };
  }
  */
}

// 实现 callLLMJsonAPI 函数
async function callLLMJsonAPI(body) {
  // 复用现有的 LLM 请求代码
  const response = await handleLLMRequest(body);
  const jsonData = extractJsonFromResponse(response);
  return jsonData;
}

// 通用聊天消息接口

// OPENAI聊天实现
class OpenAIChat {
  // 存储不同会话的历史记录

  constructor(apiKey) {
    let baseUrl = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'https://api.openai.com/v1';
    // OpenAI实例
    this.conversationId = '';
    // 添加会话ID存储
    this.conversationHistory = new Map();
    this.apiKey = apiKey;
    this.baseUrl = baseUrl;

    // 初始化OpenAI客户端
    this.openai = new OpenAI({
      apiKey: this.apiKey,
      baseURL: this.baseUrl,
      dangerouslyAllowBrowser: true
    });
  }

  // 重置会话，开始新对话
  resetConversation() {
    this.conversationId = '';
    return this;
  }

  // 设置会话ID
  setConversationId(id) {
    this.conversationId = id;
    if (!this.conversationHistory.has(id)) {
      this.conversationHistory.set(id, []);
    }
    return this;
  }

  // 获取当前会话ID
  getConversationId() {
    return this.conversationId;
  }

  // 获取当前会话的历史记录
  getConversationHistory() {
    return this.conversationHistory.get(this.conversationId) || [];
  }
  async chat(options) {
    const {
      model,
      messages,
      temperature = 0.7,
      max_tokens,
      stream = false,
      onMessage,
      onComplete,
      onError
    } = options;
    try {
      // 如果没有会话ID，创建一个新的
      if (!this.conversationId) {
        this.conversationId = Date.now().toString();
        this.conversationHistory.set(this.conversationId, []);
      }

      // 获取当前会话的历史记录
      const history = this.conversationHistory.get(this.conversationId) || [];
      const tokenLimit = model.includes('gpt-4') ? 8000 : 4000; // 根据模型调整
      const optimizedHistory = this.optimizeHistory(history, tokenLimit);
      const allMessages = [...optimizedHistory, ...messages];

      // 使用OpenAI SDK
      if (stream) {
        const stream = await this.openai.chat.completions.create({
          model,
          messages: allMessages,
          temperature,
          max_tokens,
          stream: true
        });
        let fullResponse = '';
        for await (const part of stream) {
          const content = part.choices[0]?.delta?.content || '';
          if (content) {
            fullResponse += content;
            onMessage?.(content);
          }
        }

        // 更新会话历史
        if (fullResponse) {
          history.push(...messages); // 添加用户消息
          history.push({
            role: 'assistant',
            content: fullResponse
          }); // 添加助手回复
          this.conversationHistory.set(this.conversationId, history);
        }
        onComplete?.(fullResponse);
        return fullResponse;
      } else {
        const completion = await this.openai.chat.completions.create({
          model,
          messages: allMessages,
          temperature,
          max_tokens
        });
        const content = completion.choices[0].message.content || '';

        // 更新会话历史
        if (content) {
          history.push(...messages); // 添加用户消息
          history.push({
            role: 'assistant',
            content
          }); // 添加助手回复
          this.conversationHistory.set(this.conversationId, history);
        }
        onComplete?.(content);
        return content;
      }
    } catch (error) {
      onError?.(error);
      throw error;
    }
  }
  optimizeHistory(messages) {
    let maxTokens = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 4000;
    // 如果消息数量少，直接返回
    if (messages.length <= 3) return messages;

    // 保留系统消息
    const systemMessages = messages.filter(m => m.role === 'system');

    // 获取非系统消息
    let conversationMessages = messages.filter(m => m.role !== 'system');

    // 估算当前token数量（简单估算：每4个字符约1个token）
    const estimateTokens = msgs => {
      return msgs.reduce((sum, msg) => sum + Math.ceil(msg.content.length / 4), 0);
    };

    // 如果预估token数量超过限制，开始裁剪历史
    let estimatedTokens = estimateTokens(conversationMessages);

    // 保留最新的消息，逐步移除较早的消息对
    while (estimatedTokens > maxTokens && conversationMessages.length > 2) {
      // 移除最早的一对对话（用户+助手）
      conversationMessages = conversationMessages.slice(2);
      estimatedTokens = estimateTokens(conversationMessages);
    }

    // 合并系统消息和优化后的对话
    return [...systemMessages, ...conversationMessages];
  }
}

// DIFY聊天实现
class DifyChat {
  // 添加会话ID存储

  constructor(apiKey, baseUrl) {
    this.conversationId = '';
    this.apiKey = apiKey;
    this.baseUrl = baseUrl;
  }

  // 重置会话，开始新对话
  resetConversation() {
    this.conversationId = '';
    return this;
  }

  // 设置会话ID
  setConversationId(id) {
    this.conversationId = id;
    return this;
  }

  // 获取当前会话ID
  getConversationId() {
    return this.conversationId;
  }
  async chat(options) {
    const {
      messages,
      temperature = 0.7,
      stream = false,
      onMessage,
      onComplete,
      onError
    } = options;

    // 提取用户输入（最后一条用户消息）
    const userInput = messages.filter(m => m.role === 'user').pop()?.content || '';

    // 提取历史消息
    const history = messages.slice(0, -1).map(m => ({
      role: m.role,
      content: m.content
    }));
    try {
      const requestBody = {
        inputs: {},
        query: userInput,
        response_mode: stream ? 'streaming' : 'blocking',
        user: 'user-id',
        // 可自定义
        temperature
      };

      // 如果有会话ID，添加到请求中
      if (this.conversationId) {
        requestBody.conversation_id = this.conversationId;
      }

      // 只在没有会话ID时添加历史消息
      if (!this.conversationId && history.length > 0) {
        requestBody.history = history;
      }
      const response = await fetch(`${this.baseUrl}/chat-messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify(requestBody)
      });
      if (stream) {
        // 处理流式响应
        const reader = response.body?.getReader();
        let fullResponse = '';
        let metaDataProcessed = false;
        if (reader) {
          let isDone = false;
          while (!isDone) {
            const {
              done,
              value
            } = await reader.read();
            isDone = done;
            if (done) break;
            const chunk = new TextDecoder().decode(value);
            const lines = chunk.split('\n').filter(line => line.trim());
            for (const line of lines) {
              try {
                const json = JSON.parse(line);

                // 保存会话ID (只需处理一次)
                if (!metaDataProcessed && json.conversation_id) {
                  this.conversationId = json.conversation_id;
                  metaDataProcessed = true;
                }
                if (json.event === 'message' && json.data) {
                  fullResponse += json.data.answer || '';
                  onMessage?.(json.data.answer || '');
                }
              } catch (e) {
                // 忽略解析错误
              }
            }
          }
          onComplete?.(fullResponse);
        }
      } else {
        const json = await response.json();

        // 保存会话ID
        if (json.conversation_id) {
          this.conversationId = json.conversation_id;
        }
        const content = json.answer || '';
        onComplete?.(content);
        return content;
      }
    } catch (error) {
      onError?.(error);
      throw error;
    }
  }
}

// GROQ聊天实现
class GroqChat {
  // 存储不同会话的历史记录

  constructor(apiKey) {
    // Groq实例
    this.conversationId = '';
    // 添加会话ID存储
    this.conversationHistory = new Map();
    this.apiKey = apiKey;

    // 初始化Groq客户端
    this.groq = new Groq({
      apiKey: this.apiKey,
      dangerouslyAllowBrowser: true
    });
  }

  // 重置会话，开始新对话
  resetConversation() {
    this.conversationId = '';
    return this;
  }

  // 设置会话ID
  setConversationId(id) {
    this.conversationId = id;
    if (!this.conversationHistory.has(id)) {
      this.conversationHistory.set(id, []);
    }
    return this;
  }

  // 获取当前会话ID
  getConversationId() {
    return this.conversationId;
  }

  // 获取当前会话的历史记录
  getConversationHistory() {
    return this.conversationHistory.get(this.conversationId) || [];
  }
  async chat(options) {
    const {
      model,
      messages,
      temperature = 0.7,
      max_tokens,
      stream = false,
      onMessage,
      onComplete,
      onError
    } = options;
    try {
      // 如果没有会话ID，创建一个新的
      if (!this.conversationId) {
        this.conversationId = Date.now().toString();
        this.conversationHistory.set(this.conversationId, []);
      }

      // 获取当前会话的历史记录
      const history = this.conversationHistory.get(this.conversationId) || [];
      const tokenLimit = model.includes('gpt-4') ? 8000 : 4000; // 根据模型调整
      const optimizedHistory = this.optimizeHistory(history, tokenLimit);
      const allMessages = [...optimizedHistory, ...messages];

      // 使用Groq SDK
      if (stream) {
        const stream = await this.groq.chat.completions.create({
          model,
          messages: allMessages,
          temperature,
          max_tokens,
          stream: true
        });
        let fullResponse = '';
        for await (const part of stream) {
          const content = part.choices[0]?.delta?.content || '';
          if (content) {
            fullResponse += content;
            onMessage?.(content);
          }
        }

        // 更新会话历史
        if (fullResponse) {
          history.push(...messages); // 添加用户消息
          history.push({
            role: 'assistant',
            content: fullResponse
          }); // 添加助手回复
          this.conversationHistory.set(this.conversationId, history);
        }
        onComplete?.(fullResponse);
        return fullResponse;
      } else {
        const completion = await this.groq.chat.completions.create({
          model,
          messages: allMessages,
          temperature,
          max_tokens
        });
        const content = completion.choices[0].message.content || '';

        // 更新会话历史
        if (content) {
          history.push(...messages); // 添加用户消息
          history.push({
            role: 'assistant',
            content
          }); // 添加助手回复
          this.conversationHistory.set(this.conversationId, history);
        }
        onComplete?.(content);
        return content;
      }
    } catch (error) {
      onError?.(error);
      throw error;
    }
  }
  optimizeHistory(messages) {
    let maxTokens = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 4000;
    // 如果消息数量少，直接返回
    if (messages.length <= 3) return messages;

    // 保留系统消息
    const systemMessages = messages.filter(m => m.role === 'system');

    // 获取非系统消息
    let conversationMessages = messages.filter(m => m.role !== 'system');

    // 估算当前token数量（简单估算：每4个字符约1个token）
    const estimateTokens = msgs => {
      return msgs.reduce((sum, msg) => sum + Math.ceil(msg.content.length / 4), 0);
    };

    // 如果预估token数量超过限制，开始裁剪历史
    let estimatedTokens = estimateTokens(conversationMessages);

    // 保留最新的消息，逐步移除较早的消息对
    while (estimatedTokens > maxTokens && conversationMessages.length > 2) {
      // 移除最早的一对对话（用户+助手）
      conversationMessages = conversationMessages.slice(2);
      estimatedTokens = estimateTokens(conversationMessages);
    }

    // 合并系统消息和优化后的对话
    return [...systemMessages, ...conversationMessages];
  }
}

// Ollama聊天实现
class OllamaChat {
  // 存储不同会话的历史记录

  constructor() {
    let baseUrl = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'http://localhost:11434';
    this.conversationId = '';
    // 移除了`: string`类型注解
    this.conversationHistory = new Map();
    this.baseUrl = baseUrl;
  }

  // 重置会话，开始新对话
  resetConversation() {
    this.conversationId = '';
    return this;
  }

  // 设置会话ID
  setConversationId(id) {
    this.conversationId = id;
    if (!this.conversationHistory.has(id)) {
      this.conversationHistory.set(id, []);
    }
    return this;
  }

  // 获取当前会话ID
  getConversationId() {
    return this.conversationId;
  }

  // 获取当前会话的历史记录
  getConversationHistory() {
    return this.conversationHistory.get(this.conversationId) || [];
  }
  async chat(options) {
    const {
      model,
      messages,
      temperature = 0.7,
      stream = false,
      onMessage,
      onComplete,
      onError
    } = options;
    try {
      // 如果没有会话ID，创建一个新的
      if (!this.conversationId) {
        this.conversationId = Date.now().toString();
        this.conversationHistory.set(this.conversationId, []);
      }

      // 获取当前会话的历史记录
      const history = this.conversationHistory.get(this.conversationId) || [];

      // 合并历史记录和新消息，转换为Ollama的格式
      const allMessages = [...history, ...messages].map(m => ({
        role: m.role,
        content: m.content
      }));
      const response = await fetch(`${this.baseUrl}/api/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model,
          messages: allMessages,
          temperature,
          stream
        })
      });
      if (stream) {
        // 处理流式响应
        const reader = response.body?.getReader();
        let fullResponse = '';
        if (reader) {
          let isDone = false;
          while (!isDone) {
            const {
              done,
              value
            } = await reader.read();
            isDone = done;
            if (done) break;
            const chunk = new TextDecoder().decode(value);
            const lines = chunk.split('\n').filter(line => line.trim());
            for (const line of lines) {
              try {
                const json = JSON.parse(line);
                if (json.message && json.message.content) {
                  const content = json.message.content;
                  fullResponse += content;
                  onMessage?.(content);
                }
              } catch (e) {
                // 忽略解析错误
              }
            }
          }

          // 更新会话历史
          if (fullResponse) {
            history.push(...messages); // 添加用户消息
            history.push({
              role: 'assistant',
              content: fullResponse
            }); // 添加助手回复
            this.conversationHistory.set(this.conversationId, history);
          }
          onComplete?.(fullResponse);
        }
      } else {
        const json = await response.json();
        const content = json.message?.content || '';

        // 更新会话历史
        if (content) {
          history.push(...messages); // 添加用户消息
          history.push({
            role: 'assistant',
            content
          }); // 添加助手回复
          this.conversationHistory.set(this.conversationId, history);
        }
        onComplete?.(content);
        return content;
      }
    } catch (error) {
      onError?.(error);
      throw error;
    }
  }
}

// ==================== 自动答复相关函数 ====================

/**
 * 生成自动答复内容
 * @param messageContext 消息上下文
 * @returns 生成的答复内容
 */
async function generateAutoReply(messageContext) {
  // 如果有用户模板，生成风格参考提示
  const templateHint = messageContext.replyTemplate ? `\n用户期望的答复风格参考："${messageContext.replyTemplate}"\n请保持这个风格和内容目的，但换一种表达方式，让每次答复略有不同。` : '';
  const prompt = `请根据以下消息生成一个简短的自动答复：

消息内容：${messageContext.messageContent}
发送者：${messageContext.sender}
群组：${messageContext.groupName || '私聊'}
上下文总结：${messageContext.summary || '无'}
${templateHint}

要求：
1. 简短（1-2句话）
2. ${messageContext.replyTemplate ? '保持用户的答复风格，但措辞略有变化' : '礼貌且专业'}
3. 使用与原消息相同的语言

只返回答复内容，不要包含其他解释。`;
  try {
    const response = await handleLLMRequest({
      prompt,
      type: 'auto_reply'
    });
    // 清理可能的思考标签
    const cleanedResponse = response.replace(/<think>[\s\S]*?<\/think>/g, '').trim();
    return cleanedResponse;
  } catch (error) {
    console.error('生成自动答复失败:', error);
    throw error;
  }
}

/**
 * 判断两条消息内容是否语义相似
 * @param content1 消息1
 * @param content2 消息2
 * @returns 是否相似
 */
async function isContentSimilar(content1, content2) {
  const prompt = `请判断以下两条消息是否表达类似的意思：

消息1：${content1}
消息2：${content2}

如果两条消息的核心意图相似，请回复"相似"，否则回复"不相似"。
只返回一个词，不要其他内容。`;
  try {
    const response = await handleLLMRequest({
      prompt,
      type: 'similarity'
    });
    // 清理可能的思考标签
    const cleanedResponse = response.replace(/<think>[\s\S]*?<\/think>/g, '').trim();
    return cleanedResponse.includes('相似') && !cleanedResponse.includes('不相似');
  } catch (error) {
    console.error('判断内容相似度失败:', error);
    return false; // 出错时默认返回不相似，避免错误触发
  }
}

// 导出所有实现


/***/ }),

/***/ 6939:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  memorySystem: () => (/* binding */ memorySystem)
});

// UNUSED EXPORTS: MemorySystem

// EXTERNAL MODULE: ./src/storage/CloudStorage.ts
var CloudStorage = __webpack_require__(8143);
// EXTERNAL MODULE: ./src/storage/LocalStorage.ts
var LocalStorage = __webpack_require__(7997);
;// CONCATENATED MODULE: ./src/storage/EntitySimilarityTool.ts
/**
 * 实体相似性管理工具
 * 负责实体的相似性判断、自动合并和用户确认流程
 */

/**
 * 实体相似性管理器
 */
class EntitySimilarityTool {
  constructor() {
    this.pendingMerges = new Map();
    this.mergeCandidatesCache = new Map();
    // 相似性阈值配置
    this.THRESHOLDS = {
      AUTO_MERGE: 0.9,
      // 自动合并阈值
      CANDIDATE_MARK: 0.7,
      // 候选标记阈值
      DEEP_ANALYSIS: 0.75 // 深度分析确认阈值
    };
    this.loadPendingMerges();
  }

  /**
   * 处理新实体（主入口）
   */
  async processEntity(entity) {
    const now = Date.now();
    const fullEntity = {
      ...entity,
      id: entity.type + '_' + entity.name,
      created: now,
      updated: now,
      accessCount: 0,
      lastAccessed: now,
      importance: entity.importance || 0.5
    };

    // 进行相似性检查
    const similarityResult = await this.quickSimilarityCheck(fullEntity);
    const processedEntity = {
      ...fullEntity,
      action: similarityResult.action,
      targetId: similarityResult.targetEntity?.id,
      mergeReason: similarityResult.reasoning
    };
    return processedEntity;
  }

  /**
   * 批量处理实体
   */
  async processEntities(entities) {
    const results = [];
    for (const entity of entities) {
      try {
        const processed = await this.processEntity(entity);
        results.push(processed);
      } catch (error) {
        console.error('处理实体失败:', error);
        // 继续处理其他实体
      }
    }
    return results;
  }

  /**
   * 实时简单相似性判断
   */
  async quickSimilarityCheck(newEntity) {
    try {
      // 1. 查找候选实体
      const candidates = await this.findCandidateEntities(newEntity);
      if (candidates.length === 0) {
        return {
          action: 'create_new',
          confidence: 0
        };
      }

      // 2. 计算与每个候选的相似度
      let bestMatch = null;
      for (const candidate of candidates) {
        const similarity = this.calculateQuickSimilarity(newEntity, candidate);
        if (!bestMatch || similarity > bestMatch.similarity) {
          bestMatch = {
            entity: candidate,
            similarity
          };
        }
      }
      if (!bestMatch) {
        return {
          action: 'create_new',
          confidence: 0
        };
      }

      // 3. 根据阈值决定行动
      if (bestMatch.similarity > this.THRESHOLDS.AUTO_MERGE) {
        return {
          action: 'auto_merge',
          targetEntity: bestMatch.entity,
          confidence: bestMatch.similarity,
          reasoning: '高相似度自动合并'
        };
      } else if (bestMatch.similarity > this.THRESHOLDS.CANDIDATE_MARK) {
        return {
          action: 'mark_candidate',
          targetEntity: bestMatch.entity,
          confidence: bestMatch.similarity,
          reasoning: '中等相似度，标记为候选'
        };
      } else {
        return {
          action: 'create_new',
          confidence: bestMatch.similarity,
          reasoning: '相似度较低，创建新实体'
        };
      }
    } catch (error) {
      console.error('快速相似性检查失败:', error);
      return {
        action: 'create_new',
        confidence: 0,
        reasoning: '检查失败，创建新实体'
      };
    }
  }

  /**
   * 查找候选实体（简化版本）
   */
  async findCandidateEntities(entity) {
    // 这里是简化版本，实际实现中需要从缓存中查找相同类型的实体
    const cacheKey = `candidates_${entity.type}`;
    if (this.mergeCandidatesCache.has(cacheKey)) {
      return this.mergeCandidatesCache.get(cacheKey);
    }

    // 在实际实现中，这里应该从 LocalCache 中获取相同类型的实体
    // 暂时返回空数组
    return [];
  }

  /**
   * 计算快速相似度
   */
  calculateQuickSimilarity(entity1, entity2) {
    let similarity = 0;

    // 类型必须相同
    if (entity1.type !== entity2.type) {
      return 0;
    }

    // 名称相似度（权重50%）
    const nameSimilarity = this.stringSimilarity(entity1.name, entity2.name);
    similarity += nameSimilarity * 0.5;

    // 描述相似度（权重30%）
    if (entity1.description && entity2.description) {
      const descSimilarity = this.stringSimilarity(entity1.description, entity2.description);
      similarity += descSimilarity * 0.3;
    }

    // 属性相似度（权重20%）
    const propsSimilarity = this.propertiesSimilarity(entity1.properties, entity2.properties);
    similarity += propsSimilarity * 0.2;
    return similarity;
  }

  /**
   * 字符串相似度计算
   */
  stringSimilarity(str1, str2) {
    if (str1 === str2) return 1;
    if (!str1 || !str2) return 0;
    const longer = str1.length > str2.length ? str1 : str2;
    // shorter 变量保留供将来使用
    const _shorter = str1.length > str2.length ? str2 : str1;
    if (longer.length === 0) return 1;

    // 简化的编辑距离算法
    const editDistance = this.levenshteinDistance(str1.toLowerCase(), str2.toLowerCase());
    return (longer.length - editDistance) / longer.length;
  }

  /**
   * 计算编辑距离
   */
  levenshteinDistance(str1, str2) {
    const matrix = [];
    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i];
    }
    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j;
    }
    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
        }
      }
    }
    return matrix[str2.length][str1.length];
  }

  /**
   * 属性相似度计算
   */
  propertiesSimilarity(props1, props2) {
    const keys1 = Object.keys(props1);
    const keys2 = Object.keys(props2);
    const allKeys = new Set([...keys1, ...keys2]);
    if (allKeys.size === 0) return 1;
    let matchingProps = 0;
    for (const key of allKeys) {
      const val1 = props1[key];
      const val2 = props2[key];
      if (val1 !== undefined && val2 !== undefined) {
        if (typeof val1 === 'string' && typeof val2 === 'string') {
          const similarity = this.stringSimilarity(val1, val2);
          if (similarity > 0.8) matchingProps++;
        } else if (val1 === val2) {
          matchingProps++;
        }
      }
    }
    return matchingProps / allKeys.size;
  }

  /**
   * 获取待处理的合并候选
   */
  async getPendingMerges() {
    return Array.from(this.pendingMerges.values());
  }

  /**
   * 确认合并
   */
  async confirmMerge(mergeId) {
    const mergePair = this.pendingMerges.get(mergeId);
    if (!mergePair) return false;
    try {
      mergePair.status = 'approved';
      await this.savePendingMerges();
      return true;
    } catch (error) {
      console.error('确认合并失败:', error);
      return false;
    }
  }

  /**
   * 拒绝合并
   */
  async rejectMerge(mergeId) {
    const mergePair = this.pendingMerges.get(mergeId);
    if (!mergePair) return false;
    try {
      mergePair.status = 'rejected';
      this.pendingMerges.delete(mergeId);
      await this.savePendingMerges();
      return true;
    } catch (error) {
      console.error('拒绝合并失败:', error);
      return false;
    }
  }

  /**
   * 保存待处理合并到存储
   */
  async savePendingMerges() {
    try {
      const data = Array.from(this.pendingMerges.entries());
      await chrome.storage.local.set({
        'pending_entity_merges': data
      });
    } catch (error) {
      console.error('保存待处理合并失败:', error);
    }
  }

  /**
   * 从存储加载待处理合并
   */
  async loadPendingMerges() {
    try {
      const result = await chrome.storage.local.get('pending_entity_merges');
      if (result.pending_entity_merges) {
        this.pendingMerges = new Map(result.pending_entity_merges);
      }
    } catch (error) {
      console.error('加载待处理合并失败:', error);
    }
  }

  /**
   * 调整阈值
   */
  adjustThresholds(newThresholds) {
    Object.assign(this.THRESHOLDS, newThresholds);
  }

  /**
   * 获取统计信息
   */
  getStatistics() {
    return {
      pendingMerges: this.pendingMerges.size,
      thresholds: {
        ...this.THRESHOLDS
      }
    };
  }
}

// 导出单例实例
const entitySimilarityTool = new EntitySimilarityTool();
;// CONCATENATED MODULE: ./src/storage/SystemMaintenanceTool.ts
/**
 * 系统维护工具
 * 负责健康监控、定时维护、数据清理等任务
 */

// 策略层接口定义（用于与 MemorySystem 交互）

/**
 * 系统维护工具
 */
class SystemMaintenanceTool {
  // 实体数量阈值

  constructor(cloudStorage, localStorage, strategyLayer) {
    this.isMonitoringActive = false;
    this.monitoringInterval = null;
    this.maintenanceInterval = null;
    this.MONITORING_INTERVAL = 5 * 60 * 1000;
    // 5分钟
    this.MAINTENANCE_INTERVAL = 6 * 60 * 60 * 1000;
    // 6小时
    this.CACHE_CLEANUP_THRESHOLD = 1000;
    this.cloudStorage = cloudStorage;
    this.localStorage = localStorage;
    this.strategyLayer = strategyLayer;
  }

  /**
   * 启动系统监控
   */
  startMonitoring() {
    if (this.isMonitoringActive) {
      console.log('⚠️ 系统监控已经在运行');
      return;
    }
    this.isMonitoringActive = true;

    // 启动健康监控
    this.monitoringInterval = setInterval(async () => {
      try {
        await this.performHealthCheck();
      } catch (error) {
        console.error('健康检查失败:', error);
      }
    }, this.MONITORING_INTERVAL);

    // 启动定期维护
    this.maintenanceInterval = setInterval(async () => {
      try {
        await this.performAutomaticMaintenance();
      } catch (error) {
        console.error('自动维护失败:', error);
      }
    }, this.MAINTENANCE_INTERVAL);
    console.log('🔍 系统监控已启动');
  }

  /**
   * 停止系统监控
   */
  stopMonitoring() {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
    if (this.maintenanceInterval) {
      clearInterval(this.maintenanceInterval);
      this.maintenanceInterval = null;
    }
    this.isMonitoringActive = false;
    console.log('🔍 系统监控已停止');
  }

  /**
   * 执行健康检查
   */
  async performHealthCheck() {
    const startTime = Date.now();
    const status = {
      timestamp: startTime,
      cloudStorage: {
        available: false,
        connected: false,
        entityCount: 0,
        lastSync: 0,
        errors: []
      },
      localCache: {
        available: false,
        entityCount: 0,
        relationshipCount: 0,
        cacheSize: 0,
        lastCleanup: 0,
        errors: []
      },
      overall: {
        status: 'offline',
        score: 0,
        issues: [],
        recommendations: []
      }
    };
    try {
      // 1. 检查云端存储
      await this.checkCloudStorageHealth(status);

      // 2. 检查本地缓存
      await this.checkLocalCacheHealth(status);

      // 3. 计算整体健康状态
      this.calculateOverallHealth(status);

      // 4. 生成建议
      this.generateRecommendations(status);

      // 5. 保存健康记录
      await this.saveHealthMetrics(status);
      console.log(`🏥 健康检查完成 - 状态: ${status.overall.status}, 评分: ${status.overall.score}`);
      return status;
    } catch (error) {
      console.error('❌ 健康检查失败:', error);
      status.overall.status = 'critical';
      status.overall.issues.push(`健康检查失败: ${error.message}`);
      return status;
    }
  }

  /**
   * 检查云端存储健康状态
   */
  async checkCloudStorageHealth(status) {
    try {
      status.cloudStorage.available = true;
      status.cloudStorage.connected = await this.cloudStorage.isConnected();
      if (status.cloudStorage.connected) {
        status.cloudStorage.entityCount = await this.cloudStorage.getEntityCount();
        status.cloudStorage.lastSync = await this.strategyLayer.getLastSyncTime();
      } else {
        status.cloudStorage.errors.push('云端存储连接失败');
      }
    } catch (error) {
      status.cloudStorage.errors.push(`云端存储检查失败: ${error.message}`);
    }
  }

  /**
   * 检查本地缓存健康状态
   */
  async checkLocalCacheHealth(status) {
    try {
      status.localCache.available = true;
      status.localCache.cacheSize = await this.localStorage.getCacheSize();

      // 获取实体统计
      const entityStats = await this.localStorage.getEntityStatistics();
      status.localCache.entityCount = entityStats.totalEntities;
      status.localCache.relationshipCount = entityStats.totalRelationships;

      // 检查缓存大小
      if (status.localCache.cacheSize > 4 * 1024 * 1024) {
        // 4MB
        status.localCache.errors.push('本地缓存大小超过4MB，建议清理');
      }

      // 检查实体数量
      if (status.localCache.entityCount > this.CACHE_CLEANUP_THRESHOLD) {
        status.localCache.errors.push(`实体数量过多(${status.localCache.entityCount})，建议清理`);
      }
    } catch (error) {
      status.localCache.errors.push(`本地缓存检查失败: ${error.message}`);
    }
  }

  /**
   * 计算整体健康状态
   */
  calculateOverallHealth(status) {
    let score = 100;
    const issues = [];

    // 云端存储健康度检查
    if (!status.cloudStorage.connected) {
      score -= 30;
      issues.push('云端存储连接异常');
    }

    // 本地缓存健康度检查
    if (status.localCache.errors.length > 0) {
      score -= 20;
      issues.push('本地缓存存在问题');
    }

    // 同步状态检查
    const lastSyncAge = Date.now() - status.cloudStorage.lastSync;
    if (lastSyncAge > 24 * 60 * 60 * 1000) {
      // 超过24小时
      score -= 25;
      issues.push('超过24小时未同步');
    }

    // 缓存大小检查
    if (status.localCache.cacheSize > 3 * 1024 * 1024) {
      // 3MB
      score -= 15;
      issues.push('本地缓存占用空间过大');
    }

    // 确定状态
    if (score >= 90) {
      status.overall.status = 'healthy';
    } else if (score >= 70) {
      status.overall.status = 'warning';
    } else if (score >= 40) {
      status.overall.status = 'critical';
    } else {
      status.overall.status = 'offline';
    }
    status.overall.score = Math.max(0, score);
    status.overall.issues = issues;
  }

  /**
   * 生成维护建议
   */
  generateRecommendations(status) {
    const recommendations = [];
    if (!status.cloudStorage.connected) {
      recommendations.push('检查网络连接，重新连接云端存储');
    }
    if (status.localCache.cacheSize > 3 * 1024 * 1024) {
      recommendations.push('执行缓存清理，释放本地存储空间');
    }
    if (status.localCache.entityCount > this.CACHE_CLEANUP_THRESHOLD) {
      recommendations.push('清理旧实体数据，保持缓存效率');
    }
    const lastSyncAge = Date.now() - status.cloudStorage.lastSync;
    if (lastSyncAge > 12 * 60 * 60 * 1000) {
      // 超过12小时
      recommendations.push('执行数据同步，保持数据一致性');
    }
    if (status.localCache.relationshipCount > 500) {
      recommendations.push('备份关系数据到云端，防止数据丢失');
    }
    status.overall.recommendations = recommendations;
  }

  /**
   * 执行自动维护
   */
  async performAutomaticMaintenance() {
    const startTime = Date.now();
    const result = {
      success: false,
      tasksCompleted: [],
      tasksFailed: [],
      cleanedEntities: 0,
      cleanedRelationships: 0,
      freedSpace: 0,
      totalTime: 0,
      nextMaintenanceTime: Date.now() + this.MAINTENANCE_INTERVAL
    };
    try {
      console.log('🔧 开始自动维护...');

      // 1. 清理过期缓存
      try {
        await this.localStorage.clearExpiredCache();
        result.tasksCompleted.push('清理过期缓存');
      } catch (error) {
        result.tasksFailed.push('清理过期缓存失败');
      }

      // 2. 检查并执行新设备同步
      try {
        const syncResult = await this.strategyLayer.performInitialSyncIfNeeded();
        if (syncResult.syncPerformed) {
          result.tasksCompleted.push(`新设备同步: ${syncResult.entitiesDownloaded} 个实体`);
        }
      } catch (error) {
        result.tasksFailed.push('新设备同步检查失败');
      }

      // 3. 备份关系数据（每天一次）
      try {
        const lastBackup = await this.getLastBackupTime();
        if (Date.now() - lastBackup > 24 * 60 * 60 * 1000) {
          const relationshipData = await this.localStorage.getRelationshipBackupData();
          if (relationshipData) {
            const backupSuccess = await this.cloudStorage.backupRelationships(relationshipData);
            if (backupSuccess) {
              result.tasksCompleted.push('备份关系数据');
              await this.setLastBackupTime(Date.now());
            } else {
              result.tasksFailed.push('备份关系数据失败');
            }
          }
        }
      } catch (error) {
        result.tasksFailed.push('关系数据备份失败');
      }

      // 4. 计算释放的空间
      const finalCacheSize = await this.localStorage.getCacheSize();
      result.freedSpace = Math.max(0, finalCacheSize);
      result.success = result.tasksFailed.length === 0;
      result.totalTime = Date.now() - startTime;
      console.log(`🔧 自动维护完成 - 成功: ${result.tasksCompleted.length}, 失败: ${result.tasksFailed.length}`);
      return result;
    } catch (error) {
      console.error('❌ 自动维护失败:', error);
      result.tasksFailed.push(`维护过程异常: ${error.message}`);
      result.totalTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 手动执行完整维护
   */
  async performFullMaintenance(options) {
    const startTime = Date.now();
    const opts = {
      cleanupEntities: true,
      cleanupRelationships: true,
      forceSync: false,
      backupData: true,
      cleanupExpiredConversations: true,
      // 🆕 默认启用
      ...options
    };
    const result = {
      success: false,
      tasksCompleted: [],
      tasksFailed: [],
      cleanedEntities: 0,
      cleanedRelationships: 0,
      freedSpace: 0,
      totalTime: 0,
      nextMaintenanceTime: Date.now() + this.MAINTENANCE_INTERVAL
    };
    try {
      console.log('🔧 开始完整维护...');
      const initialCacheSize = await this.localStorage.getCacheSize();

      // 1. 清理过期缓存
      try {
        await this.localStorage.clearExpiredCache();
        result.tasksCompleted.push('清理过期缓存');
      } catch (error) {
        result.tasksFailed.push('清理过期缓存失败');
      }

      // 2. 🆕 清理过期已读消息
      if (opts.cleanupExpiredConversations) {
        try {
          console.log('🧹 开始清理过期消息...');
          const cleanupResult = await this.cloudStorage.cleanExpiredReadConversations();
          result.tasksCompleted.push(`清理过期消息: ${cleanupResult.conversationsRemoved}条`);
          result.freedSpace += cleanupResult.spaceSaved;
          console.log(`✅ 清理完成: ${cleanupResult.conversationsRemoved}条消息, 节省${(cleanupResult.spaceSaved / 1024).toFixed(2)}KB`);
        } catch (error) {
          console.error('清理过期消息失败:', error);
          result.tasksFailed.push('清理过期消息失败');
        }
      }

      // 3. 强制同步（如果请求）
      if (opts.forceSync) {
        try {
          await this.strategyLayer.syncCache();
          result.tasksCompleted.push('强制同步缓存');
        } catch (error) {
          result.tasksFailed.push('强制同步失败');
        }
      }

      // 4. 备份数据（如果请求）
      if (opts.backupData) {
        try {
          const relationshipData = await this.localStorage.getRelationshipBackupData();
          if (relationshipData) {
            const backupSuccess = await this.cloudStorage.backupRelationships(relationshipData);
            if (backupSuccess) {
              result.tasksCompleted.push('备份关系数据');
            } else {
              result.tasksFailed.push('备份关系数据失败');
            }
          }
        } catch (error) {
          result.tasksFailed.push('数据备份失败');
        }
      }

      // 5. 计算释放的空间
      const finalCacheSize = await this.localStorage.getCacheSize();
      result.freedSpace += initialCacheSize - finalCacheSize;
      result.success = result.tasksFailed.length === 0;
      result.totalTime = Date.now() - startTime;
      console.log(`🔧 完整维护完成 - 成功: ${result.tasksCompleted.length}, 失败: ${result.tasksFailed.length}`);
      return result;
    } catch (error) {
      console.error('❌ 完整维护失败:', error);
      result.tasksFailed.push(`维护过程异常: ${error.message}`);
      result.totalTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 保存健康指标
   */
  async saveHealthMetrics(status) {
    try {
      await chrome.storage.local.set({
        'system_health_status': status,
        'system_health_timestamp': status.timestamp
      });
    } catch (error) {
      console.error('保存健康指标失败:', error);
    }
  }

  /**
   * 获取最后备份时间
   */
  async getLastBackupTime() {
    try {
      const result = await chrome.storage.local.get('last_backup_time');
      return result.last_backup_time || 0;
    } catch (error) {
      return 0;
    }
  }

  /**
   * 设置最后备份时间
   */
  async setLastBackupTime(time) {
    try {
      await chrome.storage.local.set({
        'last_backup_time': time
      });
    } catch (error) {
      console.error('设置备份时间失败:', error);
    }
  }

  /**
   * 获取系统状态
   */
  getSystemStatus() {
    return {
      isMonitoring: this.isMonitoringActive,
      monitoringInterval: this.MONITORING_INTERVAL,
      maintenanceInterval: this.MAINTENANCE_INTERVAL,
      nextMaintenance: Date.now() + this.MAINTENANCE_INTERVAL
    };
  }
}

// 创建工厂函数
function createSystemMaintenanceTool(cloudStorage, localStorage, strategyLayer) {
  return new SystemMaintenanceTool(cloudStorage, localStorage, strategyLayer);
}
// EXTERNAL MODULE: ./src/services/UserProfileManager.ts
var UserProfileManager = __webpack_require__(9857);
// EXTERNAL MODULE: ./src/services/entityExtraction.ts
var entityExtraction = __webpack_require__(8);
;// CONCATENATED MODULE: ./src/memory.ts
/**
 * 统一记忆系统接口层
 * 提供清晰的读取和存储接口，管理本地缓存和云端存储
 */








// 重新导出接口供其他模块使用（使用 export type 避免循环依赖）

// 查询结果接口

// 存储结果接口

// 查询选项

// 向量搜索选项

// 实体类型信息接口

// 实体类型配置
const ENTITY_TYPE_CONFIG = {
  'Person': {
    name: '人物',
    icon: '👥',
    description: '团队成员、联系人、项目相关人员等'
  },
  'Project': {
    name: '项目',
    icon: '🚀',
    description: '工作项目、产品开发、研究项目等'
  },
  'Task': {
    name: '任务',
    icon: '📋',
    description: '具体工作任务、待办事项、行动项等'
  },
  'Organization': {
    name: '组织',
    icon: '🏢',
    description: '公司、部门、团队、客户组织等'
  },
  'Document': {
    name: '文档',
    icon: '📄',
    description: '文件、资料、规范、报告等'
  },
  'Technology': {
    name: '技术',
    icon: '🔧',
    description: '技术栈、工具、框架、平台等'
  },
  'Topic': {
    name: '主题',
    icon: '💡',
    description: '讨论话题、知识领域、专业概念等'
  }
};

// 策略配置

// 性能指标

/**
 * 统一记忆系统管理器 - 现在直接充当策略层
 */
class MemorySystem {
  constructor() {
    // 🔓 改为 public，供 llm.ts 等模块访问
    this.userProfileManager = null;
    this.isInitialized = false;
    this.alarmListenerAdded = false;
    this.backgroundSyncStarted = false;
    this.isSyncing = false;
    this.initializationPromise = null;
    // 添加初始化Promise
    // 🆕 智能检索配置（ask() 方法专用）
    this.ASK_CONFIG = {
      MIN_RELEVANCE_SCORE: 0.5,
      // 实体相关度阈值（可调整）
      MAX_CONTEXT_LENGTH: 100000,
      // 最大上下文长度（~25K tokens）
      ENABLE_2HOP_THRESHOLD: 5,
      // 当 1-hop 结果少于此值时触发 2-hop
      MIN_2HOP_RELEVANCE: 0.4,
      // 2-hop 实体的最低相关度
      ENTITY_LIMIT_PER_TYPE: 20,
      // 每种类型最多返回实体数
      CONTEXT_COMPRESSION_RATIO: 0.7 // 上下文压缩比例
    };
    this.cloudStorage = new CloudStorage/* CloudStorage */.f();
    this.localStorage = new LocalStorage/* LocalStorage */.D();
    this.entitySimilarityTool = new EntitySimilarityTool();
    // 暂时延迟初始化 systemMaintenanceTool，在 initialize 方法中初始化
    this.systemMaintenanceTool = null;

    // 初始化策略配置
    this.config = {
      preferLocalForEntityQueries: true,
      localSearchThreshold: 5,
      cloudFallbackTimeout: 5000,
      requireCloudSuccess: false,
      retryAttempts: 3,
      retryDelay: 1000,
      syncInterval: 30 * 60 * 1000,
      // 30分钟
      maxSyncBatchSize: 50,
      prioritizeRecentData: true
    };

    // 初始化性能指标
    this.metrics = {
      totalQueries: 0,
      localHits: 0,
      cloudHits: 0,
      averageLocalTime: 0,
      averageCloudTime: 0,
      cacheHitRate: 0,
      lastReset: Date.now()
    };
  }

  /**
   * 初始化记忆系统（纯粹的初始化逻辑）
   */
  async performInitialization() {
    try {
      console.log('🧠 初始化记忆系统...');

      // 并行初始化各组件
      const [cloudInit, localInit] = await Promise.all([this.cloudStorage.initialize(), this.localStorage.initialize()]);

      // 加载配置和指标
      await this.loadConfig();
      await this.loadMetrics();
      this.isInitialized = cloudInit && localInit;
      if (this.isInitialized) {
        console.log('✅ 记忆系统初始化完成');

        // 初始化系统维护工具（需要 memorySystem 实例，所以在这里初始化）
        this.systemMaintenanceTool = createSystemMaintenanceTool(this.cloudStorage, this.localStorage, this // 传入自身作为策略层
        );

        // 启动后台同步
        this.startBackgroundSync();
        // 启动系统监控
        this.systemMaintenanceTool.startMonitoring();

        // 初始化用户画像管理器
        await this.initializeUserProfile();
      } else {
        console.error('❌ 记忆系统初始化失败');
      }
      return this.isInitialized;
    } catch (error) {
      console.error('❌ 记忆系统初始化异常:', error);
      this.isInitialized = false; // 确保失败时重置状态
      return false;
    }
  }

  /**
   * 初始化记忆系统（公共接口）
   */
  async initialize() {
    // 如果已经在初始化中，返回现有的Promise
    if (this.initializationPromise) {
      console.log('⚠️ 记忆系统正在初始化中，等待完成...');
      return this.initializationPromise;
    }

    // 防止重复初始化
    if (this.isInitialized) {
      console.log('⚠️ 记忆系统已初始化，跳过重复初始化');
      return true;
    }

    // 创建并缓存初始化Promise
    this.initializationPromise = this.performInitialization().finally(() => {
      // 无论成功失败，都清除Promise缓存
      this.initializationPromise = null;
    });
    return this.initializationPromise;
  }

  // ==================== 读取接口 ====================

  /**
   * 查询实体（普通查询，智能策略）
   */
  async queryEntities(type, searchTerm) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const startTime = Date.now();
    this.metrics.totalQueries++;
    try {
      // 如果有搜索词且长度大于2，考虑使用向量搜索
      if (searchTerm && searchTerm.length > 2) {
        const cloudResult = await this.cloudStorage.searchByVector(searchTerm, type, options);
        // 缓存结果到本地
        await this.cacheCloudResults(cloudResult.data);
        // 扩展实体信息
        const extendedData = await this.extendEntitiesFromCache(cloudResult.data);
        return {
          ...cloudResult,
          data: extendedData
        };
      }

      // 设置默认分页参数（第一页30条数据）
      const queryOptions = {
        ...options,
        limit: options.limit || 30,
        offset: options.offset || 0
      };

      // 优先查询云端获取分页数据
      const cloudResult = await this.queryFromCloud(type, searchTerm, queryOptions);
      this.updateMetrics('cloud', Date.now() - startTime);

      // 缓存结果到本地
      await this.cacheCloudResults(cloudResult.data);

      // 扩展实体信息：合并recent data
      const extendedData = await this.extendEntitiesFromCache(cloudResult.data);
      console.log(`🎯 MemorySystem.queryEntities: 查询到 ${cloudResult.data.length} 个实体，扩展信息后 ${extendedData.length} 个`);
      return {
        ...cloudResult,
        data: extendedData
      };
    } catch (error) {
      console.error('查询实体失败:', error);

      // 出错时尝试返回本地结果
      if (type) {
        const fallbackResult = await this.queryFromLocal(type, searchTerm, options);
        const extendedData = await this.extendEntitiesFromCache(fallbackResult.data);
        return {
          ...fallbackResult,
          data: extendedData,
          source: 'local'
        };
      }
      return {
        data: [],
        total: 0,
        source: 'local',
        cached: true,
        queryTime: Date.now() - startTime
      };
    }
  }

  /**
   * 向量搜索（直接云端查询）
   */
  async searchByVector(query, type) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.cloudStorage.searchByVector(query, type, options);
  }

  /**
   * 获取实体详情（优先本地，包含详细信息补充）
   */
  async getEntityDetails(entityId) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      // 先从本地获取
      const localEntity = await this.localStorage.getEntity(entityId);
      if (localEntity) {
        this.metrics.localHits++;
        // 检查是否需要补充详细信息
        return await this.enrichEntityWithDetails(localEntity);
      }

      // 本地没有，从云端获取
      const entity = await this.cloudStorage.getEntity(entityId);
      if (entity) {
        // 缓存到本地并补充详细信息
        await this.localStorage.cacheEntity(entity);
        this.metrics.cloudHits++;
        return await this.enrichEntityWithDetails(entity);
      }
      return null;
    } catch (error) {
      console.error('获取实体详情失败:', error);
      return null;
    }
  }

  /**
   * 为实体补充详细信息（特别是 recent data）
   */
  async enrichEntityWithDetails(entity) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      // 首先尝试从本地缓存获取详细信息
      const cachedDetails = await this.localStorage.getEntity(entity.id);

      // 检查是否缺少 recent data（没有讨论、资源、项目）
      const hasRecentData = cachedDetails && (cachedDetails.recentDataDetails?.conversations && cachedDetails.recentDataDetails.conversations.length > 0 || cachedDetails.recentDataDetails?.resources && cachedDetails.recentDataDetails.resources.length > 0 || cachedDetails.recentDataDetails?.projects && cachedDetails.recentDataDetails.projects.length > 0);
      if (hasRecentData && cachedDetails) {
        return cachedDetails;
      }

      // 如果缺少详细信息，从云端扩展实体信息
      console.log(`🔍 为实体 ${entity.id} 补充详细信息...`);
      const extendedEntity = await this.cloudStorage.extendEntityToDetailCache(entity);

      // 更新本地缓存
      await this.localStorage.cacheEntity(extendedEntity);
      return extendedEntity;
    } catch (error) {
      console.error(`补充实体 ${entity.id} 详细信息失败:`, error);

      // 失败时返回基础扩展版本
      return {
        ...entity,
        cachedAt: Date.now(),
        recentDataDetails: {
          conversations: [],
          webpages: [],
          resources: [],
          projects: [],
          people: [],
          topics: [],
          jiraTickets: [],
          cooccurringEntities: []
        },
        relatedParticipants: []
      };
    }
  }

  /**
   * 批量为实体补充详细信息
   */
  async enrichEntitiesWithDetails(entities) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const enrichedEntities = [];
    for (const entity of entities) {
      const enrichedEntity = await this.enrichEntityWithDetails(entity);
      enrichedEntities.push(enrichedEntity);
    }
    return enrichedEntities;
  }

  /**
   * 获取实体类型统计
   */
  async getEntityStatistics() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.localStorage.getEntityStatistics();
  }

  /**
   * 获取实体类型信息列表
   */
  async getEntityTypes() {
    try {
      const entityTypes = [];

      // 获取实体统计信息，包含各类型的数量
      const statistics = await this.getEntityStatistics();
      const entityCounts = statistics.entityCounts;

      // 遍历所有已知的实体类型
      for (const [type, count] of Object.entries(entityCounts)) {
        const config = ENTITY_TYPE_CONFIG[type];
        if (config) {
          entityTypes.push({
            type,
            name: config.name,
            icon: config.icon,
            count,
            description: config.description
          });
        } else {
          // 未知类型，使用默认配置
          entityTypes.push({
            type,
            name: type,
            icon: '📂',
            count,
            description: `自定义类型: ${type}`
          });
        }
      }

      // 按数量排序
      entityTypes.sort((a, b) => b.count - a.count);
      console.log(`📋 获取实体类型列表: ${entityTypes.length}个类型`);
      return entityTypes;
    } catch (error) {
      console.error('获取实体类型失败:', error);
      return [];
    }
  }

  /**
   * 搜索实体
   */
  async searchEntities(query, entityType) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (query.length > 2) {
      // 使用向量搜索 - 确保返回实体格式
      const vectorOptions = {
        ...options,
        returnType: 'entities',
        // 确保返回实体格式
        sortBy: 'relevance' // 默认按相关度排序
      };
      return this.searchByVector(query, entityType, vectorOptions);
    } else {
      // 使用普通查询
      return this.queryEntities(entityType, query, options);
    }
  }

  /**
   * 获取关系网络
   */
  async getRelationships(entityId) {
    let depth = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.localStorage.getRelationshipNetwork(entityId, depth);
  }

  /**
   * 获取时间轴数据
   */
  async getTimeline() {
    let limit = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 50;
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.cloudStorage.getTimeline(limit);
  }

  /**
   * 查询实体相关的详细消息（包含contextMessages等完整数据）
   */
  async queryEntityMessages(entityName, options) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }

    // 使用增强的 searchByVector 方法，专门搜索消息并返回原始数据格式
    const result = await this.cloudStorage.searchByVector(entityName, undefined, {
      collections: ['messages'],
      // 只搜索消息集合
      returnType: 'messages',
      // 返回原始数据格式
      limit: options?.limit,
      sortBy: options?.sortBy,
      sortOrder: options?.sortOrder,
      timeRange: options?.timeRange,
      minRelevanceScore: options?.minRelevanceScore
    });
    return result.data || [];
  }

  // ==================== 🆕 高级查询接口 ====================

  /**
   * 🆕 通过关系查找相关实体
   * 例如：查找所有与 "alex" 相关的 Topic
   * 
   * @param targetName 目标实体名称，例如: "alex", "厦门"
   * @param targetType 目标实体类型
   * @param relatedType 要查找的相关实体类型
   * @param options 查询选项
   * @returns 相关实体列表，按相关度排序
   */
  async findRelatedEntitiesByName(targetName, targetType, relatedType) {
    let options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const {
      minRelevanceScore = 0.5,
      timeRange,
      limit = 20
    } = options;
    console.log(`🔗 查找与 "${targetName}" (${targetType}) 相关的所有 ${relatedType}`);
    try {
      // Step 1: 获取所有目标类型的实体（使用分批查询避免内存问题）
      const batchSize = 50;
      let offset = 0;
      const relatedEntities = [];
      let hasMore = true;
      while (hasMore && relatedEntities.length < limit * 2) {
        // 查询足够多以应对过滤
        const batch = await this.cloudStorage.queryEntities(relatedType, undefined, {
          limit: batchSize,
          offset: offset
        });
        if (batch.data.length === 0) {
          hasMore = false;
          break;
        }

        // Step 2: 过滤出包含目标实体的实体
        for (const entity of batch.data) {
          let isRelated = false;
          let relationScore = 0;

          // 检查 relatedData 中是否包含目标实体
          if (targetType === 'Person' && entity.relatedData?.people) {
            const match = entity.relatedData.people.find(p => p.name.toLowerCase().includes(targetName.toLowerCase()));
            if (match) {
              isRelated = true;
              relationScore = match.relevanceScore || 0.5;
            }
          } else if (targetType === 'Project' && entity.relatedData?.projects) {
            const match = entity.relatedData.projects.find(p => p.name.toLowerCase().includes(targetName.toLowerCase()));
            if (match) {
              isRelated = true;
              relationScore = match.relevanceScore || 0.5;
            }
          } else if (targetType === 'Topic' && entity.relatedData?.topics) {
            const match = entity.relatedData.topics.find(t => t.name.toLowerCase().includes(targetName.toLowerCase()));
            if (match) {
              isRelated = true;
              relationScore = match.relevanceScore || 0.5;
            }
          }

          // 检查共现实体
          if (!isRelated && entity.relatedData?.cooccurringEntities) {
            const match = entity.relatedData.cooccurringEntities.find(e => e.name.toLowerCase().includes(targetName.toLowerCase()));
            if (match) {
              isRelated = true;
              relationScore = match.relevanceScore || 0.3;
            }
          }

          // 如果相关且满足条件，加入结果
          if (isRelated && relationScore >= minRelevanceScore) {
            // 时间过滤
            if (timeRange) {
              const entityTime = entity.updated || entity.created;
              if (entityTime < timeRange.start || entityTime > timeRange.end) {
                continue;
              }
            }

            // 添加关系分数
            entity.relevanceScore = relationScore;
            relatedEntities.push(entity);
          }
        }
        offset += batchSize;
      }

      // Step 3: 按相关度排序
      relatedEntities.sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));

      // Step 4: 限制结果数量
      const results = limit ? relatedEntities.slice(0, limit) : relatedEntities;
      console.log(`✅ 找到 ${results.length} 个相关 ${relatedType}`);
      return results;
    } catch (error) {
      console.error(`🚨 关系查询失败:`, error);
      return [];
    }
  }

  /**
   * 🆕 知识查询 - 智能路由的高级查询接口
   * 
   * 这个方法是记忆系统的智能查询入口，它会：
   * 1. 使用 LLM 分析用户问题，提取查询意图和实体
   * 2. 执行实体模糊匹配，找到数据库中的准确实体
   * 3. 并行搜索：实体 + 消息 + 关系扩展
   * 4. 智能融合结果，优先使用实体信息
   * 5. 使用 LLM 生成最终答案
   * 
   * @param question 用户的自然语言问题
   * @returns 查询结果，包含分析答案和相关上下文
   */
  async ask(question) {
    const startTime = Date.now();
    const success = await this.initialize();
    if (!success) {
      return {
        success: false,
        message: '记忆系统初始化失败'
      };
    }
    console.log('🌟 MemorySystem.ask:', question, Date.now());
    try {
      // Step 1: 使用 LLM 分析查询意图
      const queryIntent = await (0,entityExtraction.extractEntitiesForQuery)(question);
      console.log('📊 查询意图:', queryIntent, Date.now());

      // Step 2: 时间范围处理和实体模糊匹配
      this.processTimeRange(queryIntent);
      await this.fuzzyMatchEntities(queryIntent);
      console.log('✅ 最终查询意图:', queryIntent);

      // Step 3: 🆕 混合检索策略 - 向量搜索实体
      let initialEntities = [];
      const hasEntities = queryIntent?.query?.filters?.entities && (queryIntent.query.filters.entities.people?.length > 0 || queryIntent.query.filters.entities.projects?.length > 0 || queryIntent.query.filters.entities.topics?.length > 0);
      if (hasEntities) {
        console.log('🔍 执行混合检索（向量 + 关系）...');

        // 方式A: 向量搜索各类实体
        const searchPromises = [];
        if (queryIntent.query.filters.entities.topics?.length > 0) {
          searchPromises.push(this.searchByVector(question, 'Topic', {
            collections: ['entities'],
            limit: 10,
            minRelevanceScore: this.ASK_CONFIG.MIN_RELEVANCE_SCORE,
            returnType: 'entities'
          }));
        }
        if (queryIntent.query.filters.entities.people?.length > 0) {
          searchPromises.push(this.searchByVector(question, 'Person', {
            collections: ['entities'],
            limit: 5,
            minRelevanceScore: this.ASK_CONFIG.MIN_RELEVANCE_SCORE,
            returnType: 'entities'
          }));
        }
        if (queryIntent.query.filters.entities.projects?.length > 0) {
          searchPromises.push(this.searchByVector(question, 'Project', {
            collections: ['entities'],
            limit: 5,
            minRelevanceScore: this.ASK_CONFIG.MIN_RELEVANCE_SCORE,
            returnType: 'entities'
          }));
        }

        // 并行执行所有搜索
        const searchResults = await Promise.all(searchPromises);

        // 合并所有搜索结果
        for (const result of searchResults) {
          initialEntities.push(...result.data);
        }
        console.log(`✅ 混合检索完成: 找到 ${initialEntities.length} 个初始实体`);
      } else {
        // 如果没有提取到实体，直接进行向量搜索
        console.log('🔍 执行通用向量搜索...');
        const result = await this.searchByVector(question, undefined, {
          collections: ['entities'],
          limit: 15,
          minRelevanceScore: this.ASK_CONFIG.MIN_RELEVANCE_SCORE - 0.1,
          returnType: 'entities'
        });
        initialEntities = result.data;
        console.log(`✅ 通用搜索完成: 找到 ${initialEntities.length} 个实体`);
      }

      // Step 4: 🆕 动态多跳扩展
      console.log('🔄 开始多跳实体扩展...');
      const entityMap = await this.expandEntitiesMultiHop(initialEntities, queryIntent);
      const expandDepth = entityMap.size > initialEntities.length + 10 ? 2 : 1;
      console.log(`✅ 实体扩展完成: ${entityMap.size} 个实体 (${expandDepth}-hop)`);

      // Step 5: 构建增强上下文
      const context = await this.buildAskContext(entityMap, queryIntent);
      console.log(`📄 上下文构建完成: ${context.length} 字符`);

      // Step 6: LLM 推理 - 返回结构化 JSON
      const {
        handleLLMRequest
      } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 1995));
      const prompt = this.buildAskPrompt(question, context);
      const llmResponse = await handleLLMRequest({
        prompt
      });

      // Step 7: 解析 LLM 返回的 JSON
      let parsedResponse;
      try {
        // 尝试提取 JSON（可能被包裹在代码块中）
        const jsonMatch = llmResponse.match(/```json\s*([\s\S]*?)\s*```/);
        const jsonStr = jsonMatch ? jsonMatch[1] : llmResponse;
        parsedResponse = JSON.parse(jsonStr.trim());
      } catch (error) {
        console.warn('⚠️  LLM 返回格式解析失败，使用默认格式:', error);
        parsedResponse = {
          answer: llmResponse,
          relatedEntityIds: {
            topics: [],
            people: [],
            projects: [],
            jiraTickets: [],
            organizations: [],
            documents: [],
            technologies: []
          }
        };
      }

      // Step 8: 根据 LLM 返回的 ID 匹配完整实体
      const entitiesByType = {
        topics: [],
        people: [],
        projects: [],
        jiraTickets: [],
        organizations: [],
        documents: [],
        technologies: []
      };

      // 构建ID到实体的映射
      const idToEntity = new Map();
      for (const entity of Array.from(entityMap.values())) {
        idToEntity.set(entity.id, entity);
      }

      // 匹配实体
      if (parsedResponse.relatedEntityIds) {
        for (const [typeKey, ids] of Object.entries(parsedResponse.relatedEntityIds)) {
          if (Array.isArray(ids)) {
            for (const id of ids) {
              const entity = idToEntity.get(id);
              if (entity) {
                entitiesByType[typeKey].push(entity);
              } else {
                console.warn(`⚠️  未找到实体 ID: ${id}`);
              }
            }
          }
        }
      }

      // Step 9: 按相关度排序并限制数量
      for (const typeKey of Object.keys(entitiesByType)) {
        entitiesByType[typeKey].sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));
        entitiesByType[typeKey] = entitiesByType[typeKey].slice(0, this.ASK_CONFIG.ENTITY_LIMIT_PER_TYPE);
      }
      const totalEntities = Object.values(entitiesByType).reduce((sum, arr) => sum + arr.length, 0);
      const processingTime = Date.now() - startTime;
      console.log(`✅ ask() 完成: ${totalEntities} 个相关实体, 耗时 ${processingTime}ms`);
      return {
        success: true,
        answer: parsedResponse.answer,
        structuredAnswer: parsedResponse.structuredAnswer,
        entitiesByType,
        metadata: {
          totalEntities: totalEntities,
          expandDepth,
          processingTime,
          queryIntent
        }
      };
    } catch (error) {
      console.error('💥 智能查询失败:', error);
      return {
        success: false,
        message: '查询时发生错误，请稍后再试。'
      };
    }
  }

  /**
   * @deprecated 请使用 ask() 方法代替
   * 
   * 🆕 高级知识查询接口（兼容旧接口）
   * 
   * 这个方法是记忆系统的智能查询入口，它会：
   * 1. 使用 LLM 分析用户问题，提取查询意图和实体
   * 2. 执行实体模糊匹配，找到数据库中的准确实体
   * 3. 并行搜索：实体 + 消息 + 关系扩展
   * 4. 智能融合结果，优先使用实体信息
   * 5. 使用 LLM 生成最终答案
   * 
   * @param question 用户的自然语言问题
   * @returns 查询结果，包含分析答案和相关上下文
   */
  async knowledgeQuery(question) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    console.log('🔍 MemorySystem.knowledgeQuery:', question, Date.now());
    try {
      // 导入必要的函数
      const {
        extractEntitiesForQuery
      } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 8));
      const {
        handleLLMRequest
      } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 1995));

      // Step 1: 使用 LLM 分析查询意图
      const queryIntent = await extractEntitiesForQuery(question);
      console.log('📊 查询意图:', queryIntent, Date.now());

      // Step 2: 时间范围处理（与原来的 knowledgeQuery 逻辑相同）
      this.processTimeRange(queryIntent);

      // Step 3: 实体模糊匹配
      await this.fuzzyMatchEntities(queryIntent);
      console.log('✅ 最终查询意图:', queryIntent);

      // Step 4: 🆕 并行搜索：实体 + 消息
      let entityResults = [];
      let messageResults = null;
      const hasEntities = queryIntent?.query?.filters?.entities && (queryIntent.query.filters.entities.people?.length > 0 || queryIntent.query.filters.entities.projects?.length > 0 || queryIntent.query.filters.entities.topics?.length > 0);
      if (hasEntities) {
        console.log('🔍 尝试直接搜索 Topic 实体...');

        // 🆕 方式A: 向量搜索 Topic 实体
        const topicSearchResult = await this.searchByVector(question, 'Topic', {
          collections: ['entities'],
          limit: 5,
          minRelevanceScore: 0.6,
          returnType: 'entities'
        });

        // 🆕 方式B: 关系扩展查询
        const relationResults = [];

        // 如果查询中包含人物，通过关系查找相关Topic
        if (queryIntent.query.filters.entities.people?.length > 0) {
          const personName = queryIntent.query.filters.entities.people[0].name;
          console.log(`🔗 通过关系查找 ${personName} 相关的 Topic...`);
          const timeRange = queryIntent.query.filters.time_range && queryIntent.query.filters.time_range.start && queryIntent.query.filters.time_range.end ? {
            start: queryIntent.query.filters.time_range.start,
            end: queryIntent.query.filters.time_range.end
          } : undefined;
          const relatedTopics = await this.findRelatedEntitiesByName(personName, 'Person', 'Topic', {
            timeRange,
            minRelevanceScore: 0.5,
            limit: 5
          });
          console.log(`  找到 ${relatedTopics.length} 个通过关系找到的Topic`);
          relationResults.push(...relatedTopics);
        }

        // 🆕 合并向量搜索和关系查询的结果
        const allTopics = [...topicSearchResult.data];

        // 去重合并（基于ID）
        const topicIds = new Set(allTopics.map(t => t.id));
        for (const topic of relationResults) {
          if (!topicIds.has(topic.id)) {
            allTopics.push(topic);
            topicIds.add(topic.id);
          }
        }

        // 按相关度重新排序
        allTopics.sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));
        entityResults = allTopics.slice(0, 5); // 取前5个
        console.log(`✅ 最终找到 ${entityResults.length} 个Topic实体`);
      }

      // Step 5: 搜索相关消息
      const filters = {};
      if (queryIntent?.query?.filters) {
        if (queryIntent.query.filters.entities) {
          filters.entities = queryIntent.query.filters.entities;
        }
        if (queryIntent.query.filters.time_range) {
          filters.time_range = queryIntent.query.filters.time_range;
        }
      }
      const output = queryIntent?.query?.output || {
        format: "list",
        limit: 20,
        sort: {
          field: "timestamp",
          order: "desc"
        }
      };
      try {
        const timeRange = filters.time_range && filters.time_range.start && filters.time_range.end ? {
          start: filters.time_range.start,
          end: filters.time_range.end
        } : undefined;
        const messages = await this.cloudStorage.getSimilarMessages(question, {
          limit: output.limit || 20,
          minRelevanceScore: 0.3,
          timeRange,
          sortBy: output.sort?.field === 'timestamp' ? 'time' : 'relevance',
          sortOrder: output.sort?.order || 'desc',
          filters: {
            entities: filters.entities
          }
        });
        messageResults = {
          question: question,
          results: {
            ids: messages.map(m => m.id),
            documents: messages.map(m => m.content),
            metadatas: messages.map(m => ({
              sender: m.sender,
              source: m.sender,
              groupName: m.groupName,
              groupUrl: m.groupUrl,
              datetime: m.datetime,
              summary: m.summary,
              matchedRules: m.matchedRules,
              contextMessages: m.contextMessages
            })),
            distances: messages.map(m => 1 - (m.relevanceScore || 0))
          }
        };
      } catch (error) {
        console.error('💥 消息查询失败:', error);
        messageResults = {
          question: question,
          results: {
            ids: [],
            documents: [],
            metadatas: [],
            distances: []
          }
        };
      }

      // Step 6: 🆕 智能融合结果
      const contextSources = await this.buildContextFromResults(entityResults, messageResults);
      if (contextSources.length === 0) {
        return {
          success: false,
          message: `没有找到关于"${question}"的相关信息。`
        };
      }

      // Step 7: 构建 LLM prompt 并生成答案
      const prompt = this.buildLLMPrompt(question, contextSources, queryIntent);
      const llmResponse = await handleLLMRequest({
        prompt
      });

      // Step 8: 返回结果
      return {
        success: true,
        analysis: llmResponse,
        relatedMessages: messageResults?.results?.documents?.length || 0,
        queryIntent: queryIntent,
        results: this.formatResults(messageResults?.results)
      };
    } catch (error) {
      console.error('💥 知识查询失败:', error);
      return {
        success: false,
        message: '查询时发生错误，请稍后再试。'
      };
    }
  }

  // ==================== 私有辅助方法 ====================

  /**
   * 处理时间范围
   */
  processTimeRange(queryIntent) {
    if (!queryIntent?.query?.filters?.time_range) return;
    const timeRange = queryIntent.query.filters.time_range;

    // 处理时间疑问词
    if (timeRange.type === 'specific' && typeof timeRange.start === 'string') {
      const timeQuestionWords = ["什么时候", "何时", "几点", "哪天", "什么日期", "什么时间", "几号", "什么时段", "几月", "哪一天", "什么季节"];
      if (timeQuestionWords.some(word => timeRange.start.includes(word))) {
        console.log(`检测到时间疑问词: "${timeRange.start}"，将time_range.type设为"all"`);
        timeRange.type = "all";
        timeRange.start = null;
        timeRange.end = null;
        return;
      }
    }

    // 根据时间描述设置具体的时间范围
    if (timeRange.type === 'range' && timeRange.description) {
      const now = new Date();
      const thisYear = now.getFullYear();
      const thisMonth = now.getMonth();
      if (/今年|本年|今年度|本年度/.test(timeRange.description)) {
        const startOfYear = new Date(thisYear, 0, 1).getTime();
        timeRange.start = startOfYear;
        timeRange.end = now.getTime();
      } else if (/这个月|本月|当月/.test(timeRange.description)) {
        const startOfMonth = new Date(thisYear, thisMonth, 1).getTime();
        timeRange.start = startOfMonth;
        timeRange.end = now.getTime();
      } else if (/过去(\d+)天|最近(\d+)天/.test(timeRange.description)) {
        const matches = timeRange.description.match(/过去(\d+)天|最近(\d+)天/);
        if (matches) {
          const days = parseInt(matches[1] || matches[2]);
          if (!isNaN(days)) {
            timeRange.start = now.getTime() - days * 24 * 60 * 60 * 1000;
            timeRange.end = now.getTime();
          }
        }
      }
    }

    // 如果是recent类型，设置默认为过去7天
    if (timeRange.type === 'recent') {
      const now = new Date();
      timeRange.start = now.getTime() - 7 * 24 * 60 * 60 * 1000;
      timeRange.end = now.getTime();
    }
  }

  /**
   * 实体模糊匹配
   */
  async fuzzyMatchEntities(queryIntent) {
    // 导入模糊匹配函数
    const fuzzyMatchPerson = (name, knownPeople) => {
      const normalizedName = name.toLowerCase().trim();
      for (const knownName of knownPeople) {
        if (knownName.toLowerCase().includes(normalizedName) || normalizedName.includes(knownName.toLowerCase())) {
          return knownName;
        }
      }
      return null;
    };
    const fuzzyMatchEntityName = (name, knownNames) => {
      return fuzzyMatchPerson(name, knownNames);
    };

    // 获取所有已知实体
    const [knownPeople, knownProjects, knownTopics] = await Promise.all([this.cloudStorage.getAllKnownPeople(), this.cloudStorage.getAllKnownProjects(), this.cloudStorage.getAllKnownTopics()]);
    console.log('📋 已知实体:', {
      people: knownPeople.length,
      projects: knownProjects.length,
      topics: knownTopics.length
    });

    // 人名模糊匹配
    if (queryIntent?.query?.filters?.entities?.people?.length > 0) {
      const matchedPeople = [];
      for (const person of queryIntent.query.filters.entities.people) {
        const matchedPerson = fuzzyMatchPerson(person.name, knownPeople);
        if (matchedPerson) {
          console.log(`人名匹配: "${person.name}" => "${matchedPerson}"`);
          matchedPeople.push({
            ...person,
            name: matchedPerson
          });
        } else {
          matchedPeople.push(person);
        }
      }
      queryIntent.query.filters.entities.people = matchedPeople;
    }

    // 项目和主题模糊匹配
    if (queryIntent?.query?.filters?.entities?.projects?.length > 0) {
      const matchedProjects = [];
      for (const project of queryIntent.query.filters.entities.projects) {
        const matchedName = fuzzyMatchEntityName(project.name, knownProjects);
        if (matchedName) {
          console.log(`项目匹配: "${project.name}" => "${matchedName}"`);
          matchedProjects.push({
            ...project,
            name: matchedName
          });
        } else {
          matchedProjects.push(project);
        }
      }
      queryIntent.query.filters.entities.projects = matchedProjects;
    }
    if (queryIntent?.query?.filters?.entities?.topics?.length > 0) {
      const matchedTopics = [];
      for (const topic of queryIntent.query.filters.entities.topics) {
        const matchedName = fuzzyMatchEntityName(topic.name, knownTopics);
        if (matchedName) {
          console.log(`主题匹配: "${topic.name}" => "${matchedName}"`);
          matchedTopics.push({
            ...topic,
            name: matchedName
          });
        } else {
          matchedTopics.push(topic);
        }
      }
      queryIntent.query.filters.entities.topics = matchedTopics;
    }
  }

  /**
   * 从实体和消息结果构建上下文
   */
  async buildContextFromResults(entityResults, messageResults) {
    const contextSources = [];

    // 🆕 优先使用 Topic 实体信息
    if (entityResults && entityResults.length > 0) {
      console.log('🎯 使用 Topic 实体作为主要上下文');
      for (const entity of entityResults) {
        let entityContext = `### Topic: ${entity.name}\n`;
        if (entity.description) {
          entityContext += `描述: ${entity.description}\n`;
        }

        // 🔑 从 relatedData 中提取信息
        if (entity.relatedData) {
          if (entity.relatedData.people && entity.relatedData.people.length > 0) {
            const peopleNames = entity.relatedData.people.map(p => p.name).join(', ');
            entityContext += `相关人员: ${peopleNames}\n`;
          }
          if (entity.relatedData.projects && entity.relatedData.projects.length > 0) {
            const projectNames = entity.relatedData.projects.map(p => p.name).join(', ');
            entityContext += `相关项目: ${projectNames}\n`;
          }

          // 🔑 最近的对话记录（前3条）
          if (entity.relatedData.conversations && entity.relatedData.conversations.length > 0) {
            entityContext += `\n最近讨论:\n`;
            entity.relatedData.conversations.slice(0, 3).forEach((conv, idx) => {
              entityContext += `  ${idx + 1}. [${conv.sender}] ${conv.summary}\n`;
              entityContext += `     时间: ${conv.datetime}\n`;
            });
          }
        }
        contextSources.push({
          type: 'topic_entity',
          priority: 1,
          content: entityContext,
          relevanceScore: entity.relevanceScore || 0
        });
      }
    }

    // 添加消息上下文
    if (messageResults?.results?.documents && messageResults.results.documents.length > 0) {
      for (let i = 0; i < messageResults.results.documents.length; i++) {
        const doc = messageResults.results.documents[i];
        const metadata = messageResults.results.metadatas[i];
        const distance = messageResults.results.distances[i] || 0;
        const relevanceScore = Math.max(0, 1 - distance);
        contextSources.push({
          type: 'message',
          priority: 2,
          content: `### 消息记录\n${doc}\n时间: ${metadata?.datetime || '未知'}\n发送者: ${metadata?.source || '未知'}`,
          relevanceScore
        });
      }
    }

    // 按优先级和相关度排序
    contextSources.sort((a, b) => {
      if (a.priority !== b.priority) return a.priority - b.priority;
      return b.relevanceScore - a.relevanceScore;
    });
    return contextSources;
  }

  /**
   * 构建 LLM prompt
   */
  buildLLMPrompt(question, contextSources, _queryIntent) {
    // 构建上下文（限制总长度）
    const MAX_CONTEXT_LENGTH = 4000;
    let messagesContext = '';
    let currentLength = 0;
    for (const source of contextSources) {
      if (currentLength + source.content.length <= MAX_CONTEXT_LENGTH) {
        messagesContext += source.content + '\n\n---\n\n';
        currentLength += source.content.length;
      } else {
        break;
      }
    }
    console.log(`📊 上下文统计: 共${contextSources.length}个来源，使用了${messagesContext.length}字符`);

    // 根据查询类型选择模板
    const promptTemplate = `
以下是与问题"${question}"相关的信息:
{{context}}

请基于以上信息提供详细回答。仅使用提供的信息,不要添加额外知识。
如果信息不足,请明确指出。
    `;
    return promptTemplate.replace('{{context}}', messagesContext);
  }

  /**
   * 格式化结果
   */
  formatResults(results) {
    if (!results || !results.documents) return [];
    return results.documents.map((doc, idx) => {
      const metadata = results.metadatas[idx];
      const id = String(results.ids[idx]);
      const relevance = Math.max(0, 1 - results.distances[idx]);
      return {
        id: id,
        summary: String(metadata.summary) || doc.substring(0, 100) + '...',
        details: String(metadata.details || doc),
        timestamp: metadata.datetime || new Date().toISOString(),
        source: String(metadata.source),
        relevance: relevance,
        tags: metadata.tags || []
      };
    });
  }

  // ==================== ask() 专用辅助方法 ====================

  /**
   * 从 relatedData 中提取关联实体的 ID
   */
  extractRelatedEntityIds(relatedData, minScore) {
    const ids = new Set();
    if (!relatedData) return ids;

    // 提取 people
    if (relatedData.people && Array.isArray(relatedData.people)) {
      for (const item of relatedData.people) {
        if (item.id && (item.relevanceScore || 0) >= minScore) {
          ids.add(item.id);
        }
      }
    }

    // 提取 projects
    if (relatedData.projects && Array.isArray(relatedData.projects)) {
      for (const item of relatedData.projects) {
        if (item.id && (item.relevanceScore || 0) >= minScore) {
          ids.add(item.id);
        }
      }
    }

    // 提取 topics
    if (relatedData.topics && Array.isArray(relatedData.topics)) {
      for (const item of relatedData.topics) {
        if (item.id && (item.relevanceScore || 0) >= minScore) {
          ids.add(item.id);
        }
      }
    }

    // 提取 jiraTickets
    if (relatedData.jiraTickets && Array.isArray(relatedData.jiraTickets)) {
      for (const item of relatedData.jiraTickets) {
        if (item.id && (item.relevanceScore || 0) >= minScore) {
          ids.add(item.id);
        }
      }
    }

    // 提取 cooccurringEntities
    if (relatedData.cooccurringEntities && Array.isArray(relatedData.cooccurringEntities)) {
      for (const item of relatedData.cooccurringEntities) {
        if (item.id && (item.relevanceScore || 0) >= minScore) {
          ids.add(item.id);
        }
      }
    }
    return ids;
  }

  /**
   * 从实体的 relatedData 中提取并加载关联实体
   */
  async expandRelatedData(entities, entityMap) {
    let is2Hop = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
    const newEntityIds = new Set();
    const minScore = is2Hop ? this.ASK_CONFIG.MIN_2HOP_RELEVANCE : this.ASK_CONFIG.MIN_RELEVANCE_SCORE;
    for (const entity of entities) {
      if (!entity.relatedData) continue;

      // 提取所有关联实体 ID
      const relatedIds = this.extractRelatedEntityIds(entity.relatedData, minScore);
      for (const id of Array.from(relatedIds)) {
        if (!entityMap.has(id)) {
          newEntityIds.add(id);
        }
      }
    }

    // 批量加载新实体
    if (newEntityIds.size > 0) {
      console.log(`  🔍 发现 ${newEntityIds.size} 个新的关联实体`);
      const newEntities = await this.cloudStorage.getEntitiesByIds(Array.from(newEntityIds));
      for (const entity of newEntities) {
        entityMap.set(entity.id, entity);
      }
    }
    return newEntityIds;
  }

  /**
   * 判断是否需要进行 2-hop 扩展
   */
  shouldPerform2Hop(currentSize, initialEntities) {
    // 如果初始实体数量就很多，不需要 2-hop
    if (initialEntities.length >= 10) {
      console.log('  ℹ️  初始实体充足，跳过 2-hop');
      return false;
    }

    // 如果 1-hop 后实体数量少于阈值，触发 2-hop
    if (currentSize < this.ASK_CONFIG.ENABLE_2HOP_THRESHOLD) {
      console.log('  ⚠️  1-hop 结果不足，触发 2-hop 扩展');
      return true;
    }
    return false;
  }

  /**
   * 多跳实体扩展
   * 从初始实体集合出发，动态决定是否进行 2-hop 扩展
   */
  async expandEntitiesMultiHop(initialEntities, _queryIntent) {
    const entityMap = new Map();

    // 1-hop: 添加初始实体
    console.log(`🌱 初始实体: ${initialEntities.length} 个`);
    for (const entity of initialEntities) {
      entityMap.set(entity.id, entity);
    }

    // 1-hop: 扩展 relatedData 中的关联实体
    await this.expandRelatedData(initialEntities, entityMap);
    console.log(`✅ 1-hop 扩展完成: ${entityMap.size} 个实体`);

    // 🔍 动态决策：是否需要 2-hop
    const need2Hop = this.shouldPerform2Hop(entityMap.size, initialEntities);
    if (need2Hop) {
      console.log('🔄 触发 2-hop 扩展...');
      await this.expandRelatedData(Array.from(entityMap.values()), entityMap, true);
      console.log(`✅ 2-hop 扩展完成: ${entityMap.size} 个实体`);
    }
    return entityMap;
  }

  /**
   * 按类型分组实体
   */
  groupEntitiesByType(entities) {
    const grouped = {
      Topic: [],
      Person: [],
      Project: [],
      Task: [],
      Organization: [],
      Document: [],
      Technology: []
    };
    for (const entity of entities) {
      if (grouped[entity.type]) {
        grouped[entity.type].push(entity);
      }
    }
    return grouped;
  }

  /**
   * 构建实体上下文字符串
   */
  buildEntityContext(entitiesByType) {
    let context = '# 知识库实体信息\n\n';

    // 按类型构建上下文
    const typeNames = {
      Topic: '主题',
      Person: '人员',
      Project: '项目',
      Task: 'Jira任务',
      Organization: '组织',
      Document: '文档',
      Technology: '技术'
    };
    for (const [type, entities] of Object.entries(entitiesByType)) {
      if (entities.length === 0) continue;
      context += `## ${typeNames[type] || type} (${entities.length}个)\n\n`;
      for (const entity of entities) {
        context += `### [${entity.type}] ${entity.name} (ID: ${entity.id})\n`;
        if (entity.description) {
          context += `**描述**: ${entity.description}\n`;
        }

        // 添加重要性和相关度
        if (entity.importance) {
          context += `**重要性**: ${(entity.importance * 100).toFixed(0)}%\n`;
        }
        if (entity.relevanceScore) {
          context += `**相关度**: ${(entity.relevanceScore * 100).toFixed(0)}%\n`;
        }

        // 添加关联信息摘要
        if (entity.relatedData) {
          const summaryParts = [];
          if (entity.relatedData.people?.length > 0) {
            summaryParts.push(`${entity.relatedData.people.length}个相关人员`);
          }
          if (entity.relatedData.projects?.length > 0) {
            summaryParts.push(`${entity.relatedData.projects.length}个相关项目`);
          }
          if (entity.relatedData.conversations?.length > 0) {
            summaryParts.push(`${entity.relatedData.conversations.length}条相关对话`);
          }
          if (summaryParts.length > 0) {
            context += `**关联**: ${summaryParts.join(', ')}\n`;
          }

          // 添加最近的对话摘要（最多3条）
          if (entity.relatedData.conversations && entity.relatedData.conversations.length > 0) {
            context += `**最近讨论**:\n`;
            entity.relatedData.conversations.slice(0, 3).forEach((conv, idx) => {
              context += `  ${idx + 1}. [${conv.sender}] ${conv.summary} (${conv.datetime})\n`;
            });
          }
        }
        context += '\n';
      }
    }
    return context;
  }

  /**
   * 智能压缩上下文
   * 当上下文超出限制时，优先保留高相关度实体
   */
  compressContext(context, entitiesByType) {
    console.log(`⚠️  上下文过长 (${context.length} 字符)，进行压缩...`);

    // 按相关度重新排序所有实体
    const allEntities = [];
    for (const entities of Object.values(entitiesByType)) {
      allEntities.push(...entities);
    }
    allEntities.sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));

    // 只保留最相关的实体，直到达到长度限制
    const targetLength = Math.floor(this.ASK_CONFIG.MAX_CONTEXT_LENGTH * this.ASK_CONFIG.CONTEXT_COMPRESSION_RATIO);
    const compressedEntitiesByType = this.groupEntitiesByType([]);
    let currentLength = 0;
    for (const entity of allEntities) {
      const entityText = this.buildEntityContext({
        [entity.type]: [entity]
      });
      if (currentLength + entityText.length <= targetLength) {
        compressedEntitiesByType[entity.type].push(entity);
        currentLength += entityText.length;
      } else {
        break;
      }
    }
    const compressedContext = this.buildEntityContext(compressedEntitiesByType);
    console.log(`✂️  压缩完成: ${context.length} → ${compressedContext.length} 字符`);
    return compressedContext;
  }

  /**
   * 构建增强型上下文
   * 包含实体摘要、关系网络、对话记录等
   */
  async buildAskContext(entities, _queryIntent) {
    // 1. 按相关度排序所有实体
    const sortedEntities = Array.from(entities.values()).sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));
    console.log(`📝 构建上下文: ${sortedEntities.length} 个实体`);

    // 2. 按类型分组
    const entitiesByType = this.groupEntitiesByType(sortedEntities);

    // 3. 构建分层上下文
    let context = this.buildEntityContext(entitiesByType);

    // 4. 如果超出限制，进行智能压缩
    if (context.length > this.ASK_CONFIG.MAX_CONTEXT_LENGTH) {
      context = this.compressContext(context, entitiesByType);
    }
    return context;
  }

  /**
   * 构建 ask() 的 LLM prompt
   * 要求 LLM 返回结构化 JSON 格式
   */
  buildAskPrompt(question, context) {
    return `你是一个智能知识助手，基于提供的知识库信息回答用户问题。

# 知识库上下文

${context}

# 用户问题

${question}

# 任务要求

1. 基于上述知识库信息，准确回答用户的问题
2. 如果信息不足以完整回答，请明确说明
3. 列出与问题最相关的实体 ID（从上述知识库中提取）
4. 提供结构化的分析结果，包括关键发现、时间线和深度洞察

# 返回格式

请以 JSON 格式返回，包含以下字段：

\`\`\`json
{
  "answer": "详细的主要答案文本（必填，至少100字的完整回答）",
  "structuredAnswer": {
    "summary": "简要总结（1-2句话概括核心要点）",
    "keyFindings": [
      "关键发现1：具体的发现或结论",
      "关键发现2：重要的信息点"
    ],
    "timeline": [
      {"date": "相对时间描述（如：2小时前、昨天）", "event": "发生的事件描述"},
      {"date": "时间", "event": "事件"}
    ],
    "insights": [
      "深度洞察1：基于数据的分析和见解",
      "深度洞察2：趋势、模式或建议"
    ]
  },
  "relatedEntityIds": {
    "topics": ["topic_id_1", "topic_id_2"],
    "people": ["person_id_1"],
    "projects": ["project_id_1"],
    "jiraTickets": [],
    "organizations": [],
    "documents": [],
    "technologies": []
  }
}
\`\`\`

注意：
- answer 必须是完整、连贯的主要回答（这是用户最先看到的内容）
- structuredAnswer 是可选的增强信息，只在有足够信息时提供
  - summary: 用一两句话概括核心要点
  - keyFindings: 提炼2-5个关键发现，每个发现要具体明确
  - timeline: 如果问题涉及时间相关的事件，提供时间线（可选）
  - insights: 提供2-4个深度洞察，包括趋势分析、模式识别或可行建议
- relatedEntityIds 只包含与答案直接相关的实体 ID（必须是上述知识库中存在的ID）
- 如果某个类型没有相关实体，使用空数组 []
- 请确保返回的是有效的 JSON 格式`;
  }

  // ==================== 存储接口 ====================

  /**
   * 存储实体（先云端后本地）
   */
  async storeEntity(entity) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const startTime = Date.now();
    const result = {
      success: false,
      entityId: '',
      cloudStored: false,
      localCached: false,
      relationshipsCreated: 0,
      processingTime: 0,
      errors: []
    };
    try {
      // 构建完整实体
      const fullEntity = {
        ...entity,
        id: '',
        created: Date.now(),
        updated: Date.now(),
        accessCount: 0,
        lastAccessed: Date.now()
      };

      // 1. 先存储到云端
      let attempts = 0;
      while (attempts < this.config.retryAttempts) {
        try {
          const entityId = await this.cloudStorage.storeEntity(fullEntity);
          if (entityId) {
            fullEntity.id = entityId;
            result.entityId = entityId;
            result.cloudStored = true;
            break;
          }
        } catch (error) {
          console.warn(`云端存储尝试 ${attempts + 1} 失败:`, error);
          if (attempts < this.config.retryAttempts - 1) {
            await this.delay(this.config.retryDelay * (attempts + 1));
          }
        }
        attempts++;
      }

      // 2. 更新本地缓存
      try {
        await this.localStorage.cacheEntity(fullEntity);
        result.localCached = true;
      } catch (error) {
        console.warn('本地缓存失败:', error);
        result.errors?.push('本地缓存失败');
      }

      // 确定成功条件
      if (this.config.requireCloudSuccess) {
        result.success = result.cloudStored && result.localCached;
      } else {
        result.success = result.cloudStored || result.localCached;
      }
      result.processingTime = Date.now() - startTime;
      console.log(`💾 实体存储完成: ${result.entityId || fullEntity.id}`, {
        cloudStored: result.cloudStored,
        localCached: result.localCached,
        success: result.success
      });
      return result;
    } catch (error) {
      console.error('存储实体失败:', error);
      result.errors?.push(error.message);
      result.processingTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 存储消息（先云端后本地）- 🆕 统一接口，包含实体关联数据处理
   */
  async storeMessage(messageData) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const startTime = Date.now();
    const result = {
      success: false,
      entityId: messageData.id,
      cloudStored: false,
      localCached: false,
      relationshipsCreated: 0,
      processingTime: 0,
      errors: []
    };
    try {
      // 1. 存储消息到云端（实体数据已包含在metadata中）
      const cloudSuccess = await this.cloudStorage.storeMessage(messageData);
      result.cloudStored = cloudSuccess;

      // 2. 🆕 更新实体关联数据（从metadata中提取实体并更新关联信息）
      if (result.cloudStored) {
        try {
          await this.cloudStorage.updateEntitiesWithRelatedData(messageData.metadata, messageData.id);
          console.log(`🔗 实体关联数据更新完成: ${messageData.id}`);
        } catch (entityError) {
          console.error('🚨 更新实体关联数据失败:', entityError);
          result.errors?.push(`Entity update failed: ${entityError.message}`);
          // 不影响整体存储成功状态，仅记录错误
        }
      }
      result.success = result.cloudStored;
      result.processingTime = Date.now() - startTime;

      // 3. 同时更新用户画像
      if (result.success && this.userProfileManager && messageData.metadata?.entities) {
        try {
          // 将实体对象转换为数组格式
          const entitiesArray = this.cloudStorage.extractEntitiesFromMetadata(messageData.metadata, messageData.id);
          if (entitiesArray.length > 0) {
            // 根据消息匹配规则智能推断actionType
            const actionType = this.inferActionTypeFromMessageData(messageData);
            await this.updateUserProfileFromEntities(entitiesArray, {
              actionType,
              timestamp: Date.now(),
              context: 'message_analysis',
              metadata: {
                messageId: messageData.id,
                sender: messageData.metadata?.sender || 'unknown',
                matchedRules: messageData.metadata?.matchedRules,
                groupName: messageData.metadata?.groupName
              }
            });
          }
        } catch (profileError) {
          console.error('⚠️ 更新用户画像失败:', profileError);
          result.errors?.push(`Profile update failed: ${profileError.message}`);
          // 不影响整体存储成功状态，仅记录错误
        }
      }
      console.log(`✅ 消息完整存储完成: ${messageData.id}, 成功: ${result.success ? '✅' : '❌'}, 处理时间: ${result.processingTime}ms`);
      return result;
    } catch (error) {
      console.error('存储消息失败:', error);
      result.errors?.push(error.message);
      result.processingTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 存储网页数据
   */
  async storeWebpage(webpageData) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const startTime = Date.now();
    const result = {
      success: false,
      entityId: webpageData.id,
      cloudStored: false,
      localCached: false,
      relationshipsCreated: 0,
      processingTime: 0,
      errors: []
    };
    try {
      // 1. 存储网页到云端
      const cloudSuccess = await this.cloudStorage.storeWebpage(webpageData);
      result.cloudStored = cloudSuccess;

      // 2. 处理实体（如果有）
      if (webpageData.entities && webpageData.entities.length > 0) {
        for (const entityData of webpageData.entities) {
          const entityResult = await this.storeEntity(entityData);
          if (entityResult.success) {
            result.relationshipsCreated++;

            // 更新相关实体的最近数据缓存
            await this.localStorage.updateRecentData(entityResult.entityId, 'webpage', {
              id: webpageData.id,
              title: webpageData.title,
              url: webpageData.url,
              summary: webpageData.content.substring(0, 200),
              visitTime: Date.now(),
              domain: new URL(webpageData.url).hostname
            });
          }
        }
      }
      result.success = result.cloudStored;
      result.processingTime = Date.now() - startTime;

      // 同时更新用户画像
      if (result.success && this.userProfileManager && webpageData.entities) {
        await this.updateUserProfileFromEntities(webpageData.entities, {
          actionType: 'view',
          timestamp: Date.now(),
          context: 'webpage_analysis',
          metadata: {
            webpageId: webpageData.id,
            url: webpageData.url,
            title: webpageData.title,
            domain: new URL(webpageData.url).hostname
          }
        });
      }
      return result;
    } catch (error) {
      console.error('存储网页失败:', error);
      result.errors?.push(error.message);
      result.processingTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 更新实体（同步更新本地和云端）
   */
  async updateEntity(entityId, updates) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const startTime = Date.now();
    const result = {
      success: false,
      entityId,
      cloudStored: false,
      localCached: false,
      relationshipsCreated: 0,
      processingTime: 0,
      errors: []
    };
    try {
      // 添加更新时间
      const updatedData = {
        ...updates,
        updated: Date.now()
      };

      // 1. 更新云端
      const cloudSuccess = await this.cloudStorage.updateEntity(entityId, updatedData);
      result.cloudStored = cloudSuccess;

      // 2. 更新本地缓存
      const localEntity = await this.localStorage.getEntity(entityId);
      if (localEntity) {
        const updatedEntity = {
          ...localEntity,
          ...updatedData
        };

        // 🆕 同步更新 recentDataDetails.conversations
        // 保留策略：所有未读消息 + 最新5条已读消息
        if (updatedData.relatedData?.conversations) {
          const mergedConversations = this.mergeAndSortConversations(localEntity.recentDataDetails?.conversations || [], updatedData.relatedData.conversations);
          updatedEntity.recentDataDetails = {
            ...(updatedEntity.recentDataDetails || {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }),
            conversations: mergedConversations // 已在 mergeAndSortConversations 中应用保留策略
          };
        }
        await this.localStorage.cacheEntity(updatedEntity);
        result.localCached = true;
      }
      result.success = result.cloudStored || result.localCached;
      result.processingTime = Date.now() - startTime;
      return result;
    } catch (error) {
      console.error('更新实体失败:', error);
      result.errors?.push(error.message);
      result.processingTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 删除实体（同步删除本地和云端）
   */
  async deleteEntity(entityId) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      // 并行删除云端和本地
      const [cloudSuccess, localSuccess] = await Promise.allSettled([this.cloudStorage.deleteEntity(entityId), this.removeFromLocalCache(entityId)]);
      return cloudSuccess.status === 'fulfilled' && cloudSuccess.value || localSuccess.status === 'fulfilled' && localSuccess.value;
    } catch (error) {
      console.error('删除实体失败:', error);
      return false;
    }
  }

  /**
   * 批量存储实体
   */
  async batchStoreEntities(entities) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const results = [];
    let successCount = 0;
    let failedCount = 0;

    // 分批处理
    const batches = this.chunkArray(entities, this.config.maxSyncBatchSize);
    for (const batch of batches) {
      const batchPromises = batch.map(entity => this.storeEntity(entity));
      const batchResults = await Promise.allSettled(batchPromises);
      for (const settledResult of batchResults) {
        if (settledResult.status === 'fulfilled') {
          const result = settledResult.value;
          results.push(result);
          if (result.success) {
            successCount++;
          } else {
            failedCount++;
          }
        } else {
          failedCount++;
          results.push({
            success: false,
            entityId: `failed_${Date.now()}`,
            cloudStored: false,
            localCached: false,
            relationshipsCreated: 0,
            processingTime: 0,
            errors: [settledResult.reason?.message || '未知错误']
          });
        }
      }
    }
    return {
      success: successCount,
      failed: failedCount,
      results
    };
  }

  // ==================== 缓存管理接口 ====================

  /**
   * 更新实体的最近数据缓存
   */
  async updateRecentData(entityId, type, data) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.localStorage.updateRecentData(entityId, type, data);
  }

  /**
   * 🆕 同步实体类型统计数据到本地缓存
   */
  async syncEntityCountsToCache(entities) {
    try {
      // 统计各类型实体数量
      const entityCounts = {
        'Person': 0,
        'Project': 0,
        'Task': 0,
        'Organization': 0,
        'Document': 0,
        'Technology': 0,
        'Topic': 0
      };

      // 遍历实体并统计
      entities.forEach(entity => {
        if (Object.prototype.hasOwnProperty.call(entityCounts, entity.type)) {
          entityCounts[entity.type]++;
        } else {
          // 如果有新的类型，也记录下来
          entityCounts[entity.type] = (entityCounts[entity.type] || 0) + 1;
        }
      });

      // 保存到本地缓存
      const statistics = {
        entityCounts,
        lastUpdated: Date.now(),
        totalEntities: entities.length
      };
      await chrome.storage.local.set({
        'cache_statistics': statistics
      });
      console.log(`📊 实体统计数据已缓存:`, entityCounts);
    } catch (error) {
      console.error('📊 同步实体统计数据失败:', error);
    }
  }

  /**
   * 清理过期缓存
   */
  async clearExpiredCache() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.localStorage.clearExpiredCache();
  }

  /**
   * 强制同步缓存
   */
  async syncCache() {
    if (this.isSyncing) {
      console.log('⏭️ 同步程序还在进行，跳过本次同步');
      return;
    }
    this.isSyncing = true;
    console.log('🔄 执行定时同步...');
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      console.log('🔄 开始同步缓存...');

      // 执行云端到本地单向同步
      await this.performCloudToLocalSync();

      // 上传本地统计信息到云端
      await this.uploadLocalStatisticsToCloud();

      // 上传本地已读状态到云端
      await this.uploadLocalReadStatusToCloud();

      // 清理过期缓存
      await this.localStorage.clearExpiredCache();

      // 更新最后同步时间
      await chrome.storage.local.set({
        'cache_last_sync_time': Date.now()
      });
      console.log('✅ 缓存同步完成');
    } catch (error) {
      console.error('❌ 缓存同步失败:', error);
    }
    this.isSyncing = false;
  }

  /**
   * 新设备初始同步
   */
  async performInitialSyncIfNeeded() {
    const result = {
      isNewDevice: false,
      syncPerformed: false,
      entitiesDownloaded: 0,
      relationshipsRestored: 0
    };
    try {
      // 检查是否是新设备
      const lastSyncData = await chrome.storage.local.get(['cache_last_sync_time', 'cache_device_initialized']);
      const isNewDevice = !lastSyncData.cache_device_initialized;
      result.isNewDevice = isNewDevice;
      if (isNewDevice) {
        console.log('🆕 检测到新设备，开始初始同步...');

        // 从云端拉取实体
        const {
          data: cloudEntities
        } = await this.cloudStorage.queryEntities();
        result.entitiesDownloaded = cloudEntities.length;
        if (cloudEntities.length > 0) {
          await this.localStorage.batchCacheEntities(cloudEntities);
        }

        // 恢复关系数据
        const relationshipData = await this.cloudStorage.restoreRelationships();
        if (relationshipData) {
          await this.localStorage.restoreRelationshipData(relationshipData);
          result.relationshipsRestored = relationshipData.relationships.length;
        }

        // 标记设备已初始化
        await chrome.storage.local.set({
          cache_device_initialized: true,
          cache_last_sync_time: Date.now()
        });
        result.syncPerformed = true;
        console.log(`✅ 新设备初始同步完成: ${result.entitiesDownloaded} 个实体, ${result.relationshipsRestored} 个关系`);
      }
      return result;
    } catch (error) {
      console.error('新设备初始同步失败:', error);
      return result;
    }
  }

  /**
   * 备份关系数据到云端
   */
  async backupRelationships() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      // 获取本地关系数据
      const relationshipData = await this.localStorage.getRelationshipBackupData();
      if (!relationshipData) {
        console.log('⚠️ 没有关系数据需要备份');
        return false;
      }
      return await this.cloudStorage.backupRelationships(relationshipData);
    } catch (error) {
      console.error('备份关系数据失败:', error);
      return false;
    }
  }

  /**
   * 创建实体关系
   */
  async createRelationship(relationship) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      const fullRelationship = {
        id: `rel_${relationship.fromId}_${relationship.toId}_${relationship.type}_${Date.now()}`,
        type: relationship.type,
        fromId: relationship.fromId,
        toId: relationship.toId,
        properties: relationship.properties || {},
        strength: relationship.strength || 0.7,
        created: Date.now(),
        updated: Date.now()
      };
      await this.localStorage.cacheRelationship(fullRelationship);
      return true;
    } catch (error) {
      console.error('创建关系失败:', error);
      return false;
    }
  }

  /**
   * 实体时间轴（预留功能，待实现）
   */
  async getEntityTimeline(_entityId, _options) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }

    // 这里可以根据需要实现时间轴逻辑
    // 目前返回空数组，可以根据实际需求扩展
    return [];
  }

  /**
   * 获取系统状态
   */
  async getSystemStatus() {
    return {
      isInitialized: this.isInitialized,
      cloudConnected: await this.cloudStorage.isConnected(),
      localCacheSize: await this.localStorage.getCacheSize(),
      lastSyncTime: await this.getLastSyncTime(),
      performance: await this.getPerformanceMetrics()
    };
  }

  // ==================== 实体相似性管理接口 ====================

  /**
   * 处理实体相似性检测
   */
  async processEntitySimilarity(entity) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.entitySimilarityTool.processEntity(entity);
  }

  /**
   * 批量处理实体相似性
   */
  async processEntitiesSimilarity(entities) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.entitySimilarityTool.processEntities(entities);
  }

  /**
   * 获取待处理的实体合并候选
   */
  async getPendingEntityMerges() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.entitySimilarityTool.getPendingMerges();
  }

  /**
   * 确认实体合并
   */
  async confirmEntityMerge(mergeId) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.entitySimilarityTool.confirmMerge(mergeId);
  }

  /**
   * 拒绝实体合并
   */
  async rejectEntityMerge(mergeId) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.entitySimilarityTool.rejectMerge(mergeId);
  }

  /**
   * 获取实体相似性统计
   */
  getEntitySimilarityStats() {
    return this.entitySimilarityTool.getStatistics();
  }

  // ==================== 系统维护接口 ====================

  /**
   * 执行系统健康检查
   */
  async performHealthCheck() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.systemMaintenanceTool.performHealthCheck();
  }

  /**
   * 执行完整系统维护
   */
  async performSystemMaintenance(options) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.systemMaintenanceTool.performFullMaintenance(options);
  }

  /**
   * 🆕 单独清理实体的过期已读消息
   * @param entityId 可选，指定实体ID；不指定则清理所有实体
   */
  async cleanExpiredConversations(entityId) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.cloudStorage.cleanExpiredReadConversations(entityId);
  }

  /**
   * 获取维护工具状态
   */
  getMaintenanceStatus() {
    return this.systemMaintenanceTool.getSystemStatus();
  }

  // ==================== 用户画像接口 ====================

  /**
   * 获取用户画像
   */
  async getUserProfile() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      return {
        profile: null,
        analysis: null
      };
    }
    try {
      const profile = await this.userProfileManager.getProfile();
      const analysis = await this.userProfileManager.generateAnalysis();
      return {
        profile,
        analysis
      };
    } catch (error) {
      console.error('获取用户画像失败:', error);
      return {
        profile: null,
        analysis: null
      };
    }
  }

  /**
   * 更新用户画像
   */
  async updateUserProfile(update) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      console.warn('用户画像管理器未初始化');
      return false;
    }
    try {
      await this.userProfileManager.updateProfile(update);
      return true;
    } catch (error) {
      console.error('更新用户画像失败:', error);
      return false;
    }
  }

  /**
   * 设置用户明确重要性
   */
  async setUserExplicitImportance(itemId, type, importance) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      return false;
    }
    try {
      await this.userProfileManager.setExplicitImportance(itemId, type, importance);
      return true;
    } catch (error) {
      console.error('设置用户重要性失败:', error);
      return false;
    }
  }

  /**
   * 应用用户画像权重衰变
   */
  async applyUserProfileDecay() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (this.userProfileManager) {
      await this.userProfileManager.applyWeightDecay();
    }
  }

  /**
   * 🆕 融合用户上下文配置到用户画像
   */
  async fuseUserContextConfig(userContextConfig) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      return false;
    }
    try {
      const success = await this.userProfileManager.fuseUserContextConfig(userContextConfig);
      if (success) {
        // 融合成功后执行自适应权重调整
        await this.userProfileManager.adaptiveWeightAdjustment();
      }
      return success;
    } catch (error) {
      console.error('融合用户上下文配置失败:', error);
      return false;
    }
  }

  /**
   * 🆕 执行权重自适应调整
   */
  async adaptiveWeightAdjustment() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (this.userProfileManager) {
      try {
        await this.userProfileManager.adaptiveWeightAdjustment();
      } catch (error) {
        console.error('权重自适应调整失败:', error);
      }
    }
  }

  /**
   * 🆕 生成主动推荐内容
   */
  async generateProactiveRecommendations() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      return [];
    }
    try {
      return await this.userProfileManager.generateProactiveRecommendations();
    } catch (error) {
      console.error('生成主动推荐失败:', error);
      return [];
    }
  }

  /**
   * 🆕 获取融合后的用户画像
   * 返回应用了加权融合算法的兴趣列表
   */
  async getFusedUserProfile() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      return {
        profile: null,
        analysis: null,
        fusedInterests: null
      };
    }
    try {
      const {
        profile,
        analysis
      } = await this.getUserProfile();
      if (!profile) {
        return {
          profile: null,
          analysis: null,
          fusedInterests: null
        };
      }

      // 应用加权融合算法到各个兴趣类别
      const fusedInterests = {
        projects: this.userProfileManager.getFusedInterestItems(profile.interests.projects || []),
        people: this.userProfileManager.getFusedInterestItems(profile.interests.people || []),
        topics: this.userProfileManager.getFusedInterestItems(profile.interests.topics || []),
        jiraTickets: this.userProfileManager.getFusedInterestItems(profile.interests.jiraTickets || []),
        technologies: this.userProfileManager.getFusedInterestItems(profile.interests.technologies || []),
        documents: this.userProfileManager.getFusedInterestItems(profile.interests.documents || [])
      };
      return {
        profile: {
          ...profile,
          interests: fusedInterests
        },
        analysis,
        fusedInterests
      };
    } catch (error) {
      console.error('获取融合用户画像失败:', error);
      return {
        profile: null,
        analysis: null,
        fusedInterests: null
      };
    }
  }

  /**
   * 🆕 存储独立用户配置到云端
   */
  async storeIndependentUserConfig(config) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      const success = await this.cloudStorage.storeIndependentUserConfig(config);
      return success;
    } catch (error) {
      console.error('存储独立用户配置失败:', error);
      return false;
    }
  }

  /**
   * 🆕 获取独立用户配置
   */
  async getIndependentUserConfig() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      const config = await this.cloudStorage.getIndependentUserConfig();
      return config;
    } catch (error) {
      console.error('获取独立用户配置失败:', error);
      return null;
    }
  }

  /**
   * 获取最后同步时间
   */
  async getLastSyncTime() {
    try {
      const result = await chrome.storage.local.get('cache_last_sync_time');
      return result.cache_last_sync_time || 0;
    } catch (error) {
      return 0;
    }
  }

  /**
   * 获取性能指标
   */
  async getPerformanceMetrics() {
    return {
      averageQueryTime: (this.metrics.averageLocalTime + this.metrics.averageCloudTime) / 2,
      cacheHitRate: this.metrics.cacheHitRate
    };
  }

  // ==================== 私有方法 ====================

  /**
   * 启动后台同步 - 现在包含用户画像权重衰变逻辑
   */
  startBackgroundSync() {
    // 防止重复启动
    if (this.backgroundSyncStarted) {
      console.log('⚠️ 后台同步已启动，跳过重复启动');
      return;
    }

    // 检查是否在background script环境中
    const isBackground = typeof ServiceWorkerGlobalScope !== 'undefined' && self instanceof ServiceWorkerGlobalScope;
    if (!isBackground) {
      console.log('⚠️ 非background环境，跳过后台同步启动');
      return;
    }

    // ✅ 定时任务已统一由 TaskScheduler 管理
    // 不再在这里创建独立的 alarm，避免重复执行
    // 
    // TaskScheduler 中已包含以下任务：
    // - 'memory_sync' (scheduled_task_memory_sync) -> 调用 memorySystem.syncCache()
    // - 'user_profile_decay' (scheduled_task_user_profile_decay) -> 调用 memorySystem.applyUserProfileDecay()
    // 
    // 如需调整间隔时间，请在 TaskScheduler.ts 的 TASK_DEFINITIONS 中修改

    // 标记为已启动
    this.backgroundSyncStarted = true;
    console.log('✅ 记忆系统定时任务由 TaskScheduler 统一管理');
    console.log('   - memory_sync: 每5分钟执行一次');
    console.log('   - user_profile_decay: 每24小时执行一次');

    // 注意：首次执行由 TaskScheduler 的 performInitialRun() 处理
    // 不再在这里手动执行首次同步和衰变

    // 保留 setupAlarmListener 以兼容旧代码，但实际不再创建 alarm
    this.setupAlarmListener();
  }

  /**
   * 设置 alarm 监听器
   * 
   * ⚠️ 已废弃：此方法保留仅用于向后兼容
   * 
   * 所有定时任务现在由 TaskScheduler 统一管理：
   * - 'memory_sync' -> memorySystem.syncCache()
   * - 'user_profile_decay' -> memorySystem.applyUserProfileDecay()
   * 
   * 不再需要独立的 alarm 监听器
   */
  setupAlarmListener() {
    if (this.alarmListenerAdded) {
      return;
    }
    this.alarmListenerAdded = true;
    console.log('✅ 记忆系统定时任务已交由 TaskScheduler 统一管理');
  }

  /**
   * 执行用户画像权重衰变
   */

  /**
   * 清理实体名称，处理中文和特殊字符
   */
  sanitizeEntityName(name) {
    if (!name || name.trim() === '') {
      return 'entity';
    }

    // 简单的中文转拼音映射（部分常用字符）
    const chineseToPinyin = {
      '项目': 'xiangmu',
      '文档': 'wendang',
      '人员': 'renyuan',
      '主题': 'zhuti',
      '任务': 'renwu',
      '团队': 'tuandui',
      '公司': 'gongsi',
      '系统': 'xitong',
      '数据': 'shuju',
      '功能': 'gongneng',
      '需求': 'xuqiu',
      '设计': 'sheji',
      '开发': 'kaifa',
      '测试': 'ceshi',
      '部署': 'bushu',
      '维护': 'weihu',
      '管理': 'guanli',
      '分析': 'fenxi',
      '报告': 'baogao',
      '会议': 'huiyi'
    };
    let cleanName = name.trim();

    // 替换中文词汇为拼音
    for (const [chinese, pinyin] of Object.entries(chineseToPinyin)) {
      cleanName = cleanName.replace(new RegExp(chinese, 'g'), pinyin);
    }

    // 移除其他中文字符（通过Unicode范围）
    cleanName = cleanName.replace(/[\u4e00-\u9fff]/g, '');

    // 只保留字母、数字和连字符
    cleanName = cleanName.replace(/[^a-zA-Z0-9\-_]/g, '');

    // 移除多余的连字符和下划线
    cleanName = cleanName.replace(/[-_]+/g, '_');

    // 移除开头和结尾的连字符和下划线
    cleanName = cleanName.replace(/^[-_]+|[-_]+$/g, '');

    // 限制长度并确保不为空
    if (cleanName.length === 0) {
      cleanName = 'entity';
    } else if (cleanName.length > 20) {
      cleanName = cleanName.substring(0, 20);
    }

    // 确保以字母开头
    if (!/^[a-zA-Z]/.test(cleanName)) {
      cleanName = 'entity_' + cleanName;
    }
    return cleanName.toLowerCase();
  }
  async queryFromLocal(type, searchTerm) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    if (type) {
      return this.localStorage.queryEntitiesByType(type, options);
    } else if (searchTerm) {
      return this.localStorage.searchEntities(searchTerm, type, options);
    } else {
      // 返回所有实体（分页）
      return {
        data: [],
        total: 0,
        source: 'local',
        cached: true,
        queryTime: 0
      };
    }
  }
  async queryFromCloud(type, searchTerm) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    // 如果有搜索词且长度大于2，使用向量搜索获得更好的语义匹配
    if (searchTerm && searchTerm.length > 2 && !type) {
      // 转换为向量搜索选项
      const vectorOptions = {
        limit: options.limit,
        offset: options.offset,
        useCache: options.useCache,
        includeCounts: options.includeCounts,
        sortBy: options.sortBy === 'relevance' ? 'relevance' : options.sortBy === 'importance' ? 'importance' : 'relevance',
        sortOrder: options.sortOrder
      };
      return this.cloudStorage.searchByVector(searchTerm, type, vectorOptions);
    }

    // 使用新的云端实体查询接口，支持按type过滤
    return this.cloudStorage.queryEntities(type, searchTerm, options);
  }
  async cacheCloudResults(entities) {
    try {
      if (entities.length > 0) {
        await this.localStorage.batchCacheEntities(entities);
      }
    } catch (error) {
      console.error('缓存云端结果失败:', error);
    }
  }
  async removeFromLocalCache(entityId) {
    try {
      await chrome.storage.local.remove(`cache_entities_${entityId}`);
      // 这里还需要更新索引等，但为了简化暂时省略
      return true;
    } catch (error) {
      console.error('从本地缓存删除失败:', error);
      return false;
    }
  }
  updateMetrics(source, queryTime) {
    if (source === 'local' || source === 'hybrid') {
      this.metrics.localHits++;
      this.metrics.averageLocalTime = (this.metrics.averageLocalTime * (this.metrics.localHits - 1) + queryTime) / this.metrics.localHits;
    }
    if (source === 'cloud' || source === 'hybrid') {
      this.metrics.cloudHits++;
      this.metrics.averageCloudTime = (this.metrics.averageCloudTime * (this.metrics.cloudHits - 1) + queryTime) / this.metrics.cloudHits;
    }

    // 更新缓存命中率
    this.metrics.cacheHitRate = this.metrics.localHits / this.metrics.totalQueries;
  }
  async loadConfig() {
    try {
      const result = await chrome.storage.local.get('cache_strategy_config');
      if (result.cache_strategy_config) {
        this.config = {
          ...this.config,
          ...result.cache_strategy_config
        };
      }
    } catch (error) {
      console.warn('加载缓存策略配置失败，使用默认配置');
    }
  }
  async loadMetrics() {
    try {
      const result = await chrome.storage.local.get('cache_strategy_metrics');
      if (result.cache_strategy_metrics) {
        this.metrics = {
          ...this.metrics,
          ...result.cache_strategy_metrics
        };
      }
    } catch (error) {
      console.warn('加载性能指标失败，使用默认值');
    }
  }
  async delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

  /**
   * 从缓存扩展实体信息：直接合并缓存数据（简化版）
   */
  async extendEntitiesFromCache(entities) {
    const extendedEntities = [];
    for (const entity of entities) {
      const extendedEntity = {
        ...entity,
        cachedAt: Date.now(),
        // 初始化必要的数组字段
        recentDataDetails: {
          conversations: [],
          webpages: [],
          resources: [],
          projects: [],
          people: [],
          topics: [],
          jiraTickets: [],
          cooccurringEntities: []
        },
        relatedParticipants: []
      };
      try {
        // 获取扩展缓存数据
        const cacheData = await this.localStorage.getEntity(entity.id);
        if (cacheData) {
          // 直接合并缓存数据到实体对象
          Object.assign(extendedEntity, cacheData);
        } else {
          // 没有缓存数据时，设置默认值  
          this.setDefaultExtendedFields(extendedEntity, entity);
        }
      } catch (error) {
        console.error(`扩展实体 ${entity.id} 信息失败:`, error);
        // 设置默认值
        this.setDefaultExtendedFields(extendedEntity, entity);
      }
      extendedEntities.push(extendedEntity);
    }
    return extendedEntities;
  }

  /**
   * 设置扩展字段的默认值
   */
  setDefaultExtendedFields(extendedEntity, entity) {
    // 设置必要的数组字段默认值
    if (!extendedEntity.recentDataDetails) {
      extendedEntity.recentDataDetails = {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      };
    }

    // 确保统计字段存在
    if (!extendedEntity.statistic) {
      extendedEntity.statistic = {
        conversations: 0,
        projects: 0,
        participants: 1,
        resources: 0,
        documents: 0,
        webpages: 0,
        relationships: entity.properties?.relationshipsCount || 0,
        topics: 0,
        jiraTickets: 0
      };
    }

    // 根据实体类型设置特定默认值
    if (entity.type === 'Person') {
      extendedEntity.role = entity.properties?.role || '团队成员';
      extendedEntity.team = entity.properties?.team || '';
      extendedEntity.expertise = entity.properties?.expertise || entity.tags || [];
    }
    if (entity.type === 'Project') {
      extendedEntity.isHighlighted = entity.properties?.isHighlighted || false;
    }
  }

  /**
   * 执行云端到本地单向同步 - 只从云端拉取数据到本地缓存
   */
  async performCloudToLocalSync() {
    try {
      const lastSyncData = await chrome.storage.local.get('cache_last_sync_time');
      const lastSyncTime = lastSyncData.cache_last_sync_time || 0;

      // 如果距离上次同步不足5分钟，跳过同步
      if (Date.now() - lastSyncTime < 5 * 60 * 1000) {
        console.log('⏭️ 距离上次单向同步不足5分钟，跳过');
        return;
      }
      console.log('📥 开始云端到本地单向同步...');
      let syncedEntities = 0;
      let recentDataUpdated = 0;

      // 1. 从云端拉取所有实体
      const {
        data: cloudEntities
      } = await this.cloudStorage.queryEntities();

      // 2. 批量同步云端实体到本地
      const cloudBatches = this.chunkArray(cloudEntities, 20); // 每批最多20个
      const entitiesToUpdate = [];
      for (const batch of cloudBatches) {
        for (const entity of batch) {
          const localEntity = await this.localStorage.getEntity(entity.id);
          if (!localEntity || localEntity.updated < entity.updated) {
            // 🔄 缓存实体到本地
            await this.localStorage.cacheEntity(entity);
            syncedEntities++;
            entitiesToUpdate.push(entity);
          }
        }

        // 批间延迟，避免阻塞
        if (cloudBatches.length > 1) {
          await this.delay(100);
        }
      }

      // 3. 🆕 关联数据现在直接存储在 MemoryEntity.relatedData 中，无需单独同步关系
      console.log(`📊 实体关联数据已通过 MemoryEntity.relatedData 同步，无需额外关系处理`);
      if (entitiesToUpdate.length > 0) {
        recentDataUpdated = entitiesToUpdate.length;
      }

      // 4. 🆕 统计所有实体类型的数量并缓存到本地
      await this.syncEntityCountsToCache(cloudEntities);
      console.log(`✅ 单向同步完成: 同步了${syncedEntities}个实体，更新了${recentDataUpdated}个实体的最近数据缓存`);
    } catch (error) {
      console.error('❌ 云端到本地同步失败:', error);
    }
  }

  /**
   * 上传本地统计信息到云端
   */
  async uploadLocalStatisticsToCloud() {
    try {
      console.log('📊 开始上传本地统计信息到云端...');

      // 获取所有本地缓存的实体
      const recentDataEntries = await this.localStorage.getAllRecentDataEntries();
      if (!recentDataEntries || recentDataEntries.length === 0) {
        console.log('📊 没有本地统计信息需要上传');
        return;
      }

      // 收集需要更新的统计信息
      const statisticsUpdates = [];
      for (const entry of recentDataEntries) {
        try {
          // 计算当前统计信息
          const updatedStatistic = entry.statistic;
          statisticsUpdates.push({
            entityId: entry.id,
            statistic: updatedStatistic,
            lastUpdated: entry.lastUpdated || Date.now()
          });
        } catch (error) {
          console.error(`处理实体 ${entry.id} 统计信息失败:`, error);
        }
      }
      if (statisticsUpdates.length === 0) {
        console.log('📊 没有有效的统计信息需要上传');
        return;
      }

      // 批量更新云端实体的统计信息
      await this.cloudStorage.batchUpdateEntityStatistics(statisticsUpdates);
      console.log(`📊 成功上传 ${statisticsUpdates.length} 个实体的统计信息`);
    } catch (error) {
      console.error('📊 上传统计信息失败:', error);
    }
  }

  /**
   * 上传本地已读状态到云端
   */
  async uploadLocalReadStatusToCloud() {
    try {
      console.log('📖 开始上传本地已读状态到云端...');

      // 获取所有本地缓存的实体
      const recentDataEntries = await this.localStorage.getAllRecentDataEntries();
      if (!recentDataEntries || recentDataEntries.length === 0) {
        console.log('📖 没有本地已读状态需要上传');
        return;
      }

      // 收集需要更新的已读状态（只处理有 readStatus 的实体）
      const readStatusUpdates = [];
      for (const entry of recentDataEntries) {
        try {
          // 只上传有 readStatus 的实体（通常是 Topic 类型）
          if (entry.readStatus) {
            readStatusUpdates.push({
              entityId: entry.id,
              readStatus: entry.readStatus
            });
          }
        } catch (error) {
          console.error(`处理实体 ${entry.id} 已读状态失败:`, error);
        }
      }
      if (readStatusUpdates.length === 0) {
        console.log('📖 没有有效的已读状态需要上传');
        return;
      }

      // 批量更新云端实体的已读状态
      await this.cloudStorage.batchUpdateEntityReadStatus(readStatusUpdates);
      console.log(`📖 成功上传 ${readStatusUpdates.length} 个实体的已读状态`);
    } catch (error) {
      console.error('📖 上传已读状态失败:', error);
    }
  }

  /**
   * 初始化用户画像管理器
   */
  async initializeUserProfile() {
    try {
      // 重用现有的 CloudStorage 实例，避免重复初始化
      // UserProfileManager 现在会在 initialize() 时自动获取用户信息
      this.userProfileManager = new UserProfileManager/* UserProfileManager */.e(undefined, this.cloudStorage);
      await this.userProfileManager.initialize();
      console.log('✅ 用户画像管理器初始化成功');
    } catch (error) {
      console.error('❌ 用户画像管理器初始化失败:', error);
      // 不要抛出异常，允许记忆系统继续运行
    }
  }

  /**
   * 根据消息数据智能推断用户行为类型
   */
  inferActionTypeFromMessageData(messageData) {
    // 优先使用LLM分析提供的用户关系类型
    const userRelationType = messageData.metadata?.user_relation_type;
    if (userRelationType) {
      return this.mapUserRelationTypeToActionType(userRelationType);
    }
    const matchedRules = messageData.metadata?.matchedRules || [];
    const _sender = messageData.metadata?.sender || '';
    const messageContent = messageData.content || '';

    // 检查是否明确提到用户
    const mentionKeywords = ['@我', '@你', '提到我', '需要你', '你来', '你的'];
    const hasMention = mentionKeywords.some(keyword => messageContent.includes(keyword));
    if (hasMention) {
      return 'mention';
    }

    // 根据匹配规则推断行为类型
    for (const rule of matchedRules) {
      const lowerRule = rule.toLowerCase();

      // 项目相关消息 - 通常是查看项目进展
      if (lowerRule.includes('recording') || lowerRule.includes('project') || lowerRule.includes('dependencies')) {
        return 'view';
      }

      // 政策消息 - 通常需要关注/查看
      if (lowerRule.includes('政策') || lowerRule.includes('policy') || lowerRule.includes('规定')) {
        return 'view';
      }

      // 特定人员消息 - 算作查看行为
      if (lowerRule.includes('sophia') || lowerRule.includes('jinmei') || lowerRule.includes('发送的所有消息')) {
        return 'view';
      }

      // 明确@我的消息
      if (lowerRule.includes('@我') || lowerRule.includes('mention')) {
        return 'mention';
      }
    }

    // 默认返回view（浏览/关注）
    return 'view';
  }

  /**
   * 将LLM分析的用户关系类型映射到actionType
   */
  mapUserRelationTypeToActionType(userRelationType) {
    const lowerType = userRelationType.toLowerCase();
    if (lowerType.includes('mention')) {
      return 'mention';
    } else if (lowerType.includes('project_related')) {
      return 'view';
    } else if (lowerType.includes('policy_related')) {
      return 'view';
    } else if (lowerType.includes('person_tracking')) {
      return 'view'; // 改为view而不是social
    } else if (lowerType.includes('general_interest')) {
      return 'view';
    }

    // 默认返回view
    return 'view';
  }

  /**
   * 🆕 合并并排序conversations，保持isRead状态
   * 保留策略：所有未读消息 + 最新5条已读消息
   */
  mergeAndSortConversations(existingConversations, newConversations) {
    const conversationsMap = new Map();

    // 先添加已存在的conversations（保持isRead状态）
    existingConversations.forEach(conv => {
      conversationsMap.set(conv.id, conv);
    });

    // 合并新的conversations
    newConversations.forEach(conv => {
      if (conversationsMap.has(conv.id)) {
        // 已存在的conversation，保持其isRead状态
        const existing = conversationsMap.get(conv.id);
        conversationsMap.set(conv.id, {
          ...conv,
          isRead: existing.isRead !== undefined ? existing.isRead : conv.isRead || false,
          readTimestamp: existing.readTimestamp
        });
      } else {
        // 新conversation
        conversationsMap.set(conv.id, {
          ...conv,
          isRead: conv.isRead !== undefined ? conv.isRead : false
        });
      }
    });

    // 🆕 智能保留策略：保留所有未读 + 最新5条已读
    const unreadConversations = Array.from(conversationsMap.values()).filter(c => !c.isRead);
    const readConversations = Array.from(conversationsMap.values()).filter(c => c.isRead);

    // 保留所有未读 + 补充已读到5条
    const needReadCount = Math.max(0, 5 - unreadConversations.length);
    const finalConversations = [...unreadConversations, ...readConversations.slice(0, needReadCount)];

    // 按时间排序（最新的在前）
    finalConversations.sort((a, b) => {
      const timeA = new Date(a.datetime || 0).getTime();
      const timeB = new Date(b.datetime || 0).getTime();
      return timeB - timeA;
    });
    return finalConversations;
  }

  /**
   * 从实体列表更新用户画像
   */
  async updateUserProfileFromEntities(entities, baseAction) {
    if (!this.userProfileManager) return;
    try {
      for (const entity of entities) {
        // 映射实体类型到用户画像类型
        let profileType;
        switch (entity.type) {
          case 'Person':
            profileType = 'person';
            break;
          case 'Project':
            profileType = 'project';
            break;
          case 'Task':
            profileType = 'jira';
            break;
          case 'Technology':
            profileType = 'technology';
            break;
          case 'Document':
            profileType = 'document';
            break;
          case 'Topic':
          default:
            profileType = 'topic';
            break;
        }

        // 根据实体类型调整权重
        let weight = 0.1; // 默认权重
        switch (profileType) {
          case 'project':
            weight *= 1.5; // 项目权重更高
            break;
          case 'person':
            weight *= 1.3; // 人员权重稍高
            break;
          case 'jira':
            weight *= 1.2; // JIRA 权重稍高
            break;
          default:
            break;
        }
        const action = {
          ...baseAction,
          weight
        };
        await this.userProfileManager.updateProfile({
          userId: this.userProfileManager.userId,
          action,
          targetItem: {
            id: entity.name.replace(/\s+/g, '_').toLowerCase(),
            type: profileType,
            name: entity.name,
            metadata: {
              entityType: entity.type,
              document: entity.document,
              importance: entity.importance,
              tags: entity.tags
            }
          }
        });
      }
    } catch (error) {
      console.error('从实体更新用户画像失败:', error);
    }
  }
}

// 导出单例实例
const memorySystem = new MemorySystem();

/***/ }),

/***/ 9857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   e: () => (/* binding */ UserProfileManager)
/* harmony export */ });
/* harmony import */ var _storage_CloudStorage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8143);
/**
 * 用户画像管理器
 * 负责分散式向量存储的用户画像管理
 */


class UserProfileManager {
  // 5分钟缓存过期

  constructor(userId, cloudStorage) {
    this.displayName = '';
    this.recordsCache = new Map();
    this.lastCacheUpdate = 0;
    this.cacheExpiryTime = 5 * 60 * 1000;
    this.userId = userId || 'default_user'; // 临时默认值，将在initialize中更新
    this.cloudStorage = cloudStorage || new _storage_CloudStorage__WEBPACK_IMPORTED_MODULE_0__/* .CloudStorage */ .f();
  }

  /**
   * 初始化管理器
   */
  async initialize() {
    try {
      // 获取真实的用户信息
      await this.loadUserInfo();

      // 确保CloudStorage已连接
      if (!(await this.cloudStorage.isConnected())) {
        await this.cloudStorage.initialize();
      }

      // 初始化缓存
      await this.refreshCache();
      console.log(`✅ 用户画像管理器初始化成功: ${this.userId} (${this.displayName})`);
      return true;
    } catch (error) {
      console.error('用户画像管理器初始化失败:', error);
      return false;
    }
  }

  /**
   * 从localStorage加载用户信息
   */
  async loadUserInfo() {
    try {
      const result = await chrome.storage.local.get(['userinfo']);
      const userinfo = result.userinfo;
      if (userinfo) {
        // 使用username作为userId，fullName作为显示名
        this.userId = userinfo.username || userinfo.extensionId || 'default_user';
        this.displayName = userinfo.fullName || userinfo.username || 'Unknown User';
        console.log(`📝 用户信息加载成功: ${this.userId} (${this.displayName})`);
      } else {
        console.warn('⚠️ 未找到用户信息，使用默认值');
        this.userId = 'default_user';
        this.displayName = 'Default User';
      }
    } catch (error) {
      console.error('获取用户信息失败:', error);
      // 保持默认值
      this.userId = 'default_user';
      this.displayName = 'Default User';
    }
  }

  /**
   * 更新用户画像（兼容旧接口）
   */
  async updateProfile(update) {
    try {
      // 1. 更新兴趣项
      const interestSuccess = await this.updateInterestItem(update);
      if (!interestSuccess) {
        console.warn(`Failed to update interest item for ${update.targetItem.name}`);
      }

      // 2. 更新行为模式
      await this.updateBehaviorPattern({
        userId: update.userId,
        actionType: update.action.actionType,
        timestamp: update.action.timestamp,
        context: update.action.context || '',
        targetType: update.targetItem.type,
        targetId: update.targetItem.id
      });

      // 3. 更新统计数据（通过行为记录自动统计）
      await this.updateUserStatistics(update.action);

      // 4. 重新计算衍生偏好（基于最新的向量化数据）
      await this.recalculateDerivedPreferences();
      console.log(`✅ Profile updated successfully for ${update.targetItem.name}`);
    } catch (error) {
      console.error('Failed to update profile:', error);
      throw new Error(`Failed to update profile for ${update.targetItem.name}: ${error.message}`);
    }
  }

  /**
   * 更新用户统计数据
   */
  async updateUserStatistics(action) {
    try {
      const statsRecordId = `${this.userId}_user_summary_statistics`;

      // 查找现有统计记录
      let existingStats = this.recordsCache.get(statsRecordId);
      if (!existingStats) {
        // 尝试从云端获取
        const queryResult = await this.cloudStorage.searchByVector('user statistics', undefined, {
          collections: ['userprofiles'],
          returnType: 'userprofiles',
          where: {
            user_id: this.userId,
            record_type: {
              $in: ['user_summary']
            },
            summary_type: 'statistics'
          },
          limit: 1
        });
        if (queryResult.data.length > 0) {
          existingStats = queryResult.data[0];
          this.recordsCache.set(statsRecordId, existingStats);
        }
      }
      if (!existingStats) {
        // 创建新的统计记录
        existingStats = {
          id: statsRecordId,
          document: `用户 ${this.userId} 的统计数据汇总`,
          metadata: {
            record_type: 'user_summary',
            user_id: this.userId,
            created_at: Date.now(),
            updated_at: Date.now(),
            summary_type: 'statistics',
            total_interactions: 1,
            daily_activity_average: 1,
            most_active_day: new Date().toISOString().split('T')[0],
            top_interaction_types: {
              [action.actionType]: 1
            },
            last_activity: action.timestamp
          }
        };
      } else {
        // 更新统计数据
        const metadata = existingStats.metadata;
        metadata.total_interactions = (metadata.total_interactions || 0) + 1;
        metadata.updated_at = Date.now();
        metadata.last_activity = action.timestamp;

        // 更新交互类型统计
        const topTypes = metadata.top_interaction_types || {};
        topTypes[action.actionType] = (topTypes[action.actionType] || 0) + 1;
        metadata.top_interaction_types = topTypes;

        // 计算日平均活动
        const daysSinceCreated = Math.max(1, Math.floor((Date.now() - metadata.created_at) / (24 * 60 * 60 * 1000)));
        metadata.daily_activity_average = metadata.total_interactions / daysSinceCreated;

        // 更新文档描述
        existingStats.document = `用户 ${this.userId} 的统计数据汇总：总交互${metadata.total_interactions}次，日均活动${metadata.daily_activity_average.toFixed(1)}次`;
      }

      // 存储更新后的统计记录
      await this.cloudStorage.storeUserprofilesRecord(existingStats);
      this.recordsCache.set(statsRecordId, existingStats);
    } catch (error) {
      console.error('Failed to update user statistics:', error);
    }
  }

  /**
   * 重新计算衍生偏好
   */
  async recalculateDerivedPreferences() {
    try {
      const preferencesRecordId = `${this.userId}_user_summary_preferences`;

      // 获取用户的所有兴趣项记录
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item' && record.metadata.user_id === this.userId);
      if (interestRecords.length === 0) return;

      // 分析偏好项目类型
      const projectTypes = new Map();
      const expertiseAreas = new Map();
      const collaborators = new Map();
      interestRecords.forEach(record => {
        const metadata = record.metadata;

        // 统计项目类型偏好
        if (metadata.interest_category === 'project' && metadata.project_type) {
          projectTypes.set(metadata.project_type, (projectTypes.get(metadata.project_type) || 0) + metadata.current_weight);
        }

        // 统计专业领域
        if (metadata.interest_category === 'technology' && metadata.technology_stack) {
          metadata.technology_stack.forEach(tech => {
            expertiseAreas.set(tech, (expertiseAreas.get(tech) || 0) + metadata.current_weight);
          });
        }

        // 统计协作者
        if (metadata.interest_category === 'person') {
          collaborators.set(metadata.name, (collaborators.get(metadata.name) || 0) + metadata.current_weight);
        }
      });

      // 生成偏好记录
      const preferencesRecord = {
        id: preferencesRecordId,
        document: `用户 ${this.userId} 的衍生偏好分析：` + `偏好项目类型${Array.from(projectTypes.keys()).slice(0, 3).join('、')}，` + `专业领域包括${Array.from(expertiseAreas.keys()).slice(0, 5).join('、')}，` + `主要协作者有${Array.from(collaborators.keys()).slice(0, 3).join('、')}`,
        metadata: {
          record_type: 'user_summary',
          user_id: this.userId,
          created_at: this.recordsCache.get(preferencesRecordId)?.metadata.created_at || Date.now(),
          updated_at: Date.now(),
          summary_type: 'derived_preferences',
          preferred_project_types: Array.from(projectTypes.entries()).sort((a, b) => b[1] - a[1]).slice(0, 5).map(_ref => {
            let [type] = _ref;
            return type;
          }),
          expertise_areas: Array.from(expertiseAreas.entries()).sort((a, b) => b[1] - a[1]).slice(0, 10).map(_ref2 => {
            let [area] = _ref2;
            return area;
          }),
          key_collaborators: Array.from(collaborators.entries()).sort((a, b) => b[1] - a[1]).slice(0, 10).map(_ref3 => {
            let [name] = _ref3;
            return name;
          }),
          risk_sensitivity: this.calculateRiskSensitivity(interestRecords),
          update_frequency: this.calculateUpdateFrequency(interestRecords)
        }
      };

      // 存储偏好记录
      await this.cloudStorage.storeUserprofilesRecord(preferencesRecord);
      this.recordsCache.set(preferencesRecordId, preferencesRecord);
    } catch (error) {
      console.error('Failed to recalculate derived preferences:', error);
    }
  }

  /**
   * 计算风险敏感度
   */
  calculateRiskSensitivity(interestRecords) {
    const totalWeight = interestRecords.reduce((sum, record) => sum + record.metadata.current_weight, 0);
    const diversityScore = new Set(interestRecords.map(r => r.metadata.interest_category)).size;
    if (diversityScore >= 4 && totalWeight > 5) return 'low';
    if (diversityScore >= 2 && totalWeight > 3) return 'medium';
    return 'high';
  }

  /**
   * 计算更新频率模式
   */
  calculateUpdateFrequency(interestRecords) {
    const now = Date.now();
    const recentUpdates = interestRecords.filter(record => now - record.metadata.last_accessed < 7 * 24 * 60 * 60 * 1000).length;
    if (recentUpdates >= 10) return 'daily';
    if (recentUpdates >= 3) return 'weekly';
    return 'monthly';
  }

  /**
   * 更新兴趣项
   */
  async updateInterestItem(update) {
    try {
      const {
        targetItem,
        action
      } = update;
      const recordId = `${this.userId}_interest_${targetItem.type}_${this.sanitizeId(targetItem.id)}`;

      // 查找现有记录
      let existingRecord = this.recordsCache.get(recordId);
      if (!existingRecord) {
        // 尝试从云端获取
        const queryResult = await this.cloudStorage.queryUserprofiles({
          user_id: this.userId,
          record_types: ['interest_item'],
          metadata_filters: {
            name: targetItem.name,
            interest_category: targetItem.type
          }
        });
        if (queryResult.records.length > 0) {
          existingRecord = queryResult.records[0];
          this.recordsCache.set(recordId, existingRecord);
        }
      }
      if (existingRecord) {
        // 更新现有记录
        await this.updateExistingInterestRecord(existingRecord, action);
      } else {
        // 创建新记录
        await this.createNewInterestRecord(recordId, targetItem, action);
      }
      return true;
    } catch (error) {
      console.error('更新兴趣项失败:', error);
      return false;
    }
  }

  /**
   * 更新行为模式
   */
  async updateBehaviorPattern(data) {
    try {
      const recordId = `${this.userId}_behavior_pattern_${data.actionType}_${Date.now()}`;

      // 创建行为模式记录
      const behaviorRecord = {
        id: recordId,
        document: this.generateBehaviorPatternDocument(data),
        metadata: {
          record_type: 'behavior_pattern',
          user_id: this.userId,
          created_at: data.timestamp,
          updated_at: data.timestamp,
          pattern_type: this.getPatternType(data.actionType),
          // 根据行为类型设置相应的元数据
          ...this.getBehaviorSpecificMetadata(data)
        }
      };

      // 存储记录
      await this.cloudStorage.storeUserprofilesRecord(behaviorRecord);
      this.recordsCache.set(recordId, behaviorRecord);
      return true;
    } catch (error) {
      console.error('更新行为模式失败:', error);
      return false;
    }
  }

  /**
   * 查询兴趣项
   */
  async queryInterestItems() {
    let options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    try {
      const {
        category,
        searchQuery = '',
        limit = 20,
        sortBy = 'weight'
      } = options;

      // 构建查询选项
      const queryOptions = {
        user_id: this.userId,
        record_types: ['interest_item'],
        limit
      };
      if (category) {
        queryOptions.metadata_filters = {
          interest_category: category
        };
      }

      // 执行查询
      const result = await this.cloudStorage.searchByVector(searchQuery, undefined, {
        collections: ['userprofiles'],
        returnType: 'userprofiles',
        where: queryOptions.metadata_filters || {},
        limit: queryOptions.limit || 20
      });

      // 类型转换和排序
      const interestRecords = result.data;
      return this.sortInterestItems(interestRecords, sortBy);
    } catch (error) {
      console.error('查询兴趣项失败:', error);
      return [];
    }
  }

  /**
   * 查找相似用户
   */
  async findSimilarUsers() {
    let options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    try {
      const {
        limit = 10,
        similarityThreshold = 0.3
      } = options;

      // 获取用户的主要兴趣描述
      const userInterests = await this.queryInterestItems({
        limit: 10,
        sortBy: 'weight'
      });
      const queryText = userInterests.map(item => item.document).join(' ');
      if (!queryText.trim()) {
        return [];
      }

      // 查找相似用户
      return await this.cloudStorage.findSimilarUsers(this.userId, queryText, {
        record_types: ['interest_item'],
        limit,
        similarity_threshold: similarityThreshold
      });
    } catch (error) {
      console.error('查找相似用户失败:', error);
      return [];
    }
  }

  /**
   * 根据行为模式查找用户
   */
  async findUsersByBehaviorPattern(patternType) {
    let _options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    // 占位符实现，后续可扩展
    return [];
  }

  /**
   * 查找话题相关兴趣
   */
  async findTopicRelatedInterests(topic) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    try {
      const {
        limit = 10
      } = options;
      const result = await this.cloudStorage.searchByVector(topic, undefined, {
        collections: ['userprofiles'],
        returnType: 'userprofiles',
        where: {
          user_id: this.userId,
          record_type: {
            $in: ['interest_item']
          }
        },
        limit
      });
      return result.data;
    } catch (error) {
      console.error('查找话题相关兴趣失败:', error);
      return [];
    }
  }

  /**
   * 生成用户画像分析
   */
  async generateAnalysis() {
    try {
      await this.refreshCacheIfNeeded();
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item');
      const behaviorRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'behavior_pattern');
      const topItemsByCategory = this.getTopItemsByCategory(interestRecords);
      const behaviorAnalysis = this.analyzeBehaviorPatterns(behaviorRecords);
      return {
        userId: this.userId,
        timestamp: Date.now(),
        // 当前最关注的内容
        topInterests: {
          projects: topItemsByCategory.project?.map(item => item.name) || [],
          people: topItemsByCategory.person?.map(item => item.name) || [],
          topics: topItemsByCategory.topic?.map(item => item.name) || []
        },
        // 预测的兴趣
        predictedInterests: this.predictInterests(interestRecords),
        // 行为洞察
        insights: {
          workingPattern: behaviorAnalysis.activeHours?.length > 0 ? `主要活跃时间：${behaviorAnalysis.activeHours.join('、')}点` : '暂无数据',
          collaborationStyle: behaviorAnalysis.communicationStyle || 'semi-formal',
          focusAreas: topItemsByCategory.technology?.map(item => item.name) || [],
          suggestedContent: this.generateContentSuggestions(interestRecords)
        }
      };
    } catch (error) {
      console.error('生成用户画像分析失败:', error);
      throw error;
    }
  }

  /**
   * 获取画像统计信息
   */
  async getProfileStats() {
    try {
      await this.refreshCacheIfNeeded();
      const records = Array.from(this.recordsCache.values());
      const recordsByType = {};
      let lastActivity = 0;
      records.forEach(record => {
        const type = record.metadata.record_type;
        recordsByType[type] = (recordsByType[type] || 0) + 1;
        if (record.metadata.last_accessed && record.metadata.last_accessed > lastActivity) {
          lastActivity = record.metadata.last_accessed;
        }
      });

      // 简单的健康度计算
      const healthScore = Math.min(records.length / 50, 1); // 假设50个记录为满分

      return {
        totalRecords: records.length,
        recordsByType,
        lastActivity,
        healthScore
      };
    } catch (error) {
      console.error('获取画像统计失败:', error);
      return {
        totalRecords: 0,
        recordsByType: {},
        lastActivity: 0,
        healthScore: 0
      };
    }
  }

  /**
   * 刷新缓存
   */
  async refreshCache() {
    try {
      const result = await this.cloudStorage.queryUserprofiles({
        user_id: this.userId,
        limit: 1000 // 获取用户的所有记录
      });
      this.recordsCache.clear();
      result.records.forEach(record => {
        this.recordsCache.set(record.id, record);
      });
      this.lastCacheUpdate = Date.now();
      console.log(`缓存已刷新，加载了 ${result.records.length} 条记录`);
    } catch (error) {
      console.error('刷新缓存失败:', error);
    }
  }

  /**
   * 按需刷新缓存
   */
  async refreshCacheIfNeeded() {
    if (Date.now() - this.lastCacheUpdate > this.cacheExpiryTime) {
      await this.refreshCache();
    }
  }

  // =================== 以下为兼容旧接口的方法 ===================

  /**
   * 获取用户画像（向后兼容）
   */
  async getProfile() {
    try {
      await this.refreshCacheIfNeeded();
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item');
      const behaviorRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'behavior_pattern');
      const summaryRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'user_summary');
      if (interestRecords.length === 0) {
        return null;
      }

      // 重构用户画像对象
      return {
        userId: this.userId,
        createdAt: Math.min(...interestRecords.map(r => r.metadata.created_at)),
        lastUpdated: Math.max(...interestRecords.map(r => r.metadata.updated_at)),
        interests: this.reconstructInterestItems(interestRecords),
        behaviorPatterns: this.reconstructBehaviorPatterns(behaviorRecords),
        derivedPreferences: this.reconstructDerivedPreferences(summaryRecords),
        statistics: this.calculateStatistics(interestRecords, summaryRecords)
      };
    } catch (error) {
      console.error('获取用户画像失败:', error);
      return null;
    }
  }

  /**
   * 设置明确重要性
   */
  async setExplicitImportance(itemId, type, importance) {
    try {
      const recordId = `${this.userId}_interest_${type}_${this.sanitizeId(itemId)}`;
      const record = this.recordsCache.get(recordId);
      if (record) {
        record.metadata.explicit_importance = importance;
        record.metadata.updated_at = Date.now();
        await this.cloudStorage.storeUserprofilesRecord(record);
        return true;
      }
      return false;
    } catch (error) {
      console.error('设置明确重要性失败:', error);
      return false;
    }
  }

  /**
   * 应用权重衰减
   */
  async applyWeightDecay() {
    try {
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item');
      const now = Date.now();
      const oneDay = 24 * 60 * 60 * 1000;
      for (const record of interestRecords) {
        const daysSinceLastAccess = (now - (record.metadata.last_accessed || record.metadata.created_at)) / oneDay;

        // 简单的衰减公式
        const decayFactor = Math.exp(-daysSinceLastAccess / 30); // 30天为衰减周期
        record.metadata.current_weight *= decayFactor;
        record.metadata.updated_at = now;
        await this.cloudStorage.storeUserprofilesRecord(record);
      }
      console.log(`权重衰减应用完成，更新了 ${interestRecords.length} 条记录`);
    } catch (error) {
      console.error('应用权重衰减失败:', error);
    }
  }

  /**
   * 融合用户上下文配置
   */
  async fuseUserContextConfig(userContextConfig) {
    try {
      const configRecordId = `${this.userId}_user_summary_context_config`;
      const configRecord = {
        id: configRecordId,
        document: `用户 ${this.userId} 的上下文配置：${JSON.stringify(userContextConfig)}`,
        metadata: {
          record_type: 'user_summary',
          user_id: this.userId,
          created_at: Date.now(),
          updated_at: Date.now(),
          summary_type: 'user_context_config',
          user_context_config: userContextConfig
        }
      };
      await this.cloudStorage.storeUserprofilesRecord(configRecord);
      this.recordsCache.set(configRecordId, configRecord);
      return true;
    } catch (error) {
      console.error('融合用户上下文配置失败:', error);
      return false;
    }
  }

  /**
   * 自适应权重调整
   */
  async adaptiveWeightAdjustment() {
    try {
      // 这是一个简化的实现，真实场景下会更复杂
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item');

      // 基于访问频率调整权重
      for (const record of interestRecords) {
        const accessFrequency = record.metadata.access_count / Math.max(1, (Date.now() - record.metadata.first_seen) / (24 * 60 * 60 * 1000));

        // 高频访问的项目增加权重
        if (accessFrequency > 1) {
          record.metadata.current_weight = Math.min(1, record.metadata.current_weight * 1.1);
        }
        record.metadata.updated_at = Date.now();
        await this.cloudStorage.storeUserprofilesRecord(record);
      }
    } catch (error) {
      console.error('自适应权重调整失败:', error);
    }
  }

  /**
   * 生成主动推荐
   */
  async generateProactiveRecommendations() {
    try {
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item');

      // 简化的推荐算法
      const recommendations = [];

      // 基于技术栈推荐相关技术
      const techItems = interestRecords.filter(r => r.metadata.interest_category === 'technology');
      const topTech = techItems.sort((a, b) => b.metadata.current_weight - a.metadata.current_weight)[0];
      if (topTech) {
        recommendations.push({
          id: `tech_learning_${topTech.metadata.name}`,
          type: 'learning',
          title: `${topTech.metadata.name} 高级特性`,
          description: `学习更多关于 ${topTech.metadata.name} 的高级用法和最佳实践`,
          reason: `基于您对 ${topTech.metadata.name} 的高度关注`,
          confidence: 0.8,
          priority: 'medium'
        });
      }
      return recommendations.slice(0, 5);
    } catch (error) {
      console.error('生成主动推荐失败:', error);
      return [];
    }
  }

  /**
   * 融合兴趣项权重
   */
  getFusedInterestItems(items) {
    return items.map(item => {
      const explicitWeight = item.explicitImportance || 0;
      const implicitWeight = item.currentWeight || item.weight || 0;

      // 融合公式：明确重要性占40%，隐式权重占60%
      const fusedWeight = explicitWeight * 0.4 + implicitWeight * 0.6;
      return {
        ...item,
        weight: fusedWeight,
        currentWeight: fusedWeight
      };
    });
  }

  // =================== 私有辅助方法 ===================

  /**
   * 更新现有兴趣记录
   */
  async updateExistingInterestRecord(record, action) {
    const metadata = record.metadata;

    // 更新访问统计
    metadata.access_count += 1;
    metadata.last_accessed = action.timestamp;
    metadata.updated_at = action.timestamp;

    // 更新权重
    const actionWeight = this.getActionWeight(action.actionType);
    metadata.current_weight = Math.min(1, metadata.current_weight + actionWeight * 0.1);

    // 更新最近行为
    if (!metadata.recent_action_types.includes(action.actionType)) {
      metadata.recent_action_types.push(action.actionType);
      // 保持最近5种行为类型
      if (metadata.recent_action_types.length > 5) {
        metadata.recent_action_types.shift();
      }
    }

    // 更新交互模式
    metadata.interaction_patterns.view_frequency += action.actionType === 'view' ? 1 : 0;
    metadata.interaction_patterns.edit_frequency += action.actionType === 'edit' ? 1 : 0;
    metadata.interaction_patterns.share_frequency += action.actionType === 'mention' ? 1 : 0;

    // 重新生成文档描述
    record.document = this.generateInterestItemDocument(metadata);

    // 存储更新
    await this.cloudStorage.storeUserprofilesRecord(record);
    this.recordsCache.set(record.id, record);
  }

  /**
   * 创建新兴趣记录
   */
  async createNewInterestRecord(recordId, targetItem, action) {
    const actionWeight = this.getActionWeight(action.actionType);
    const newRecord = {
      id: recordId,
      document: '',
      // 将在下面生成
      metadata: {
        record_type: 'interest_item',
        user_id: this.userId,
        created_at: action.timestamp,
        updated_at: action.timestamp,
        last_accessed: action.timestamp,
        interest_category: targetItem.type,
        name: targetItem.name,
        current_weight: actionWeight,
        access_count: 1,
        first_seen: action.timestamp,
        recent_action_types: [action.actionType],
        interaction_patterns: {
          view_frequency: action.actionType === 'view' ? 1 : 0,
          edit_frequency: action.actionType === 'edit' ? 1 : 0,
          share_frequency: action.actionType === 'mention' ? 1 : 0
        },
        trend: 'stable',
        // 从targetItem.metadata复制特定字段
        ...(targetItem.metadata?.projectType && {
          project_type: targetItem.metadata.projectType
        }),
        ...(targetItem.metadata?.role && {
          person_role: targetItem.metadata.role
        }),
        ...(targetItem.metadata?.stack && {
          technology_stack: [targetItem.metadata.stack]
        }),
        ...(targetItem.metadata?.keywords && {
          topic_keywords: targetItem.metadata.keywords
        })
      }
    };

    // 生成文档描述
    newRecord.document = this.generateInterestItemDocument(newRecord.metadata);

    // 存储记录
    await this.cloudStorage.storeUserprofilesRecord(newRecord);
    this.recordsCache.set(recordId, newRecord);
  }

  /**
   * 生成兴趣项文档描述
   */
  generateInterestItemDocument(metadata) {
    const category = metadata.interest_category;
    const name = metadata.name;
    const weight = metadata.current_weight;
    let description = `${category}: ${name}`;

    // 添加类型特定信息
    if (category === 'project' && metadata.project_type) {
      description += ` (项目类型: ${metadata.project_type})`;
    } else if (category === 'person' && metadata.person_role) {
      description += ` (角色: ${metadata.person_role})`;
    } else if (category === 'technology' && metadata.technology_stack) {
      description += ` (技术栈: ${metadata.technology_stack.join(', ')})`;
    } else if (category === 'topic' && metadata.topic_keywords) {
      description += ` (关键词: ${metadata.topic_keywords.join(', ')})`;
    }
    description += ` - 权重: ${weight.toFixed(2)}, 访问次数: ${metadata.access_count}`;
    return description;
  }

  /**
   * 生成行为模式文档描述
   */
  generateBehaviorPatternDocument(data) {
    return `用户行为: ${data.actionType} 在 ${data.targetType} "${data.targetId}" 上，上下文: ${data.context}`;
  }

  /**
   * 获取行为模式类型
   */
  getPatternType(actionType) {
    // 简化的映射
    if (['view', 'edit', 'create'].includes(actionType)) return 'work_pattern';
    if (['mention', 'search'].includes(actionType)) return 'communication_style';
    return 'time_preference';
  }

  /**
   * 获取行为特定元数据
   */
  getBehaviorSpecificMetadata(data) {
    const hour = new Date(data.timestamp).getHours();
    return {
      active_hours: [hour],
      formality_level: 'semi-formal',
      response_speed: 'normal'
    };
  }

  /**
   * 排序兴趣项
   */
  sortInterestItems(records, sortBy) {
    return records.sort((a, b) => {
      switch (sortBy) {
        case 'weight':
          return b.metadata.current_weight - a.metadata.current_weight;
        case 'frequency':
          return b.metadata.access_count - a.metadata.access_count;
        case 'recent':
          return (b.metadata.last_accessed || 0) - (a.metadata.last_accessed || 0);
        default:
          return 0;
      }
    });
  }

  /**
   * 获取行为权重
   */
  getActionWeight(actionType) {
    const weights = {
      'view': 0.1,
      'edit': 0.3,
      'create': 0.5,
      'link': 0.2,
      'mention': 0.2,
      'search': 0.15,
      'favorite': 0.4
    };
    return weights[actionType] || 0.1;
  }

  /**
   * 按类别获取顶级项目
   */
  getTopItemsByCategory(records) {
    const byCategory = {};
    records.forEach(record => {
      const category = record.metadata.interest_category;
      if (!byCategory[category]) {
        byCategory[category] = [];
      }
      byCategory[category].push(record);
    });
    const result = {};
    Object.keys(byCategory).forEach(category => {
      result[category] = byCategory[category].sort((a, b) => b.metadata.current_weight - a.metadata.current_weight).slice(0, 5).map(record => ({
        name: record.metadata.name,
        weight: record.metadata.current_weight,
        accessCount: record.metadata.access_count
      }));
    });
    return result;
  }

  /**
   * 计算兴趣分布
   */
  calculateInterestDistribution(records) {
    const distribution = {};
    const total = records.length;
    records.forEach(record => {
      const category = record.metadata.interest_category;
      distribution[category] = (distribution[category] || 0) + 1;
    });

    // 转换为百分比
    Object.keys(distribution).forEach(key => {
      distribution[key] = distribution[key] / total;
    });
    return distribution;
  }

  /**
   * 分析行为模式
   */
  analyzeBehaviorPatterns(records) {
    // 简化的行为分析
    const timeData = records.filter(r => r.metadata.pattern_type === 'time_preference');
    const _now = Date.now();
    const socialRecords = records.filter(r => r.metadata.pattern_type === 'communication_style');
    return {
      activeHours: timeData.length > 0 ? timeData[0].metadata.active_hours : [],
      communicationStyle: socialRecords.length > 0 ? socialRecords[0].metadata.formality_level : 'semi-formal',
      responseSpeed: socialRecords.length > 0 ? socialRecords[0].metadata.response_speed : 'normal'
    };
  }

  /**
   * 预测兴趣
   */
  predictInterests(records) {
    // 基于现有兴趣的简单预测
    const techRecords = records.filter(r => r.metadata.interest_category === 'technology');
    const topTech = techRecords.sort((a, b) => b.metadata.current_weight - a.metadata.current_weight)[0];
    if (topTech) {
      return [{
        item: `${topTech.metadata.name} 进阶应用`,
        type: 'technology',
        confidence: 0.8,
        reason: `基于您对 ${topTech.metadata.name} 的高度关注`
      }];
    }
    return [];
  }

  /**
   * 生成内容建议
   */
  generateContentSuggestions(records) {
    const suggestions = [];
    const topRecords = records.sort((a, b) => b.metadata.current_weight - a.metadata.current_weight).slice(0, 3);
    topRecords.forEach(record => {
      suggestions.push(`关于 ${record.metadata.name} 的深度内容`);
    });
    return suggestions;
  }

  /**
   * 计算分析置信度
   */
  calculateAnalysisConfidence(records) {
    if (records.length === 0) return 0;
    const totalInteractions = records.reduce((sum, r) => sum + r.metadata.access_count, 0);
    const avgWeight = records.reduce((sum, r) => sum + r.metadata.current_weight, 0) / records.length;

    // 简单的置信度计算
    return Math.min(1, totalInteractions / 100 * 0.5 + avgWeight * 0.5);
  }

  /**
   * 重构兴趣项（用于向后兼容）
   */
  reconstructInterestItems(records) {
    const interests = {
      projects: [],
      people: [],
      topics: [],
      technologies: [],
      documents: [],
      jiraTickets: []
    };
    records.forEach(record => {
      const metadata = record.metadata;
      const item = {
        id: record.id,
        type: metadata.interest_category,
        name: metadata.name,
        firstSeen: metadata.first_seen,
        lastAccessed: metadata.last_accessed || metadata.updated_at,
        accessCount: metadata.access_count,
        currentWeight: metadata.current_weight,
        decayFactor: 1.0,
        userActions: [],
        // 简化处理
        explicitImportance: metadata.explicit_importance,
        metadata: {
          projectType: metadata.project_type,
          role: metadata.person_role,
          stack: metadata.technology_stack?.[0],
          keywords: metadata.topic_keywords
        }
      };
      const categoryMap = {
        'project': 'projects',
        'person': 'people',
        'topic': 'topics',
        'technology': 'technologies',
        'document': 'documents',
        'jira': 'jiraTickets'
      };
      const category = categoryMap[metadata.interest_category];
      if (category && interests[category]) {
        interests[category].push(item);
      }
    });
    return interests;
  }

  /**
   * 重构行为模式（用于向后兼容）
   */
  reconstructBehaviorPatterns(_records) {
    return {
      activeTimeZones: [],
      primaryWorkAreas: [],
      communicationStyle: {
        formality: 'semi-formal',
        detailLevel: 'medium',
        responseSpeed: 'normal',
        preferredChannels: ['email', 'chat']
      },
      toolUsageFrequency: []
    };
  }

  /**
   * 重构衍生偏好（用于向后兼容）
   */
  reconstructDerivedPreferences(summaryRecords) {
    const preferencesRecord = summaryRecords.find(r => r.metadata.summary_type === 'derived_preferences');
    if (preferencesRecord) {
      return {
        preferredProjectTypes: preferencesRecord.metadata.preferred_project_types || [],
        keyCollaborators: preferencesRecord.metadata.key_collaborators || [],
        expertiseAreas: preferencesRecord.metadata.expertise_areas || [],
        riskSensitivity: preferencesRecord.metadata.risk_sensitivity || 'medium',
        updateFrequency: preferencesRecord.metadata.update_frequency || 'weekly'
      };
    }
    return {
      preferredProjectTypes: [],
      keyCollaborators: [],
      expertiseAreas: [],
      riskSensitivity: 'medium',
      updateFrequency: 'weekly'
    };
  }

  /**
   * 计算统计信息（用于向后兼容）
   */
  calculateStatistics(interestRecords, summaryRecords) {
    const statsRecord = summaryRecords.find(r => r.metadata.summary_type === 'statistics');
    if (statsRecord) {
      return {
        totalInteractions: statsRecord.metadata.total_interactions || 0,
        averageDailyActivity: statsRecord.metadata.daily_activity_average || 0,
        mostActiveDay: statsRecord.metadata.most_active_day || '',
        topInteractionTypes: statsRecord.metadata.top_interaction_types || {}
      };
    }

    // 从兴趣记录计算基本统计
    const totalInteractions = interestRecords.reduce((sum, r) => sum + r.metadata.access_count, 0);
    return {
      totalInteractions,
      averageDailyActivity: totalInteractions / Math.max(1, interestRecords.length),
      mostActiveDay: new Date().toISOString().split('T')[0],
      topInteractionTypes: {
        view: totalInteractions
      }
    };
  }

  /**
   * 清理ID用于存储
   */
  sanitizeId(id) {
    return id.replace(/[^a-zA-Z0-9_-]/g, '_');
  }
}

/***/ }),

/***/ 8:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   extractEntitiesForQuery: () => (/* binding */ extractEntitiesForQuery)
/* harmony export */ });
/* unused harmony export extractEntitiesFromMessage */
/* harmony import */ var _llm__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1995);
// 新文件：实体识别和提取


// 使用LLM提取消息中的实体
// 该格式与MemoryEntity的relatedData结构保持一致
async function extractEntitiesFromMessage(content) {
  let metadata = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  try {
    const prompt = `
    请分析以下消息，提取所有相关的实体信息和关系：
    
    消息内容：
    ${content}
    ${metadata.sender ? `消息发送者：${metadata.sender}` : ''}
    ${metadata.team_name ? `消息所在群组：${metadata.team_name}` : ''}
    ${metadata.summary ? `根据上下文得到的总结：${metadata.summary}` : ''}

    请严格按照以下 JSON 格式提取实体信息：
    {
      "entities": {
        "people": [
          {
            "name": "",
            "role": "", // 如果不知道可以留空
            "team": "", // 如果不知道可以留空
            "expertise": [], // 如果不知道可以留空
            "lastContact": null,
            "relevanceScore": 0.8
          }
        ],
        "projects": [
          {
            "name": "",
            "description": "",
            "status": "", // 如果不知道可以留空
            "relevanceScore": 0.8
          }
        ],
        "topics": [
          {
            "name": "",
            "summary": "",
            "category": "",
            "relevanceScore": 0.8
          }
        ],
        "resources": [ // 如果找到 wiki, docs, slides 等资源对应的 URL, 提取相关资源信息
          {
            "name": "",
            "summary": "",
            "type": "",
            "url": "wiki|docs|slides|...",
            "relevanceScore": 0.8
          }
        ],
        "webpages": [ // 如果找到非以上资源的其他网页，提取相关网页信息
          {
            "title": "",
            "summary": "",
            "url": "",
            "relevanceScore": 0.8
          }
        ],
        "jiraTickets": [
          {
            "key": "",
            "summary": "",
            "status": "",
            "assignee": "",
            "priority": "",
            "relevanceScore": 0.8
          }
        ]
      },
      "metadata": {
        "sentiment": "",
        "priority": "",
        "category": [],
        "tags": []
      },
      "actions": [
        {
          "type": "",
          "description": "",
          "assignee": "",
          "deadline": null,
          "status": ""
        }
      ]
    }
    
    仅返回JSON，不要有其他内容。如果某类实体不存在，返回空数组。
    注意：relevanceScore应该在0-1之间，表示与当前消息的相关性。
    `;
    const entityData = await callLLMJsonAPI({
      prompt,
      type: 'query'
    });
    console.log('提取出的实体信息：', entityData);
    if (typeof entityData === 'object') {
      return {
        entities: {
          people: entityData.entities?.people || [],
          projects: entityData.entities?.projects || [],
          topics: entityData.entities?.topics || [],
          resources: entityData.entities?.resources || [],
          webpages: entityData.entities?.webpages || [],
          jiraTickets: entityData.entities?.jiraTickets || [],
          conversations: entityData.entities?.conversations || []
        },
        metadata: {
          sentiment: entityData.metadata?.sentiment || "neutral",
          priority: entityData.metadata?.priority || "medium",
          category: entityData.metadata?.category || [],
          tags: entityData.metadata?.tags || []
        },
        actions: entityData.actions || []
      };
    }
    return {
      entities: {
        people: [],
        projects: [],
        topics: [],
        resources: [],
        webpages: [],
        jiraTickets: [],
        conversations: []
      },
      metadata: {
        sentiment: "neutral",
        priority: "medium",
        category: [],
        tags: []
      },
      actions: []
    };
  } catch (error) {
    console.error('实体提取失败:', error);
    return {
      entities: {
        people: [],
        projects: [],
        topics: [],
        resources: [],
        webpages: [],
        jiraTickets: [],
        conversations: []
      },
      metadata: {
        sentiment: "neutral",
        priority: "medium",
        category: [],
        tags: []
      },
      actions: []
    };
  }
}
async function extractEntitiesForQuery(question) {
  try {
    const analysisPrompt = `
    分析以下问题，提取查询意图和关键实体。按JSON格式返回：
    
    问题: "${question}"
    
    {
      "query": {
        "intent": {
          "primary": "",     // search/analyze/summarize/compare
          "secondary": "",   // 具体查询类型，如project_status/person_info等
          "action_type": "" // retrieve/count/timeline/relationship
        },
        "filters": {
          "time_range": {
            "type": "recent|all|specific|range",
            "start": null,   // 时间戳
            "end": null,     // 时间戳
            "description": "" // 对时间范围的文字描述，如"今年"、"这个月"、"最近一周"等
          },
          "entities": {
            "people": [
              {
                "name": "",
                "role": "",
                "required": true  // 是否必须包含该人物
              }
            ],
            "projects": [
              {
                "name": "",
                "status": "",
                "required": true
              }
            ],
            "topics": [
              {
                "name": "",
                "category": "",
                "required": true
              }
            ],
            "location": [
              {
                "name": "",
                "type": "",
                "required": true
              }
            ]
          }
        },
        "output": {
          "format": "",     // list/timeline/summary/graph
          "fields": [],     // 需要返回的字段
          "sort": {
            "field": "",
            "order": "asc|desc"
          },
          "limit": null    // 结果数量限制
        }
      },
      "context": {
        "reference_time": null,  // 参考时间点
        "user_context": "",     // 用户查询上下文
        "priority": ""         // high/medium/low
      }
    }
    
    注意：
    1. time_range.type 必须是以下值之一：
       - "all"：表示所有时间，不指定则默认是 all
       - "recent"：仅表示最近几天，如"最近"、"近期"、"最近几天"
       - "specific"：表示具体时间点
       - "range"：表示时间范围
    2. 对于包含较长时间段的描述：
       - "这个月"、"本月"应设为range类型，而非recent
       - "今年"、"本年"应设为range类型，而非recent
       - "去年"、"上个月"等也应设为range类型
    3. 请在description字段中保留原始时间描述词，如"今年"、"这个月"等
    4. 所有时间戳必须是数字或null，不能是字符串
    5. 如果无法确定具体时间，相关时间字段设为null
    6. 时间疑问词表示查询事件发生时间，不是限制查询范围
    7. required 字段表示该实体是否为必需匹配项
    8. 重要：如果问题中没有明确的时间限定词（如"最近"、"今年"、"这个月"等），请将time_range.type设为"all"
    `;

    // 使用LLM分析问题
    const queryIntent = await (0,_llm__WEBPACK_IMPORTED_MODULE_0__/* .callLLMJsonAPI */ .sc)({
      prompt: analysisPrompt,
      type: 'query'
    });
    return queryIntent;
  } catch (error) {
    console.error('查询意图分析失败:', error);
    return {
      query: {
        intent: {
          primary: "search",
          secondary: "general",
          action_type: "retrieve"
        },
        filters: {
          time_range: {
            type: "all",
            start: null,
            end: null,
            description: ""
          },
          entities: {
            people: [],
            projects: [],
            topics: [],
            location: []
          }
        },
        output: {
          format: "list",
          fields: [],
          sort: {
            field: "",
            order: "desc"
          },
          limit: 10
        }
      },
      context: {
        reference_time: null,
        user_context: "",
        priority: "medium"
      }
    };
  }
}

/***/ }),

/***/ 8143:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   f: () => (/* binding */ CloudStorage)
/* harmony export */ });
/* harmony import */ var chromadb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9266);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5279);
/* harmony import */ var _embeddings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1929);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3922);
/* harmony import */ var _memory__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6939);
/**
 * 云端存储管理器
 * 专门管理 ChromaDB 操作，包括向量搜索和完整数据存储
 */







// GraphEntity 替换为 MemoryEntity，类型兼容

/**
 * 自定义空嵌入函数 - 禁用 ChromaDB v3 的默认嵌入
 * 实际嵌入计算通过离屏文档完成
 */
class NullEmbeddingFunction {
  async generate(_texts) {
    // 不实际计算嵌入向量，因为我们使用离屏文档方案
    throw new Error('嵌入计算应通过离屏文档完成，不应调用此函数');
  }
}

/**
 * 云端存储管理器
 */
class CloudStorage {
  constructor() {
    this.client = null;
    this.collections = new Map();
    this.username = '';
    this.isInitialized = false;
    // 实体相似度阈值配置
    this.entitySimilarityThreshold = 0.85;
    // 相似度阈值，超过此值认为是同一实体
    // 用户档案维护配置
    this.userprofilesMaintenanceConfig = {
      cleanup_thresholds: {
        min_weight: 0.01,
        max_age_days: 180,
        min_access_count: 1
      },
      aggregation_rules: {
        combine_threshold: 0.8,
        max_records_per_category: 100,
        enable_auto_summary: true,
        summary_frequency_days: 7,
        max_records_per_user: 1000
      },
      update_frequency: {
        full_analysis_days: 7,
        incremental_hours: 24
      },
      vector_update: {
        enable_batch_update: true,
        batch_size: 50,
        update_frequency_hours: 24
      }
    };
    this.config = {
      collections: ['messages', 'webpages', 'projects', 'documents', 'graph-entities', 'userprofiles'],
      batchSize: 100,
      timeout: 10000
    };
  }

  /**
   * 初始化云端存储
   */
  async initialize() {
    try {
      console.log('☁️ 初始化云端存储...');
      const envConfig = await (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .getEnvConfig */ .Un)();
      if (!envConfig.ENABLE_CHROMA) {
        console.log('⚠️ ChromaDB 已禁用，云端存储功能不可用');
        return false;
      }

      // 获取用户信息
      const userinfo = await this.getUserInfo();
      this.username = userinfo.username;

      // 初始化 ChromaDB 客户端
      const chromaConfig = (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .parseChromaConfig */ .Wc)(envConfig);
      this.client = new chromadb__WEBPACK_IMPORTED_MODULE_0__.ChromaClient({
        host: chromaConfig.host,
        port: chromaConfig.port,
        ssl: chromaConfig.ssl
      });

      // 初始化集合
      await this.initializeCollections();
      this.isInitialized = true;
      console.log('✅ 云端存储初始化完成');
      return true;
    } catch (error) {
      console.error('❌ 云端存储初始化失败:', error);
      return false;
    }
  }

  /**
   * 检查连接状态
   */
  async isConnected() {
    if (!this.client) return false;
    try {
      await this.client.heartbeat();
      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * 确保已初始化
   */
  ensureInitialized() {
    if (!this.isInitialized) {
      throw new Error('云端存储未初始化');
    }
  }

  /**
   * 增强向量搜索 - 支持多种搜索模式和返回格式
   */
  // 函数重载：根据 returnType 返回不同类型

  // 实现
  async searchByVector(query, type) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    this.ensureInitialized();
    const startTime = Date.now();
    const {
      limit = 20,
      nResults = 20,
      collections = ['entities', 'messages', 'webpages'],
      returnType = 'entities',
      sortBy = 'relevance',
      sortOrder = 'desc',
      timeRange,
      minRelevanceScore,
      where: customWhere
    } = options;
    try {
      // 生成查询向量
      const queryEmbedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(query);

      // 确定搜索的集合
      const collectionMap = {
        'entities': `${this.username}-graph-entities`,
        'messages': `${this.username}-messages`,
        'webpages': `${this.username}-webpages`,
        'userprofiles': `${this.username}-userprofiles`
      };
      const collectionsToSearch = type ? [`${this.username}-graph-entities`] : collections.map(c => collectionMap[c]).filter(Boolean);
      const allResults = [];

      // 在多个集合中搜索
      for (const collectionName of collectionsToSearch) {
        const collection = this.collections.get(collectionName);
        if (!collection) continue;
        try {
          // 构建查询参数
          const queryParams = {
            queryEmbeddings: [queryEmbedding],
            nResults,
            include: ['metadatas', 'documents', 'distances']
          };

          // 构建where条件 - 使用 $and 操作符组合多个条件
          const conditions = [];

          // 1. 添加type过滤（对entities集合有效）
          if (type && collectionName.includes('graph-entities')) {
            conditions.push({
              type: type
            });
          }

          // 2. 添加时间范围过滤（对 messages、webpages 和 userprofiles 有效）
          if (timeRange && (collectionName.includes('messages') || collectionName.includes('webpages') || collectionName.includes('userprofiles'))) {
            let timeField = 'extractedAt';
            if (collectionName.includes('messages')) {
              timeField = 'timestamp';
            } else if (collectionName.includes('userprofiles')) {
              timeField = 'updated_at';
            }
            conditions.push({
              [timeField]: {
                $gte: timeRange.start,
                $lte: timeRange.end
              }
            });
          }

          // 3. 添加自定义过滤条件
          if (customWhere && typeof customWhere === 'object') {
            Object.entries(customWhere).forEach(_ref => {
              let [key, value] = _ref;
              conditions.push({
                [key]: value
              });
            });
          }

          // 4. 应用where条件（只有当有条件时才添加）
          if (conditions.length > 0) {
            if (conditions.length === 1) {
              queryParams.where = conditions[0];
            } else {
              queryParams.where = {
                $and: conditions
              };
            }
          }
          const searchResults = await collection.query(queryParams);

          // 处理搜索结果
          if (searchResults.metadatas?.[0]) {
            for (let i = 0; i < searchResults.metadatas[0].length; i++) {
              const metadata = searchResults.metadatas[0][i];
              const distance = searchResults.distances?.[0]?.[i] !== undefined ? Number(searchResults.distances?.[0]?.[i]) : 1;
              const relevanceScore = Math.max(0, 1 - distance); // 余弦距离：1-distance转换为0-1的相关度评分

              // 过滤低相关性结果
              if (minRelevanceScore && relevanceScore < minRelevanceScore) continue;
              if (returnType === 'entities') {
                // 返回实体格式
                const entity = await this.buildEntity({
                  metadata,
                  id: searchResults.ids?.[0]?.[i],
                  document: searchResults.documents?.[0]?.[i],
                  distance: Number(distance),
                  relevanceScore,
                  collectionName
                });
                if (entity) {
                  allResults.push(entity);
                }
              } else if (returnType === 'messages' || collectionName.includes('messages')) {
                // 返回消息格式
                const processedMetadata = this.deserializeChromaMetadata(metadata || {});
                allResults.push({
                  id: searchResults.ids?.[0]?.[i] || `result_${i}`,
                  messageId: searchResults.ids?.[0]?.[i],
                  content: searchResults.documents?.[0]?.[i] || '',
                  sender: metadata?.sender || metadata?.source || 'unknown',
                  datetime: metadata?.datetime || metadata?.extractedAt || Date.now(),
                  relevanceScore,
                  distance,
                  collectionType: this.getCollectionType(collectionName),
                  metadata: processedMetadata
                });
              } else {
                // 返回原始数据格式（用于用户档案查询等）
                allResults.push({
                  id: searchResults.ids?.[0]?.[i],
                  document: searchResults.documents?.[0]?.[i] || '',
                  metadata: metadata,
                  relevanceScore,
                  distance,
                  collectionType: this.getCollectionType(collectionName)
                });
              }
            }
          }
        } catch (error) {
          console.warn(`搜索集合 ${collectionName} 失败:`, error);
        }
      }

      // 应用排序
      allResults.sort((a, b) => {
        let valueA, valueB;
        switch (sortBy) {
          case 'relevance':
            valueA = a.relevanceScore || 0;
            valueB = b.relevanceScore || 0;
            break;
          case 'time':
            valueA = a.timestamp || a.updated || a.created || 0;
            valueB = b.timestamp || b.updated || b.created || 0;
            break;
          case 'importance':
            valueA = a.importance || 0;
            valueB = b.importance || 0;
            break;
          default:
            // 默认按相关度排序
            valueA = a.relevanceScore || 0;
            valueB = b.relevanceScore || 0;
        }
        return sortOrder === 'desc' ? valueB - valueA : valueA - valueB;
      });

      // 分页
      const paginatedResults = allResults.slice(0, limit);
      console.log(`🔍 向量搜索完成: "${query}" -> ${paginatedResults.length}/${allResults.length} 条结果 (${returnType}, 排序:${sortBy})`);
      return {
        data: paginatedResults,
        total: allResults.length,
        source: 'cloud',
        cached: false,
        queryTime: Date.now() - startTime
      };
    } catch (error) {
      console.error('向量搜索失败:', error);
      return {
        data: [],
        total: 0,
        source: 'cloud',
        cached: false,
        queryTime: Date.now() - startTime
      };
    }
  }

  /**
   * 获取单个实体
   */
  async getEntity(entityId) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return null;
      const result = await collection.get({
        ids: [entityId],
        include: ['metadatas', 'documents']
      });
      if (result.ids && result.ids.length > 0 && result.metadatas) {
        const metadata = result.metadatas[0];

        // 跳过备份数据
        if (metadata.type === 'graph_backup') return null;
        const entity = await this.buildEntity({
          metadata,
          id: result.ids[0],
          document: result.documents?.[0],
          collectionName: 'graph-entities'
        });
        return entity;
      }
      return null;
    } catch (error) {
      console.error(`获取实体 ${entityId} 失败:`, error);
      return null;
    }
  }

  /**
   * 从消息集合获取单个消息
   */
  async getMessage(messageId) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-messages`);
      if (!collection) return null;
      const result = await collection.get({
        ids: [messageId],
        include: ['metadatas', 'documents']
      });
      if (result.ids && result.ids.length > 0 && result.metadatas) {
        const metadata = result.metadatas[0];
        const document = result.documents?.[0];

        // 构建消息对象
        const processedMetadata = this.deserializeChromaMetadata(metadata || {});
        return {
          id: result.ids[0],
          content: document || '',
          sender: metadata?.sender || 'unknown',
          datetime: metadata?.datetime || Date.now(),
          metadata: processedMetadata,
          // 从 metadata 中提取常用字段
          groupName: metadata?.groupName || '未知群组',
          groupUrl: metadata?.groupUrl || metadata?.team_url || '#',
          groupId: metadata?.groupId || '',
          summary: metadata?.summary || (document ? document.substring(0, 100) + '...' : ''),
          matchedRules: metadata?.matchedRules || [],
          replyAdvice: metadata?.replyAdvice || '',
          contextMessages: processedMetadata?.contextMessages || []
        };
      }
      return null;
    } catch (error) {
      console.error(`获取消息 ${messageId} 失败:`, error);
      return null;
    }
  }

  /**
   * 通过 postId 查询消息是否已存在
   * @param postId 原始消息的 postId
   * @returns 如果存在返回消息对象，否则返回 null
   */
  async getMessageByPostId(postId) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-messages`);
      if (!collection) return null;

      // 使用 where 条件查询 metadata.postId
      const result = await collection.get({
        where: {
          postId: postId
        },
        include: ['metadatas', 'documents'],
        limit: 1 // 只需要第一条匹配的记录
      });
      if (result.ids && result.ids.length > 0 && result.metadatas) {
        const metadata = result.metadatas[0];
        const document = result.documents?.[0];

        // 构建消息对象
        const processedMetadata = this.deserializeChromaMetadata(metadata || {});
        return {
          id: result.ids[0],
          content: document || '',
          sender: metadata?.sender || 'unknown',
          datetime: metadata?.datetime || Date.now(),
          metadata: processedMetadata,
          // 从 metadata 中提取常用字段
          groupName: metadata?.groupName || '未知群组',
          groupUrl: metadata?.groupUrl || metadata?.team_url || '#',
          groupId: metadata?.groupId || '',
          summary: metadata?.summary || (document ? document.substring(0, 100) + '...' : ''),
          matchedRules: metadata?.matchedRules || [],
          replyAdvice: metadata?.replyAdvice || '',
          contextMessages: processedMetadata?.contextMessages || []
        };
      }
      return null;
    } catch (error) {
      console.error(`通过 postId ${postId} 查询消息失败:`, error);
      return null;
    }
  }

  /**
   * 查询云端实体（支持按type过滤和真正的分页）
   */
  async queryEntities(type, searchTerm) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    this.ensureInitialized();
    const startTime = Date.now();
    const limit = options.limit || 30; // 默认30条
    const offset = options.offset || 0;
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) {
        return {
          data: [],
          total: 0,
          source: 'cloud',
          cached: false,
          queryTime: Date.now() - startTime
        };
      }

      // 如果有搜索词，使用向量搜索
      if (searchTerm && searchTerm.length > 2) {
        // 转换 sortBy 参数为向量搜索支持的类型
        let vectorSortBy = 'relevance';
        if (options.sortBy === 'importance') {
          vectorSortBy = 'importance';
        } else if (options.sortBy === 'created' || options.sortBy === 'updated') {
          vectorSortBy = 'time';
        }
        return await this.searchByVector(searchTerm, type, {
          limit,
          nResults: limit * 2,
          // 获取更多结果以应对过滤
          collections: ['entities'],
          returnType: 'entities',
          sortBy: vectorSortBy,
          sortOrder: options.sortOrder
        });
      }

      // 构建 where 查询条件
      const conditions = [];

      // 排除备份数据
      conditions.push({
        type: {
          $ne: 'graph_backup'
        }
      });

      // 如果指定了实体类型，添加类型过滤
      if (type) {
        conditions.push({
          type: type
        });
      }

      // 构建最终的 where 条件
      const whereCondition = conditions.length === 1 ? conditions[0] : {
        $and: conditions
      };

      // 直接使用 where 查询，真正的分页
      const result = await collection.get({
        where: whereCondition,
        include: ['metadatas', 'documents'],
        limit,
        offset
      });
      if (!result.ids || result.ids.length === 0) {
        return {
          data: [],
          total: 0,
          source: 'cloud',
          cached: false,
          queryTime: Date.now() - startTime
        };
      }

      // 构建实体列表
      const entities = [];
      for (let i = 0; i < result.ids.length; i++) {
        const metadata = result.metadatas[i];
        const entity = await this.buildEntity({
          metadata,
          id: result.ids[i],
          document: result.documents?.[i],
          collectionName: 'graph-entities'
        });
        if (entity) {
          entities.push(entity);
        }
      }

      // 应用排序
      if (options.sortBy && entities.length > 0) {
        entities.sort((a, b) => {
          const order = options.sortOrder === 'desc' ? -1 : 1;
          switch (options.sortBy) {
            case 'name':
              return order * a.name.localeCompare(b.name);
            case 'created':
              return order * (a.created - b.created);
            case 'updated':
              return order * (a.updated - b.updated);
            case 'importance':
              return order * (a.importance - b.importance);
            default:
              return 0;
          }
        });
      }

      // 🆕 从本地缓存获取总数，避免实时查询
      let total = entities.length; // 当前查询到的数量作为默认值
      try {
        const cachedStats = await chrome.storage.local.get('cache_statistics');
        if (cachedStats.cache_statistics?.entityCounts) {
          if (type) {
            total = cachedStats.cache_statistics.entityCounts[type] || 0;
          } else {
            total = Object.values(cachedStats.cache_statistics.entityCounts).reduce((sum, count) => sum + count, 0);
          }
        }
      } catch (error) {
        console.warn('获取缓存统计数据失败，使用查询结果数量:', error);
      }
      console.log(`📥 从云端分页查询了 ${entities.length} 个实体 (offset: ${offset}, limit: ${limit}, type: ${type || '全部'})`);
      return {
        data: entities,
        total: total,
        source: 'cloud',
        cached: false,
        queryTime: Date.now() - startTime
      };
    } catch (error) {
      console.error('查询云端实体失败:', error);
      return {
        data: [],
        total: 0,
        source: 'cloud',
        cached: false,
        queryTime: Date.now() - startTime
      };
    }
  }

  /**
   * 🆕 批量获取实体（根据ID列表）
   * 用于实体扩展时批量加载关联实体
   */
  async getEntitiesByIds(ids) {
    this.ensureInitialized();
    if (!ids || ids.length === 0) {
      return [];
    }
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) {
        console.warn('graph-entities collection 未找到');
        return [];
      }

      // 使用 where 条件批量查询
      const result = await collection.get({
        ids: ids,
        include: ['metadatas', 'documents']
      });
      if (!result.ids || result.ids.length === 0) {
        return [];
      }

      // 构建实体列表
      const entities = [];
      for (let i = 0; i < result.ids.length; i++) {
        const metadata = result.metadatas[i];
        const entity = await this.buildEntity({
          metadata,
          id: result.ids[i],
          document: result.documents?.[i],
          collectionName: 'graph-entities'
        });
        if (entity) {
          entities.push(entity);
        }
      }
      console.log(`📥 批量获取了 ${entities.length}/${ids.length} 个实体`);
      return entities;
    } catch (error) {
      console.error('批量获取实体失败:', error);
      return [];
    }
  }

  /**
   * 查询用户档案记录（非向量搜索）
   * 用于根据元数据条件查询用户档案，不进行向量相似度计算
   */
  async queryUserprofiles() {
    let options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    this.ensureInitialized();
    const startTime = Date.now();
    const {
      record_types,
      user_id,
      limit = 20,
      time_range,
      metadata_filters = {},
      sort_by = 'time',
      sort_order = 'desc'
    } = options;
    try {
      const collectionName = `${this.username}-userprofiles`;
      const collection = this.collections.get(collectionName);
      if (!collection) {
        return {
          records: [],
          total_count: 0,
          query_metadata: {
            query_time: Date.now(),
            processing_time_ms: Date.now() - startTime
          }
        };
      }

      // 构建查询条件 - 使用 $and 操作符组合多个条件
      const conditions = [];

      // 添加 metadata_filters 中的条件
      Object.entries(metadata_filters).forEach(_ref2 => {
        let [key, value] = _ref2;
        conditions.push({
          [key]: value
        });
      });
      if (user_id) {
        conditions.push({
          user_id: user_id
        });
      }
      if (record_types && record_types.length > 0) {
        conditions.push({
          record_type: {
            $in: record_types
          }
        });
      }
      if (time_range) {
        conditions.push({
          updated_at: {
            $gte: time_range.start,
            $lte: time_range.end
          }
        });
      }

      // 构建最终的 where 条件
      let whereCondition = undefined;
      if (conditions.length > 0) {
        if (conditions.length === 1) {
          whereCondition = conditions[0];
        } else {
          whereCondition = {
            $and: conditions
          };
        }
      }

      // 执行查询（不使用向量搜索）
      const searchResult = await collection.get({
        where: whereCondition,
        limit: limit,
        include: ['documents', 'metadatas']
      });

      // 处理结果
      const records = [];
      if (searchResult.documents && searchResult.metadatas) {
        for (let i = 0; i < searchResult.documents.length; i++) {
          records.push({
            id: searchResult.ids[i],
            document: searchResult.documents[i],
            metadata: this.deserializeChromaMetadata(searchResult.metadatas[i])
          });
        }
      }

      // 排序
      if (sort_by === 'time') {
        records.sort((a, b) => {
          const timeA = a.metadata?.updated_at || a.metadata?.created_at || 0;
          const timeB = b.metadata?.updated_at || b.metadata?.created_at || 0;
          return sort_order === 'desc' ? timeB - timeA : timeA - timeB;
        });
      }
      return {
        records: records,
        total_count: records.length,
        query_metadata: {
          query_time: Date.now(),
          processing_time_ms: Date.now() - startTime
        }
      };
    } catch (error) {
      console.error('查询用户档案记录失败:', error);
      return {
        records: [],
        total_count: 0,
        query_metadata: {
          query_time: Date.now(),
          processing_time_ms: Date.now() - startTime
        }
      };
    }
  }

  /**
   * 查找相似实体
   */
  async getSimilarEntities(entity) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    this.ensureInitialized();
    const {
      limit = 1,
      minRelevanceScore = this.entitySimilarityThreshold
    } = options;
    try {
      // 为查询生成与存储时相同的自然语言描述
      const queryDocument = await this.generateSimpleDocument(entity);

      // 使用丰富的描述文本进行向量检索查找相似实体，确保type匹配
      const similarResults = await this.searchByVector(queryDocument, entity.type, {
        limit,
        minRelevanceScore,
        collections: ['entities'],
        returnType: 'entities'
      });
      if (similarResults.data.length > 0) {
        console.log(`🔍 找到 ${similarResults.data.length} 个相似实体 (阈值: ${minRelevanceScore}):`, similarResults.data.map(e => `${e.name}(${e.relevanceScore?.toFixed(3)})`).join(', '));
        return similarResults.data;
      } else {
        console.log(`📝 未找到相似实体: ${entity.name} (${entity.type}) - 阈值: ${minRelevanceScore}`);
        return [];
      }
    } catch (error) {
      console.error(`⚠️ 检查实体相似性时出错: ${entity.name}`, error);
      return [];
    }
  }

  /**
   * 查找相似消息（支持复杂过滤条件，替代 vectorStore.naturalLanguageQuery）
   */
  async getSimilarMessages(query) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    this.ensureInitialized();
    const {
      limit = 10,
      minRelevanceScore = 0.3,
      timeRange,
      sortBy = 'relevance',
      sortOrder = 'desc',
      filters
    } = options;
    try {
      // 构建 where 条件（如果有 filters）
      let whereCondition = undefined;
      if (filters) {
        const conditions = [];

        // 基础过滤
        if (filters.source) {
          conditions.push({
            source: filters.source
          });
        }
        if (filters.teamName) {
          conditions.push({
            teamName: filters.teamName
          });
        }

        // 实体过滤
        if (filters.entities) {
          if (filters.entities.people?.length) {
            const peopleNames = filters.entities.people.map(p => p.name);
            // 检查 source 字段（发送者）或 people 字段
            conditions.push({
              $or: [{
                source: {
                  $in: peopleNames
                }
              }, ...peopleNames.map(name => ({
                people: {
                  $contains: name
                }
              }))]
            });
          }
          if (filters.entities.projects?.length) {
            const projectNames = filters.entities.projects.map(p => p.name);
            conditions.push({
              $or: projectNames.map(name => ({
                projects: {
                  $contains: name
                }
              }))
            });
          }
          if (filters.entities.topics?.length) {
            const topicNames = filters.entities.topics.map(t => t.name);
            conditions.push({
              $or: topicNames.map(name => ({
                topics: {
                  $contains: name
                }
              }))
            });
          }
        }

        // 元数据过滤
        if (filters.metadata) {
          if (filters.metadata.sentiment) {
            conditions.push({
              sentiment: filters.metadata.sentiment
            });
          }
          if (filters.metadata.priority) {
            conditions.push({
              priority: filters.metadata.priority
            });
          }
          if (filters.metadata.category?.length) {
            conditions.push({
              $or: filters.metadata.category.map(cat => ({
                category: {
                  $contains: cat
                }
              }))
            });
          }
          if (filters.metadata.tags?.length) {
            conditions.push({
              $or: filters.metadata.tags.map(tag => ({
                searchTags: {
                  $contains: tag
                }
              }))
            });
          }
        }

        // 合并所有条件
        if (conditions.length > 0) {
          whereCondition = conditions.length === 1 ? conditions[0] : {
            $and: conditions
          };
        }
      }

      // 使用向量搜索获取相关消息
      const searchResults = await this.searchByVector(query, undefined, {
        collections: ['messages'],
        returnType: 'messages',
        limit,
        minRelevanceScore,
        timeRange,
        sortBy,
        sortOrder,
        where: whereCondition
      });
      if (searchResults.data.length > 0) {
        console.log(`💬 找到 ${searchResults.data.length} 个相似消息 (阈值: ${minRelevanceScore}):`, searchResults.data.map(m => `${m.source}(${m.relevanceScore?.toFixed(3)})`).join(', '));

        // 转换为前端需要的格式，包含完整的contextMessages
        const formattedMessages = searchResults.data.map(msg => {
          // 处理上下文消息：从metadata中提取contextMessages
          let contextMessages = [];
          if (msg.metadata?.contextMessages && Array.isArray(msg.metadata.contextMessages)) {
            contextMessages = msg.metadata.contextMessages.map(ctx => ({
              id: ctx.id,
              sender: ctx.sender,
              content: ctx.content,
              datetime: ctx.datetime,
              isMainMessage: ctx.isMainMessage || false
            }));
          }

          // 安全地处理时间戳，避免 Invalid Date 错误
          let datetime;
          try {
            const date = new Date(msg.timestamp);
            if (isNaN(date.getTime())) {
              // 如果时间戳无效，使用当前时间或metadata中的时间
              console.warn(`⚠️ 消息 ${msg.messageId} 的时间戳无效: ${msg.timestamp}`);
              datetime = msg.metadata?.datetime || new Date().toISOString();
            } else {
              datetime = date.toISOString();
            }
          } catch (e) {
            console.warn(`⚠️ 消息 ${msg.messageId} 的时间戳转换失败:`, e);
            datetime = msg.metadata?.datetime || new Date().toISOString();
          }
          return {
            id: msg.messageId,
            sender: msg.source,
            groupName: msg.metadata?.groupName || '未知群组',
            groupUrl: msg.metadata?.groupUrl || msg.metadata?.team_url || '#',
            datetime,
            summary: msg.metadata?.summary || msg.content.substring(0, 100) + '...',
            content: msg.content,
            highlightText: msg.metadata?.highlightText || msg.content,
            matchedRules: msg.metadata?.matchedRules || [],
            relevanceScore: msg.relevanceScore,
            contextMessages: contextMessages
          };
        });
        return formattedMessages;
      } else {
        console.log(`📭 未找到相似消息: "${query}" - 阈值: ${minRelevanceScore}`);
        return [];
      }
    } catch (error) {
      console.error(`⚠️ 检查消息相似性时出错: "${query}"`, error);
      return [];
    }
  }

  /**
   * 获取所有已知人员（从 graph-entities 查询 Person 类型）
   * 替代 vectorStore.getAllKnownPeople()
   */
  async getAllKnownPeople() {
    this.ensureInitialized();
    try {
      const result = await this.queryEntities('Person', undefined, {
        limit: 1000,
        // 获取所有人员
        sortBy: 'name',
        sortOrder: 'asc'
      });
      const peopleNames = result.data.map(entity => entity.name);
      console.log(`📋 获取到 ${peopleNames.length} 个已知人员`);
      return peopleNames;
    } catch (error) {
      console.error('获取已知人员失败:', error);
      return [];
    }
  }

  /**
   * 获取所有已知项目（从 graph-entities 查询 Project 类型）
   * 替代 vectorStore.getAllKnownProjects()
   */
  async getAllKnownProjects() {
    this.ensureInitialized();
    try {
      const result = await this.queryEntities('Project', undefined, {
        limit: 1000,
        // 获取所有项目
        sortBy: 'name',
        sortOrder: 'asc'
      });
      const projectNames = result.data.map(entity => entity.name);
      console.log(`📋 获取到 ${projectNames.length} 个已知项目`);
      return projectNames;
    } catch (error) {
      console.error('获取已知项目失败:', error);
      return [];
    }
  }

  /**
   * 获取所有已知话题（从 graph-entities 查询 Topic 类型）
   * 替代 vectorStore.getAllKnownTopics()
   */
  async getAllKnownTopics() {
    this.ensureInitialized();
    try {
      const result = await this.queryEntities('Topic', undefined, {
        limit: 1000,
        // 获取所有话题
        sortBy: 'name',
        sortOrder: 'asc'
      });
      const topicNames = result.data.map(entity => entity.name);
      console.log(`📋 获取到 ${topicNames.length} 个已知话题`);
      return topicNames;
    } catch (error) {
      console.error('获取已知话题失败:', error);
      return [];
    }
  }

  /**
   * 获取集合类型
   */
  getCollectionType(collectionName) {
    if (collectionName.includes('messages')) return 'message';
    if (collectionName.includes('webpages')) return 'webpage';
    if (collectionName.includes('entities')) return 'entity';
    return 'unknown';
  }

  /**
   * 存储实体到云端 - 新的关联数据存储
   */
  async storeEntity(entity) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return '';

      // 生成实体ID
      if (!entity.id) entity.id = this.generateEntityId(entity.type, entity.name);

      // 🆕 方案E: 用精简文本生成embedding（仅name+tags）
      const simpleDocument = this.generateSimpleDocument(entity);
      const embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(simpleDocument);

      // 🆕 生成完整的自然语言描述，存入metadata.description
      const naturalDescription = await this.generateNaturalLanguageDescription(entity);

      // 转换关联数据为ChromaDB兼容格式，并添加description
      const chromaMetadata = this.serializeChromaMetadata({
        ...entity,
        description: naturalDescription // 完整描述存储在metadata中
      });
      await collection.add({
        ids: [entity.id],
        documents: [simpleDocument],
        // 精简文本用于向量搜索
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      console.log(`✅ 实体存储完成: ${entity.name} (${entity.type}), document长度: ${simpleDocument.length}字符, description长度: ${naturalDescription.length}字符`);
      return entity.id;
    } catch (error) {
      console.error('存储实体到云端失败:', error);
      return '';
    }
  }

  /**
   * 存储消息到云端
   */
  async storeMessage(messageData) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-messages`);
      if (!collection) return false;
      const embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(`sender: ${messageData.metadata.sender}\ncontent: ${messageData.content}\nsummary: ${messageData.metadata.summary}`);

      // 转换复杂元数据为 ChromaDB 兼容格式
      const chromaMetadata = this.serializeChromaMetadata(messageData.metadata);
      await collection.add({
        ids: [messageData.id],
        documents: [messageData.content],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      return true;
    } catch (error) {
      console.error('存储消息到云端失败:', error);
      return false;
    }
  }

  /**
   * 存储网页到云端
   */
  async storeWebpage(webpageData) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-webpages`);
      if (!collection) return false;
      const content = `${webpageData.title} ${webpageData.content}`;
      const embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(content);
      const chromaMetadata = this.serializeChromaMetadata({
        ...webpageData.metadata,
        title: webpageData.title,
        url: webpageData.url
      });
      await collection.add({
        ids: [webpageData.id],
        documents: [content],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      return true;
    } catch (error) {
      console.error('存储网页到云端失败:', error);
      return false;
    }
  }

  /**
   * 🆕 智能更新实体 - 支持关联数据和智能documents更新
   */
  async updateEntity(entityId, updates) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return false;

      // 获取现有实体
      const existing = await collection.get({
        ids: [entityId],
        include: ['metadatas', 'documents']
      });
      if (!existing.metadatas?.[0]) return false;

      // 反序列化现有实体数据
      const currentMetadata = existing.metadatas[0];
      const currentEntity = this.deserializeEntityFromMetadata(currentMetadata);

      // 🆕 智能合并更新：特别处理relatedData
      const mergedEntity = {
        ...currentEntity,
        ...updates,
        updated: Date.now(),
        // 🆕 智能合并关联数据
        relatedData: this.mergeRelatedData(currentEntity.relatedData, updates.relatedData),
        // 🆕 重新计算统计信息
        statistic: this.recalculateStatistics(currentEntity, updates)
      };

      // 🆕 判断是否需要立即更新documents和embedding
      // 特别处理：name改变时必须更新embedding
      const nameChanged = updates.name && updates.name !== currentEntity.name;
      const shouldUpdateDocuments = nameChanged || this.shouldUpdateDocuments(mergedEntity, updates);
      let documents = existing.documents?.[0] || '';
      let embedding = [];
      let naturalDescription = '';
      if (shouldUpdateDocuments) {
        console.log(`📝 重要实体${mergedEntity.name}立即更新documents和embedding...`);
        // 🆕 方案E: 用精简文本生成embedding
        documents = this.generateSimpleDocument(mergedEntity);
        embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(documents);
        // 🆕 生成完整描述
        naturalDescription = await this.generateNaturalLanguageDescription(mergedEntity);
        mergedEntity.lastDocumentUpdate = Date.now();
      } else {
        console.log(`⏳ 普通实体${mergedEntity.name}延迟更新documents`);
        // 保持原有embedding，不重新计算
        const existingResult = await collection.get({
          ids: [entityId],
          include: ['embeddings']
        });
        embedding = existingResult.embeddings?.[0] || [];
        // 保持原有description
        naturalDescription = currentEntity.description || '';
      }

      // 转换为ChromaDB格式，包含description
      const chromaMetadata = this.serializeChromaMetadata({
        ...mergedEntity,
        description: naturalDescription // 完整描述存储在metadata中
      });

      // 执行更新
      await collection.update({
        ids: [entityId],
        documents: [documents],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      console.log(`✅ 实体更新完成: ${mergedEntity.name}, documents更新: ${shouldUpdateDocuments ? '是' : '否'}`);
      return true;
    } catch (error) {
      console.error('更新实体失败:', error);
      return false;
    }
  }

  /**
   * 删除实体
   */
  async deleteEntity(entityId) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return false;
      await collection.delete({
        ids: [entityId]
      });
      return true;
    } catch (error) {
      console.error('删除实体失败:', error);
      return false;
    }
  }

  /**
   * 🆕 判断是否应该立即更新documents
   */
  shouldUpdateDocuments(entity, updates) {
    // 1. 高重要性实体 (importance > 0.7)
    if (entity.importance && entity.importance > 0.7) return true;

    // 2. 高热度实体 (hotness > 0.6)  
    if (entity.hotness && entity.hotness > 0.6) return true;

    // 3. 关键性评分高的实体 (criticalityScore > 0.8)
    if (entity.criticalityScore && entity.criticalityScore > 0.8) return true;

    // 4. 长时间未更新documents的实体 (超过24小时)
    const daysSinceLastUpdate = entity.lastDocumentUpdate ? (Date.now() - entity.lastDocumentUpdate) / (1000 * 60 * 60 * 24) : 999;
    if (daysSinceLastUpdate > 1) return true;

    // 5. 如果关联数据有重大变化（新增5条以上记录）
    const hasSignificantDataChanges = updates.relatedData && (updates.relatedData.conversations && updates.relatedData.conversations.length > 5 || updates.relatedData.projects && updates.relatedData.projects.length > 2 || updates.relatedData.jiraTickets && updates.relatedData.jiraTickets.length > 3);
    if (hasSignificantDataChanges) return true;
    return false;
  }

  /**
   * 🆕 智能合并关联数据
   */
  mergeRelatedData() {
    let current = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    let updates = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    const merged = {
      ...current
    };

    // 合并各类关联数据，保持最多50条记录
    const dataTypes = ['conversations', 'webpages', 'resources', 'projects', 'people', 'topics', 'jiraTickets', 'cooccurringEntities'];
    for (const type of dataTypes) {
      if (updates[type]) {
        // 合并并去重（基于id）
        const currentItems = merged[type] || [];
        const newItems = updates[type] || [];
        const allItems = [...currentItems];
        newItems.forEach(newItem => {
          const existingIndex = allItems.findIndex(item => item.id === newItem.id);
          if (existingIndex >= 0) {
            // 更新现有项目，但保护特定字段不被覆盖
            const existingItem = allItems[existingIndex];

            // 🆕 对于conversations类型，保护已读状态
            if (type === 'conversations') {
              allItems[existingIndex] = {
                ...existingItem,
                ...newItem,
                // 保护已读状态：如果已存在的是已读，则保持已读
                isRead: existingItem.isRead !== undefined ? existingItem.isRead : newItem.isRead || false,
                readTimestamp: existingItem.readTimestamp !== undefined ? existingItem.readTimestamp : newItem.readTimestamp
              };
            } else {
              allItems[existingIndex] = {
                ...existingItem,
                ...newItem
              };
            }
          } else {
            // 添加新项目
            // 🆕 对于conversations类型，确保新消息有isRead字段
            if (type === 'conversations') {
              allItems.push({
                ...newItem,
                isRead: newItem.isRead !== undefined ? newItem.isRead : false,
                readTimestamp: newItem.readTimestamp
              });
            } else {
              allItems.push(newItem);
            }
          }
        });

        // 按相关性和时间排序，保留最多50条
        allItems.sort((a, b) => {
          // 优先按相关性排序，然后按时间
          const scoreA = (a.relevanceScore || 0) * 100 + new Date(a.datetime || a.visitTime || Date.now()).getTime() / 1000000;
          const scoreB = (b.relevanceScore || 0) * 100 + new Date(b.datetime || b.visitTime || Date.now()).getTime() / 1000000;
          return scoreB - scoreA;
        });
        merged[type] = allItems.slice(0, 50);
      }
    }
    return merged;
  }

  /**
   * 🆕 重新计算统计信息
   */
  recalculateStatistics(current, updates) {
    const relatedData = updates.relatedData || current.relatedData || {
      conversations: [],
      webpages: [],
      resources: [],
      projects: [],
      people: [],
      topics: [],
      jiraTickets: [],
      cooccurringEntities: []
    };
    return {
      conversations: relatedData.conversations?.length || 0,
      projects: relatedData.projects?.length || 0,
      participants: relatedData.people?.length || 0,
      resources: relatedData.resources?.length || 0,
      documents: relatedData.resources?.filter(r => r.type === 'document')?.length || 0,
      webpages: relatedData.webpages?.length || 0,
      topics: relatedData.topics?.length || 0,
      jiraTickets: relatedData.jiraTickets?.length || 0,
      relationships: relatedData.cooccurringEntities?.length || 0
    };
  }

  /**
   * 获取时间轴数据
   */
  async getTimeline() {
    let limit = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 50;
    this.ensureInitialized();
    try {
      const results = [];

      // 从消息集合获取最近数据
      const messageCollection = this.collections.get(`${this.username}-messages`);
      if (messageCollection) {
        const messageResults = await messageCollection.get({
          limit: limit / 2,
          include: ['metadatas', 'documents']
        });
        if (messageResults.metadatas && messageResults.documents) {
          for (let i = 0; i < messageResults.metadatas.length; i++) {
            const metadata = messageResults.metadatas[i];
            const document = messageResults.documents[i];
            results.push({
              id: `msg_${i}`,
              type: 'message',
              title: metadata.summary || '消息记录',
              content: document.substring(0, 200) + '...',
              timestamp: metadata.timestamp || Date.now(),
              sender: metadata.sender || metadata.source || 'unknown',
              metadata
            });
          }
        }
      }

      // 从网页集合获取最近数据
      const webpageCollection = this.collections.get(`${this.username}-webpages`);
      if (webpageCollection) {
        const webpageResults = await webpageCollection.get({
          limit: limit / 2,
          include: ['metadatas', 'documents']
        });
        if (webpageResults.metadatas && webpageResults.documents) {
          for (let i = 0; i < webpageResults.metadatas.length; i++) {
            const metadata = webpageResults.metadatas[i];
            const document = webpageResults.documents[i];
            results.push({
              id: `web_${i}`,
              type: 'webpage',
              title: metadata.title || '网页访问',
              content: document.substring(0, 200) + '...',
              timestamp: metadata.extractedAt || Date.now(),
              source: metadata.domain || 'unknown',
              metadata
            });
          }
        }
      }

      // 按时间排序
      return results.sort((a, b) => b.timestamp - a.timestamp).slice(0, limit);
    } catch (error) {
      console.error('获取时间轴数据失败:', error);
      return [];
    }
  }

  /**
   * 反序列化 metadata 中的对象字段
   */
  deserializeMetadata(metadata) {
    const processed = {
      ...metadata
    };
    try {
      // 反序列化 contextMessages 字段
      if (processed.contextMessages && typeof processed.contextMessages === 'string') {
        processed.contextMessages = JSON.parse(processed.contextMessages);
      }
    } catch (error) {
      // 忽略解析错误
    }
    try {
      // 反序列化 matchedRules 字段
      if (processed.matchedRules && typeof processed.matchedRules === 'string') {
        processed.matchedRules = JSON.parse(processed.matchedRules);
      }
    } catch (error) {
      // 忽略解析错误
    }
    try {
      // 反序列化 entities 字段
      if (processed.entities && typeof processed.entities === 'string') {
        processed.entities = JSON.parse(processed.entities);
      }
    } catch (error) {
      // 忽略解析错误
    }
    try {
      // 反序列化 relationships 字段
      if (processed.relationships && typeof processed.relationships === 'string') {
        processed.relationships = JSON.parse(processed.relationships);
      }
    } catch (error) {
      // 忽略解析错误
    }
    try {
      // 反序列化 metadata 嵌套字段
      if (processed.metadata && typeof processed.metadata === 'string') {
        processed.metadata = JSON.parse(processed.metadata);
      }
    } catch (error) {
      // 忽略解析错误
    }
    try {
      // 反序列化 actions 字段
      if (processed.actions && typeof processed.actions === 'string') {
        processed.actions = JSON.parse(processed.actions);
      }
    } catch (error) {
      // 忽略解析错误
    }
    return processed;
  }

  /**
   * 获取云端实体数量
   */
  async getEntityCount() {
    if (!this.client) return 0;
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return 0;
      const result = await collection.get({
        limit: 1
      });
      return result.ids?.length || 0;
    } catch (error) {
      console.error('获取实体数量失败:', error);
      return 0;
    }
  }

  /**
   * 备份关系数据到云端
   */
  async backupRelationships(relationshipData) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return false;
      const backupId = `graph-backup-${Date.now()}`;
      const backupContent = JSON.stringify({
        ...relationshipData,
        backupTime: Date.now()
      });
      const embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(backupContent);
      const chromaMetadata = this.serializeChromaMetadata({
        type: 'graph_backup',
        backupTime: Date.now(),
        relationshipCount: relationshipData.relationships.length
      });
      await collection.add({
        ids: [backupId],
        documents: [backupContent],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      console.log(`☁️ 关系数据已备份: ${backupId}`);
      return true;
    } catch (error) {
      console.error('备份关系数据失败:', error);
      return false;
    }
  }

  /**
   * 从云端恢复关系数据
   */
  async restoreRelationships() {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return null;

      // 查找最新备份
      const result = await collection.get({
        where: {
          type: 'graph_backup'
        },
        include: ['metadatas', 'documents']
      });
      if (!result.ids || result.ids.length === 0) {
        console.log('📭 云端没有找到关系数据备份');
        return null;
      }

      // 获取最新备份
      const latestBackupIndex = result.metadatas.map((meta, index) => ({
        meta,
        index
      })).sort((a, b) => (b.meta.backupTime || 0) - (a.meta.backupTime || 0))[0].index;
      const backupContent = result.documents[latestBackupIndex];
      const backupData = JSON.parse(backupContent);
      console.log(`📥 恢复关系数据: ${backupData.relationships?.length || 0} 个关系`);
      return {
        relationships: backupData.relationships || [],
        entityToRelations: backupData.entityToRelations || [],
        typeToEntities: backupData.typeToEntities || []
      };
    } catch (error) {
      console.error('恢复关系数据失败:', error);
      return null;
    }
  }

  /**
   * 批量操作
   */
  async batchStore(items) {
    this.ensureInitialized();
    let success = 0;
    let failed = 0;
    const batches = this.chunkArray(items, this.config.batchSize);
    for (const batch of batches) {
      try {
        await Promise.all(batch.map(async item => {
          try {
            switch (item.type) {
              case 'entity':
                await this.storeEntity(item.data);
                break;
              case 'message':
                await this.storeMessage(item.data);
                break;
              case 'webpage':
                await this.storeWebpage(item.data);
                break;
            }
            success++;
          } catch (error) {
            failed++;
            console.error(`批量存储失败 (${item.type}):`, error);
          }
        }));
      } catch (error) {
        failed += batch.length;
        console.error('批量存储失败:', error);
      }
    }
    return {
      success,
      failed
    };
  }

  // ==================== 私有方法 ====================

  /**
   * 🆕 生成实体ID - 移入内部方法
   */
  generateEntityId(type, name) {
    const sanitizedType = type.replace(/[^a-zA-Z0-9]/g, '');
    const sanitizedName = this.sanitizeName(name);
    const shortUuid = (0,uuid__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A)().substring(0, 8);
    return `${sanitizedType}_${sanitizedName}_${shortUuid}`;
  }

  /**
   * 清理实体名称，处理中文和特殊字符
   */
  sanitizeName(name) {
    if (!name || name.trim() === '') {
      return 'entity';
    }

    // 简单的中文转拼音映射（部分常用字符）
    const chineseToPinyin = {
      '项目': 'xiangmu',
      '文档': 'wendang',
      '人员': 'renyuan',
      '主题': 'zhuti',
      '任务': 'renwu',
      '团队': 'tuandui',
      '公司': 'gongsi',
      '系统': 'xitong',
      '数据': 'shuju',
      '功能': 'gongneng',
      '需求': 'xuqiu',
      '设计': 'sheji',
      '开发': 'kaifa',
      '测试': 'ceshi',
      '部署': 'bushu',
      '维护': 'weihu',
      '管理': 'guanli',
      '分析': 'fenxi',
      '报告': 'baogao',
      '会议': 'huiyi',
      '刘': 'liu',
      '陈': 'chen',
      '王': 'wang',
      '李': 'li',
      '张': 'zhang',
      '赵': 'zhao',
      '孙': 'sun',
      '周': 'zhou',
      '吴': 'wu',
      '郑': 'zheng'
    };
    let cleanName = name.trim();

    // 替换中文词汇为拼音
    for (const [chinese, pinyin] of Object.entries(chineseToPinyin)) {
      cleanName = cleanName.replace(new RegExp(chinese, 'g'), pinyin);
    }

    // 移除其他中文字符（通过Unicode范围）
    cleanName = cleanName.replace(/[\u4e00-\u9fff]/g, '');

    // 只保留字母、数字和连字符
    cleanName = cleanName.replace(/[^a-zA-Z0-9\-_]/g, '');

    // 移除多余的连字符和下划线
    cleanName = cleanName.replace(/[-_]+/g, '_');

    // 移除开头和结尾的连字符和下划线
    cleanName = cleanName.replace(/^[-_]+|[-_]+$/g, '');

    // 限制长度并确保不为空
    if (cleanName.length === 0) {
      cleanName = 'entity';
    } else if (cleanName.length > 15) {
      cleanName = cleanName.substring(0, 15);
    }

    // 确保以字母开头
    if (!/^[a-zA-Z]/.test(cleanName)) {
      cleanName = 'entity_' + cleanName;
    }
    return cleanName.toLowerCase();
  }
  async initializeCollections() {
    if (!this.client) throw new Error('ChromaDB 客户端未初始化');

    // ChromaDB v3: 显式指定嵌入函数，防止默认加载 @chroma-core/default-embed
    const nullEmbeddingFunction = new NullEmbeddingFunction();
    for (const collectionType of this.config.collections) {
      const collectionName = `${this.username}-${collectionType}`;
      try {
        const collection = await this.client.getOrCreateCollection({
          name: collectionName,
          embeddingFunction: nullEmbeddingFunction,
          metadata: {
            "hnsw:space": "cosine"
          } // 明确指定使用余弦距离
        });
        this.collections.set(collectionName, collection);
        // console.log(`✅ 集合已初始化: ${collectionName}`);
      } catch (error) {
        console.error(`❌ 初始化集合失败: ${collectionName}`, error);
      }
    }
  }
  async getUserInfo() {
    try {
      const result = await chrome.storage.local.get(['userinfo']);
      return result.userinfo || {
        username: 'default-user'
      };
    } catch (error) {
      console.warn('获取用户信息失败，使用默认值');
      return {
        username: 'default-user'
      };
    }
  }
  async buildEntity(entityData) {
    try {
      const {
        id,
        document,
        distance,
        relevanceScore,
        collectionName
      } = entityData;
      const metadata = this.deserializeEntityFromMetadata(entityData.metadata);
      if (collectionName.includes('graph-entities')) {
        return {
          id,
          type: metadata.type || 'Document',
          name: metadata.name || '未知实体',
          document,
          description: metadata.description || '',
          properties: typeof metadata.properties === 'string' ? JSON.parse(metadata.properties || '{}') : metadata.properties || {},
          created: metadata.created || Date.now(),
          updated: metadata.updated || Date.now(),
          accessCount: metadata.accessCount || 0,
          lastAccessed: metadata.lastAccessed || Date.now(),
          importance: metadata.importance || 0.5,
          tags: metadata.tags || [],
          status: metadata.status || 'active',
          statistic: metadata.statistic || {
            conversations: 0,
            projects: 0,
            participants: 0,
            resources: 0,
            documents: 0,
            webpages: 0,
            relationships: 0,
            topics: 0,
            jiraTickets: 0
          },
          relatedData: metadata.relatedData || {
            conversations: [],
            webpages: [],
            resources: [],
            projects: [],
            people: [],
            topics: [],
            jiraTickets: [],
            cooccurringEntities: []
          },
          // 添加搜索相关信息
          ...(distance !== undefined && {
            searchDistance: distance
          }),
          ...(relevanceScore !== undefined && {
            relevanceScore
          })
        };
      }

      // 从其他集合构建虚拟实体
      return {
        id: id || `virtual_${Date.now()}_${Math.random()}`,
        type: 'Document',
        name: metadata.name || '相关内容',
        document: document || '相关内容',
        properties: {
          ...metadata,
          ...(document && {
            originalDocument: document
          }),
          collectionSource: collectionName
        },
        created: metadata.created || Date.now(),
        updated: metadata.updated || Date.now(),
        accessCount: metadata.accessCount || 1,
        lastAccessed: metadata.lastAccessed || Date.now(),
        importance: metadata.importance || 0.3,
        tags: metadata.tags || [],
        status: metadata.status || 'active',
        statistic: metadata.statistic || {
          conversations: 0,
          projects: 0,
          participants: 0,
          resources: 0,
          documents: 0,
          webpages: 0,
          relationships: 0,
          topics: 0,
          jiraTickets: 0
        },
        relatedData: metadata.relatedData || {
          conversations: [],
          webpages: [],
          resources: [],
          projects: [],
          people: [],
          topics: [],
          jiraTickets: [],
          cooccurringEntities: []
        },
        // 添加搜索相关信息
        ...(distance !== undefined && {
          searchDistance: distance
        }),
        ...(relevanceScore !== undefined && {
          relevanceScore
        })
      };
    } catch (error) {
      console.error('构建实体失败:', error);
      return null;
    }
  }
  chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

  /**
   * 存储用户画像到云端
   */
  async storeUserProfile(userId, profile) {
    this.ensureInitialized();
    try {
      // 获取或创建用户画像集合
      const collectionName = `${this.username}-userprofiles`;
      let collection = this.collections.get(collectionName);
      if (!collection) {
        collection = await this.client.getOrCreateCollection({
          name: collectionName,
          metadata: {
            type: 'user_profiles',
            "hnsw:space": "cosine"
          },
          embeddingFunction: new NullEmbeddingFunction()
        });
        this.collections.set(collectionName, collection);
      }

      // 为用户画像创建向量表示
      const profileText = this.createProfileText(profile);
      const embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(profileText);

      // 存储用户画像
      const chromaMetadata = this.serializeChromaMetadata({
        userId: userId,
        lastUpdated: profile.lastUpdated,
        createdAt: profile.createdAt,
        totalInteractions: profile.statistics.totalInteractions,
        profileData: JSON.stringify(profile)
      });
      await collection.upsert({
        ids: [userId],
        documents: [profileText],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      console.log(`✅ 用户画像 ${userId} 已存储到云端`);
      return true;
    } catch (error) {
      console.error('存储用户画像到云端失败:', error);
      return false;
    }
  }

  /**
   * 从云端获取用户画像
   */
  async getUserProfile(userId) {
    this.ensureInitialized();
    try {
      const collectionName = `${this.username}-userprofiles`;
      const collection = this.collections.get(collectionName);
      if (!collection) {
        return null;
      }
      const result = await collection.get({
        ids: [userId],
        include: ['metadatas']
      });
      if (result.metadatas && result.metadatas.length > 0) {
        const metadata = this.deserializeChromaMetadata(result.metadatas[0]);
        if (metadata.profileData) {
          return JSON.parse(metadata.profileData);
        }
      }
      return null;
    } catch (error) {
      console.error('从云端获取用户画像失败:', error);
      return null;
    }
  }

  // =====================================
  // 🆕 用户档案存储方法
  // =====================================

  /**
   * 存储用户档案记录
   */
  async storeUserprofilesRecord(record) {
    this.ensureInitialized();
    try {
      const collectionName = `${this.username}-userprofiles`;
      let collection = this.collections.get(collectionName);
      if (!collection) {
        collection = await this.client.getOrCreateCollection({
          name: collectionName,
          metadata: {
            type: 'vectorized_user_profiles',
            "hnsw:space": "cosine"
          },
          embeddingFunction: new NullEmbeddingFunction()
        });
        this.collections.set(collectionName, collection);
      }

      // 生成嵌入向量（如果没有提供）
      let embedding = record.embedding;
      if (!embedding) {
        embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(record.document);
      }
      const metadata = this.serializeChromaMetadata(record.metadata);

      // 存储记录
      await collection.upsert({
        ids: [record.id],
        documents: [record.document],
        embeddings: [embedding],
        metadatas: [metadata]
      });

      // console.log(`✅ 用户档案记录 ${record.id} 已存储`);
      return true;
    } catch (error) {
      console.error('存储用户档案记录失败:', error);
      return false;
    }
  }

  /**
   * 批量存储用户档案记录
   */
  async storeUserprofilesRecordsBatch(records) {
    this.ensureInitialized();
    let successCount = 0;
    const batchSize = this.userprofilesMaintenanceConfig.vector_update.batch_size;
    for (let i = 0; i < records.length; i += batchSize) {
      const batch = records.slice(i, i + batchSize);
      try {
        const collectionName = `${this.username}-userprofiles`;
        let collection = this.collections.get(collectionName);
        if (!collection) {
          collection = await this.client.getOrCreateCollection({
            name: collectionName,
            metadata: {
              type: 'vectorized_user_profiles',
              "hnsw:space": "cosine"
            },
            embeddingFunction: new NullEmbeddingFunction()
          });
          this.collections.set(collectionName, collection);
        }

        // 准备批量数据
        const ids = batch.map(r => r.id);
        const documents = batch.map(r => r.document);
        const metadatas = batch.map(r => this.serializeChromaMetadata(r.metadata));

        // 生成嵌入向量
        const embeddings = await Promise.all(batch.map(r => r.embedding || (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(r.document)));

        // 批量存储
        await collection.upsert({
          ids,
          documents,
          embeddings,
          metadatas: metadatas
        });
        successCount += batch.length;
        console.log(`✅ 批量存储 ${batch.length} 条用户档案记录`);
      } catch (error) {
        console.error(`批量存储失败 (batch ${Math.floor(i / batchSize) + 1}):`, error);
      }
    }
    return successCount;
  }

  /**
   * 查找相似用户
   */
  async findSimilarUsers(currentUserId, query) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const {
      record_types,
      limit = 10,
      similarity_threshold = 0.6
    } = options;
    const queryResult = await this.searchByVector(query, undefined, {
      collections: ['userprofiles'],
      returnType: 'userprofiles',
      where: {
        record_type: {
          $in: record_types
        },
        user_id: {
          $ne: currentUserId
        }
      },
      minRelevanceScore: similarity_threshold,
      limit: 100
    });

    // 按用户聚合结果
    const userMatches = new Map();
    queryResult.data.forEach((record, _index) => {
      const userId = record.metadata.user_id;
      const similarity = record.relevanceScore || 0;
      if (!userMatches.has(userId)) {
        userMatches.set(userId, {
          similarity_scores: [],
          matching_categories: new Set(),
          matching_items: []
        });
      }
      const userMatch = userMatches.get(userId);
      userMatch.similarity_scores.push(similarity);
      userMatch.matching_categories.add(record.metadata.record_type);
      if ('name' in record.metadata) {
        userMatch.matching_items.push(record.metadata.name);
      }
    });

    // 计算综合相似度并格式化结果
    const results = [];
    for (const [userId, matches] of Array.from(userMatches.entries())) {
      const avgSimilarity = matches.similarity_scores.reduce((sum, score) => sum + score, 0) / matches.similarity_scores.length;
      results.push({
        user_id: userId,
        similarity_score: avgSimilarity,
        matching_categories: Array.from(matches.matching_categories).map(category => ({
          category: category,
          similarity: avgSimilarity,
          matching_items: matches.matching_items
        })),
        total_matches: matches.similarity_scores.length
      });
    }
    return results.sort((a, b) => b.similarity_score - a.similarity_score).slice(0, limit);
  }

  /**
   * 删除用户的档案记录
   */
  async deleteUserProfilesRecords(userId) {
    this.ensureInitialized();
    try {
      const collectionName = `${this.username}-userprofiles`;
      const collection = this.collections.get(collectionName);
      if (!collection) {
        return true; // 集合不存在，认为删除成功
      }

      // 查找用户的所有记录
      const userRecords = await collection.get({
        where: {
          user_id: userId
        },
        include: ['metadatas']
      });
      if (userRecords.ids && userRecords.ids.length > 0) {
        // 批量删除
        await collection.delete({
          ids: userRecords.ids
        });
        console.log(`🗑️ 删除用户 ${userId} 的 ${userRecords.ids.length} 条用户档案记录`);
      }
      return true;
    } catch (error) {
      console.error('删除用户档案记录失败:', error);
      return false;
    }
  }

  /**
   * 获取用户档案存储统计信息
   */
  async getUserprofilesStorageStats() {
    this.ensureInitialized();
    try {
      const collectionName = `${this.username}-userprofiles`;
      const collection = this.collections.get(collectionName);
      if (!collection) {
        return {
          total_records: 0,
          records_by_type: {},
          records_by_user: {},
          storage_size_mb: 0,
          last_maintenance: 0,
          health_score: 1.0
        };
      }

      // 获取所有记录的元数据
      const allRecords = await collection.get({
        include: ['metadatas']
      });
      const stats = {
        total_records: allRecords.ids?.length || 0,
        records_by_type: {},
        records_by_user: {},
        storage_size_mb: 0,
        last_maintenance: 0,
        health_score: 1.0
      };
      if (allRecords.metadatas) {
        allRecords.metadatas.forEach(metadata => {
          const meta = metadata;

          // 按类型统计
          const recordType = meta.record_type || 'unknown';
          stats.records_by_type[recordType] = (stats.records_by_type[recordType] || 0) + 1;

          // 按用户统计
          const userId = meta.user_id || 'unknown';
          stats.records_by_user[userId] = (stats.records_by_user[userId] || 0) + 1;
        });
      }

      // 估算存储大小（简化计算）
      stats.storage_size_mb = Math.round(stats.total_records * 0.1); // 假设每条记录约0.1MB

      // 计算健康度（基于记录分布和完整性）
      const typeCount = Object.keys(stats.records_by_type).length;
      const userCount = Object.keys(stats.records_by_user).length;
      stats.health_score = Math.min(1.0, typeCount * userCount / (stats.total_records || 1));
      return stats;
    } catch (error) {
      console.error('获取用户档案存储统计失败:', error);
      return {
        total_records: 0,
        records_by_type: {},
        records_by_user: {},
        storage_size_mb: 0,
        last_maintenance: 0,
        health_score: 0
      };
    }
  }

  /**
   * 用户档案数据维护
   */
  async performUserprofilesMaintenance() {
    this.ensureInitialized();
    const result = {
      cleaned_records: 0,
      updated_records: 0,
      created_summaries: 0,
      errors: []
    };
    try {
      const collectionName = `${this.username}-userprofiles`;
      const collection = this.collections.get(collectionName);
      if (!collection) {
        return result;
      }
      console.log('🔧 开始用户档案数据维护...');

      // 1. 清理过期/低权重记录
      try {
        const cleanupThreshold = Date.now() - this.userprofilesMaintenanceConfig.cleanup_thresholds.max_age_days * 24 * 60 * 60 * 1000;
        const oldRecords = await collection.get({
          where: {
            $or: [{
              updated_at: {
                $lt: cleanupThreshold
              }
            }, {
              current_weight: {
                $lt: this.userprofilesMaintenanceConfig.cleanup_thresholds.min_weight
              }
            }]
          },
          include: ['metadatas']
        });
        if (oldRecords.ids && oldRecords.ids.length > 0) {
          await collection.delete({
            ids: oldRecords.ids
          });
          result.cleaned_records = oldRecords.ids.length;
          console.log(`🗑️ 清理了 ${result.cleaned_records} 条过期记录`);
        }
      } catch (error) {
        result.errors.push(`清理记录失败: ${error}`);
      }

      // 2. 更新向量表示（重新计算embedding）
      if (this.userprofilesMaintenanceConfig.vector_update.enable_batch_update) {
        try {
          // 找到需要更新的记录（这里简化为随机选择部分记录）
          const allRecords = await collection.get({
            limit: this.userprofilesMaintenanceConfig.vector_update.batch_size,
            include: ['documents', 'metadatas']
          });
          if (allRecords.documents && allRecords.metadatas && allRecords.ids) {
            const updatedEmbeddings = await Promise.all(allRecords.documents[0].map(doc => (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(doc)));
            await collection.upsert({
              ids: allRecords.ids,
              documents: allRecords.documents[0],
              embeddings: updatedEmbeddings,
              metadatas: allRecords.metadatas[0]
            });
            result.updated_records = allRecords.ids.length;
            console.log(`🔄 更新了 ${result.updated_records} 条记录的向量表示`);
          }
        } catch (error) {
          result.errors.push(`更新向量失败: ${error}`);
        }
      }

      // 3. 生成用户概要记录
      if (this.userprofilesMaintenanceConfig.aggregation_rules.enable_auto_summary) {
        try {
          const userStats = await this.getUserprofilesStorageStats();
          for (const userId of Object.keys(userStats.records_by_user)) {
            // 检查是否需要创建或更新概要
            const existingSummary = await collection.get({
              where: {
                user_id: userId,
                record_type: 'user_summary'
              },
              limit: 1
            });
            if (!existingSummary.ids || existingSummary.ids.length === 0) {
              // 创建新的用户概要
              const summaryRecord = await this.generateUserSummaryRecord(userId);
              if (summaryRecord) {
                await this.storeUserprofilesRecord(summaryRecord);
                result.created_summaries++;
              }
            }
          }
          console.log(`📊 创建了 ${result.created_summaries} 个用户概要记录`);
        } catch (error) {
          result.errors.push(`生成概要失败: ${error}`);
        }
      }
      console.log('✅ 用户档案数据维护完成');
      return result;
    } catch (error) {
      console.error('用户档案数据维护失败:', error);
      result.errors.push(`维护过程失败: ${error}`);
      return result;
    }
  }

  /**
   * 生成用户概要记录
   */
  async generateUserSummaryRecord(userId) {
    try {
      // 获取用户的所有记录
      const userRecords = await this.queryUserprofiles({
        user_id: userId,
        limit: 1000,
        record_types: ['interest_item', 'behavior_pattern', 'social_relationship', 'expertise_area']
      });
      if (userRecords.records.length === 0) {
        return null;
      }

      // 统计分析
      const recordsByType = userRecords.records.reduce((acc, record) => {
        const type = record.metadata.record_type;
        acc[type] = (acc[type] || 0) + 1;
        return acc;
      }, {});

      // 计算权重分布
      const weights = userRecords.records.map(r => r.metadata.current_weight).filter(w => typeof w === 'number');
      const weightDistribution = {
        high_weight_items: weights.filter(w => w > 0.7).length,
        medium_weight_items: weights.filter(w => w >= 0.3 && w <= 0.7).length,
        low_weight_items: weights.filter(w => w < 0.3).length
      };

      // 生成概要文本
      const summaryText = `用户 ${userId} 的画像概要：
        总记录数: ${userRecords.records.length}
        记录类型分布: ${Object.entries(recordsByType).map(_ref3 => {
        let [type, count] = _ref3;
        return `${type}: ${count}`;
      }).join(', ')}
        权重分布: 高权重${weightDistribution.high_weight_items}项, 中权重${weightDistribution.medium_weight_items}项, 低权重${weightDistribution.low_weight_items}项
        活跃领域: ${Object.keys(recordsByType).join(', ')}`;
      const summaryRecord = {
        id: `${userId}_summary_${Date.now()}`,
        document: summaryText,
        metadata: {
          record_type: 'user_summary',
          summary_type: 'overall',
          user_id: userId,
          created_at: Date.now(),
          updated_at: Date.now(),
          total_records: userRecords.records.length,
          summary_period: {
            start: Math.min(...userRecords.records.map(r => r.metadata.created_at)),
            end: Date.now()
          },
          weight_distribution: weightDistribution,
          activity_metrics: {
            avg_daily_interactions: weights.length / 30,
            // 简化计算
            peak_activity_hour: 9,
            // 简化为固定值
            active_days_count: Math.min(30, weights.length)
          },
          growth_trends: {
            new_interests_per_month: 0,
            skill_development_rate: 0,
            social_network_growth: 0
          },
          auto_generated: true,
          generation_algorithm: 'v1.0'
        }
      };
      return summaryRecord;
    } catch (error) {
      console.error('生成用户概要记录失败:', error);
      return null;
    }
  }

  /**
   * 创建用户画像的文本表示（用于向量化）
   */
  createProfileText(profile) {
    const parts = [];

    // 用户ID和基本信息
    parts.push(`用户: ${profile.userId}`);

    // 兴趣项目
    if (profile.interests.projects.length > 0) {
      parts.push('关注项目: ' + profile.interests.projects.slice(0, 5).map(p => `${p.name}(权重:${p.currentWeight.toFixed(2)})`).join(', '));
    }

    // 关注人员
    if (profile.interests.people.length > 0) {
      parts.push('关注人员: ' + profile.interests.people.slice(0, 5).map(p => `${p.name}(权重:${p.currentWeight.toFixed(2)})`).join(', '));
    }

    // 技术栈
    if (profile.interests.technologies.length > 0) {
      parts.push('技术栈: ' + profile.interests.technologies.slice(0, 5).map(t => `${t.name}(权重:${t.currentWeight.toFixed(2)})`).join(', '));
    }

    // 主题
    if (profile.interests.topics.length > 0) {
      parts.push('关注主题: ' + profile.interests.topics.slice(0, 5).map(t => `${t.name}(权重:${t.currentWeight.toFixed(2)})`).join(', '));
    }

    // 专业领域
    if (profile.derivedPreferences.expertiseAreas.length > 0) {
      parts.push('专业领域: ' + profile.derivedPreferences.expertiseAreas.join(', '));
    }

    // 统计信息
    parts.push(`总交互次数: ${profile.statistics.totalInteractions}`);
    parts.push(`日均活动: ${profile.statistics.averageDailyActivity.toFixed(1)}`);
    return parts.join('\n');
  }

  /**
   * 备份关系数据到独立的关系集合
   */
  async backupRelationshipsToCollection(relationshipData) {
    this.ensureInitialized();
    try {
      if (!relationshipData.relationships || relationshipData.relationships.length === 0) {
        console.log('📭 没有关系数据需要备份');
        return true;
      }
      const relationshipCollectionName = `${this.username}-graph-relationships`;

      // 获取或创建关系集合
      let relationshipCollection;
      try {
        relationshipCollection = await this.client.getOrCreateCollection({
          name: relationshipCollectionName,
          metadata: {
            type: 'relationships',
            "hnsw:space": "cosine"
          },
          embeddingFunction: new NullEmbeddingFunction()
        });
      } catch (error) {
        console.error('❌ 无法创建关系集合:', error);
        return false;
      }
      const relationships = relationshipData.relationships || [];
      let storedCount = 0;

      // 按实体类型和时间进行分组存储，减少数据量
      const groupedRelationships = this.groupRelationshipsForStorage(relationships);
      for (const [groupKey, groupData] of Object.entries(groupedRelationships)) {
        try {
          const groupDoc = {
            id: `rel-group-${groupKey}-${Date.now()}`,
            groupKey,
            relationshipCount: groupData.relationships.length,
            timeRange: groupData.timeRange,
            entityTypes: groupData.entityTypes,
            relationshipTypes: groupData.relationshipTypes,
            createdAt: Date.now(),
            data: JSON.stringify(groupData.relationships)
          };

          // 为文档内容生成向量（用于检索）
          const searchableContent = [`关系组 ${groupKey}`, `实体类型: ${groupData.entityTypes.join(', ')}`, `关系类型: ${groupData.relationshipTypes.join(', ')}`, `时间范围: ${new Date(groupData.timeRange.start).toLocaleDateString()} - ${new Date(groupData.timeRange.end).toLocaleDateString()}`].join('\n');
          const embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(searchableContent);
          await relationshipCollection.add({
            ids: [groupDoc.id],
            documents: [searchableContent],
            embeddings: [embedding],
            metadatas: [groupDoc]
          });
          storedCount += groupData.relationships.length;
        } catch (error) {
          console.error(`❌ 存储关系组 ${groupKey} 失败:`, error);
        }
      }
      console.log(`☁️ 关系数据已备份到独立集合: ${storedCount} 个关系，${Object.keys(groupedRelationships).length} 个分组`);
      return true;
    } catch (error) {
      console.error('❌ 云端备份关系数据失败:', error);
      return false;
    }
  }

  /**
   * 按类型和时间对关系进行分组，优化存储和检索
   */
  groupRelationshipsForStorage(relationships) {
    const groups = {};
    const timeSpan = 7 * 24 * 60 * 60 * 1000; // 7天为一组

    for (const [id, relationship] of relationships) {
      if (!relationship) continue;

      // 计算时间分组
      const timestamp = relationship.created || Date.now();
      const timeGroup = Math.floor(timestamp / timeSpan);

      // 获取实体类型（从 ID 推断）
      const fromType = this.getEntityTypeFromId(relationship.fromId);
      const toType = this.getEntityTypeFromId(relationship.toId);
      const entityTypesKey = [fromType, toType].sort().join('-');

      // 生成分组键：实体类型_关系类型_时间组
      const groupKey = `${entityTypesKey}_${relationship.type}_${timeGroup}`;
      if (!groups[groupKey]) {
        groups[groupKey] = {
          relationships: [],
          timeRange: {
            start: timeGroup * timeSpan,
            end: (timeGroup + 1) * timeSpan
          },
          entityTypes: [fromType, toType],
          relationshipTypes: new Set()
        };
      }
      groups[groupKey].relationships.push([id, relationship]);
      groups[groupKey].relationshipTypes.add(relationship.type);
    }

    // 转换 Set 为 Array
    Object.values(groups).forEach(group => {
      group.relationshipTypes = Array.from(group.relationshipTypes);
    });
    return groups;
  }

  /**
   * 从实体ID推断实体类型
   */
  getEntityTypeFromId(entityId) {
    if (!entityId) return 'Unknown';
    const parts = entityId.split('_');
    return parts[0] || 'Unknown';
  }

  /**
   * 将复杂元数据转换为 ChromaDB 兼容的格式
   * ChromaDB 只支持 string, number, boolean, null 类型
   */
  serializeChromaMetadata(metadata) {
    const converted = {};
    if (!metadata) return converted;

    // 递归处理函数
    const processValue = (key, value) => {
      if (value === null || value === undefined) {
        converted[key] = '';
      } else if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
        converted[key] = value;
      } else if (Array.isArray(value)) {
        // 数组转换为JSON字符串
        converted[key] = JSON.stringify(value);
      } else if (typeof value === 'object') {
        // 对象转换为JSON字符串
        converted[key] = JSON.stringify(value);
      } else {
        // 其他类型转换为字符串
        converted[key] = String(value);
      }
    };

    // 处理顶级字段
    for (const [key, value] of Object.entries(metadata)) {
      processValue(key, value);
    }
    return converted;
  }

  /**
   * 🆕 通用的ChromaDB metadata反序列化函数
   * 可以处理任意类型的metadata，自动判断字段类型并进行相应转换
   */
  deserializeChromaMetadata(metadata, defaultValues) {
    if (!metadata) return defaultValues || {};

    // 通用字段处理：自动判断字段类型并进行相应转换
    const processField = (value, fieldName, defaultValue) => {
      // 如果值为空，返回默认值
      if (value === null || value === undefined || value === '') {
        return defaultValue;
      }

      // 如果已经是正确类型，直接返回
      if (typeof value !== 'string') {
        return value;
      }

      // 尝试解析为 JSON（数组或对象）
      if (value.startsWith('{') && value.endsWith('}') || value.startsWith('[') && value.endsWith(']')) {
        try {
          return JSON.parse(value);
        } catch (error) {
          console.warn(`字段 ${fieldName} JSON解析失败:`, error);
          return defaultValue;
        }
      }

      // 判断是否为时间戳字段，如果是数字字符串且字段名包含时间相关词汇
      const timeFields = ['created', 'updated', 'lastAccessed', 'lastContact', 'lastDocumentUpdate', 'created_at', 'updated_at', 'timestamp', 'datetime', 'extractedAt'];
      if (timeFields.includes(fieldName) && /^\d+$/.test(value)) {
        return parseInt(value, 10);
      }

      // 判断是否为数字字段
      const numberFields = ['accessCount', 'importance', 'hotness', 'criticalityScore', 'current_weight', 'relevanceScore', 'total_interactions', 'total_records'];
      if (numberFields.includes(fieldName) && /^-?\d*\.?\d+$/.test(value)) {
        return parseFloat(value);
      }

      // 布尔字段处理
      if (value === 'true') return true;
      if (value === 'false') return false;

      // 其他情况保持字符串
      return value;
    };
    try {
      // 从默认值开始或创建新对象
      const result = defaultValues ? {
        ...defaultValues
      } : {};

      // 处理metadata中的所有字段
      for (const key in metadata) {
        if (metadata[key] !== undefined) {
          result[key] = processField(metadata[key], key, result[key]);
        }
      }
      return result;
    } catch (error) {
      console.error('反序列化ChromaDB metadata失败:', error);
      return defaultValues || {};
    }
  }

  /**
   * 🆕 从ChromaDB metadata反序列化实体（使用通用反序列化函数）
   */
  deserializeEntityFromMetadata(metadata) {
    // 默认值定义
    const defaults = {
      id: '',
      type: 'Document',
      name: '',
      document: '',
      properties: {},
      created: Date.now(),
      updated: Date.now(),
      accessCount: 0,
      lastAccessed: Date.now(),
      importance: 0.5,
      tags: [],
      status: 'active',
      statistic: {
        conversations: 0,
        projects: 0,
        participants: 0,
        resources: 0,
        documents: 0,
        webpages: 0,
        relationships: 0,
        topics: 0,
        jiraTickets: 0
      },
      relatedData: {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      },
      hotness: 0,
      criticalityScore: 0,
      lastDocumentUpdate: Date.now(),
      expertise: []
    };
    return this.deserializeChromaMetadata(metadata, defaults);
  }

  /**
   * 将基础 MemoryEntity 扩展为包含完整缓存数据的实体
   */
  async extendEntityToDetailCache(entity) {
    this.ensureInitialized();
    try {
      // 获取相关项目：优先使用 entity.relatedData.projects，否则向量搜索
      let relatedProjects = [];
      if (entity.relatedData?.projects && entity.relatedData.projects.length > 0) {
        // 使用现有的相关项目数据
        relatedProjects = entity.relatedData.projects.map(project => ({
          id: project.id || `project_${Date.now()}`,
          name: project.name || project.projectName || '未知项目',
          status: project.status || '开发中',
          description: project.document || `项目: ${project.name || project.projectName || '未命名项目'}`
        }));
        console.log(`📁 使用实体现有的项目数据: ${relatedProjects.length} 个`);
      } else {
        // 向量搜索相关项目
        try {
          const projectSearchResults = await this.searchByVector(`${entity.name} 项目`, 'Project', {
            limit: 5,
            returnType: 'entities'
          });
          relatedProjects = projectSearchResults.data.map(project => ({
            id: project.id,
            name: project.name || '未知项目',
            status: project.properties?.status || project.status || '开发中',
            description: project.document || `项目: ${project.name || '未命名项目'}`
          }));
          console.log(`🔍 通过向量搜索找到相关项目: ${relatedProjects.length} 个`);
        } catch (error) {
          console.warn('搜索相关项目失败:', error);
          relatedProjects = [];
        }
      }

      // 获取相关资源：优先使用 entity.relatedData.resources，否则向量搜索
      let relatedResources = [];
      if (entity.relatedData?.resources && entity.relatedData.resources.length > 0) {
        // 使用现有的相关资源数据
        relatedResources = entity.relatedData.resources.map(resource => ({
          id: resource.id || `resource_${Date.now()}`,
          name: resource.name || resource.title || '文档资源',
          type: resource.type || '文档',
          url: resource.url || '#'
        }));
        console.log(`📄 使用实体现有的资源数据: ${relatedResources.length} 个`);
      } else {
        // 向量搜索相关文档资源
        try {
          const resourceSearchResults = await this.searchByVector(`${entity.name} 文档 资源`, 'Document', {
            limit: 5,
            returnType: 'entities'
          });
          relatedResources = resourceSearchResults.data.map(doc => ({
            id: doc.id,
            name: doc.name || '文档资源',
            type: '文档',
            url: doc.properties?.url || '#'
          }));
          console.log(`🔍 通过向量搜索找到相关资源: ${relatedResources.length} 个`);
        } catch (error) {
          console.warn('搜索相关资源失败:', error);
          relatedResources = [];
        }
      }

      // 获取相关对话：优先使用 entity.relatedData.conversations，扩展缺失信息，否则使用 getSimilarMessages 搜索
      let latestConversations = [];
      if (entity.relatedData?.conversations && entity.relatedData.conversations.length > 0) {
        // 使用现有的对话数据，并扩展缺失的详细信息
        console.log(`💬 处理实体现有的对话数据: ${entity.relatedData.conversations.length} 个`);
        for (const conv of entity.relatedData.conversations) {
          const relatedDataConv = {
            ...conv
          };

          // 如果缺少 contextMessages 或 originalContent，尝试通过 getMessage 扩展
          if (!relatedDataConv.contextMessages || relatedDataConv.contextMessages.length === 0 || !relatedDataConv.content) {
            try {
              const messageData = await this.getMessage(relatedDataConv.id);
              if (messageData) {
                // 从检索到的文档中获取 content
                if (!relatedDataConv.content && messageData.content) {
                  relatedDataConv.content = messageData.content;
                }

                // 从 metadata 中获取 contextMessages
                if (!relatedDataConv.contextMessages || relatedDataConv.contextMessages.length === 0) {
                  if (messageData.contextMessages && messageData.contextMessages.length > 0) {
                    relatedDataConv.contextMessages = messageData.contextMessages;
                  } else {
                    relatedDataConv.contextMessages = [{
                      id: messageData.id,
                      sender: messageData.sender,
                      content: messageData.content,
                      datetime: messageData.datetime,
                      isMainMessage: true
                    }];
                  }
                }

                // 补充其他缺失字段
                relatedDataConv.summary = messageData.summary;
                relatedDataConv.groupName = messageData.groupName;
                relatedDataConv.groupUrl = messageData.groupUrl;
                relatedDataConv.groupId = messageData.groupId;
                relatedDataConv.matchedRules = messageData.matchedRules;
                relatedDataConv.replyAdvice = messageData.replyAdvice;
                console.log(`🔍 通过 getMessage 扩展了对话 ${relatedDataConv.id} 的详细信息`);
              }
            } catch (error) {
              console.warn(`扩展对话 ${relatedDataConv.id} 详细信息失败:`, error);
            }
          }
          latestConversations.push(relatedDataConv);
        }
        console.log(`💬 完成对话数据处理: ${latestConversations.length} 个，其中扩展了详细信息`);
      } else {
        // 使用新的 getSimilarMessages 方法搜索相关对话
        try {
          latestConversations = await this.getSimilarMessages(entity.name, {
            limit: 5,
            minRelevanceScore: 0.3,
            sortBy: 'relevance',
            sortOrder: 'desc'
          });
          console.log(`🔍 通过 getSimilarMessages 找到相关对话: ${latestConversations.length} 个`);
        } catch (error) {
          console.warn('搜索相关对话失败:', error);
          latestConversations = [];
        }
      }

      // 获取相关网页记录：优先使用 entity.relatedData.webpages，否则从对话中提取
      let latestWebpages = [];
      if (entity.relatedData?.webpages && entity.relatedData.webpages.length > 0) {
        // 使用现有的网页数据
        latestWebpages = entity.relatedData.webpages.map(webpage => ({
          id: webpage.id || `web_${Date.now()}`,
          title: webpage.title || webpage.name || `${entity.name}相关网页`,
          url: webpage.url || '#',
          type: webpage.type || 'webpage',
          datetime: webpage.datetime || webpage.visitTime || new Date().toISOString(),
          summary: webpage.summary || webpage.description || `与${entity.name}相关的内容`,
          tags: webpage.tags || [entity.name, '网页']
        }));
        console.log(`🌐 使用实体现有的网页数据: ${latestWebpages.length} 个`);
      } else {
        // 向量搜索相关网页记录
        try {
          const webpageSearchResults = await this.searchByVector(`${entity.name} 文档 资源`, 'Document', {
            limit: 5,
            returnType: 'entities'
          });
          latestWebpages = webpageSearchResults.data.map(webpage => ({
            id: webpage.id,
            name: webpage.name || '网页资源',
            type: '网页',
            url: webpage.properties?.url || '#'
          }));
          console.log(`🔍 通过向量搜索找到相关资源: ${latestWebpages.length} 个`);
        } catch (error) {
          console.warn('搜索相关资源失败:', error);
          latestWebpages = [];
        }
      }

      // 获取相关人员和主题：优先使用现有数据
      const relatedPeople = entity.relatedData?.people ? entity.relatedData.people.slice(0, 5) : [];
      const relatedTopics = entity.relatedData?.topics ? entity.relatedData.topics.slice(0, 5) : [];
      const jiraTickets = entity.relatedData?.jiraTickets ? entity.relatedData.jiraTickets.slice(0, 5) : [];
      const cooccurringEntities = entity.relatedData?.cooccurringEntities ? entity.relatedData.cooccurringEntities.slice(0, 10) : [];

      // 统计参与者：优先从 people 数据，否则从对话中统计
      let participantCount = 1;
      if (relatedPeople.length > 0) {
        participantCount = relatedPeople.length;
      } else {
        participantCount = new Set(latestConversations.map(conv => conv.sender)).size || 1;
      }

      // 构建扩展后的实体详情
      const result = {
        ...entity,
        statistic: {
          conversations: latestConversations.length,
          projects: relatedProjects.length,
          participants: participantCount,
          resources: relatedResources.length,
          documents: relatedResources.filter(r => r.type === '文档').length,
          webpages: latestWebpages.length,
          relationships: entity.properties?.relationshipsCount || 0,
          topics: relatedTopics.length,
          jiraTickets: jiraTickets.length
        },
        recentDataDetails: {
          conversations: latestConversations,
          webpages: latestWebpages,
          resources: relatedResources,
          projects: relatedProjects,
          people: relatedPeople,
          topics: relatedTopics,
          jiraTickets: jiraTickets,
          cooccurringEntities: cooccurringEntities
        },
        relatedParticipants: [],
        // 由 LocalStorage 在本地填充
        cachedAt: Date.now()
      };

      // 输出数据获取总结
      console.log(`✅ 实体详情扩展完成 [${entity.name}]:`, {
        conversations: `${latestConversations.length} 个`,
        projects: `${relatedProjects.length} 个`,
        resources: `${relatedResources.length} 个`,
        webpages: `${latestWebpages.length} 个`,
        people: `${relatedPeople.length} 个`,
        topics: `${relatedTopics.length} 个`,
        jiraTickets: `${jiraTickets.length} 个`,
        participants: `${participantCount} 人`
      });
      return result;
    } catch (error) {
      console.error('扩展实体详情失败:', error);
      // 返回基础实体和默认值
      return {
        ...entity,
        statistic: {
          conversations: 0,
          projects: 0,
          participants: 1,
          resources: 0,
          documents: 0,
          webpages: 0,
          relationships: 0,
          topics: 0,
          jiraTickets: 0
        },
        recentDataDetails: {
          conversations: [],
          webpages: [],
          resources: [],
          projects: [],
          people: [],
          topics: [],
          jiraTickets: [],
          cooccurringEntities: []
        },
        relatedParticipants: [],
        cachedAt: Date.now()
      };
    }
  }

  /**
   * 批量更新实体的统计信息
   */
  async batchUpdateEntityStatistics(updates) {
    this.ensureInitialized();
    if (!updates || updates.length === 0) {
      console.log('📊 没有统计信息需要更新');
      return;
    }
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) {
        throw new Error('graph-entities 集合未找到');
      }
      console.log(`📊 开始批量更新 ${updates.length} 个实体的统计信息...`);

      // 分批处理，避免一次性操作过多
      const batchSize = 50;
      for (let i = 0; i < updates.length; i += batchSize) {
        const batch = updates.slice(i, i + batchSize);
        try {
          // 获取当前批次的实体
          const entityIds = batch.map(u => u.entityId);
          const existingEntities = await collection.get({
            ids: entityIds,
            include: ['metadatas']
          });
          if (!existingEntities.ids || existingEntities.ids.length === 0) {
            console.log(`📊 批次 ${i / batchSize + 1}: 没有找到对应的实体`);
            continue;
          }

          // 准备更新的元数据
          const updateMetadatas = [];
          const updateIds = [];
          for (let j = 0; j < existingEntities.ids.length; j++) {
            const entityId = existingEntities.ids[j];
            const updateInfo = batch.find(u => u.entityId === entityId);
            if (updateInfo && existingEntities.metadatas) {
              const currentMetadata = existingEntities.metadatas[j];

              // 更新统计信息
              const updatedMetadata = {
                ...currentMetadata,
                statistic: JSON.stringify(updateInfo.statistic),
                lastStatisticUpdate: updateInfo.lastUpdated,
                updated: Date.now()
              };
              updateMetadatas.push(this.serializeChromaMetadata(updatedMetadata));
              updateIds.push(entityId);
            }
          }
          if (updateIds.length > 0) {
            // 执行批量更新
            await collection.update({
              ids: updateIds,
              metadatas: updateMetadatas
            });
            console.log(`📊 批次 ${i / batchSize + 1}: 成功更新 ${updateIds.length} 个实体的统计信息`);
          }
        } catch (batchError) {
          console.error(`📊 批次 ${i / batchSize + 1} 更新失败:`, batchError);
        }
      }
      console.log(`📊 批量统计信息更新完成`);
    } catch (error) {
      console.error('📊 批量更新实体统计信息失败:', error);
      throw error;
    }
  }

  /**
   * 批量更新实体的已读状态
   */
  async batchUpdateEntityReadStatus(updates) {
    this.ensureInitialized();
    if (!updates || updates.length === 0) {
      console.log('📖 没有已读状态需要更新');
      return;
    }
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) {
        throw new Error('graph-entities 集合未找到');
      }
      console.log(`📖 开始批量更新 ${updates.length} 个实体的已读状态...`);

      // 分批处理，避免一次性操作过多
      const batchSize = 50;
      for (let i = 0; i < updates.length; i += batchSize) {
        const batch = updates.slice(i, i + batchSize);
        try {
          // 获取当前批次的实体
          const entityIds = batch.map(u => u.entityId);
          const existingEntities = await collection.get({
            ids: entityIds,
            include: ['metadatas']
          });
          if (!existingEntities.ids || existingEntities.ids.length === 0) {
            console.log(`📖 批次 ${i / batchSize + 1}: 没有找到对应的实体`);
            continue;
          }

          // 准备更新的元数据
          const updateMetadatas = [];
          const updateIds = [];
          for (let j = 0; j < existingEntities.ids.length; j++) {
            const entityId = existingEntities.ids[j];
            const updateInfo = batch.find(u => u.entityId === entityId);
            if (updateInfo && existingEntities.metadatas) {
              const currentMetadata = existingEntities.metadatas[j];

              // 更新已读状态
              const updatedMetadata = {
                ...currentMetadata,
                readStatus: JSON.stringify(updateInfo.readStatus),
                lastReadStatusUpdate: Date.now(),
                updated: Date.now()
              };
              updateMetadatas.push(this.serializeChromaMetadata(updatedMetadata));
              updateIds.push(entityId);
            }
          }
          if (updateIds.length > 0) {
            // 执行批量更新
            await collection.update({
              ids: updateIds,
              metadatas: updateMetadatas
            });
            console.log(`📖 批次 ${i / batchSize + 1}: 成功更新 ${updateIds.length} 个实体的已读状态`);
          }
        } catch (batchError) {
          console.error(`📖 批次 ${i / batchSize + 1} 更新失败:`, batchError);
        }
      }
      console.log(`📖 批量已读状态更新完成`);
    } catch (error) {
      console.error('📖 批量更新实体已读状态失败:', error);
      throw error;
    }
  }

  /**
   * 🆕 生成自然语言描述 - 用于向量搜索的丰富上下文
   */
  /**
   * 🆕 方案E: 生成精简的document用于向量搜索
   * 策略：name + 关键tags（限制总长度不超过100字符）
   */
  generateSimpleDocument(entity) {
    // 基础：实体名称
    let doc = entity.name;

    // 增强：添加关键标签（最多3个，提升语义匹配能力）
    if (entity.tags && entity.tags.length > 0) {
      const tagText = entity.tags.slice(0, 3).join(' ');
      doc += ' ' + tagText;
    }

    // 限制总长度不超过100字符（避免过长影响匹配精度）
    if (doc.length > 100) {
      doc = doc.substring(0, 100);
    }
    return doc.trim();
  }

  /**
   * 生成完整的自然语言描述（用于存储在metadata.description中供LLM理解）
   */
  async generateNaturalLanguageDescription(entity) {
    const parts = [];

    // 基础信息
    parts.push(`${entity.name}是一个${entity.type}实体。`);

    // 类型特定信息
    switch (entity.type) {
      case 'Person':
        if (entity.role) parts.push(`担任${entity.role}角色。`);
        if (entity.team) parts.push(`属于${entity.team}团队。`);
        if (entity.expertise && entity.expertise.length > 0) {
          parts.push(`专业领域包括：${entity.expertise.join('、')}。`);
        }
        break;
      case 'Project':
        if (entity.properties?.status) parts.push(`项目状态：${entity.properties.status}。`);
        break;
      case 'Topic':
        if (entity.properties?.category) parts.push(`话题分类：${entity.properties.category}。`);
        break;
    }

    // 🆕 关联数据的自然语言描述
    const {
      relatedData
    } = entity;

    // 最近的对话情况
    if (relatedData?.conversations && relatedData.conversations.length > 0) {
      const recentConversations = relatedData.conversations.slice(0, 5); // 取最近5条
      parts.push(`最近的相关讨论包括：`);
      recentConversations.forEach(conv => {
        parts.push(`- ${conv.sender}在${conv.groupName || '聊天'}中提到：${conv.summary}`);
      });
    }

    // 关联的项目
    if (relatedData?.projects && relatedData.projects.length > 0) {
      const topProjects = relatedData.projects.slice(0, 3);
      parts.push(`与以下项目相关：${topProjects.map(p => `${p.name}(${p.status})`).join('、')}。`);
    }

    // 关联的人员
    if (relatedData?.people && relatedData.people.length > 0) {
      const topPeople = relatedData.people.slice(0, 5);
      parts.push(`经常与这些人员合作：${topPeople.map(p => `${p.name}(${p.role})`).join('、')}。`);
    }

    // 关联的话题
    if (relatedData?.topics && relatedData.topics.length > 0) {
      const topTopics = relatedData.topics.slice(0, 3);
      parts.push(`相关讨论话题：${topTopics.map(t => t.name).join('、')}。`);
    }

    // JIRA工作项
    if (relatedData?.jiraTickets && relatedData.jiraTickets.length > 0) {
      const activeTickets = relatedData.jiraTickets.filter(t => t.status !== 'Done').slice(0, 3);
      if (activeTickets.length > 0) {
        parts.push(`相关的工作项：${activeTickets.map(t => `${t.key}: ${t.summary}`).join('；')}。`);
      }
    }

    // 网页资源
    if (relatedData?.webpages && relatedData.webpages.length > 0) {
      const recentPages = relatedData.webpages.slice(0, 3);
      parts.push(`相关网页资源：${recentPages.map(w => w.title).join('、')}。`);
    }

    // 其他相关实体
    if (relatedData?.cooccurringEntities && relatedData.cooccurringEntities.length > 0) {
      const topEntities = relatedData.cooccurringEntities.slice(0, 5);
      parts.push(`经常与这些概念一起出现：${topEntities.map(e => e.name).join('、')}。`);
    }

    // 统计信息
    const stats = entity.statistic;
    if (stats) {
      const activeParts = [];
      if (stats.conversations > 0) activeParts.push(`${stats.conversations}次对话`);
      if (stats.projects > 0) activeParts.push(`${stats.projects}个项目`);
      if (stats.participants > 0) activeParts.push(`${stats.participants}位参与者`);
      if (stats.jiraTickets > 0) activeParts.push(`${stats.jiraTickets}个工作项`);
      if (activeParts.length > 0) {
        parts.push(`总体活跃度：${activeParts.join('、')}。`);
      }
    }

    // 重要性和标签
    if (entity.importance > 0.7) {
      parts.push(`这是一个高优先级项目。`);
    }
    if (entity.tags && entity.tags.length > 0) {
      parts.push(`标签：${entity.tags.join('、')}。`);
    }
    return parts.join(' ');
  }

  /**
   * 🆕 计算实体热度评分 (0-1)
   */
  calculateEntityHotness(entity) {
    const now = Date.now();
    const dayMs = 24 * 60 * 60 * 1000;

    // 1. 最近活动频率（权重40%）
    let recentActivityScore = 0;
    const recentConversations = entity.relatedData?.conversations?.filter(c => now - new Date(c.datetime).getTime() < 7 * dayMs).length || 0;
    recentActivityScore = Math.min(recentConversations / 10, 1); // 7天内10条消息=满分

    // 2. 访问频率（权重30%）
    const daysSinceCreated = Math.max(1, (now - entity.created) / dayMs);
    const accessFrequency = (entity.accessCount || 0) / daysSinceCreated;
    const accessScore = Math.min(accessFrequency * 5, 1); // 每天5次访问=满分

    // 3. 关联数据丰富度（权重20%）
    const totalRelations = (entity.relatedData?.conversations?.length || 0) + (entity.relatedData?.projects?.length || 0) * 2 + (entity.relatedData?.people?.length || 0) + (entity.relatedData?.jiraTickets?.length || 0);
    const richnessScore = Math.min(totalRelations / 30, 1); // 30个关联=满分

    // 4. 最近更新（权重10%）
    const daysSinceUpdate = (now - entity.updated) / dayMs;
    const freshnessScore = Math.max(0, 1 - daysSinceUpdate / 7); // 7天内=满分

    return recentActivityScore * 0.4 + accessScore * 0.3 + richnessScore * 0.2 + freshnessScore * 0.1;
  }

  /**
   * 🆕 计算实体关键性评分 (0-1)
   */
  calculateEntityCriticality(entity) {
    let userImportanceBoost = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
    // 1. 基础重要性（权重50%）
    const baseImportance = entity.importance || 0.5;

    // 2. 用户明确标记（权重30%）
    const userBoostScore = Math.min(userImportanceBoost, 1);

    // 3. 关联项目重要性（权重15%）
    let projectImportanceScore = 0;
    if (entity.relatedData?.projects && entity.relatedData.projects.length > 0) {
      const activeProjects = entity.relatedData.projects.filter(p => p.status !== 'Completed');
      projectImportanceScore = Math.min(activeProjects.length / 3, 1); // 3个活跃项目=满分
    }

    // 4. 关联人员重要性（权重5%）
    const peopleImportanceScore = Math.min((entity.relatedData?.people?.length || 0) / 10, 1);
    return baseImportance * 0.5 + userBoostScore * 0.3 + projectImportanceScore * 0.15 + peopleImportanceScore * 0.05;
  }

  /**
   * 🆕 从消息元数据构建实体关联数据
   * 🔧 修复：使用实体ID映射表，避免重复查询数据库
   */
  async buildEntityRelatedDataFromMessage(entityName, entityType, messageMetadata, extractedEntities, messageId, entityIdMap) {
    const entityKey = entityType + '_' + entityName;
    const relatedData = {
      conversations: [],
      webpages: [],
      resources: [],
      projects: [],
      people: [],
      topics: [],
      jiraTickets: [],
      cooccurringEntities: []
    };

    // 1. 添加当前消息
    if (messageMetadata) {
      relatedData.conversations.push({
        id: messageId,
        summary: messageMetadata.summary || messageMetadata.content?.substring(0, 100) + '...',
        sender: messageMetadata.sender || messageMetadata.source || 'unknown',
        groupId: messageMetadata.groupId || '',
        groupName: messageMetadata.groupName || '未知群组',
        groupUrl: messageMetadata.groupUrl || '#',
        datetime: messageMetadata.datetime || new Date().toISOString(),
        relevanceScore: 0.9,
        // 来源消息相关性最高
        isRead: false,
        // 🆕 新消息默认未读
        readTimestamp: undefined // 🆕 未阅读时为undefined
      });
    }

    // 2. 添加同消息中的其他实体作为共现实体
    // 🔧 优化：直接从映射表获取实体ID，避免重复查询数据库
    for (const otherEntity of extractedEntities) {
      const key = otherEntity.type + '_' + otherEntity.name;
      if (key !== entityKey) {
        // 🔧 从映射表中获取实体ID（阶段1已经确保所有实体都存在）
        const entityId = entityIdMap.get(key);
        if (!entityId) {
          // 理论上不应该发生，因为阶段1已经处理了所有实体
          console.warn(`⚠️ 映射表中未找到实体ID: ${otherEntity.name}(${otherEntity.type})`);
          continue;
        }
        relatedData.cooccurringEntities.push({
          id: entityId,
          name: otherEntity.name,
          type: otherEntity.type,
          relevanceScore: 0.8 // 同消息共现的相关性较高
        });

        // 根据类型添加到对应的关联数据中
        switch (otherEntity.type) {
          case 'Person':
            relatedData.people.push({
              id: entityId,
              name: otherEntity.name,
              role: otherEntity.properties?.role || '',
              team: otherEntity.properties?.team || '',
              expertise: otherEntity.properties?.expertise || [],
              lastContact: Date.now(),
              relevanceScore: 0.8
            });
            break;
          case 'Project':
            relatedData.projects.push({
              id: entityId,
              name: otherEntity.name,
              description: otherEntity.document || '',
              status: otherEntity.properties?.status || 'Active',
              relevanceScore: 0.8
            });
            break;
          case 'Topic':
            relatedData.topics.push({
              id: entityId,
              name: otherEntity.name,
              summary: otherEntity.document || `关于${otherEntity.name}的讨论`,
              category: otherEntity.properties?.category || '技术讨论',
              relevanceScore: 0.8
            });
            break;
          case 'Task':
            // 假设Task类型是JIRA ticket
            relatedData.jiraTickets.push({
              id: entityId,
              key: otherEntity.properties?.key || otherEntity.name,
              summary: otherEntity.document || otherEntity.name,
              status: otherEntity.properties?.status || 'In Progress',
              assignee: otherEntity.properties?.assignee || '',
              dueDate: otherEntity.properties?.dueDate || Date.now(),
              priority: otherEntity.properties?.priority || 'Medium',
              relevanceScore: 0.8
            });
            break;
          case 'Document':
            relatedData.resources.push({
              id: entityId,
              summary: otherEntity.document || `文档：${otherEntity.name}`,
              name: otherEntity.name,
              type: 'document',
              url: otherEntity.properties?.url,
              relevanceScore: 0.7
            });
            break;
        }
      }
    }
    return relatedData;
  }

  /**
   * 🆕 从消息元数据提取实体信息
   */
  extractEntitiesFromMetadata(metadata, messageId) {
    const entities = [];
    if (metadata.entities) {
      // 提取人员实体
      if (metadata.entities.people) {
        for (const person of metadata.entities.people) {
          entities.push({
            type: 'Person',
            name: person.name,
            document: `人员: ${person.name}`,
            role: person.role,
            team: person.team,
            expertise: person.expertise,
            properties: {
              mentioned_context: person.mentioned_context,
              source: 'message_analysis',
              groupName: metadata.groupName || '',
              messageId: messageId,
              datetime: metadata.datetime || Date.now()
            },
            importance: 0.7,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }

      // 提取项目实体
      if (metadata.entities.projects) {
        for (const project of metadata.entities.projects) {
          entities.push({
            type: 'Project',
            name: project.name,
            document: `项目: ${project.name}`,
            properties: {
              status: project.status,
              related_people: project.related_people,
              source: 'message_analysis',
              groupName: metadata.groupName || '',
              messageId: messageId,
              timestamp: metadata.timestamp || Date.now()
            },
            importance: 0.8,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }

      // 提取话题实体
      if (metadata.entities.topics) {
        for (const topic of metadata.entities.topics) {
          entities.push({
            type: 'Topic',
            name: topic.name,
            document: `话题: ${topic.name}`,
            properties: {
              category: topic.category,
              keywords: topic.keywords,
              source: 'message_analysis',
              groupName: metadata.groupName || '',
              messageId: messageId,
              timestamp: metadata.timestamp || Date.now()
            },
            importance: 0.5,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }

      // 提取文档/资源实体
      if (metadata.entities.documents || metadata.entities.resources) {
        const documentsList = [...(metadata.entities.documents || []), ...(metadata.entities.resources || [])];
        for (const doc of documentsList) {
          entities.push({
            type: 'Document',
            name: doc.name || doc.title,
            document: `文档: ${doc.name || doc.title}`,
            properties: {
              url: doc.url,
              type: doc.type || 'document',
              description: doc.description,
              source: 'message_analysis',
              groupName: metadata.groupName || '',
              messageId: messageId,
              timestamp: metadata.timestamp || Date.now()
            },
            importance: 0.6,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }

      // 提取技术实体
      if (metadata.entities.technologies || metadata.entities.tools) {
        const techList = [...(metadata.entities.technologies || []), ...(metadata.entities.tools || [])];
        for (const tech of techList) {
          entities.push({
            type: 'Technology',
            name: tech.name,
            document: `技术: ${tech.name}`,
            properties: {
              category: tech.category,
              version: tech.version,
              usage_context: tech.usage_context,
              source: 'message_analysis',
              groupName: metadata.groupName || '',
              type: 'technology',
              messageId: messageId,
              timestamp: metadata.timestamp || Date.now()
            },
            importance: 0.6,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }

      // 提取组织实体或个人实体（根据 groupName 格式判断）
      if (metadata.groupName && metadata.groupName !== 'SM AI') {
        // 检查是否是 firstName.lastName 组合形式的聊天（用 + 分隔）
        const participants = metadata.groupName.split('+').map(p => p.trim());
        const isPersonalChat = participants.every(p => /^[a-zA-Z]+\.[a-zA-Z]+$/.test(p));
        if (isPersonalChat && participants.length >= 2) {
          // 这是一个个人或多人聊天，提取除了 esone.qiu 之外的参与者
          const otherParticipants = participants.filter(p => p.toLowerCase() !== 'esone.qiu');
          for (const participant of otherParticipants) {
            // 将 firstName.lastName 转换为 Firstname Lastname
            const [firstName, lastName] = participant.split('.');
            const displayName = `${firstName.charAt(0).toUpperCase() + firstName.slice(1)} ${lastName.charAt(0).toUpperCase() + lastName.slice(1)}`;
            entities.push({
              type: 'Person',
              name: displayName,
              document: `人物: ${displayName}`,
              properties: {
                email: `${participant}@ringcentral.com`,
                // 可能的邮箱格式
                username: participant,
                source: 'message_analysis',
                messageId: messageId,
                timestamp: metadata.timestamp || Date.now()
              },
              importance: 0.7,
              accessCount: 1,
              lastAccessed: Date.now(),
              tags: [],
              statistic: {
                conversations: 0,
                projects: 0,
                participants: 0,
                resources: 0,
                documents: 0,
                webpages: 0,
                relationships: 0,
                topics: 0,
                jiraTickets: 0
              },
              relatedData: {
                conversations: [],
                webpages: [],
                resources: [],
                projects: [],
                people: [],
                topics: [],
                jiraTickets: [],
                cooccurringEntities: []
              }
            });
          }
        } else {
          // 这是一个正常的组织/团队聊天组
          entities.push({
            type: 'Organization',
            name: metadata.groupName,
            document: `组织: ${metadata.groupName}`,
            properties: {
              groupId: metadata.groupId,
              source: 'message_analysis',
              type: 'team',
              messageId: messageId,
              timestamp: metadata.timestamp || Date.now()
            },
            importance: 0.6,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }
    }
    return entities;
  }

  /**
   * 🆕 更新实体关联数据 - 从消息分析中提取实体并更新其关联信息
   * 🔧 修复：采用两阶段处理，先创建所有实体，再建立关联关系
   */
  async updateEntitiesWithRelatedData(messageMetadata, messageId) {
    console.log(`🔗 开始从消息 ${messageId} 更新实体关联数据...`);
    try {
      // 1. 从消息元数据提取实体
      const extractedEntities = this.extractEntitiesFromMetadata(messageMetadata, messageId);
      if (extractedEntities.length === 0) {
        console.log('📭 消息中未发现实体，跳过关联数据更新');
        return;
      }
      console.log(`📝 从消息中提取到 ${extractedEntities.length} 个实体: ${extractedEntities.map(e => `${e.name}(${e.type})`).join(', ')}`);

      // 🔧 阶段1：确保所有实体都存在于数据库中（不包含相互引用）
      const entityIdMap = new Map(); // key: type_name, value: entityId

      for (const entity of extractedEntities) {
        try {
          const entityKey = `${entity.type}_${entity.name}`;

          // 检查实体是否已存在
          const similarEntities = await this.getSimilarEntities({
            ...entity,
            created: Date.now(),
            updated: Date.now()
          });
          const existingEntity = similarEntities.length > 0 ? similarEntities[0] : null;
          if (existingEntity) {
            console.log(`✅ 实体已存在: ${entity.name}(${entity.type}) -> ${existingEntity.id}`);
            entityIdMap.set(entityKey, existingEntity.id);
          } else {
            // 创建新实体（暂不包含关联数据）
            const newEntity = {
              ...entity,
              created: Date.now(),
              updated: Date.now(),
              accessCount: 1,
              lastAccessed: Date.now(),
              hotness: 0.5,
              criticalityScore: entity.importance || 0.5,
              readStatus: {
                unreadCount: 1,
                // 初始有1条未读消息
                lastReadTime: null,
                lastUpdateTime: Date.now()
              }
            };
            const storeResult = await _memory__WEBPACK_IMPORTED_MODULE_3__.memorySystem.storeEntity(newEntity);
            if (storeResult.success && storeResult.entityId) {
              console.log(`🆕 新实体创建: ${entity.name}(${entity.type}) -> ${storeResult.entityId}`);
              entityIdMap.set(entityKey, storeResult.entityId);
            } else {
              console.error(`❌ 创建实体失败: ${entity.name}(${entity.type})`);
            }
          }
        } catch (error) {
          console.error(`❌ 处理实体 ${entity.name} 失败:`, error);
        }
      }
      console.log(`📊 实体ID映射表创建完成，共 ${entityIdMap.size} 个实体`);

      // 🔧 阶段2：为每个实体构建和更新关联数据（使用真实的实体ID）
      for (const entity of extractedEntities) {
        try {
          const entityKey = `${entity.type}_${entity.name}`;
          const currentEntityId = entityIdMap.get(entityKey);
          if (!currentEntityId) {
            console.warn(`⚠️ 未找到实体ID: ${entity.name}(${entity.type})`);
            continue;
          }

          // 构建关联数据（传入映射表，避免重复查询数据库）
          const relatedDataForEntity = await this.buildEntityRelatedDataFromMessage(entity.name, entity.type, messageMetadata, extractedEntities, messageId, entityIdMap // 🔧 传入映射表
          );

          // 计算实体热度和重要性
          const entityWithRelatedData = {
            ...entity,
            created: Date.now(),
            updated: Date.now(),
            relatedData: relatedDataForEntity
          };

          // 更新热度和关键性评分
          entityWithRelatedData.hotness = this.calculateEntityHotness(entityWithRelatedData);
          entityWithRelatedData.criticalityScore = this.calculateEntityCriticality(entityWithRelatedData, 0);

          // 获取现有实体
          const existingEntity = await this.getEntity(currentEntityId);
          if (!existingEntity) {
            console.error(`❌ 无法获取实体: ${currentEntityId}`);
            continue;
          }

          // 计算未读消息数
          const newUnreadCount = relatedDataForEntity.conversations?.filter(c => !c.isRead).length || 0;
          const currentUnreadCount = existingEntity.readStatus?.unreadCount || 0;
          const unreadCount = currentUnreadCount + newUnreadCount;

          // 更新实体的关联数据
          const updateData = {
            relatedData: relatedDataForEntity,
            hotness: entityWithRelatedData.hotness,
            criticalityScore: entityWithRelatedData.criticalityScore,
            lastAccessed: Date.now(),
            accessCount: (existingEntity.accessCount || 0) + 1,
            statistic: {
              conversations: relatedDataForEntity.conversations?.length || 0,
              projects: relatedDataForEntity.projects?.length || 0,
              participants: relatedDataForEntity.people?.length || 0,
              resources: relatedDataForEntity.resources?.length || 0,
              documents: relatedDataForEntity.resources?.filter(r => r.type === 'document')?.length || 0,
              webpages: relatedDataForEntity.webpages?.length || 0,
              topics: relatedDataForEntity.topics?.length || 0,
              jiraTickets: relatedDataForEntity.jiraTickets?.length || 0,
              relationships: relatedDataForEntity.cooccurringEntities?.length || 0
            },
            readStatus: {
              unreadCount: unreadCount,
              lastReadTime: existingEntity.readStatus?.lastReadTime || null,
              lastUpdateTime: Date.now()
            }
          };
          const updateResult = await _memory__WEBPACK_IMPORTED_MODULE_3__.memorySystem.updateEntity(currentEntityId, updateData);
          console.log(`🔄 实体关联数据更新: ${entity.name}, 成功: ${updateResult.success ? '✅' : '❌'}, 未读: ${unreadCount}`);
        } catch (entityError) {
          console.error(`❌ 更新实体 ${entity.name} 关联数据失败:`, entityError);
        }
      }
      console.log(`✅ 所有实体关联数据更新完成`);
    } catch (error) {
      console.error('🚨 更新实体关联数据过程中发生错误:', error);
    }
  }

  /**
   * 🆕 清理实体的过期消息
   * 清理策略：只保留1个月内的消息（不区分已读未读）
   */
  async cleanExpiredReadConversations(entityId) {
    this.ensureInitialized();
    const result = {
      entitiesProcessed: 0,
      conversationsRemoved: 0,
      spaceSaved: 0
    };
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) {
        console.warn('graph-entities 集合不存在');
        return result;
      }
      const oneMonthAgo = Date.now() - 30 * 24 * 60 * 60 * 1000; // 30天前

      // 如果指定了entityId，只清理该实体
      const entityIds = entityId ? [entityId] : [];

      // 如果没有指定，获取所有实体
      if (!entityId) {
        const allEntities = await collection.get({
          include: ['metadatas']
        });
        if (allEntities.ids) {
          entityIds.push(...allEntities.ids);
        }
      }
      console.log(`🧹 开始清理 ${entityIds.length} 个实体的过期消息...`);

      // 批量处理实体
      const batchSize = 50;
      for (let i = 0; i < entityIds.length; i += batchSize) {
        const batch = entityIds.slice(i, i + batchSize);
        const entities = await collection.get({
          ids: batch,
          include: ['metadatas', 'documents']
        });
        if (!entities.metadatas || entities.metadatas.length === 0) continue;
        const updateIds = [];
        const updateMetadatas = [];
        for (let j = 0; j < entities.ids.length; j++) {
          const entityId = entities.ids[j];
          const metadata = entities.metadatas[j];

          // 反序列化实体
          const entity = this.deserializeEntityFromMetadata(metadata);
          if (!entity.relatedData?.conversations || entity.relatedData.conversations.length === 0) {
            continue;
          }
          const originalCount = entity.relatedData.conversations.length;

          // 🆕 简化策略：只保留1个月内的消息（不区分已读未读）
          entity.relatedData.conversations = entity.relatedData.conversations.filter(conv => {
            const convTime = new Date(conv.datetime).getTime();
            return convTime > oneMonthAgo; // 保留1个月内的所有消息
          });
          const newCount = entity.relatedData.conversations.length;
          const removed = originalCount - newCount;
          if (removed > 0) {
            // 更新统计信息
            entity.statistic.conversations = entity.relatedData.conversations.length;

            // 🆕 重新计算 unreadCount（清理后可能有变化）
            if (entity.readStatus) {
              const unreadInRemaining = entity.relatedData.conversations.filter(c => !c.isRead).length;
              entity.readStatus.unreadCount = unreadInRemaining;
              entity.readStatus.lastUpdateTime = Date.now();
            }

            // 重新序列化
            const updatedMetadata = {
              ...metadata,
              relatedData: JSON.stringify(entity.relatedData),
              statistic: JSON.stringify(entity.statistic),
              readStatus: entity.readStatus ? JSON.stringify(entity.readStatus) : undefined,
              updated: Date.now()
            };
            updateIds.push(entityId);
            updateMetadatas.push(this.serializeChromaMetadata(updatedMetadata));
            result.conversationsRemoved += removed;
            result.spaceSaved += removed * 500; // 估算每条消息约500字节
          }
        }

        // 批量更新
        if (updateIds.length > 0) {
          await collection.update({
            ids: updateIds,
            metadatas: updateMetadatas
          });
          result.entitiesProcessed += updateIds.length;
        }
      }
      console.log(`✅ 清理完成: 处理${result.entitiesProcessed}个实体, 移除${result.conversationsRemoved}条过期消息, 节省${(result.spaceSaved / 1024).toFixed(2)}KB空间`);
      return result;
    } catch (error) {
      console.error('🚨 清理过期消息失败:', error);
      throw error;
    }
  }

  /**
   * 🆕 存储独立用户配置（自定义Prompt和分析偏好）
   */
  async storeIndependentUserConfig(config) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-user-config`);
      if (!collection) {
        console.warn('用户配置集合不存在，尝试创建...');
        // 尝试创建集合
        try {
          await this.client.createCollection({
            name: `${this.username}-user-config`,
            metadata: {
              type: 'user-config'
            }
          });
          this.collections.set(`${this.username}-user-config`, await this.client.getCollection({
            name: `${this.username}-user-config`
          }));
        } catch (createError) {
          console.error('创建用户配置集合失败:', createError);
          return false;
        }
      }
      const configCollection = this.collections.get(`${this.username}-user-config`);
      const configId = `config-${this.username}`;
      const embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(`user config: ${JSON.stringify(config).substring(0, 100)}`);
      await configCollection.upsert({
        ids: [configId],
        documents: [`User configuration for ${this.username}`],
        embeddings: [embedding],
        metadatas: [{
          userId: this.username,
          configType: 'independent_user_config',
          lastUpdated: Date.now(),
          version: config.version || '1.0',
          configData: JSON.stringify(config)
        }]
      });
      console.log('独立用户配置已存储到云端');
      return true;
    } catch (error) {
      console.error('存储独立用户配置失败:', error);
      return false;
    }
  }

  /**
   * 🆕 获取独立用户配置
   */
  async getIndependentUserConfig() {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-user-config`);
      if (!collection) {
        console.log('用户配置集合不存在');
        return null;
      }
      const configId = `config-${this.username}`;
      const result = await collection.get({
        ids: [configId],
        include: ['metadatas']
      });
      if (result.metadatas && result.metadatas.length > 0) {
        const metadata = result.metadatas[0];
        if (metadata && metadata.configData) {
          console.log('从云端获取独立用户配置成功');
          return JSON.parse(metadata.configData);
        }
      }
      console.log('云端未找到独立用户配置');
      return null;
    } catch (error) {
      console.error('获取独立用户配置失败:', error);
      return null;
    }
  }

  // ==================== ChromaDB 包装方法(暂不启用) ====================

  /**
   * 包装 collection.get 方法，自动反序列化 metadata
   */
  async wrappedCollectionGet(collection, params) {
    const result = await collection.get(params);

    // 自动反序列化 metadata（创建新对象以避免只读属性错误）
    if (result.metadatas) {
      return {
        ...result,
        metadatas: result.metadatas.map(metadata => this.deserializeChromaMetadata(metadata))
      };
    }
    return result;
  }

  /**
   * 包装 collection.query 方法，自动反序列化 metadata
   */
  async wrappedCollectionQuery(collection, params) {
    const result = await collection.query(params);

    // 自动反序列化 metadata（创建新对象以避免只读属性错误）
    if (result.metadatas) {
      return {
        ...result,
        metadatas: result.metadatas.map(metadataArray => metadataArray.map(metadata => this.deserializeChromaMetadata(metadata)))
      };
    }
    return result;
  }

  /**
   * 包装 collection.add 方法，自动序列化 metadata
   */
  async wrappedCollectionAdd(collection, params) {
    const wrappedParams = {
      ...params
    };

    // 自动序列化 metadata
    if (wrappedParams.metadatas) {
      wrappedParams.metadatas = wrappedParams.metadatas.map(metadata => this.serializeChromaMetadata(metadata));
    }
    return await collection.add(wrappedParams);
  }

  /**
   * 包装 collection.update 方法，自动序列化 metadata
   */
  async wrappedCollectionUpdate(collection, params) {
    const wrappedParams = {
      ...params
    };

    // 自动序列化 metadata
    if (wrappedParams.metadatas) {
      wrappedParams.metadatas = wrappedParams.metadatas.map(metadata => this.serializeChromaMetadata(metadata));
    }
    return await collection.update(wrappedParams);
  }

  /**
   * 包装 collection.upsert 方法，自动序列化 metadata
   */
  async wrappedCollectionUpsert(collection, params) {
    const wrappedParams = {
      ...params
    };

    // 自动序列化 metadata
    if (wrappedParams.metadatas) {
      wrappedParams.metadatas = wrappedParams.metadatas.map(metadata => this.serializeChromaMetadata(metadata));
    }
    return await collection.upsert(wrappedParams);
  }

  /**
   * 包装 collection.delete 方法（不需要序列化/反序列化）
   */
  async wrappedCollectionDelete(collection, params) {
    return await collection.delete(params);
  }
}

/***/ }),

/***/ 7997:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   D: () => (/* binding */ LocalStorage)
/* harmony export */ });
/**
 * 本地缓存管理器
 * 专门管理 Chrome Storage 缓存，包括实体基础信息、关系索引和最近数据
 */

// 统一的缓存实体详情接口 - 包含所有本地缓存数据

// 关系类型定义

// 缓存键前缀
const CACHE_KEYS = {
  ENTITIES: 'cache_entities',
  // 统一存储 CachedEntityDetail 格式，移除 RECENT_DATA
  ENTITY_INDEX: 'cache_entity_index',
  TYPE_INDEX: 'cache_type_index',
  RELATIONSHIPS: 'cache_relationships',
  RELATIONSHIP_INDEX: 'cache_relationship_index',
  STATISTICS: 'cache_statistics'
};

// 缓存配置

// 实体索引

// 类型索引

// 关系索引

/**
 * 本地存储管理器
 */
class LocalStorage {
  constructor() {
    this.memoryEntities = new Map();
    this.memoryRelationships = new Map();
    this.isInitialized = false;
    this.config = {
      maxEntitiesInMemory: 1000,
      // 内存中最多保存1000个实体
      maxRecentDataPerEntity: 5,
      // 每个实体最多保存5条最近数据
      statisticsCacheDuration: 30 * 60 * 1000,
      // 30分钟
      recentDataCacheDuration: 6 * 60 * 60 * 1000,
      // 6小时
      // 新增：最近数据同步配置
      enableRecentDataSync: true,
      // 启用基于关系的最近数据同步
      recentDataSyncBatchSize: 10,
      // 每批处理10个实体的最近数据
      recentDataQueryLimit: 5 // 每个实体最多查询5条最近数据
    };
  }

  /**
   * 初始化本地缓存
   */
  async initialize() {
    try {
      console.log('💾 初始化本地缓存...');

      // 加载实体到内存
      await this.loadEntitiesToMemory();

      // 加载关系到内存
      await this.loadRelationshipsToMemory();

      // 启动定期清理
      this.startPeriodicCleanup();
      this.isInitialized = true;
      console.log('✅ 本地缓存初始化完成');
      return true;
    } catch (error) {
      console.error('❌ 本地缓存初始化失败:', error);
      return false;
    }
  }

  // ==================== 实体缓存管理 ====================

  /**
   * 获取实体详情（统一的CachedEntityDetail格式，先内存后存储）
   */
  async getEntity(entityId) {
    this.ensureInitialized();

    // 从存储获取完整的 CachedEntityDetail
    try {
      const result = await chrome.storage.local.get(`${CACHE_KEYS.ENTITIES}_${entityId}`);
      const entity = result[`${CACHE_KEYS.ENTITIES}_${entityId}`];
      if (entity) {
        // 更新访问时间
        entity.lastAccessed = Date.now();
        entity.accessCount = (entity.accessCount || 0) + 1;

        // 确保实体包含所有必要的字段
        this.ensureDetailEntityFields(entity);

        // 同步基础实体到内存（如果空间允许）
        if (this.memoryEntities.size < this.config.maxEntitiesInMemory) {
          const baseEntity = this.convertToBaseEntity(entity);
          this.memoryEntities.set(entityId, baseEntity);
        }
        return entity;
      }
    } catch (error) {
      console.error('从存储获取实体失败:', error);
    }
    return null;
  }

  /**
   * 按类型查询实体
   */
  async queryEntitiesByType(type) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    this.ensureInitialized();
    const startTime = Date.now();
    const {
      limit = 50,
      offset = 0,
      sortBy = 'lastAccessed',
      sortOrder = 'desc'
    } = options;
    try {
      // 获取类型索引
      const typeIndex = await this.getTypeIndex();
      const entityIds = typeIndex[type] || [];
      const entities = [];

      // 获取实体数据
      for (const entityId of entityIds) {
        const entity = await this.getEntity(entityId);
        if (entity) {
          entities.push(entity);
        }
      }

      // 排序
      entities.sort((a, b) => {
        const aValue = a[sortBy];
        const bValue = b[sortBy];
        return sortOrder === 'desc' ? bValue - aValue : aValue - bValue;
      });

      // 分页
      const paginatedEntities = entities.slice(offset, offset + limit);
      return {
        data: paginatedEntities,
        total: entities.length,
        source: 'local',
        cached: true,
        queryTime: Date.now() - startTime
      };
    } catch (error) {
      console.error('按类型查询实体失败:', error);
      return {
        data: [],
        total: 0,
        source: 'local',
        cached: true,
        queryTime: Date.now() - startTime
      };
    }
  }

  /**
   * 搜索实体（本地模糊搜索）
   */
  async searchEntities(searchTerm, type) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    this.ensureInitialized();
    const startTime = Date.now();
    const {
      limit = 20
    } = options;
    try {
      const entities = [];
      const searchLower = searchTerm.toLowerCase();

      // 从内存搜索
      for (const entity of Array.from(this.memoryEntities.values())) {
        if (type && entity.type !== type) continue;
        const matchesName = entity.name.toLowerCase().includes(searchLower);
        const matchesDescription = entity.description?.toLowerCase().includes(searchLower);
        const matchesTags = entity.tags?.some(tag => tag.toLowerCase().includes(searchLower));
        if (matchesName || matchesDescription || matchesTags) {
          entities.push(entity);
        }
      }

      // 如果内存中结果不够，从存储搜索
      if (entities.length < limit) {
        // 这里可以实现更复杂的存储搜索逻辑
        // 暂时先返回内存结果
      }

      // 按相关性排序（简单实现）
      entities.sort((a, b) => {
        const aScore = this.calculateRelevanceScore(a, searchTerm);
        const bScore = this.calculateRelevanceScore(b, searchTerm);
        return bScore - aScore;
      });
      return {
        data: entities.slice(0, limit),
        total: entities.length,
        source: 'local',
        cached: true,
        queryTime: Date.now() - startTime
      };
    } catch (error) {
      console.error('搜索实体失败:', error);
      return {
        data: [],
        total: 0,
        source: 'local',
        cached: true,
        queryTime: Date.now() - startTime
      };
    }
  }

  /**
   * 缓存实体（统一存储为CachedEntityDetail格式）
   */
  async cacheEntity(entity) {
    this.ensureInitialized();
    try {
      // 转换为 CachedEntityDetail 格式
      const detailEntity = this.isCachedEntityDetail(entity) ? entity : this.convertToDetailEntity(entity);

      // 确保包含所有必要字段
      this.ensureDetailEntityFields(detailEntity);

      // 存储到持久化存储（统一使用 CachedEntityDetail 格式）
      await chrome.storage.local.set({
        [`${CACHE_KEYS.ENTITIES}_${entity.id}`]: detailEntity
      });

      // 加载基础实体到内存（如果空间允许）
      const baseEntity = this.convertToBaseEntity(detailEntity);
      if (this.memoryEntities.size < this.config.maxEntitiesInMemory) {
        this.memoryEntities.set(entity.id, baseEntity);
      } else {
        // 移除最少使用的实体
        const lruEntity = this.findLRUEntity();
        if (lruEntity) {
          this.memoryEntities.delete(lruEntity.id);
        }
        this.memoryEntities.set(entity.id, baseEntity);
      }

      // 更新索引
      await this.updateEntityIndex(baseEntity);
    } catch (error) {
      console.error('缓存实体失败:', error);
    }
  }

  /**
   * 获取所有缓存的实体
   */
  async getAllEntities() {
    this.ensureInitialized();
    try {
      const entities = [];

      // 从内存获取所有实体
      for (const entity of Array.from(this.memoryEntities.values())) {
        entities.push(entity);
      }

      // 如果内存中没有实体，从存储中加载
      if (entities.length === 0) {
        const entityIndex = await this.getEntityIndex();
        for (const entityId of Object.keys(entityIndex)) {
          const entity = await this.getEntity(entityId);
          if (entity) {
            entities.push(entity);
          }
        }
      }
      console.log(`📦 从本地缓存获取了 ${entities.length} 个实体`);
      return entities;
    } catch (error) {
      console.error('获取所有本地实体失败:', error);
      return [];
    }
  }

  /**
   * 批量缓存实体
   */
  async batchCacheEntities(entities) {
    this.ensureInitialized();
    try {
      // 批量存储
      const storageData = {};
      for (const entity of entities) {
        storageData[`${CACHE_KEYS.ENTITIES}_${entity.id}`] = entity;
      }
      await chrome.storage.local.set(storageData);

      // 更新内存和索引
      for (const entity of entities) {
        if (this.memoryEntities.size < this.config.maxEntitiesInMemory) {
          this.memoryEntities.set(entity.id, entity);
        }
        await this.updateEntityIndex(entity);
      }
    } catch (error) {
      console.error('批量缓存实体失败:', error);
    }
  }

  // ==================== 关系缓存管理 ====================

  /**
   * 获取关系网络
   */
  async getRelationshipNetwork(entityId) {
    let depth = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
    this.ensureInitialized();
    try {
      const visitedEntities = new Set();
      const foundEntities = [];
      const foundRelationships = [];
      await this.traverseRelationships(entityId, depth, visitedEntities, foundEntities, foundRelationships);
      return {
        entities: foundEntities,
        relationships: foundRelationships
      };
    } catch (error) {
      console.error('获取关系网络失败:', error);
      return {
        entities: [],
        relationships: []
      };
    }
  }

  /**
   * 🆕 存储关系（对外接口）
   */
  async storeRelationship(relationship) {
    await this.cacheRelationship(relationship);
  }

  /**
   * 缓存关系
   */
  async cacheRelationship(relationship) {
    this.ensureInitialized();
    try {
      // 存储到持久化存储
      await chrome.storage.local.set({
        [`${CACHE_KEYS.RELATIONSHIPS}_${relationship.id}`]: relationship
      });

      // 加载到内存
      this.memoryRelationships.set(relationship.id, relationship);

      // 更新关系索引
      await this.updateRelationshipIndex(relationship);

      // 🆕 更新聚合关系数据（用于同步）
      await this.updateAggregatedRelationshipData();
    } catch (error) {
      console.error('缓存关系失败:', error);
    }
  }

  /**
   * 恢复关系数据（新设备同步）- 简化版
   */
  async restoreRelationshipData(relationshipData) {
    this.ensureInitialized();
    try {
      console.log('🔄 恢复关系数据到本地缓存...');

      // 1. 恢复关系数据
      const relationshipMap = new Map();
      const entityRelationsMap = new Map();
      for (const [id, relationship] of relationshipData.relationships) {
        relationshipMap.set(id, relationship);

        // 构建实体-关系映射
        if (!entityRelationsMap.has(relationship.fromId)) {
          entityRelationsMap.set(relationship.fromId, new Set());
        }
        if (!entityRelationsMap.has(relationship.toId)) {
          entityRelationsMap.set(relationship.toId, new Set());
        }
        entityRelationsMap.get(relationship.fromId).add(id);
        entityRelationsMap.get(relationship.toId).add(id);
      }

      // 2. 批量保存关系到存储
      const relationshipStorageData = {};
      for (const [id, relationship] of Array.from(relationshipMap.entries())) {
        relationshipStorageData[`${CACHE_KEYS.RELATIONSHIPS}_${id}`] = relationship;
      }
      await chrome.storage.local.set(relationshipStorageData);

      // 3. 更新内存中的关系
      this.memoryRelationships = relationshipMap;

      // 4. 保存关系索引
      const relationshipIndexData = {
        relationships: Array.from(relationshipMap.entries()),
        entityToRelations: Array.from(entityRelationsMap.entries()).map(_ref => {
          let [key, value] = _ref;
          return [key, Array.from(value)];
        })
      };
      await chrome.storage.local.set({
        [CACHE_KEYS.RELATIONSHIP_INDEX]: relationshipIndexData
      });
      console.log(`✅ 恢复了 ${relationshipMap.size} 个关系到本地缓存`);

      // 🆕 更新聚合关系数据（用于同步）
      await this.updateAggregatedRelationshipData();
    } catch (error) {
      console.error('恢复关系数据失败:', error);
    }
  }

  /**
   * 🆕 获取简化的关系数据备份
   */
  async getSimplifiedRelationshipData() {
    const fullData = await this.getRelationshipBackupData();
    if (!fullData) return null;
    return {
      relationships: fullData.relationships,
      typeToEntities: fullData.typeToEntities
    };
  }

  /**
   * 获取完整的关系数据备份（包含entityToRelations）
   */
  async getRelationshipBackupData() {
    this.ensureInitialized();
    try {
      // 1. 获取关系数据
      const relationships = Array.from(this.memoryRelationships.entries());
      if (relationships.length === 0) {
        return null;
      }

      // 2. 获取类型索引
      const typeIndex = await this.getTypeIndex();
      const typeToEntities = Array.from(Object.entries(typeIndex)).map(_ref2 => {
        let [key, value] = _ref2;
        return [key, Array.from(value)];
      });

      // 3. 获取关系索引（entityToRelations）
      const relationshipIndex = await this.getRelationshipIndex();
      const entityToRelations = Array.from(Object.entries(relationshipIndex));
      return {
        relationships,
        entityToRelations,
        typeToEntities
      };
    } catch (error) {
      console.error('获取关系备份数据失败:', error);
      return null;
    }
  }

  // ==================== 最近数据缓存 ====================

  /**
   * 更新实体的详细数据（统一存储到ENTITIES）
   */
  async updateRecentData(entityId, type, data) {
    this.ensureInitialized();
    try {
      let entityDetail = await this.getEntity(entityId);
      if (!entityDetail) {
        // 如果实体不存在，创建一个基础的 CachedEntityDetail
        entityDetail = {
          id: entityId,
          type: 'Topic',
          // 默认类型，后续可以根据需要调整
          name: entityId,
          document: '',
          properties: {},
          created: Date.now(),
          updated: Date.now(),
          accessCount: 0,
          lastAccessed: Date.now(),
          importance: 0.5,
          statistic: {
            conversations: 0,
            projects: 0,
            participants: 1,
            resources: 0,
            documents: 0,
            webpages: 0,
            relationships: 0,
            topics: 0,
            jiraTickets: 0
          },
          relatedData: {
            conversations: [],
            webpages: [],
            resources: [],
            projects: [],
            people: [],
            topics: [],
            jiraTickets: [],
            cooccurringEntities: []
          },
          cachedAt: Date.now(),
          recentDataDetails: {
            conversations: [],
            webpages: [],
            resources: [],
            projects: [],
            people: [],
            topics: [],
            jiraTickets: [],
            cooccurringEntities: []
          },
          relatedParticipants: [],
          lastUpdated: Date.now()
        };
      }

      // 添加新数据到对应数组的开头（只保留最近5条）
      if (type === 'conversation') {
        entityDetail.recentDataDetails.conversations.unshift(data);
        if (entityDetail.recentDataDetails.conversations.length > 5) {
          entityDetail.recentDataDetails.conversations = entityDetail.recentDataDetails.conversations.slice(0, 5);
        }
      } else if (type === 'resource') {
        entityDetail.recentDataDetails.resources.unshift(data);
        if (entityDetail.recentDataDetails.resources.length > 5) {
          entityDetail.recentDataDetails.resources = entityDetail.recentDataDetails.resources.slice(0, 5);
        }
      } else if (type === 'project') {
        entityDetail.recentDataDetails.projects.unshift(data);
        if (entityDetail.recentDataDetails.projects.length > 5) {
          entityDetail.recentDataDetails.projects = entityDetail.recentDataDetails.projects.slice(0, 5);
        }
      } else {
        // webpage
        entityDetail.recentDataDetails.webpages.unshift(data);
        if (entityDetail.recentDataDetails.webpages.length > 5) {
          entityDetail.recentDataDetails.webpages = entityDetail.recentDataDetails.webpages.slice(0, 5);
        }
      }
      entityDetail.lastUpdated = Date.now();
      entityDetail.updated = Date.now();

      // 重新计算统计字段
      this.recalculateUIFields(entityDetail);

      // 保存更新到统一的ENTITIES存储
      await this.cacheEntity(entityDetail);
    } catch (error) {
      console.error('更新实体详细数据失败:', error);
    }
  }

  /**
   * 🆕 基于本地关系数据批量更新实体的最近数据缓存
   */
  async batchUpdateRecentDataCacheFromRelations(entities) {
    if (!this.config.enableRecentDataSync) {
      return 0;
    }
    let updatedCount = 0;
    const batches = this.chunkArray(entities, this.config.recentDataSyncBatchSize);
    for (const batch of batches) {
      // 并行处理批内实体，但控制并发数量
      const promises = batch.map(entity => this.updateEntityRecentDataFromRelations(entity));
      const results = await Promise.allSettled(promises);

      // 统计成功更新的数量
      for (const result of results) {
        if (result.status === 'fulfilled' && result.value) {
          updatedCount++;
        }
      }

      // 批间延迟，避免过度负载
      if (batches.length > 1) {
        await this.delay(50); // 减少延迟，因为本地查询更快
      }
    }
    return updatedCount;
  }

  /**
   * 🆕 基于本地关系数据更新单个实体的最近数据缓存
   */
  async updateEntityRecentDataFromRelations(entity) {
    try {
      const entityName = entity.name;
      let hasUpdates = false;

      // 🔗 1. 获取实体的关系网络（深度1，只获取直接相关的实体）
      const relationshipNetwork = await this.getRelationshipNetwork(entity.id, 1);
      if (relationshipNetwork.relationships.length === 0) {
        // console.log(`实体 ${entityName} 没有发现关系数据`);
        return false;
      }

      // 📊 2. 按数据来源分类关系
      const relationshipsBySource = {
        conversations: [],
        webpages: [],
        projects: [],
        resources: []
      };
      for (const relationship of relationshipNetwork.relationships) {
        const properties = relationship.properties || {};
        const source = properties.source;
        const discoveredAt = properties.discoveredAt || relationship.created;

        // 构建基础数据对象
        const baseData = {
          id: properties.messageId || properties.webpageId || properties.projectId || relationship.id,
          relationshipId: relationship.id,
          timestamp: discoveredAt,
          relationType: relationship.type,
          strength: relationship.strength
        };

        // 根据数据来源分类
        switch (source) {
          case 'message':
            relationshipsBySource.conversations.push({
              ...baseData,
              content: `通过关系"${relationship.type}"发现的相关消息`,
              summary: `与${this.getRelatedEntityName(relationship, entity.id)}的关系`,
              sender: 'system',
              // 可以后续优化为从原始消息获取
              messageId: properties.messageId
            });
            break;
          case 'webpage':
            relationshipsBySource.webpages.push({
              ...baseData,
              title: `通过关系"${relationship.type}"发现的相关网页`,
              url: properties.url || '',
              summary: `与${this.getRelatedEntityName(relationship, entity.id)}的关系`,
              visitTime: discoveredAt,
              domain: properties.domain || 'unknown'
            });
            break;
          case 'project':
            relationshipsBySource.projects.push({
              ...baseData,
              name: `通过关系"${relationship.type}"发现的相关项目`,
              description: `与${this.getRelatedEntityName(relationship, entity.id)}的关系`,
              status: properties.status || 'active'
            });
            break;
          default:
            // 其他类型归类为资源
            relationshipsBySource.resources.push({
              ...baseData,
              name: `通过关系"${relationship.type}"发现的相关资源`,
              description: `与${this.getRelatedEntityName(relationship, entity.id)}的关系`,
              type: source || 'unknown'
            });
            break;
        }
      }

      // 📝 3. 批量更新最近数据缓存
      const updatePromises = [];

      // 更新conversations
      if (relationshipsBySource.conversations.length > 0) {
        const sortedConversations = relationshipsBySource.conversations.sort((a, b) => b.timestamp - a.timestamp).slice(0, this.config.recentDataQueryLimit);
        for (const conversation of sortedConversations) {
          updatePromises.push(this.updateRecentData(entity.id, 'conversation', conversation));
        }
        hasUpdates = true;
      }

      // 更新webpages
      if (relationshipsBySource.webpages.length > 0) {
        const sortedWebpages = relationshipsBySource.webpages.sort((a, b) => b.timestamp - a.timestamp).slice(0, this.config.recentDataQueryLimit);
        for (const webpage of sortedWebpages) {
          updatePromises.push(this.updateRecentData(entity.id, 'webpage', webpage));
        }
        hasUpdates = true;
      }

      // 更新projects
      if (relationshipsBySource.projects.length > 0) {
        const sortedProjects = relationshipsBySource.projects.sort((a, b) => b.timestamp - a.timestamp).slice(0, this.config.recentDataQueryLimit);
        for (const project of sortedProjects) {
          updatePromises.push(this.updateRecentData(entity.id, 'project', project));
        }
        hasUpdates = true;
      }

      // 更新resources
      if (relationshipsBySource.resources.length > 0) {
        const sortedResources = relationshipsBySource.resources.sort((a, b) => b.timestamp - a.timestamp).slice(0, this.config.recentDataQueryLimit);
        for (const resource of sortedResources) {
          updatePromises.push(this.updateRecentData(entity.id, 'resource', resource));
        }
        hasUpdates = true;
      }

      // 🚀 4. 并行执行所有更新
      if (updatePromises.length > 0) {
        await Promise.allSettled(updatePromises);
        console.log(`📝 基于${relationshipNetwork.relationships.length}个关系更新了实体 ${entityName} 的最近数据缓存`);
      }
      return hasUpdates;
    } catch (error) {
      console.error(`基于关系数据更新实体 ${entity.name} 的最近数据缓存失败:`, error);
      return false;
    }
  }

  /**
   * 🔗 获取关系中相关实体的名称
   */
  getRelatedEntityName(relationship, currentEntityId) {
    const relatedEntityId = relationship.fromId === currentEntityId ? relationship.toId : relationship.fromId;

    // 从实体ID中提取可读名称（简化版）
    const namePart = relatedEntityId.split('_').slice(1).join(' ');
    return namePart || relatedEntityId;
  }

  /**
   * 🆕 更新聚合关系数据到本地存储（用于云端同步）- 简化版
   */
  async updateAggregatedRelationshipData() {
    this.ensureInitialized();
    try {
      // 🆕 获取简化的关系数据
      const backupData = await this.getSimplifiedRelationshipData();
      if (backupData) {
        // 存储简化的关系数据
        await chrome.storage.local.set({
          'cache_graph_relationships': {
            relationships: backupData.relationships,
            typeToEntities: backupData.typeToEntities,
            lastUpdated: Date.now()
            // 🚫 移除冗余的 entityToRelations
          }
        });
        console.log(`📊 更新聚合关系数据: ${backupData.relationships.length} 个关系`);
      }
    } catch (error) {
      console.error('更新聚合关系数据失败:', error);
    }
  }

  // ==================== 主题详情缓存 ====================

  // ==================== 实体格式转换辅助方法 ====================

  /**
   * 确保 CachedEntityDetail 包含所有必要字段
   */
  ensureDetailEntityFields(entity) {
    if (!entity.recentDataDetails) {
      entity.recentDataDetails = {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      };
    }
    if (!entity.relatedParticipants) entity.relatedParticipants = [];
    if (!entity.statistic) {
      entity.statistic = {
        conversations: entity.recentDataDetails.conversations.length,
        projects: entity.recentDataDetails.projects.length,
        participants: entity.relatedParticipants.length,
        resources: entity.recentDataDetails.resources.length,
        documents: entity.recentDataDetails.resources.filter(r => r.type === '文档').length,
        webpages: entity.recentDataDetails.webpages.length,
        relationships: 0,
        topics: entity.recentDataDetails.topics.length,
        jiraTickets: entity.recentDataDetails.jiraTickets.length
      };
    }
    if (!entity.cachedAt) entity.cachedAt = Date.now();
    if (!entity.lastUpdated) entity.lastUpdated = Date.now();
  }

  /**
   * 将 CachedEntityDetail 转换为基础的 MemoryEntity（用于内存存储）
   */
  convertToBaseEntity(detailEntity) {
    return {
      id: detailEntity.id,
      type: detailEntity.type,
      name: detailEntity.name,
      description: detailEntity.description,
      properties: detailEntity.properties,
      created: detailEntity.created,
      updated: detailEntity.updated,
      accessCount: detailEntity.accessCount,
      lastAccessed: detailEntity.lastAccessed,
      importance: detailEntity.importance,
      tags: detailEntity.tags,
      status: detailEntity.status,
      searchDistance: detailEntity.searchDistance,
      relevanceScore: detailEntity.relevanceScore,
      statistic: detailEntity.statistic,
      relatedData: detailEntity.relatedData,
      readStatus: detailEntity.readStatus
    };
  }

  /**
   * 将基础 MemoryEntity 转换为 CachedEntityDetail
   */
  convertToDetailEntity(baseEntity) {
    const detailEntity = {
      ...baseEntity,
      cachedAt: Date.now(),
      recentDataDetails: {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      },
      relatedParticipants: [],
      lastUpdated: Date.now()
    };
    this.ensureDetailEntityFields(detailEntity);
    return detailEntity;
  }

  /**
   * 检查实体是否为 CachedEntityDetail 格式
   */
  isCachedEntityDetail(entity) {
    return 'recentDataDetails' in entity && 'cachedAt' in entity;
  }

  // ==================== 统计信息缓存 ====================

  /**
   * 获取实体统计信息
   */
  async getEntityStatistics() {
    this.ensureInitialized();
    try {
      const result = await chrome.storage.local.get(CACHE_KEYS.STATISTICS);
      const cached = result[CACHE_KEYS.STATISTICS];
      if (cached && Date.now() - cached.cachedAt < this.config.statisticsCacheDuration) {
        return cached.data;
      }

      // 重新计算统计信息
      return await this.calculateStatistics();
    } catch (error) {
      console.error('获取统计信息失败:', error);
      return {
        entityCounts: {},
        totalEntities: 0,
        totalRelationships: 0,
        entitiesCreatedToday: 0,
        entitiesCreatedThisWeek: 0,
        entitiesCreatedThisMonth: 0,
        topEntitiesByType: {}
      };
    }
  }

  // ==================== 缓存管理 ====================

  /**
   * 清理过期缓存
   */
  async clearExpiredCache() {
    this.ensureInitialized();
    try {
      const now = Date.now();
      const allKeys = await this.getAllCacheKeys();
      const keysToRemove = [];
      for (const key of allKeys) {
        if (key.startsWith(CACHE_KEYS.ENTITIES)) {
          const result = await chrome.storage.local.get(key);
          const data = result[key];

          // 只清理有 cachedAt 字段的 CachedEntityDetail 实体（表示有详细缓存数据）
          if (data && data.cachedAt && this.isCachedEntityDetail(data)) {
            const age = now - data.cachedAt;
            const maxAge = this.config.recentDataCacheDuration;
            if (age > maxAge) {
              keysToRemove.push(key);
            }
          }
        }
      }
      if (keysToRemove.length > 0) {
        await chrome.storage.local.remove(keysToRemove);
        console.log(`🧹 清理了 ${keysToRemove.length} 个过期缓存项`);
      }
    } catch (error) {
      console.error('清理过期缓存失败:', error);
    }
  }

  /**
   * 获取缓存大小
   */
  async getCacheSize() {
    try {
      const result = await chrome.storage.local.getBytesInUse();
      return result;
    } catch (error) {
      console.error('获取缓存大小失败:', error);
      return 0;
    }
  }

  // ==================== 私有方法 ====================

  async loadEntitiesToMemory() {
    try {
      const entityIndex = await this.getEntityIndex();
      const entityIds = Object.keys(entityIndex);
      let loadedCount = 0;
      for (const entityId of entityIds) {
        if (loadedCount >= this.config.maxEntitiesInMemory) break;
        const result = await chrome.storage.local.get(`${CACHE_KEYS.ENTITIES}_${entityId}`);
        const entity = result[`${CACHE_KEYS.ENTITIES}_${entityId}`];
        if (entity) {
          this.memoryEntities.set(entityId, entity);
          loadedCount++;
        }
      }
      console.log(`📥 加载了 ${loadedCount} 个实体到内存`);
    } catch (error) {
      console.error('加载实体到内存失败:', error);
    }
  }
  async loadRelationshipsToMemory() {
    try {
      const relationshipIndex = await this.getRelationshipIndex();
      const allRelationshipIds = Object.values(relationshipIndex).flat();
      for (const relationshipId of allRelationshipIds) {
        const result = await chrome.storage.local.get(`${CACHE_KEYS.RELATIONSHIPS}_${relationshipId}`);
        const relationship = result[`${CACHE_KEYS.RELATIONSHIPS}_${relationshipId}`];
        if (relationship) {
          this.memoryRelationships.set(relationshipId, relationship);
        }
      }
      console.log(`📥 加载了 ${this.memoryRelationships.size} 个关系到内存`);
    } catch (error) {
      console.error('加载关系到内存失败:', error);
    }
  }
  async getEntityIndex() {
    try {
      const result = await chrome.storage.local.get(CACHE_KEYS.ENTITY_INDEX);
      return result[CACHE_KEYS.ENTITY_INDEX] || {};
    } catch (error) {
      console.error('获取实体索引失败:', error);
      return {};
    }
  }
  async getTypeIndex() {
    try {
      const result = await chrome.storage.local.get(CACHE_KEYS.TYPE_INDEX);
      return result[CACHE_KEYS.TYPE_INDEX] || {};
    } catch (error) {
      console.error('获取类型索引失败:', error);
      return {};
    }
  }
  async getRelationshipIndex() {
    try {
      const result = await chrome.storage.local.get(CACHE_KEYS.RELATIONSHIP_INDEX);
      return result[CACHE_KEYS.RELATIONSHIP_INDEX] || {};
    } catch (error) {
      console.error('获取关系索引失败:', error);
      return {};
    }
  }
  async updateEntityIndex(entity) {
    try {
      const entityIndex = await this.getEntityIndex();
      const typeIndex = await this.getTypeIndex();

      // 更新实体索引
      entityIndex[entity.id] = {
        type: entity.type,
        name: entity.name,
        lastAccessed: entity.lastAccessed,
        inMemory: this.memoryEntities.has(entity.id)
      };

      // 更新类型索引
      if (!typeIndex[entity.type]) {
        typeIndex[entity.type] = [];
      }
      if (!typeIndex[entity.type].includes(entity.id)) {
        typeIndex[entity.type].push(entity.id);
      }
      await chrome.storage.local.set({
        [CACHE_KEYS.ENTITY_INDEX]: entityIndex,
        [CACHE_KEYS.TYPE_INDEX]: typeIndex
      });
    } catch (error) {
      console.error('更新实体索引失败:', error);
    }
  }
  async updateRelationshipIndex(relationship) {
    try {
      const relationshipIndex = await this.getRelationshipIndex();

      // 为源实体和目标实体添加关系引用
      if (!relationshipIndex[relationship.fromId]) {
        relationshipIndex[relationship.fromId] = [];
      }
      if (!relationshipIndex[relationship.fromId].includes(relationship.id)) {
        relationshipIndex[relationship.fromId].push(relationship.id);
      }
      if (!relationshipIndex[relationship.toId]) {
        relationshipIndex[relationship.toId] = [];
      }
      if (!relationshipIndex[relationship.toId].includes(relationship.id)) {
        relationshipIndex[relationship.toId].push(relationship.id);
      }
      await chrome.storage.local.set({
        [CACHE_KEYS.RELATIONSHIP_INDEX]: relationshipIndex
      });
    } catch (error) {
      console.error('更新关系索引失败:', error);
    }
  }
  findLRUEntity() {
    let lruEntity = null;
    let lruTime = Date.now();
    for (const entity of Array.from(this.memoryEntities.values())) {
      if (entity.lastAccessed < lruTime) {
        lruTime = entity.lastAccessed;
        lruEntity = entity;
      }
    }
    return lruEntity;
  }
  calculateRelevanceScore(entity, searchTerm) {
    let score = 0;
    const searchLower = searchTerm.toLowerCase();

    // 名称匹配（权重最高）
    if (entity.name.toLowerCase().includes(searchLower)) {
      score += 10;
      if (entity.name.toLowerCase().startsWith(searchLower)) {
        score += 5; // 前缀匹配加分
      }
    }

    // 描述匹配
    if (entity.description?.toLowerCase().includes(searchLower)) {
      score += 3;
    }

    // 标签匹配
    entity.tags?.forEach(tag => {
      if (tag.toLowerCase().includes(searchLower)) {
        score += 2;
      }
    });

    // 重要性加权
    score *= entity.importance || 0.5;
    return score;
  }
  async traverseRelationships(entityId, remainingDepth, visited, foundEntities, foundRelationships) {
    if (remainingDepth <= 0 || visited.has(entityId)) return;
    visited.add(entityId);

    // 获取当前实体（可能不存在）
    const entity = await this.getEntity(entityId);
    if (entity) {
      foundEntities.push(entity);
    } else {
      console.warn(`关系遍历中发现缺失实体: ${entityId}`);
    }

    // 获取相关关系
    const relationshipIndex = await this.getRelationshipIndex();
    const relationshipIds = relationshipIndex[entityId] || [];
    for (const relationshipId of relationshipIds) {
      const relationship = this.memoryRelationships.get(relationshipId);
      if (relationship) {
        // 🆕 优化：区分实体-实体关系和实体-消息关系
        const isEntityMessageRelation = relationship.type === 'discovered_in';
        if (isEntityMessageRelation) {
          // 对于实体-消息关系，只验证实体端
          const entitySideId = relationship.fromId === entityId ? relationship.fromId : relationship.toId;
          const messageSideId = relationship.fromId === entityId ? relationship.toId : relationship.fromId;
          if (await this.getEntity(entitySideId)) {
            foundRelationships.push(relationship);
            console.log(`🔗 发现实体-消息关系: ${entitySideId} -> ${messageSideId.slice(0, 8)}`);
          }

          // 实体-消息关系不继续递归遍历
        } else {
          // 对于实体-实体关系，验证两端实体
          const fromEntity = await this.getEntity(relationship.fromId);
          const toEntity = await this.getEntity(relationship.toId);
          if (fromEntity || toEntity) {
            foundRelationships.push(relationship);

            // 递归遍历相关实体
            const relatedEntityId = relationship.fromId === entityId ? relationship.toId : relationship.fromId;
            if (await this.getEntity(relatedEntityId)) {
              await this.traverseRelationships(relatedEntityId, remainingDepth - 1, visited, foundEntities, foundRelationships);
            }
          }
        }
      }
    }
  }
  async calculateStatistics() {
    const now = Date.now();
    const today = new Date().toDateString();
    const thisWeek = now - 7 * 24 * 60 * 60 * 1000;
    const thisMonth = now - 30 * 24 * 60 * 60 * 1000;
    const entityCounts = {};
    let totalEntities = 0;
    let entitiesCreatedToday = 0;
    let entitiesCreatedThisWeek = 0;
    let entitiesCreatedThisMonth = 0;
    const topEntitiesByType = {};

    // 统计内存中的实体
    for (const entity of Array.from(this.memoryEntities.values())) {
      totalEntities++;
      entityCounts[entity.type] = (entityCounts[entity.type] || 0) + 1;

      // 时间统计
      const entityDate = new Date(entity.created).toDateString();
      if (entityDate === today) entitiesCreatedToday++;
      if (entity.created >= thisWeek) entitiesCreatedThisWeek++;
      if (entity.created >= thisMonth) entitiesCreatedThisMonth++;

      // 顶级实体
      if (!topEntitiesByType[entity.type]) {
        topEntitiesByType[entity.type] = [];
      }
      topEntitiesByType[entity.type].push(entity);
    }

    // 对每种类型的实体按重要性排序，取前5个
    for (const type in topEntitiesByType) {
      topEntitiesByType[type] = topEntitiesByType[type].sort((a, b) => b.importance - a.importance).slice(0, 5);
    }
    const statistics = {
      entityCounts,
      totalEntities,
      totalRelationships: this.memoryRelationships.size,
      entitiesCreatedToday,
      entitiesCreatedThisWeek,
      entitiesCreatedThisMonth,
      topEntitiesByType
    };

    // 缓存统计信息
    await chrome.storage.local.set({
      [CACHE_KEYS.STATISTICS]: {
        data: statistics,
        cachedAt: now
      }
    });
    return statistics;
  }
  async getAllCacheKeys() {
    try {
      const allKeys = await chrome.storage.local.get();
      return Object.keys(allKeys).filter(key => key.startsWith('cache_'));
    } catch (error) {
      console.error('获取所有缓存键失败:', error);
      return [];
    }
  }
  startPeriodicCleanup() {
    // 每小时清理一次过期缓存
    setInterval(() => {
      this.clearExpiredCache();
    }, 60 * 60 * 1000);
  }
  chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }
  async delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * 创建空的扩展缓存对象
   */
  createEmptyExtendedCache(_entityId) {
    return {
      lastUpdated: Date.now(),
      cachedAt: Date.now(),
      // 关联数据字段
      relatedData: {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      },
      recentDataDetails: {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      },
      expertise: [],
      // 统计字段
      statistic: {
        conversations: 0,
        projects: 0,
        participants: 0,
        resources: 0,
        documents: 0,
        webpages: 0,
        relationships: 0,
        topics: 0,
        jiraTickets: 0
      }
    };
  }

  /**
   * 确保缓存数据包含所有必要的UI字段
   */
  ensureUIFields(cache) {
    // 如果缺少UI字段，重新计算
    if (!cache.statistic || !cache.recentDataDetails) {
      this.recalculateUIFields(cache);
    }
  }

  /**
   * 重新计算UI字段
   */
  recalculateUIFields(cache) {
    // 确保缓存字段存在（使用正确的字段名）
    if (!cache.recentDataDetails) {
      cache.recentDataDetails = {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      };
    }

    // 更新统计字段到 statistic 对象中
    if (!cache.statistic) {
      cache.statistic = {
        conversations: 0,
        projects: 0,
        participants: 0,
        resources: 0,
        documents: 0,
        webpages: 0,
        relationships: 0,
        topics: 0,
        jiraTickets: 0
      };
    }

    // 重新计算统计字段
    cache.statistic.conversations = cache.recentDataDetails.conversations.length;
    cache.statistic.webpages = cache.recentDataDetails.webpages.length;
    cache.statistic.resources = cache.recentDataDetails.resources.length;
    cache.statistic.projects = cache.recentDataDetails.projects.length;
    cache.statistic.topics = cache.recentDataDetails.topics.length;
    cache.statistic.jiraTickets = cache.recentDataDetails.jiraTickets.length;

    // 确保必要字段存在
    if (!cache.expertise) cache.expertise = [];
    if (!cache.lastUpdated) cache.lastUpdated = Date.now();
  }

  /**
   * 获取所有本地缓存的实体数据（用于统计信息上传）
   */
  async getAllRecentDataEntries() {
    this.ensureInitialized();
    try {
      const entityEntries = [];

      // 获取所有键，然后过滤出 ENTITIES 相关的键
      const allKeys = await this.getAllCacheKeys();
      for (const key of allKeys) {
        if (key.startsWith(CACHE_KEYS.ENTITIES + '_')) {
          try {
            const result = await chrome.storage.local.get(key);
            const data = result[key];
            if (data && this.isCachedEntityDetail(data)) {
              // 检查数据是否过期
              const now = Date.now();
              if (data.cachedAt && now - data.cachedAt < this.config.recentDataCacheDuration) {
                entityEntries.push(data);
              }
            }
          } catch (error) {
            console.error(`解析缓存数据失败 (${key}):`, error);
          }
        }
      }
      console.log(`📊 找到 ${entityEntries.length} 个本地缓存实体`);
      return entityEntries;
    } catch (error) {
      console.error('获取所有本地缓存数据失败:', error);
      return [];
    }
  }
  ensureInitialized() {
    if (!this.isInitialized) {
      throw new Error('本地缓存未初始化');
    }
  }
}

/***/ }),

/***/ 7526:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports.byteLength = byteLength
exports.toByteArray = toByteArray
exports.fromByteArray = fromByteArray

var lookup = []
var revLookup = []
var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array

var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
for (var i = 0, len = code.length; i < len; ++i) {
  lookup[i] = code[i]
  revLookup[code.charCodeAt(i)] = i
}

// Support decoding URL-safe base64 strings, as Node.js does.
// See: https://en.wikipedia.org/wiki/Base64#URL_applications
revLookup['-'.charCodeAt(0)] = 62
revLookup['_'.charCodeAt(0)] = 63

function getLens (b64) {
  var len = b64.length

  if (len % 4 > 0) {
    throw new Error('Invalid string. Length must be a multiple of 4')
  }

  // Trim off extra bytes after placeholder bytes are found
  // See: https://github.com/beatgammit/base64-js/issues/42
  var validLen = b64.indexOf('=')
  if (validLen === -1) validLen = len

  var placeHoldersLen = validLen === len
    ? 0
    : 4 - (validLen % 4)

  return [validLen, placeHoldersLen]
}

// base64 is 4/3 + up to two characters of the original data
function byteLength (b64) {
  var lens = getLens(b64)
  var validLen = lens[0]
  var placeHoldersLen = lens[1]
  return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
}

function _byteLength (b64, validLen, placeHoldersLen) {
  return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
}

function toByteArray (b64) {
  var tmp
  var lens = getLens(b64)
  var validLen = lens[0]
  var placeHoldersLen = lens[1]

  var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen))

  var curByte = 0

  // if there are placeholders, only get up to the last complete 4 chars
  var len = placeHoldersLen > 0
    ? validLen - 4
    : validLen

  var i
  for (i = 0; i < len; i += 4) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 18) |
      (revLookup[b64.charCodeAt(i + 1)] << 12) |
      (revLookup[b64.charCodeAt(i + 2)] << 6) |
      revLookup[b64.charCodeAt(i + 3)]
    arr[curByte++] = (tmp >> 16) & 0xFF
    arr[curByte++] = (tmp >> 8) & 0xFF
    arr[curByte++] = tmp & 0xFF
  }

  if (placeHoldersLen === 2) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 2) |
      (revLookup[b64.charCodeAt(i + 1)] >> 4)
    arr[curByte++] = tmp & 0xFF
  }

  if (placeHoldersLen === 1) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 10) |
      (revLookup[b64.charCodeAt(i + 1)] << 4) |
      (revLookup[b64.charCodeAt(i + 2)] >> 2)
    arr[curByte++] = (tmp >> 8) & 0xFF
    arr[curByte++] = tmp & 0xFF
  }

  return arr
}

function tripletToBase64 (num) {
  return lookup[num >> 18 & 0x3F] +
    lookup[num >> 12 & 0x3F] +
    lookup[num >> 6 & 0x3F] +
    lookup[num & 0x3F]
}

function encodeChunk (uint8, start, end) {
  var tmp
  var output = []
  for (var i = start; i < end; i += 3) {
    tmp =
      ((uint8[i] << 16) & 0xFF0000) +
      ((uint8[i + 1] << 8) & 0xFF00) +
      (uint8[i + 2] & 0xFF)
    output.push(tripletToBase64(tmp))
  }
  return output.join('')
}

function fromByteArray (uint8) {
  var tmp
  var len = uint8.length
  var extraBytes = len % 3 // if we have 1 byte left, pad 2 bytes
  var parts = []
  var maxChunkLength = 16383 // must be multiple of 3

  // go through the array every three bytes, we'll deal with trailing stuff later
  for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
    parts.push(encodeChunk(uint8, i, (i + maxChunkLength) > len2 ? len2 : (i + maxChunkLength)))
  }

  // pad the end with zeros, but make sure to not forget the extra bytes
  if (extraBytes === 1) {
    tmp = uint8[len - 1]
    parts.push(
      lookup[tmp >> 2] +
      lookup[(tmp << 4) & 0x3F] +
      '=='
    )
  } else if (extraBytes === 2) {
    tmp = (uint8[len - 2] << 8) + uint8[len - 1]
    parts.push(
      lookup[tmp >> 10] +
      lookup[(tmp >> 4) & 0x3F] +
      lookup[(tmp << 2) & 0x3F] +
      '='
    )
  }

  return parts.join('')
}


/***/ }),

/***/ 8287:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
var __webpack_unused_export__;
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */
/* eslint-disable no-proto */



const base64 = __webpack_require__(7526)
const ieee754 = __webpack_require__(251)
const customInspectSymbol =
  (typeof Symbol === 'function' && typeof Symbol['for'] === 'function') // eslint-disable-line dot-notation
    ? Symbol['for']('nodejs.util.inspect.custom') // eslint-disable-line dot-notation
    : null

exports.hp = Buffer
__webpack_unused_export__ = SlowBuffer
exports.IS = 50

const K_MAX_LENGTH = 0x7fffffff
__webpack_unused_export__ = K_MAX_LENGTH

/**
 * If `Buffer.TYPED_ARRAY_SUPPORT`:
 *   === true    Use Uint8Array implementation (fastest)
 *   === false   Print warning and recommend using `buffer` v4.x which has an Object
 *               implementation (most compatible, even IE6)
 *
 * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
 * Opera 11.6+, iOS 4.2+.
 *
 * We report that the browser does not support typed arrays if the are not subclassable
 * using __proto__. Firefox 4-29 lacks support for adding new properties to `Uint8Array`
 * (See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438). IE 10 lacks support
 * for __proto__ and has a buggy typed array implementation.
 */
Buffer.TYPED_ARRAY_SUPPORT = typedArraySupport()

if (!Buffer.TYPED_ARRAY_SUPPORT && typeof console !== 'undefined' &&
    typeof console.error === 'function') {
  console.error(
    'This browser lacks typed array (Uint8Array) support which is required by ' +
    '`buffer` v5.x. Use `buffer` v4.x if you require old browser support.'
  )
}

function typedArraySupport () {
  // Can typed array instances can be augmented?
  try {
    const arr = new Uint8Array(1)
    const proto = { foo: function () { return 42 } }
    Object.setPrototypeOf(proto, Uint8Array.prototype)
    Object.setPrototypeOf(arr, proto)
    return arr.foo() === 42
  } catch (e) {
    return false
  }
}

Object.defineProperty(Buffer.prototype, 'parent', {
  enumerable: true,
  get: function () {
    if (!Buffer.isBuffer(this)) return undefined
    return this.buffer
  }
})

Object.defineProperty(Buffer.prototype, 'offset', {
  enumerable: true,
  get: function () {
    if (!Buffer.isBuffer(this)) return undefined
    return this.byteOffset
  }
})

function createBuffer (length) {
  if (length > K_MAX_LENGTH) {
    throw new RangeError('The value "' + length + '" is invalid for option "size"')
  }
  // Return an augmented `Uint8Array` instance
  const buf = new Uint8Array(length)
  Object.setPrototypeOf(buf, Buffer.prototype)
  return buf
}

/**
 * The Buffer constructor returns instances of `Uint8Array` that have their
 * prototype changed to `Buffer.prototype`. Furthermore, `Buffer` is a subclass of
 * `Uint8Array`, so the returned instances will have all the node `Buffer` methods
 * and the `Uint8Array` methods. Square bracket notation works as expected -- it
 * returns a single octet.
 *
 * The `Uint8Array` prototype remains unmodified.
 */

function Buffer (arg, encodingOrOffset, length) {
  // Common case.
  if (typeof arg === 'number') {
    if (typeof encodingOrOffset === 'string') {
      throw new TypeError(
        'The "string" argument must be of type string. Received type number'
      )
    }
    return allocUnsafe(arg)
  }
  return from(arg, encodingOrOffset, length)
}

Buffer.poolSize = 8192 // not used by this implementation

function from (value, encodingOrOffset, length) {
  if (typeof value === 'string') {
    return fromString(value, encodingOrOffset)
  }

  if (ArrayBuffer.isView(value)) {
    return fromArrayView(value)
  }

  if (value == null) {
    throw new TypeError(
      'The first argument must be one of type string, Buffer, ArrayBuffer, Array, ' +
      'or Array-like Object. Received type ' + (typeof value)
    )
  }

  if (isInstance(value, ArrayBuffer) ||
      (value && isInstance(value.buffer, ArrayBuffer))) {
    return fromArrayBuffer(value, encodingOrOffset, length)
  }

  if (typeof SharedArrayBuffer !== 'undefined' &&
      (isInstance(value, SharedArrayBuffer) ||
      (value && isInstance(value.buffer, SharedArrayBuffer)))) {
    return fromArrayBuffer(value, encodingOrOffset, length)
  }

  if (typeof value === 'number') {
    throw new TypeError(
      'The "value" argument must not be of type number. Received type number'
    )
  }

  const valueOf = value.valueOf && value.valueOf()
  if (valueOf != null && valueOf !== value) {
    return Buffer.from(valueOf, encodingOrOffset, length)
  }

  const b = fromObject(value)
  if (b) return b

  if (typeof Symbol !== 'undefined' && Symbol.toPrimitive != null &&
      typeof value[Symbol.toPrimitive] === 'function') {
    return Buffer.from(value[Symbol.toPrimitive]('string'), encodingOrOffset, length)
  }

  throw new TypeError(
    'The first argument must be one of type string, Buffer, ArrayBuffer, Array, ' +
    'or Array-like Object. Received type ' + (typeof value)
  )
}

/**
 * Functionally equivalent to Buffer(arg, encoding) but throws a TypeError
 * if value is a number.
 * Buffer.from(str[, encoding])
 * Buffer.from(array)
 * Buffer.from(buffer)
 * Buffer.from(arrayBuffer[, byteOffset[, length]])
 **/
Buffer.from = function (value, encodingOrOffset, length) {
  return from(value, encodingOrOffset, length)
}

// Note: Change prototype *after* Buffer.from is defined to workaround Chrome bug:
// https://github.com/feross/buffer/pull/148
Object.setPrototypeOf(Buffer.prototype, Uint8Array.prototype)
Object.setPrototypeOf(Buffer, Uint8Array)

function assertSize (size) {
  if (typeof size !== 'number') {
    throw new TypeError('"size" argument must be of type number')
  } else if (size < 0) {
    throw new RangeError('The value "' + size + '" is invalid for option "size"')
  }
}

function alloc (size, fill, encoding) {
  assertSize(size)
  if (size <= 0) {
    return createBuffer(size)
  }
  if (fill !== undefined) {
    // Only pay attention to encoding if it's a string. This
    // prevents accidentally sending in a number that would
    // be interpreted as a start offset.
    return typeof encoding === 'string'
      ? createBuffer(size).fill(fill, encoding)
      : createBuffer(size).fill(fill)
  }
  return createBuffer(size)
}

/**
 * Creates a new filled Buffer instance.
 * alloc(size[, fill[, encoding]])
 **/
Buffer.alloc = function (size, fill, encoding) {
  return alloc(size, fill, encoding)
}

function allocUnsafe (size) {
  assertSize(size)
  return createBuffer(size < 0 ? 0 : checked(size) | 0)
}

/**
 * Equivalent to Buffer(num), by default creates a non-zero-filled Buffer instance.
 * */
Buffer.allocUnsafe = function (size) {
  return allocUnsafe(size)
}
/**
 * Equivalent to SlowBuffer(num), by default creates a non-zero-filled Buffer instance.
 */
Buffer.allocUnsafeSlow = function (size) {
  return allocUnsafe(size)
}

function fromString (string, encoding) {
  if (typeof encoding !== 'string' || encoding === '') {
    encoding = 'utf8'
  }

  if (!Buffer.isEncoding(encoding)) {
    throw new TypeError('Unknown encoding: ' + encoding)
  }

  const length = byteLength(string, encoding) | 0
  let buf = createBuffer(length)

  const actual = buf.write(string, encoding)

  if (actual !== length) {
    // Writing a hex string, for example, that contains invalid characters will
    // cause everything after the first invalid character to be ignored. (e.g.
    // 'abxxcd' will be treated as 'ab')
    buf = buf.slice(0, actual)
  }

  return buf
}

function fromArrayLike (array) {
  const length = array.length < 0 ? 0 : checked(array.length) | 0
  const buf = createBuffer(length)
  for (let i = 0; i < length; i += 1) {
    buf[i] = array[i] & 255
  }
  return buf
}

function fromArrayView (arrayView) {
  if (isInstance(arrayView, Uint8Array)) {
    const copy = new Uint8Array(arrayView)
    return fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength)
  }
  return fromArrayLike(arrayView)
}

function fromArrayBuffer (array, byteOffset, length) {
  if (byteOffset < 0 || array.byteLength < byteOffset) {
    throw new RangeError('"offset" is outside of buffer bounds')
  }

  if (array.byteLength < byteOffset + (length || 0)) {
    throw new RangeError('"length" is outside of buffer bounds')
  }

  let buf
  if (byteOffset === undefined && length === undefined) {
    buf = new Uint8Array(array)
  } else if (length === undefined) {
    buf = new Uint8Array(array, byteOffset)
  } else {
    buf = new Uint8Array(array, byteOffset, length)
  }

  // Return an augmented `Uint8Array` instance
  Object.setPrototypeOf(buf, Buffer.prototype)

  return buf
}

function fromObject (obj) {
  if (Buffer.isBuffer(obj)) {
    const len = checked(obj.length) | 0
    const buf = createBuffer(len)

    if (buf.length === 0) {
      return buf
    }

    obj.copy(buf, 0, 0, len)
    return buf
  }

  if (obj.length !== undefined) {
    if (typeof obj.length !== 'number' || numberIsNaN(obj.length)) {
      return createBuffer(0)
    }
    return fromArrayLike(obj)
  }

  if (obj.type === 'Buffer' && Array.isArray(obj.data)) {
    return fromArrayLike(obj.data)
  }
}

function checked (length) {
  // Note: cannot use `length < K_MAX_LENGTH` here because that fails when
  // length is NaN (which is otherwise coerced to zero.)
  if (length >= K_MAX_LENGTH) {
    throw new RangeError('Attempt to allocate Buffer larger than maximum ' +
                         'size: 0x' + K_MAX_LENGTH.toString(16) + ' bytes')
  }
  return length | 0
}

function SlowBuffer (length) {
  if (+length != length) { // eslint-disable-line eqeqeq
    length = 0
  }
  return Buffer.alloc(+length)
}

Buffer.isBuffer = function isBuffer (b) {
  return b != null && b._isBuffer === true &&
    b !== Buffer.prototype // so Buffer.isBuffer(Buffer.prototype) will be false
}

Buffer.compare = function compare (a, b) {
  if (isInstance(a, Uint8Array)) a = Buffer.from(a, a.offset, a.byteLength)
  if (isInstance(b, Uint8Array)) b = Buffer.from(b, b.offset, b.byteLength)
  if (!Buffer.isBuffer(a) || !Buffer.isBuffer(b)) {
    throw new TypeError(
      'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
    )
  }

  if (a === b) return 0

  let x = a.length
  let y = b.length

  for (let i = 0, len = Math.min(x, y); i < len; ++i) {
    if (a[i] !== b[i]) {
      x = a[i]
      y = b[i]
      break
    }
  }

  if (x < y) return -1
  if (y < x) return 1
  return 0
}

Buffer.isEncoding = function isEncoding (encoding) {
  switch (String(encoding).toLowerCase()) {
    case 'hex':
    case 'utf8':
    case 'utf-8':
    case 'ascii':
    case 'latin1':
    case 'binary':
    case 'base64':
    case 'ucs2':
    case 'ucs-2':
    case 'utf16le':
    case 'utf-16le':
      return true
    default:
      return false
  }
}

Buffer.concat = function concat (list, length) {
  if (!Array.isArray(list)) {
    throw new TypeError('"list" argument must be an Array of Buffers')
  }

  if (list.length === 0) {
    return Buffer.alloc(0)
  }

  let i
  if (length === undefined) {
    length = 0
    for (i = 0; i < list.length; ++i) {
      length += list[i].length
    }
  }

  const buffer = Buffer.allocUnsafe(length)
  let pos = 0
  for (i = 0; i < list.length; ++i) {
    let buf = list[i]
    if (isInstance(buf, Uint8Array)) {
      if (pos + buf.length > buffer.length) {
        if (!Buffer.isBuffer(buf)) buf = Buffer.from(buf)
        buf.copy(buffer, pos)
      } else {
        Uint8Array.prototype.set.call(
          buffer,
          buf,
          pos
        )
      }
    } else if (!Buffer.isBuffer(buf)) {
      throw new TypeError('"list" argument must be an Array of Buffers')
    } else {
      buf.copy(buffer, pos)
    }
    pos += buf.length
  }
  return buffer
}

function byteLength (string, encoding) {
  if (Buffer.isBuffer(string)) {
    return string.length
  }
  if (ArrayBuffer.isView(string) || isInstance(string, ArrayBuffer)) {
    return string.byteLength
  }
  if (typeof string !== 'string') {
    throw new TypeError(
      'The "string" argument must be one of type string, Buffer, or ArrayBuffer. ' +
      'Received type ' + typeof string
    )
  }

  const len = string.length
  const mustMatch = (arguments.length > 2 && arguments[2] === true)
  if (!mustMatch && len === 0) return 0

  // Use a for loop to avoid recursion
  let loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'ascii':
      case 'latin1':
      case 'binary':
        return len
      case 'utf8':
      case 'utf-8':
        return utf8ToBytes(string).length
      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return len * 2
      case 'hex':
        return len >>> 1
      case 'base64':
        return base64ToBytes(string).length
      default:
        if (loweredCase) {
          return mustMatch ? -1 : utf8ToBytes(string).length // assume utf8
        }
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}
Buffer.byteLength = byteLength

function slowToString (encoding, start, end) {
  let loweredCase = false

  // No need to verify that "this.length <= MAX_UINT32" since it's a read-only
  // property of a typed array.

  // This behaves neither like String nor Uint8Array in that we set start/end
  // to their upper/lower bounds if the value passed is out of range.
  // undefined is handled specially as per ECMA-262 6th Edition,
  // Section 13.3.3.7 Runtime Semantics: KeyedBindingInitialization.
  if (start === undefined || start < 0) {
    start = 0
  }
  // Return early if start > this.length. Done here to prevent potential uint32
  // coercion fail below.
  if (start > this.length) {
    return ''
  }

  if (end === undefined || end > this.length) {
    end = this.length
  }

  if (end <= 0) {
    return ''
  }

  // Force coercion to uint32. This will also coerce falsey/NaN values to 0.
  end >>>= 0
  start >>>= 0

  if (end <= start) {
    return ''
  }

  if (!encoding) encoding = 'utf8'

  while (true) {
    switch (encoding) {
      case 'hex':
        return hexSlice(this, start, end)

      case 'utf8':
      case 'utf-8':
        return utf8Slice(this, start, end)

      case 'ascii':
        return asciiSlice(this, start, end)

      case 'latin1':
      case 'binary':
        return latin1Slice(this, start, end)

      case 'base64':
        return base64Slice(this, start, end)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return utf16leSlice(this, start, end)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = (encoding + '').toLowerCase()
        loweredCase = true
    }
  }
}

// This property is used by `Buffer.isBuffer` (and the `is-buffer` npm package)
// to detect a Buffer instance. It's not possible to use `instanceof Buffer`
// reliably in a browserify context because there could be multiple different
// copies of the 'buffer' package in use. This method works even for Buffer
// instances that were created from another copy of the `buffer` package.
// See: https://github.com/feross/buffer/issues/154
Buffer.prototype._isBuffer = true

function swap (b, n, m) {
  const i = b[n]
  b[n] = b[m]
  b[m] = i
}

Buffer.prototype.swap16 = function swap16 () {
  const len = this.length
  if (len % 2 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 16-bits')
  }
  for (let i = 0; i < len; i += 2) {
    swap(this, i, i + 1)
  }
  return this
}

Buffer.prototype.swap32 = function swap32 () {
  const len = this.length
  if (len % 4 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 32-bits')
  }
  for (let i = 0; i < len; i += 4) {
    swap(this, i, i + 3)
    swap(this, i + 1, i + 2)
  }
  return this
}

Buffer.prototype.swap64 = function swap64 () {
  const len = this.length
  if (len % 8 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 64-bits')
  }
  for (let i = 0; i < len; i += 8) {
    swap(this, i, i + 7)
    swap(this, i + 1, i + 6)
    swap(this, i + 2, i + 5)
    swap(this, i + 3, i + 4)
  }
  return this
}

Buffer.prototype.toString = function toString () {
  const length = this.length
  if (length === 0) return ''
  if (arguments.length === 0) return utf8Slice(this, 0, length)
  return slowToString.apply(this, arguments)
}

Buffer.prototype.toLocaleString = Buffer.prototype.toString

Buffer.prototype.equals = function equals (b) {
  if (!Buffer.isBuffer(b)) throw new TypeError('Argument must be a Buffer')
  if (this === b) return true
  return Buffer.compare(this, b) === 0
}

Buffer.prototype.inspect = function inspect () {
  let str = ''
  const max = exports.IS
  str = this.toString('hex', 0, max).replace(/(.{2})/g, '$1 ').trim()
  if (this.length > max) str += ' ... '
  return '<Buffer ' + str + '>'
}
if (customInspectSymbol) {
  Buffer.prototype[customInspectSymbol] = Buffer.prototype.inspect
}

Buffer.prototype.compare = function compare (target, start, end, thisStart, thisEnd) {
  if (isInstance(target, Uint8Array)) {
    target = Buffer.from(target, target.offset, target.byteLength)
  }
  if (!Buffer.isBuffer(target)) {
    throw new TypeError(
      'The "target" argument must be one of type Buffer or Uint8Array. ' +
      'Received type ' + (typeof target)
    )
  }

  if (start === undefined) {
    start = 0
  }
  if (end === undefined) {
    end = target ? target.length : 0
  }
  if (thisStart === undefined) {
    thisStart = 0
  }
  if (thisEnd === undefined) {
    thisEnd = this.length
  }

  if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
    throw new RangeError('out of range index')
  }

  if (thisStart >= thisEnd && start >= end) {
    return 0
  }
  if (thisStart >= thisEnd) {
    return -1
  }
  if (start >= end) {
    return 1
  }

  start >>>= 0
  end >>>= 0
  thisStart >>>= 0
  thisEnd >>>= 0

  if (this === target) return 0

  let x = thisEnd - thisStart
  let y = end - start
  const len = Math.min(x, y)

  const thisCopy = this.slice(thisStart, thisEnd)
  const targetCopy = target.slice(start, end)

  for (let i = 0; i < len; ++i) {
    if (thisCopy[i] !== targetCopy[i]) {
      x = thisCopy[i]
      y = targetCopy[i]
      break
    }
  }

  if (x < y) return -1
  if (y < x) return 1
  return 0
}

// Finds either the first index of `val` in `buffer` at offset >= `byteOffset`,
// OR the last index of `val` in `buffer` at offset <= `byteOffset`.
//
// Arguments:
// - buffer - a Buffer to search
// - val - a string, Buffer, or number
// - byteOffset - an index into `buffer`; will be clamped to an int32
// - encoding - an optional encoding, relevant is val is a string
// - dir - true for indexOf, false for lastIndexOf
function bidirectionalIndexOf (buffer, val, byteOffset, encoding, dir) {
  // Empty buffer means no match
  if (buffer.length === 0) return -1

  // Normalize byteOffset
  if (typeof byteOffset === 'string') {
    encoding = byteOffset
    byteOffset = 0
  } else if (byteOffset > 0x7fffffff) {
    byteOffset = 0x7fffffff
  } else if (byteOffset < -0x80000000) {
    byteOffset = -0x80000000
  }
  byteOffset = +byteOffset // Coerce to Number.
  if (numberIsNaN(byteOffset)) {
    // byteOffset: it it's undefined, null, NaN, "foo", etc, search whole buffer
    byteOffset = dir ? 0 : (buffer.length - 1)
  }

  // Normalize byteOffset: negative offsets start from the end of the buffer
  if (byteOffset < 0) byteOffset = buffer.length + byteOffset
  if (byteOffset >= buffer.length) {
    if (dir) return -1
    else byteOffset = buffer.length - 1
  } else if (byteOffset < 0) {
    if (dir) byteOffset = 0
    else return -1
  }

  // Normalize val
  if (typeof val === 'string') {
    val = Buffer.from(val, encoding)
  }

  // Finally, search either indexOf (if dir is true) or lastIndexOf
  if (Buffer.isBuffer(val)) {
    // Special case: looking for empty string/buffer always fails
    if (val.length === 0) {
      return -1
    }
    return arrayIndexOf(buffer, val, byteOffset, encoding, dir)
  } else if (typeof val === 'number') {
    val = val & 0xFF // Search for a byte value [0-255]
    if (typeof Uint8Array.prototype.indexOf === 'function') {
      if (dir) {
        return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset)
      } else {
        return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset)
      }
    }
    return arrayIndexOf(buffer, [val], byteOffset, encoding, dir)
  }

  throw new TypeError('val must be string, number or Buffer')
}

function arrayIndexOf (arr, val, byteOffset, encoding, dir) {
  let indexSize = 1
  let arrLength = arr.length
  let valLength = val.length

  if (encoding !== undefined) {
    encoding = String(encoding).toLowerCase()
    if (encoding === 'ucs2' || encoding === 'ucs-2' ||
        encoding === 'utf16le' || encoding === 'utf-16le') {
      if (arr.length < 2 || val.length < 2) {
        return -1
      }
      indexSize = 2
      arrLength /= 2
      valLength /= 2
      byteOffset /= 2
    }
  }

  function read (buf, i) {
    if (indexSize === 1) {
      return buf[i]
    } else {
      return buf.readUInt16BE(i * indexSize)
    }
  }

  let i
  if (dir) {
    let foundIndex = -1
    for (i = byteOffset; i < arrLength; i++) {
      if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
        if (foundIndex === -1) foundIndex = i
        if (i - foundIndex + 1 === valLength) return foundIndex * indexSize
      } else {
        if (foundIndex !== -1) i -= i - foundIndex
        foundIndex = -1
      }
    }
  } else {
    if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength
    for (i = byteOffset; i >= 0; i--) {
      let found = true
      for (let j = 0; j < valLength; j++) {
        if (read(arr, i + j) !== read(val, j)) {
          found = false
          break
        }
      }
      if (found) return i
    }
  }

  return -1
}

Buffer.prototype.includes = function includes (val, byteOffset, encoding) {
  return this.indexOf(val, byteOffset, encoding) !== -1
}

Buffer.prototype.indexOf = function indexOf (val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, true)
}

Buffer.prototype.lastIndexOf = function lastIndexOf (val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, false)
}

function hexWrite (buf, string, offset, length) {
  offset = Number(offset) || 0
  const remaining = buf.length - offset
  if (!length) {
    length = remaining
  } else {
    length = Number(length)
    if (length > remaining) {
      length = remaining
    }
  }

  const strLen = string.length

  if (length > strLen / 2) {
    length = strLen / 2
  }
  let i
  for (i = 0; i < length; ++i) {
    const parsed = parseInt(string.substr(i * 2, 2), 16)
    if (numberIsNaN(parsed)) return i
    buf[offset + i] = parsed
  }
  return i
}

function utf8Write (buf, string, offset, length) {
  return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length)
}

function asciiWrite (buf, string, offset, length) {
  return blitBuffer(asciiToBytes(string), buf, offset, length)
}

function base64Write (buf, string, offset, length) {
  return blitBuffer(base64ToBytes(string), buf, offset, length)
}

function ucs2Write (buf, string, offset, length) {
  return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length)
}

Buffer.prototype.write = function write (string, offset, length, encoding) {
  // Buffer#write(string)
  if (offset === undefined) {
    encoding = 'utf8'
    length = this.length
    offset = 0
  // Buffer#write(string, encoding)
  } else if (length === undefined && typeof offset === 'string') {
    encoding = offset
    length = this.length
    offset = 0
  // Buffer#write(string, offset[, length][, encoding])
  } else if (isFinite(offset)) {
    offset = offset >>> 0
    if (isFinite(length)) {
      length = length >>> 0
      if (encoding === undefined) encoding = 'utf8'
    } else {
      encoding = length
      length = undefined
    }
  } else {
    throw new Error(
      'Buffer.write(string, encoding, offset[, length]) is no longer supported'
    )
  }

  const remaining = this.length - offset
  if (length === undefined || length > remaining) length = remaining

  if ((string.length > 0 && (length < 0 || offset < 0)) || offset > this.length) {
    throw new RangeError('Attempt to write outside buffer bounds')
  }

  if (!encoding) encoding = 'utf8'

  let loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'hex':
        return hexWrite(this, string, offset, length)

      case 'utf8':
      case 'utf-8':
        return utf8Write(this, string, offset, length)

      case 'ascii':
      case 'latin1':
      case 'binary':
        return asciiWrite(this, string, offset, length)

      case 'base64':
        // Warning: maxLength not taken into account in base64Write
        return base64Write(this, string, offset, length)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return ucs2Write(this, string, offset, length)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}

Buffer.prototype.toJSON = function toJSON () {
  return {
    type: 'Buffer',
    data: Array.prototype.slice.call(this._arr || this, 0)
  }
}

function base64Slice (buf, start, end) {
  if (start === 0 && end === buf.length) {
    return base64.fromByteArray(buf)
  } else {
    return base64.fromByteArray(buf.slice(start, end))
  }
}

function utf8Slice (buf, start, end) {
  end = Math.min(buf.length, end)
  const res = []

  let i = start
  while (i < end) {
    const firstByte = buf[i]
    let codePoint = null
    let bytesPerSequence = (firstByte > 0xEF)
      ? 4
      : (firstByte > 0xDF)
          ? 3
          : (firstByte > 0xBF)
              ? 2
              : 1

    if (i + bytesPerSequence <= end) {
      let secondByte, thirdByte, fourthByte, tempCodePoint

      switch (bytesPerSequence) {
        case 1:
          if (firstByte < 0x80) {
            codePoint = firstByte
          }
          break
        case 2:
          secondByte = buf[i + 1]
          if ((secondByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0x1F) << 0x6 | (secondByte & 0x3F)
            if (tempCodePoint > 0x7F) {
              codePoint = tempCodePoint
            }
          }
          break
        case 3:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | (thirdByte & 0x3F)
            if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) {
              codePoint = tempCodePoint
            }
          }
          break
        case 4:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          fourthByte = buf[i + 3]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | (fourthByte & 0x3F)
            if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) {
              codePoint = tempCodePoint
            }
          }
      }
    }

    if (codePoint === null) {
      // we did not generate a valid codePoint so insert a
      // replacement char (U+FFFD) and advance only 1 byte
      codePoint = 0xFFFD
      bytesPerSequence = 1
    } else if (codePoint > 0xFFFF) {
      // encode to utf16 (surrogate pair dance)
      codePoint -= 0x10000
      res.push(codePoint >>> 10 & 0x3FF | 0xD800)
      codePoint = 0xDC00 | codePoint & 0x3FF
    }

    res.push(codePoint)
    i += bytesPerSequence
  }

  return decodeCodePointsArray(res)
}

// Based on http://stackoverflow.com/a/22747272/680742, the browser with
// the lowest limit is Chrome, with 0x10000 args.
// We go 1 magnitude less, for safety
const MAX_ARGUMENTS_LENGTH = 0x1000

function decodeCodePointsArray (codePoints) {
  const len = codePoints.length
  if (len <= MAX_ARGUMENTS_LENGTH) {
    return String.fromCharCode.apply(String, codePoints) // avoid extra slice()
  }

  // Decode in chunks to avoid "call stack size exceeded".
  let res = ''
  let i = 0
  while (i < len) {
    res += String.fromCharCode.apply(
      String,
      codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
    )
  }
  return res
}

function asciiSlice (buf, start, end) {
  let ret = ''
  end = Math.min(buf.length, end)

  for (let i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i] & 0x7F)
  }
  return ret
}

function latin1Slice (buf, start, end) {
  let ret = ''
  end = Math.min(buf.length, end)

  for (let i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i])
  }
  return ret
}

function hexSlice (buf, start, end) {
  const len = buf.length

  if (!start || start < 0) start = 0
  if (!end || end < 0 || end > len) end = len

  let out = ''
  for (let i = start; i < end; ++i) {
    out += hexSliceLookupTable[buf[i]]
  }
  return out
}

function utf16leSlice (buf, start, end) {
  const bytes = buf.slice(start, end)
  let res = ''
  // If bytes.length is odd, the last 8 bits must be ignored (same as node.js)
  for (let i = 0; i < bytes.length - 1; i += 2) {
    res += String.fromCharCode(bytes[i] + (bytes[i + 1] * 256))
  }
  return res
}

Buffer.prototype.slice = function slice (start, end) {
  const len = this.length
  start = ~~start
  end = end === undefined ? len : ~~end

  if (start < 0) {
    start += len
    if (start < 0) start = 0
  } else if (start > len) {
    start = len
  }

  if (end < 0) {
    end += len
    if (end < 0) end = 0
  } else if (end > len) {
    end = len
  }

  if (end < start) end = start

  const newBuf = this.subarray(start, end)
  // Return an augmented `Uint8Array` instance
  Object.setPrototypeOf(newBuf, Buffer.prototype)

  return newBuf
}

/*
 * Need to make sure that buffer isn't trying to write out of bounds.
 */
function checkOffset (offset, ext, length) {
  if ((offset % 1) !== 0 || offset < 0) throw new RangeError('offset is not uint')
  if (offset + ext > length) throw new RangeError('Trying to access beyond buffer length')
}

Buffer.prototype.readUintLE =
Buffer.prototype.readUIntLE = function readUIntLE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  let val = this[offset]
  let mul = 1
  let i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }

  return val
}

Buffer.prototype.readUintBE =
Buffer.prototype.readUIntBE = function readUIntBE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) {
    checkOffset(offset, byteLength, this.length)
  }

  let val = this[offset + --byteLength]
  let mul = 1
  while (byteLength > 0 && (mul *= 0x100)) {
    val += this[offset + --byteLength] * mul
  }

  return val
}

Buffer.prototype.readUint8 =
Buffer.prototype.readUInt8 = function readUInt8 (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 1, this.length)
  return this[offset]
}

Buffer.prototype.readUint16LE =
Buffer.prototype.readUInt16LE = function readUInt16LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  return this[offset] | (this[offset + 1] << 8)
}

Buffer.prototype.readUint16BE =
Buffer.prototype.readUInt16BE = function readUInt16BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  return (this[offset] << 8) | this[offset + 1]
}

Buffer.prototype.readUint32LE =
Buffer.prototype.readUInt32LE = function readUInt32LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return ((this[offset]) |
      (this[offset + 1] << 8) |
      (this[offset + 2] << 16)) +
      (this[offset + 3] * 0x1000000)
}

Buffer.prototype.readUint32BE =
Buffer.prototype.readUInt32BE = function readUInt32BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] * 0x1000000) +
    ((this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    this[offset + 3])
}

Buffer.prototype.readBigUInt64LE = defineBigIntMethod(function readBigUInt64LE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const lo = first +
    this[++offset] * 2 ** 8 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 24

  const hi = this[++offset] +
    this[++offset] * 2 ** 8 +
    this[++offset] * 2 ** 16 +
    last * 2 ** 24

  return BigInt(lo) + (BigInt(hi) << BigInt(32))
})

Buffer.prototype.readBigUInt64BE = defineBigIntMethod(function readBigUInt64BE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const hi = first * 2 ** 24 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    this[++offset]

  const lo = this[++offset] * 2 ** 24 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    last

  return (BigInt(hi) << BigInt(32)) + BigInt(lo)
})

Buffer.prototype.readIntLE = function readIntLE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  let val = this[offset]
  let mul = 1
  let i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readIntBE = function readIntBE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  let i = byteLength
  let mul = 1
  let val = this[offset + --i]
  while (i > 0 && (mul *= 0x100)) {
    val += this[offset + --i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readInt8 = function readInt8 (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 1, this.length)
  if (!(this[offset] & 0x80)) return (this[offset])
  return ((0xff - this[offset] + 1) * -1)
}

Buffer.prototype.readInt16LE = function readInt16LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  const val = this[offset] | (this[offset + 1] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt16BE = function readInt16BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  const val = this[offset + 1] | (this[offset] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt32LE = function readInt32LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset]) |
    (this[offset + 1] << 8) |
    (this[offset + 2] << 16) |
    (this[offset + 3] << 24)
}

Buffer.prototype.readInt32BE = function readInt32BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] << 24) |
    (this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    (this[offset + 3])
}

Buffer.prototype.readBigInt64LE = defineBigIntMethod(function readBigInt64LE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const val = this[offset + 4] +
    this[offset + 5] * 2 ** 8 +
    this[offset + 6] * 2 ** 16 +
    (last << 24) // Overflow

  return (BigInt(val) << BigInt(32)) +
    BigInt(first +
    this[++offset] * 2 ** 8 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 24)
})

Buffer.prototype.readBigInt64BE = defineBigIntMethod(function readBigInt64BE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const val = (first << 24) + // Overflow
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    this[++offset]

  return (BigInt(val) << BigInt(32)) +
    BigInt(this[++offset] * 2 ** 24 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    last)
})

Buffer.prototype.readFloatLE = function readFloatLE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, true, 23, 4)
}

Buffer.prototype.readFloatBE = function readFloatBE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, false, 23, 4)
}

Buffer.prototype.readDoubleLE = function readDoubleLE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, true, 52, 8)
}

Buffer.prototype.readDoubleBE = function readDoubleBE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, false, 52, 8)
}

function checkInt (buf, value, offset, ext, max, min) {
  if (!Buffer.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance')
  if (value > max || value < min) throw new RangeError('"value" argument is out of bounds')
  if (offset + ext > buf.length) throw new RangeError('Index out of range')
}

Buffer.prototype.writeUintLE =
Buffer.prototype.writeUIntLE = function writeUIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) {
    const maxBytes = Math.pow(2, 8 * byteLength) - 1
    checkInt(this, value, offset, byteLength, maxBytes, 0)
  }

  let mul = 1
  let i = 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUintBE =
Buffer.prototype.writeUIntBE = function writeUIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) {
    const maxBytes = Math.pow(2, 8 * byteLength) - 1
    checkInt(this, value, offset, byteLength, maxBytes, 0)
  }

  let i = byteLength - 1
  let mul = 1
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUint8 =
Buffer.prototype.writeUInt8 = function writeUInt8 (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0)
  this[offset] = (value & 0xff)
  return offset + 1
}

Buffer.prototype.writeUint16LE =
Buffer.prototype.writeUInt16LE = function writeUInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  this[offset] = (value & 0xff)
  this[offset + 1] = (value >>> 8)
  return offset + 2
}

Buffer.prototype.writeUint16BE =
Buffer.prototype.writeUInt16BE = function writeUInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  this[offset] = (value >>> 8)
  this[offset + 1] = (value & 0xff)
  return offset + 2
}

Buffer.prototype.writeUint32LE =
Buffer.prototype.writeUInt32LE = function writeUInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  this[offset + 3] = (value >>> 24)
  this[offset + 2] = (value >>> 16)
  this[offset + 1] = (value >>> 8)
  this[offset] = (value & 0xff)
  return offset + 4
}

Buffer.prototype.writeUint32BE =
Buffer.prototype.writeUInt32BE = function writeUInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  this[offset] = (value >>> 24)
  this[offset + 1] = (value >>> 16)
  this[offset + 2] = (value >>> 8)
  this[offset + 3] = (value & 0xff)
  return offset + 4
}

function wrtBigUInt64LE (buf, value, offset, min, max) {
  checkIntBI(value, min, max, buf, offset, 7)

  let lo = Number(value & BigInt(0xffffffff))
  buf[offset++] = lo
  lo = lo >> 8
  buf[offset++] = lo
  lo = lo >> 8
  buf[offset++] = lo
  lo = lo >> 8
  buf[offset++] = lo
  let hi = Number(value >> BigInt(32) & BigInt(0xffffffff))
  buf[offset++] = hi
  hi = hi >> 8
  buf[offset++] = hi
  hi = hi >> 8
  buf[offset++] = hi
  hi = hi >> 8
  buf[offset++] = hi
  return offset
}

function wrtBigUInt64BE (buf, value, offset, min, max) {
  checkIntBI(value, min, max, buf, offset, 7)

  let lo = Number(value & BigInt(0xffffffff))
  buf[offset + 7] = lo
  lo = lo >> 8
  buf[offset + 6] = lo
  lo = lo >> 8
  buf[offset + 5] = lo
  lo = lo >> 8
  buf[offset + 4] = lo
  let hi = Number(value >> BigInt(32) & BigInt(0xffffffff))
  buf[offset + 3] = hi
  hi = hi >> 8
  buf[offset + 2] = hi
  hi = hi >> 8
  buf[offset + 1] = hi
  hi = hi >> 8
  buf[offset] = hi
  return offset + 8
}

Buffer.prototype.writeBigUInt64LE = defineBigIntMethod(function writeBigUInt64LE (value, offset = 0) {
  return wrtBigUInt64LE(this, value, offset, BigInt(0), BigInt('0xffffffffffffffff'))
})

Buffer.prototype.writeBigUInt64BE = defineBigIntMethod(function writeBigUInt64BE (value, offset = 0) {
  return wrtBigUInt64BE(this, value, offset, BigInt(0), BigInt('0xffffffffffffffff'))
})

Buffer.prototype.writeIntLE = function writeIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    const limit = Math.pow(2, (8 * byteLength) - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  let i = 0
  let mul = 1
  let sub = 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
      sub = 1
    }
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeIntBE = function writeIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    const limit = Math.pow(2, (8 * byteLength) - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  let i = byteLength - 1
  let mul = 1
  let sub = 0
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
      sub = 1
    }
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeInt8 = function writeInt8 (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -0x80)
  if (value < 0) value = 0xff + value + 1
  this[offset] = (value & 0xff)
  return offset + 1
}

Buffer.prototype.writeInt16LE = function writeInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  this[offset] = (value & 0xff)
  this[offset + 1] = (value >>> 8)
  return offset + 2
}

Buffer.prototype.writeInt16BE = function writeInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  this[offset] = (value >>> 8)
  this[offset + 1] = (value & 0xff)
  return offset + 2
}

Buffer.prototype.writeInt32LE = function writeInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  this[offset] = (value & 0xff)
  this[offset + 1] = (value >>> 8)
  this[offset + 2] = (value >>> 16)
  this[offset + 3] = (value >>> 24)
  return offset + 4
}

Buffer.prototype.writeInt32BE = function writeInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  if (value < 0) value = 0xffffffff + value + 1
  this[offset] = (value >>> 24)
  this[offset + 1] = (value >>> 16)
  this[offset + 2] = (value >>> 8)
  this[offset + 3] = (value & 0xff)
  return offset + 4
}

Buffer.prototype.writeBigInt64LE = defineBigIntMethod(function writeBigInt64LE (value, offset = 0) {
  return wrtBigUInt64LE(this, value, offset, -BigInt('0x8000000000000000'), BigInt('0x7fffffffffffffff'))
})

Buffer.prototype.writeBigInt64BE = defineBigIntMethod(function writeBigInt64BE (value, offset = 0) {
  return wrtBigUInt64BE(this, value, offset, -BigInt('0x8000000000000000'), BigInt('0x7fffffffffffffff'))
})

function checkIEEE754 (buf, value, offset, ext, max, min) {
  if (offset + ext > buf.length) throw new RangeError('Index out of range')
  if (offset < 0) throw new RangeError('Index out of range')
}

function writeFloat (buf, value, offset, littleEndian, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 4, 3.4028234663852886e+38, -3.4028234663852886e+38)
  }
  ieee754.write(buf, value, offset, littleEndian, 23, 4)
  return offset + 4
}

Buffer.prototype.writeFloatLE = function writeFloatLE (value, offset, noAssert) {
  return writeFloat(this, value, offset, true, noAssert)
}

Buffer.prototype.writeFloatBE = function writeFloatBE (value, offset, noAssert) {
  return writeFloat(this, value, offset, false, noAssert)
}

function writeDouble (buf, value, offset, littleEndian, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 8, 1.7976931348623157E+308, -1.7976931348623157E+308)
  }
  ieee754.write(buf, value, offset, littleEndian, 52, 8)
  return offset + 8
}

Buffer.prototype.writeDoubleLE = function writeDoubleLE (value, offset, noAssert) {
  return writeDouble(this, value, offset, true, noAssert)
}

Buffer.prototype.writeDoubleBE = function writeDoubleBE (value, offset, noAssert) {
  return writeDouble(this, value, offset, false, noAssert)
}

// copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
Buffer.prototype.copy = function copy (target, targetStart, start, end) {
  if (!Buffer.isBuffer(target)) throw new TypeError('argument should be a Buffer')
  if (!start) start = 0
  if (!end && end !== 0) end = this.length
  if (targetStart >= target.length) targetStart = target.length
  if (!targetStart) targetStart = 0
  if (end > 0 && end < start) end = start

  // Copy 0 bytes; we're done
  if (end === start) return 0
  if (target.length === 0 || this.length === 0) return 0

  // Fatal error conditions
  if (targetStart < 0) {
    throw new RangeError('targetStart out of bounds')
  }
  if (start < 0 || start >= this.length) throw new RangeError('Index out of range')
  if (end < 0) throw new RangeError('sourceEnd out of bounds')

  // Are we oob?
  if (end > this.length) end = this.length
  if (target.length - targetStart < end - start) {
    end = target.length - targetStart + start
  }

  const len = end - start

  if (this === target && typeof Uint8Array.prototype.copyWithin === 'function') {
    // Use built-in when available, missing from IE11
    this.copyWithin(targetStart, start, end)
  } else {
    Uint8Array.prototype.set.call(
      target,
      this.subarray(start, end),
      targetStart
    )
  }

  return len
}

// Usage:
//    buffer.fill(number[, offset[, end]])
//    buffer.fill(buffer[, offset[, end]])
//    buffer.fill(string[, offset[, end]][, encoding])
Buffer.prototype.fill = function fill (val, start, end, encoding) {
  // Handle string cases:
  if (typeof val === 'string') {
    if (typeof start === 'string') {
      encoding = start
      start = 0
      end = this.length
    } else if (typeof end === 'string') {
      encoding = end
      end = this.length
    }
    if (encoding !== undefined && typeof encoding !== 'string') {
      throw new TypeError('encoding must be a string')
    }
    if (typeof encoding === 'string' && !Buffer.isEncoding(encoding)) {
      throw new TypeError('Unknown encoding: ' + encoding)
    }
    if (val.length === 1) {
      const code = val.charCodeAt(0)
      if ((encoding === 'utf8' && code < 128) ||
          encoding === 'latin1') {
        // Fast path: If `val` fits into a single byte, use that numeric value.
        val = code
      }
    }
  } else if (typeof val === 'number') {
    val = val & 255
  } else if (typeof val === 'boolean') {
    val = Number(val)
  }

  // Invalid ranges are not set to a default, so can range check early.
  if (start < 0 || this.length < start || this.length < end) {
    throw new RangeError('Out of range index')
  }

  if (end <= start) {
    return this
  }

  start = start >>> 0
  end = end === undefined ? this.length : end >>> 0

  if (!val) val = 0

  let i
  if (typeof val === 'number') {
    for (i = start; i < end; ++i) {
      this[i] = val
    }
  } else {
    const bytes = Buffer.isBuffer(val)
      ? val
      : Buffer.from(val, encoding)
    const len = bytes.length
    if (len === 0) {
      throw new TypeError('The value "' + val +
        '" is invalid for argument "value"')
    }
    for (i = 0; i < end - start; ++i) {
      this[i + start] = bytes[i % len]
    }
  }

  return this
}

// CUSTOM ERRORS
// =============

// Simplified versions from Node, changed for Buffer-only usage
const errors = {}
function E (sym, getMessage, Base) {
  errors[sym] = class NodeError extends Base {
    constructor () {
      super()

      Object.defineProperty(this, 'message', {
        value: getMessage.apply(this, arguments),
        writable: true,
        configurable: true
      })

      // Add the error code to the name to include it in the stack trace.
      this.name = `${this.name} [${sym}]`
      // Access the stack to generate the error message including the error code
      // from the name.
      this.stack // eslint-disable-line no-unused-expressions
      // Reset the name to the actual name.
      delete this.name
    }

    get code () {
      return sym
    }

    set code (value) {
      Object.defineProperty(this, 'code', {
        configurable: true,
        enumerable: true,
        value,
        writable: true
      })
    }

    toString () {
      return `${this.name} [${sym}]: ${this.message}`
    }
  }
}

E('ERR_BUFFER_OUT_OF_BOUNDS',
  function (name) {
    if (name) {
      return `${name} is outside of buffer bounds`
    }

    return 'Attempt to access memory outside buffer bounds'
  }, RangeError)
E('ERR_INVALID_ARG_TYPE',
  function (name, actual) {
    return `The "${name}" argument must be of type number. Received type ${typeof actual}`
  }, TypeError)
E('ERR_OUT_OF_RANGE',
  function (str, range, input) {
    let msg = `The value of "${str}" is out of range.`
    let received = input
    if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) {
      received = addNumericalSeparator(String(input))
    } else if (typeof input === 'bigint') {
      received = String(input)
      if (input > BigInt(2) ** BigInt(32) || input < -(BigInt(2) ** BigInt(32))) {
        received = addNumericalSeparator(received)
      }
      received += 'n'
    }
    msg += ` It must be ${range}. Received ${received}`
    return msg
  }, RangeError)

function addNumericalSeparator (val) {
  let res = ''
  let i = val.length
  const start = val[0] === '-' ? 1 : 0
  for (; i >= start + 4; i -= 3) {
    res = `_${val.slice(i - 3, i)}${res}`
  }
  return `${val.slice(0, i)}${res}`
}

// CHECK FUNCTIONS
// ===============

function checkBounds (buf, offset, byteLength) {
  validateNumber(offset, 'offset')
  if (buf[offset] === undefined || buf[offset + byteLength] === undefined) {
    boundsError(offset, buf.length - (byteLength + 1))
  }
}

function checkIntBI (value, min, max, buf, offset, byteLength) {
  if (value > max || value < min) {
    const n = typeof min === 'bigint' ? 'n' : ''
    let range
    if (byteLength > 3) {
      if (min === 0 || min === BigInt(0)) {
        range = `>= 0${n} and < 2${n} ** ${(byteLength + 1) * 8}${n}`
      } else {
        range = `>= -(2${n} ** ${(byteLength + 1) * 8 - 1}${n}) and < 2 ** ` +
                `${(byteLength + 1) * 8 - 1}${n}`
      }
    } else {
      range = `>= ${min}${n} and <= ${max}${n}`
    }
    throw new errors.ERR_OUT_OF_RANGE('value', range, value)
  }
  checkBounds(buf, offset, byteLength)
}

function validateNumber (value, name) {
  if (typeof value !== 'number') {
    throw new errors.ERR_INVALID_ARG_TYPE(name, 'number', value)
  }
}

function boundsError (value, length, type) {
  if (Math.floor(value) !== value) {
    validateNumber(value, type)
    throw new errors.ERR_OUT_OF_RANGE(type || 'offset', 'an integer', value)
  }

  if (length < 0) {
    throw new errors.ERR_BUFFER_OUT_OF_BOUNDS()
  }

  throw new errors.ERR_OUT_OF_RANGE(type || 'offset',
                                    `>= ${type ? 1 : 0} and <= ${length}`,
                                    value)
}

// HELPER FUNCTIONS
// ================

const INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g

function base64clean (str) {
  // Node takes equal signs as end of the Base64 encoding
  str = str.split('=')[0]
  // Node strips out invalid characters like \n and \t from the string, base64-js does not
  str = str.trim().replace(INVALID_BASE64_RE, '')
  // Node converts strings with length < 2 to ''
  if (str.length < 2) return ''
  // Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
  while (str.length % 4 !== 0) {
    str = str + '='
  }
  return str
}

function utf8ToBytes (string, units) {
  units = units || Infinity
  let codePoint
  const length = string.length
  let leadSurrogate = null
  const bytes = []

  for (let i = 0; i < length; ++i) {
    codePoint = string.charCodeAt(i)

    // is surrogate component
    if (codePoint > 0xD7FF && codePoint < 0xE000) {
      // last char was a lead
      if (!leadSurrogate) {
        // no lead yet
        if (codePoint > 0xDBFF) {
          // unexpected trail
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        } else if (i + 1 === length) {
          // unpaired lead
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        }

        // valid lead
        leadSurrogate = codePoint

        continue
      }

      // 2 leads in a row
      if (codePoint < 0xDC00) {
        if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
        leadSurrogate = codePoint
        continue
      }

      // valid surrogate pair
      codePoint = (leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00) + 0x10000
    } else if (leadSurrogate) {
      // valid bmp char, but last char was a lead
      if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
    }

    leadSurrogate = null

    // encode utf8
    if (codePoint < 0x80) {
      if ((units -= 1) < 0) break
      bytes.push(codePoint)
    } else if (codePoint < 0x800) {
      if ((units -= 2) < 0) break
      bytes.push(
        codePoint >> 0x6 | 0xC0,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x10000) {
      if ((units -= 3) < 0) break
      bytes.push(
        codePoint >> 0xC | 0xE0,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x110000) {
      if ((units -= 4) < 0) break
      bytes.push(
        codePoint >> 0x12 | 0xF0,
        codePoint >> 0xC & 0x3F | 0x80,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else {
      throw new Error('Invalid code point')
    }
  }

  return bytes
}

function asciiToBytes (str) {
  const byteArray = []
  for (let i = 0; i < str.length; ++i) {
    // Node's code seems to be doing this and not & 0x7F..
    byteArray.push(str.charCodeAt(i) & 0xFF)
  }
  return byteArray
}

function utf16leToBytes (str, units) {
  let c, hi, lo
  const byteArray = []
  for (let i = 0; i < str.length; ++i) {
    if ((units -= 2) < 0) break

    c = str.charCodeAt(i)
    hi = c >> 8
    lo = c % 256
    byteArray.push(lo)
    byteArray.push(hi)
  }

  return byteArray
}

function base64ToBytes (str) {
  return base64.toByteArray(base64clean(str))
}

function blitBuffer (src, dst, offset, length) {
  let i
  for (i = 0; i < length; ++i) {
    if ((i + offset >= dst.length) || (i >= src.length)) break
    dst[i + offset] = src[i]
  }
  return i
}

// ArrayBuffer or Uint8Array objects from other contexts (i.e. iframes) do not pass
// the `instanceof` check but they should be treated as of that type.
// See: https://github.com/feross/buffer/issues/166
function isInstance (obj, type) {
  return obj instanceof type ||
    (obj != null && obj.constructor != null && obj.constructor.name != null &&
      obj.constructor.name === type.name)
}
function numberIsNaN (obj) {
  // For IE11 support
  return obj !== obj // eslint-disable-line no-self-compare
}

// Create lookup table for `toString('hex')`
// See: https://github.com/feross/buffer/issues/219
const hexSliceLookupTable = (function () {
  const alphabet = '0123456789abcdef'
  const table = new Array(256)
  for (let i = 0; i < 16; ++i) {
    const i16 = i * 16
    for (let j = 0; j < 16; ++j) {
      table[i16 + j] = alphabet[i] + alphabet[j]
    }
  }
  return table
})()

// Return not function with Error if BigInt not supported
function defineBigIntMethod (fn) {
  return typeof BigInt === 'undefined' ? BufferBigIntNotDefined : fn
}

function BufferBigIntNotDefined () {
  throw new Error('BigInt not supported')
}


/***/ }),

/***/ 251:
/***/ ((__unused_webpack_module, exports) => {

/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
exports.read = function (buffer, offset, isLE, mLen, nBytes) {
  var e, m
  var eLen = (nBytes * 8) - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var nBits = -7
  var i = isLE ? (nBytes - 1) : 0
  var d = isLE ? -1 : 1
  var s = buffer[offset + i]

  i += d

  e = s & ((1 << (-nBits)) - 1)
  s >>= (-nBits)
  nBits += eLen
  for (; nBits > 0; e = (e * 256) + buffer[offset + i], i += d, nBits -= 8) {}

  m = e & ((1 << (-nBits)) - 1)
  e >>= (-nBits)
  nBits += mLen
  for (; nBits > 0; m = (m * 256) + buffer[offset + i], i += d, nBits -= 8) {}

  if (e === 0) {
    e = 1 - eBias
  } else if (e === eMax) {
    return m ? NaN : ((s ? -1 : 1) * Infinity)
  } else {
    m = m + Math.pow(2, mLen)
    e = e - eBias
  }
  return (s ? -1 : 1) * m * Math.pow(2, e - mLen)
}

exports.write = function (buffer, value, offset, isLE, mLen, nBytes) {
  var e, m, c
  var eLen = (nBytes * 8) - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var rt = (mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0)
  var i = isLE ? 0 : (nBytes - 1)
  var d = isLE ? 1 : -1
  var s = value < 0 || (value === 0 && 1 / value < 0) ? 1 : 0

  value = Math.abs(value)

  if (isNaN(value) || value === Infinity) {
    m = isNaN(value) ? 1 : 0
    e = eMax
  } else {
    e = Math.floor(Math.log(value) / Math.LN2)
    if (value * (c = Math.pow(2, -e)) < 1) {
      e--
      c *= 2
    }
    if (e + eBias >= 1) {
      value += rt / c
    } else {
      value += rt * Math.pow(2, 1 - eBias)
    }
    if (value * c >= 2) {
      e++
      c /= 2
    }

    if (e + eBias >= eMax) {
      m = 0
      e = eMax
    } else if (e + eBias >= 1) {
      m = ((value * c) - 1) * Math.pow(2, mLen)
      e = e + eBias
    } else {
      m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen)
      e = 0
    }
  }

  for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) {}

  e = (e << mLen) | m
  eLen += mLen
  for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) {}

  buffer[offset + i - d] |= s * 128
}


/***/ }),

/***/ 5606:
/***/ ((module) => {

// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };


/***/ }),

/***/ 9266:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  ChromaClient: () => (/* binding */ ChromaClient)
});

// UNUSED EXPORTS: AdminClient, AdminCloudClient, ChromaClientError, ChromaConnectionError, ChromaError, ChromaForbiddenError, ChromaNotFoundError, ChromaQuotaExceededError, ChromaRateLimitError, ChromaServerError, ChromaUnauthorizedError, ChromaUniqueError, ChromaValueError, CloudClient, GetResult, IncludeEnum, InvalidArgumentError, InvalidCollectionError, QueryResult, baseRecordSetFields, createErrorByType, getDefaultEFConfig, getEmbeddingFunction, knownEmbeddingFunctions, processCreateCollectionConfig, processUpdateCollectionConfig, recordSetFields, registerEmbeddingFunction, serializeEmbeddingFunction, withChroma

;// CONCATENATED MODULE: ./node_modules/chromadb/dist/chunk-NSSMTXJJ.mjs
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);


//# sourceMappingURL=chunk-NSSMTXJJ.mjs.map
// EXTERNAL MODULE: ./node_modules/process/browser.js
var browser = __webpack_require__(5606);
;// CONCATENATED MODULE: ./node_modules/chromadb/dist/chromadb.mjs


// src/deno.ts
if (typeof globalThis.Deno !== "undefined") {
  const OriginalRequest = globalThis.Request;
  const PatchedRequest = function(input, init) {
    if (init && typeof init === "object") {
      const cleanInit = { ...init };
      if ("client" in cleanInit) {
        delete cleanInit.client;
      }
      return new OriginalRequest(input, cleanInit);
    }
    return new OriginalRequest(input, init);
  };
  Object.setPrototypeOf(PatchedRequest, OriginalRequest);
  Object.defineProperty(PatchedRequest, "prototype", {
    value: OriginalRequest.prototype,
    writable: false
  });
  globalThis.Request = PatchedRequest;
}

// src/types.ts
var baseRecordSetFields = [
  "ids",
  "embeddings",
  "metadatas",
  "documents",
  "uris"
];
var recordSetFields = [...baseRecordSetFields, "ids"];
var IncludeEnum = /* @__PURE__ */ ((IncludeEnum2) => {
  IncludeEnum2["distances"] = "distances";
  IncludeEnum2["documents"] = "documents";
  IncludeEnum2["embeddings"] = "embeddings";
  IncludeEnum2["metadatas"] = "metadatas";
  IncludeEnum2["uris"] = "uris";
  return IncludeEnum2;
})(IncludeEnum || {});
var GetResult = class {
  /**
   * Creates a new GetResult instance.
   * @param data - The result data containing all fields
   */
  constructor({
    documents,
    embeddings,
    ids,
    include,
    metadatas,
    uris
  }) {
    this.documents = documents;
    this.embeddings = embeddings;
    this.ids = ids;
    this.include = include;
    this.metadatas = metadatas;
    this.uris = uris;
  }
  /**
   * Converts the result to a row-based format for easier iteration.
   * @returns Object containing include fields and array of record objects
   */
  rows() {
    return this.ids.map((id, index) => {
      return {
        id,
        document: this.include.includes("documents") ? this.documents[index] : void 0,
        embedding: this.include.includes("embeddings") ? this.embeddings[index] : void 0,
        metadata: this.include.includes("metadatas") ? this.metadatas[index] : void 0,
        uri: this.include.includes("uris") ? this.uris[index] : void 0
      };
    });
  }
};
var QueryResult = class {
  /**
   * Creates a new QueryResult instance.
   * @param data - The query result data containing all fields
   */
  constructor({
    distances,
    documents,
    embeddings,
    ids,
    include,
    metadatas,
    uris
  }) {
    this.distances = distances;
    this.documents = documents;
    this.embeddings = embeddings;
    this.ids = ids;
    this.include = include;
    this.metadatas = metadatas;
    this.uris = uris;
  }
  /**
   * Converts the query result to a row-based format for easier iteration.
   * @returns Object containing include fields and structured query results
   */
  rows() {
    const queries = [];
    for (let q2 = 0; q2 < this.ids.length; q2++) {
      const records = this.ids[q2].map((id, index) => {
        return {
          id,
          document: this.include.includes("documents") ? this.documents[q2][index] : void 0,
          embedding: this.include.includes("embeddings") ? this.embeddings[q2][index] : void 0,
          metadata: this.include.includes("metadatas") ? this.metadatas[q2][index] : void 0,
          uri: this.include.includes("uris") ? this.uris[q2][index] : void 0,
          distance: this.include.includes("distances") ? this.distances[q2][index] : void 0
        };
      });
      queries.push(records);
    }
    return queries;
  }
};

// ../../node_modules/.pnpm/@hey-api+client-fetch@0.10.0_@hey-api+openapi-ts@0.67.3_typescript@5.8.3_/node_modules/@hey-api/client-fetch/dist/index.js
var A = async (t, r) => {
  let e = typeof r == "function" ? await r(t) : r;
  if (e) return t.scheme === "bearer" ? `Bearer ${e}` : t.scheme === "basic" ? `Basic ${btoa(e)}` : e;
};
var R = { bodySerializer: (t) => JSON.stringify(t, (r, e) => typeof e == "bigint" ? e.toString() : e) };
var U = (t) => {
  switch (t) {
    case "label":
      return ".";
    case "matrix":
      return ";";
    case "simple":
      return ",";
    default:
      return "&";
  }
};
var _ = (t) => {
  switch (t) {
    case "form":
      return ",";
    case "pipeDelimited":
      return "|";
    case "spaceDelimited":
      return "%20";
    default:
      return ",";
  }
};
var D = (t) => {
  switch (t) {
    case "label":
      return ".";
    case "matrix":
      return ";";
    case "simple":
      return ",";
    default:
      return "&";
  }
};
var O = ({ allowReserved: t, explode: r, name: e, style: a, value: i }) => {
  if (!r) {
    let s = (t ? i : i.map((l) => encodeURIComponent(l))).join(_(a));
    switch (a) {
      case "label":
        return `.${s}`;
      case "matrix":
        return `;${e}=${s}`;
      case "simple":
        return s;
      default:
        return `${e}=${s}`;
    }
  }
  let o = U(a), n = i.map((s) => a === "label" || a === "simple" ? t ? s : encodeURIComponent(s) : y({ allowReserved: t, name: e, value: s })).join(o);
  return a === "label" || a === "matrix" ? o + n : n;
};
var y = ({ allowReserved: t, name: r, value: e }) => {
  if (e == null) return "";
  if (typeof e == "object") throw new Error("Deeply-nested arrays/objects aren\u2019t supported. Provide your own `querySerializer()` to handle these.");
  return `${r}=${t ? e : encodeURIComponent(e)}`;
};
var q = ({ allowReserved: t, explode: r, name: e, style: a, value: i }) => {
  if (i instanceof Date) return `${e}=${i.toISOString()}`;
  if (a !== "deepObject" && !r) {
    let s = [];
    Object.entries(i).forEach(([f, u]) => {
      s = [...s, f, t ? u : encodeURIComponent(u)];
    });
    let l = s.join(",");
    switch (a) {
      case "form":
        return `${e}=${l}`;
      case "label":
        return `.${l}`;
      case "matrix":
        return `;${e}=${l}`;
      default:
        return l;
    }
  }
  let o = D(a), n = Object.entries(i).map(([s, l]) => y({ allowReserved: t, name: a === "deepObject" ? `${e}[${s}]` : s, value: l })).join(o);
  return a === "label" || a === "matrix" ? o + n : n;
};
var H = /\{[^{}]+\}/g;
var B = ({ path: t, url: r }) => {
  let e = r, a = r.match(H);
  if (a) for (let i of a) {
    let o = false, n = i.substring(1, i.length - 1), s = "simple";
    n.endsWith("*") && (o = true, n = n.substring(0, n.length - 1)), n.startsWith(".") ? (n = n.substring(1), s = "label") : n.startsWith(";") && (n = n.substring(1), s = "matrix");
    let l = t[n];
    if (l == null) continue;
    if (Array.isArray(l)) {
      e = e.replace(i, O({ explode: o, name: n, style: s, value: l }));
      continue;
    }
    if (typeof l == "object") {
      e = e.replace(i, q({ explode: o, name: n, style: s, value: l }));
      continue;
    }
    if (s === "matrix") {
      e = e.replace(i, `;${y({ name: n, value: l })}`);
      continue;
    }
    let f = encodeURIComponent(s === "label" ? `.${l}` : l);
    e = e.replace(i, f);
  }
  return e;
};
var E = ({ allowReserved: t, array: r, object: e } = {}) => (i) => {
  let o = [];
  if (i && typeof i == "object") for (let n in i) {
    let s = i[n];
    if (s != null) {
      if (Array.isArray(s)) {
        o = [...o, O({ allowReserved: t, explode: true, name: n, style: "form", value: s, ...r })];
        continue;
      }
      if (typeof s == "object") {
        o = [...o, q({ allowReserved: t, explode: true, name: n, style: "deepObject", value: s, ...e })];
        continue;
      }
      o = [...o, y({ allowReserved: t, name: n, value: s })];
    }
  }
  return o.join("&");
};
var P = (t) => {
  if (!t) return "stream";
  let r = t.split(";")[0]?.trim();
  if (r) {
    if (r.startsWith("application/json") || r.endsWith("+json")) return "json";
    if (r === "multipart/form-data") return "formData";
    if (["application/", "audio/", "image/", "video/"].some((e) => r.startsWith(e))) return "blob";
    if (r.startsWith("text/")) return "text";
  }
};
var I = async ({ security: t, ...r }) => {
  for (let e of t) {
    let a = await A(e, r.auth);
    if (!a) continue;
    let i = e.name ?? "Authorization";
    switch (e.in) {
      case "query":
        r.query || (r.query = {}), r.query[i] = a;
        break;
      case "cookie":
        r.headers.append("Cookie", `${i}=${a}`);
        break;
      case "header":
      default:
        r.headers.set(i, a);
        break;
    }
    return;
  }
};
var S = (t) => W({ baseUrl: t.baseUrl, path: t.path, query: t.query, querySerializer: typeof t.querySerializer == "function" ? t.querySerializer : E(t.querySerializer), url: t.url });
var W = ({ baseUrl: t, path: r, query: e, querySerializer: a, url: i }) => {
  let o = i.startsWith("/") ? i : `/${i}`, n = (t ?? "") + o;
  r && (n = B({ path: r, url: n }));
  let s = e ? a(e) : "";
  return s.startsWith("?") && (s = s.substring(1)), s && (n += `?${s}`), n;
};
var C = (t, r) => {
  let e = { ...t, ...r };
  return e.baseUrl?.endsWith("/") && (e.baseUrl = e.baseUrl.substring(0, e.baseUrl.length - 1)), e.headers = x(t.headers, r.headers), e;
};
var x = (...t) => {
  let r = new Headers();
  for (let e of t) {
    if (!e || typeof e != "object") continue;
    let a = e instanceof Headers ? e.entries() : Object.entries(e);
    for (let [i, o] of a) if (o === null) r.delete(i);
    else if (Array.isArray(o)) for (let n of o) r.append(i, n);
    else o !== void 0 && r.set(i, typeof o == "object" ? JSON.stringify(o) : o);
  }
  return r;
};
var h = class {
  constructor() {
    __publicField(this, "_fns");
    this._fns = [];
  }
  clear() {
    this._fns = [];
  }
  exists(r) {
    return this._fns.indexOf(r) !== -1;
  }
  eject(r) {
    let e = this._fns.indexOf(r);
    e !== -1 && (this._fns = [...this._fns.slice(0, e), ...this._fns.slice(e + 1)]);
  }
  use(r) {
    this._fns = [...this._fns, r];
  }
};
var T = () => ({ error: new h(), request: new h(), response: new h() });
var N = E({ allowReserved: false, array: { explode: true, style: "form" }, object: { explode: true, style: "deepObject" } });
var Q = { "Content-Type": "application/json" };
var w = (t = {}) => ({ ...R, headers: Q, parseAs: "auto", querySerializer: N, ...t });
var J = (t = {}) => {
  let r = C(w(), t), e = () => ({ ...r }), a = (n) => (r = C(r, n), e()), i = T(), o = async (n) => {
    let s = { ...r, ...n, fetch: n.fetch ?? r.fetch ?? globalThis.fetch, headers: x(r.headers, n.headers) };
    s.security && await I({ ...s, security: s.security }), s.body && s.bodySerializer && (s.body = s.bodySerializer(s.body)), (s.body === void 0 || s.body === "") && s.headers.delete("Content-Type");
    let l = S(s), f = { redirect: "follow", ...s }, u = new Request(l, f);
    for (let p of i.request._fns) u = await p(u, s);
    let k = s.fetch, c = await k(u);
    for (let p of i.response._fns) c = await p(c, u, s);
    let m = { request: u, response: c };
    if (c.ok) {
      if (c.status === 204 || c.headers.get("Content-Length") === "0") return { data: {}, ...m };
      let p = (s.parseAs === "auto" ? P(c.headers.get("Content-Type")) : s.parseAs) ?? "json";
      if (p === "stream") return { data: c.body, ...m };
      let b = await c[p]();
      return p === "json" && (s.responseValidator && await s.responseValidator(b), s.responseTransformer && (b = await s.responseTransformer(b))), { data: b, ...m };
    }
    let g = await c.text();
    try {
      g = JSON.parse(g);
    } catch {
    }
    let d = g;
    for (let p of i.error._fns) d = await p(g, c, u, s);
    if (d = d || {}, s.throwOnError) throw d;
    return { error: d, ...m };
  };
  return { buildUrl: S, connect: (n) => o({ ...n, method: "CONNECT" }), delete: (n) => o({ ...n, method: "DELETE" }), get: (n) => o({ ...n, method: "GET" }), getConfig: e, head: (n) => o({ ...n, method: "HEAD" }), interceptors: i, options: (n) => o({ ...n, method: "OPTIONS" }), patch: (n) => o({ ...n, method: "PATCH" }), post: (n) => o({ ...n, method: "POST" }), put: (n) => o({ ...n, method: "PUT" }), request: o, setConfig: a, trace: (n) => o({ ...n, method: "TRACE" }) };
};

// src/api/client.gen.ts
var client = J(w({
  baseUrl: "http://localhost:8000",
  throwOnError: true
}));

// src/api/sdk.gen.ts
var DefaultService = class {
  /**
   * Retrieves the current user's identity, tenant, and databases.
   */
  static getUserIdentity(options) {
    return (options?.client ?? client).get({
      url: "/api/v2/auth/identity",
      ...options
    });
  }
  /**
   * Health check endpoint that returns 200 if the server and executor are ready
   */
  static healthcheck(options) {
    return (options?.client ?? client).get({
      url: "/api/v2/healthcheck",
      ...options
    });
  }
  /**
   * Heartbeat endpoint that returns a nanosecond timestamp of the current time.
   */
  static heartbeat(options) {
    return (options?.client ?? client).get({
      url: "/api/v2/heartbeat",
      ...options
    });
  }
  /**
   * Pre-flight checks endpoint reporting basic readiness info.
   */
  static preFlightChecks(options) {
    return (options?.client ?? client).get({
      url: "/api/v2/pre-flight-checks",
      ...options
    });
  }
  /**
   * Reset endpoint allowing authorized users to reset the database.
   */
  static reset(options) {
    return (options?.client ?? client).post({
      url: "/api/v2/reset",
      ...options
    });
  }
  /**
   * Creates a new tenant.
   */
  static createTenant(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Returns an existing tenant by name.
   */
  static getTenant(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant_name}",
      ...options
    });
  }
  /**
   * Updates an existing tenant by name.
   */
  static updateTenant(options) {
    return (options.client ?? client).patch({
      url: "/api/v2/tenants/{tenant_name}",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Lists all databases for a given tenant.
   */
  static listDatabases(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases",
      ...options
    });
  }
  /**
   * Creates a new database for a given tenant.
   */
  static createDatabase(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Deletes a specific database.
   */
  static deleteDatabase(options) {
    return (options.client ?? client).delete({
      url: "/api/v2/tenants/{tenant}/databases/{database}",
      ...options
    });
  }
  /**
   * Retrieves a specific database by name.
   */
  static getDatabase(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases/{database}",
      ...options
    });
  }
  /**
   * Lists all collections in the specified database.
   */
  static listCollections(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections",
      ...options
    });
  }
  /**
   * Creates a new collection under the specified database.
   */
  static createCollection(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Deletes a collection in a given database.
   */
  static deleteCollection(options) {
    return (options.client ?? client).delete({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}",
      ...options
    });
  }
  /**
   * Retrieves a collection by ID or name.
   */
  static getCollection(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}",
      ...options
    });
  }
  /**
   * Updates an existing collection's name or metadata.
   */
  static updateCollection(options) {
    return (options.client ?? client).put({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Adds records to a collection.
   */
  static collectionAdd(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/add",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Retrieves the number of records in a collection.
   */
  static collectionCount(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/count",
      ...options
    });
  }
  /**
   * Deletes records in a collection. Can filter by IDs or metadata.
   */
  static collectionDelete(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/delete",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Forks an existing collection.
   */
  static forkCollection(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/fork",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Retrieves records from a collection by ID or metadata filter.
   */
  static collectionGet(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/get",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Query a collection in a variety of ways, including vector search, metadata filtering, and full-text search
   */
  static collectionQuery(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/query",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Updates records in a collection by ID.
   */
  static collectionUpdate(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/update",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Upserts records in a collection (create if not exists, otherwise update).
   */
  static collectionUpsert(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/upsert",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Retrieves the total number of collections in a given database.
   */
  static countCollections(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections_count",
      ...options
    });
  }
  /**
   * Returns the version of the server.
   */
  static version(options) {
    return (options?.client ?? client).get({
      url: "/api/v2/version",
      ...options
    });
  }
};

// src/errors.ts
var ChromaError = class extends Error {
  constructor(name, message, cause) {
    super(message);
    this.cause = cause;
    this.name = name;
  }
};
var ChromaConnectionError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaConnectionError";
  }
};
var ChromaServerError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaServerError";
  }
};
var ChromaClientError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaClientError";
  }
};
var ChromaUnauthorizedError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaAuthError";
  }
};
var ChromaForbiddenError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaForbiddenError";
  }
};
var ChromaNotFoundError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaNotFoundError";
  }
};
var ChromaValueError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaValueError";
  }
};
var InvalidCollectionError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "InvalidCollectionError";
  }
};
var InvalidArgumentError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "InvalidArgumentError";
  }
};
var ChromaUniqueError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaUniqueError";
  }
};
var ChromaQuotaExceededError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaQuotaExceededError";
  }
};
var ChromaRateLimitError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaRateLimitError";
  }
};
function createErrorByType(type, message) {
  switch (type) {
    case "InvalidCollection":
      return new InvalidCollectionError(message);
    case "InvalidArgumentError":
      return new InvalidArgumentError(message);
    default:
      return void 0;
  }
}

// src/utils.ts
var DEFAULT_TENANT = "default_tenant";
var DEFAULT_DATABASE = "default_database";
var defaultAdminClientArgs = {
  host: "localhost",
  port: 8e3,
  ssl: false
};
var defaultChromaClientArgs = {
  ...defaultAdminClientArgs,
  tenant: DEFAULT_TENANT,
  database: DEFAULT_DATABASE
};
var normalizeMethod = (method) => {
  if (method) {
    switch (method.toUpperCase()) {
      case "GET":
        return "GET";
      case "POST":
        return "POST";
      case "PUT":
        return "PUT";
      case "DELETE":
        return "DELETE";
      case "HEAD":
        return "HEAD";
      case "CONNECT":
        return "CONNECT";
      case "OPTIONS":
        return "OPTIONS";
      case "PATCH":
        return "PATCH";
      case "TRACE":
        return "TRACE";
      default:
        return void 0;
    }
  }
  return void 0;
};
var validateRecordSetLengthConsistency = (recordSet) => {
  const lengths = Object.entries(recordSet).filter(
    ([field, value]) => recordSetFields.includes(field) && value !== void 0
  ).map(([field, value]) => [field, value.length]);
  if (lengths.length === 0) {
    throw new ChromaValueError(
      `At least one of ${recordSetFields.join(", ")} must be provided`
    );
  }
  const zeroLength = lengths.filter(([_2, length]) => length === 0).map(([field, _2]) => field);
  if (zeroLength.length > 0) {
    throw new ChromaValueError(
      `Non-empty lists are required for ${zeroLength.join(", ")}`
    );
  }
  if (new Set(lengths.map(([_2, length]) => length)).size > 1) {
    throw new ChromaValueError(
      `Unequal lengths for fields ${lengths.map(([field, _2]) => field).join(", ")}`
    );
  }
};
var validateEmbeddings = ({
  embeddings,
  fieldName = "embeddings"
}) => {
  if (!Array.isArray(embeddings)) {
    throw new ChromaValueError(
      `Expected '${fieldName}' to be an array, but got ${typeof embeddings}`
    );
  }
  if (embeddings.length === 0) {
    throw new ChromaValueError(
      "Expected embeddings to be an array with at least one item"
    );
  }
  if (!embeddings.filter((e) => e.every((n) => typeof n === "number"))) {
    throw new ChromaValueError(
      "Expected each embedding to be an array of numbers"
    );
  }
  embeddings.forEach((embedding, i) => {
    if (embedding.length === 0) {
      throw new ChromaValueError(
        `Expected each embedding to be a non-empty array of numbers, but got an empty array at index ${i}`
      );
    }
  });
};
var validateDocuments = ({
  documents,
  nullable = false,
  fieldName = "documents"
}) => {
  if (!Array.isArray(documents)) {
    throw new ChromaValueError(
      `Expected '${fieldName}' to be an array, but got ${typeof documents}`
    );
  }
  if (documents.length === 0) {
    throw new ChromaValueError(
      `Expected '${fieldName}' to be a non-empty list`
    );
  }
  documents.forEach((document) => {
    if (!nullable && typeof document !== "string" && !document) {
      throw new ChromaValueError(
        `Expected each document to be a string, but got ${typeof document}`
      );
    }
  });
};
var validateIDs = (ids) => {
  if (!Array.isArray(ids)) {
    throw new ChromaValueError(
      `Expected 'ids' to be an array, but got ${typeof ids}`
    );
  }
  if (ids.length === 0) {
    throw new ChromaValueError("Expected 'ids' to be a non-empty list");
  }
  const nonStrings = ids.map((id, i) => [id, i]).filter(([id, _2]) => typeof id !== "string").map(([_2, i]) => i);
  if (nonStrings.length > 0) {
    throw new ChromaValueError(
      `Found non-string IDs at ${nonStrings.join(", ")}`
    );
  }
  const seen = /* @__PURE__ */ new Set();
  const duplicates = ids.filter((id) => {
    if (seen.has(id)) {
      return id;
    }
    seen.add(id);
  });
  let message = "Expected IDs to be unique, but found duplicates of";
  if (duplicates.length > 0 && duplicates.length <= 5) {
    throw new ChromaValueError(`${message} ${duplicates.join(", ")}`);
  }
  if (duplicates.length > 0) {
    throw new ChromaValueError(
      `${message} ${duplicates.slice(0, 5).join(", ")}, ..., ${duplicates.slice(duplicates.length - 5).join(", ")}`
    );
  }
};
var validateMetadata = (metadata) => {
  if (!metadata) {
    return;
  }
  if (Object.keys(metadata).length === 0) {
    throw new ChromaValueError("Expected metadata to be non-empty");
  }
  if (!Object.values(metadata).every(
    (v) => v === null || v === void 0 || typeof v === "string" || typeof v === "number" || typeof v === "boolean"
  )) {
    throw new ChromaValueError(
      "Expected metadata to be a string, number, boolean, or nullable"
    );
  }
};
var validateMetadatas = (metadatas) => {
  if (!Array.isArray(metadatas)) {
    throw new ChromaValueError(
      `Expected metadatas to be an array, but got ${typeof metadatas}`
    );
  }
  metadatas.forEach((metadata) => validateMetadata(metadata));
};
var validateBaseRecordSet = ({
  recordSet,
  update = false,
  embeddingsField = "embeddings",
  documentsField = "documents"
}) => {
  if (!recordSet.embeddings && !recordSet.documents && !update) {
    throw new ChromaValueError(
      `At least one of '${embeddingsField}' and '${documentsField}' must be provided`
    );
  }
  if (recordSet.embeddings) {
    validateEmbeddings({
      embeddings: recordSet.embeddings,
      fieldName: embeddingsField
    });
  }
  if (recordSet.documents) {
    validateDocuments({
      documents: recordSet.documents,
      fieldName: documentsField
    });
  }
  if (recordSet.metadatas) {
    validateMetadatas(recordSet.metadatas);
  }
};
var validateMaxBatchSize = (recordSetLength, maxBatchSize) => {
  if (recordSetLength > maxBatchSize) {
    throw new ChromaValueError(
      `Record set length ${recordSetLength} exceeds max batch size ${maxBatchSize}`
    );
  }
};
var validateWhere = (where) => {
  if (typeof where !== "object") {
    throw new ChromaValueError("Expected where to be a non-empty object");
  }
  if (Object.keys(where).length != 1) {
    throw new ChromaValueError(
      `Expected 'where' to have exactly one operator, but got ${Object.keys(where).length}`
    );
  }
  Object.entries(where).forEach(([key, value]) => {
    if (key !== "$and" && key !== "$or" && key !== "$in" && key !== "$nin" && !["string", "number", "boolean", "object"].includes(typeof value)) {
      throw new ChromaValueError(
        `Expected 'where' value to be a string, number, boolean, or an operator expression, but got ${value}`
      );
    }
    if (key === "$and" || key === "$or") {
      if (Object.keys(value).length <= 1) {
        throw new ChromaValueError(
          `Expected 'where' value for $and or $or to be a list of 'where' expressions, but got ${value}`
        );
      }
      value.forEach((w2) => validateWhere(w2));
      return;
    }
    if (typeof value === "object") {
      if (Object.keys(value).length != 1) {
        throw new ChromaValueError(
          `Expected operator expression to have one operator, but got ${value}`
        );
      }
      const [operator, operand] = Object.entries(value)[0];
      if (["$gt", "$gte", "$lt", "$lte"].includes(operator) && typeof operand !== "number") {
        throw new ChromaValueError(
          `Expected operand value to be a number for ${operator}, but got ${typeof operand}`
        );
      }
      if (["$in", "$nin"].includes(operator) && !Array.isArray(operand)) {
        throw new ChromaValueError(
          `Expected operand value to be an array for ${operator}, but got ${operand}`
        );
      }
      if (!["$gt", "$gte", "$lt", "$lte", "$ne", "$eq", "$in", "$nin"].includes(
        operator
      )) {
        throw new ChromaValueError(
          `Expected operator to be one of $gt, $gte, $lt, $lte, $ne, $eq, $in, $nin, but got ${operator}`
        );
      }
      if (!["string", "number", "boolean"].includes(typeof operand) && !Array.isArray(operand)) {
        throw new ChromaValueError(
          "Expected operand value to be a string, number, boolean, or a list of those types"
        );
      }
      if (Array.isArray(operand) && (operand.length === 0 || !operand.every((item) => typeof item === typeof operand[0]))) {
        throw new ChromaValueError(
          "Expected 'where' operand value to be a non-empty list and all values to be of the same type"
        );
      }
    }
  });
};
var validateWhereDocument = (whereDocument) => {
  if (typeof whereDocument !== "object") {
    throw new ChromaValueError(
      "Expected 'whereDocument' to be a non-empty object"
    );
  }
  if (Object.keys(whereDocument).length != 1) {
    throw new ChromaValueError(
      `Expected 'whereDocument' to have exactly one operator, but got ${whereDocument}`
    );
  }
  const [operator, operand] = Object.entries(whereDocument)[0];
  if (![
    "$contains",
    "$not_contains",
    "$matches",
    "$not_matches",
    "$regex",
    "$not_regex",
    "$and",
    "$or"
  ].includes(operator)) {
    throw new ChromaValueError(
      `Expected 'whereDocument' operator to be one of $contains, $not_contains, $matches, $not_matches, $regex, $not_regex, $and, or $or, but got ${operator}`
    );
  }
  if (operator === "$and" || operator === "$or") {
    if (!Array.isArray(operand)) {
      throw new ChromaValueError(
        `Expected operand for ${operator} to be a list of 'whereDocument' expressions, but got ${operand}`
      );
    }
    if (operand.length <= 1) {
      throw new ChromaValueError(
        `Expected 'whereDocument' operand for ${operator} to be a list with at least two 'whereDocument' expressions`
      );
    }
    operand.forEach((item) => validateWhereDocument(item));
  }
  if ((operand === "$contains" || operand === "$not_contains" || operand === "$regex" || operand === "$not_regex") && (typeof operator !== "string" || operator.length === 0)) {
    throw new ChromaValueError(
      `Expected operand for ${operator} to be a non empty string, but got ${operand}`
    );
  }
};
var validateInclude = ({
  include,
  exclude
}) => {
  if (!Array.isArray(include)) {
    throw new ChromaValueError("Expected 'include' to be a non-empty array");
  }
  const validValues = Object.keys(IncludeEnum);
  include.forEach((item) => {
    if (typeof item !== "string") {
      throw new ChromaValueError("Expected 'include' items to be strings");
    }
    if (!validValues.includes(item)) {
      throw new ChromaValueError(
        `Expected 'include' items to be one of ${validValues.join(
          ", "
        )}, but got ${item}`
      );
    }
    if (exclude?.includes(item)) {
      throw new ChromaValueError(`${item} is not allowed for this operation`);
    }
  });
};
var validateNResults = (nResults) => {
  if (typeof nResults !== "number") {
    throw new ChromaValueError(
      `Expected 'nResults' to be a number, but got ${typeof nResults}`
    );
  }
  if (nResults <= 0) {
    throw new ChromaValueError("Number of requested results has to positive");
  }
};
var parseConnectionPath = (path) => {
  try {
    const url = new URL(path);
    const ssl = url.protocol === "https:";
    const host = url.hostname;
    const port = url.port;
    return {
      ssl,
      host,
      port: Number(port)
    };
  } catch {
    throw new ChromaValueError(`Invalid URL: ${path}`);
  }
};
var packEmbedding = (embedding) => {
  const buffer = new ArrayBuffer(embedding.length * 4);
  const view = new Float32Array(buffer);
  for (let i = 0; i < embedding.length; i++) {
    view[i] = embedding[i];
  }
  return buffer;
};
var embeddingsToBase64Bytes = (embeddings) => {
  return embeddings.map((embedding) => {
    const buffer = packEmbedding(embedding);
    const uint8Array = new Uint8Array(buffer);
    const binaryString = Array.from(
      uint8Array,
      (byte) => String.fromCharCode(byte)
    ).join("");
    return btoa(binaryString);
  });
};

// src/embedding-function.ts
var knownEmbeddingFunctions = /* @__PURE__ */ new Map();
var registerEmbeddingFunction = (name, fn) => {
  if (knownEmbeddingFunctions.has(name)) {
    throw new ChromaValueError(
      `Embedding function with name ${name} is already registered.`
    );
  }
  knownEmbeddingFunctions.set(name, fn);
};
var getEmbeddingFunction = async (collectionName, efConfig) => {
  if (!efConfig) {
    console.warn(
      `No embedding function configuration found for collection ${collectionName}. 'add' and 'query' will fail unless you provide them embeddings directly.`
    );
    return void 0;
  }
  if (efConfig.type === "legacy") {
    console.warn(
      `No embedding function configuration found for collection ${collectionName}. 'add' and 'query' will fail unless you provide them embeddings directly.`
    );
    return void 0;
  }
  const name = efConfig.name;
  const embeddingFunction = knownEmbeddingFunctions.get(name);
  if (!embeddingFunction) {
    console.warn(
      `Collection ${collectionName} was created with the ${embeddingFunction} embedding function. However, the @chroma-core/${embeddingFunction} package is not install. 'add' and 'query' will fail unless you provide them embeddings directly, or install the @chroma-core/${embeddingFunction} package.`
    );
    return void 0;
  }
  let constructorConfig = efConfig.type === "known" ? efConfig.config : {};
  try {
    if (embeddingFunction.buildFromConfig) {
      return embeddingFunction.buildFromConfig(constructorConfig);
    }
    console.warn(
      `Embedding function ${name} does not define a 'buildFromConfig' function. 'add' and 'query' will fail unless you provide them embeddings directly.`
    );
    return void 0;
  } catch (e) {
    console.warn(
      `Embedding function ${name} failed to build with config: ${constructorConfig}. 'add' and 'query' will fail unless you provide them embeddings directly. Error: ${e}`
    );
    return void 0;
  }
};
var serializeEmbeddingFunction = ({
  embeddingFunction,
  configEmbeddingFunction
}) => {
  if (embeddingFunction && configEmbeddingFunction) {
    throw new ChromaValueError(
      "Embedding function provided when already defined in the collection configuration"
    );
  }
  if (!embeddingFunction && !configEmbeddingFunction) {
    return void 0;
  }
  const ef = embeddingFunction || configEmbeddingFunction;
  if (!ef.getConfig || !ef.name || !ef.constructor.buildFromConfig) {
    return { type: "legacy" };
  }
  if (ef.validateConfig) ef.validateConfig(ef.getConfig());
  return {
    name: ef.name,
    type: "known",
    config: ef.getConfig()
  };
};
var getDefaultEFConfig = async () => {
  try {
    const { DefaultEmbeddingFunction } = await Promise.resolve().then(function webpackMissingModule() { var e = new Error("Cannot find module '@chroma-core/default-embed'"); e.code = 'MODULE_NOT_FOUND'; throw e; });
    if (!knownEmbeddingFunctions.has(new DefaultEmbeddingFunction().name)) {
      registerEmbeddingFunction("default", DefaultEmbeddingFunction);
    }
  } catch (e) {
    console.error(e);
    throw new Error(
      "Cannot instantiate a collection with the DefaultEmbeddingFunction. Please install @chroma-core/default-embed, or provide a different embedding function"
    );
  }
  return {
    name: "default",
    type: "known",
    config: {}
  };
};

// src/collection-configuration.ts
var processCreateCollectionConfig = async ({
  configuration,
  embeddingFunction,
  metadata
}) => {
  if (configuration?.hnsw && configuration?.spann) {
    throw new ChromaValueError(
      "Cannot specify both HNSW and SPANN configurations"
    );
  }
  let embeddingFunctionConfiguration = serializeEmbeddingFunction({
    embeddingFunction: embeddingFunction ?? void 0,
    configEmbeddingFunction: configuration?.embeddingFunction
  });
  if (!embeddingFunctionConfiguration && embeddingFunction !== null) {
    embeddingFunctionConfiguration = await getDefaultEFConfig();
  }
  const overallEf = embeddingFunction || configuration?.embeddingFunction;
  if (overallEf && overallEf.defaultSpace && overallEf.supportedSpaces) {
    if (configuration?.hnsw === void 0 && configuration?.spann === void 0) {
      if (metadata === void 0 || metadata?.["hnsw:space"] === void 0) {
        if (!configuration) configuration = {};
        configuration.hnsw = { space: overallEf.defaultSpace() };
      }
    }
    if (configuration?.hnsw && !configuration.hnsw.space && overallEf.defaultSpace) {
      configuration.hnsw.space = overallEf.defaultSpace();
    }
    if (configuration?.spann && !configuration.spann.space && overallEf.defaultSpace) {
      configuration.spann.space = overallEf.defaultSpace();
    }
    if (overallEf.supportedSpaces) {
      const supportedSpaces = overallEf.supportedSpaces();
      if (configuration?.hnsw?.space && !supportedSpaces.includes(configuration.hnsw.space)) {
        console.warn(
          `Space '${configuration.hnsw.space}' is not supported by embedding function '${overallEf.name || "unknown"}'. Supported spaces: ${supportedSpaces.join(", ")}`
        );
      }
      if (configuration?.spann?.space && !supportedSpaces.includes(configuration.spann.space)) {
        console.warn(
          `Space '${configuration.spann.space}' is not supported by embedding function '${overallEf.name || "unknown"}'. Supported spaces: ${supportedSpaces.join(", ")}`
        );
      }
      if (!configuration?.hnsw && !configuration?.spann && metadata && typeof metadata["hnsw:space"] === "string" && !supportedSpaces.includes(metadata["hnsw:space"])) {
        console.warn(
          `Space '${metadata["hnsw:space"]}' from metadata is not supported by embedding function '${overallEf.name || "unknown"}'. Supported spaces: ${supportedSpaces.join(", ")}`
        );
      }
    }
  }
  return {
    ...configuration || {},
    embedding_function: embeddingFunctionConfiguration
  };
};
var processUpdateCollectionConfig = async ({
  collectionName,
  currentConfiguration,
  currentEmbeddingFunction,
  newConfiguration
}) => {
  if (newConfiguration.hnsw && typeof newConfiguration.hnsw !== "object") {
    throw new ChromaValueError(
      "Invalid HNSW config provided in UpdateCollectionConfiguration"
    );
  }
  if (newConfiguration.spann && typeof newConfiguration.spann !== "object") {
    throw new ChromaValueError(
      "Invalid SPANN config provided in UpdateCollectionConfiguration"
    );
  }
  const embeddingFunction = currentEmbeddingFunction || await getEmbeddingFunction(
    collectionName,
    currentConfiguration.embeddingFunction ?? void 0
  );
  const newEmbeddingFunction = newConfiguration.embeddingFunction;
  if (embeddingFunction && embeddingFunction.validateConfigUpdate && newEmbeddingFunction && newEmbeddingFunction.getConfig) {
    embeddingFunction.validateConfigUpdate(newEmbeddingFunction.getConfig());
  }
  return {
    updateConfiguration: {
      hnsw: newConfiguration.hnsw,
      spann: newConfiguration.spann,
      embedding_function: newEmbeddingFunction && serializeEmbeddingFunction({ embeddingFunction: newEmbeddingFunction })
    },
    updateEmbeddingFunction: newEmbeddingFunction
  };
};

// src/collection.ts
var CollectionImpl = class _CollectionImpl {
  /**
   * Creates a new CollectionAPIImpl instance.
   * @param options - Configuration for the collection API
   */
  constructor({
    chromaClient,
    apiClient,
    id,
    name,
    metadata,
    configuration,
    embeddingFunction
  }) {
    this.chromaClient = chromaClient;
    this.apiClient = apiClient;
    this.id = id;
    this._name = name;
    this._metadata = metadata;
    this._configuration = configuration;
    this._embeddingFunction = embeddingFunction;
  }
  get name() {
    return this._name;
  }
  set name(name) {
    this._name = name;
  }
  get configuration() {
    return this._configuration;
  }
  set configuration(configuration) {
    this._configuration = configuration;
  }
  get metadata() {
    return this._metadata;
  }
  set metadata(metadata) {
    this._metadata = metadata;
  }
  get embeddingFunction() {
    return this._embeddingFunction;
  }
  set embeddingFunction(embeddingFunction) {
    this._embeddingFunction = embeddingFunction;
  }
  async path() {
    const clientPath = await this.chromaClient._path();
    return {
      ...clientPath,
      collection_id: this.id
    };
  }
  async embed(documents) {
    if (!this._embeddingFunction) {
      throw new ChromaValueError(
        "Embedding function must be defined for operations requiring embeddings."
      );
    }
    return await this._embeddingFunction.generate(documents);
  }
  async prepareRecords({
    recordSet,
    update = false
  }) {
    const maxBatchSize = await this.chromaClient.getMaxBatchSize();
    validateRecordSetLengthConsistency(recordSet);
    validateIDs(recordSet.ids);
    validateBaseRecordSet({ recordSet, update });
    validateMaxBatchSize(recordSet.ids.length, maxBatchSize);
    if (!recordSet.embeddings && recordSet.documents) {
      recordSet.embeddings = await this.embed(recordSet.documents);
    }
    const preparedRecordSet = { ...recordSet };
    const base64Supported = await this.chromaClient.supportsBase64Encoding();
    if (base64Supported && recordSet.embeddings) {
      preparedRecordSet.embeddings = embeddingsToBase64Bytes(
        recordSet.embeddings
      );
    }
    return preparedRecordSet;
  }
  validateGet(include, ids, where, whereDocument) {
    validateInclude({ include, exclude: ["distances"] });
    if (ids) validateIDs(ids);
    if (where) validateWhere(where);
    if (whereDocument) validateWhereDocument(whereDocument);
  }
  async prepareQuery(recordSet, include, ids, where, whereDocument, nResults) {
    validateBaseRecordSet({
      recordSet,
      embeddingsField: "queryEmbeddings",
      documentsField: "queryTexts"
    });
    validateInclude({ include });
    if (ids) validateIDs(ids);
    if (where) validateWhere(where);
    if (whereDocument) validateWhereDocument(whereDocument);
    if (nResults) validateNResults(nResults);
    let embeddings;
    if (!recordSet.embeddings) {
      embeddings = await this.embed(recordSet.documents);
    } else {
      embeddings = recordSet.embeddings;
    }
    return {
      ...recordSet,
      ids,
      embeddings
    };
  }
  validateDelete(ids, where, whereDocument) {
    if (ids) validateIDs(ids);
    if (where) validateWhere(where);
    if (whereDocument) validateWhereDocument(whereDocument);
  }
  async count() {
    const { data } = await DefaultService.collectionCount({
      client: this.apiClient,
      path: await this.path()
    });
    return data;
  }
  async add({
    ids,
    embeddings,
    metadatas,
    documents,
    uris
  }) {
    const recordSet = {
      ids,
      embeddings,
      documents,
      metadatas,
      uris
    };
    const preparedRecordSet = await this.prepareRecords({ recordSet });
    await DefaultService.collectionAdd({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids: preparedRecordSet.ids,
        embeddings: preparedRecordSet.embeddings,
        documents: preparedRecordSet.documents,
        metadatas: preparedRecordSet.metadatas,
        uris: preparedRecordSet.uris
      }
    });
  }
  async get(args = {}) {
    const {
      ids,
      where,
      limit,
      offset,
      whereDocument,
      include = ["documents", "metadatas"]
    } = args;
    this.validateGet(include, ids, where, whereDocument);
    const { data } = await DefaultService.collectionGet({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids,
        where,
        limit,
        offset,
        where_document: whereDocument,
        include
      }
    });
    return new GetResult({
      documents: data.documents ?? [],
      embeddings: data.embeddings ?? [],
      ids: data.ids,
      include: data.include,
      metadatas: data.metadatas ?? [],
      uris: data.uris ?? []
    });
  }
  async peek({ limit = 10 }) {
    return this.get({ limit });
  }
  async query({
    queryEmbeddings,
    queryTexts,
    queryURIs,
    ids,
    nResults = 10,
    where,
    whereDocument,
    include = ["metadatas", "documents", "distances"]
  }) {
    const recordSet = {
      embeddings: queryEmbeddings,
      documents: queryTexts,
      uris: queryURIs
    };
    const queryRecordSet = await this.prepareQuery(
      recordSet,
      include,
      ids,
      where,
      whereDocument,
      nResults
    );
    const { data } = await DefaultService.collectionQuery({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids: queryRecordSet.ids,
        include,
        n_results: nResults,
        query_embeddings: queryRecordSet.embeddings,
        where,
        where_document: whereDocument
      }
    });
    return new QueryResult({
      distances: data.distances ?? [],
      documents: data.documents ?? [],
      embeddings: data.embeddings ?? [],
      ids: data.ids ?? [],
      include: data.include,
      metadatas: data.metadatas ?? [],
      uris: data.uris ?? []
    });
  }
  async modify({
    name,
    metadata,
    configuration
  }) {
    if (name) this.name = name;
    if (metadata) {
      validateMetadata(metadata);
      this.metadata = metadata;
    }
    const { updateConfiguration, updateEmbeddingFunction } = configuration ? await processUpdateCollectionConfig({
      collectionName: this.name,
      currentConfiguration: this.configuration,
      newConfiguration: configuration,
      currentEmbeddingFunction: this.embeddingFunction
    }) : {};
    if (updateEmbeddingFunction) {
      this.embeddingFunction = updateEmbeddingFunction;
    }
    if (updateConfiguration) {
      this.configuration = {
        hnsw: { ...this.configuration.hnsw, ...updateConfiguration.hnsw },
        spann: { ...this.configuration.spann, ...updateConfiguration.spann },
        embeddingFunction: updateConfiguration.embedding_function
      };
    }
    await DefaultService.updateCollection({
      client: this.apiClient,
      path: await this.path(),
      body: {
        new_name: name,
        new_metadata: metadata,
        new_configuration: updateConfiguration
      }
    });
  }
  async fork({ name }) {
    const { data } = await DefaultService.forkCollection({
      client: this.apiClient,
      path: await this.path(),
      body: { new_name: name }
    });
    return new _CollectionImpl({
      chromaClient: this.chromaClient,
      apiClient: this.apiClient,
      name: data.name,
      id: data.id,
      embeddingFunction: this._embeddingFunction,
      metadata: data.metadata ?? void 0,
      configuration: data.configuration_json
    });
  }
  async update({
    ids,
    embeddings,
    metadatas,
    documents,
    uris
  }) {
    const recordSet = {
      ids,
      embeddings,
      documents,
      metadatas,
      uris
    };
    const preparedRecordSet = await this.prepareRecords({
      recordSet,
      update: true
    });
    await DefaultService.collectionUpdate({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids: preparedRecordSet.ids,
        embeddings: preparedRecordSet.embeddings,
        metadatas: preparedRecordSet.metadatas,
        uris: preparedRecordSet.uris,
        documents: preparedRecordSet.documents
      }
    });
  }
  async upsert({
    ids,
    embeddings,
    metadatas,
    documents,
    uris
  }) {
    const recordSet = {
      ids,
      embeddings,
      documents,
      metadatas,
      uris
    };
    const preparedRecordSet = await this.prepareRecords({
      recordSet
    });
    await DefaultService.collectionUpsert({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids: preparedRecordSet.ids,
        embeddings: preparedRecordSet.embeddings,
        metadatas: preparedRecordSet.metadatas,
        uris: preparedRecordSet.uris,
        documents: preparedRecordSet.documents
      }
    });
  }
  async delete({
    ids,
    where,
    whereDocument
  }) {
    this.validateDelete(ids, where, whereDocument);
    await DefaultService.collectionDelete({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids,
        where,
        where_document: whereDocument
      }
    });
  }
};

// src/next.ts
function withChroma(userNextConfig = {}) {
  const originalWebpackFunction = userNextConfig.webpack;
  const newWebpackFunction = (config, options) => {
    if (!Array.isArray(config.externals)) {
      config.externals = [];
    }
    const externalsToAdd = ["@huggingface/transformers", "chromadb"];
    for (const ext of externalsToAdd) {
      if (!config.externals.includes(ext)) {
        config.externals.push(ext);
      }
    }
    if (typeof originalWebpackFunction === "function") {
      return originalWebpackFunction(config, options);
    }
    return config;
  };
  return {
    ...userNextConfig,
    webpack: newWebpackFunction
  };
}

// src/chroma-fetch.ts
var offlineError = (error) => {
  return Boolean(
    (error?.name === "TypeError" || error?.name === "FetchError") && (error.message?.includes("fetch failed") || error.message?.includes("Failed to fetch") || error.message?.includes("ENOTFOUND"))
  );
};
var chromaFetch = async (input, init) => {
  let response;
  try {
    response = await fetch(input, init);
  } catch (err) {
    if (offlineError(err)) {
      throw new ChromaConnectionError(
        "Failed to connect to chromadb. Make sure your server is running and try again. If you are running from a browser, make sure that your chromadb instance is configured to allow requests from the current origin using the CHROMA_SERVER_CORS_ALLOW_ORIGINS environment variable."
      );
    }
    throw new ChromaConnectionError("Failed to connect to Chroma");
  }
  if (response.ok) {
    return response;
  }
  switch (response.status) {
    case 400:
      let status = "Bad Request";
      try {
        const responseBody = await response.json();
        status = responseBody.message || status;
      } catch {
      }
      throw new ChromaClientError(
        `Bad request to ${input.url || "Chroma"} with status: ${status}`
      );
    case 401:
      throw new ChromaUnauthorizedError(`Unauthorized`);
    case 403:
      throw new ChromaForbiddenError(
        `You do not have permission to access the requested resource.`
      );
    case 404:
      throw new ChromaNotFoundError(
        `The requested resource could not be found`
      );
    case 409:
      throw new ChromaUniqueError("The resource already exists");
    case 422:
      const body = await response.json();
      if (body && body.message && (body.message.startsWith("Quota exceeded") || body.message.startsWith("Billing limit exceeded"))) {
        throw new ChromaQuotaExceededError(body?.message);
      }
      break;
    case 429:
      throw new ChromaRateLimitError("Rate limit exceeded");
  }
  throw new ChromaConnectionError(
    `Unable to connect to the chromadb server (status: ${response.status}). Please try again later.`
  );
};

// src/admin-client.ts
var AdminClient = class {
  /**
   * Creates a new AdminClient instance.
   * @param args - Optional configuration for the admin client
   */
  constructor(args) {
    const { host, port, ssl, headers, fetchOptions } = args || defaultAdminClientArgs;
    const baseUrl = `${ssl ? "https" : "http"}://${host}:${port}`;
    const configOptions = {
      ...fetchOptions,
      method: normalizeMethod(fetchOptions?.method),
      baseUrl,
      headers
    };
    this.apiClient = J(w(configOptions));
    this.apiClient.setConfig({ fetch: chromaFetch });
  }
  /**
   * Creates a new database within a tenant.
   * @param options - Database creation options
   * @param options.name - Name of the database to create
   * @param options.tenant - Tenant that will own the database
   */
  async createDatabase({
    name,
    tenant
  }) {
    await DefaultService.createDatabase({
      client: this.apiClient,
      path: { tenant },
      body: { name }
    });
  }
  /**
   * Retrieves information about a specific database.
   * @param options - Database retrieval options
   * @param options.name - Name of the database to retrieve
   * @param options.tenant - Tenant that owns the database
   * @returns Promise resolving to database information
   */
  async getDatabase({
    name,
    tenant
  }) {
    const { data } = await DefaultService.getDatabase({
      client: this.apiClient,
      path: { tenant, database: name }
    });
    return data;
  }
  /**
   * Deletes a database and all its data.
   * @param options - Database deletion options
   * @param options.name - Name of the database to delete
   * @param options.tenant - Tenant that owns the database
   * @warning This operation is irreversible and will delete all data
   */
  async deleteDatabase({
    name,
    tenant
  }) {
    await DefaultService.deleteDatabase({
      client: this.apiClient,
      path: { tenant, database: name }
    });
  }
  /**
   * Lists all databases within a tenant.
   * @param args - Listing parameters including tenant and pagination
   * @returns Promise resolving to an array of database information
   */
  async listDatabases(args) {
    const { limit = 100, offset = 0, tenant } = args;
    const { data } = await DefaultService.listDatabases({
      client: this.apiClient,
      path: { tenant },
      query: { limit, offset }
    });
    return data;
  }
  /**
   * Creates a new tenant.
   * @param options - Tenant creation options
   * @param options.name - Name of the tenant to create
   */
  async createTenant({ name }) {
    await DefaultService.createTenant({
      client: this.apiClient,
      body: { name }
    });
  }
  /**
   * Retrieves information about a specific tenant.
   * @param options - Tenant retrieval options
   * @param options.name - Name of the tenant to retrieve
   * @returns Promise resolving to the tenant name
   */
  async getTenant({ name }) {
    const { data } = await DefaultService.getTenant({
      client: this.apiClient,
      path: { tenant_name: name }
    });
    return data.name;
  }
};

// src/chroma-client.ts

var ChromaClient = class {
  /**
   * Creates a new ChromaClient instance.
   * @param args - Configuration options for the client
   */
  constructor(args = {}) {
    let {
      host = defaultChromaClientArgs.host,
      port = defaultChromaClientArgs.port,
      ssl = defaultChromaClientArgs.ssl,
      tenant = defaultChromaClientArgs.tenant,
      database = defaultChromaClientArgs.database,
      headers = defaultChromaClientArgs.headers,
      fetchOptions = defaultChromaClientArgs.fetchOptions
    } = args;
    if (args.path) {
      console.warn(
        "The 'path' argument is deprecated. Please use 'ssl', 'host', and 'port' instead"
      );
      const parsedPath = parseConnectionPath(args.path);
      ssl = parsedPath.ssl;
      host = parsedPath.host;
      port = parsedPath.port;
    }
    if (args.auth) {
      console.warn(
        "The 'auth' argument is deprecated. Please use 'headers' instead"
      );
      if (!headers) {
        headers = {};
      }
      if (!headers["x-chroma-token"] && args.auth.tokenHeaderType === "X_CHROMA_TOKEN" && args.auth.credentials) {
        headers["x-chroma-token"] = args.auth.credentials;
      }
    }
    const baseUrl = `${ssl ? "https" : "http"}://${host}:${port}`;
    this._tenant = tenant || browser.env.CHROMA_TENANT;
    this._database = database || browser.env.CHROMA_DATABASE;
    const configOptions = {
      ...fetchOptions,
      method: normalizeMethod(fetchOptions?.method),
      baseUrl,
      headers
    };
    this.apiClient = J(w(configOptions));
    this.apiClient.setConfig({ fetch: chromaFetch });
  }
  /**
   * Gets the current tenant name.
   * @returns The tenant name or undefined if not set
   */
  get tenant() {
    return this._tenant;
  }
  set tenant(tenant) {
    this._tenant = tenant;
  }
  /**
   * Gets the current database name.
   * @returns The database name or undefined if not set
   */
  get database() {
    return this._database;
  }
  set database(database) {
    this._database = database;
  }
  /**
   * Gets the preflight checks
   * @returns The preflight checks or undefined if not set
   */
  get preflightChecks() {
    return this._preflightChecks;
  }
  set preflightChecks(preflightChecks) {
    this._preflightChecks = preflightChecks;
  }
  /** @ignore */
  async _path() {
    if (!this._tenant || !this._database) {
      const { tenant, databases } = await this.getUserIdentity();
      const uniqueDBs = [...new Set(databases)];
      this._tenant = tenant;
      if (uniqueDBs.length === 0) {
        throw new ChromaUnauthorizedError(
          `Your API key does not have access to any DBs for tenant ${this.tenant}`
        );
      }
      if (uniqueDBs.length > 1 || uniqueDBs[0] === "*") {
        throw new ChromaValueError(
          "Your API key is scoped to more than 1 DB. Please provide a DB name to the CloudClient constructor"
        );
      }
      this._database = uniqueDBs[0];
    }
    return { tenant: this._tenant, database: this._database };
  }
  /**
   * Gets the user identity information including tenant and accessible databases.
   * @returns Promise resolving to user identity data
   */
  async getUserIdentity() {
    const { data } = await DefaultService.getUserIdentity({
      client: this.apiClient
    });
    return data;
  }
  /**
   * Sends a heartbeat request to check server connectivity.
   * @returns Promise resolving to the server's nanosecond heartbeat timestamp
   */
  async heartbeat() {
    const { data } = await DefaultService.heartbeat({
      client: this.apiClient
    });
    return data["nanosecond heartbeat"];
  }
  /**
   * Lists all collections in the current database.
   * @param args - Optional pagination parameters
   * @param args.limit - Maximum number of collections to return (default: 100)
   * @param args.offset - Number of collections to skip (default: 0)
   * @returns Promise resolving to an array of Collection instances
   */
  async listCollections(args) {
    const { limit = 100, offset = 0 } = args || {};
    const { data } = await DefaultService.listCollections({
      client: this.apiClient,
      path: await this._path(),
      query: { limit, offset }
    });
    return Promise.all(
      data.map(
        async (collection) => new CollectionImpl({
          chromaClient: this,
          apiClient: this.apiClient,
          name: collection.name,
          id: collection.id,
          embeddingFunction: await getEmbeddingFunction(
            collection.name,
            collection.configuration_json.embedding_function ?? void 0
          ),
          configuration: collection.configuration_json,
          metadata: collection.metadata ?? void 0
        })
      )
    );
  }
  /**
   * Gets the total number of collections in the current database.
   * @returns Promise resolving to the collection count
   */
  async countCollections() {
    const { data } = await DefaultService.countCollections({
      client: this.apiClient,
      path: await this._path()
    });
    return data;
  }
  /**
   * Creates a new collection with the specified configuration.
   * @param options - Collection creation options
   * @param options.name - The name of the collection
   * @param options.configuration - Optional collection configuration
   * @param options.metadata - Optional metadata for the collection
   * @param options.embeddingFunction - Optional embedding function to use. Defaults to `DefaultEmbeddingFunction` from @chroma-core/default-embed
   * @returns Promise resolving to the created Collection instance
   * @throws Error if a collection with the same name already exists
   */
  async createCollection({
    name,
    configuration,
    metadata,
    embeddingFunction
  }) {
    const collectionConfig = await processCreateCollectionConfig({
      configuration,
      embeddingFunction,
      metadata
    });
    const { data } = await DefaultService.createCollection({
      client: this.apiClient,
      path: await this._path(),
      body: {
        name,
        configuration: collectionConfig,
        metadata,
        get_or_create: false
      }
    });
    return new CollectionImpl({
      chromaClient: this,
      apiClient: this.apiClient,
      name,
      configuration: data.configuration_json,
      metadata,
      embeddingFunction: embeddingFunction ?? await getEmbeddingFunction(
        data.name,
        data.configuration_json.embedding_function ?? void 0
      ),
      id: data.id
    });
  }
  /**
   * Retrieves an existing collection by name.
   * @param options - Collection retrieval options
   * @param options.name - The name of the collection to retrieve
   * @param options.embeddingFunction - Optional embedding function. Should match the one used to create the collection.
   * @returns Promise resolving to the Collection instance
   * @throws Error if the collection does not exist
   */
  async getCollection({
    name,
    embeddingFunction
  }) {
    const { data } = await DefaultService.getCollection({
      client: this.apiClient,
      path: { ...await this._path(), collection_id: name }
    });
    return new CollectionImpl({
      chromaClient: this,
      apiClient: this.apiClient,
      name,
      configuration: data.configuration_json,
      metadata: data.metadata ?? void 0,
      embeddingFunction: embeddingFunction ? embeddingFunction : await getEmbeddingFunction(
        data.name,
        data.configuration_json.embedding_function ?? void 0
      ),
      id: data.id
    });
  }
  /**
   * Retrieves multiple collections by name.
   * @param items - Array of collection names or objects with name and optional embedding function (should match the ones used to create the collections)
   * @returns Promise resolving to an array of Collection instances
   */
  async getCollections(items) {
    if (items.length === 0) return [];
    let requestedCollections = items;
    if (typeof items[0] === "string") {
      requestedCollections = items.map((item) => {
        return { name: item, embeddingFunction: void 0 };
      });
    }
    let collections = requestedCollections;
    return Promise.all(
      collections.map(async (collection) => {
        return this.getCollection({ ...collection });
      })
    );
  }
  /**
   * Gets an existing collection or creates it if it doesn't exist.
   * @param options - Collection options
   * @param options.name - The name of the collection
   * @param options.configuration - Optional collection configuration (used only if creating)
   * @param options.metadata - Optional metadata for the collection (used only if creating)
   * @param options.embeddingFunction - Optional embedding function to use
   * @returns Promise resolving to the Collection instance
   */
  async getOrCreateCollection({
    name,
    configuration,
    metadata,
    embeddingFunction
  }) {
    const collectionConfig = await processCreateCollectionConfig({
      configuration,
      embeddingFunction,
      metadata
    });
    const { data } = await DefaultService.createCollection({
      client: this.apiClient,
      path: await this._path(),
      body: {
        name,
        configuration: collectionConfig,
        metadata,
        get_or_create: true
      }
    });
    return new CollectionImpl({
      chromaClient: this,
      apiClient: this.apiClient,
      name,
      configuration: data.configuration_json,
      metadata: data.metadata ?? void 0,
      embeddingFunction: embeddingFunction ?? await getEmbeddingFunction(
        name,
        data.configuration_json.embedding_function ?? void 0
      ),
      id: data.id
    });
  }
  /**
   * Deletes a collection and all its data.
   * @param options - Deletion options
   * @param options.name - The name of the collection to delete
   */
  async deleteCollection({ name }) {
    await DefaultService.deleteCollection({
      client: this.apiClient,
      path: { ...await this._path(), collection_id: name }
    });
  }
  /**
   * Resets the entire database, deleting all collections and data.
   * @returns Promise that resolves when the reset is complete
   * @warning This operation is irreversible and will delete all data
   */
  async reset() {
    await DefaultService.reset({
      client: this.apiClient
    });
  }
  /**
   * Gets the version of the Chroma server.
   * @returns Promise resolving to the server version string
   */
  async version() {
    const { data } = await DefaultService.version({
      client: this.apiClient
    });
    return data;
  }
  /**
   * Gets the preflight checks
   * @returns Promise resolving to the preflight checks
   */
  async getPreflightChecks() {
    if (!this.preflightChecks) {
      const { data } = await DefaultService.preFlightChecks({
        client: this.apiClient
      });
      this.preflightChecks = data;
      return this.preflightChecks;
    }
    return this.preflightChecks;
  }
  /**
   * Gets the max batch size
   * @returns Promise resolving to the max batch size
   */
  async getMaxBatchSize() {
    const preflightChecks = await this.getPreflightChecks();
    return preflightChecks.max_batch_size ?? -1;
  }
  /**
   * Gets whether base64_encoding is supported by the connected server
   * @returns Promise resolving to whether base64_encoding is supported
   */
  async supportsBase64Encoding() {
    const preflightChecks = await this.getPreflightChecks();
    return preflightChecks.supports_base64_encoding ?? false;
  }
};

// src/cloud-client.ts

var CloudClient = class extends ChromaClient {
  /**
   * Creates a new CloudClient instance for Chroma Cloud.
   * @param args - Cloud client configuration options
   */
  constructor(args = {}) {
    const apiKey = args.apiKey || browser.env.CHROMA_API_KEY;
    if (!apiKey) {
      throw new ChromaValueError(
        "Missing API key. Please provide it to the CloudClient constructor or set your CHROMA_API_KEY environment variable"
      );
    }
    const tenant = args.tenant || browser.env.CHROMA_TENANT;
    const database = args.database || browser.env.CHROMA_DATABASE;
    super({
      host: "api.trychroma.com",
      port: 8e3,
      ssl: true,
      tenant,
      database,
      headers: { "x-chroma-token": apiKey },
      fetchOptions: args.fetchOptions
    });
    this.tenant = tenant;
    this.database = database;
  }
};
var AdminCloudClient = class extends AdminClient {
  /**
   * Creates a new AdminCloudClient instance for cloud admin operations.
   * @param args - Admin cloud client configuration options
   */
  constructor(args = {}) {
    const apiKey = args.apiKey || browser.env.CHROMA_API_KEY;
    if (!apiKey) {
      throw new ChromaValueError(
        "Missing API key. Please provide it to the CloudClient constructor or set your CHROMA_API_KEY environment variable"
      );
    }
    super({
      host: "api.trychroma.com",
      port: 8e3,
      ssl: true,
      headers: { "x-chroma-token": apiKey },
      fetchOptions: args.fetchOptions
    });
  }
};

//# sourceMappingURL=chromadb.mjs.map

/***/ }),

/***/ 5279:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  A: () => (/* binding */ esm_browser_v4)
});

;// CONCATENATED MODULE: ./node_modules/uuid/dist/esm-browser/native.js
const randomUUID = typeof crypto !== 'undefined' && crypto.randomUUID && crypto.randomUUID.bind(crypto);
/* harmony default export */ const esm_browser_native = ({ randomUUID });

;// CONCATENATED MODULE: ./node_modules/uuid/dist/esm-browser/rng.js
let getRandomValues;
const rnds8 = new Uint8Array(16);
function rng() {
    if (!getRandomValues) {
        if (typeof crypto === 'undefined' || !crypto.getRandomValues) {
            throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
        }
        getRandomValues = crypto.getRandomValues.bind(crypto);
    }
    return getRandomValues(rnds8);
}

;// CONCATENATED MODULE: ./node_modules/uuid/dist/esm-browser/stringify.js

const byteToHex = [];
for (let i = 0; i < 256; ++i) {
    byteToHex.push((i + 0x100).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
    return (byteToHex[arr[offset + 0]] +
        byteToHex[arr[offset + 1]] +
        byteToHex[arr[offset + 2]] +
        byteToHex[arr[offset + 3]] +
        '-' +
        byteToHex[arr[offset + 4]] +
        byteToHex[arr[offset + 5]] +
        '-' +
        byteToHex[arr[offset + 6]] +
        byteToHex[arr[offset + 7]] +
        '-' +
        byteToHex[arr[offset + 8]] +
        byteToHex[arr[offset + 9]] +
        '-' +
        byteToHex[arr[offset + 10]] +
        byteToHex[arr[offset + 11]] +
        byteToHex[arr[offset + 12]] +
        byteToHex[arr[offset + 13]] +
        byteToHex[arr[offset + 14]] +
        byteToHex[arr[offset + 15]]).toLowerCase();
}
function stringify(arr, offset = 0) {
    const uuid = unsafeStringify(arr, offset);
    if (!validate(uuid)) {
        throw TypeError('Stringified UUID is invalid');
    }
    return uuid;
}
/* harmony default export */ const esm_browser_stringify = ((/* unused pure expression or super */ null && (stringify)));

;// CONCATENATED MODULE: ./node_modules/uuid/dist/esm-browser/v4.js



function v4(options, buf, offset) {
    if (esm_browser_native.randomUUID && !buf && !options) {
        return esm_browser_native.randomUUID();
    }
    options = options || {};
    const rnds = options.random ?? options.rng?.() ?? rng();
    if (rnds.length < 16) {
        throw new Error('Random bytes length must be >= 16');
    }
    rnds[6] = (rnds[6] & 0x0f) | 0x40;
    rnds[8] = (rnds[8] & 0x3f) | 0x80;
    if (buf) {
        offset = offset || 0;
        if (offset < 0 || offset + 16 > buf.length) {
            throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
        for (let i = 0; i < 16; ++i) {
            buf[offset + i] = rnds[i];
        }
        return buf;
    }
    return unsafeStringify(rnds);
}
/* harmony default export */ const esm_browser_v4 = (v4);


/***/ })

}]);
//# sourceMappingURL=743.js.map