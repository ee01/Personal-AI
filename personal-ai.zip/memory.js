/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 5228:
/***/ ((module) => {

"use strict";
/*
object-assign
(c) Sindre Sorhus
@license MIT
*/


/* eslint-disable no-unused-vars */
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;

function toObject(val) {
	if (val === null || val === undefined) {
		throw new TypeError('Object.assign cannot be called with null or undefined');
	}

	return Object(val);
}

function shouldUseNative() {
	try {
		if (!Object.assign) {
			return false;
		}

		// Detect buggy property enumeration order in older V8 versions.

		// https://bugs.chromium.org/p/v8/issues/detail?id=4118
		var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
		test1[5] = 'de';
		if (Object.getOwnPropertyNames(test1)[0] === '5') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test2 = {};
		for (var i = 0; i < 10; i++) {
			test2['_' + String.fromCharCode(i)] = i;
		}
		var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
			return test2[n];
		});
		if (order2.join('') !== '0123456789') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test3 = {};
		'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
			test3[letter] = letter;
		});
		if (Object.keys(Object.assign({}, test3)).join('') !==
				'abcdefghijklmnopqrst') {
			return false;
		}

		return true;
	} catch (err) {
		// We don't expect any of the above to throw, but better to be safe.
		return false;
	}
}

module.exports = shouldUseNative() ? Object.assign : function (target, source) {
	var from;
	var to = toObject(target);
	var symbols;

	for (var s = 1; s < arguments.length; s++) {
		from = Object(arguments[s]);

		for (var key in from) {
			if (hasOwnProperty.call(from, key)) {
				to[key] = from[key];
			}
		}

		if (getOwnPropertySymbols) {
			symbols = getOwnPropertySymbols(from);
			for (var i = 0; i < symbols.length; i++) {
				if (propIsEnumerable.call(from, symbols[i])) {
					to[symbols[i]] = from[symbols[i]];
				}
			}
		}
	}

	return to;
};


/***/ }),

/***/ 5606:
/***/ ((module) => {

// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };


/***/ }),

/***/ 2551:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
var __webpack_unused_export__;
/** @license React v17.0.2
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/*
 Modernizr 3.0.0pre (Custom Build) | MIT
*/
var aa=__webpack_require__(6540),m=__webpack_require__(5228),r=__webpack_require__(9982);function y(a){for(var b="https://reactjs.org/docs/error-decoder.html?invariant="+a,c=1;c<arguments.length;c++)b+="&args[]="+encodeURIComponent(arguments[c]);return"Minified React error #"+a+"; visit "+b+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}if(!aa)throw Error(y(227));var ba=new Set,ca={};function da(a,b){ea(a,b);ea(a+"Capture",b)}
function ea(a,b){ca[a]=b;for(a=0;a<b.length;a++)ba.add(b[a])}
var fa=!("undefined"===typeof window||"undefined"===typeof window.document||"undefined"===typeof window.document.createElement),ha=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,ia=Object.prototype.hasOwnProperty,
ja={},ka={};function la(a){if(ia.call(ka,a))return!0;if(ia.call(ja,a))return!1;if(ha.test(a))return ka[a]=!0;ja[a]=!0;return!1}function ma(a,b,c,d){if(null!==c&&0===c.type)return!1;switch(typeof b){case "function":case "symbol":return!0;case "boolean":if(d)return!1;if(null!==c)return!c.acceptsBooleans;a=a.toLowerCase().slice(0,5);return"data-"!==a&&"aria-"!==a;default:return!1}}
function na(a,b,c,d){if(null===b||"undefined"===typeof b||ma(a,b,c,d))return!0;if(d)return!1;if(null!==c)switch(c.type){case 3:return!b;case 4:return!1===b;case 5:return isNaN(b);case 6:return isNaN(b)||1>b}return!1}function B(a,b,c,d,e,f,g){this.acceptsBooleans=2===b||3===b||4===b;this.attributeName=d;this.attributeNamespace=e;this.mustUseProperty=c;this.propertyName=a;this.type=b;this.sanitizeURL=f;this.removeEmptyString=g}var D={};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a){D[a]=new B(a,0,!1,a,null,!1,!1)});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(a){var b=a[0];D[b]=new B(b,1,!1,a[1],null,!1,!1)});["contentEditable","draggable","spellCheck","value"].forEach(function(a){D[a]=new B(a,2,!1,a.toLowerCase(),null,!1,!1)});
["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(a){D[a]=new B(a,2,!1,a,null,!1,!1)});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a){D[a]=new B(a,3,!1,a.toLowerCase(),null,!1,!1)});
["checked","multiple","muted","selected"].forEach(function(a){D[a]=new B(a,3,!0,a,null,!1,!1)});["capture","download"].forEach(function(a){D[a]=new B(a,4,!1,a,null,!1,!1)});["cols","rows","size","span"].forEach(function(a){D[a]=new B(a,6,!1,a,null,!1,!1)});["rowSpan","start"].forEach(function(a){D[a]=new B(a,5,!1,a.toLowerCase(),null,!1,!1)});var oa=/[\-:]([a-z])/g;function pa(a){return a[1].toUpperCase()}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a){var b=a.replace(oa,
pa);D[b]=new B(b,1,!1,a,null,!1,!1)});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a){var b=a.replace(oa,pa);D[b]=new B(b,1,!1,a,"http://www.w3.org/1999/xlink",!1,!1)});["xml:base","xml:lang","xml:space"].forEach(function(a){var b=a.replace(oa,pa);D[b]=new B(b,1,!1,a,"http://www.w3.org/XML/1998/namespace",!1,!1)});["tabIndex","crossOrigin"].forEach(function(a){D[a]=new B(a,1,!1,a.toLowerCase(),null,!1,!1)});
D.xlinkHref=new B("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);["src","href","action","formAction"].forEach(function(a){D[a]=new B(a,1,!1,a.toLowerCase(),null,!0,!0)});
function qa(a,b,c,d){var e=D.hasOwnProperty(b)?D[b]:null;var f=null!==e?0===e.type:d?!1:!(2<b.length)||"o"!==b[0]&&"O"!==b[0]||"n"!==b[1]&&"N"!==b[1]?!1:!0;f||(na(b,c,e,d)&&(c=null),d||null===e?la(b)&&(null===c?a.removeAttribute(b):a.setAttribute(b,""+c)):e.mustUseProperty?a[e.propertyName]=null===c?3===e.type?!1:"":c:(b=e.attributeName,d=e.attributeNamespace,null===c?a.removeAttribute(b):(e=e.type,c=3===e||4===e&&!0===c?"":""+c,d?a.setAttributeNS(d,b,c):a.setAttribute(b,c))))}
var ra=aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,sa=60103,ta=60106,ua=60107,wa=60108,xa=60114,ya=60109,za=60110,Aa=60112,Ba=60113,Ca=60120,Da=60115,Ea=60116,Fa=60121,Ga=60128,Ha=60129,Ia=60130,Ja=60131;
if("function"===typeof Symbol&&Symbol.for){var E=Symbol.for;sa=E("react.element");ta=E("react.portal");ua=E("react.fragment");wa=E("react.strict_mode");xa=E("react.profiler");ya=E("react.provider");za=E("react.context");Aa=E("react.forward_ref");Ba=E("react.suspense");Ca=E("react.suspense_list");Da=E("react.memo");Ea=E("react.lazy");Fa=E("react.block");E("react.scope");Ga=E("react.opaque.id");Ha=E("react.debug_trace_mode");Ia=E("react.offscreen");Ja=E("react.legacy_hidden")}
var Ka="function"===typeof Symbol&&Symbol.iterator;function La(a){if(null===a||"object"!==typeof a)return null;a=Ka&&a[Ka]||a["@@iterator"];return"function"===typeof a?a:null}var Ma;function Na(a){if(void 0===Ma)try{throw Error();}catch(c){var b=c.stack.trim().match(/\n( *(at )?)/);Ma=b&&b[1]||""}return"\n"+Ma+a}var Oa=!1;
function Pa(a,b){if(!a||Oa)return"";Oa=!0;var c=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(b)if(b=function(){throw Error();},Object.defineProperty(b.prototype,"props",{set:function(){throw Error();}}),"object"===typeof Reflect&&Reflect.construct){try{Reflect.construct(b,[])}catch(k){var d=k}Reflect.construct(a,[],b)}else{try{b.call()}catch(k){d=k}a.call(b.prototype)}else{try{throw Error();}catch(k){d=k}a()}}catch(k){if(k&&d&&"string"===typeof k.stack){for(var e=k.stack.split("\n"),
f=d.stack.split("\n"),g=e.length-1,h=f.length-1;1<=g&&0<=h&&e[g]!==f[h];)h--;for(;1<=g&&0<=h;g--,h--)if(e[g]!==f[h]){if(1!==g||1!==h){do if(g--,h--,0>h||e[g]!==f[h])return"\n"+e[g].replace(" at new "," at ");while(1<=g&&0<=h)}break}}}finally{Oa=!1,Error.prepareStackTrace=c}return(a=a?a.displayName||a.name:"")?Na(a):""}
function Qa(a){switch(a.tag){case 5:return Na(a.type);case 16:return Na("Lazy");case 13:return Na("Suspense");case 19:return Na("SuspenseList");case 0:case 2:case 15:return a=Pa(a.type,!1),a;case 11:return a=Pa(a.type.render,!1),a;case 22:return a=Pa(a.type._render,!1),a;case 1:return a=Pa(a.type,!0),a;default:return""}}
function Ra(a){if(null==a)return null;if("function"===typeof a)return a.displayName||a.name||null;if("string"===typeof a)return a;switch(a){case ua:return"Fragment";case ta:return"Portal";case xa:return"Profiler";case wa:return"StrictMode";case Ba:return"Suspense";case Ca:return"SuspenseList"}if("object"===typeof a)switch(a.$$typeof){case za:return(a.displayName||"Context")+".Consumer";case ya:return(a._context.displayName||"Context")+".Provider";case Aa:var b=a.render;b=b.displayName||b.name||"";
return a.displayName||(""!==b?"ForwardRef("+b+")":"ForwardRef");case Da:return Ra(a.type);case Fa:return Ra(a._render);case Ea:b=a._payload;a=a._init;try{return Ra(a(b))}catch(c){}}return null}function Sa(a){switch(typeof a){case "boolean":case "number":case "object":case "string":case "undefined":return a;default:return""}}function Ta(a){var b=a.type;return(a=a.nodeName)&&"input"===a.toLowerCase()&&("checkbox"===b||"radio"===b)}
function Ua(a){var b=Ta(a)?"checked":"value",c=Object.getOwnPropertyDescriptor(a.constructor.prototype,b),d=""+a[b];if(!a.hasOwnProperty(b)&&"undefined"!==typeof c&&"function"===typeof c.get&&"function"===typeof c.set){var e=c.get,f=c.set;Object.defineProperty(a,b,{configurable:!0,get:function(){return e.call(this)},set:function(a){d=""+a;f.call(this,a)}});Object.defineProperty(a,b,{enumerable:c.enumerable});return{getValue:function(){return d},setValue:function(a){d=""+a},stopTracking:function(){a._valueTracker=
null;delete a[b]}}}}function Va(a){a._valueTracker||(a._valueTracker=Ua(a))}function Wa(a){if(!a)return!1;var b=a._valueTracker;if(!b)return!0;var c=b.getValue();var d="";a&&(d=Ta(a)?a.checked?"true":"false":a.value);a=d;return a!==c?(b.setValue(a),!0):!1}function Xa(a){a=a||("undefined"!==typeof document?document:void 0);if("undefined"===typeof a)return null;try{return a.activeElement||a.body}catch(b){return a.body}}
function Ya(a,b){var c=b.checked;return m({},b,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:null!=c?c:a._wrapperState.initialChecked})}function Za(a,b){var c=null==b.defaultValue?"":b.defaultValue,d=null!=b.checked?b.checked:b.defaultChecked;c=Sa(null!=b.value?b.value:c);a._wrapperState={initialChecked:d,initialValue:c,controlled:"checkbox"===b.type||"radio"===b.type?null!=b.checked:null!=b.value}}function $a(a,b){b=b.checked;null!=b&&qa(a,"checked",b,!1)}
function ab(a,b){$a(a,b);var c=Sa(b.value),d=b.type;if(null!=c)if("number"===d){if(0===c&&""===a.value||a.value!=c)a.value=""+c}else a.value!==""+c&&(a.value=""+c);else if("submit"===d||"reset"===d){a.removeAttribute("value");return}b.hasOwnProperty("value")?bb(a,b.type,c):b.hasOwnProperty("defaultValue")&&bb(a,b.type,Sa(b.defaultValue));null==b.checked&&null!=b.defaultChecked&&(a.defaultChecked=!!b.defaultChecked)}
function cb(a,b,c){if(b.hasOwnProperty("value")||b.hasOwnProperty("defaultValue")){var d=b.type;if(!("submit"!==d&&"reset"!==d||void 0!==b.value&&null!==b.value))return;b=""+a._wrapperState.initialValue;c||b===a.value||(a.value=b);a.defaultValue=b}c=a.name;""!==c&&(a.name="");a.defaultChecked=!!a._wrapperState.initialChecked;""!==c&&(a.name=c)}
function bb(a,b,c){if("number"!==b||Xa(a.ownerDocument)!==a)null==c?a.defaultValue=""+a._wrapperState.initialValue:a.defaultValue!==""+c&&(a.defaultValue=""+c)}function db(a){var b="";aa.Children.forEach(a,function(a){null!=a&&(b+=a)});return b}function eb(a,b){a=m({children:void 0},b);if(b=db(b.children))a.children=b;return a}
function fb(a,b,c,d){a=a.options;if(b){b={};for(var e=0;e<c.length;e++)b["$"+c[e]]=!0;for(c=0;c<a.length;c++)e=b.hasOwnProperty("$"+a[c].value),a[c].selected!==e&&(a[c].selected=e),e&&d&&(a[c].defaultSelected=!0)}else{c=""+Sa(c);b=null;for(e=0;e<a.length;e++){if(a[e].value===c){a[e].selected=!0;d&&(a[e].defaultSelected=!0);return}null!==b||a[e].disabled||(b=a[e])}null!==b&&(b.selected=!0)}}
function gb(a,b){if(null!=b.dangerouslySetInnerHTML)throw Error(y(91));return m({},b,{value:void 0,defaultValue:void 0,children:""+a._wrapperState.initialValue})}function hb(a,b){var c=b.value;if(null==c){c=b.children;b=b.defaultValue;if(null!=c){if(null!=b)throw Error(y(92));if(Array.isArray(c)){if(!(1>=c.length))throw Error(y(93));c=c[0]}b=c}null==b&&(b="");c=b}a._wrapperState={initialValue:Sa(c)}}
function ib(a,b){var c=Sa(b.value),d=Sa(b.defaultValue);null!=c&&(c=""+c,c!==a.value&&(a.value=c),null==b.defaultValue&&a.defaultValue!==c&&(a.defaultValue=c));null!=d&&(a.defaultValue=""+d)}function jb(a){var b=a.textContent;b===a._wrapperState.initialValue&&""!==b&&null!==b&&(a.value=b)}var kb={html:"http://www.w3.org/1999/xhtml",mathml:"http://www.w3.org/1998/Math/MathML",svg:"http://www.w3.org/2000/svg"};
function lb(a){switch(a){case "svg":return"http://www.w3.org/2000/svg";case "math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function mb(a,b){return null==a||"http://www.w3.org/1999/xhtml"===a?lb(b):"http://www.w3.org/2000/svg"===a&&"foreignObject"===b?"http://www.w3.org/1999/xhtml":a}
var nb,ob=function(a){return"undefined"!==typeof MSApp&&MSApp.execUnsafeLocalFunction?function(b,c,d,e){MSApp.execUnsafeLocalFunction(function(){return a(b,c,d,e)})}:a}(function(a,b){if(a.namespaceURI!==kb.svg||"innerHTML"in a)a.innerHTML=b;else{nb=nb||document.createElement("div");nb.innerHTML="<svg>"+b.valueOf().toString()+"</svg>";for(b=nb.firstChild;a.firstChild;)a.removeChild(a.firstChild);for(;b.firstChild;)a.appendChild(b.firstChild)}});
function pb(a,b){if(b){var c=a.firstChild;if(c&&c===a.lastChild&&3===c.nodeType){c.nodeValue=b;return}}a.textContent=b}
var qb={animationIterationCount:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,
floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},rb=["Webkit","ms","Moz","O"];Object.keys(qb).forEach(function(a){rb.forEach(function(b){b=b+a.charAt(0).toUpperCase()+a.substring(1);qb[b]=qb[a]})});function sb(a,b,c){return null==b||"boolean"===typeof b||""===b?"":c||"number"!==typeof b||0===b||qb.hasOwnProperty(a)&&qb[a]?(""+b).trim():b+"px"}
function tb(a,b){a=a.style;for(var c in b)if(b.hasOwnProperty(c)){var d=0===c.indexOf("--"),e=sb(c,b[c],d);"float"===c&&(c="cssFloat");d?a.setProperty(c,e):a[c]=e}}var ub=m({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});
function vb(a,b){if(b){if(ub[a]&&(null!=b.children||null!=b.dangerouslySetInnerHTML))throw Error(y(137,a));if(null!=b.dangerouslySetInnerHTML){if(null!=b.children)throw Error(y(60));if(!("object"===typeof b.dangerouslySetInnerHTML&&"__html"in b.dangerouslySetInnerHTML))throw Error(y(61));}if(null!=b.style&&"object"!==typeof b.style)throw Error(y(62));}}
function wb(a,b){if(-1===a.indexOf("-"))return"string"===typeof b.is;switch(a){case "annotation-xml":case "color-profile":case "font-face":case "font-face-src":case "font-face-uri":case "font-face-format":case "font-face-name":case "missing-glyph":return!1;default:return!0}}function xb(a){a=a.target||a.srcElement||window;a.correspondingUseElement&&(a=a.correspondingUseElement);return 3===a.nodeType?a.parentNode:a}var yb=null,zb=null,Ab=null;
function Bb(a){if(a=Cb(a)){if("function"!==typeof yb)throw Error(y(280));var b=a.stateNode;b&&(b=Db(b),yb(a.stateNode,a.type,b))}}function Eb(a){zb?Ab?Ab.push(a):Ab=[a]:zb=a}function Fb(){if(zb){var a=zb,b=Ab;Ab=zb=null;Bb(a);if(b)for(a=0;a<b.length;a++)Bb(b[a])}}function Gb(a,b){return a(b)}function Hb(a,b,c,d,e){return a(b,c,d,e)}function Ib(){}var Jb=Gb,Kb=!1,Lb=!1;function Mb(){if(null!==zb||null!==Ab)Ib(),Fb()}
function Nb(a,b,c){if(Lb)return a(b,c);Lb=!0;try{return Jb(a,b,c)}finally{Lb=!1,Mb()}}
function Ob(a,b){var c=a.stateNode;if(null===c)return null;var d=Db(c);if(null===d)return null;c=d[b];a:switch(b){case "onClick":case "onClickCapture":case "onDoubleClick":case "onDoubleClickCapture":case "onMouseDown":case "onMouseDownCapture":case "onMouseMove":case "onMouseMoveCapture":case "onMouseUp":case "onMouseUpCapture":case "onMouseEnter":(d=!d.disabled)||(a=a.type,d=!("button"===a||"input"===a||"select"===a||"textarea"===a));a=!d;break a;default:a=!1}if(a)return null;if(c&&"function"!==
typeof c)throw Error(y(231,b,typeof c));return c}var Pb=!1;if(fa)try{var Qb={};Object.defineProperty(Qb,"passive",{get:function(){Pb=!0}});window.addEventListener("test",Qb,Qb);window.removeEventListener("test",Qb,Qb)}catch(a){Pb=!1}function Rb(a,b,c,d,e,f,g,h,k){var l=Array.prototype.slice.call(arguments,3);try{b.apply(c,l)}catch(n){this.onError(n)}}var Sb=!1,Tb=null,Ub=!1,Vb=null,Wb={onError:function(a){Sb=!0;Tb=a}};function Xb(a,b,c,d,e,f,g,h,k){Sb=!1;Tb=null;Rb.apply(Wb,arguments)}
function Yb(a,b,c,d,e,f,g,h,k){Xb.apply(this,arguments);if(Sb){if(Sb){var l=Tb;Sb=!1;Tb=null}else throw Error(y(198));Ub||(Ub=!0,Vb=l)}}function Zb(a){var b=a,c=a;if(a.alternate)for(;b.return;)b=b.return;else{a=b;do b=a,0!==(b.flags&1026)&&(c=b.return),a=b.return;while(a)}return 3===b.tag?c:null}function $b(a){if(13===a.tag){var b=a.memoizedState;null===b&&(a=a.alternate,null!==a&&(b=a.memoizedState));if(null!==b)return b.dehydrated}return null}function ac(a){if(Zb(a)!==a)throw Error(y(188));}
function bc(a){var b=a.alternate;if(!b){b=Zb(a);if(null===b)throw Error(y(188));return b!==a?null:a}for(var c=a,d=b;;){var e=c.return;if(null===e)break;var f=e.alternate;if(null===f){d=e.return;if(null!==d){c=d;continue}break}if(e.child===f.child){for(f=e.child;f;){if(f===c)return ac(e),a;if(f===d)return ac(e),b;f=f.sibling}throw Error(y(188));}if(c.return!==d.return)c=e,d=f;else{for(var g=!1,h=e.child;h;){if(h===c){g=!0;c=e;d=f;break}if(h===d){g=!0;d=e;c=f;break}h=h.sibling}if(!g){for(h=f.child;h;){if(h===
c){g=!0;c=f;d=e;break}if(h===d){g=!0;d=f;c=e;break}h=h.sibling}if(!g)throw Error(y(189));}}if(c.alternate!==d)throw Error(y(190));}if(3!==c.tag)throw Error(y(188));return c.stateNode.current===c?a:b}function cc(a){a=bc(a);if(!a)return null;for(var b=a;;){if(5===b.tag||6===b.tag)return b;if(b.child)b.child.return=b,b=b.child;else{if(b===a)break;for(;!b.sibling;){if(!b.return||b.return===a)return null;b=b.return}b.sibling.return=b.return;b=b.sibling}}return null}
function dc(a,b){for(var c=a.alternate;null!==b;){if(b===a||b===c)return!0;b=b.return}return!1}var ec,fc,gc,hc,ic=!1,jc=[],kc=null,lc=null,mc=null,nc=new Map,oc=new Map,pc=[],qc="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
function rc(a,b,c,d,e){return{blockedOn:a,domEventName:b,eventSystemFlags:c|16,nativeEvent:e,targetContainers:[d]}}function sc(a,b){switch(a){case "focusin":case "focusout":kc=null;break;case "dragenter":case "dragleave":lc=null;break;case "mouseover":case "mouseout":mc=null;break;case "pointerover":case "pointerout":nc.delete(b.pointerId);break;case "gotpointercapture":case "lostpointercapture":oc.delete(b.pointerId)}}
function tc(a,b,c,d,e,f){if(null===a||a.nativeEvent!==f)return a=rc(b,c,d,e,f),null!==b&&(b=Cb(b),null!==b&&fc(b)),a;a.eventSystemFlags|=d;b=a.targetContainers;null!==e&&-1===b.indexOf(e)&&b.push(e);return a}
function uc(a,b,c,d,e){switch(b){case "focusin":return kc=tc(kc,a,b,c,d,e),!0;case "dragenter":return lc=tc(lc,a,b,c,d,e),!0;case "mouseover":return mc=tc(mc,a,b,c,d,e),!0;case "pointerover":var f=e.pointerId;nc.set(f,tc(nc.get(f)||null,a,b,c,d,e));return!0;case "gotpointercapture":return f=e.pointerId,oc.set(f,tc(oc.get(f)||null,a,b,c,d,e)),!0}return!1}
function vc(a){var b=wc(a.target);if(null!==b){var c=Zb(b);if(null!==c)if(b=c.tag,13===b){if(b=$b(c),null!==b){a.blockedOn=b;hc(a.lanePriority,function(){r.unstable_runWithPriority(a.priority,function(){gc(c)})});return}}else if(3===b&&c.stateNode.hydrate){a.blockedOn=3===c.tag?c.stateNode.containerInfo:null;return}}a.blockedOn=null}
function xc(a){if(null!==a.blockedOn)return!1;for(var b=a.targetContainers;0<b.length;){var c=yc(a.domEventName,a.eventSystemFlags,b[0],a.nativeEvent);if(null!==c)return b=Cb(c),null!==b&&fc(b),a.blockedOn=c,!1;b.shift()}return!0}function zc(a,b,c){xc(a)&&c.delete(b)}
function Ac(){for(ic=!1;0<jc.length;){var a=jc[0];if(null!==a.blockedOn){a=Cb(a.blockedOn);null!==a&&ec(a);break}for(var b=a.targetContainers;0<b.length;){var c=yc(a.domEventName,a.eventSystemFlags,b[0],a.nativeEvent);if(null!==c){a.blockedOn=c;break}b.shift()}null===a.blockedOn&&jc.shift()}null!==kc&&xc(kc)&&(kc=null);null!==lc&&xc(lc)&&(lc=null);null!==mc&&xc(mc)&&(mc=null);nc.forEach(zc);oc.forEach(zc)}
function Bc(a,b){a.blockedOn===b&&(a.blockedOn=null,ic||(ic=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,Ac)))}
function Cc(a){function b(b){return Bc(b,a)}if(0<jc.length){Bc(jc[0],a);for(var c=1;c<jc.length;c++){var d=jc[c];d.blockedOn===a&&(d.blockedOn=null)}}null!==kc&&Bc(kc,a);null!==lc&&Bc(lc,a);null!==mc&&Bc(mc,a);nc.forEach(b);oc.forEach(b);for(c=0;c<pc.length;c++)d=pc[c],d.blockedOn===a&&(d.blockedOn=null);for(;0<pc.length&&(c=pc[0],null===c.blockedOn);)vc(c),null===c.blockedOn&&pc.shift()}
function Dc(a,b){var c={};c[a.toLowerCase()]=b.toLowerCase();c["Webkit"+a]="webkit"+b;c["Moz"+a]="moz"+b;return c}var Ec={animationend:Dc("Animation","AnimationEnd"),animationiteration:Dc("Animation","AnimationIteration"),animationstart:Dc("Animation","AnimationStart"),transitionend:Dc("Transition","TransitionEnd")},Fc={},Gc={};
fa&&(Gc=document.createElement("div").style,"AnimationEvent"in window||(delete Ec.animationend.animation,delete Ec.animationiteration.animation,delete Ec.animationstart.animation),"TransitionEvent"in window||delete Ec.transitionend.transition);function Hc(a){if(Fc[a])return Fc[a];if(!Ec[a])return a;var b=Ec[a],c;for(c in b)if(b.hasOwnProperty(c)&&c in Gc)return Fc[a]=b[c];return a}
var Ic=Hc("animationend"),Jc=Hc("animationiteration"),Kc=Hc("animationstart"),Lc=Hc("transitionend"),Mc=new Map,Nc=new Map,Oc=["abort","abort",Ic,"animationEnd",Jc,"animationIteration",Kc,"animationStart","canplay","canPlay","canplaythrough","canPlayThrough","durationchange","durationChange","emptied","emptied","encrypted","encrypted","ended","ended","error","error","gotpointercapture","gotPointerCapture","load","load","loadeddata","loadedData","loadedmetadata","loadedMetadata","loadstart","loadStart",
"lostpointercapture","lostPointerCapture","playing","playing","progress","progress","seeking","seeking","stalled","stalled","suspend","suspend","timeupdate","timeUpdate",Lc,"transitionEnd","waiting","waiting"];function Pc(a,b){for(var c=0;c<a.length;c+=2){var d=a[c],e=a[c+1];e="on"+(e[0].toUpperCase()+e.slice(1));Nc.set(d,b);Mc.set(d,e);da(e,[d])}}var Qc=r.unstable_now;Qc();var F=8;
function Rc(a){if(0!==(1&a))return F=15,1;if(0!==(2&a))return F=14,2;if(0!==(4&a))return F=13,4;var b=24&a;if(0!==b)return F=12,b;if(0!==(a&32))return F=11,32;b=192&a;if(0!==b)return F=10,b;if(0!==(a&256))return F=9,256;b=3584&a;if(0!==b)return F=8,b;if(0!==(a&4096))return F=7,4096;b=4186112&a;if(0!==b)return F=6,b;b=62914560&a;if(0!==b)return F=5,b;if(a&67108864)return F=4,67108864;if(0!==(a&134217728))return F=3,134217728;b=805306368&a;if(0!==b)return F=2,b;if(0!==(1073741824&a))return F=1,1073741824;
F=8;return a}function Sc(a){switch(a){case 99:return 15;case 98:return 10;case 97:case 96:return 8;case 95:return 2;default:return 0}}function Tc(a){switch(a){case 15:case 14:return 99;case 13:case 12:case 11:case 10:return 98;case 9:case 8:case 7:case 6:case 4:case 5:return 97;case 3:case 2:case 1:return 95;case 0:return 90;default:throw Error(y(358,a));}}
function Uc(a,b){var c=a.pendingLanes;if(0===c)return F=0;var d=0,e=0,f=a.expiredLanes,g=a.suspendedLanes,h=a.pingedLanes;if(0!==f)d=f,e=F=15;else if(f=c&134217727,0!==f){var k=f&~g;0!==k?(d=Rc(k),e=F):(h&=f,0!==h&&(d=Rc(h),e=F))}else f=c&~g,0!==f?(d=Rc(f),e=F):0!==h&&(d=Rc(h),e=F);if(0===d)return 0;d=31-Vc(d);d=c&((0>d?0:1<<d)<<1)-1;if(0!==b&&b!==d&&0===(b&g)){Rc(b);if(e<=F)return b;F=e}b=a.entangledLanes;if(0!==b)for(a=a.entanglements,b&=d;0<b;)c=31-Vc(b),e=1<<c,d|=a[c],b&=~e;return d}
function Wc(a){a=a.pendingLanes&-1073741825;return 0!==a?a:a&1073741824?1073741824:0}function Xc(a,b){switch(a){case 15:return 1;case 14:return 2;case 12:return a=Yc(24&~b),0===a?Xc(10,b):a;case 10:return a=Yc(192&~b),0===a?Xc(8,b):a;case 8:return a=Yc(3584&~b),0===a&&(a=Yc(4186112&~b),0===a&&(a=512)),a;case 2:return b=Yc(805306368&~b),0===b&&(b=268435456),b}throw Error(y(358,a));}function Yc(a){return a&-a}function Zc(a){for(var b=[],c=0;31>c;c++)b.push(a);return b}
function $c(a,b,c){a.pendingLanes|=b;var d=b-1;a.suspendedLanes&=d;a.pingedLanes&=d;a=a.eventTimes;b=31-Vc(b);a[b]=c}var Vc=Math.clz32?Math.clz32:ad,bd=Math.log,cd=Math.LN2;function ad(a){return 0===a?32:31-(bd(a)/cd|0)|0}var dd=r.unstable_UserBlockingPriority,ed=r.unstable_runWithPriority,fd=!0;function gd(a,b,c,d){Kb||Ib();var e=hd,f=Kb;Kb=!0;try{Hb(e,a,b,c,d)}finally{(Kb=f)||Mb()}}function id(a,b,c,d){ed(dd,hd.bind(null,a,b,c,d))}
function hd(a,b,c,d){if(fd){var e;if((e=0===(b&4))&&0<jc.length&&-1<qc.indexOf(a))a=rc(null,a,b,c,d),jc.push(a);else{var f=yc(a,b,c,d);if(null===f)e&&sc(a,d);else{if(e){if(-1<qc.indexOf(a)){a=rc(f,a,b,c,d);jc.push(a);return}if(uc(f,a,b,c,d))return;sc(a,d)}jd(a,b,d,null,c)}}}}
function yc(a,b,c,d){var e=xb(d);e=wc(e);if(null!==e){var f=Zb(e);if(null===f)e=null;else{var g=f.tag;if(13===g){e=$b(f);if(null!==e)return e;e=null}else if(3===g){if(f.stateNode.hydrate)return 3===f.tag?f.stateNode.containerInfo:null;e=null}else f!==e&&(e=null)}}jd(a,b,d,e,c);return null}var kd=null,ld=null,md=null;
function nd(){if(md)return md;var a,b=ld,c=b.length,d,e="value"in kd?kd.value:kd.textContent,f=e.length;for(a=0;a<c&&b[a]===e[a];a++);var g=c-a;for(d=1;d<=g&&b[c-d]===e[f-d];d++);return md=e.slice(a,1<d?1-d:void 0)}function od(a){var b=a.keyCode;"charCode"in a?(a=a.charCode,0===a&&13===b&&(a=13)):a=b;10===a&&(a=13);return 32<=a||13===a?a:0}function pd(){return!0}function qd(){return!1}
function rd(a){function b(b,d,e,f,g){this._reactName=b;this._targetInst=e;this.type=d;this.nativeEvent=f;this.target=g;this.currentTarget=null;for(var c in a)a.hasOwnProperty(c)&&(b=a[c],this[c]=b?b(f):f[c]);this.isDefaultPrevented=(null!=f.defaultPrevented?f.defaultPrevented:!1===f.returnValue)?pd:qd;this.isPropagationStopped=qd;return this}m(b.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():"unknown"!==typeof a.returnValue&&
(a.returnValue=!1),this.isDefaultPrevented=pd)},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():"unknown"!==typeof a.cancelBubble&&(a.cancelBubble=!0),this.isPropagationStopped=pd)},persist:function(){},isPersistent:pd});return b}
var sd={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(a){return a.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},td=rd(sd),ud=m({},sd,{view:0,detail:0}),vd=rd(ud),wd,xd,yd,Ad=m({},ud,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:zd,button:0,buttons:0,relatedTarget:function(a){return void 0===a.relatedTarget?a.fromElement===a.srcElement?a.toElement:a.fromElement:a.relatedTarget},movementX:function(a){if("movementX"in
a)return a.movementX;a!==yd&&(yd&&"mousemove"===a.type?(wd=a.screenX-yd.screenX,xd=a.screenY-yd.screenY):xd=wd=0,yd=a);return wd},movementY:function(a){return"movementY"in a?a.movementY:xd}}),Bd=rd(Ad),Cd=m({},Ad,{dataTransfer:0}),Dd=rd(Cd),Ed=m({},ud,{relatedTarget:0}),Fd=rd(Ed),Gd=m({},sd,{animationName:0,elapsedTime:0,pseudoElement:0}),Hd=rd(Gd),Id=m({},sd,{clipboardData:function(a){return"clipboardData"in a?a.clipboardData:window.clipboardData}}),Jd=rd(Id),Kd=m({},sd,{data:0}),Ld=rd(Kd),Md={Esc:"Escape",
Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Nd={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",
119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Od={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Pd(a){var b=this.nativeEvent;return b.getModifierState?b.getModifierState(a):(a=Od[a])?!!b[a]:!1}function zd(){return Pd}
var Qd=m({},ud,{key:function(a){if(a.key){var b=Md[a.key]||a.key;if("Unidentified"!==b)return b}return"keypress"===a.type?(a=od(a),13===a?"Enter":String.fromCharCode(a)):"keydown"===a.type||"keyup"===a.type?Nd[a.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:zd,charCode:function(a){return"keypress"===a.type?od(a):0},keyCode:function(a){return"keydown"===a.type||"keyup"===a.type?a.keyCode:0},which:function(a){return"keypress"===
a.type?od(a):"keydown"===a.type||"keyup"===a.type?a.keyCode:0}}),Rd=rd(Qd),Sd=m({},Ad,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Td=rd(Sd),Ud=m({},ud,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:zd}),Vd=rd(Ud),Wd=m({},sd,{propertyName:0,elapsedTime:0,pseudoElement:0}),Xd=rd(Wd),Yd=m({},Ad,{deltaX:function(a){return"deltaX"in a?a.deltaX:"wheelDeltaX"in a?-a.wheelDeltaX:0},
deltaY:function(a){return"deltaY"in a?a.deltaY:"wheelDeltaY"in a?-a.wheelDeltaY:"wheelDelta"in a?-a.wheelDelta:0},deltaZ:0,deltaMode:0}),Zd=rd(Yd),$d=[9,13,27,32],ae=fa&&"CompositionEvent"in window,be=null;fa&&"documentMode"in document&&(be=document.documentMode);var ce=fa&&"TextEvent"in window&&!be,de=fa&&(!ae||be&&8<be&&11>=be),ee=String.fromCharCode(32),fe=!1;
function ge(a,b){switch(a){case "keyup":return-1!==$d.indexOf(b.keyCode);case "keydown":return 229!==b.keyCode;case "keypress":case "mousedown":case "focusout":return!0;default:return!1}}function he(a){a=a.detail;return"object"===typeof a&&"data"in a?a.data:null}var ie=!1;function je(a,b){switch(a){case "compositionend":return he(b);case "keypress":if(32!==b.which)return null;fe=!0;return ee;case "textInput":return a=b.data,a===ee&&fe?null:a;default:return null}}
function ke(a,b){if(ie)return"compositionend"===a||!ae&&ge(a,b)?(a=nd(),md=ld=kd=null,ie=!1,a):null;switch(a){case "paste":return null;case "keypress":if(!(b.ctrlKey||b.altKey||b.metaKey)||b.ctrlKey&&b.altKey){if(b.char&&1<b.char.length)return b.char;if(b.which)return String.fromCharCode(b.which)}return null;case "compositionend":return de&&"ko"!==b.locale?null:b.data;default:return null}}
var le={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function me(a){var b=a&&a.nodeName&&a.nodeName.toLowerCase();return"input"===b?!!le[a.type]:"textarea"===b?!0:!1}function ne(a,b,c,d){Eb(d);b=oe(b,"onChange");0<b.length&&(c=new td("onChange","change",null,c,d),a.push({event:c,listeners:b}))}var pe=null,qe=null;function re(a){se(a,0)}function te(a){var b=ue(a);if(Wa(b))return a}
function ve(a,b){if("change"===a)return b}var we=!1;if(fa){var xe;if(fa){var ye="oninput"in document;if(!ye){var ze=document.createElement("div");ze.setAttribute("oninput","return;");ye="function"===typeof ze.oninput}xe=ye}else xe=!1;we=xe&&(!document.documentMode||9<document.documentMode)}function Ae(){pe&&(pe.detachEvent("onpropertychange",Be),qe=pe=null)}function Be(a){if("value"===a.propertyName&&te(qe)){var b=[];ne(b,qe,a,xb(a));a=re;if(Kb)a(b);else{Kb=!0;try{Gb(a,b)}finally{Kb=!1,Mb()}}}}
function Ce(a,b,c){"focusin"===a?(Ae(),pe=b,qe=c,pe.attachEvent("onpropertychange",Be)):"focusout"===a&&Ae()}function De(a){if("selectionchange"===a||"keyup"===a||"keydown"===a)return te(qe)}function Ee(a,b){if("click"===a)return te(b)}function Fe(a,b){if("input"===a||"change"===a)return te(b)}function Ge(a,b){return a===b&&(0!==a||1/a===1/b)||a!==a&&b!==b}var He="function"===typeof Object.is?Object.is:Ge,Ie=Object.prototype.hasOwnProperty;
function Je(a,b){if(He(a,b))return!0;if("object"!==typeof a||null===a||"object"!==typeof b||null===b)return!1;var c=Object.keys(a),d=Object.keys(b);if(c.length!==d.length)return!1;for(d=0;d<c.length;d++)if(!Ie.call(b,c[d])||!He(a[c[d]],b[c[d]]))return!1;return!0}function Ke(a){for(;a&&a.firstChild;)a=a.firstChild;return a}
function Le(a,b){var c=Ke(a);a=0;for(var d;c;){if(3===c.nodeType){d=a+c.textContent.length;if(a<=b&&d>=b)return{node:c,offset:b-a};a=d}a:{for(;c;){if(c.nextSibling){c=c.nextSibling;break a}c=c.parentNode}c=void 0}c=Ke(c)}}function Me(a,b){return a&&b?a===b?!0:a&&3===a.nodeType?!1:b&&3===b.nodeType?Me(a,b.parentNode):"contains"in a?a.contains(b):a.compareDocumentPosition?!!(a.compareDocumentPosition(b)&16):!1:!1}
function Ne(){for(var a=window,b=Xa();b instanceof a.HTMLIFrameElement;){try{var c="string"===typeof b.contentWindow.location.href}catch(d){c=!1}if(c)a=b.contentWindow;else break;b=Xa(a.document)}return b}function Oe(a){var b=a&&a.nodeName&&a.nodeName.toLowerCase();return b&&("input"===b&&("text"===a.type||"search"===a.type||"tel"===a.type||"url"===a.type||"password"===a.type)||"textarea"===b||"true"===a.contentEditable)}
var Pe=fa&&"documentMode"in document&&11>=document.documentMode,Qe=null,Re=null,Se=null,Te=!1;
function Ue(a,b,c){var d=c.window===c?c.document:9===c.nodeType?c:c.ownerDocument;Te||null==Qe||Qe!==Xa(d)||(d=Qe,"selectionStart"in d&&Oe(d)?d={start:d.selectionStart,end:d.selectionEnd}:(d=(d.ownerDocument&&d.ownerDocument.defaultView||window).getSelection(),d={anchorNode:d.anchorNode,anchorOffset:d.anchorOffset,focusNode:d.focusNode,focusOffset:d.focusOffset}),Se&&Je(Se,d)||(Se=d,d=oe(Re,"onSelect"),0<d.length&&(b=new td("onSelect","select",null,b,c),a.push({event:b,listeners:d}),b.target=Qe)))}
Pc("cancel cancel click click close close contextmenu contextMenu copy copy cut cut auxclick auxClick dblclick doubleClick dragend dragEnd dragstart dragStart drop drop focusin focus focusout blur input input invalid invalid keydown keyDown keypress keyPress keyup keyUp mousedown mouseDown mouseup mouseUp paste paste pause pause play play pointercancel pointerCancel pointerdown pointerDown pointerup pointerUp ratechange rateChange reset reset seeked seeked submit submit touchcancel touchCancel touchend touchEnd touchstart touchStart volumechange volumeChange".split(" "),
0);Pc("drag drag dragenter dragEnter dragexit dragExit dragleave dragLeave dragover dragOver mousemove mouseMove mouseout mouseOut mouseover mouseOver pointermove pointerMove pointerout pointerOut pointerover pointerOver scroll scroll toggle toggle touchmove touchMove wheel wheel".split(" "),1);Pc(Oc,2);for(var Ve="change selectionchange textInput compositionstart compositionend compositionupdate".split(" "),We=0;We<Ve.length;We++)Nc.set(Ve[We],0);ea("onMouseEnter",["mouseout","mouseover"]);
ea("onMouseLeave",["mouseout","mouseover"]);ea("onPointerEnter",["pointerout","pointerover"]);ea("onPointerLeave",["pointerout","pointerover"]);da("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));da("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));da("onBeforeInput",["compositionend","keypress","textInput","paste"]);da("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));
da("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));da("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Xe="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Ye=new Set("cancel close invalid load scroll toggle".split(" ").concat(Xe));
function Ze(a,b,c){var d=a.type||"unknown-event";a.currentTarget=c;Yb(d,b,void 0,a);a.currentTarget=null}
function se(a,b){b=0!==(b&4);for(var c=0;c<a.length;c++){var d=a[c],e=d.event;d=d.listeners;a:{var f=void 0;if(b)for(var g=d.length-1;0<=g;g--){var h=d[g],k=h.instance,l=h.currentTarget;h=h.listener;if(k!==f&&e.isPropagationStopped())break a;Ze(e,h,l);f=k}else for(g=0;g<d.length;g++){h=d[g];k=h.instance;l=h.currentTarget;h=h.listener;if(k!==f&&e.isPropagationStopped())break a;Ze(e,h,l);f=k}}}if(Ub)throw a=Vb,Ub=!1,Vb=null,a;}
function G(a,b){var c=$e(b),d=a+"__bubble";c.has(d)||(af(b,a,2,!1),c.add(d))}var bf="_reactListening"+Math.random().toString(36).slice(2);function cf(a){a[bf]||(a[bf]=!0,ba.forEach(function(b){Ye.has(b)||df(b,!1,a,null);df(b,!0,a,null)}))}
function df(a,b,c,d){var e=4<arguments.length&&void 0!==arguments[4]?arguments[4]:0,f=c;"selectionchange"===a&&9!==c.nodeType&&(f=c.ownerDocument);if(null!==d&&!b&&Ye.has(a)){if("scroll"!==a)return;e|=2;f=d}var g=$e(f),h=a+"__"+(b?"capture":"bubble");g.has(h)||(b&&(e|=4),af(f,a,e,b),g.add(h))}
function af(a,b,c,d){var e=Nc.get(b);switch(void 0===e?2:e){case 0:e=gd;break;case 1:e=id;break;default:e=hd}c=e.bind(null,b,c,a);e=void 0;!Pb||"touchstart"!==b&&"touchmove"!==b&&"wheel"!==b||(e=!0);d?void 0!==e?a.addEventListener(b,c,{capture:!0,passive:e}):a.addEventListener(b,c,!0):void 0!==e?a.addEventListener(b,c,{passive:e}):a.addEventListener(b,c,!1)}
function jd(a,b,c,d,e){var f=d;if(0===(b&1)&&0===(b&2)&&null!==d)a:for(;;){if(null===d)return;var g=d.tag;if(3===g||4===g){var h=d.stateNode.containerInfo;if(h===e||8===h.nodeType&&h.parentNode===e)break;if(4===g)for(g=d.return;null!==g;){var k=g.tag;if(3===k||4===k)if(k=g.stateNode.containerInfo,k===e||8===k.nodeType&&k.parentNode===e)return;g=g.return}for(;null!==h;){g=wc(h);if(null===g)return;k=g.tag;if(5===k||6===k){d=f=g;continue a}h=h.parentNode}}d=d.return}Nb(function(){var d=f,e=xb(c),g=[];
a:{var h=Mc.get(a);if(void 0!==h){var k=td,x=a;switch(a){case "keypress":if(0===od(c))break a;case "keydown":case "keyup":k=Rd;break;case "focusin":x="focus";k=Fd;break;case "focusout":x="blur";k=Fd;break;case "beforeblur":case "afterblur":k=Fd;break;case "click":if(2===c.button)break a;case "auxclick":case "dblclick":case "mousedown":case "mousemove":case "mouseup":case "mouseout":case "mouseover":case "contextmenu":k=Bd;break;case "drag":case "dragend":case "dragenter":case "dragexit":case "dragleave":case "dragover":case "dragstart":case "drop":k=
Dd;break;case "touchcancel":case "touchend":case "touchmove":case "touchstart":k=Vd;break;case Ic:case Jc:case Kc:k=Hd;break;case Lc:k=Xd;break;case "scroll":k=vd;break;case "wheel":k=Zd;break;case "copy":case "cut":case "paste":k=Jd;break;case "gotpointercapture":case "lostpointercapture":case "pointercancel":case "pointerdown":case "pointermove":case "pointerout":case "pointerover":case "pointerup":k=Td}var w=0!==(b&4),z=!w&&"scroll"===a,u=w?null!==h?h+"Capture":null:h;w=[];for(var t=d,q;null!==
t;){q=t;var v=q.stateNode;5===q.tag&&null!==v&&(q=v,null!==u&&(v=Ob(t,u),null!=v&&w.push(ef(t,v,q))));if(z)break;t=t.return}0<w.length&&(h=new k(h,x,null,c,e),g.push({event:h,listeners:w}))}}if(0===(b&7)){a:{h="mouseover"===a||"pointerover"===a;k="mouseout"===a||"pointerout"===a;if(h&&0===(b&16)&&(x=c.relatedTarget||c.fromElement)&&(wc(x)||x[ff]))break a;if(k||h){h=e.window===e?e:(h=e.ownerDocument)?h.defaultView||h.parentWindow:window;if(k){if(x=c.relatedTarget||c.toElement,k=d,x=x?wc(x):null,null!==
x&&(z=Zb(x),x!==z||5!==x.tag&&6!==x.tag))x=null}else k=null,x=d;if(k!==x){w=Bd;v="onMouseLeave";u="onMouseEnter";t="mouse";if("pointerout"===a||"pointerover"===a)w=Td,v="onPointerLeave",u="onPointerEnter",t="pointer";z=null==k?h:ue(k);q=null==x?h:ue(x);h=new w(v,t+"leave",k,c,e);h.target=z;h.relatedTarget=q;v=null;wc(e)===d&&(w=new w(u,t+"enter",x,c,e),w.target=q,w.relatedTarget=z,v=w);z=v;if(k&&x)b:{w=k;u=x;t=0;for(q=w;q;q=gf(q))t++;q=0;for(v=u;v;v=gf(v))q++;for(;0<t-q;)w=gf(w),t--;for(;0<q-t;)u=
gf(u),q--;for(;t--;){if(w===u||null!==u&&w===u.alternate)break b;w=gf(w);u=gf(u)}w=null}else w=null;null!==k&&hf(g,h,k,w,!1);null!==x&&null!==z&&hf(g,z,x,w,!0)}}}a:{h=d?ue(d):window;k=h.nodeName&&h.nodeName.toLowerCase();if("select"===k||"input"===k&&"file"===h.type)var J=ve;else if(me(h))if(we)J=Fe;else{J=De;var K=Ce}else(k=h.nodeName)&&"input"===k.toLowerCase()&&("checkbox"===h.type||"radio"===h.type)&&(J=Ee);if(J&&(J=J(a,d))){ne(g,J,c,e);break a}K&&K(a,h,d);"focusout"===a&&(K=h._wrapperState)&&
K.controlled&&"number"===h.type&&bb(h,"number",h.value)}K=d?ue(d):window;switch(a){case "focusin":if(me(K)||"true"===K.contentEditable)Qe=K,Re=d,Se=null;break;case "focusout":Se=Re=Qe=null;break;case "mousedown":Te=!0;break;case "contextmenu":case "mouseup":case "dragend":Te=!1;Ue(g,c,e);break;case "selectionchange":if(Pe)break;case "keydown":case "keyup":Ue(g,c,e)}var Q;if(ae)b:{switch(a){case "compositionstart":var L="onCompositionStart";break b;case "compositionend":L="onCompositionEnd";break b;
case "compositionupdate":L="onCompositionUpdate";break b}L=void 0}else ie?ge(a,c)&&(L="onCompositionEnd"):"keydown"===a&&229===c.keyCode&&(L="onCompositionStart");L&&(de&&"ko"!==c.locale&&(ie||"onCompositionStart"!==L?"onCompositionEnd"===L&&ie&&(Q=nd()):(kd=e,ld="value"in kd?kd.value:kd.textContent,ie=!0)),K=oe(d,L),0<K.length&&(L=new Ld(L,a,null,c,e),g.push({event:L,listeners:K}),Q?L.data=Q:(Q=he(c),null!==Q&&(L.data=Q))));if(Q=ce?je(a,c):ke(a,c))d=oe(d,"onBeforeInput"),0<d.length&&(e=new Ld("onBeforeInput",
"beforeinput",null,c,e),g.push({event:e,listeners:d}),e.data=Q)}se(g,b)})}function ef(a,b,c){return{instance:a,listener:b,currentTarget:c}}function oe(a,b){for(var c=b+"Capture",d=[];null!==a;){var e=a,f=e.stateNode;5===e.tag&&null!==f&&(e=f,f=Ob(a,c),null!=f&&d.unshift(ef(a,f,e)),f=Ob(a,b),null!=f&&d.push(ef(a,f,e)));a=a.return}return d}function gf(a){if(null===a)return null;do a=a.return;while(a&&5!==a.tag);return a?a:null}
function hf(a,b,c,d,e){for(var f=b._reactName,g=[];null!==c&&c!==d;){var h=c,k=h.alternate,l=h.stateNode;if(null!==k&&k===d)break;5===h.tag&&null!==l&&(h=l,e?(k=Ob(c,f),null!=k&&g.unshift(ef(c,k,h))):e||(k=Ob(c,f),null!=k&&g.push(ef(c,k,h))));c=c.return}0!==g.length&&a.push({event:b,listeners:g})}function jf(){}var kf=null,lf=null;function mf(a,b){switch(a){case "button":case "input":case "select":case "textarea":return!!b.autoFocus}return!1}
function nf(a,b){return"textarea"===a||"option"===a||"noscript"===a||"string"===typeof b.children||"number"===typeof b.children||"object"===typeof b.dangerouslySetInnerHTML&&null!==b.dangerouslySetInnerHTML&&null!=b.dangerouslySetInnerHTML.__html}var of="function"===typeof setTimeout?setTimeout:void 0,pf="function"===typeof clearTimeout?clearTimeout:void 0;function qf(a){1===a.nodeType?a.textContent="":9===a.nodeType&&(a=a.body,null!=a&&(a.textContent=""))}
function rf(a){for(;null!=a;a=a.nextSibling){var b=a.nodeType;if(1===b||3===b)break}return a}function sf(a){a=a.previousSibling;for(var b=0;a;){if(8===a.nodeType){var c=a.data;if("$"===c||"$!"===c||"$?"===c){if(0===b)return a;b--}else"/$"===c&&b++}a=a.previousSibling}return null}var tf=0;function uf(a){return{$$typeof:Ga,toString:a,valueOf:a}}var vf=Math.random().toString(36).slice(2),wf="__reactFiber$"+vf,xf="__reactProps$"+vf,ff="__reactContainer$"+vf,yf="__reactEvents$"+vf;
function wc(a){var b=a[wf];if(b)return b;for(var c=a.parentNode;c;){if(b=c[ff]||c[wf]){c=b.alternate;if(null!==b.child||null!==c&&null!==c.child)for(a=sf(a);null!==a;){if(c=a[wf])return c;a=sf(a)}return b}a=c;c=a.parentNode}return null}function Cb(a){a=a[wf]||a[ff];return!a||5!==a.tag&&6!==a.tag&&13!==a.tag&&3!==a.tag?null:a}function ue(a){if(5===a.tag||6===a.tag)return a.stateNode;throw Error(y(33));}function Db(a){return a[xf]||null}
function $e(a){var b=a[yf];void 0===b&&(b=a[yf]=new Set);return b}var zf=[],Af=-1;function Bf(a){return{current:a}}function H(a){0>Af||(a.current=zf[Af],zf[Af]=null,Af--)}function I(a,b){Af++;zf[Af]=a.current;a.current=b}var Cf={},M=Bf(Cf),N=Bf(!1),Df=Cf;
function Ef(a,b){var c=a.type.contextTypes;if(!c)return Cf;var d=a.stateNode;if(d&&d.__reactInternalMemoizedUnmaskedChildContext===b)return d.__reactInternalMemoizedMaskedChildContext;var e={},f;for(f in c)e[f]=b[f];d&&(a=a.stateNode,a.__reactInternalMemoizedUnmaskedChildContext=b,a.__reactInternalMemoizedMaskedChildContext=e);return e}function Ff(a){a=a.childContextTypes;return null!==a&&void 0!==a}function Gf(){H(N);H(M)}function Hf(a,b,c){if(M.current!==Cf)throw Error(y(168));I(M,b);I(N,c)}
function If(a,b,c){var d=a.stateNode;a=b.childContextTypes;if("function"!==typeof d.getChildContext)return c;d=d.getChildContext();for(var e in d)if(!(e in a))throw Error(y(108,Ra(b)||"Unknown",e));return m({},c,d)}function Jf(a){a=(a=a.stateNode)&&a.__reactInternalMemoizedMergedChildContext||Cf;Df=M.current;I(M,a);I(N,N.current);return!0}function Kf(a,b,c){var d=a.stateNode;if(!d)throw Error(y(169));c?(a=If(a,b,Df),d.__reactInternalMemoizedMergedChildContext=a,H(N),H(M),I(M,a)):H(N);I(N,c)}
var Lf=null,Mf=null,Nf=r.unstable_runWithPriority,Of=r.unstable_scheduleCallback,Pf=r.unstable_cancelCallback,Qf=r.unstable_shouldYield,Rf=r.unstable_requestPaint,Sf=r.unstable_now,Tf=r.unstable_getCurrentPriorityLevel,Uf=r.unstable_ImmediatePriority,Vf=r.unstable_UserBlockingPriority,Wf=r.unstable_NormalPriority,Xf=r.unstable_LowPriority,Yf=r.unstable_IdlePriority,Zf={},$f=void 0!==Rf?Rf:function(){},ag=null,bg=null,cg=!1,dg=Sf(),O=1E4>dg?Sf:function(){return Sf()-dg};
function eg(){switch(Tf()){case Uf:return 99;case Vf:return 98;case Wf:return 97;case Xf:return 96;case Yf:return 95;default:throw Error(y(332));}}function fg(a){switch(a){case 99:return Uf;case 98:return Vf;case 97:return Wf;case 96:return Xf;case 95:return Yf;default:throw Error(y(332));}}function gg(a,b){a=fg(a);return Nf(a,b)}function hg(a,b,c){a=fg(a);return Of(a,b,c)}function ig(){if(null!==bg){var a=bg;bg=null;Pf(a)}jg()}
function jg(){if(!cg&&null!==ag){cg=!0;var a=0;try{var b=ag;gg(99,function(){for(;a<b.length;a++){var c=b[a];do c=c(!0);while(null!==c)}});ag=null}catch(c){throw null!==ag&&(ag=ag.slice(a+1)),Of(Uf,ig),c;}finally{cg=!1}}}var kg=ra.ReactCurrentBatchConfig;function lg(a,b){if(a&&a.defaultProps){b=m({},b);a=a.defaultProps;for(var c in a)void 0===b[c]&&(b[c]=a[c]);return b}return b}var mg=Bf(null),ng=null,og=null,pg=null;function qg(){pg=og=ng=null}
function rg(a){var b=mg.current;H(mg);a.type._context._currentValue=b}function sg(a,b){for(;null!==a;){var c=a.alternate;if((a.childLanes&b)===b)if(null===c||(c.childLanes&b)===b)break;else c.childLanes|=b;else a.childLanes|=b,null!==c&&(c.childLanes|=b);a=a.return}}function tg(a,b){ng=a;pg=og=null;a=a.dependencies;null!==a&&null!==a.firstContext&&(0!==(a.lanes&b)&&(ug=!0),a.firstContext=null)}
function vg(a,b){if(pg!==a&&!1!==b&&0!==b){if("number"!==typeof b||1073741823===b)pg=a,b=1073741823;b={context:a,observedBits:b,next:null};if(null===og){if(null===ng)throw Error(y(308));og=b;ng.dependencies={lanes:0,firstContext:b,responders:null}}else og=og.next=b}return a._currentValue}var wg=!1;function xg(a){a.updateQueue={baseState:a.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null},effects:null}}
function yg(a,b){a=a.updateQueue;b.updateQueue===a&&(b.updateQueue={baseState:a.baseState,firstBaseUpdate:a.firstBaseUpdate,lastBaseUpdate:a.lastBaseUpdate,shared:a.shared,effects:a.effects})}function zg(a,b){return{eventTime:a,lane:b,tag:0,payload:null,callback:null,next:null}}function Ag(a,b){a=a.updateQueue;if(null!==a){a=a.shared;var c=a.pending;null===c?b.next=b:(b.next=c.next,c.next=b);a.pending=b}}
function Bg(a,b){var c=a.updateQueue,d=a.alternate;if(null!==d&&(d=d.updateQueue,c===d)){var e=null,f=null;c=c.firstBaseUpdate;if(null!==c){do{var g={eventTime:c.eventTime,lane:c.lane,tag:c.tag,payload:c.payload,callback:c.callback,next:null};null===f?e=f=g:f=f.next=g;c=c.next}while(null!==c);null===f?e=f=b:f=f.next=b}else e=f=b;c={baseState:d.baseState,firstBaseUpdate:e,lastBaseUpdate:f,shared:d.shared,effects:d.effects};a.updateQueue=c;return}a=c.lastBaseUpdate;null===a?c.firstBaseUpdate=b:a.next=
b;c.lastBaseUpdate=b}
function Cg(a,b,c,d){var e=a.updateQueue;wg=!1;var f=e.firstBaseUpdate,g=e.lastBaseUpdate,h=e.shared.pending;if(null!==h){e.shared.pending=null;var k=h,l=k.next;k.next=null;null===g?f=l:g.next=l;g=k;var n=a.alternate;if(null!==n){n=n.updateQueue;var A=n.lastBaseUpdate;A!==g&&(null===A?n.firstBaseUpdate=l:A.next=l,n.lastBaseUpdate=k)}}if(null!==f){A=e.baseState;g=0;n=l=k=null;do{h=f.lane;var p=f.eventTime;if((d&h)===h){null!==n&&(n=n.next={eventTime:p,lane:0,tag:f.tag,payload:f.payload,callback:f.callback,
next:null});a:{var C=a,x=f;h=b;p=c;switch(x.tag){case 1:C=x.payload;if("function"===typeof C){A=C.call(p,A,h);break a}A=C;break a;case 3:C.flags=C.flags&-4097|64;case 0:C=x.payload;h="function"===typeof C?C.call(p,A,h):C;if(null===h||void 0===h)break a;A=m({},A,h);break a;case 2:wg=!0}}null!==f.callback&&(a.flags|=32,h=e.effects,null===h?e.effects=[f]:h.push(f))}else p={eventTime:p,lane:h,tag:f.tag,payload:f.payload,callback:f.callback,next:null},null===n?(l=n=p,k=A):n=n.next=p,g|=h;f=f.next;if(null===
f)if(h=e.shared.pending,null===h)break;else f=h.next,h.next=null,e.lastBaseUpdate=h,e.shared.pending=null}while(1);null===n&&(k=A);e.baseState=k;e.firstBaseUpdate=l;e.lastBaseUpdate=n;Dg|=g;a.lanes=g;a.memoizedState=A}}function Eg(a,b,c){a=b.effects;b.effects=null;if(null!==a)for(b=0;b<a.length;b++){var d=a[b],e=d.callback;if(null!==e){d.callback=null;d=c;if("function"!==typeof e)throw Error(y(191,e));e.call(d)}}}var Fg=(new aa.Component).refs;
function Gg(a,b,c,d){b=a.memoizedState;c=c(d,b);c=null===c||void 0===c?b:m({},b,c);a.memoizedState=c;0===a.lanes&&(a.updateQueue.baseState=c)}
var Kg={isMounted:function(a){return(a=a._reactInternals)?Zb(a)===a:!1},enqueueSetState:function(a,b,c){a=a._reactInternals;var d=Hg(),e=Ig(a),f=zg(d,e);f.payload=b;void 0!==c&&null!==c&&(f.callback=c);Ag(a,f);Jg(a,e,d)},enqueueReplaceState:function(a,b,c){a=a._reactInternals;var d=Hg(),e=Ig(a),f=zg(d,e);f.tag=1;f.payload=b;void 0!==c&&null!==c&&(f.callback=c);Ag(a,f);Jg(a,e,d)},enqueueForceUpdate:function(a,b){a=a._reactInternals;var c=Hg(),d=Ig(a),e=zg(c,d);e.tag=2;void 0!==b&&null!==b&&(e.callback=
b);Ag(a,e);Jg(a,d,c)}};function Lg(a,b,c,d,e,f,g){a=a.stateNode;return"function"===typeof a.shouldComponentUpdate?a.shouldComponentUpdate(d,f,g):b.prototype&&b.prototype.isPureReactComponent?!Je(c,d)||!Je(e,f):!0}
function Mg(a,b,c){var d=!1,e=Cf;var f=b.contextType;"object"===typeof f&&null!==f?f=vg(f):(e=Ff(b)?Df:M.current,d=b.contextTypes,f=(d=null!==d&&void 0!==d)?Ef(a,e):Cf);b=new b(c,f);a.memoizedState=null!==b.state&&void 0!==b.state?b.state:null;b.updater=Kg;a.stateNode=b;b._reactInternals=a;d&&(a=a.stateNode,a.__reactInternalMemoizedUnmaskedChildContext=e,a.__reactInternalMemoizedMaskedChildContext=f);return b}
function Ng(a,b,c,d){a=b.state;"function"===typeof b.componentWillReceiveProps&&b.componentWillReceiveProps(c,d);"function"===typeof b.UNSAFE_componentWillReceiveProps&&b.UNSAFE_componentWillReceiveProps(c,d);b.state!==a&&Kg.enqueueReplaceState(b,b.state,null)}
function Og(a,b,c,d){var e=a.stateNode;e.props=c;e.state=a.memoizedState;e.refs=Fg;xg(a);var f=b.contextType;"object"===typeof f&&null!==f?e.context=vg(f):(f=Ff(b)?Df:M.current,e.context=Ef(a,f));Cg(a,c,e,d);e.state=a.memoizedState;f=b.getDerivedStateFromProps;"function"===typeof f&&(Gg(a,b,f,c),e.state=a.memoizedState);"function"===typeof b.getDerivedStateFromProps||"function"===typeof e.getSnapshotBeforeUpdate||"function"!==typeof e.UNSAFE_componentWillMount&&"function"!==typeof e.componentWillMount||
(b=e.state,"function"===typeof e.componentWillMount&&e.componentWillMount(),"function"===typeof e.UNSAFE_componentWillMount&&e.UNSAFE_componentWillMount(),b!==e.state&&Kg.enqueueReplaceState(e,e.state,null),Cg(a,c,e,d),e.state=a.memoizedState);"function"===typeof e.componentDidMount&&(a.flags|=4)}var Pg=Array.isArray;
function Qg(a,b,c){a=c.ref;if(null!==a&&"function"!==typeof a&&"object"!==typeof a){if(c._owner){c=c._owner;if(c){if(1!==c.tag)throw Error(y(309));var d=c.stateNode}if(!d)throw Error(y(147,a));var e=""+a;if(null!==b&&null!==b.ref&&"function"===typeof b.ref&&b.ref._stringRef===e)return b.ref;b=function(a){var b=d.refs;b===Fg&&(b=d.refs={});null===a?delete b[e]:b[e]=a};b._stringRef=e;return b}if("string"!==typeof a)throw Error(y(284));if(!c._owner)throw Error(y(290,a));}return a}
function Rg(a,b){if("textarea"!==a.type)throw Error(y(31,"[object Object]"===Object.prototype.toString.call(b)?"object with keys {"+Object.keys(b).join(", ")+"}":b));}
function Sg(a){function b(b,c){if(a){var d=b.lastEffect;null!==d?(d.nextEffect=c,b.lastEffect=c):b.firstEffect=b.lastEffect=c;c.nextEffect=null;c.flags=8}}function c(c,d){if(!a)return null;for(;null!==d;)b(c,d),d=d.sibling;return null}function d(a,b){for(a=new Map;null!==b;)null!==b.key?a.set(b.key,b):a.set(b.index,b),b=b.sibling;return a}function e(a,b){a=Tg(a,b);a.index=0;a.sibling=null;return a}function f(b,c,d){b.index=d;if(!a)return c;d=b.alternate;if(null!==d)return d=d.index,d<c?(b.flags=2,
c):d;b.flags=2;return c}function g(b){a&&null===b.alternate&&(b.flags=2);return b}function h(a,b,c,d){if(null===b||6!==b.tag)return b=Ug(c,a.mode,d),b.return=a,b;b=e(b,c);b.return=a;return b}function k(a,b,c,d){if(null!==b&&b.elementType===c.type)return d=e(b,c.props),d.ref=Qg(a,b,c),d.return=a,d;d=Vg(c.type,c.key,c.props,null,a.mode,d);d.ref=Qg(a,b,c);d.return=a;return d}function l(a,b,c,d){if(null===b||4!==b.tag||b.stateNode.containerInfo!==c.containerInfo||b.stateNode.implementation!==c.implementation)return b=
Wg(c,a.mode,d),b.return=a,b;b=e(b,c.children||[]);b.return=a;return b}function n(a,b,c,d,f){if(null===b||7!==b.tag)return b=Xg(c,a.mode,d,f),b.return=a,b;b=e(b,c);b.return=a;return b}function A(a,b,c){if("string"===typeof b||"number"===typeof b)return b=Ug(""+b,a.mode,c),b.return=a,b;if("object"===typeof b&&null!==b){switch(b.$$typeof){case sa:return c=Vg(b.type,b.key,b.props,null,a.mode,c),c.ref=Qg(a,null,b),c.return=a,c;case ta:return b=Wg(b,a.mode,c),b.return=a,b}if(Pg(b)||La(b))return b=Xg(b,
a.mode,c,null),b.return=a,b;Rg(a,b)}return null}function p(a,b,c,d){var e=null!==b?b.key:null;if("string"===typeof c||"number"===typeof c)return null!==e?null:h(a,b,""+c,d);if("object"===typeof c&&null!==c){switch(c.$$typeof){case sa:return c.key===e?c.type===ua?n(a,b,c.props.children,d,e):k(a,b,c,d):null;case ta:return c.key===e?l(a,b,c,d):null}if(Pg(c)||La(c))return null!==e?null:n(a,b,c,d,null);Rg(a,c)}return null}function C(a,b,c,d,e){if("string"===typeof d||"number"===typeof d)return a=a.get(c)||
null,h(b,a,""+d,e);if("object"===typeof d&&null!==d){switch(d.$$typeof){case sa:return a=a.get(null===d.key?c:d.key)||null,d.type===ua?n(b,a,d.props.children,e,d.key):k(b,a,d,e);case ta:return a=a.get(null===d.key?c:d.key)||null,l(b,a,d,e)}if(Pg(d)||La(d))return a=a.get(c)||null,n(b,a,d,e,null);Rg(b,d)}return null}function x(e,g,h,k){for(var l=null,t=null,u=g,z=g=0,q=null;null!==u&&z<h.length;z++){u.index>z?(q=u,u=null):q=u.sibling;var n=p(e,u,h[z],k);if(null===n){null===u&&(u=q);break}a&&u&&null===
n.alternate&&b(e,u);g=f(n,g,z);null===t?l=n:t.sibling=n;t=n;u=q}if(z===h.length)return c(e,u),l;if(null===u){for(;z<h.length;z++)u=A(e,h[z],k),null!==u&&(g=f(u,g,z),null===t?l=u:t.sibling=u,t=u);return l}for(u=d(e,u);z<h.length;z++)q=C(u,e,z,h[z],k),null!==q&&(a&&null!==q.alternate&&u.delete(null===q.key?z:q.key),g=f(q,g,z),null===t?l=q:t.sibling=q,t=q);a&&u.forEach(function(a){return b(e,a)});return l}function w(e,g,h,k){var l=La(h);if("function"!==typeof l)throw Error(y(150));h=l.call(h);if(null==
h)throw Error(y(151));for(var t=l=null,u=g,z=g=0,q=null,n=h.next();null!==u&&!n.done;z++,n=h.next()){u.index>z?(q=u,u=null):q=u.sibling;var w=p(e,u,n.value,k);if(null===w){null===u&&(u=q);break}a&&u&&null===w.alternate&&b(e,u);g=f(w,g,z);null===t?l=w:t.sibling=w;t=w;u=q}if(n.done)return c(e,u),l;if(null===u){for(;!n.done;z++,n=h.next())n=A(e,n.value,k),null!==n&&(g=f(n,g,z),null===t?l=n:t.sibling=n,t=n);return l}for(u=d(e,u);!n.done;z++,n=h.next())n=C(u,e,z,n.value,k),null!==n&&(a&&null!==n.alternate&&
u.delete(null===n.key?z:n.key),g=f(n,g,z),null===t?l=n:t.sibling=n,t=n);a&&u.forEach(function(a){return b(e,a)});return l}return function(a,d,f,h){var k="object"===typeof f&&null!==f&&f.type===ua&&null===f.key;k&&(f=f.props.children);var l="object"===typeof f&&null!==f;if(l)switch(f.$$typeof){case sa:a:{l=f.key;for(k=d;null!==k;){if(k.key===l){switch(k.tag){case 7:if(f.type===ua){c(a,k.sibling);d=e(k,f.props.children);d.return=a;a=d;break a}break;default:if(k.elementType===f.type){c(a,k.sibling);
d=e(k,f.props);d.ref=Qg(a,k,f);d.return=a;a=d;break a}}c(a,k);break}else b(a,k);k=k.sibling}f.type===ua?(d=Xg(f.props.children,a.mode,h,f.key),d.return=a,a=d):(h=Vg(f.type,f.key,f.props,null,a.mode,h),h.ref=Qg(a,d,f),h.return=a,a=h)}return g(a);case ta:a:{for(k=f.key;null!==d;){if(d.key===k)if(4===d.tag&&d.stateNode.containerInfo===f.containerInfo&&d.stateNode.implementation===f.implementation){c(a,d.sibling);d=e(d,f.children||[]);d.return=a;a=d;break a}else{c(a,d);break}else b(a,d);d=d.sibling}d=
Wg(f,a.mode,h);d.return=a;a=d}return g(a)}if("string"===typeof f||"number"===typeof f)return f=""+f,null!==d&&6===d.tag?(c(a,d.sibling),d=e(d,f),d.return=a,a=d):(c(a,d),d=Ug(f,a.mode,h),d.return=a,a=d),g(a);if(Pg(f))return x(a,d,f,h);if(La(f))return w(a,d,f,h);l&&Rg(a,f);if("undefined"===typeof f&&!k)switch(a.tag){case 1:case 22:case 0:case 11:case 15:throw Error(y(152,Ra(a.type)||"Component"));}return c(a,d)}}var Yg=Sg(!0),Zg=Sg(!1),$g={},ah=Bf($g),bh=Bf($g),ch=Bf($g);
function dh(a){if(a===$g)throw Error(y(174));return a}function eh(a,b){I(ch,b);I(bh,a);I(ah,$g);a=b.nodeType;switch(a){case 9:case 11:b=(b=b.documentElement)?b.namespaceURI:mb(null,"");break;default:a=8===a?b.parentNode:b,b=a.namespaceURI||null,a=a.tagName,b=mb(b,a)}H(ah);I(ah,b)}function fh(){H(ah);H(bh);H(ch)}function gh(a){dh(ch.current);var b=dh(ah.current);var c=mb(b,a.type);b!==c&&(I(bh,a),I(ah,c))}function hh(a){bh.current===a&&(H(ah),H(bh))}var P=Bf(0);
function ih(a){for(var b=a;null!==b;){if(13===b.tag){var c=b.memoizedState;if(null!==c&&(c=c.dehydrated,null===c||"$?"===c.data||"$!"===c.data))return b}else if(19===b.tag&&void 0!==b.memoizedProps.revealOrder){if(0!==(b.flags&64))return b}else if(null!==b.child){b.child.return=b;b=b.child;continue}if(b===a)break;for(;null===b.sibling;){if(null===b.return||b.return===a)return null;b=b.return}b.sibling.return=b.return;b=b.sibling}return null}var jh=null,kh=null,lh=!1;
function mh(a,b){var c=nh(5,null,null,0);c.elementType="DELETED";c.type="DELETED";c.stateNode=b;c.return=a;c.flags=8;null!==a.lastEffect?(a.lastEffect.nextEffect=c,a.lastEffect=c):a.firstEffect=a.lastEffect=c}function oh(a,b){switch(a.tag){case 5:var c=a.type;b=1!==b.nodeType||c.toLowerCase()!==b.nodeName.toLowerCase()?null:b;return null!==b?(a.stateNode=b,!0):!1;case 6:return b=""===a.pendingProps||3!==b.nodeType?null:b,null!==b?(a.stateNode=b,!0):!1;case 13:return!1;default:return!1}}
function ph(a){if(lh){var b=kh;if(b){var c=b;if(!oh(a,b)){b=rf(c.nextSibling);if(!b||!oh(a,b)){a.flags=a.flags&-1025|2;lh=!1;jh=a;return}mh(jh,c)}jh=a;kh=rf(b.firstChild)}else a.flags=a.flags&-1025|2,lh=!1,jh=a}}function qh(a){for(a=a.return;null!==a&&5!==a.tag&&3!==a.tag&&13!==a.tag;)a=a.return;jh=a}
function rh(a){if(a!==jh)return!1;if(!lh)return qh(a),lh=!0,!1;var b=a.type;if(5!==a.tag||"head"!==b&&"body"!==b&&!nf(b,a.memoizedProps))for(b=kh;b;)mh(a,b),b=rf(b.nextSibling);qh(a);if(13===a.tag){a=a.memoizedState;a=null!==a?a.dehydrated:null;if(!a)throw Error(y(317));a:{a=a.nextSibling;for(b=0;a;){if(8===a.nodeType){var c=a.data;if("/$"===c){if(0===b){kh=rf(a.nextSibling);break a}b--}else"$"!==c&&"$!"!==c&&"$?"!==c||b++}a=a.nextSibling}kh=null}}else kh=jh?rf(a.stateNode.nextSibling):null;return!0}
function sh(){kh=jh=null;lh=!1}var th=[];function uh(){for(var a=0;a<th.length;a++)th[a]._workInProgressVersionPrimary=null;th.length=0}var vh=ra.ReactCurrentDispatcher,wh=ra.ReactCurrentBatchConfig,xh=0,R=null,S=null,T=null,yh=!1,zh=!1;function Ah(){throw Error(y(321));}function Bh(a,b){if(null===b)return!1;for(var c=0;c<b.length&&c<a.length;c++)if(!He(a[c],b[c]))return!1;return!0}
function Ch(a,b,c,d,e,f){xh=f;R=b;b.memoizedState=null;b.updateQueue=null;b.lanes=0;vh.current=null===a||null===a.memoizedState?Dh:Eh;a=c(d,e);if(zh){f=0;do{zh=!1;if(!(25>f))throw Error(y(301));f+=1;T=S=null;b.updateQueue=null;vh.current=Fh;a=c(d,e)}while(zh)}vh.current=Gh;b=null!==S&&null!==S.next;xh=0;T=S=R=null;yh=!1;if(b)throw Error(y(300));return a}function Hh(){var a={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};null===T?R.memoizedState=T=a:T=T.next=a;return T}
function Ih(){if(null===S){var a=R.alternate;a=null!==a?a.memoizedState:null}else a=S.next;var b=null===T?R.memoizedState:T.next;if(null!==b)T=b,S=a;else{if(null===a)throw Error(y(310));S=a;a={memoizedState:S.memoizedState,baseState:S.baseState,baseQueue:S.baseQueue,queue:S.queue,next:null};null===T?R.memoizedState=T=a:T=T.next=a}return T}function Jh(a,b){return"function"===typeof b?b(a):b}
function Kh(a){var b=Ih(),c=b.queue;if(null===c)throw Error(y(311));c.lastRenderedReducer=a;var d=S,e=d.baseQueue,f=c.pending;if(null!==f){if(null!==e){var g=e.next;e.next=f.next;f.next=g}d.baseQueue=e=f;c.pending=null}if(null!==e){e=e.next;d=d.baseState;var h=g=f=null,k=e;do{var l=k.lane;if((xh&l)===l)null!==h&&(h=h.next={lane:0,action:k.action,eagerReducer:k.eagerReducer,eagerState:k.eagerState,next:null}),d=k.eagerReducer===a?k.eagerState:a(d,k.action);else{var n={lane:l,action:k.action,eagerReducer:k.eagerReducer,
eagerState:k.eagerState,next:null};null===h?(g=h=n,f=d):h=h.next=n;R.lanes|=l;Dg|=l}k=k.next}while(null!==k&&k!==e);null===h?f=d:h.next=g;He(d,b.memoizedState)||(ug=!0);b.memoizedState=d;b.baseState=f;b.baseQueue=h;c.lastRenderedState=d}return[b.memoizedState,c.dispatch]}
function Lh(a){var b=Ih(),c=b.queue;if(null===c)throw Error(y(311));c.lastRenderedReducer=a;var d=c.dispatch,e=c.pending,f=b.memoizedState;if(null!==e){c.pending=null;var g=e=e.next;do f=a(f,g.action),g=g.next;while(g!==e);He(f,b.memoizedState)||(ug=!0);b.memoizedState=f;null===b.baseQueue&&(b.baseState=f);c.lastRenderedState=f}return[f,d]}
function Mh(a,b,c){var d=b._getVersion;d=d(b._source);var e=b._workInProgressVersionPrimary;if(null!==e)a=e===d;else if(a=a.mutableReadLanes,a=(xh&a)===a)b._workInProgressVersionPrimary=d,th.push(b);if(a)return c(b._source);th.push(b);throw Error(y(350));}
function Nh(a,b,c,d){var e=U;if(null===e)throw Error(y(349));var f=b._getVersion,g=f(b._source),h=vh.current,k=h.useState(function(){return Mh(e,b,c)}),l=k[1],n=k[0];k=T;var A=a.memoizedState,p=A.refs,C=p.getSnapshot,x=A.source;A=A.subscribe;var w=R;a.memoizedState={refs:p,source:b,subscribe:d};h.useEffect(function(){p.getSnapshot=c;p.setSnapshot=l;var a=f(b._source);if(!He(g,a)){a=c(b._source);He(n,a)||(l(a),a=Ig(w),e.mutableReadLanes|=a&e.pendingLanes);a=e.mutableReadLanes;e.entangledLanes|=a;for(var d=
e.entanglements,h=a;0<h;){var k=31-Vc(h),v=1<<k;d[k]|=a;h&=~v}}},[c,b,d]);h.useEffect(function(){return d(b._source,function(){var a=p.getSnapshot,c=p.setSnapshot;try{c(a(b._source));var d=Ig(w);e.mutableReadLanes|=d&e.pendingLanes}catch(q){c(function(){throw q;})}})},[b,d]);He(C,c)&&He(x,b)&&He(A,d)||(a={pending:null,dispatch:null,lastRenderedReducer:Jh,lastRenderedState:n},a.dispatch=l=Oh.bind(null,R,a),k.queue=a,k.baseQueue=null,n=Mh(e,b,c),k.memoizedState=k.baseState=n);return n}
function Ph(a,b,c){var d=Ih();return Nh(d,a,b,c)}function Qh(a){var b=Hh();"function"===typeof a&&(a=a());b.memoizedState=b.baseState=a;a=b.queue={pending:null,dispatch:null,lastRenderedReducer:Jh,lastRenderedState:a};a=a.dispatch=Oh.bind(null,R,a);return[b.memoizedState,a]}
function Rh(a,b,c,d){a={tag:a,create:b,destroy:c,deps:d,next:null};b=R.updateQueue;null===b?(b={lastEffect:null},R.updateQueue=b,b.lastEffect=a.next=a):(c=b.lastEffect,null===c?b.lastEffect=a.next=a:(d=c.next,c.next=a,a.next=d,b.lastEffect=a));return a}function Sh(a){var b=Hh();a={current:a};return b.memoizedState=a}function Th(){return Ih().memoizedState}function Uh(a,b,c,d){var e=Hh();R.flags|=a;e.memoizedState=Rh(1|b,c,void 0,void 0===d?null:d)}
function Vh(a,b,c,d){var e=Ih();d=void 0===d?null:d;var f=void 0;if(null!==S){var g=S.memoizedState;f=g.destroy;if(null!==d&&Bh(d,g.deps)){Rh(b,c,f,d);return}}R.flags|=a;e.memoizedState=Rh(1|b,c,f,d)}function Wh(a,b){return Uh(516,4,a,b)}function Xh(a,b){return Vh(516,4,a,b)}function Yh(a,b){return Vh(4,2,a,b)}function Zh(a,b){if("function"===typeof b)return a=a(),b(a),function(){b(null)};if(null!==b&&void 0!==b)return a=a(),b.current=a,function(){b.current=null}}
function $h(a,b,c){c=null!==c&&void 0!==c?c.concat([a]):null;return Vh(4,2,Zh.bind(null,b,a),c)}function ai(){}function bi(a,b){var c=Ih();b=void 0===b?null:b;var d=c.memoizedState;if(null!==d&&null!==b&&Bh(b,d[1]))return d[0];c.memoizedState=[a,b];return a}function ci(a,b){var c=Ih();b=void 0===b?null:b;var d=c.memoizedState;if(null!==d&&null!==b&&Bh(b,d[1]))return d[0];a=a();c.memoizedState=[a,b];return a}
function di(a,b){var c=eg();gg(98>c?98:c,function(){a(!0)});gg(97<c?97:c,function(){var c=wh.transition;wh.transition=1;try{a(!1),b()}finally{wh.transition=c}})}
function Oh(a,b,c){var d=Hg(),e=Ig(a),f={lane:e,action:c,eagerReducer:null,eagerState:null,next:null},g=b.pending;null===g?f.next=f:(f.next=g.next,g.next=f);b.pending=f;g=a.alternate;if(a===R||null!==g&&g===R)zh=yh=!0;else{if(0===a.lanes&&(null===g||0===g.lanes)&&(g=b.lastRenderedReducer,null!==g))try{var h=b.lastRenderedState,k=g(h,c);f.eagerReducer=g;f.eagerState=k;if(He(k,h))return}catch(l){}finally{}Jg(a,e,d)}}
var Gh={readContext:vg,useCallback:Ah,useContext:Ah,useEffect:Ah,useImperativeHandle:Ah,useLayoutEffect:Ah,useMemo:Ah,useReducer:Ah,useRef:Ah,useState:Ah,useDebugValue:Ah,useDeferredValue:Ah,useTransition:Ah,useMutableSource:Ah,useOpaqueIdentifier:Ah,unstable_isNewReconciler:!1},Dh={readContext:vg,useCallback:function(a,b){Hh().memoizedState=[a,void 0===b?null:b];return a},useContext:vg,useEffect:Wh,useImperativeHandle:function(a,b,c){c=null!==c&&void 0!==c?c.concat([a]):null;return Uh(4,2,Zh.bind(null,
b,a),c)},useLayoutEffect:function(a,b){return Uh(4,2,a,b)},useMemo:function(a,b){var c=Hh();b=void 0===b?null:b;a=a();c.memoizedState=[a,b];return a},useReducer:function(a,b,c){var d=Hh();b=void 0!==c?c(b):b;d.memoizedState=d.baseState=b;a=d.queue={pending:null,dispatch:null,lastRenderedReducer:a,lastRenderedState:b};a=a.dispatch=Oh.bind(null,R,a);return[d.memoizedState,a]},useRef:Sh,useState:Qh,useDebugValue:ai,useDeferredValue:function(a){var b=Qh(a),c=b[0],d=b[1];Wh(function(){var b=wh.transition;
wh.transition=1;try{d(a)}finally{wh.transition=b}},[a]);return c},useTransition:function(){var a=Qh(!1),b=a[0];a=di.bind(null,a[1]);Sh(a);return[a,b]},useMutableSource:function(a,b,c){var d=Hh();d.memoizedState={refs:{getSnapshot:b,setSnapshot:null},source:a,subscribe:c};return Nh(d,a,b,c)},useOpaqueIdentifier:function(){if(lh){var a=!1,b=uf(function(){a||(a=!0,c("r:"+(tf++).toString(36)));throw Error(y(355));}),c=Qh(b)[1];0===(R.mode&2)&&(R.flags|=516,Rh(5,function(){c("r:"+(tf++).toString(36))},
void 0,null));return b}b="r:"+(tf++).toString(36);Qh(b);return b},unstable_isNewReconciler:!1},Eh={readContext:vg,useCallback:bi,useContext:vg,useEffect:Xh,useImperativeHandle:$h,useLayoutEffect:Yh,useMemo:ci,useReducer:Kh,useRef:Th,useState:function(){return Kh(Jh)},useDebugValue:ai,useDeferredValue:function(a){var b=Kh(Jh),c=b[0],d=b[1];Xh(function(){var b=wh.transition;wh.transition=1;try{d(a)}finally{wh.transition=b}},[a]);return c},useTransition:function(){var a=Kh(Jh)[0];return[Th().current,
a]},useMutableSource:Ph,useOpaqueIdentifier:function(){return Kh(Jh)[0]},unstable_isNewReconciler:!1},Fh={readContext:vg,useCallback:bi,useContext:vg,useEffect:Xh,useImperativeHandle:$h,useLayoutEffect:Yh,useMemo:ci,useReducer:Lh,useRef:Th,useState:function(){return Lh(Jh)},useDebugValue:ai,useDeferredValue:function(a){var b=Lh(Jh),c=b[0],d=b[1];Xh(function(){var b=wh.transition;wh.transition=1;try{d(a)}finally{wh.transition=b}},[a]);return c},useTransition:function(){var a=Lh(Jh)[0];return[Th().current,
a]},useMutableSource:Ph,useOpaqueIdentifier:function(){return Lh(Jh)[0]},unstable_isNewReconciler:!1},ei=ra.ReactCurrentOwner,ug=!1;function fi(a,b,c,d){b.child=null===a?Zg(b,null,c,d):Yg(b,a.child,c,d)}function gi(a,b,c,d,e){c=c.render;var f=b.ref;tg(b,e);d=Ch(a,b,c,d,f,e);if(null!==a&&!ug)return b.updateQueue=a.updateQueue,b.flags&=-517,a.lanes&=~e,hi(a,b,e);b.flags|=1;fi(a,b,d,e);return b.child}
function ii(a,b,c,d,e,f){if(null===a){var g=c.type;if("function"===typeof g&&!ji(g)&&void 0===g.defaultProps&&null===c.compare&&void 0===c.defaultProps)return b.tag=15,b.type=g,ki(a,b,g,d,e,f);a=Vg(c.type,null,d,b,b.mode,f);a.ref=b.ref;a.return=b;return b.child=a}g=a.child;if(0===(e&f)&&(e=g.memoizedProps,c=c.compare,c=null!==c?c:Je,c(e,d)&&a.ref===b.ref))return hi(a,b,f);b.flags|=1;a=Tg(g,d);a.ref=b.ref;a.return=b;return b.child=a}
function ki(a,b,c,d,e,f){if(null!==a&&Je(a.memoizedProps,d)&&a.ref===b.ref)if(ug=!1,0!==(f&e))0!==(a.flags&16384)&&(ug=!0);else return b.lanes=a.lanes,hi(a,b,f);return li(a,b,c,d,f)}
function mi(a,b,c){var d=b.pendingProps,e=d.children,f=null!==a?a.memoizedState:null;if("hidden"===d.mode||"unstable-defer-without-hiding"===d.mode)if(0===(b.mode&4))b.memoizedState={baseLanes:0},ni(b,c);else if(0!==(c&1073741824))b.memoizedState={baseLanes:0},ni(b,null!==f?f.baseLanes:c);else return a=null!==f?f.baseLanes|c:c,b.lanes=b.childLanes=1073741824,b.memoizedState={baseLanes:a},ni(b,a),null;else null!==f?(d=f.baseLanes|c,b.memoizedState=null):d=c,ni(b,d);fi(a,b,e,c);return b.child}
function oi(a,b){var c=b.ref;if(null===a&&null!==c||null!==a&&a.ref!==c)b.flags|=128}function li(a,b,c,d,e){var f=Ff(c)?Df:M.current;f=Ef(b,f);tg(b,e);c=Ch(a,b,c,d,f,e);if(null!==a&&!ug)return b.updateQueue=a.updateQueue,b.flags&=-517,a.lanes&=~e,hi(a,b,e);b.flags|=1;fi(a,b,c,e);return b.child}
function pi(a,b,c,d,e){if(Ff(c)){var f=!0;Jf(b)}else f=!1;tg(b,e);if(null===b.stateNode)null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2),Mg(b,c,d),Og(b,c,d,e),d=!0;else if(null===a){var g=b.stateNode,h=b.memoizedProps;g.props=h;var k=g.context,l=c.contextType;"object"===typeof l&&null!==l?l=vg(l):(l=Ff(c)?Df:M.current,l=Ef(b,l));var n=c.getDerivedStateFromProps,A="function"===typeof n||"function"===typeof g.getSnapshotBeforeUpdate;A||"function"!==typeof g.UNSAFE_componentWillReceiveProps&&
"function"!==typeof g.componentWillReceiveProps||(h!==d||k!==l)&&Ng(b,g,d,l);wg=!1;var p=b.memoizedState;g.state=p;Cg(b,d,g,e);k=b.memoizedState;h!==d||p!==k||N.current||wg?("function"===typeof n&&(Gg(b,c,n,d),k=b.memoizedState),(h=wg||Lg(b,c,h,d,p,k,l))?(A||"function"!==typeof g.UNSAFE_componentWillMount&&"function"!==typeof g.componentWillMount||("function"===typeof g.componentWillMount&&g.componentWillMount(),"function"===typeof g.UNSAFE_componentWillMount&&g.UNSAFE_componentWillMount()),"function"===
typeof g.componentDidMount&&(b.flags|=4)):("function"===typeof g.componentDidMount&&(b.flags|=4),b.memoizedProps=d,b.memoizedState=k),g.props=d,g.state=k,g.context=l,d=h):("function"===typeof g.componentDidMount&&(b.flags|=4),d=!1)}else{g=b.stateNode;yg(a,b);h=b.memoizedProps;l=b.type===b.elementType?h:lg(b.type,h);g.props=l;A=b.pendingProps;p=g.context;k=c.contextType;"object"===typeof k&&null!==k?k=vg(k):(k=Ff(c)?Df:M.current,k=Ef(b,k));var C=c.getDerivedStateFromProps;(n="function"===typeof C||
"function"===typeof g.getSnapshotBeforeUpdate)||"function"!==typeof g.UNSAFE_componentWillReceiveProps&&"function"!==typeof g.componentWillReceiveProps||(h!==A||p!==k)&&Ng(b,g,d,k);wg=!1;p=b.memoizedState;g.state=p;Cg(b,d,g,e);var x=b.memoizedState;h!==A||p!==x||N.current||wg?("function"===typeof C&&(Gg(b,c,C,d),x=b.memoizedState),(l=wg||Lg(b,c,l,d,p,x,k))?(n||"function"!==typeof g.UNSAFE_componentWillUpdate&&"function"!==typeof g.componentWillUpdate||("function"===typeof g.componentWillUpdate&&g.componentWillUpdate(d,
x,k),"function"===typeof g.UNSAFE_componentWillUpdate&&g.UNSAFE_componentWillUpdate(d,x,k)),"function"===typeof g.componentDidUpdate&&(b.flags|=4),"function"===typeof g.getSnapshotBeforeUpdate&&(b.flags|=256)):("function"!==typeof g.componentDidUpdate||h===a.memoizedProps&&p===a.memoizedState||(b.flags|=4),"function"!==typeof g.getSnapshotBeforeUpdate||h===a.memoizedProps&&p===a.memoizedState||(b.flags|=256),b.memoizedProps=d,b.memoizedState=x),g.props=d,g.state=x,g.context=k,d=l):("function"!==typeof g.componentDidUpdate||
h===a.memoizedProps&&p===a.memoizedState||(b.flags|=4),"function"!==typeof g.getSnapshotBeforeUpdate||h===a.memoizedProps&&p===a.memoizedState||(b.flags|=256),d=!1)}return qi(a,b,c,d,f,e)}
function qi(a,b,c,d,e,f){oi(a,b);var g=0!==(b.flags&64);if(!d&&!g)return e&&Kf(b,c,!1),hi(a,b,f);d=b.stateNode;ei.current=b;var h=g&&"function"!==typeof c.getDerivedStateFromError?null:d.render();b.flags|=1;null!==a&&g?(b.child=Yg(b,a.child,null,f),b.child=Yg(b,null,h,f)):fi(a,b,h,f);b.memoizedState=d.state;e&&Kf(b,c,!0);return b.child}function ri(a){var b=a.stateNode;b.pendingContext?Hf(a,b.pendingContext,b.pendingContext!==b.context):b.context&&Hf(a,b.context,!1);eh(a,b.containerInfo)}
var si={dehydrated:null,retryLane:0};
function ti(a,b,c){var d=b.pendingProps,e=P.current,f=!1,g;(g=0!==(b.flags&64))||(g=null!==a&&null===a.memoizedState?!1:0!==(e&2));g?(f=!0,b.flags&=-65):null!==a&&null===a.memoizedState||void 0===d.fallback||!0===d.unstable_avoidThisFallback||(e|=1);I(P,e&1);if(null===a){void 0!==d.fallback&&ph(b);a=d.children;e=d.fallback;if(f)return a=ui(b,a,e,c),b.child.memoizedState={baseLanes:c},b.memoizedState=si,a;if("number"===typeof d.unstable_expectedLoadTime)return a=ui(b,a,e,c),b.child.memoizedState={baseLanes:c},
b.memoizedState=si,b.lanes=33554432,a;c=vi({mode:"visible",children:a},b.mode,c,null);c.return=b;return b.child=c}if(null!==a.memoizedState){if(f)return d=wi(a,b,d.children,d.fallback,c),f=b.child,e=a.child.memoizedState,f.memoizedState=null===e?{baseLanes:c}:{baseLanes:e.baseLanes|c},f.childLanes=a.childLanes&~c,b.memoizedState=si,d;c=xi(a,b,d.children,c);b.memoizedState=null;return c}if(f)return d=wi(a,b,d.children,d.fallback,c),f=b.child,e=a.child.memoizedState,f.memoizedState=null===e?{baseLanes:c}:
{baseLanes:e.baseLanes|c},f.childLanes=a.childLanes&~c,b.memoizedState=si,d;c=xi(a,b,d.children,c);b.memoizedState=null;return c}function ui(a,b,c,d){var e=a.mode,f=a.child;b={mode:"hidden",children:b};0===(e&2)&&null!==f?(f.childLanes=0,f.pendingProps=b):f=vi(b,e,0,null);c=Xg(c,e,d,null);f.return=a;c.return=a;f.sibling=c;a.child=f;return c}
function xi(a,b,c,d){var e=a.child;a=e.sibling;c=Tg(e,{mode:"visible",children:c});0===(b.mode&2)&&(c.lanes=d);c.return=b;c.sibling=null;null!==a&&(a.nextEffect=null,a.flags=8,b.firstEffect=b.lastEffect=a);return b.child=c}
function wi(a,b,c,d,e){var f=b.mode,g=a.child;a=g.sibling;var h={mode:"hidden",children:c};0===(f&2)&&b.child!==g?(c=b.child,c.childLanes=0,c.pendingProps=h,g=c.lastEffect,null!==g?(b.firstEffect=c.firstEffect,b.lastEffect=g,g.nextEffect=null):b.firstEffect=b.lastEffect=null):c=Tg(g,h);null!==a?d=Tg(a,d):(d=Xg(d,f,e,null),d.flags|=2);d.return=b;c.return=b;c.sibling=d;b.child=c;return d}function yi(a,b){a.lanes|=b;var c=a.alternate;null!==c&&(c.lanes|=b);sg(a.return,b)}
function zi(a,b,c,d,e,f){var g=a.memoizedState;null===g?a.memoizedState={isBackwards:b,rendering:null,renderingStartTime:0,last:d,tail:c,tailMode:e,lastEffect:f}:(g.isBackwards=b,g.rendering=null,g.renderingStartTime=0,g.last=d,g.tail=c,g.tailMode=e,g.lastEffect=f)}
function Ai(a,b,c){var d=b.pendingProps,e=d.revealOrder,f=d.tail;fi(a,b,d.children,c);d=P.current;if(0!==(d&2))d=d&1|2,b.flags|=64;else{if(null!==a&&0!==(a.flags&64))a:for(a=b.child;null!==a;){if(13===a.tag)null!==a.memoizedState&&yi(a,c);else if(19===a.tag)yi(a,c);else if(null!==a.child){a.child.return=a;a=a.child;continue}if(a===b)break a;for(;null===a.sibling;){if(null===a.return||a.return===b)break a;a=a.return}a.sibling.return=a.return;a=a.sibling}d&=1}I(P,d);if(0===(b.mode&2))b.memoizedState=
null;else switch(e){case "forwards":c=b.child;for(e=null;null!==c;)a=c.alternate,null!==a&&null===ih(a)&&(e=c),c=c.sibling;c=e;null===c?(e=b.child,b.child=null):(e=c.sibling,c.sibling=null);zi(b,!1,e,c,f,b.lastEffect);break;case "backwards":c=null;e=b.child;for(b.child=null;null!==e;){a=e.alternate;if(null!==a&&null===ih(a)){b.child=e;break}a=e.sibling;e.sibling=c;c=e;e=a}zi(b,!0,c,null,f,b.lastEffect);break;case "together":zi(b,!1,null,null,void 0,b.lastEffect);break;default:b.memoizedState=null}return b.child}
function hi(a,b,c){null!==a&&(b.dependencies=a.dependencies);Dg|=b.lanes;if(0!==(c&b.childLanes)){if(null!==a&&b.child!==a.child)throw Error(y(153));if(null!==b.child){a=b.child;c=Tg(a,a.pendingProps);b.child=c;for(c.return=b;null!==a.sibling;)a=a.sibling,c=c.sibling=Tg(a,a.pendingProps),c.return=b;c.sibling=null}return b.child}return null}var Bi,Ci,Di,Ei;
Bi=function(a,b){for(var c=b.child;null!==c;){if(5===c.tag||6===c.tag)a.appendChild(c.stateNode);else if(4!==c.tag&&null!==c.child){c.child.return=c;c=c.child;continue}if(c===b)break;for(;null===c.sibling;){if(null===c.return||c.return===b)return;c=c.return}c.sibling.return=c.return;c=c.sibling}};Ci=function(){};
Di=function(a,b,c,d){var e=a.memoizedProps;if(e!==d){a=b.stateNode;dh(ah.current);var f=null;switch(c){case "input":e=Ya(a,e);d=Ya(a,d);f=[];break;case "option":e=eb(a,e);d=eb(a,d);f=[];break;case "select":e=m({},e,{value:void 0});d=m({},d,{value:void 0});f=[];break;case "textarea":e=gb(a,e);d=gb(a,d);f=[];break;default:"function"!==typeof e.onClick&&"function"===typeof d.onClick&&(a.onclick=jf)}vb(c,d);var g;c=null;for(l in e)if(!d.hasOwnProperty(l)&&e.hasOwnProperty(l)&&null!=e[l])if("style"===
l){var h=e[l];for(g in h)h.hasOwnProperty(g)&&(c||(c={}),c[g]="")}else"dangerouslySetInnerHTML"!==l&&"children"!==l&&"suppressContentEditableWarning"!==l&&"suppressHydrationWarning"!==l&&"autoFocus"!==l&&(ca.hasOwnProperty(l)?f||(f=[]):(f=f||[]).push(l,null));for(l in d){var k=d[l];h=null!=e?e[l]:void 0;if(d.hasOwnProperty(l)&&k!==h&&(null!=k||null!=h))if("style"===l)if(h){for(g in h)!h.hasOwnProperty(g)||k&&k.hasOwnProperty(g)||(c||(c={}),c[g]="");for(g in k)k.hasOwnProperty(g)&&h[g]!==k[g]&&(c||
(c={}),c[g]=k[g])}else c||(f||(f=[]),f.push(l,c)),c=k;else"dangerouslySetInnerHTML"===l?(k=k?k.__html:void 0,h=h?h.__html:void 0,null!=k&&h!==k&&(f=f||[]).push(l,k)):"children"===l?"string"!==typeof k&&"number"!==typeof k||(f=f||[]).push(l,""+k):"suppressContentEditableWarning"!==l&&"suppressHydrationWarning"!==l&&(ca.hasOwnProperty(l)?(null!=k&&"onScroll"===l&&G("scroll",a),f||h===k||(f=[])):"object"===typeof k&&null!==k&&k.$$typeof===Ga?k.toString():(f=f||[]).push(l,k))}c&&(f=f||[]).push("style",
c);var l=f;if(b.updateQueue=l)b.flags|=4}};Ei=function(a,b,c,d){c!==d&&(b.flags|=4)};function Fi(a,b){if(!lh)switch(a.tailMode){case "hidden":b=a.tail;for(var c=null;null!==b;)null!==b.alternate&&(c=b),b=b.sibling;null===c?a.tail=null:c.sibling=null;break;case "collapsed":c=a.tail;for(var d=null;null!==c;)null!==c.alternate&&(d=c),c=c.sibling;null===d?b||null===a.tail?a.tail=null:a.tail.sibling=null:d.sibling=null}}
function Gi(a,b,c){var d=b.pendingProps;switch(b.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return null;case 1:return Ff(b.type)&&Gf(),null;case 3:fh();H(N);H(M);uh();d=b.stateNode;d.pendingContext&&(d.context=d.pendingContext,d.pendingContext=null);if(null===a||null===a.child)rh(b)?b.flags|=4:d.hydrate||(b.flags|=256);Ci(b);return null;case 5:hh(b);var e=dh(ch.current);c=b.type;if(null!==a&&null!=b.stateNode)Di(a,b,c,d,e),a.ref!==b.ref&&(b.flags|=128);else{if(!d){if(null===
b.stateNode)throw Error(y(166));return null}a=dh(ah.current);if(rh(b)){d=b.stateNode;c=b.type;var f=b.memoizedProps;d[wf]=b;d[xf]=f;switch(c){case "dialog":G("cancel",d);G("close",d);break;case "iframe":case "object":case "embed":G("load",d);break;case "video":case "audio":for(a=0;a<Xe.length;a++)G(Xe[a],d);break;case "source":G("error",d);break;case "img":case "image":case "link":G("error",d);G("load",d);break;case "details":G("toggle",d);break;case "input":Za(d,f);G("invalid",d);break;case "select":d._wrapperState=
{wasMultiple:!!f.multiple};G("invalid",d);break;case "textarea":hb(d,f),G("invalid",d)}vb(c,f);a=null;for(var g in f)f.hasOwnProperty(g)&&(e=f[g],"children"===g?"string"===typeof e?d.textContent!==e&&(a=["children",e]):"number"===typeof e&&d.textContent!==""+e&&(a=["children",""+e]):ca.hasOwnProperty(g)&&null!=e&&"onScroll"===g&&G("scroll",d));switch(c){case "input":Va(d);cb(d,f,!0);break;case "textarea":Va(d);jb(d);break;case "select":case "option":break;default:"function"===typeof f.onClick&&(d.onclick=
jf)}d=a;b.updateQueue=d;null!==d&&(b.flags|=4)}else{g=9===e.nodeType?e:e.ownerDocument;a===kb.html&&(a=lb(c));a===kb.html?"script"===c?(a=g.createElement("div"),a.innerHTML="<script>\x3c/script>",a=a.removeChild(a.firstChild)):"string"===typeof d.is?a=g.createElement(c,{is:d.is}):(a=g.createElement(c),"select"===c&&(g=a,d.multiple?g.multiple=!0:d.size&&(g.size=d.size))):a=g.createElementNS(a,c);a[wf]=b;a[xf]=d;Bi(a,b,!1,!1);b.stateNode=a;g=wb(c,d);switch(c){case "dialog":G("cancel",a);G("close",a);
e=d;break;case "iframe":case "object":case "embed":G("load",a);e=d;break;case "video":case "audio":for(e=0;e<Xe.length;e++)G(Xe[e],a);e=d;break;case "source":G("error",a);e=d;break;case "img":case "image":case "link":G("error",a);G("load",a);e=d;break;case "details":G("toggle",a);e=d;break;case "input":Za(a,d);e=Ya(a,d);G("invalid",a);break;case "option":e=eb(a,d);break;case "select":a._wrapperState={wasMultiple:!!d.multiple};e=m({},d,{value:void 0});G("invalid",a);break;case "textarea":hb(a,d);e=
gb(a,d);G("invalid",a);break;default:e=d}vb(c,e);var h=e;for(f in h)if(h.hasOwnProperty(f)){var k=h[f];"style"===f?tb(a,k):"dangerouslySetInnerHTML"===f?(k=k?k.__html:void 0,null!=k&&ob(a,k)):"children"===f?"string"===typeof k?("textarea"!==c||""!==k)&&pb(a,k):"number"===typeof k&&pb(a,""+k):"suppressContentEditableWarning"!==f&&"suppressHydrationWarning"!==f&&"autoFocus"!==f&&(ca.hasOwnProperty(f)?null!=k&&"onScroll"===f&&G("scroll",a):null!=k&&qa(a,f,k,g))}switch(c){case "input":Va(a);cb(a,d,!1);
break;case "textarea":Va(a);jb(a);break;case "option":null!=d.value&&a.setAttribute("value",""+Sa(d.value));break;case "select":a.multiple=!!d.multiple;f=d.value;null!=f?fb(a,!!d.multiple,f,!1):null!=d.defaultValue&&fb(a,!!d.multiple,d.defaultValue,!0);break;default:"function"===typeof e.onClick&&(a.onclick=jf)}mf(c,d)&&(b.flags|=4)}null!==b.ref&&(b.flags|=128)}return null;case 6:if(a&&null!=b.stateNode)Ei(a,b,a.memoizedProps,d);else{if("string"!==typeof d&&null===b.stateNode)throw Error(y(166));
c=dh(ch.current);dh(ah.current);rh(b)?(d=b.stateNode,c=b.memoizedProps,d[wf]=b,d.nodeValue!==c&&(b.flags|=4)):(d=(9===c.nodeType?c:c.ownerDocument).createTextNode(d),d[wf]=b,b.stateNode=d)}return null;case 13:H(P);d=b.memoizedState;if(0!==(b.flags&64))return b.lanes=c,b;d=null!==d;c=!1;null===a?void 0!==b.memoizedProps.fallback&&rh(b):c=null!==a.memoizedState;if(d&&!c&&0!==(b.mode&2))if(null===a&&!0!==b.memoizedProps.unstable_avoidThisFallback||0!==(P.current&1))0===V&&(V=3);else{if(0===V||3===V)V=
4;null===U||0===(Dg&134217727)&&0===(Hi&134217727)||Ii(U,W)}if(d||c)b.flags|=4;return null;case 4:return fh(),Ci(b),null===a&&cf(b.stateNode.containerInfo),null;case 10:return rg(b),null;case 17:return Ff(b.type)&&Gf(),null;case 19:H(P);d=b.memoizedState;if(null===d)return null;f=0!==(b.flags&64);g=d.rendering;if(null===g)if(f)Fi(d,!1);else{if(0!==V||null!==a&&0!==(a.flags&64))for(a=b.child;null!==a;){g=ih(a);if(null!==g){b.flags|=64;Fi(d,!1);f=g.updateQueue;null!==f&&(b.updateQueue=f,b.flags|=4);
null===d.lastEffect&&(b.firstEffect=null);b.lastEffect=d.lastEffect;d=c;for(c=b.child;null!==c;)f=c,a=d,f.flags&=2,f.nextEffect=null,f.firstEffect=null,f.lastEffect=null,g=f.alternate,null===g?(f.childLanes=0,f.lanes=a,f.child=null,f.memoizedProps=null,f.memoizedState=null,f.updateQueue=null,f.dependencies=null,f.stateNode=null):(f.childLanes=g.childLanes,f.lanes=g.lanes,f.child=g.child,f.memoizedProps=g.memoizedProps,f.memoizedState=g.memoizedState,f.updateQueue=g.updateQueue,f.type=g.type,a=g.dependencies,
f.dependencies=null===a?null:{lanes:a.lanes,firstContext:a.firstContext}),c=c.sibling;I(P,P.current&1|2);return b.child}a=a.sibling}null!==d.tail&&O()>Ji&&(b.flags|=64,f=!0,Fi(d,!1),b.lanes=33554432)}else{if(!f)if(a=ih(g),null!==a){if(b.flags|=64,f=!0,c=a.updateQueue,null!==c&&(b.updateQueue=c,b.flags|=4),Fi(d,!0),null===d.tail&&"hidden"===d.tailMode&&!g.alternate&&!lh)return b=b.lastEffect=d.lastEffect,null!==b&&(b.nextEffect=null),null}else 2*O()-d.renderingStartTime>Ji&&1073741824!==c&&(b.flags|=
64,f=!0,Fi(d,!1),b.lanes=33554432);d.isBackwards?(g.sibling=b.child,b.child=g):(c=d.last,null!==c?c.sibling=g:b.child=g,d.last=g)}return null!==d.tail?(c=d.tail,d.rendering=c,d.tail=c.sibling,d.lastEffect=b.lastEffect,d.renderingStartTime=O(),c.sibling=null,b=P.current,I(P,f?b&1|2:b&1),c):null;case 23:case 24:return Ki(),null!==a&&null!==a.memoizedState!==(null!==b.memoizedState)&&"unstable-defer-without-hiding"!==d.mode&&(b.flags|=4),null}throw Error(y(156,b.tag));}
function Li(a){switch(a.tag){case 1:Ff(a.type)&&Gf();var b=a.flags;return b&4096?(a.flags=b&-4097|64,a):null;case 3:fh();H(N);H(M);uh();b=a.flags;if(0!==(b&64))throw Error(y(285));a.flags=b&-4097|64;return a;case 5:return hh(a),null;case 13:return H(P),b=a.flags,b&4096?(a.flags=b&-4097|64,a):null;case 19:return H(P),null;case 4:return fh(),null;case 10:return rg(a),null;case 23:case 24:return Ki(),null;default:return null}}
function Mi(a,b){try{var c="",d=b;do c+=Qa(d),d=d.return;while(d);var e=c}catch(f){e="\nError generating stack: "+f.message+"\n"+f.stack}return{value:a,source:b,stack:e}}function Ni(a,b){try{console.error(b.value)}catch(c){setTimeout(function(){throw c;})}}var Oi="function"===typeof WeakMap?WeakMap:Map;function Pi(a,b,c){c=zg(-1,c);c.tag=3;c.payload={element:null};var d=b.value;c.callback=function(){Qi||(Qi=!0,Ri=d);Ni(a,b)};return c}
function Si(a,b,c){c=zg(-1,c);c.tag=3;var d=a.type.getDerivedStateFromError;if("function"===typeof d){var e=b.value;c.payload=function(){Ni(a,b);return d(e)}}var f=a.stateNode;null!==f&&"function"===typeof f.componentDidCatch&&(c.callback=function(){"function"!==typeof d&&(null===Ti?Ti=new Set([this]):Ti.add(this),Ni(a,b));var c=b.stack;this.componentDidCatch(b.value,{componentStack:null!==c?c:""})});return c}var Ui="function"===typeof WeakSet?WeakSet:Set;
function Vi(a){var b=a.ref;if(null!==b)if("function"===typeof b)try{b(null)}catch(c){Wi(a,c)}else b.current=null}function Xi(a,b){switch(b.tag){case 0:case 11:case 15:case 22:return;case 1:if(b.flags&256&&null!==a){var c=a.memoizedProps,d=a.memoizedState;a=b.stateNode;b=a.getSnapshotBeforeUpdate(b.elementType===b.type?c:lg(b.type,c),d);a.__reactInternalSnapshotBeforeUpdate=b}return;case 3:b.flags&256&&qf(b.stateNode.containerInfo);return;case 5:case 6:case 4:case 17:return}throw Error(y(163));}
function Yi(a,b,c){switch(c.tag){case 0:case 11:case 15:case 22:b=c.updateQueue;b=null!==b?b.lastEffect:null;if(null!==b){a=b=b.next;do{if(3===(a.tag&3)){var d=a.create;a.destroy=d()}a=a.next}while(a!==b)}b=c.updateQueue;b=null!==b?b.lastEffect:null;if(null!==b){a=b=b.next;do{var e=a;d=e.next;e=e.tag;0!==(e&4)&&0!==(e&1)&&(Zi(c,a),$i(c,a));a=d}while(a!==b)}return;case 1:a=c.stateNode;c.flags&4&&(null===b?a.componentDidMount():(d=c.elementType===c.type?b.memoizedProps:lg(c.type,b.memoizedProps),a.componentDidUpdate(d,
b.memoizedState,a.__reactInternalSnapshotBeforeUpdate)));b=c.updateQueue;null!==b&&Eg(c,b,a);return;case 3:b=c.updateQueue;if(null!==b){a=null;if(null!==c.child)switch(c.child.tag){case 5:a=c.child.stateNode;break;case 1:a=c.child.stateNode}Eg(c,b,a)}return;case 5:a=c.stateNode;null===b&&c.flags&4&&mf(c.type,c.memoizedProps)&&a.focus();return;case 6:return;case 4:return;case 12:return;case 13:null===c.memoizedState&&(c=c.alternate,null!==c&&(c=c.memoizedState,null!==c&&(c=c.dehydrated,null!==c&&Cc(c))));
return;case 19:case 17:case 20:case 21:case 23:case 24:return}throw Error(y(163));}
function aj(a,b){for(var c=a;;){if(5===c.tag){var d=c.stateNode;if(b)d=d.style,"function"===typeof d.setProperty?d.setProperty("display","none","important"):d.display="none";else{d=c.stateNode;var e=c.memoizedProps.style;e=void 0!==e&&null!==e&&e.hasOwnProperty("display")?e.display:null;d.style.display=sb("display",e)}}else if(6===c.tag)c.stateNode.nodeValue=b?"":c.memoizedProps;else if((23!==c.tag&&24!==c.tag||null===c.memoizedState||c===a)&&null!==c.child){c.child.return=c;c=c.child;continue}if(c===
a)break;for(;null===c.sibling;){if(null===c.return||c.return===a)return;c=c.return}c.sibling.return=c.return;c=c.sibling}}
function bj(a,b){if(Mf&&"function"===typeof Mf.onCommitFiberUnmount)try{Mf.onCommitFiberUnmount(Lf,b)}catch(f){}switch(b.tag){case 0:case 11:case 14:case 15:case 22:a=b.updateQueue;if(null!==a&&(a=a.lastEffect,null!==a)){var c=a=a.next;do{var d=c,e=d.destroy;d=d.tag;if(void 0!==e)if(0!==(d&4))Zi(b,c);else{d=b;try{e()}catch(f){Wi(d,f)}}c=c.next}while(c!==a)}break;case 1:Vi(b);a=b.stateNode;if("function"===typeof a.componentWillUnmount)try{a.props=b.memoizedProps,a.state=b.memoizedState,a.componentWillUnmount()}catch(f){Wi(b,
f)}break;case 5:Vi(b);break;case 4:cj(a,b)}}function dj(a){a.alternate=null;a.child=null;a.dependencies=null;a.firstEffect=null;a.lastEffect=null;a.memoizedProps=null;a.memoizedState=null;a.pendingProps=null;a.return=null;a.updateQueue=null}function ej(a){return 5===a.tag||3===a.tag||4===a.tag}
function fj(a){a:{for(var b=a.return;null!==b;){if(ej(b))break a;b=b.return}throw Error(y(160));}var c=b;b=c.stateNode;switch(c.tag){case 5:var d=!1;break;case 3:b=b.containerInfo;d=!0;break;case 4:b=b.containerInfo;d=!0;break;default:throw Error(y(161));}c.flags&16&&(pb(b,""),c.flags&=-17);a:b:for(c=a;;){for(;null===c.sibling;){if(null===c.return||ej(c.return)){c=null;break a}c=c.return}c.sibling.return=c.return;for(c=c.sibling;5!==c.tag&&6!==c.tag&&18!==c.tag;){if(c.flags&2)continue b;if(null===
c.child||4===c.tag)continue b;else c.child.return=c,c=c.child}if(!(c.flags&2)){c=c.stateNode;break a}}d?gj(a,c,b):hj(a,c,b)}
function gj(a,b,c){var d=a.tag,e=5===d||6===d;if(e)a=e?a.stateNode:a.stateNode.instance,b?8===c.nodeType?c.parentNode.insertBefore(a,b):c.insertBefore(a,b):(8===c.nodeType?(b=c.parentNode,b.insertBefore(a,c)):(b=c,b.appendChild(a)),c=c._reactRootContainer,null!==c&&void 0!==c||null!==b.onclick||(b.onclick=jf));else if(4!==d&&(a=a.child,null!==a))for(gj(a,b,c),a=a.sibling;null!==a;)gj(a,b,c),a=a.sibling}
function hj(a,b,c){var d=a.tag,e=5===d||6===d;if(e)a=e?a.stateNode:a.stateNode.instance,b?c.insertBefore(a,b):c.appendChild(a);else if(4!==d&&(a=a.child,null!==a))for(hj(a,b,c),a=a.sibling;null!==a;)hj(a,b,c),a=a.sibling}
function cj(a,b){for(var c=b,d=!1,e,f;;){if(!d){d=c.return;a:for(;;){if(null===d)throw Error(y(160));e=d.stateNode;switch(d.tag){case 5:f=!1;break a;case 3:e=e.containerInfo;f=!0;break a;case 4:e=e.containerInfo;f=!0;break a}d=d.return}d=!0}if(5===c.tag||6===c.tag){a:for(var g=a,h=c,k=h;;)if(bj(g,k),null!==k.child&&4!==k.tag)k.child.return=k,k=k.child;else{if(k===h)break a;for(;null===k.sibling;){if(null===k.return||k.return===h)break a;k=k.return}k.sibling.return=k.return;k=k.sibling}f?(g=e,h=c.stateNode,
8===g.nodeType?g.parentNode.removeChild(h):g.removeChild(h)):e.removeChild(c.stateNode)}else if(4===c.tag){if(null!==c.child){e=c.stateNode.containerInfo;f=!0;c.child.return=c;c=c.child;continue}}else if(bj(a,c),null!==c.child){c.child.return=c;c=c.child;continue}if(c===b)break;for(;null===c.sibling;){if(null===c.return||c.return===b)return;c=c.return;4===c.tag&&(d=!1)}c.sibling.return=c.return;c=c.sibling}}
function ij(a,b){switch(b.tag){case 0:case 11:case 14:case 15:case 22:var c=b.updateQueue;c=null!==c?c.lastEffect:null;if(null!==c){var d=c=c.next;do 3===(d.tag&3)&&(a=d.destroy,d.destroy=void 0,void 0!==a&&a()),d=d.next;while(d!==c)}return;case 1:return;case 5:c=b.stateNode;if(null!=c){d=b.memoizedProps;var e=null!==a?a.memoizedProps:d;a=b.type;var f=b.updateQueue;b.updateQueue=null;if(null!==f){c[xf]=d;"input"===a&&"radio"===d.type&&null!=d.name&&$a(c,d);wb(a,e);b=wb(a,d);for(e=0;e<f.length;e+=
2){var g=f[e],h=f[e+1];"style"===g?tb(c,h):"dangerouslySetInnerHTML"===g?ob(c,h):"children"===g?pb(c,h):qa(c,g,h,b)}switch(a){case "input":ab(c,d);break;case "textarea":ib(c,d);break;case "select":a=c._wrapperState.wasMultiple,c._wrapperState.wasMultiple=!!d.multiple,f=d.value,null!=f?fb(c,!!d.multiple,f,!1):a!==!!d.multiple&&(null!=d.defaultValue?fb(c,!!d.multiple,d.defaultValue,!0):fb(c,!!d.multiple,d.multiple?[]:"",!1))}}}return;case 6:if(null===b.stateNode)throw Error(y(162));b.stateNode.nodeValue=
b.memoizedProps;return;case 3:c=b.stateNode;c.hydrate&&(c.hydrate=!1,Cc(c.containerInfo));return;case 12:return;case 13:null!==b.memoizedState&&(jj=O(),aj(b.child,!0));kj(b);return;case 19:kj(b);return;case 17:return;case 23:case 24:aj(b,null!==b.memoizedState);return}throw Error(y(163));}function kj(a){var b=a.updateQueue;if(null!==b){a.updateQueue=null;var c=a.stateNode;null===c&&(c=a.stateNode=new Ui);b.forEach(function(b){var d=lj.bind(null,a,b);c.has(b)||(c.add(b),b.then(d,d))})}}
function mj(a,b){return null!==a&&(a=a.memoizedState,null===a||null!==a.dehydrated)?(b=b.memoizedState,null!==b&&null===b.dehydrated):!1}var nj=Math.ceil,oj=ra.ReactCurrentDispatcher,pj=ra.ReactCurrentOwner,X=0,U=null,Y=null,W=0,qj=0,rj=Bf(0),V=0,sj=null,tj=0,Dg=0,Hi=0,uj=0,vj=null,jj=0,Ji=Infinity;function wj(){Ji=O()+500}var Z=null,Qi=!1,Ri=null,Ti=null,xj=!1,yj=null,zj=90,Aj=[],Bj=[],Cj=null,Dj=0,Ej=null,Fj=-1,Gj=0,Hj=0,Ij=null,Jj=!1;function Hg(){return 0!==(X&48)?O():-1!==Fj?Fj:Fj=O()}
function Ig(a){a=a.mode;if(0===(a&2))return 1;if(0===(a&4))return 99===eg()?1:2;0===Gj&&(Gj=tj);if(0!==kg.transition){0!==Hj&&(Hj=null!==vj?vj.pendingLanes:0);a=Gj;var b=4186112&~Hj;b&=-b;0===b&&(a=4186112&~a,b=a&-a,0===b&&(b=8192));return b}a=eg();0!==(X&4)&&98===a?a=Xc(12,Gj):(a=Sc(a),a=Xc(a,Gj));return a}
function Jg(a,b,c){if(50<Dj)throw Dj=0,Ej=null,Error(y(185));a=Kj(a,b);if(null===a)return null;$c(a,b,c);a===U&&(Hi|=b,4===V&&Ii(a,W));var d=eg();1===b?0!==(X&8)&&0===(X&48)?Lj(a):(Mj(a,c),0===X&&(wj(),ig())):(0===(X&4)||98!==d&&99!==d||(null===Cj?Cj=new Set([a]):Cj.add(a)),Mj(a,c));vj=a}function Kj(a,b){a.lanes|=b;var c=a.alternate;null!==c&&(c.lanes|=b);c=a;for(a=a.return;null!==a;)a.childLanes|=b,c=a.alternate,null!==c&&(c.childLanes|=b),c=a,a=a.return;return 3===c.tag?c.stateNode:null}
function Mj(a,b){for(var c=a.callbackNode,d=a.suspendedLanes,e=a.pingedLanes,f=a.expirationTimes,g=a.pendingLanes;0<g;){var h=31-Vc(g),k=1<<h,l=f[h];if(-1===l){if(0===(k&d)||0!==(k&e)){l=b;Rc(k);var n=F;f[h]=10<=n?l+250:6<=n?l+5E3:-1}}else l<=b&&(a.expiredLanes|=k);g&=~k}d=Uc(a,a===U?W:0);b=F;if(0===d)null!==c&&(c!==Zf&&Pf(c),a.callbackNode=null,a.callbackPriority=0);else{if(null!==c){if(a.callbackPriority===b)return;c!==Zf&&Pf(c)}15===b?(c=Lj.bind(null,a),null===ag?(ag=[c],bg=Of(Uf,jg)):ag.push(c),
c=Zf):14===b?c=hg(99,Lj.bind(null,a)):(c=Tc(b),c=hg(c,Nj.bind(null,a)));a.callbackPriority=b;a.callbackNode=c}}
function Nj(a){Fj=-1;Hj=Gj=0;if(0!==(X&48))throw Error(y(327));var b=a.callbackNode;if(Oj()&&a.callbackNode!==b)return null;var c=Uc(a,a===U?W:0);if(0===c)return null;var d=c;var e=X;X|=16;var f=Pj();if(U!==a||W!==d)wj(),Qj(a,d);do try{Rj();break}catch(h){Sj(a,h)}while(1);qg();oj.current=f;X=e;null!==Y?d=0:(U=null,W=0,d=V);if(0!==(tj&Hi))Qj(a,0);else if(0!==d){2===d&&(X|=64,a.hydrate&&(a.hydrate=!1,qf(a.containerInfo)),c=Wc(a),0!==c&&(d=Tj(a,c)));if(1===d)throw b=sj,Qj(a,0),Ii(a,c),Mj(a,O()),b;a.finishedWork=
a.current.alternate;a.finishedLanes=c;switch(d){case 0:case 1:throw Error(y(345));case 2:Uj(a);break;case 3:Ii(a,c);if((c&62914560)===c&&(d=jj+500-O(),10<d)){if(0!==Uc(a,0))break;e=a.suspendedLanes;if((e&c)!==c){Hg();a.pingedLanes|=a.suspendedLanes&e;break}a.timeoutHandle=of(Uj.bind(null,a),d);break}Uj(a);break;case 4:Ii(a,c);if((c&4186112)===c)break;d=a.eventTimes;for(e=-1;0<c;){var g=31-Vc(c);f=1<<g;g=d[g];g>e&&(e=g);c&=~f}c=e;c=O()-c;c=(120>c?120:480>c?480:1080>c?1080:1920>c?1920:3E3>c?3E3:4320>
c?4320:1960*nj(c/1960))-c;if(10<c){a.timeoutHandle=of(Uj.bind(null,a),c);break}Uj(a);break;case 5:Uj(a);break;default:throw Error(y(329));}}Mj(a,O());return a.callbackNode===b?Nj.bind(null,a):null}function Ii(a,b){b&=~uj;b&=~Hi;a.suspendedLanes|=b;a.pingedLanes&=~b;for(a=a.expirationTimes;0<b;){var c=31-Vc(b),d=1<<c;a[c]=-1;b&=~d}}
function Lj(a){if(0!==(X&48))throw Error(y(327));Oj();if(a===U&&0!==(a.expiredLanes&W)){var b=W;var c=Tj(a,b);0!==(tj&Hi)&&(b=Uc(a,b),c=Tj(a,b))}else b=Uc(a,0),c=Tj(a,b);0!==a.tag&&2===c&&(X|=64,a.hydrate&&(a.hydrate=!1,qf(a.containerInfo)),b=Wc(a),0!==b&&(c=Tj(a,b)));if(1===c)throw c=sj,Qj(a,0),Ii(a,b),Mj(a,O()),c;a.finishedWork=a.current.alternate;a.finishedLanes=b;Uj(a);Mj(a,O());return null}
function Vj(){if(null!==Cj){var a=Cj;Cj=null;a.forEach(function(a){a.expiredLanes|=24&a.pendingLanes;Mj(a,O())})}ig()}function Wj(a,b){var c=X;X|=1;try{return a(b)}finally{X=c,0===X&&(wj(),ig())}}function Xj(a,b){var c=X;X&=-2;X|=8;try{return a(b)}finally{X=c,0===X&&(wj(),ig())}}function ni(a,b){I(rj,qj);qj|=b;tj|=b}function Ki(){qj=rj.current;H(rj)}
function Qj(a,b){a.finishedWork=null;a.finishedLanes=0;var c=a.timeoutHandle;-1!==c&&(a.timeoutHandle=-1,pf(c));if(null!==Y)for(c=Y.return;null!==c;){var d=c;switch(d.tag){case 1:d=d.type.childContextTypes;null!==d&&void 0!==d&&Gf();break;case 3:fh();H(N);H(M);uh();break;case 5:hh(d);break;case 4:fh();break;case 13:H(P);break;case 19:H(P);break;case 10:rg(d);break;case 23:case 24:Ki()}c=c.return}U=a;Y=Tg(a.current,null);W=qj=tj=b;V=0;sj=null;uj=Hi=Dg=0}
function Sj(a,b){do{var c=Y;try{qg();vh.current=Gh;if(yh){for(var d=R.memoizedState;null!==d;){var e=d.queue;null!==e&&(e.pending=null);d=d.next}yh=!1}xh=0;T=S=R=null;zh=!1;pj.current=null;if(null===c||null===c.return){V=1;sj=b;Y=null;break}a:{var f=a,g=c.return,h=c,k=b;b=W;h.flags|=2048;h.firstEffect=h.lastEffect=null;if(null!==k&&"object"===typeof k&&"function"===typeof k.then){var l=k;if(0===(h.mode&2)){var n=h.alternate;n?(h.updateQueue=n.updateQueue,h.memoizedState=n.memoizedState,h.lanes=n.lanes):
(h.updateQueue=null,h.memoizedState=null)}var A=0!==(P.current&1),p=g;do{var C;if(C=13===p.tag){var x=p.memoizedState;if(null!==x)C=null!==x.dehydrated?!0:!1;else{var w=p.memoizedProps;C=void 0===w.fallback?!1:!0!==w.unstable_avoidThisFallback?!0:A?!1:!0}}if(C){var z=p.updateQueue;if(null===z){var u=new Set;u.add(l);p.updateQueue=u}else z.add(l);if(0===(p.mode&2)){p.flags|=64;h.flags|=16384;h.flags&=-2981;if(1===h.tag)if(null===h.alternate)h.tag=17;else{var t=zg(-1,1);t.tag=2;Ag(h,t)}h.lanes|=1;break a}k=
void 0;h=b;var q=f.pingCache;null===q?(q=f.pingCache=new Oi,k=new Set,q.set(l,k)):(k=q.get(l),void 0===k&&(k=new Set,q.set(l,k)));if(!k.has(h)){k.add(h);var v=Yj.bind(null,f,l,h);l.then(v,v)}p.flags|=4096;p.lanes=b;break a}p=p.return}while(null!==p);k=Error((Ra(h.type)||"A React component")+" suspended while rendering, but no fallback UI was specified.\n\nAdd a <Suspense fallback=...> component higher in the tree to provide a loading indicator or placeholder to display.")}5!==V&&(V=2);k=Mi(k,h);p=
g;do{switch(p.tag){case 3:f=k;p.flags|=4096;b&=-b;p.lanes|=b;var J=Pi(p,f,b);Bg(p,J);break a;case 1:f=k;var K=p.type,Q=p.stateNode;if(0===(p.flags&64)&&("function"===typeof K.getDerivedStateFromError||null!==Q&&"function"===typeof Q.componentDidCatch&&(null===Ti||!Ti.has(Q)))){p.flags|=4096;b&=-b;p.lanes|=b;var L=Si(p,f,b);Bg(p,L);break a}}p=p.return}while(null!==p)}Zj(c)}catch(va){b=va;Y===c&&null!==c&&(Y=c=c.return);continue}break}while(1)}
function Pj(){var a=oj.current;oj.current=Gh;return null===a?Gh:a}function Tj(a,b){var c=X;X|=16;var d=Pj();U===a&&W===b||Qj(a,b);do try{ak();break}catch(e){Sj(a,e)}while(1);qg();X=c;oj.current=d;if(null!==Y)throw Error(y(261));U=null;W=0;return V}function ak(){for(;null!==Y;)bk(Y)}function Rj(){for(;null!==Y&&!Qf();)bk(Y)}function bk(a){var b=ck(a.alternate,a,qj);a.memoizedProps=a.pendingProps;null===b?Zj(a):Y=b;pj.current=null}
function Zj(a){var b=a;do{var c=b.alternate;a=b.return;if(0===(b.flags&2048)){c=Gi(c,b,qj);if(null!==c){Y=c;return}c=b;if(24!==c.tag&&23!==c.tag||null===c.memoizedState||0!==(qj&1073741824)||0===(c.mode&4)){for(var d=0,e=c.child;null!==e;)d|=e.lanes|e.childLanes,e=e.sibling;c.childLanes=d}null!==a&&0===(a.flags&2048)&&(null===a.firstEffect&&(a.firstEffect=b.firstEffect),null!==b.lastEffect&&(null!==a.lastEffect&&(a.lastEffect.nextEffect=b.firstEffect),a.lastEffect=b.lastEffect),1<b.flags&&(null!==
a.lastEffect?a.lastEffect.nextEffect=b:a.firstEffect=b,a.lastEffect=b))}else{c=Li(b);if(null!==c){c.flags&=2047;Y=c;return}null!==a&&(a.firstEffect=a.lastEffect=null,a.flags|=2048)}b=b.sibling;if(null!==b){Y=b;return}Y=b=a}while(null!==b);0===V&&(V=5)}function Uj(a){var b=eg();gg(99,dk.bind(null,a,b));return null}
function dk(a,b){do Oj();while(null!==yj);if(0!==(X&48))throw Error(y(327));var c=a.finishedWork;if(null===c)return null;a.finishedWork=null;a.finishedLanes=0;if(c===a.current)throw Error(y(177));a.callbackNode=null;var d=c.lanes|c.childLanes,e=d,f=a.pendingLanes&~e;a.pendingLanes=e;a.suspendedLanes=0;a.pingedLanes=0;a.expiredLanes&=e;a.mutableReadLanes&=e;a.entangledLanes&=e;e=a.entanglements;for(var g=a.eventTimes,h=a.expirationTimes;0<f;){var k=31-Vc(f),l=1<<k;e[k]=0;g[k]=-1;h[k]=-1;f&=~l}null!==
Cj&&0===(d&24)&&Cj.has(a)&&Cj.delete(a);a===U&&(Y=U=null,W=0);1<c.flags?null!==c.lastEffect?(c.lastEffect.nextEffect=c,d=c.firstEffect):d=c:d=c.firstEffect;if(null!==d){e=X;X|=32;pj.current=null;kf=fd;g=Ne();if(Oe(g)){if("selectionStart"in g)h={start:g.selectionStart,end:g.selectionEnd};else a:if(h=(h=g.ownerDocument)&&h.defaultView||window,(l=h.getSelection&&h.getSelection())&&0!==l.rangeCount){h=l.anchorNode;f=l.anchorOffset;k=l.focusNode;l=l.focusOffset;try{h.nodeType,k.nodeType}catch(va){h=null;
break a}var n=0,A=-1,p=-1,C=0,x=0,w=g,z=null;b:for(;;){for(var u;;){w!==h||0!==f&&3!==w.nodeType||(A=n+f);w!==k||0!==l&&3!==w.nodeType||(p=n+l);3===w.nodeType&&(n+=w.nodeValue.length);if(null===(u=w.firstChild))break;z=w;w=u}for(;;){if(w===g)break b;z===h&&++C===f&&(A=n);z===k&&++x===l&&(p=n);if(null!==(u=w.nextSibling))break;w=z;z=w.parentNode}w=u}h=-1===A||-1===p?null:{start:A,end:p}}else h=null;h=h||{start:0,end:0}}else h=null;lf={focusedElem:g,selectionRange:h};fd=!1;Ij=null;Jj=!1;Z=d;do try{ek()}catch(va){if(null===
Z)throw Error(y(330));Wi(Z,va);Z=Z.nextEffect}while(null!==Z);Ij=null;Z=d;do try{for(g=a;null!==Z;){var t=Z.flags;t&16&&pb(Z.stateNode,"");if(t&128){var q=Z.alternate;if(null!==q){var v=q.ref;null!==v&&("function"===typeof v?v(null):v.current=null)}}switch(t&1038){case 2:fj(Z);Z.flags&=-3;break;case 6:fj(Z);Z.flags&=-3;ij(Z.alternate,Z);break;case 1024:Z.flags&=-1025;break;case 1028:Z.flags&=-1025;ij(Z.alternate,Z);break;case 4:ij(Z.alternate,Z);break;case 8:h=Z;cj(g,h);var J=h.alternate;dj(h);null!==
J&&dj(J)}Z=Z.nextEffect}}catch(va){if(null===Z)throw Error(y(330));Wi(Z,va);Z=Z.nextEffect}while(null!==Z);v=lf;q=Ne();t=v.focusedElem;g=v.selectionRange;if(q!==t&&t&&t.ownerDocument&&Me(t.ownerDocument.documentElement,t)){null!==g&&Oe(t)&&(q=g.start,v=g.end,void 0===v&&(v=q),"selectionStart"in t?(t.selectionStart=q,t.selectionEnd=Math.min(v,t.value.length)):(v=(q=t.ownerDocument||document)&&q.defaultView||window,v.getSelection&&(v=v.getSelection(),h=t.textContent.length,J=Math.min(g.start,h),g=void 0===
g.end?J:Math.min(g.end,h),!v.extend&&J>g&&(h=g,g=J,J=h),h=Le(t,J),f=Le(t,g),h&&f&&(1!==v.rangeCount||v.anchorNode!==h.node||v.anchorOffset!==h.offset||v.focusNode!==f.node||v.focusOffset!==f.offset)&&(q=q.createRange(),q.setStart(h.node,h.offset),v.removeAllRanges(),J>g?(v.addRange(q),v.extend(f.node,f.offset)):(q.setEnd(f.node,f.offset),v.addRange(q))))));q=[];for(v=t;v=v.parentNode;)1===v.nodeType&&q.push({element:v,left:v.scrollLeft,top:v.scrollTop});"function"===typeof t.focus&&t.focus();for(t=
0;t<q.length;t++)v=q[t],v.element.scrollLeft=v.left,v.element.scrollTop=v.top}fd=!!kf;lf=kf=null;a.current=c;Z=d;do try{for(t=a;null!==Z;){var K=Z.flags;K&36&&Yi(t,Z.alternate,Z);if(K&128){q=void 0;var Q=Z.ref;if(null!==Q){var L=Z.stateNode;switch(Z.tag){case 5:q=L;break;default:q=L}"function"===typeof Q?Q(q):Q.current=q}}Z=Z.nextEffect}}catch(va){if(null===Z)throw Error(y(330));Wi(Z,va);Z=Z.nextEffect}while(null!==Z);Z=null;$f();X=e}else a.current=c;if(xj)xj=!1,yj=a,zj=b;else for(Z=d;null!==Z;)b=
Z.nextEffect,Z.nextEffect=null,Z.flags&8&&(K=Z,K.sibling=null,K.stateNode=null),Z=b;d=a.pendingLanes;0===d&&(Ti=null);1===d?a===Ej?Dj++:(Dj=0,Ej=a):Dj=0;c=c.stateNode;if(Mf&&"function"===typeof Mf.onCommitFiberRoot)try{Mf.onCommitFiberRoot(Lf,c,void 0,64===(c.current.flags&64))}catch(va){}Mj(a,O());if(Qi)throw Qi=!1,a=Ri,Ri=null,a;if(0!==(X&8))return null;ig();return null}
function ek(){for(;null!==Z;){var a=Z.alternate;Jj||null===Ij||(0!==(Z.flags&8)?dc(Z,Ij)&&(Jj=!0):13===Z.tag&&mj(a,Z)&&dc(Z,Ij)&&(Jj=!0));var b=Z.flags;0!==(b&256)&&Xi(a,Z);0===(b&512)||xj||(xj=!0,hg(97,function(){Oj();return null}));Z=Z.nextEffect}}function Oj(){if(90!==zj){var a=97<zj?97:zj;zj=90;return gg(a,fk)}return!1}function $i(a,b){Aj.push(b,a);xj||(xj=!0,hg(97,function(){Oj();return null}))}function Zi(a,b){Bj.push(b,a);xj||(xj=!0,hg(97,function(){Oj();return null}))}
function fk(){if(null===yj)return!1;var a=yj;yj=null;if(0!==(X&48))throw Error(y(331));var b=X;X|=32;var c=Bj;Bj=[];for(var d=0;d<c.length;d+=2){var e=c[d],f=c[d+1],g=e.destroy;e.destroy=void 0;if("function"===typeof g)try{g()}catch(k){if(null===f)throw Error(y(330));Wi(f,k)}}c=Aj;Aj=[];for(d=0;d<c.length;d+=2){e=c[d];f=c[d+1];try{var h=e.create;e.destroy=h()}catch(k){if(null===f)throw Error(y(330));Wi(f,k)}}for(h=a.current.firstEffect;null!==h;)a=h.nextEffect,h.nextEffect=null,h.flags&8&&(h.sibling=
null,h.stateNode=null),h=a;X=b;ig();return!0}function gk(a,b,c){b=Mi(c,b);b=Pi(a,b,1);Ag(a,b);b=Hg();a=Kj(a,1);null!==a&&($c(a,1,b),Mj(a,b))}
function Wi(a,b){if(3===a.tag)gk(a,a,b);else for(var c=a.return;null!==c;){if(3===c.tag){gk(c,a,b);break}else if(1===c.tag){var d=c.stateNode;if("function"===typeof c.type.getDerivedStateFromError||"function"===typeof d.componentDidCatch&&(null===Ti||!Ti.has(d))){a=Mi(b,a);var e=Si(c,a,1);Ag(c,e);e=Hg();c=Kj(c,1);if(null!==c)$c(c,1,e),Mj(c,e);else if("function"===typeof d.componentDidCatch&&(null===Ti||!Ti.has(d)))try{d.componentDidCatch(b,a)}catch(f){}break}}c=c.return}}
function Yj(a,b,c){var d=a.pingCache;null!==d&&d.delete(b);b=Hg();a.pingedLanes|=a.suspendedLanes&c;U===a&&(W&c)===c&&(4===V||3===V&&(W&62914560)===W&&500>O()-jj?Qj(a,0):uj|=c);Mj(a,b)}function lj(a,b){var c=a.stateNode;null!==c&&c.delete(b);b=0;0===b&&(b=a.mode,0===(b&2)?b=1:0===(b&4)?b=99===eg()?1:2:(0===Gj&&(Gj=tj),b=Yc(62914560&~Gj),0===b&&(b=4194304)));c=Hg();a=Kj(a,b);null!==a&&($c(a,b,c),Mj(a,c))}var ck;
ck=function(a,b,c){var d=b.lanes;if(null!==a)if(a.memoizedProps!==b.pendingProps||N.current)ug=!0;else if(0!==(c&d))ug=0!==(a.flags&16384)?!0:!1;else{ug=!1;switch(b.tag){case 3:ri(b);sh();break;case 5:gh(b);break;case 1:Ff(b.type)&&Jf(b);break;case 4:eh(b,b.stateNode.containerInfo);break;case 10:d=b.memoizedProps.value;var e=b.type._context;I(mg,e._currentValue);e._currentValue=d;break;case 13:if(null!==b.memoizedState){if(0!==(c&b.child.childLanes))return ti(a,b,c);I(P,P.current&1);b=hi(a,b,c);return null!==
b?b.sibling:null}I(P,P.current&1);break;case 19:d=0!==(c&b.childLanes);if(0!==(a.flags&64)){if(d)return Ai(a,b,c);b.flags|=64}e=b.memoizedState;null!==e&&(e.rendering=null,e.tail=null,e.lastEffect=null);I(P,P.current);if(d)break;else return null;case 23:case 24:return b.lanes=0,mi(a,b,c)}return hi(a,b,c)}else ug=!1;b.lanes=0;switch(b.tag){case 2:d=b.type;null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2);a=b.pendingProps;e=Ef(b,M.current);tg(b,c);e=Ch(null,b,d,a,e,c);b.flags|=1;if("object"===
typeof e&&null!==e&&"function"===typeof e.render&&void 0===e.$$typeof){b.tag=1;b.memoizedState=null;b.updateQueue=null;if(Ff(d)){var f=!0;Jf(b)}else f=!1;b.memoizedState=null!==e.state&&void 0!==e.state?e.state:null;xg(b);var g=d.getDerivedStateFromProps;"function"===typeof g&&Gg(b,d,g,a);e.updater=Kg;b.stateNode=e;e._reactInternals=b;Og(b,d,a,c);b=qi(null,b,d,!0,f,c)}else b.tag=0,fi(null,b,e,c),b=b.child;return b;case 16:e=b.elementType;a:{null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2);
a=b.pendingProps;f=e._init;e=f(e._payload);b.type=e;f=b.tag=hk(e);a=lg(e,a);switch(f){case 0:b=li(null,b,e,a,c);break a;case 1:b=pi(null,b,e,a,c);break a;case 11:b=gi(null,b,e,a,c);break a;case 14:b=ii(null,b,e,lg(e.type,a),d,c);break a}throw Error(y(306,e,""));}return b;case 0:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),li(a,b,d,e,c);case 1:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),pi(a,b,d,e,c);case 3:ri(b);d=b.updateQueue;if(null===a||null===d)throw Error(y(282));
d=b.pendingProps;e=b.memoizedState;e=null!==e?e.element:null;yg(a,b);Cg(b,d,null,c);d=b.memoizedState.element;if(d===e)sh(),b=hi(a,b,c);else{e=b.stateNode;if(f=e.hydrate)kh=rf(b.stateNode.containerInfo.firstChild),jh=b,f=lh=!0;if(f){a=e.mutableSourceEagerHydrationData;if(null!=a)for(e=0;e<a.length;e+=2)f=a[e],f._workInProgressVersionPrimary=a[e+1],th.push(f);c=Zg(b,null,d,c);for(b.child=c;c;)c.flags=c.flags&-3|1024,c=c.sibling}else fi(a,b,d,c),sh();b=b.child}return b;case 5:return gh(b),null===a&&
ph(b),d=b.type,e=b.pendingProps,f=null!==a?a.memoizedProps:null,g=e.children,nf(d,e)?g=null:null!==f&&nf(d,f)&&(b.flags|=16),oi(a,b),fi(a,b,g,c),b.child;case 6:return null===a&&ph(b),null;case 13:return ti(a,b,c);case 4:return eh(b,b.stateNode.containerInfo),d=b.pendingProps,null===a?b.child=Yg(b,null,d,c):fi(a,b,d,c),b.child;case 11:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),gi(a,b,d,e,c);case 7:return fi(a,b,b.pendingProps,c),b.child;case 8:return fi(a,b,b.pendingProps.children,
c),b.child;case 12:return fi(a,b,b.pendingProps.children,c),b.child;case 10:a:{d=b.type._context;e=b.pendingProps;g=b.memoizedProps;f=e.value;var h=b.type._context;I(mg,h._currentValue);h._currentValue=f;if(null!==g)if(h=g.value,f=He(h,f)?0:("function"===typeof d._calculateChangedBits?d._calculateChangedBits(h,f):1073741823)|0,0===f){if(g.children===e.children&&!N.current){b=hi(a,b,c);break a}}else for(h=b.child,null!==h&&(h.return=b);null!==h;){var k=h.dependencies;if(null!==k){g=h.child;for(var l=
k.firstContext;null!==l;){if(l.context===d&&0!==(l.observedBits&f)){1===h.tag&&(l=zg(-1,c&-c),l.tag=2,Ag(h,l));h.lanes|=c;l=h.alternate;null!==l&&(l.lanes|=c);sg(h.return,c);k.lanes|=c;break}l=l.next}}else g=10===h.tag?h.type===b.type?null:h.child:h.child;if(null!==g)g.return=h;else for(g=h;null!==g;){if(g===b){g=null;break}h=g.sibling;if(null!==h){h.return=g.return;g=h;break}g=g.return}h=g}fi(a,b,e.children,c);b=b.child}return b;case 9:return e=b.type,f=b.pendingProps,d=f.children,tg(b,c),e=vg(e,
f.unstable_observedBits),d=d(e),b.flags|=1,fi(a,b,d,c),b.child;case 14:return e=b.type,f=lg(e,b.pendingProps),f=lg(e.type,f),ii(a,b,e,f,d,c);case 15:return ki(a,b,b.type,b.pendingProps,d,c);case 17:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2),b.tag=1,Ff(d)?(a=!0,Jf(b)):a=!1,tg(b,c),Mg(b,d,e),Og(b,d,e,c),qi(null,b,d,!0,a,c);case 19:return Ai(a,b,c);case 23:return mi(a,b,c);case 24:return mi(a,b,c)}throw Error(y(156,b.tag));
};function ik(a,b,c,d){this.tag=a;this.key=c;this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null;this.index=0;this.ref=null;this.pendingProps=b;this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null;this.mode=d;this.flags=0;this.lastEffect=this.firstEffect=this.nextEffect=null;this.childLanes=this.lanes=0;this.alternate=null}function nh(a,b,c,d){return new ik(a,b,c,d)}function ji(a){a=a.prototype;return!(!a||!a.isReactComponent)}
function hk(a){if("function"===typeof a)return ji(a)?1:0;if(void 0!==a&&null!==a){a=a.$$typeof;if(a===Aa)return 11;if(a===Da)return 14}return 2}
function Tg(a,b){var c=a.alternate;null===c?(c=nh(a.tag,b,a.key,a.mode),c.elementType=a.elementType,c.type=a.type,c.stateNode=a.stateNode,c.alternate=a,a.alternate=c):(c.pendingProps=b,c.type=a.type,c.flags=0,c.nextEffect=null,c.firstEffect=null,c.lastEffect=null);c.childLanes=a.childLanes;c.lanes=a.lanes;c.child=a.child;c.memoizedProps=a.memoizedProps;c.memoizedState=a.memoizedState;c.updateQueue=a.updateQueue;b=a.dependencies;c.dependencies=null===b?null:{lanes:b.lanes,firstContext:b.firstContext};
c.sibling=a.sibling;c.index=a.index;c.ref=a.ref;return c}
function Vg(a,b,c,d,e,f){var g=2;d=a;if("function"===typeof a)ji(a)&&(g=1);else if("string"===typeof a)g=5;else a:switch(a){case ua:return Xg(c.children,e,f,b);case Ha:g=8;e|=16;break;case wa:g=8;e|=1;break;case xa:return a=nh(12,c,b,e|8),a.elementType=xa,a.type=xa,a.lanes=f,a;case Ba:return a=nh(13,c,b,e),a.type=Ba,a.elementType=Ba,a.lanes=f,a;case Ca:return a=nh(19,c,b,e),a.elementType=Ca,a.lanes=f,a;case Ia:return vi(c,e,f,b);case Ja:return a=nh(24,c,b,e),a.elementType=Ja,a.lanes=f,a;default:if("object"===
typeof a&&null!==a)switch(a.$$typeof){case ya:g=10;break a;case za:g=9;break a;case Aa:g=11;break a;case Da:g=14;break a;case Ea:g=16;d=null;break a;case Fa:g=22;break a}throw Error(y(130,null==a?a:typeof a,""));}b=nh(g,c,b,e);b.elementType=a;b.type=d;b.lanes=f;return b}function Xg(a,b,c,d){a=nh(7,a,d,b);a.lanes=c;return a}function vi(a,b,c,d){a=nh(23,a,d,b);a.elementType=Ia;a.lanes=c;return a}function Ug(a,b,c){a=nh(6,a,null,b);a.lanes=c;return a}
function Wg(a,b,c){b=nh(4,null!==a.children?a.children:[],a.key,b);b.lanes=c;b.stateNode={containerInfo:a.containerInfo,pendingChildren:null,implementation:a.implementation};return b}
function jk(a,b,c){this.tag=b;this.containerInfo=a;this.finishedWork=this.pingCache=this.current=this.pendingChildren=null;this.timeoutHandle=-1;this.pendingContext=this.context=null;this.hydrate=c;this.callbackNode=null;this.callbackPriority=0;this.eventTimes=Zc(0);this.expirationTimes=Zc(-1);this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0;this.entanglements=Zc(0);this.mutableSourceEagerHydrationData=null}
function kk(a,b,c){var d=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;return{$$typeof:ta,key:null==d?null:""+d,children:a,containerInfo:b,implementation:c}}
function lk(a,b,c,d){var e=b.current,f=Hg(),g=Ig(e);a:if(c){c=c._reactInternals;b:{if(Zb(c)!==c||1!==c.tag)throw Error(y(170));var h=c;do{switch(h.tag){case 3:h=h.stateNode.context;break b;case 1:if(Ff(h.type)){h=h.stateNode.__reactInternalMemoizedMergedChildContext;break b}}h=h.return}while(null!==h);throw Error(y(171));}if(1===c.tag){var k=c.type;if(Ff(k)){c=If(c,k,h);break a}}c=h}else c=Cf;null===b.context?b.context=c:b.pendingContext=c;b=zg(f,g);b.payload={element:a};d=void 0===d?null:d;null!==
d&&(b.callback=d);Ag(e,b);Jg(e,g,f);return g}function mk(a){a=a.current;if(!a.child)return null;switch(a.child.tag){case 5:return a.child.stateNode;default:return a.child.stateNode}}function nk(a,b){a=a.memoizedState;if(null!==a&&null!==a.dehydrated){var c=a.retryLane;a.retryLane=0!==c&&c<b?c:b}}function ok(a,b){nk(a,b);(a=a.alternate)&&nk(a,b)}function pk(){return null}
function qk(a,b,c){var d=null!=c&&null!=c.hydrationOptions&&c.hydrationOptions.mutableSources||null;c=new jk(a,b,null!=c&&!0===c.hydrate);b=nh(3,null,null,2===b?7:1===b?3:0);c.current=b;b.stateNode=c;xg(b);a[ff]=c.current;cf(8===a.nodeType?a.parentNode:a);if(d)for(a=0;a<d.length;a++){b=d[a];var e=b._getVersion;e=e(b._source);null==c.mutableSourceEagerHydrationData?c.mutableSourceEagerHydrationData=[b,e]:c.mutableSourceEagerHydrationData.push(b,e)}this._internalRoot=c}
qk.prototype.render=function(a){lk(a,this._internalRoot,null,null)};qk.prototype.unmount=function(){var a=this._internalRoot,b=a.containerInfo;lk(null,a,null,function(){b[ff]=null})};function rk(a){return!(!a||1!==a.nodeType&&9!==a.nodeType&&11!==a.nodeType&&(8!==a.nodeType||" react-mount-point-unstable "!==a.nodeValue))}
function sk(a,b){b||(b=a?9===a.nodeType?a.documentElement:a.firstChild:null,b=!(!b||1!==b.nodeType||!b.hasAttribute("data-reactroot")));if(!b)for(var c;c=a.lastChild;)a.removeChild(c);return new qk(a,0,b?{hydrate:!0}:void 0)}
function tk(a,b,c,d,e){var f=c._reactRootContainer;if(f){var g=f._internalRoot;if("function"===typeof e){var h=e;e=function(){var a=mk(g);h.call(a)}}lk(b,g,a,e)}else{f=c._reactRootContainer=sk(c,d);g=f._internalRoot;if("function"===typeof e){var k=e;e=function(){var a=mk(g);k.call(a)}}Xj(function(){lk(b,g,a,e)})}return mk(g)}ec=function(a){if(13===a.tag){var b=Hg();Jg(a,4,b);ok(a,4)}};fc=function(a){if(13===a.tag){var b=Hg();Jg(a,67108864,b);ok(a,67108864)}};
gc=function(a){if(13===a.tag){var b=Hg(),c=Ig(a);Jg(a,c,b);ok(a,c)}};hc=function(a,b){return b()};
yb=function(a,b,c){switch(b){case "input":ab(a,c);b=c.name;if("radio"===c.type&&null!=b){for(c=a;c.parentNode;)c=c.parentNode;c=c.querySelectorAll("input[name="+JSON.stringify(""+b)+'][type="radio"]');for(b=0;b<c.length;b++){var d=c[b];if(d!==a&&d.form===a.form){var e=Db(d);if(!e)throw Error(y(90));Wa(d);ab(d,e)}}}break;case "textarea":ib(a,c);break;case "select":b=c.value,null!=b&&fb(a,!!c.multiple,b,!1)}};Gb=Wj;
Hb=function(a,b,c,d,e){var f=X;X|=4;try{return gg(98,a.bind(null,b,c,d,e))}finally{X=f,0===X&&(wj(),ig())}};Ib=function(){0===(X&49)&&(Vj(),Oj())};Jb=function(a,b){var c=X;X|=2;try{return a(b)}finally{X=c,0===X&&(wj(),ig())}};function uk(a,b){var c=2<arguments.length&&void 0!==arguments[2]?arguments[2]:null;if(!rk(b))throw Error(y(200));return kk(a,b,null,c)}var vk={Events:[Cb,ue,Db,Eb,Fb,Oj,{current:!1}]},wk={findFiberByHostInstance:wc,bundleType:0,version:"17.0.2",rendererPackageName:"react-dom"};
var xk={bundleType:wk.bundleType,version:wk.version,rendererPackageName:wk.rendererPackageName,rendererConfig:wk.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:ra.ReactCurrentDispatcher,findHostInstanceByFiber:function(a){a=cc(a);return null===a?null:a.stateNode},findFiberByHostInstance:wk.findFiberByHostInstance||
pk,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null};if("undefined"!==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__){var yk=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!yk.isDisabled&&yk.supportsFiber)try{Lf=yk.inject(xk),Mf=yk}catch(a){}}__webpack_unused_export__=vk;__webpack_unused_export__=uk;
__webpack_unused_export__=function(a){if(null==a)return null;if(1===a.nodeType)return a;var b=a._reactInternals;if(void 0===b){if("function"===typeof a.render)throw Error(y(188));throw Error(y(268,Object.keys(a)));}a=cc(b);a=null===a?null:a.stateNode;return a};__webpack_unused_export__=function(a,b){var c=X;if(0!==(c&48))return a(b);X|=1;try{if(a)return gg(99,a.bind(null,b))}finally{X=c,ig()}};__webpack_unused_export__=function(a,b,c){if(!rk(b))throw Error(y(200));return tk(null,a,b,!0,c)};
exports.render=function(a,b,c){if(!rk(b))throw Error(y(200));return tk(null,a,b,!1,c)};__webpack_unused_export__=function(a){if(!rk(a))throw Error(y(40));return a._reactRootContainer?(Xj(function(){tk(null,null,a,!1,function(){a._reactRootContainer=null;a[ff]=null})}),!0):!1};__webpack_unused_export__=Wj;__webpack_unused_export__=function(a,b){return uk(a,b,2<arguments.length&&void 0!==arguments[2]?arguments[2]:null)};
__webpack_unused_export__=function(a,b,c,d){if(!rk(c))throw Error(y(200));if(null==a||void 0===a._reactInternals)throw Error(y(38));return tk(a,b,c,!1,d)};__webpack_unused_export__="17.0.2";


/***/ }),

/***/ 961:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


function checkDCE() {
  /* global __REACT_DEVTOOLS_GLOBAL_HOOK__ */
  if (
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === 'undefined' ||
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== 'function'
  ) {
    return;
  }
  if (false) {}
  try {
    // Verify that the code above has been dead code eliminated (DCE'd).
    __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
  } catch (err) {
    // DevTools shouldn't crash React, no matter what.
    // We should still report in case we break this code.
    console.error(err);
  }
}

if (true) {
  // DCE check should happen before ReactDOM bundle executes so that
  // DevTools can report bad minification during injection.
  checkDCE();
  module.exports = __webpack_require__(2551);
} else {}


/***/ }),

/***/ 5287:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/** @license React v17.0.2
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var l=__webpack_require__(5228),n=60103,p=60106;exports.Fragment=60107;exports.StrictMode=60108;exports.Profiler=60114;var q=60109,r=60110,t=60112;exports.Suspense=60113;var u=60115,v=60116;
if("function"===typeof Symbol&&Symbol.for){var w=Symbol.for;n=w("react.element");p=w("react.portal");exports.Fragment=w("react.fragment");exports.StrictMode=w("react.strict_mode");exports.Profiler=w("react.profiler");q=w("react.provider");r=w("react.context");t=w("react.forward_ref");exports.Suspense=w("react.suspense");u=w("react.memo");v=w("react.lazy")}var x="function"===typeof Symbol&&Symbol.iterator;
function y(a){if(null===a||"object"!==typeof a)return null;a=x&&a[x]||a["@@iterator"];return"function"===typeof a?a:null}function z(a){for(var b="https://reactjs.org/docs/error-decoder.html?invariant="+a,c=1;c<arguments.length;c++)b+="&args[]="+encodeURIComponent(arguments[c]);return"Minified React error #"+a+"; visit "+b+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}
var A={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},B={};function C(a,b,c){this.props=a;this.context=b;this.refs=B;this.updater=c||A}C.prototype.isReactComponent={};C.prototype.setState=function(a,b){if("object"!==typeof a&&"function"!==typeof a&&null!=a)throw Error(z(85));this.updater.enqueueSetState(this,a,b,"setState")};C.prototype.forceUpdate=function(a){this.updater.enqueueForceUpdate(this,a,"forceUpdate")};
function D(){}D.prototype=C.prototype;function E(a,b,c){this.props=a;this.context=b;this.refs=B;this.updater=c||A}var F=E.prototype=new D;F.constructor=E;l(F,C.prototype);F.isPureReactComponent=!0;var G={current:null},H=Object.prototype.hasOwnProperty,I={key:!0,ref:!0,__self:!0,__source:!0};
function J(a,b,c){var e,d={},k=null,h=null;if(null!=b)for(e in void 0!==b.ref&&(h=b.ref),void 0!==b.key&&(k=""+b.key),b)H.call(b,e)&&!I.hasOwnProperty(e)&&(d[e]=b[e]);var g=arguments.length-2;if(1===g)d.children=c;else if(1<g){for(var f=Array(g),m=0;m<g;m++)f[m]=arguments[m+2];d.children=f}if(a&&a.defaultProps)for(e in g=a.defaultProps,g)void 0===d[e]&&(d[e]=g[e]);return{$$typeof:n,type:a,key:k,ref:h,props:d,_owner:G.current}}
function K(a,b){return{$$typeof:n,type:a.type,key:b,ref:a.ref,props:a.props,_owner:a._owner}}function L(a){return"object"===typeof a&&null!==a&&a.$$typeof===n}function escape(a){var b={"=":"=0",":":"=2"};return"$"+a.replace(/[=:]/g,function(a){return b[a]})}var M=/\/+/g;function N(a,b){return"object"===typeof a&&null!==a&&null!=a.key?escape(""+a.key):b.toString(36)}
function O(a,b,c,e,d){var k=typeof a;if("undefined"===k||"boolean"===k)a=null;var h=!1;if(null===a)h=!0;else switch(k){case "string":case "number":h=!0;break;case "object":switch(a.$$typeof){case n:case p:h=!0}}if(h)return h=a,d=d(h),a=""===e?"."+N(h,0):e,Array.isArray(d)?(c="",null!=a&&(c=a.replace(M,"$&/")+"/"),O(d,b,c,"",function(a){return a})):null!=d&&(L(d)&&(d=K(d,c+(!d.key||h&&h.key===d.key?"":(""+d.key).replace(M,"$&/")+"/")+a)),b.push(d)),1;h=0;e=""===e?".":e+":";if(Array.isArray(a))for(var g=
0;g<a.length;g++){k=a[g];var f=e+N(k,g);h+=O(k,b,c,f,d)}else if(f=y(a),"function"===typeof f)for(a=f.call(a),g=0;!(k=a.next()).done;)k=k.value,f=e+N(k,g++),h+=O(k,b,c,f,d);else if("object"===k)throw b=""+a,Error(z(31,"[object Object]"===b?"object with keys {"+Object.keys(a).join(", ")+"}":b));return h}function P(a,b,c){if(null==a)return a;var e=[],d=0;O(a,e,"","",function(a){return b.call(c,a,d++)});return e}
function Q(a){if(-1===a._status){var b=a._result;b=b();a._status=0;a._result=b;b.then(function(b){0===a._status&&(b=b.default,a._status=1,a._result=b)},function(b){0===a._status&&(a._status=2,a._result=b)})}if(1===a._status)return a._result;throw a._result;}var R={current:null};function S(){var a=R.current;if(null===a)throw Error(z(321));return a}var T={ReactCurrentDispatcher:R,ReactCurrentBatchConfig:{transition:0},ReactCurrentOwner:G,IsSomeRendererActing:{current:!1},assign:l};
exports.Children={map:P,forEach:function(a,b,c){P(a,function(){b.apply(this,arguments)},c)},count:function(a){var b=0;P(a,function(){b++});return b},toArray:function(a){return P(a,function(a){return a})||[]},only:function(a){if(!L(a))throw Error(z(143));return a}};exports.Component=C;exports.PureComponent=E;exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=T;
exports.cloneElement=function(a,b,c){if(null===a||void 0===a)throw Error(z(267,a));var e=l({},a.props),d=a.key,k=a.ref,h=a._owner;if(null!=b){void 0!==b.ref&&(k=b.ref,h=G.current);void 0!==b.key&&(d=""+b.key);if(a.type&&a.type.defaultProps)var g=a.type.defaultProps;for(f in b)H.call(b,f)&&!I.hasOwnProperty(f)&&(e[f]=void 0===b[f]&&void 0!==g?g[f]:b[f])}var f=arguments.length-2;if(1===f)e.children=c;else if(1<f){g=Array(f);for(var m=0;m<f;m++)g[m]=arguments[m+2];e.children=g}return{$$typeof:n,type:a.type,
key:d,ref:k,props:e,_owner:h}};exports.createContext=function(a,b){void 0===b&&(b=null);a={$$typeof:r,_calculateChangedBits:b,_currentValue:a,_currentValue2:a,_threadCount:0,Provider:null,Consumer:null};a.Provider={$$typeof:q,_context:a};return a.Consumer=a};exports.createElement=J;exports.createFactory=function(a){var b=J.bind(null,a);b.type=a;return b};exports.createRef=function(){return{current:null}};exports.forwardRef=function(a){return{$$typeof:t,render:a}};exports.isValidElement=L;
exports.lazy=function(a){return{$$typeof:v,_payload:{_status:-1,_result:a},_init:Q}};exports.memo=function(a,b){return{$$typeof:u,type:a,compare:void 0===b?null:b}};exports.useCallback=function(a,b){return S().useCallback(a,b)};exports.useContext=function(a,b){return S().useContext(a,b)};exports.useDebugValue=function(){};exports.useEffect=function(a,b){return S().useEffect(a,b)};exports.useImperativeHandle=function(a,b,c){return S().useImperativeHandle(a,b,c)};
exports.useLayoutEffect=function(a,b){return S().useLayoutEffect(a,b)};exports.useMemo=function(a,b){return S().useMemo(a,b)};exports.useReducer=function(a,b,c){return S().useReducer(a,b,c)};exports.useRef=function(a){return S().useRef(a)};exports.useState=function(a){return S().useState(a)};exports.version="17.0.2";


/***/ }),

/***/ 6540:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


if (true) {
  module.exports = __webpack_require__(5287);
} else {}


/***/ }),

/***/ 7463:
/***/ ((__unused_webpack_module, exports) => {

"use strict";
/** @license React v0.20.2
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f,g,h,k;if("object"===typeof performance&&"function"===typeof performance.now){var l=performance;exports.unstable_now=function(){return l.now()}}else{var p=Date,q=p.now();exports.unstable_now=function(){return p.now()-q}}
if("undefined"===typeof window||"function"!==typeof MessageChannel){var t=null,u=null,w=function(){if(null!==t)try{var a=exports.unstable_now();t(!0,a);t=null}catch(b){throw setTimeout(w,0),b;}};f=function(a){null!==t?setTimeout(f,0,a):(t=a,setTimeout(w,0))};g=function(a,b){u=setTimeout(a,b)};h=function(){clearTimeout(u)};exports.unstable_shouldYield=function(){return!1};k=exports.unstable_forceFrameRate=function(){}}else{var x=window.setTimeout,y=window.clearTimeout;if("undefined"!==typeof console){var z=
window.cancelAnimationFrame;"function"!==typeof window.requestAnimationFrame&&console.error("This browser doesn't support requestAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills");"function"!==typeof z&&console.error("This browser doesn't support cancelAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills")}var A=!1,B=null,C=-1,D=5,E=0;exports.unstable_shouldYield=function(){return exports.unstable_now()>=
E};k=function(){};exports.unstable_forceFrameRate=function(a){0>a||125<a?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):D=0<a?Math.floor(1E3/a):5};var F=new MessageChannel,G=F.port2;F.port1.onmessage=function(){if(null!==B){var a=exports.unstable_now();E=a+D;try{B(!0,a)?G.postMessage(null):(A=!1,B=null)}catch(b){throw G.postMessage(null),b;}}else A=!1};f=function(a){B=a;A||(A=!0,G.postMessage(null))};g=function(a,b){C=
x(function(){a(exports.unstable_now())},b)};h=function(){y(C);C=-1}}function H(a,b){var c=a.length;a.push(b);a:for(;;){var d=c-1>>>1,e=a[d];if(void 0!==e&&0<I(e,b))a[d]=b,a[c]=e,c=d;else break a}}function J(a){a=a[0];return void 0===a?null:a}
function K(a){var b=a[0];if(void 0!==b){var c=a.pop();if(c!==b){a[0]=c;a:for(var d=0,e=a.length;d<e;){var m=2*(d+1)-1,n=a[m],v=m+1,r=a[v];if(void 0!==n&&0>I(n,c))void 0!==r&&0>I(r,n)?(a[d]=r,a[v]=c,d=v):(a[d]=n,a[m]=c,d=m);else if(void 0!==r&&0>I(r,c))a[d]=r,a[v]=c,d=v;else break a}}return b}return null}function I(a,b){var c=a.sortIndex-b.sortIndex;return 0!==c?c:a.id-b.id}var L=[],M=[],N=1,O=null,P=3,Q=!1,R=!1,S=!1;
function T(a){for(var b=J(M);null!==b;){if(null===b.callback)K(M);else if(b.startTime<=a)K(M),b.sortIndex=b.expirationTime,H(L,b);else break;b=J(M)}}function U(a){S=!1;T(a);if(!R)if(null!==J(L))R=!0,f(V);else{var b=J(M);null!==b&&g(U,b.startTime-a)}}
function V(a,b){R=!1;S&&(S=!1,h());Q=!0;var c=P;try{T(b);for(O=J(L);null!==O&&(!(O.expirationTime>b)||a&&!exports.unstable_shouldYield());){var d=O.callback;if("function"===typeof d){O.callback=null;P=O.priorityLevel;var e=d(O.expirationTime<=b);b=exports.unstable_now();"function"===typeof e?O.callback=e:O===J(L)&&K(L);T(b)}else K(L);O=J(L)}if(null!==O)var m=!0;else{var n=J(M);null!==n&&g(U,n.startTime-b);m=!1}return m}finally{O=null,P=c,Q=!1}}var W=k;exports.unstable_IdlePriority=5;
exports.unstable_ImmediatePriority=1;exports.unstable_LowPriority=4;exports.unstable_NormalPriority=3;exports.unstable_Profiling=null;exports.unstable_UserBlockingPriority=2;exports.unstable_cancelCallback=function(a){a.callback=null};exports.unstable_continueExecution=function(){R||Q||(R=!0,f(V))};exports.unstable_getCurrentPriorityLevel=function(){return P};exports.unstable_getFirstCallbackNode=function(){return J(L)};
exports.unstable_next=function(a){switch(P){case 1:case 2:case 3:var b=3;break;default:b=P}var c=P;P=b;try{return a()}finally{P=c}};exports.unstable_pauseExecution=function(){};exports.unstable_requestPaint=W;exports.unstable_runWithPriority=function(a,b){switch(a){case 1:case 2:case 3:case 4:case 5:break;default:a=3}var c=P;P=a;try{return b()}finally{P=c}};
exports.unstable_scheduleCallback=function(a,b,c){var d=exports.unstable_now();"object"===typeof c&&null!==c?(c=c.delay,c="number"===typeof c&&0<c?d+c:d):c=d;switch(a){case 1:var e=-1;break;case 2:e=250;break;case 5:e=1073741823;break;case 4:e=1E4;break;default:e=5E3}e=c+e;a={id:N++,callback:b,priorityLevel:a,startTime:c,expirationTime:e,sortIndex:-1};c>d?(a.sortIndex=c,H(M,a),null===J(L)&&a===J(M)&&(S?h():S=!0,g(U,c-d))):(a.sortIndex=e,H(L,a),R||Q||(R=!0,f(V)));return a};
exports.unstable_wrapCallback=function(a){var b=P;return function(){var c=P;P=b;try{return a.apply(this,arguments)}finally{P=c}}};


/***/ }),

/***/ 9982:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


if (true) {
  module.exports = __webpack_require__(7463);
} else {}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";

// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(6540);
// EXTERNAL MODULE: ./node_modules/react-dom/index.js
var react_dom = __webpack_require__(961);
;// CONCATENATED MODULE: ./node_modules/chromadb/dist/chunk-NSSMTXJJ.mjs
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);


//# sourceMappingURL=chunk-NSSMTXJJ.mjs.map
// EXTERNAL MODULE: ./node_modules/process/browser.js
var browser = __webpack_require__(5606);
;// CONCATENATED MODULE: ./node_modules/chromadb/dist/chromadb.mjs


// src/deno.ts
if (typeof globalThis.Deno !== "undefined") {
  const OriginalRequest = globalThis.Request;
  const PatchedRequest = function(input, init) {
    if (init && typeof init === "object") {
      const cleanInit = { ...init };
      if ("client" in cleanInit) {
        delete cleanInit.client;
      }
      return new OriginalRequest(input, cleanInit);
    }
    return new OriginalRequest(input, init);
  };
  Object.setPrototypeOf(PatchedRequest, OriginalRequest);
  Object.defineProperty(PatchedRequest, "prototype", {
    value: OriginalRequest.prototype,
    writable: false
  });
  globalThis.Request = PatchedRequest;
}

// src/types.ts
var baseRecordSetFields = [
  "ids",
  "embeddings",
  "metadatas",
  "documents",
  "uris"
];
var recordSetFields = [...baseRecordSetFields, "ids"];
var IncludeEnum = /* @__PURE__ */ ((IncludeEnum2) => {
  IncludeEnum2["distances"] = "distances";
  IncludeEnum2["documents"] = "documents";
  IncludeEnum2["embeddings"] = "embeddings";
  IncludeEnum2["metadatas"] = "metadatas";
  IncludeEnum2["uris"] = "uris";
  return IncludeEnum2;
})(IncludeEnum || {});
var GetResult = class {
  /**
   * Creates a new GetResult instance.
   * @param data - The result data containing all fields
   */
  constructor({
    documents,
    embeddings,
    ids,
    include,
    metadatas,
    uris
  }) {
    this.documents = documents;
    this.embeddings = embeddings;
    this.ids = ids;
    this.include = include;
    this.metadatas = metadatas;
    this.uris = uris;
  }
  /**
   * Converts the result to a row-based format for easier iteration.
   * @returns Object containing include fields and array of record objects
   */
  rows() {
    return this.ids.map((id, index) => {
      return {
        id,
        document: this.include.includes("documents") ? this.documents[index] : void 0,
        embedding: this.include.includes("embeddings") ? this.embeddings[index] : void 0,
        metadata: this.include.includes("metadatas") ? this.metadatas[index] : void 0,
        uri: this.include.includes("uris") ? this.uris[index] : void 0
      };
    });
  }
};
var QueryResult = class {
  /**
   * Creates a new QueryResult instance.
   * @param data - The query result data containing all fields
   */
  constructor({
    distances,
    documents,
    embeddings,
    ids,
    include,
    metadatas,
    uris
  }) {
    this.distances = distances;
    this.documents = documents;
    this.embeddings = embeddings;
    this.ids = ids;
    this.include = include;
    this.metadatas = metadatas;
    this.uris = uris;
  }
  /**
   * Converts the query result to a row-based format for easier iteration.
   * @returns Object containing include fields and structured query results
   */
  rows() {
    const queries = [];
    for (let q2 = 0; q2 < this.ids.length; q2++) {
      const records = this.ids[q2].map((id, index) => {
        return {
          id,
          document: this.include.includes("documents") ? this.documents[q2][index] : void 0,
          embedding: this.include.includes("embeddings") ? this.embeddings[q2][index] : void 0,
          metadata: this.include.includes("metadatas") ? this.metadatas[q2][index] : void 0,
          uri: this.include.includes("uris") ? this.uris[q2][index] : void 0,
          distance: this.include.includes("distances") ? this.distances[q2][index] : void 0
        };
      });
      queries.push(records);
    }
    return queries;
  }
};

// ../../node_modules/.pnpm/@hey-api+client-fetch@0.10.0_@hey-api+openapi-ts@0.67.3_typescript@5.8.3_/node_modules/@hey-api/client-fetch/dist/index.js
var A = async (t, r) => {
  let e = typeof r == "function" ? await r(t) : r;
  if (e) return t.scheme === "bearer" ? `Bearer ${e}` : t.scheme === "basic" ? `Basic ${btoa(e)}` : e;
};
var R = { bodySerializer: (t) => JSON.stringify(t, (r, e) => typeof e == "bigint" ? e.toString() : e) };
var U = (t) => {
  switch (t) {
    case "label":
      return ".";
    case "matrix":
      return ";";
    case "simple":
      return ",";
    default:
      return "&";
  }
};
var _ = (t) => {
  switch (t) {
    case "form":
      return ",";
    case "pipeDelimited":
      return "|";
    case "spaceDelimited":
      return "%20";
    default:
      return ",";
  }
};
var D = (t) => {
  switch (t) {
    case "label":
      return ".";
    case "matrix":
      return ";";
    case "simple":
      return ",";
    default:
      return "&";
  }
};
var O = ({ allowReserved: t, explode: r, name: e, style: a, value: i }) => {
  if (!r) {
    let s = (t ? i : i.map((l) => encodeURIComponent(l))).join(_(a));
    switch (a) {
      case "label":
        return `.${s}`;
      case "matrix":
        return `;${e}=${s}`;
      case "simple":
        return s;
      default:
        return `${e}=${s}`;
    }
  }
  let o = U(a), n = i.map((s) => a === "label" || a === "simple" ? t ? s : encodeURIComponent(s) : y({ allowReserved: t, name: e, value: s })).join(o);
  return a === "label" || a === "matrix" ? o + n : n;
};
var y = ({ allowReserved: t, name: r, value: e }) => {
  if (e == null) return "";
  if (typeof e == "object") throw new Error("Deeply-nested arrays/objects aren\u2019t supported. Provide your own `querySerializer()` to handle these.");
  return `${r}=${t ? e : encodeURIComponent(e)}`;
};
var q = ({ allowReserved: t, explode: r, name: e, style: a, value: i }) => {
  if (i instanceof Date) return `${e}=${i.toISOString()}`;
  if (a !== "deepObject" && !r) {
    let s = [];
    Object.entries(i).forEach(([f, u]) => {
      s = [...s, f, t ? u : encodeURIComponent(u)];
    });
    let l = s.join(",");
    switch (a) {
      case "form":
        return `${e}=${l}`;
      case "label":
        return `.${l}`;
      case "matrix":
        return `;${e}=${l}`;
      default:
        return l;
    }
  }
  let o = D(a), n = Object.entries(i).map(([s, l]) => y({ allowReserved: t, name: a === "deepObject" ? `${e}[${s}]` : s, value: l })).join(o);
  return a === "label" || a === "matrix" ? o + n : n;
};
var H = /\{[^{}]+\}/g;
var B = ({ path: t, url: r }) => {
  let e = r, a = r.match(H);
  if (a) for (let i of a) {
    let o = false, n = i.substring(1, i.length - 1), s = "simple";
    n.endsWith("*") && (o = true, n = n.substring(0, n.length - 1)), n.startsWith(".") ? (n = n.substring(1), s = "label") : n.startsWith(";") && (n = n.substring(1), s = "matrix");
    let l = t[n];
    if (l == null) continue;
    if (Array.isArray(l)) {
      e = e.replace(i, O({ explode: o, name: n, style: s, value: l }));
      continue;
    }
    if (typeof l == "object") {
      e = e.replace(i, q({ explode: o, name: n, style: s, value: l }));
      continue;
    }
    if (s === "matrix") {
      e = e.replace(i, `;${y({ name: n, value: l })}`);
      continue;
    }
    let f = encodeURIComponent(s === "label" ? `.${l}` : l);
    e = e.replace(i, f);
  }
  return e;
};
var E = ({ allowReserved: t, array: r, object: e } = {}) => (i) => {
  let o = [];
  if (i && typeof i == "object") for (let n in i) {
    let s = i[n];
    if (s != null) {
      if (Array.isArray(s)) {
        o = [...o, O({ allowReserved: t, explode: true, name: n, style: "form", value: s, ...r })];
        continue;
      }
      if (typeof s == "object") {
        o = [...o, q({ allowReserved: t, explode: true, name: n, style: "deepObject", value: s, ...e })];
        continue;
      }
      o = [...o, y({ allowReserved: t, name: n, value: s })];
    }
  }
  return o.join("&");
};
var P = (t) => {
  if (!t) return "stream";
  let r = t.split(";")[0]?.trim();
  if (r) {
    if (r.startsWith("application/json") || r.endsWith("+json")) return "json";
    if (r === "multipart/form-data") return "formData";
    if (["application/", "audio/", "image/", "video/"].some((e) => r.startsWith(e))) return "blob";
    if (r.startsWith("text/")) return "text";
  }
};
var I = async ({ security: t, ...r }) => {
  for (let e of t) {
    let a = await A(e, r.auth);
    if (!a) continue;
    let i = e.name ?? "Authorization";
    switch (e.in) {
      case "query":
        r.query || (r.query = {}), r.query[i] = a;
        break;
      case "cookie":
        r.headers.append("Cookie", `${i}=${a}`);
        break;
      case "header":
      default:
        r.headers.set(i, a);
        break;
    }
    return;
  }
};
var S = (t) => W({ baseUrl: t.baseUrl, path: t.path, query: t.query, querySerializer: typeof t.querySerializer == "function" ? t.querySerializer : E(t.querySerializer), url: t.url });
var W = ({ baseUrl: t, path: r, query: e, querySerializer: a, url: i }) => {
  let o = i.startsWith("/") ? i : `/${i}`, n = (t ?? "") + o;
  r && (n = B({ path: r, url: n }));
  let s = e ? a(e) : "";
  return s.startsWith("?") && (s = s.substring(1)), s && (n += `?${s}`), n;
};
var C = (t, r) => {
  let e = { ...t, ...r };
  return e.baseUrl?.endsWith("/") && (e.baseUrl = e.baseUrl.substring(0, e.baseUrl.length - 1)), e.headers = x(t.headers, r.headers), e;
};
var x = (...t) => {
  let r = new Headers();
  for (let e of t) {
    if (!e || typeof e != "object") continue;
    let a = e instanceof Headers ? e.entries() : Object.entries(e);
    for (let [i, o] of a) if (o === null) r.delete(i);
    else if (Array.isArray(o)) for (let n of o) r.append(i, n);
    else o !== void 0 && r.set(i, typeof o == "object" ? JSON.stringify(o) : o);
  }
  return r;
};
var h = class {
  constructor() {
    __publicField(this, "_fns");
    this._fns = [];
  }
  clear() {
    this._fns = [];
  }
  exists(r) {
    return this._fns.indexOf(r) !== -1;
  }
  eject(r) {
    let e = this._fns.indexOf(r);
    e !== -1 && (this._fns = [...this._fns.slice(0, e), ...this._fns.slice(e + 1)]);
  }
  use(r) {
    this._fns = [...this._fns, r];
  }
};
var T = () => ({ error: new h(), request: new h(), response: new h() });
var N = E({ allowReserved: false, array: { explode: true, style: "form" }, object: { explode: true, style: "deepObject" } });
var Q = { "Content-Type": "application/json" };
var w = (t = {}) => ({ ...R, headers: Q, parseAs: "auto", querySerializer: N, ...t });
var J = (t = {}) => {
  let r = C(w(), t), e = () => ({ ...r }), a = (n) => (r = C(r, n), e()), i = T(), o = async (n) => {
    let s = { ...r, ...n, fetch: n.fetch ?? r.fetch ?? globalThis.fetch, headers: x(r.headers, n.headers) };
    s.security && await I({ ...s, security: s.security }), s.body && s.bodySerializer && (s.body = s.bodySerializer(s.body)), (s.body === void 0 || s.body === "") && s.headers.delete("Content-Type");
    let l = S(s), f = { redirect: "follow", ...s }, u = new Request(l, f);
    for (let p of i.request._fns) u = await p(u, s);
    let k = s.fetch, c = await k(u);
    for (let p of i.response._fns) c = await p(c, u, s);
    let m = { request: u, response: c };
    if (c.ok) {
      if (c.status === 204 || c.headers.get("Content-Length") === "0") return { data: {}, ...m };
      let p = (s.parseAs === "auto" ? P(c.headers.get("Content-Type")) : s.parseAs) ?? "json";
      if (p === "stream") return { data: c.body, ...m };
      let b = await c[p]();
      return p === "json" && (s.responseValidator && await s.responseValidator(b), s.responseTransformer && (b = await s.responseTransformer(b))), { data: b, ...m };
    }
    let g = await c.text();
    try {
      g = JSON.parse(g);
    } catch {
    }
    let d = g;
    for (let p of i.error._fns) d = await p(g, c, u, s);
    if (d = d || {}, s.throwOnError) throw d;
    return { error: d, ...m };
  };
  return { buildUrl: S, connect: (n) => o({ ...n, method: "CONNECT" }), delete: (n) => o({ ...n, method: "DELETE" }), get: (n) => o({ ...n, method: "GET" }), getConfig: e, head: (n) => o({ ...n, method: "HEAD" }), interceptors: i, options: (n) => o({ ...n, method: "OPTIONS" }), patch: (n) => o({ ...n, method: "PATCH" }), post: (n) => o({ ...n, method: "POST" }), put: (n) => o({ ...n, method: "PUT" }), request: o, setConfig: a, trace: (n) => o({ ...n, method: "TRACE" }) };
};

// src/api/client.gen.ts
var client = J(w({
  baseUrl: "http://localhost:8000",
  throwOnError: true
}));

// src/api/sdk.gen.ts
var DefaultService = class {
  /**
   * Retrieves the current user's identity, tenant, and databases.
   */
  static getUserIdentity(options) {
    return (options?.client ?? client).get({
      url: "/api/v2/auth/identity",
      ...options
    });
  }
  /**
   * Health check endpoint that returns 200 if the server and executor are ready
   */
  static healthcheck(options) {
    return (options?.client ?? client).get({
      url: "/api/v2/healthcheck",
      ...options
    });
  }
  /**
   * Heartbeat endpoint that returns a nanosecond timestamp of the current time.
   */
  static heartbeat(options) {
    return (options?.client ?? client).get({
      url: "/api/v2/heartbeat",
      ...options
    });
  }
  /**
   * Pre-flight checks endpoint reporting basic readiness info.
   */
  static preFlightChecks(options) {
    return (options?.client ?? client).get({
      url: "/api/v2/pre-flight-checks",
      ...options
    });
  }
  /**
   * Reset endpoint allowing authorized users to reset the database.
   */
  static reset(options) {
    return (options?.client ?? client).post({
      url: "/api/v2/reset",
      ...options
    });
  }
  /**
   * Creates a new tenant.
   */
  static createTenant(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Returns an existing tenant by name.
   */
  static getTenant(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant_name}",
      ...options
    });
  }
  /**
   * Updates an existing tenant by name.
   */
  static updateTenant(options) {
    return (options.client ?? client).patch({
      url: "/api/v2/tenants/{tenant_name}",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Lists all databases for a given tenant.
   */
  static listDatabases(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases",
      ...options
    });
  }
  /**
   * Creates a new database for a given tenant.
   */
  static createDatabase(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Deletes a specific database.
   */
  static deleteDatabase(options) {
    return (options.client ?? client).delete({
      url: "/api/v2/tenants/{tenant}/databases/{database}",
      ...options
    });
  }
  /**
   * Retrieves a specific database by name.
   */
  static getDatabase(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases/{database}",
      ...options
    });
  }
  /**
   * Lists all collections in the specified database.
   */
  static listCollections(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections",
      ...options
    });
  }
  /**
   * Creates a new collection under the specified database.
   */
  static createCollection(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Deletes a collection in a given database.
   */
  static deleteCollection(options) {
    return (options.client ?? client).delete({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}",
      ...options
    });
  }
  /**
   * Retrieves a collection by ID or name.
   */
  static getCollection(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}",
      ...options
    });
  }
  /**
   * Updates an existing collection's name or metadata.
   */
  static updateCollection(options) {
    return (options.client ?? client).put({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Adds records to a collection.
   */
  static collectionAdd(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/add",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Retrieves the number of records in a collection.
   */
  static collectionCount(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/count",
      ...options
    });
  }
  /**
   * Deletes records in a collection. Can filter by IDs or metadata.
   */
  static collectionDelete(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/delete",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Forks an existing collection.
   */
  static forkCollection(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/fork",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Retrieves records from a collection by ID or metadata filter.
   */
  static collectionGet(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/get",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Query a collection in a variety of ways, including vector search, metadata filtering, and full-text search
   */
  static collectionQuery(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/query",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Updates records in a collection by ID.
   */
  static collectionUpdate(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/update",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Upserts records in a collection (create if not exists, otherwise update).
   */
  static collectionUpsert(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/upsert",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Retrieves the total number of collections in a given database.
   */
  static countCollections(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections_count",
      ...options
    });
  }
  /**
   * Returns the version of the server.
   */
  static version(options) {
    return (options?.client ?? client).get({
      url: "/api/v2/version",
      ...options
    });
  }
};

// src/errors.ts
var ChromaError = class extends Error {
  constructor(name, message, cause) {
    super(message);
    this.cause = cause;
    this.name = name;
  }
};
var ChromaConnectionError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaConnectionError";
  }
};
var ChromaServerError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaServerError";
  }
};
var ChromaClientError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaClientError";
  }
};
var ChromaUnauthorizedError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaAuthError";
  }
};
var ChromaForbiddenError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaForbiddenError";
  }
};
var ChromaNotFoundError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaNotFoundError";
  }
};
var ChromaValueError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaValueError";
  }
};
var InvalidCollectionError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "InvalidCollectionError";
  }
};
var InvalidArgumentError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "InvalidArgumentError";
  }
};
var ChromaUniqueError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaUniqueError";
  }
};
var ChromaQuotaExceededError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaQuotaExceededError";
  }
};
var ChromaRateLimitError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaRateLimitError";
  }
};
function createErrorByType(type, message) {
  switch (type) {
    case "InvalidCollection":
      return new InvalidCollectionError(message);
    case "InvalidArgumentError":
      return new InvalidArgumentError(message);
    default:
      return void 0;
  }
}

// src/utils.ts
var DEFAULT_TENANT = "default_tenant";
var DEFAULT_DATABASE = "default_database";
var defaultAdminClientArgs = {
  host: "localhost",
  port: 8e3,
  ssl: false
};
var defaultChromaClientArgs = {
  ...defaultAdminClientArgs,
  tenant: DEFAULT_TENANT,
  database: DEFAULT_DATABASE
};
var normalizeMethod = (method) => {
  if (method) {
    switch (method.toUpperCase()) {
      case "GET":
        return "GET";
      case "POST":
        return "POST";
      case "PUT":
        return "PUT";
      case "DELETE":
        return "DELETE";
      case "HEAD":
        return "HEAD";
      case "CONNECT":
        return "CONNECT";
      case "OPTIONS":
        return "OPTIONS";
      case "PATCH":
        return "PATCH";
      case "TRACE":
        return "TRACE";
      default:
        return void 0;
    }
  }
  return void 0;
};
var validateRecordSetLengthConsistency = (recordSet) => {
  const lengths = Object.entries(recordSet).filter(
    ([field, value]) => recordSetFields.includes(field) && value !== void 0
  ).map(([field, value]) => [field, value.length]);
  if (lengths.length === 0) {
    throw new ChromaValueError(
      `At least one of ${recordSetFields.join(", ")} must be provided`
    );
  }
  const zeroLength = lengths.filter(([_2, length]) => length === 0).map(([field, _2]) => field);
  if (zeroLength.length > 0) {
    throw new ChromaValueError(
      `Non-empty lists are required for ${zeroLength.join(", ")}`
    );
  }
  if (new Set(lengths.map(([_2, length]) => length)).size > 1) {
    throw new ChromaValueError(
      `Unequal lengths for fields ${lengths.map(([field, _2]) => field).join(", ")}`
    );
  }
};
var validateEmbeddings = ({
  embeddings,
  fieldName = "embeddings"
}) => {
  if (!Array.isArray(embeddings)) {
    throw new ChromaValueError(
      `Expected '${fieldName}' to be an array, but got ${typeof embeddings}`
    );
  }
  if (embeddings.length === 0) {
    throw new ChromaValueError(
      "Expected embeddings to be an array with at least one item"
    );
  }
  if (!embeddings.filter((e) => e.every((n) => typeof n === "number"))) {
    throw new ChromaValueError(
      "Expected each embedding to be an array of numbers"
    );
  }
  embeddings.forEach((embedding, i) => {
    if (embedding.length === 0) {
      throw new ChromaValueError(
        `Expected each embedding to be a non-empty array of numbers, but got an empty array at index ${i}`
      );
    }
  });
};
var validateDocuments = ({
  documents,
  nullable = false,
  fieldName = "documents"
}) => {
  if (!Array.isArray(documents)) {
    throw new ChromaValueError(
      `Expected '${fieldName}' to be an array, but got ${typeof documents}`
    );
  }
  if (documents.length === 0) {
    throw new ChromaValueError(
      `Expected '${fieldName}' to be a non-empty list`
    );
  }
  documents.forEach((document) => {
    if (!nullable && typeof document !== "string" && !document) {
      throw new ChromaValueError(
        `Expected each document to be a string, but got ${typeof document}`
      );
    }
  });
};
var validateIDs = (ids) => {
  if (!Array.isArray(ids)) {
    throw new ChromaValueError(
      `Expected 'ids' to be an array, but got ${typeof ids}`
    );
  }
  if (ids.length === 0) {
    throw new ChromaValueError("Expected 'ids' to be a non-empty list");
  }
  const nonStrings = ids.map((id, i) => [id, i]).filter(([id, _2]) => typeof id !== "string").map(([_2, i]) => i);
  if (nonStrings.length > 0) {
    throw new ChromaValueError(
      `Found non-string IDs at ${nonStrings.join(", ")}`
    );
  }
  const seen = /* @__PURE__ */ new Set();
  const duplicates = ids.filter((id) => {
    if (seen.has(id)) {
      return id;
    }
    seen.add(id);
  });
  let message = "Expected IDs to be unique, but found duplicates of";
  if (duplicates.length > 0 && duplicates.length <= 5) {
    throw new ChromaValueError(`${message} ${duplicates.join(", ")}`);
  }
  if (duplicates.length > 0) {
    throw new ChromaValueError(
      `${message} ${duplicates.slice(0, 5).join(", ")}, ..., ${duplicates.slice(duplicates.length - 5).join(", ")}`
    );
  }
};
var validateMetadata = (metadata) => {
  if (!metadata) {
    return;
  }
  if (Object.keys(metadata).length === 0) {
    throw new ChromaValueError("Expected metadata to be non-empty");
  }
  if (!Object.values(metadata).every(
    (v) => v === null || v === void 0 || typeof v === "string" || typeof v === "number" || typeof v === "boolean"
  )) {
    throw new ChromaValueError(
      "Expected metadata to be a string, number, boolean, or nullable"
    );
  }
};
var validateMetadatas = (metadatas) => {
  if (!Array.isArray(metadatas)) {
    throw new ChromaValueError(
      `Expected metadatas to be an array, but got ${typeof metadatas}`
    );
  }
  metadatas.forEach((metadata) => validateMetadata(metadata));
};
var validateBaseRecordSet = ({
  recordSet,
  update = false,
  embeddingsField = "embeddings",
  documentsField = "documents"
}) => {
  if (!recordSet.embeddings && !recordSet.documents && !update) {
    throw new ChromaValueError(
      `At least one of '${embeddingsField}' and '${documentsField}' must be provided`
    );
  }
  if (recordSet.embeddings) {
    validateEmbeddings({
      embeddings: recordSet.embeddings,
      fieldName: embeddingsField
    });
  }
  if (recordSet.documents) {
    validateDocuments({
      documents: recordSet.documents,
      fieldName: documentsField
    });
  }
  if (recordSet.metadatas) {
    validateMetadatas(recordSet.metadatas);
  }
};
var validateMaxBatchSize = (recordSetLength, maxBatchSize) => {
  if (recordSetLength > maxBatchSize) {
    throw new ChromaValueError(
      `Record set length ${recordSetLength} exceeds max batch size ${maxBatchSize}`
    );
  }
};
var validateWhere = (where) => {
  if (typeof where !== "object") {
    throw new ChromaValueError("Expected where to be a non-empty object");
  }
  if (Object.keys(where).length != 1) {
    throw new ChromaValueError(
      `Expected 'where' to have exactly one operator, but got ${Object.keys(where).length}`
    );
  }
  Object.entries(where).forEach(([key, value]) => {
    if (key !== "$and" && key !== "$or" && key !== "$in" && key !== "$nin" && !["string", "number", "boolean", "object"].includes(typeof value)) {
      throw new ChromaValueError(
        `Expected 'where' value to be a string, number, boolean, or an operator expression, but got ${value}`
      );
    }
    if (key === "$and" || key === "$or") {
      if (Object.keys(value).length <= 1) {
        throw new ChromaValueError(
          `Expected 'where' value for $and or $or to be a list of 'where' expressions, but got ${value}`
        );
      }
      value.forEach((w2) => validateWhere(w2));
      return;
    }
    if (typeof value === "object") {
      if (Object.keys(value).length != 1) {
        throw new ChromaValueError(
          `Expected operator expression to have one operator, but got ${value}`
        );
      }
      const [operator, operand] = Object.entries(value)[0];
      if (["$gt", "$gte", "$lt", "$lte"].includes(operator) && typeof operand !== "number") {
        throw new ChromaValueError(
          `Expected operand value to be a number for ${operator}, but got ${typeof operand}`
        );
      }
      if (["$in", "$nin"].includes(operator) && !Array.isArray(operand)) {
        throw new ChromaValueError(
          `Expected operand value to be an array for ${operator}, but got ${operand}`
        );
      }
      if (!["$gt", "$gte", "$lt", "$lte", "$ne", "$eq", "$in", "$nin"].includes(
        operator
      )) {
        throw new ChromaValueError(
          `Expected operator to be one of $gt, $gte, $lt, $lte, $ne, $eq, $in, $nin, but got ${operator}`
        );
      }
      if (!["string", "number", "boolean"].includes(typeof operand) && !Array.isArray(operand)) {
        throw new ChromaValueError(
          "Expected operand value to be a string, number, boolean, or a list of those types"
        );
      }
      if (Array.isArray(operand) && (operand.length === 0 || !operand.every((item) => typeof item === typeof operand[0]))) {
        throw new ChromaValueError(
          "Expected 'where' operand value to be a non-empty list and all values to be of the same type"
        );
      }
    }
  });
};
var validateWhereDocument = (whereDocument) => {
  if (typeof whereDocument !== "object") {
    throw new ChromaValueError(
      "Expected 'whereDocument' to be a non-empty object"
    );
  }
  if (Object.keys(whereDocument).length != 1) {
    throw new ChromaValueError(
      `Expected 'whereDocument' to have exactly one operator, but got ${whereDocument}`
    );
  }
  const [operator, operand] = Object.entries(whereDocument)[0];
  if (![
    "$contains",
    "$not_contains",
    "$matches",
    "$not_matches",
    "$regex",
    "$not_regex",
    "$and",
    "$or"
  ].includes(operator)) {
    throw new ChromaValueError(
      `Expected 'whereDocument' operator to be one of $contains, $not_contains, $matches, $not_matches, $regex, $not_regex, $and, or $or, but got ${operator}`
    );
  }
  if (operator === "$and" || operator === "$or") {
    if (!Array.isArray(operand)) {
      throw new ChromaValueError(
        `Expected operand for ${operator} to be a list of 'whereDocument' expressions, but got ${operand}`
      );
    }
    if (operand.length <= 1) {
      throw new ChromaValueError(
        `Expected 'whereDocument' operand for ${operator} to be a list with at least two 'whereDocument' expressions`
      );
    }
    operand.forEach((item) => validateWhereDocument(item));
  }
  if ((operand === "$contains" || operand === "$not_contains" || operand === "$regex" || operand === "$not_regex") && (typeof operator !== "string" || operator.length === 0)) {
    throw new ChromaValueError(
      `Expected operand for ${operator} to be a non empty string, but got ${operand}`
    );
  }
};
var validateInclude = ({
  include,
  exclude
}) => {
  if (!Array.isArray(include)) {
    throw new ChromaValueError("Expected 'include' to be a non-empty array");
  }
  const validValues = Object.keys(IncludeEnum);
  include.forEach((item) => {
    if (typeof item !== "string") {
      throw new ChromaValueError("Expected 'include' items to be strings");
    }
    if (!validValues.includes(item)) {
      throw new ChromaValueError(
        `Expected 'include' items to be one of ${validValues.join(
          ", "
        )}, but got ${item}`
      );
    }
    if (exclude?.includes(item)) {
      throw new ChromaValueError(`${item} is not allowed for this operation`);
    }
  });
};
var validateNResults = (nResults) => {
  if (typeof nResults !== "number") {
    throw new ChromaValueError(
      `Expected 'nResults' to be a number, but got ${typeof nResults}`
    );
  }
  if (nResults <= 0) {
    throw new ChromaValueError("Number of requested results has to positive");
  }
};
var parseConnectionPath = (path) => {
  try {
    const url = new URL(path);
    const ssl = url.protocol === "https:";
    const host = url.hostname;
    const port = url.port;
    return {
      ssl,
      host,
      port: Number(port)
    };
  } catch {
    throw new ChromaValueError(`Invalid URL: ${path}`);
  }
};
var packEmbedding = (embedding) => {
  const buffer = new ArrayBuffer(embedding.length * 4);
  const view = new Float32Array(buffer);
  for (let i = 0; i < embedding.length; i++) {
    view[i] = embedding[i];
  }
  return buffer;
};
var embeddingsToBase64Bytes = (embeddings) => {
  return embeddings.map((embedding) => {
    const buffer = packEmbedding(embedding);
    const uint8Array = new Uint8Array(buffer);
    const binaryString = Array.from(
      uint8Array,
      (byte) => String.fromCharCode(byte)
    ).join("");
    return btoa(binaryString);
  });
};

// src/embedding-function.ts
var knownEmbeddingFunctions = /* @__PURE__ */ new Map();
var registerEmbeddingFunction = (name, fn) => {
  if (knownEmbeddingFunctions.has(name)) {
    throw new ChromaValueError(
      `Embedding function with name ${name} is already registered.`
    );
  }
  knownEmbeddingFunctions.set(name, fn);
};
var getEmbeddingFunction = async (collectionName, efConfig) => {
  if (!efConfig) {
    console.warn(
      `No embedding function configuration found for collection ${collectionName}. 'add' and 'query' will fail unless you provide them embeddings directly.`
    );
    return void 0;
  }
  if (efConfig.type === "legacy") {
    console.warn(
      `No embedding function configuration found for collection ${collectionName}. 'add' and 'query' will fail unless you provide them embeddings directly.`
    );
    return void 0;
  }
  const name = efConfig.name;
  const embeddingFunction = knownEmbeddingFunctions.get(name);
  if (!embeddingFunction) {
    console.warn(
      `Collection ${collectionName} was created with the ${embeddingFunction} embedding function. However, the @chroma-core/${embeddingFunction} package is not install. 'add' and 'query' will fail unless you provide them embeddings directly, or install the @chroma-core/${embeddingFunction} package.`
    );
    return void 0;
  }
  let constructorConfig = efConfig.type === "known" ? efConfig.config : {};
  try {
    if (embeddingFunction.buildFromConfig) {
      return embeddingFunction.buildFromConfig(constructorConfig);
    }
    console.warn(
      `Embedding function ${name} does not define a 'buildFromConfig' function. 'add' and 'query' will fail unless you provide them embeddings directly.`
    );
    return void 0;
  } catch (e) {
    console.warn(
      `Embedding function ${name} failed to build with config: ${constructorConfig}. 'add' and 'query' will fail unless you provide them embeddings directly. Error: ${e}`
    );
    return void 0;
  }
};
var serializeEmbeddingFunction = ({
  embeddingFunction,
  configEmbeddingFunction
}) => {
  if (embeddingFunction && configEmbeddingFunction) {
    throw new ChromaValueError(
      "Embedding function provided when already defined in the collection configuration"
    );
  }
  if (!embeddingFunction && !configEmbeddingFunction) {
    return void 0;
  }
  const ef = embeddingFunction || configEmbeddingFunction;
  if (!ef.getConfig || !ef.name || !ef.constructor.buildFromConfig) {
    return { type: "legacy" };
  }
  if (ef.validateConfig) ef.validateConfig(ef.getConfig());
  return {
    name: ef.name,
    type: "known",
    config: ef.getConfig()
  };
};
var getDefaultEFConfig = async () => {
  try {
    const { DefaultEmbeddingFunction } = await Promise.resolve().then(function webpackMissingModule() { var e = new Error("Cannot find module '@chroma-core/default-embed'"); e.code = 'MODULE_NOT_FOUND'; throw e; });
    if (!knownEmbeddingFunctions.has(new DefaultEmbeddingFunction().name)) {
      registerEmbeddingFunction("default", DefaultEmbeddingFunction);
    }
  } catch (e) {
    console.error(e);
    throw new Error(
      "Cannot instantiate a collection with the DefaultEmbeddingFunction. Please install @chroma-core/default-embed, or provide a different embedding function"
    );
  }
  return {
    name: "default",
    type: "known",
    config: {}
  };
};

// src/collection-configuration.ts
var processCreateCollectionConfig = async ({
  configuration,
  embeddingFunction,
  metadata
}) => {
  if (configuration?.hnsw && configuration?.spann) {
    throw new ChromaValueError(
      "Cannot specify both HNSW and SPANN configurations"
    );
  }
  let embeddingFunctionConfiguration = serializeEmbeddingFunction({
    embeddingFunction: embeddingFunction ?? void 0,
    configEmbeddingFunction: configuration?.embeddingFunction
  });
  if (!embeddingFunctionConfiguration && embeddingFunction !== null) {
    embeddingFunctionConfiguration = await getDefaultEFConfig();
  }
  const overallEf = embeddingFunction || configuration?.embeddingFunction;
  if (overallEf && overallEf.defaultSpace && overallEf.supportedSpaces) {
    if (configuration?.hnsw === void 0 && configuration?.spann === void 0) {
      if (metadata === void 0 || metadata?.["hnsw:space"] === void 0) {
        if (!configuration) configuration = {};
        configuration.hnsw = { space: overallEf.defaultSpace() };
      }
    }
    if (configuration?.hnsw && !configuration.hnsw.space && overallEf.defaultSpace) {
      configuration.hnsw.space = overallEf.defaultSpace();
    }
    if (configuration?.spann && !configuration.spann.space && overallEf.defaultSpace) {
      configuration.spann.space = overallEf.defaultSpace();
    }
    if (overallEf.supportedSpaces) {
      const supportedSpaces = overallEf.supportedSpaces();
      if (configuration?.hnsw?.space && !supportedSpaces.includes(configuration.hnsw.space)) {
        console.warn(
          `Space '${configuration.hnsw.space}' is not supported by embedding function '${overallEf.name || "unknown"}'. Supported spaces: ${supportedSpaces.join(", ")}`
        );
      }
      if (configuration?.spann?.space && !supportedSpaces.includes(configuration.spann.space)) {
        console.warn(
          `Space '${configuration.spann.space}' is not supported by embedding function '${overallEf.name || "unknown"}'. Supported spaces: ${supportedSpaces.join(", ")}`
        );
      }
      if (!configuration?.hnsw && !configuration?.spann && metadata && typeof metadata["hnsw:space"] === "string" && !supportedSpaces.includes(metadata["hnsw:space"])) {
        console.warn(
          `Space '${metadata["hnsw:space"]}' from metadata is not supported by embedding function '${overallEf.name || "unknown"}'. Supported spaces: ${supportedSpaces.join(", ")}`
        );
      }
    }
  }
  return {
    ...configuration || {},
    embedding_function: embeddingFunctionConfiguration
  };
};
var processUpdateCollectionConfig = async ({
  collectionName,
  currentConfiguration,
  currentEmbeddingFunction,
  newConfiguration
}) => {
  if (newConfiguration.hnsw && typeof newConfiguration.hnsw !== "object") {
    throw new ChromaValueError(
      "Invalid HNSW config provided in UpdateCollectionConfiguration"
    );
  }
  if (newConfiguration.spann && typeof newConfiguration.spann !== "object") {
    throw new ChromaValueError(
      "Invalid SPANN config provided in UpdateCollectionConfiguration"
    );
  }
  const embeddingFunction = currentEmbeddingFunction || await getEmbeddingFunction(
    collectionName,
    currentConfiguration.embeddingFunction ?? void 0
  );
  const newEmbeddingFunction = newConfiguration.embeddingFunction;
  if (embeddingFunction && embeddingFunction.validateConfigUpdate && newEmbeddingFunction && newEmbeddingFunction.getConfig) {
    embeddingFunction.validateConfigUpdate(newEmbeddingFunction.getConfig());
  }
  return {
    updateConfiguration: {
      hnsw: newConfiguration.hnsw,
      spann: newConfiguration.spann,
      embedding_function: newEmbeddingFunction && serializeEmbeddingFunction({ embeddingFunction: newEmbeddingFunction })
    },
    updateEmbeddingFunction: newEmbeddingFunction
  };
};

// src/collection.ts
var CollectionImpl = class _CollectionImpl {
  /**
   * Creates a new CollectionAPIImpl instance.
   * @param options - Configuration for the collection API
   */
  constructor({
    chromaClient,
    apiClient,
    id,
    name,
    metadata,
    configuration,
    embeddingFunction
  }) {
    this.chromaClient = chromaClient;
    this.apiClient = apiClient;
    this.id = id;
    this._name = name;
    this._metadata = metadata;
    this._configuration = configuration;
    this._embeddingFunction = embeddingFunction;
  }
  get name() {
    return this._name;
  }
  set name(name) {
    this._name = name;
  }
  get configuration() {
    return this._configuration;
  }
  set configuration(configuration) {
    this._configuration = configuration;
  }
  get metadata() {
    return this._metadata;
  }
  set metadata(metadata) {
    this._metadata = metadata;
  }
  get embeddingFunction() {
    return this._embeddingFunction;
  }
  set embeddingFunction(embeddingFunction) {
    this._embeddingFunction = embeddingFunction;
  }
  async path() {
    const clientPath = await this.chromaClient._path();
    return {
      ...clientPath,
      collection_id: this.id
    };
  }
  async embed(documents) {
    if (!this._embeddingFunction) {
      throw new ChromaValueError(
        "Embedding function must be defined for operations requiring embeddings."
      );
    }
    return await this._embeddingFunction.generate(documents);
  }
  async prepareRecords({
    recordSet,
    update = false
  }) {
    const maxBatchSize = await this.chromaClient.getMaxBatchSize();
    validateRecordSetLengthConsistency(recordSet);
    validateIDs(recordSet.ids);
    validateBaseRecordSet({ recordSet, update });
    validateMaxBatchSize(recordSet.ids.length, maxBatchSize);
    if (!recordSet.embeddings && recordSet.documents) {
      recordSet.embeddings = await this.embed(recordSet.documents);
    }
    const preparedRecordSet = { ...recordSet };
    const base64Supported = await this.chromaClient.supportsBase64Encoding();
    if (base64Supported && recordSet.embeddings) {
      preparedRecordSet.embeddings = embeddingsToBase64Bytes(
        recordSet.embeddings
      );
    }
    return preparedRecordSet;
  }
  validateGet(include, ids, where, whereDocument) {
    validateInclude({ include, exclude: ["distances"] });
    if (ids) validateIDs(ids);
    if (where) validateWhere(where);
    if (whereDocument) validateWhereDocument(whereDocument);
  }
  async prepareQuery(recordSet, include, ids, where, whereDocument, nResults) {
    validateBaseRecordSet({
      recordSet,
      embeddingsField: "queryEmbeddings",
      documentsField: "queryTexts"
    });
    validateInclude({ include });
    if (ids) validateIDs(ids);
    if (where) validateWhere(where);
    if (whereDocument) validateWhereDocument(whereDocument);
    if (nResults) validateNResults(nResults);
    let embeddings;
    if (!recordSet.embeddings) {
      embeddings = await this.embed(recordSet.documents);
    } else {
      embeddings = recordSet.embeddings;
    }
    return {
      ...recordSet,
      ids,
      embeddings
    };
  }
  validateDelete(ids, where, whereDocument) {
    if (ids) validateIDs(ids);
    if (where) validateWhere(where);
    if (whereDocument) validateWhereDocument(whereDocument);
  }
  async count() {
    const { data } = await DefaultService.collectionCount({
      client: this.apiClient,
      path: await this.path()
    });
    return data;
  }
  async add({
    ids,
    embeddings,
    metadatas,
    documents,
    uris
  }) {
    const recordSet = {
      ids,
      embeddings,
      documents,
      metadatas,
      uris
    };
    const preparedRecordSet = await this.prepareRecords({ recordSet });
    await DefaultService.collectionAdd({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids: preparedRecordSet.ids,
        embeddings: preparedRecordSet.embeddings,
        documents: preparedRecordSet.documents,
        metadatas: preparedRecordSet.metadatas,
        uris: preparedRecordSet.uris
      }
    });
  }
  async get(args = {}) {
    const {
      ids,
      where,
      limit,
      offset,
      whereDocument,
      include = ["documents", "metadatas"]
    } = args;
    this.validateGet(include, ids, where, whereDocument);
    const { data } = await DefaultService.collectionGet({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids,
        where,
        limit,
        offset,
        where_document: whereDocument,
        include
      }
    });
    return new GetResult({
      documents: data.documents ?? [],
      embeddings: data.embeddings ?? [],
      ids: data.ids,
      include: data.include,
      metadatas: data.metadatas ?? [],
      uris: data.uris ?? []
    });
  }
  async peek({ limit = 10 }) {
    return this.get({ limit });
  }
  async query({
    queryEmbeddings,
    queryTexts,
    queryURIs,
    ids,
    nResults = 10,
    where,
    whereDocument,
    include = ["metadatas", "documents", "distances"]
  }) {
    const recordSet = {
      embeddings: queryEmbeddings,
      documents: queryTexts,
      uris: queryURIs
    };
    const queryRecordSet = await this.prepareQuery(
      recordSet,
      include,
      ids,
      where,
      whereDocument,
      nResults
    );
    const { data } = await DefaultService.collectionQuery({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids: queryRecordSet.ids,
        include,
        n_results: nResults,
        query_embeddings: queryRecordSet.embeddings,
        where,
        where_document: whereDocument
      }
    });
    return new QueryResult({
      distances: data.distances ?? [],
      documents: data.documents ?? [],
      embeddings: data.embeddings ?? [],
      ids: data.ids ?? [],
      include: data.include,
      metadatas: data.metadatas ?? [],
      uris: data.uris ?? []
    });
  }
  async modify({
    name,
    metadata,
    configuration
  }) {
    if (name) this.name = name;
    if (metadata) {
      validateMetadata(metadata);
      this.metadata = metadata;
    }
    const { updateConfiguration, updateEmbeddingFunction } = configuration ? await processUpdateCollectionConfig({
      collectionName: this.name,
      currentConfiguration: this.configuration,
      newConfiguration: configuration,
      currentEmbeddingFunction: this.embeddingFunction
    }) : {};
    if (updateEmbeddingFunction) {
      this.embeddingFunction = updateEmbeddingFunction;
    }
    if (updateConfiguration) {
      this.configuration = {
        hnsw: { ...this.configuration.hnsw, ...updateConfiguration.hnsw },
        spann: { ...this.configuration.spann, ...updateConfiguration.spann },
        embeddingFunction: updateConfiguration.embedding_function
      };
    }
    await DefaultService.updateCollection({
      client: this.apiClient,
      path: await this.path(),
      body: {
        new_name: name,
        new_metadata: metadata,
        new_configuration: updateConfiguration
      }
    });
  }
  async fork({ name }) {
    const { data } = await DefaultService.forkCollection({
      client: this.apiClient,
      path: await this.path(),
      body: { new_name: name }
    });
    return new _CollectionImpl({
      chromaClient: this.chromaClient,
      apiClient: this.apiClient,
      name: data.name,
      id: data.id,
      embeddingFunction: this._embeddingFunction,
      metadata: data.metadata ?? void 0,
      configuration: data.configuration_json
    });
  }
  async update({
    ids,
    embeddings,
    metadatas,
    documents,
    uris
  }) {
    const recordSet = {
      ids,
      embeddings,
      documents,
      metadatas,
      uris
    };
    const preparedRecordSet = await this.prepareRecords({
      recordSet,
      update: true
    });
    await DefaultService.collectionUpdate({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids: preparedRecordSet.ids,
        embeddings: preparedRecordSet.embeddings,
        metadatas: preparedRecordSet.metadatas,
        uris: preparedRecordSet.uris,
        documents: preparedRecordSet.documents
      }
    });
  }
  async upsert({
    ids,
    embeddings,
    metadatas,
    documents,
    uris
  }) {
    const recordSet = {
      ids,
      embeddings,
      documents,
      metadatas,
      uris
    };
    const preparedRecordSet = await this.prepareRecords({
      recordSet
    });
    await DefaultService.collectionUpsert({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids: preparedRecordSet.ids,
        embeddings: preparedRecordSet.embeddings,
        metadatas: preparedRecordSet.metadatas,
        uris: preparedRecordSet.uris,
        documents: preparedRecordSet.documents
      }
    });
  }
  async delete({
    ids,
    where,
    whereDocument
  }) {
    this.validateDelete(ids, where, whereDocument);
    await DefaultService.collectionDelete({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids,
        where,
        where_document: whereDocument
      }
    });
  }
};

// src/next.ts
function withChroma(userNextConfig = {}) {
  const originalWebpackFunction = userNextConfig.webpack;
  const newWebpackFunction = (config, options) => {
    if (!Array.isArray(config.externals)) {
      config.externals = [];
    }
    const externalsToAdd = ["@huggingface/transformers", "chromadb"];
    for (const ext of externalsToAdd) {
      if (!config.externals.includes(ext)) {
        config.externals.push(ext);
      }
    }
    if (typeof originalWebpackFunction === "function") {
      return originalWebpackFunction(config, options);
    }
    return config;
  };
  return {
    ...userNextConfig,
    webpack: newWebpackFunction
  };
}

// src/chroma-fetch.ts
var offlineError = (error) => {
  return Boolean(
    (error?.name === "TypeError" || error?.name === "FetchError") && (error.message?.includes("fetch failed") || error.message?.includes("Failed to fetch") || error.message?.includes("ENOTFOUND"))
  );
};
var chromaFetch = async (input, init) => {
  let response;
  try {
    response = await fetch(input, init);
  } catch (err) {
    if (offlineError(err)) {
      throw new ChromaConnectionError(
        "Failed to connect to chromadb. Make sure your server is running and try again. If you are running from a browser, make sure that your chromadb instance is configured to allow requests from the current origin using the CHROMA_SERVER_CORS_ALLOW_ORIGINS environment variable."
      );
    }
    throw new ChromaConnectionError("Failed to connect to Chroma");
  }
  if (response.ok) {
    return response;
  }
  switch (response.status) {
    case 400:
      let status = "Bad Request";
      try {
        const responseBody = await response.json();
        status = responseBody.message || status;
      } catch {
      }
      throw new ChromaClientError(
        `Bad request to ${input.url || "Chroma"} with status: ${status}`
      );
    case 401:
      throw new ChromaUnauthorizedError(`Unauthorized`);
    case 403:
      throw new ChromaForbiddenError(
        `You do not have permission to access the requested resource.`
      );
    case 404:
      throw new ChromaNotFoundError(
        `The requested resource could not be found`
      );
    case 409:
      throw new ChromaUniqueError("The resource already exists");
    case 422:
      const body = await response.json();
      if (body && body.message && (body.message.startsWith("Quota exceeded") || body.message.startsWith("Billing limit exceeded"))) {
        throw new ChromaQuotaExceededError(body?.message);
      }
      break;
    case 429:
      throw new ChromaRateLimitError("Rate limit exceeded");
  }
  throw new ChromaConnectionError(
    `Unable to connect to the chromadb server (status: ${response.status}). Please try again later.`
  );
};

// src/admin-client.ts
var AdminClient = class {
  /**
   * Creates a new AdminClient instance.
   * @param args - Optional configuration for the admin client
   */
  constructor(args) {
    const { host, port, ssl, headers, fetchOptions } = args || defaultAdminClientArgs;
    const baseUrl = `${ssl ? "https" : "http"}://${host}:${port}`;
    const configOptions = {
      ...fetchOptions,
      method: normalizeMethod(fetchOptions?.method),
      baseUrl,
      headers
    };
    this.apiClient = J(w(configOptions));
    this.apiClient.setConfig({ fetch: chromaFetch });
  }
  /**
   * Creates a new database within a tenant.
   * @param options - Database creation options
   * @param options.name - Name of the database to create
   * @param options.tenant - Tenant that will own the database
   */
  async createDatabase({
    name,
    tenant
  }) {
    await DefaultService.createDatabase({
      client: this.apiClient,
      path: { tenant },
      body: { name }
    });
  }
  /**
   * Retrieves information about a specific database.
   * @param options - Database retrieval options
   * @param options.name - Name of the database to retrieve
   * @param options.tenant - Tenant that owns the database
   * @returns Promise resolving to database information
   */
  async getDatabase({
    name,
    tenant
  }) {
    const { data } = await DefaultService.getDatabase({
      client: this.apiClient,
      path: { tenant, database: name }
    });
    return data;
  }
  /**
   * Deletes a database and all its data.
   * @param options - Database deletion options
   * @param options.name - Name of the database to delete
   * @param options.tenant - Tenant that owns the database
   * @warning This operation is irreversible and will delete all data
   */
  async deleteDatabase({
    name,
    tenant
  }) {
    await DefaultService.deleteDatabase({
      client: this.apiClient,
      path: { tenant, database: name }
    });
  }
  /**
   * Lists all databases within a tenant.
   * @param args - Listing parameters including tenant and pagination
   * @returns Promise resolving to an array of database information
   */
  async listDatabases(args) {
    const { limit = 100, offset = 0, tenant } = args;
    const { data } = await DefaultService.listDatabases({
      client: this.apiClient,
      path: { tenant },
      query: { limit, offset }
    });
    return data;
  }
  /**
   * Creates a new tenant.
   * @param options - Tenant creation options
   * @param options.name - Name of the tenant to create
   */
  async createTenant({ name }) {
    await DefaultService.createTenant({
      client: this.apiClient,
      body: { name }
    });
  }
  /**
   * Retrieves information about a specific tenant.
   * @param options - Tenant retrieval options
   * @param options.name - Name of the tenant to retrieve
   * @returns Promise resolving to the tenant name
   */
  async getTenant({ name }) {
    const { data } = await DefaultService.getTenant({
      client: this.apiClient,
      path: { tenant_name: name }
    });
    return data.name;
  }
};

// src/chroma-client.ts

var ChromaClient = class {
  /**
   * Creates a new ChromaClient instance.
   * @param args - Configuration options for the client
   */
  constructor(args = {}) {
    let {
      host = defaultChromaClientArgs.host,
      port = defaultChromaClientArgs.port,
      ssl = defaultChromaClientArgs.ssl,
      tenant = defaultChromaClientArgs.tenant,
      database = defaultChromaClientArgs.database,
      headers = defaultChromaClientArgs.headers,
      fetchOptions = defaultChromaClientArgs.fetchOptions
    } = args;
    if (args.path) {
      console.warn(
        "The 'path' argument is deprecated. Please use 'ssl', 'host', and 'port' instead"
      );
      const parsedPath = parseConnectionPath(args.path);
      ssl = parsedPath.ssl;
      host = parsedPath.host;
      port = parsedPath.port;
    }
    if (args.auth) {
      console.warn(
        "The 'auth' argument is deprecated. Please use 'headers' instead"
      );
      if (!headers) {
        headers = {};
      }
      if (!headers["x-chroma-token"] && args.auth.tokenHeaderType === "X_CHROMA_TOKEN" && args.auth.credentials) {
        headers["x-chroma-token"] = args.auth.credentials;
      }
    }
    const baseUrl = `${ssl ? "https" : "http"}://${host}:${port}`;
    this._tenant = tenant || browser.env.CHROMA_TENANT;
    this._database = database || browser.env.CHROMA_DATABASE;
    const configOptions = {
      ...fetchOptions,
      method: normalizeMethod(fetchOptions?.method),
      baseUrl,
      headers
    };
    this.apiClient = J(w(configOptions));
    this.apiClient.setConfig({ fetch: chromaFetch });
  }
  /**
   * Gets the current tenant name.
   * @returns The tenant name or undefined if not set
   */
  get tenant() {
    return this._tenant;
  }
  set tenant(tenant) {
    this._tenant = tenant;
  }
  /**
   * Gets the current database name.
   * @returns The database name or undefined if not set
   */
  get database() {
    return this._database;
  }
  set database(database) {
    this._database = database;
  }
  /**
   * Gets the preflight checks
   * @returns The preflight checks or undefined if not set
   */
  get preflightChecks() {
    return this._preflightChecks;
  }
  set preflightChecks(preflightChecks) {
    this._preflightChecks = preflightChecks;
  }
  /** @ignore */
  async _path() {
    if (!this._tenant || !this._database) {
      const { tenant, databases } = await this.getUserIdentity();
      const uniqueDBs = [...new Set(databases)];
      this._tenant = tenant;
      if (uniqueDBs.length === 0) {
        throw new ChromaUnauthorizedError(
          `Your API key does not have access to any DBs for tenant ${this.tenant}`
        );
      }
      if (uniqueDBs.length > 1 || uniqueDBs[0] === "*") {
        throw new ChromaValueError(
          "Your API key is scoped to more than 1 DB. Please provide a DB name to the CloudClient constructor"
        );
      }
      this._database = uniqueDBs[0];
    }
    return { tenant: this._tenant, database: this._database };
  }
  /**
   * Gets the user identity information including tenant and accessible databases.
   * @returns Promise resolving to user identity data
   */
  async getUserIdentity() {
    const { data } = await DefaultService.getUserIdentity({
      client: this.apiClient
    });
    return data;
  }
  /**
   * Sends a heartbeat request to check server connectivity.
   * @returns Promise resolving to the server's nanosecond heartbeat timestamp
   */
  async heartbeat() {
    const { data } = await DefaultService.heartbeat({
      client: this.apiClient
    });
    return data["nanosecond heartbeat"];
  }
  /**
   * Lists all collections in the current database.
   * @param args - Optional pagination parameters
   * @param args.limit - Maximum number of collections to return (default: 100)
   * @param args.offset - Number of collections to skip (default: 0)
   * @returns Promise resolving to an array of Collection instances
   */
  async listCollections(args) {
    const { limit = 100, offset = 0 } = args || {};
    const { data } = await DefaultService.listCollections({
      client: this.apiClient,
      path: await this._path(),
      query: { limit, offset }
    });
    return Promise.all(
      data.map(
        async (collection) => new CollectionImpl({
          chromaClient: this,
          apiClient: this.apiClient,
          name: collection.name,
          id: collection.id,
          embeddingFunction: await getEmbeddingFunction(
            collection.name,
            collection.configuration_json.embedding_function ?? void 0
          ),
          configuration: collection.configuration_json,
          metadata: collection.metadata ?? void 0
        })
      )
    );
  }
  /**
   * Gets the total number of collections in the current database.
   * @returns Promise resolving to the collection count
   */
  async countCollections() {
    const { data } = await DefaultService.countCollections({
      client: this.apiClient,
      path: await this._path()
    });
    return data;
  }
  /**
   * Creates a new collection with the specified configuration.
   * @param options - Collection creation options
   * @param options.name - The name of the collection
   * @param options.configuration - Optional collection configuration
   * @param options.metadata - Optional metadata for the collection
   * @param options.embeddingFunction - Optional embedding function to use. Defaults to `DefaultEmbeddingFunction` from @chroma-core/default-embed
   * @returns Promise resolving to the created Collection instance
   * @throws Error if a collection with the same name already exists
   */
  async createCollection({
    name,
    configuration,
    metadata,
    embeddingFunction
  }) {
    const collectionConfig = await processCreateCollectionConfig({
      configuration,
      embeddingFunction,
      metadata
    });
    const { data } = await DefaultService.createCollection({
      client: this.apiClient,
      path: await this._path(),
      body: {
        name,
        configuration: collectionConfig,
        metadata,
        get_or_create: false
      }
    });
    return new CollectionImpl({
      chromaClient: this,
      apiClient: this.apiClient,
      name,
      configuration: data.configuration_json,
      metadata,
      embeddingFunction: embeddingFunction ?? await getEmbeddingFunction(
        data.name,
        data.configuration_json.embedding_function ?? void 0
      ),
      id: data.id
    });
  }
  /**
   * Retrieves an existing collection by name.
   * @param options - Collection retrieval options
   * @param options.name - The name of the collection to retrieve
   * @param options.embeddingFunction - Optional embedding function. Should match the one used to create the collection.
   * @returns Promise resolving to the Collection instance
   * @throws Error if the collection does not exist
   */
  async getCollection({
    name,
    embeddingFunction
  }) {
    const { data } = await DefaultService.getCollection({
      client: this.apiClient,
      path: { ...await this._path(), collection_id: name }
    });
    return new CollectionImpl({
      chromaClient: this,
      apiClient: this.apiClient,
      name,
      configuration: data.configuration_json,
      metadata: data.metadata ?? void 0,
      embeddingFunction: embeddingFunction ? embeddingFunction : await getEmbeddingFunction(
        data.name,
        data.configuration_json.embedding_function ?? void 0
      ),
      id: data.id
    });
  }
  /**
   * Retrieves multiple collections by name.
   * @param items - Array of collection names or objects with name and optional embedding function (should match the ones used to create the collections)
   * @returns Promise resolving to an array of Collection instances
   */
  async getCollections(items) {
    if (items.length === 0) return [];
    let requestedCollections = items;
    if (typeof items[0] === "string") {
      requestedCollections = items.map((item) => {
        return { name: item, embeddingFunction: void 0 };
      });
    }
    let collections = requestedCollections;
    return Promise.all(
      collections.map(async (collection) => {
        return this.getCollection({ ...collection });
      })
    );
  }
  /**
   * Gets an existing collection or creates it if it doesn't exist.
   * @param options - Collection options
   * @param options.name - The name of the collection
   * @param options.configuration - Optional collection configuration (used only if creating)
   * @param options.metadata - Optional metadata for the collection (used only if creating)
   * @param options.embeddingFunction - Optional embedding function to use
   * @returns Promise resolving to the Collection instance
   */
  async getOrCreateCollection({
    name,
    configuration,
    metadata,
    embeddingFunction
  }) {
    const collectionConfig = await processCreateCollectionConfig({
      configuration,
      embeddingFunction,
      metadata
    });
    const { data } = await DefaultService.createCollection({
      client: this.apiClient,
      path: await this._path(),
      body: {
        name,
        configuration: collectionConfig,
        metadata,
        get_or_create: true
      }
    });
    return new CollectionImpl({
      chromaClient: this,
      apiClient: this.apiClient,
      name,
      configuration: data.configuration_json,
      metadata: data.metadata ?? void 0,
      embeddingFunction: embeddingFunction ?? await getEmbeddingFunction(
        name,
        data.configuration_json.embedding_function ?? void 0
      ),
      id: data.id
    });
  }
  /**
   * Deletes a collection and all its data.
   * @param options - Deletion options
   * @param options.name - The name of the collection to delete
   */
  async deleteCollection({ name }) {
    await DefaultService.deleteCollection({
      client: this.apiClient,
      path: { ...await this._path(), collection_id: name }
    });
  }
  /**
   * Resets the entire database, deleting all collections and data.
   * @returns Promise that resolves when the reset is complete
   * @warning This operation is irreversible and will delete all data
   */
  async reset() {
    await DefaultService.reset({
      client: this.apiClient
    });
  }
  /**
   * Gets the version of the Chroma server.
   * @returns Promise resolving to the server version string
   */
  async version() {
    const { data } = await DefaultService.version({
      client: this.apiClient
    });
    return data;
  }
  /**
   * Gets the preflight checks
   * @returns Promise resolving to the preflight checks
   */
  async getPreflightChecks() {
    if (!this.preflightChecks) {
      const { data } = await DefaultService.preFlightChecks({
        client: this.apiClient
      });
      this.preflightChecks = data;
      return this.preflightChecks;
    }
    return this.preflightChecks;
  }
  /**
   * Gets the max batch size
   * @returns Promise resolving to the max batch size
   */
  async getMaxBatchSize() {
    const preflightChecks = await this.getPreflightChecks();
    return preflightChecks.max_batch_size ?? -1;
  }
  /**
   * Gets whether base64_encoding is supported by the connected server
   * @returns Promise resolving to whether base64_encoding is supported
   */
  async supportsBase64Encoding() {
    const preflightChecks = await this.getPreflightChecks();
    return preflightChecks.supports_base64_encoding ?? false;
  }
};

// src/cloud-client.ts

var CloudClient = class extends ChromaClient {
  /**
   * Creates a new CloudClient instance for Chroma Cloud.
   * @param args - Cloud client configuration options
   */
  constructor(args = {}) {
    const apiKey = args.apiKey || browser.env.CHROMA_API_KEY;
    if (!apiKey) {
      throw new ChromaValueError(
        "Missing API key. Please provide it to the CloudClient constructor or set your CHROMA_API_KEY environment variable"
      );
    }
    const tenant = args.tenant || browser.env.CHROMA_TENANT;
    const database = args.database || browser.env.CHROMA_DATABASE;
    super({
      host: "api.trychroma.com",
      port: 8e3,
      ssl: true,
      tenant,
      database,
      headers: { "x-chroma-token": apiKey },
      fetchOptions: args.fetchOptions
    });
    this.tenant = tenant;
    this.database = database;
  }
};
var AdminCloudClient = class extends AdminClient {
  /**
   * Creates a new AdminCloudClient instance for cloud admin operations.
   * @param args - Admin cloud client configuration options
   */
  constructor(args = {}) {
    const apiKey = args.apiKey || browser.env.CHROMA_API_KEY;
    if (!apiKey) {
      throw new ChromaValueError(
        "Missing API key. Please provide it to the CloudClient constructor or set your CHROMA_API_KEY environment variable"
      );
    }
    super({
      host: "api.trychroma.com",
      port: 8e3,
      ssl: true,
      headers: { "x-chroma-token": apiKey },
      fetchOptions: args.fetchOptions
    });
  }
};

//# sourceMappingURL=chromadb.mjs.map
;// CONCATENATED MODULE: ./node_modules/uuid/dist/esm-browser/native.js
const randomUUID = typeof crypto !== 'undefined' && crypto.randomUUID && crypto.randomUUID.bind(crypto);
/* harmony default export */ const esm_browser_native = ({ randomUUID });

;// CONCATENATED MODULE: ./node_modules/uuid/dist/esm-browser/rng.js
let getRandomValues;
const rnds8 = new Uint8Array(16);
function rng() {
    if (!getRandomValues) {
        if (typeof crypto === 'undefined' || !crypto.getRandomValues) {
            throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
        }
        getRandomValues = crypto.getRandomValues.bind(crypto);
    }
    return getRandomValues(rnds8);
}

;// CONCATENATED MODULE: ./node_modules/uuid/dist/esm-browser/stringify.js

const byteToHex = [];
for (let i = 0; i < 256; ++i) {
    byteToHex.push((i + 0x100).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
    return (byteToHex[arr[offset + 0]] +
        byteToHex[arr[offset + 1]] +
        byteToHex[arr[offset + 2]] +
        byteToHex[arr[offset + 3]] +
        '-' +
        byteToHex[arr[offset + 4]] +
        byteToHex[arr[offset + 5]] +
        '-' +
        byteToHex[arr[offset + 6]] +
        byteToHex[arr[offset + 7]] +
        '-' +
        byteToHex[arr[offset + 8]] +
        byteToHex[arr[offset + 9]] +
        '-' +
        byteToHex[arr[offset + 10]] +
        byteToHex[arr[offset + 11]] +
        byteToHex[arr[offset + 12]] +
        byteToHex[arr[offset + 13]] +
        byteToHex[arr[offset + 14]] +
        byteToHex[arr[offset + 15]]).toLowerCase();
}
function stringify(arr, offset = 0) {
    const uuid = unsafeStringify(arr, offset);
    if (!validate(uuid)) {
        throw TypeError('Stringified UUID is invalid');
    }
    return uuid;
}
/* harmony default export */ const esm_browser_stringify = ((/* unused pure expression or super */ null && (stringify)));

;// CONCATENATED MODULE: ./node_modules/uuid/dist/esm-browser/v4.js



function v4(options, buf, offset) {
    if (esm_browser_native.randomUUID && !buf && !options) {
        return esm_browser_native.randomUUID();
    }
    options = options || {};
    const rnds = options.random ?? options.rng?.() ?? rng();
    if (rnds.length < 16) {
        throw new Error('Random bytes length must be >= 16');
    }
    rnds[6] = (rnds[6] & 0x0f) | 0x40;
    rnds[8] = (rnds[8] & 0x3f) | 0x80;
    if (buf) {
        offset = offset || 0;
        if (offset < 0 || offset + 16 > buf.length) {
            throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
        for (let i = 0; i < 16; ++i) {
            buf[offset + i] = rnds[i];
        }
        return buf;
    }
    return unsafeStringify(rnds);
}
/* harmony default export */ const esm_browser_v4 = (v4);

;// CONCATENATED MODULE: ./src/embeddings.ts
// 创建新文件处理嵌入相关功能
const pendingEmbeddingRequests = new Map();

// 创建离屏文档
async function createOffscreenDocument() {
  try {
    // 检查是否已经存在离屏文档
    const existingContexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT']
    });
    if (existingContexts.length > 0) {
      // console.log('离屏文档已存在');
      return;
    }
    console.log('创建离屏文档...');
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['WORKERS'],
      justification: '需要使用 WebAssembly 来运行嵌入模型'
    });
    console.log('离屏文档创建成功');
  } catch (error) {
    console.error('创建离屏文档失败:', error);
  }
}

// 通过离屏文档获取嵌入向量
async function getEmbeddingViaOffscreen(text) {
  const isBackground = typeof ServiceWorkerGlobalScope !== 'undefined' && self instanceof ServiceWorkerGlobalScope;
  if (isBackground) {
    return await getEmbeddingInBackground(text);
  } else {
    const result = await chrome.runtime.sendMessage({
      type: 'EXEC_EMBEDDING_REQUEST',
      text
    });
    return result;
  }
}
async function getEmbeddingInBackground(text) {
  try {
    await createOffscreenDocument();

    // 生成唯一请求ID
    const requestId = Date.now().toString() + Math.random().toString().slice(2);

    // 创建Promise并存储
    const resultPromise = new Promise((resolve, reject) => {
      pendingEmbeddingRequests.set(requestId, {
        resolve,
        reject
      });

      // 设置超时
      setTimeout(() => {
        if (pendingEmbeddingRequests.has(requestId)) {
          pendingEmbeddingRequests.delete(requestId);
          reject(new Error('获取嵌入向量超时'));
        }
      }, 30000); // 30秒超时
    });

    // 发送消息到离屏文档
    chrome.runtime.sendMessage({
      type: 'GET_EMBEDDING',
      requestId,
      text
    });
    return resultPromise;
  } catch (error) {
    console.error('通过离屏文档获取嵌入向量失败:', error);
    return new Array(384).fill(0);
  }
}

// 处理嵌入结果
function handleEmbeddingResult(message) {
  if (message.type === 'EMBEDDING_RESULT') {
    const requestId = message.requestId;
    const pendingRequest = pendingEmbeddingRequests.get(requestId);
    if (pendingRequest) {
      pendingEmbeddingRequests.delete(requestId);
      pendingRequest.resolve(message.embedding);
    }
  }
}
;// CONCATENATED MODULE: ./src/utils.ts
// 环境配置类型定义

function formatDate(dateString) {
  const date = new Date(dateString);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}
function uniqBy(array, key) {
  const seen = new Set();
  return array.filter(item => {
    const keyValue = item[key];
    if (seen.has(keyValue)) {
      return false;
    }
    seen.add(keyValue);
    return true;
  });
}
function showToast(message, type, onClose) {
  // 获取或创建容器元素
  const container = document.getElementById('radar-poc-result');
  if (!container) return;

  // 移除现有的 Toast 元素
  const existingToast = container.querySelector('.radar-poc-toast');
  if (existingToast) {
    container.removeChild(existingToast);
  }

  // 创建新的 Toast 元素
  const toast = document.createElement('div');
  toast.className = `radar-poc-toast radar-poc-toast-${type}`;
  const toastInner = document.createElement('div');
  toastInner.className = 'radar-poc-toast-inner';
  toastInner.textContent = message;
  toast.appendChild(toastInner);
  container.appendChild(toast);

  // 设置定时器在 3 秒后关闭 Toast
  const timer = setTimeout(() => {
    if (container.contains(toast)) {
      container.removeChild(toast);
    }
    if (onClose) {
      onClose();
    }
  }, 3000);

  // 返回一个函数以便手动关闭 Toast
  return () => {
    clearTimeout(timer);
    if (container.contains(toast)) {
      container.removeChild(toast);
    }
    if (onClose) {
      onClose();
    }
  };
}
function transformGroupLinks(inputString) {
  const groupLinkPattern = /\[group:(.+):(\d+)\]/g;
  const transformedString = inputString.replace(groupLinkPattern, (match, groupName, groupId) => {
    return `[${groupName}](/messages/${groupId})`;
  });
  return transformedString;
}
function transformPostLinks(inputString) {
  const postLinkPattern = /\[post:(\d+)\]/g;
  let index = 1;
  const transformedString = inputString.replace(postLinkPattern, (match, postId) => {
    return `[[${index++}]](/l${window.location.pathname}/${postId})`;
  });
  return transformedString;
}

// 默认环境配置
const defaultEnvConfig = {
  SCHEDULED_INTERVAL: Number({"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.SCHEDULED_INTERVAL) || 120,
  ANALYSIS_TYPE: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.ANALYSIS_TYPE || "filter",
  LLM_TYPE: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.LLM_TYPE || "dify",
  ANALYZE_BY_GROUP: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.ANALYZE_BY_GROUP === "true",
  OLLAMA_BASE_URL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OLLAMA_BASE_URL || "http://localhost:11434",
  OLLAMA_MODEL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OLLAMA_MODEL || "deepseek-r1",
  OLLAMA_REVIEW_MODEL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OLLAMA_REVIEW_MODEL || "llama3.1",
  OLLAMA_QUERY_MODEL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OLLAMA_QUERY_MODEL || "llama3.1",
  DIFY_API_KEY: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.DIFY_API_KEY || "",
  DIFY_REVIEW_API_KEY: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.DIFY_REVIEW_API_KEY || "",
  DIFY_API_BASE_URL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.DIFY_API_BASE_URL || "",
  OPENAI_API_KEY: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OPENAI_API_KEY || "",
  OPENAI_MODEL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OPENAI_MODEL || "",
  OPENAI_REVIEW_MODEL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OPENAI_REVIEW_MODEL || "",
  OPENAI_API_BASE_URL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OPENAI_API_BASE_URL || "",
  GROQ_API_KEY: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.GROQ_API_KEY || "",
  GROQ_MODEL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.GROQ_MODEL || "",
  GROQ_REVIEW_MODEL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.GROQ_REVIEW_MODEL || "",
  BOT_API_BASE_URL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.BOT_API_BASE_URL || "https://botman.int.rclabenv.com/v2",
  BOT_TOKEN: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.BOT_TOKEN || "",
  BOT_ID: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.BOT_ID || "4700372020@37439510.bot.glip.net",
  BOT_TYPE: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.BOT_TYPE || "user",
  TEAM_ID: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.TEAM_ID || "",
  ENABLE_BOT: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.ENABLE_BOT === "true",
  LLM_REVIEW_BEFORE_SEND: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.LLM_REVIEW_BEFORE_SEND === "true",
  ENABLE_CHROMA: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.ENABLE_CHROMA === "true",
  CHROMA_API_URL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.CHROMA_API_URL || "http://localhost:8000",
  // 保留用于兼容
  CHROMA_HOST: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.CHROMA_HOST || "localhost",
  CHROMA_PORT: Number({"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.CHROMA_PORT) || 8000,
  CHROMA_SSL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.CHROMA_SSL === "true",
  CHROMA_COLLECTION_NAME: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.CHROMA_COLLECTION_NAME || "",
  JIRA_BASE_URL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.JIRA_BASE_URL || "https://jira.ringcentral.com",
  JIRA_USERNAME: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.JIRA_USERNAME || "",
  JIRA_API_TOKEN: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.JIRA_API_TOKEN || ""
};

// 获取环境配置，如果可能的话从 storage 获取，否则从 process.env 获取
async function getEnvConfig() {
  try {
    const {
      envConfig
    } = await chrome.storage.local.get(['envConfig']);
    if (envConfig) {
      // 将存储的配置与默认配置合并，确保新增的配置项也会被包含
      return {
        ...defaultEnvConfig,
        ...envConfig
      };
    }
  } catch (error) {
    console.error('获取配置失败:', error);
  }

  // 如果获取失败或没有保存的配置，返回默认值
  return defaultEnvConfig;
}
function getDefaultEnvConfig() {
  return defaultEnvConfig;
}
async function getUserInfo() {
  const {
    userinfo
  } = await chrome.storage.local.get(['userinfo']);
  return userinfo;
}

/**
 * 解析 ChromaDB 连接参数，支持新旧配置格式的兼容
 */
function parseChromaConfig(config) {
  // 如果有新的 host 配置，直接使用
  if (config.CHROMA_HOST && config.CHROMA_HOST !== 'localhost') {
    return {
      host: config.CHROMA_HOST,
      port: config.CHROMA_PORT,
      ssl: config.CHROMA_SSL
    };
  }

  // 如果没有配置新的 host，尝试从旧的 CHROMA_API_URL 解析
  if (config.CHROMA_API_URL) {
    try {
      const url = new URL(config.CHROMA_API_URL);
      return {
        host: url.hostname,
        port: url.port ? parseInt(url.port) : url.protocol === 'https:' ? 443 : 8000,
        ssl: url.protocol === 'https:'
      };
    } catch (error) {
      console.warn('解析 CHROMA_API_URL 失败:', error);
      // 回退到默认值
      return {
        host: 'localhost',
        port: config.CHROMA_PORT || 8000,
        ssl: false
      };
    }
  }

  // 都没有配置，使用默认值
  return {
    host: config.CHROMA_HOST || 'localhost',
    port: config.CHROMA_PORT || 8000,
    ssl: config.CHROMA_SSL || false
  };
}
;// CONCATENATED MODULE: ./src/storage/CloudStorage.ts
/**
 * 云端存储管理器
 * 专门管理 ChromaDB 操作，包括向量搜索和完整数据存储
 */







// GraphEntity 替换为 MemoryEntity，类型兼容

/**
 * 自定义空嵌入函数 - 禁用 ChromaDB v3 的默认嵌入
 * 实际嵌入计算通过离屏文档完成
 */
class NullEmbeddingFunction {
  async generate(texts) {
    // 不实际计算嵌入向量，因为我们使用离屏文档方案
    throw new Error('嵌入计算应通过离屏文档完成，不应调用此函数');
  }
}

/**
 * 云端存储管理器
 */
class CloudStorage {
  constructor() {
    this.client = null;
    this.collections = new Map();
    this.username = '';
    this.isInitialized = false;
    // 实体相似度阈值配置
    this.entitySimilarityThreshold = 0.85;
    // 相似度阈值，超过此值认为是同一实体
    // 用户档案维护配置
    this.userprofilesMaintenanceConfig = {
      cleanup_thresholds: {
        min_weight: 0.01,
        max_age_days: 180,
        min_access_count: 1
      },
      aggregation_rules: {
        combine_threshold: 0.8,
        max_records_per_category: 100,
        enable_auto_summary: true,
        summary_frequency_days: 7,
        max_records_per_user: 1000
      },
      update_frequency: {
        full_analysis_days: 7,
        incremental_hours: 24
      },
      vector_update: {
        enable_batch_update: true,
        batch_size: 50,
        update_frequency_hours: 24
      }
    };
    this.config = {
      collections: ['messages', 'webpages', 'projects', 'documents', 'graph-entities', 'userprofiles'],
      batchSize: 100,
      timeout: 10000
    };
  }

  /**
   * 初始化云端存储
   */
  async initialize() {
    try {
      console.log('☁️ 初始化云端存储...');
      const envConfig = await getEnvConfig();
      if (!envConfig.ENABLE_CHROMA) {
        console.log('⚠️ ChromaDB 已禁用，云端存储功能不可用');
        return false;
      }

      // 获取用户信息
      const userinfo = await this.getUserInfo();
      this.username = userinfo.username;

      // 初始化 ChromaDB 客户端
      const chromaConfig = parseChromaConfig(envConfig);
      this.client = new ChromaClient({
        host: chromaConfig.host,
        port: chromaConfig.port,
        ssl: chromaConfig.ssl
      });

      // 初始化集合
      await this.initializeCollections();
      this.isInitialized = true;
      console.log('✅ 云端存储初始化完成');
      return true;
    } catch (error) {
      console.error('❌ 云端存储初始化失败:', error);
      return false;
    }
  }

  /**
   * 检查连接状态
   */
  async isConnected() {
    if (!this.client) return false;
    try {
      await this.client.heartbeat();
      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * 确保已初始化
   */
  ensureInitialized() {
    if (!this.isInitialized) {
      throw new Error('云端存储未初始化');
    }
  }

  /**
   * 增强向量搜索 - 支持多种搜索模式和返回格式
   */
  async searchByVector(query, type) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    this.ensureInitialized();
    const startTime = Date.now();
    const {
      limit = 20,
      nResults = 20,
      collections = ['entities', 'messages', 'webpages'],
      returnType = 'entities',
      sortBy = 'relevance',
      sortOrder = 'desc',
      timeRange,
      minRelevanceScore,
      where: customWhere
    } = options;
    try {
      // 生成查询向量
      const queryEmbedding = await getEmbeddingViaOffscreen(query);

      // 确定搜索的集合
      const collectionMap = {
        'entities': `${this.username}-graph-entities`,
        'messages': `${this.username}-messages`,
        'webpages': `${this.username}-webpages`,
        'userprofiles': `${this.username}-userprofiles`
      };
      const collectionsToSearch = type ? [`${this.username}-graph-entities`] : collections.map(c => collectionMap[c]).filter(Boolean);
      const allResults = [];

      // 在多个集合中搜索
      for (const collectionName of collectionsToSearch) {
        const collection = this.collections.get(collectionName);
        if (!collection) continue;
        try {
          // 构建查询参数
          const queryParams = {
            queryEmbeddings: [queryEmbedding],
            nResults,
            include: ['metadatas', 'documents', 'distances']
          };

          // 构建where条件 - 使用 $and 操作符组合多个条件
          const conditions = [];

          // 1. 添加type过滤（对entities集合有效）
          if (type && collectionName.includes('graph-entities')) {
            conditions.push({
              type: type
            });
          }

          // 2. 添加时间范围过滤（对 messages、webpages 和 userprofiles 有效）
          if (timeRange && (collectionName.includes('messages') || collectionName.includes('webpages') || collectionName.includes('userprofiles'))) {
            let timeField = 'extractedAt';
            if (collectionName.includes('messages')) {
              timeField = 'timestamp';
            } else if (collectionName.includes('userprofiles')) {
              timeField = 'updated_at';
            }
            conditions.push({
              [timeField]: {
                $gte: timeRange.start,
                $lte: timeRange.end
              }
            });
          }

          // 3. 添加自定义过滤条件
          if (customWhere && typeof customWhere === 'object') {
            Object.entries(customWhere).forEach(_ref => {
              let [key, value] = _ref;
              conditions.push({
                [key]: value
              });
            });
          }

          // 4. 应用where条件（只有当有条件时才添加）
          if (conditions.length > 0) {
            if (conditions.length === 1) {
              queryParams.where = conditions[0];
            } else {
              queryParams.where = {
                $and: conditions
              };
            }
          }
          const searchResults = await collection.query(queryParams);

          // 处理搜索结果
          if (searchResults.metadatas?.[0]) {
            for (let i = 0; i < searchResults.metadatas[0].length; i++) {
              const metadata = searchResults.metadatas[0][i];
              const distance = searchResults.distances?.[0]?.[i] || 1;
              const relevanceScore = Math.max(0, 1 - distance); // 余弦距离：1-distance转换为0-1的相关度评分

              // 过滤低相关性结果
              if (minRelevanceScore && relevanceScore < minRelevanceScore) continue;
              if (returnType === 'entities') {
                // 返回实体格式
                const entity = await this.buildEntity({
                  metadata,
                  id: searchResults.ids?.[0]?.[i],
                  document: searchResults.documents?.[0]?.[i],
                  distance,
                  relevanceScore,
                  collectionName
                });
                if (entity) {
                  allResults.push(entity);
                }
              } else if (returnType === 'messages' || collectionName.includes('messages')) {
                // 返回消息格式
                const processedMetadata = this.deserializeChromaMetadata(metadata || {});
                allResults.push({
                  id: searchResults.ids?.[0]?.[i] || `result_${i}`,
                  messageId: searchResults.ids?.[0]?.[i],
                  content: searchResults.documents?.[0]?.[i] || '',
                  sender: metadata?.sender || metadata?.source || 'unknown',
                  datetime: metadata?.datetime || metadata?.extractedAt || Date.now(),
                  relevanceScore,
                  distance,
                  collectionType: this.getCollectionType(collectionName),
                  metadata: processedMetadata
                });
              } else {
                // 返回原始数据格式（用于用户档案查询等）
                allResults.push({
                  id: searchResults.ids?.[0]?.[i],
                  document: searchResults.documents?.[0]?.[i] || '',
                  metadata: metadata,
                  relevanceScore,
                  distance,
                  collectionType: this.getCollectionType(collectionName)
                });
              }
            }
          }
        } catch (error) {
          console.warn(`搜索集合 ${collectionName} 失败:`, error);
        }
      }

      // 应用排序
      allResults.sort((a, b) => {
        let valueA, valueB;
        switch (sortBy) {
          case 'relevance':
            valueA = a.relevanceScore || 0;
            valueB = b.relevanceScore || 0;
            break;
          case 'time':
            valueA = a.timestamp || a.updated || a.created || 0;
            valueB = b.timestamp || b.updated || b.created || 0;
            break;
          case 'importance':
            valueA = a.importance || 0;
            valueB = b.importance || 0;
            break;
          default:
            // 默认按相关度排序
            valueA = a.relevanceScore || 0;
            valueB = b.relevanceScore || 0;
        }
        return sortOrder === 'desc' ? valueB - valueA : valueA - valueB;
      });

      // 分页
      const paginatedResults = allResults.slice(0, limit);
      console.log(`🔍 向量搜索完成: "${query}" -> ${paginatedResults.length}/${allResults.length} 条结果 (${returnType}, 排序:${sortBy})`);
      return {
        data: paginatedResults,
        total: allResults.length,
        source: 'cloud',
        cached: false,
        queryTime: Date.now() - startTime
      };
    } catch (error) {
      console.error('向量搜索失败:', error);
      return {
        data: [],
        total: 0,
        source: 'cloud',
        cached: false,
        queryTime: Date.now() - startTime
      };
    }
  }

  /**
   * 获取单个实体
   */
  async getEntity(entityId) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return null;
      const result = await collection.get({
        ids: [entityId],
        include: ['metadatas', 'documents']
      });
      if (result.ids && result.ids.length > 0 && result.metadatas) {
        const metadata = result.metadatas[0];

        // 跳过备份数据
        if (metadata.type === 'graph_backup') return null;
        const entity = await this.buildEntity({
          metadata,
          id: result.ids[0],
          document: result.documents?.[0],
          collectionName: 'graph-entities'
        });
        return entity;
      }
      return null;
    } catch (error) {
      console.error(`获取实体 ${entityId} 失败:`, error);
      return null;
    }
  }

  /**
   * 从消息集合获取单个消息
   */
  async getMessage(messageId) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-messages`);
      if (!collection) return null;
      const result = await collection.get({
        ids: [messageId],
        include: ['metadatas', 'documents']
      });
      if (result.ids && result.ids.length > 0 && result.metadatas) {
        const metadata = result.metadatas[0];
        const document = result.documents?.[0];

        // 构建消息对象
        const processedMetadata = this.deserializeChromaMetadata(metadata || {});
        return {
          id: result.ids[0],
          content: document || '',
          sender: metadata?.sender || 'unknown',
          datetime: metadata?.datetime || Date.now(),
          metadata: processedMetadata,
          // 从 metadata 中提取常用字段
          groupName: metadata?.groupName || '未知群组',
          groupUrl: metadata?.groupUrl || metadata?.team_url || '#',
          groupId: metadata?.groupId || '',
          summary: metadata?.summary || (document ? document.substring(0, 100) + '...' : ''),
          matchedRules: metadata?.matchedRules || [],
          replyAdvice: metadata?.replyAdvice || '',
          contextMessages: processedMetadata?.contextMessages || []
        };
      }
      return null;
    } catch (error) {
      console.error(`获取消息 ${messageId} 失败:`, error);
      return null;
    }
  }

  /**
   * 查询云端实体（支持按type过滤和真正的分页）
   */
  async queryEntities(type, searchTerm) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    this.ensureInitialized();
    const startTime = Date.now();
    const limit = options.limit || 30; // 默认30条
    const offset = options.offset || 0;
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) {
        return {
          data: [],
          total: 0,
          source: 'cloud',
          cached: false,
          queryTime: Date.now() - startTime
        };
      }

      // 如果有搜索词，使用向量搜索
      if (searchTerm && searchTerm.length > 2) {
        // 转换 sortBy 参数为向量搜索支持的类型
        let vectorSortBy = 'relevance';
        if (options.sortBy === 'importance') {
          vectorSortBy = 'importance';
        } else if (options.sortBy === 'created' || options.sortBy === 'updated') {
          vectorSortBy = 'time';
        }
        return await this.searchByVector(searchTerm, type, {
          limit,
          nResults: limit * 2,
          // 获取更多结果以应对过滤
          collections: ['entities'],
          returnType: 'entities',
          sortBy: vectorSortBy,
          sortOrder: options.sortOrder
        });
      }

      // 构建 where 查询条件
      const conditions = [];

      // 排除备份数据
      conditions.push({
        type: {
          $ne: 'graph_backup'
        }
      });

      // 如果指定了实体类型，添加类型过滤
      if (type) {
        conditions.push({
          type: type
        });
      }

      // 构建最终的 where 条件
      const whereCondition = conditions.length === 1 ? conditions[0] : {
        $and: conditions
      };

      // 直接使用 where 查询，真正的分页
      const result = await collection.get({
        where: whereCondition,
        include: ['metadatas', 'documents'],
        limit,
        offset
      });
      if (!result.ids || result.ids.length === 0) {
        return {
          data: [],
          total: 0,
          source: 'cloud',
          cached: false,
          queryTime: Date.now() - startTime
        };
      }

      // 构建实体列表
      const entities = [];
      for (let i = 0; i < result.ids.length; i++) {
        const metadata = result.metadatas[i];
        const entity = await this.buildEntity({
          metadata,
          id: result.ids[i],
          document: result.documents?.[i],
          collectionName: 'graph-entities'
        });
        if (entity) {
          entities.push(entity);
        }
      }

      // 应用排序
      if (options.sortBy && entities.length > 0) {
        entities.sort((a, b) => {
          const order = options.sortOrder === 'desc' ? -1 : 1;
          switch (options.sortBy) {
            case 'name':
              return order * a.name.localeCompare(b.name);
            case 'created':
              return order * (a.created - b.created);
            case 'updated':
              return order * (a.updated - b.updated);
            case 'importance':
              return order * (a.importance - b.importance);
            default:
              return 0;
          }
        });
      }

      // 🆕 从本地缓存获取总数，避免实时查询
      let total = entities.length; // 当前查询到的数量作为默认值
      try {
        const cachedStats = await chrome.storage.local.get('cache_statistics');
        if (cachedStats.cache_statistics?.entityCounts) {
          if (type) {
            total = cachedStats.cache_statistics.entityCounts[type] || 0;
          } else {
            total = Object.values(cachedStats.cache_statistics.entityCounts).reduce((sum, count) => sum + count, 0);
          }
        }
      } catch (error) {
        console.warn('获取缓存统计数据失败，使用查询结果数量:', error);
      }
      console.log(`📥 从云端分页查询了 ${entities.length} 个实体 (offset: ${offset}, limit: ${limit}, type: ${type || '全部'})`);
      return {
        data: entities,
        total: total,
        source: 'cloud',
        cached: false,
        queryTime: Date.now() - startTime
      };
    } catch (error) {
      console.error('查询云端实体失败:', error);
      return {
        data: [],
        total: 0,
        source: 'cloud',
        cached: false,
        queryTime: Date.now() - startTime
      };
    }
  }

  /**
   * 查询用户档案记录（非向量搜索）
   * 用于根据元数据条件查询用户档案，不进行向量相似度计算
   */
  async queryUserprofiles() {
    let options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    this.ensureInitialized();
    const startTime = Date.now();
    const {
      record_types,
      user_id,
      limit = 20,
      time_range,
      metadata_filters = {},
      sort_by = 'time',
      sort_order = 'desc'
    } = options;
    try {
      const collectionName = `${this.username}-userprofiles`;
      const collection = this.collections.get(collectionName);
      if (!collection) {
        return {
          records: [],
          total_count: 0,
          query_metadata: {
            query_time: Date.now(),
            processing_time_ms: Date.now() - startTime
          }
        };
      }

      // 构建查询条件 - 使用 $and 操作符组合多个条件
      const conditions = [];

      // 添加 metadata_filters 中的条件
      Object.entries(metadata_filters).forEach(_ref2 => {
        let [key, value] = _ref2;
        conditions.push({
          [key]: value
        });
      });
      if (user_id) {
        conditions.push({
          user_id: user_id
        });
      }
      if (record_types && record_types.length > 0) {
        conditions.push({
          record_type: {
            $in: record_types
          }
        });
      }
      if (time_range) {
        conditions.push({
          updated_at: {
            $gte: time_range.start,
            $lte: time_range.end
          }
        });
      }

      // 构建最终的 where 条件
      let whereCondition = undefined;
      if (conditions.length > 0) {
        if (conditions.length === 1) {
          whereCondition = conditions[0];
        } else {
          whereCondition = {
            $and: conditions
          };
        }
      }

      // 执行查询（不使用向量搜索）
      const searchResult = await collection.get({
        where: whereCondition,
        limit: limit,
        include: ['documents', 'metadatas']
      });

      // 处理结果
      const records = [];
      if (searchResult.documents && searchResult.metadatas) {
        for (let i = 0; i < searchResult.documents.length; i++) {
          records.push({
            id: searchResult.ids[i],
            document: searchResult.documents[i],
            metadata: this.deserializeChromaMetadata(searchResult.metadatas[i])
          });
        }
      }

      // 排序
      if (sort_by === 'time') {
        records.sort((a, b) => {
          const timeA = a.metadata?.updated_at || a.metadata?.created_at || 0;
          const timeB = b.metadata?.updated_at || b.metadata?.created_at || 0;
          return sort_order === 'desc' ? timeB - timeA : timeA - timeB;
        });
      }
      return {
        records: records,
        total_count: records.length,
        query_metadata: {
          query_time: Date.now(),
          processing_time_ms: Date.now() - startTime
        }
      };
    } catch (error) {
      console.error('查询用户档案记录失败:', error);
      return {
        records: [],
        total_count: 0,
        query_metadata: {
          query_time: Date.now(),
          processing_time_ms: Date.now() - startTime
        }
      };
    }
  }

  /**
   * 查找相似实体
   */
  async getSimilarEntities(entity) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    this.ensureInitialized();
    const {
      limit = 1,
      minRelevanceScore = this.entitySimilarityThreshold
    } = options;
    try {
      // 为查询生成与存储时相同的自然语言描述
      const queryDescription = await this.generateNaturalLanguageDescription(entity);

      // 使用丰富的描述文本进行向量检索查找相似实体，确保type匹配
      const similarResults = await this.searchByVector(queryDescription, entity.type, {
        limit,
        minRelevanceScore,
        collections: ['entities'],
        returnType: 'entities'
      });
      if (similarResults.data.length > 0) {
        console.log(`🔍 找到 ${similarResults.data.length} 个相似实体 (阈值: ${minRelevanceScore}):`, similarResults.data.map(e => `${e.name}(${e.relevanceScore?.toFixed(3)})`).join(', '));
        return similarResults.data;
      } else {
        console.log(`📝 未找到相似实体: ${entity.name} (${entity.type}) - 阈值: ${minRelevanceScore}`);
        return [];
      }
    } catch (error) {
      console.error(`⚠️ 检查实体相似性时出错: ${entity.name}`, error);
      return [];
    }
  }

  /**
   * 查找相似消息
   */
  async getSimilarMessages(query) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    this.ensureInitialized();
    const {
      limit = 10,
      minRelevanceScore = 0.3,
      timeRange,
      sortBy = 'relevance',
      sortOrder = 'desc'
    } = options;
    try {
      // 使用向量搜索获取相关消息
      const searchResults = await this.searchByVector(query, undefined, {
        collections: ['messages'],
        returnType: 'messages',
        limit,
        minRelevanceScore,
        timeRange,
        sortBy,
        sortOrder
      });
      if (searchResults.data.length > 0) {
        console.log(`💬 找到 ${searchResults.data.length} 个相似消息 (阈值: ${minRelevanceScore}):`, searchResults.data.map(m => `${m.source}(${m.relevanceScore?.toFixed(3)})`).join(', '));

        // 转换为前端需要的格式，包含完整的contextMessages
        const formattedMessages = searchResults.data.map(msg => {
          // 处理上下文消息：从metadata中提取contextMessages
          let contextMessages = [];
          if (msg.metadata?.contextMessages && Array.isArray(msg.metadata.contextMessages)) {
            contextMessages = msg.metadata.contextMessages.map(ctx => ({
              id: ctx.id,
              sender: ctx.sender,
              content: ctx.content,
              datetime: ctx.datetime,
              isMainMessage: ctx.isMainMessage || false
            }));
          }
          return {
            id: msg.messageId,
            sender: msg.source,
            groupName: msg.metadata?.groupName || '未知群组',
            groupUrl: msg.metadata?.groupUrl || msg.metadata?.team_url || '#',
            datetime: new Date(msg.timestamp).toISOString(),
            summary: msg.metadata?.summary || msg.content.substring(0, 100) + '...',
            content: msg.content,
            highlightText: msg.metadata?.highlightText || msg.content,
            matchedRules: msg.metadata?.matchedRules || [],
            relevanceScore: msg.relevanceScore,
            contextMessages: contextMessages
          };
        });
        return formattedMessages;
      } else {
        console.log(`📭 未找到相似消息: "${query}" - 阈值: ${minRelevanceScore}`);
        return [];
      }
    } catch (error) {
      console.error(`⚠️ 检查消息相似性时出错: "${query}"`, error);
      return [];
    }
  }

  /**
   * 获取集合类型
   */
  getCollectionType(collectionName) {
    if (collectionName.includes('messages')) return 'message';
    if (collectionName.includes('webpages')) return 'webpage';
    if (collectionName.includes('entities')) return 'entity';
    return 'unknown';
  }

  /**
   * 存储实体到云端 - 新的关联数据存储
   */
  async storeEntity(entity) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return '';

      // 生成实体ID
      if (!entity.id) entity.id = this.generateEntityId(entity.type, entity.name);

      // 🆕 生成丰富的自然语言描述文本
      const naturalDescription = await this.generateNaturalLanguageDescription(entity);
      const embedding = await getEmbeddingViaOffscreen(naturalDescription);

      // 转换关联数据为ChromaDB兼容格式
      const chromaMetadata = this.serializeChromaMetadata(entity);
      await collection.add({
        ids: [entity.id],
        documents: [naturalDescription],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      console.log(`✅ 实体存储完成: ${entity.name} (${entity.type}), documents长度: ${naturalDescription.length}字符`);
      return entity.id;
    } catch (error) {
      console.error('存储实体到云端失败:', error);
      return '';
    }
  }

  /**
   * 存储消息到云端
   */
  async storeMessage(messageData) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-messages`);
      if (!collection) return false;
      const embedding = await getEmbeddingViaOffscreen(`sender: ${messageData.metadata.sender}\ncontent: ${messageData.content}\nsummary: ${messageData.metadata.summary}`);

      // 转换复杂元数据为 ChromaDB 兼容格式
      const chromaMetadata = this.serializeChromaMetadata(messageData.metadata);
      await collection.add({
        ids: [messageData.id],
        documents: [messageData.content],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      return true;
    } catch (error) {
      console.error('存储消息到云端失败:', error);
      return false;
    }
  }

  /**
   * 存储网页到云端
   */
  async storeWebpage(webpageData) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-webpages`);
      if (!collection) return false;
      const content = `${webpageData.title} ${webpageData.content}`;
      const embedding = await getEmbeddingViaOffscreen(content);
      const chromaMetadata = this.serializeChromaMetadata({
        ...webpageData.metadata,
        title: webpageData.title,
        url: webpageData.url
      });
      await collection.add({
        ids: [webpageData.id],
        documents: [content],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      return true;
    } catch (error) {
      console.error('存储网页到云端失败:', error);
      return false;
    }
  }

  /**
   * 🆕 智能更新实体 - 支持关联数据和智能documents更新
   */
  async updateEntity(entityId, updates) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return false;

      // 获取现有实体
      const existing = await collection.get({
        ids: [entityId],
        include: ['metadatas', 'documents']
      });
      if (!existing.metadatas?.[0]) return false;

      // 反序列化现有实体数据
      const currentMetadata = existing.metadatas[0];
      const currentEntity = this.deserializeEntityFromMetadata(currentMetadata);

      // 🆕 智能合并更新：特别处理relatedData
      const mergedEntity = {
        ...currentEntity,
        ...updates,
        updated: Date.now(),
        // 🆕 智能合并关联数据
        relatedData: this.mergeRelatedData(currentEntity.relatedData, updates.relatedData),
        // 🆕 重新计算统计信息
        statistic: this.recalculateStatistics(currentEntity, updates)
      };

      // 🆕 判断是否需要立即更新documents
      const shouldUpdateDocuments = this.shouldUpdateDocuments(mergedEntity, updates);
      let documents = existing.documents?.[0] || '';
      let embedding = [];
      if (shouldUpdateDocuments) {
        console.log(`📝 重要实体${mergedEntity.name}立即更新documents...`);
        documents = await this.generateNaturalLanguageDescription(mergedEntity);
        embedding = await getEmbeddingViaOffscreen(documents);
        mergedEntity.lastDocumentUpdate = Date.now();
      } else {
        console.log(`⏳ 普通实体${mergedEntity.name}延迟更新documents`);
        // 保持原有embedding，不重新计算
        const existingResult = await collection.get({
          ids: [entityId],
          include: ['embeddings']
        });
        embedding = existingResult.embeddings?.[0] || [];
      }

      // 转换为ChromaDB格式
      const chromaMetadata = this.serializeChromaMetadata(mergedEntity);

      // 执行更新
      await collection.update({
        ids: [entityId],
        documents: [documents],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      console.log(`✅ 实体更新完成: ${mergedEntity.name}, documents更新: ${shouldUpdateDocuments ? '是' : '否'}`);
      return true;
    } catch (error) {
      console.error('更新实体失败:', error);
      return false;
    }
  }

  /**
   * 删除实体
   */
  async deleteEntity(entityId) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return false;
      await collection.delete({
        ids: [entityId]
      });
      return true;
    } catch (error) {
      console.error('删除实体失败:', error);
      return false;
    }
  }

  /**
   * 🆕 判断是否应该立即更新documents
   */
  shouldUpdateDocuments(entity, updates) {
    // 1. 高重要性实体 (importance > 0.7)
    if (entity.importance && entity.importance > 0.7) return true;

    // 2. 高热度实体 (hotness > 0.6)  
    if (entity.hotness && entity.hotness > 0.6) return true;

    // 3. 关键性评分高的实体 (criticalityScore > 0.8)
    if (entity.criticalityScore && entity.criticalityScore > 0.8) return true;

    // 4. 长时间未更新documents的实体 (超过24小时)
    const daysSinceLastUpdate = entity.lastDocumentUpdate ? (Date.now() - entity.lastDocumentUpdate) / (1000 * 60 * 60 * 24) : 999;
    if (daysSinceLastUpdate > 1) return true;

    // 5. 如果关联数据有重大变化（新增5条以上记录）
    const hasSignificantDataChanges = updates.relatedData && (updates.relatedData.conversations && updates.relatedData.conversations.length > 5 || updates.relatedData.projects && updates.relatedData.projects.length > 2 || updates.relatedData.jiraTickets && updates.relatedData.jiraTickets.length > 3);
    if (hasSignificantDataChanges) return true;
    return false;
  }

  /**
   * 🆕 智能合并关联数据
   */
  mergeRelatedData() {
    let current = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    let updates = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    const merged = {
      ...current
    };

    // 合并各类关联数据，保持最多50条记录
    const dataTypes = ['conversations', 'webpages', 'resources', 'projects', 'people', 'topics', 'jiraTickets', 'cooccurringEntities'];
    for (const type of dataTypes) {
      if (updates[type]) {
        // 合并并去重（基于id）
        const currentItems = merged[type] || [];
        const newItems = updates[type] || [];
        const allItems = [...currentItems];
        newItems.forEach(newItem => {
          const existingIndex = allItems.findIndex(item => item.id === newItem.id);
          if (existingIndex >= 0) {
            // 更新现有项目
            allItems[existingIndex] = {
              ...allItems[existingIndex],
              ...newItem
            };
          } else {
            // 添加新项目
            allItems.push(newItem);
          }
        });

        // 按相关性和时间排序，保留最多50条
        allItems.sort((a, b) => {
          // 优先按相关性排序，然后按时间
          const scoreA = (a.relevanceScore || 0) * 100 + new Date(a.datetime || a.visitTime || Date.now()).getTime() / 1000000;
          const scoreB = (b.relevanceScore || 0) * 100 + new Date(b.datetime || b.visitTime || Date.now()).getTime() / 1000000;
          return scoreB - scoreA;
        });
        merged[type] = allItems.slice(0, 50);
      }
    }
    return merged;
  }

  /**
   * 🆕 重新计算统计信息
   */
  recalculateStatistics(current, updates) {
    const relatedData = updates.relatedData || current.relatedData || {
      conversations: [],
      webpages: [],
      resources: [],
      projects: [],
      people: [],
      topics: [],
      jiraTickets: [],
      cooccurringEntities: []
    };
    return {
      conversations: relatedData.conversations?.length || 0,
      projects: relatedData.projects?.length || 0,
      participants: relatedData.people?.length || 0,
      resources: relatedData.resources?.length || 0,
      documents: relatedData.resources?.filter(r => r.type === 'document')?.length || 0,
      webpages: relatedData.webpages?.length || 0,
      topics: relatedData.topics?.length || 0,
      jiraTickets: relatedData.jiraTickets?.length || 0,
      relationships: relatedData.cooccurringEntities?.length || 0
    };
  }

  /**
   * 获取时间轴数据
   */
  async getTimeline() {
    let limit = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 50;
    this.ensureInitialized();
    try {
      const results = [];

      // 从消息集合获取最近数据
      const messageCollection = this.collections.get(`${this.username}-messages`);
      if (messageCollection) {
        const messageResults = await messageCollection.get({
          limit: limit / 2,
          include: ['metadatas', 'documents']
        });
        if (messageResults.metadatas && messageResults.documents) {
          for (let i = 0; i < messageResults.metadatas.length; i++) {
            const metadata = messageResults.metadatas[i];
            const document = messageResults.documents[i];
            results.push({
              id: `msg_${i}`,
              type: 'message',
              title: metadata.summary || '消息记录',
              content: document.substring(0, 200) + '...',
              timestamp: metadata.timestamp || Date.now(),
              sender: metadata.sender || metadata.source || 'unknown',
              metadata
            });
          }
        }
      }

      // 从网页集合获取最近数据
      const webpageCollection = this.collections.get(`${this.username}-webpages`);
      if (webpageCollection) {
        const webpageResults = await webpageCollection.get({
          limit: limit / 2,
          include: ['metadatas', 'documents']
        });
        if (webpageResults.metadatas && webpageResults.documents) {
          for (let i = 0; i < webpageResults.metadatas.length; i++) {
            const metadata = webpageResults.metadatas[i];
            const document = webpageResults.documents[i];
            results.push({
              id: `web_${i}`,
              type: 'webpage',
              title: metadata.title || '网页访问',
              content: document.substring(0, 200) + '...',
              timestamp: metadata.extractedAt || Date.now(),
              source: metadata.domain || 'unknown',
              metadata
            });
          }
        }
      }

      // 按时间排序
      return results.sort((a, b) => b.timestamp - a.timestamp).slice(0, limit);
    } catch (error) {
      console.error('获取时间轴数据失败:', error);
      return [];
    }
  }

  /**
   * 反序列化 metadata 中的对象字段
   */
  deserializeMetadata(metadata) {
    const processed = {
      ...metadata
    };
    try {
      // 反序列化 contextMessages 字段
      if (processed.contextMessages && typeof processed.contextMessages === 'string') {
        processed.contextMessages = JSON.parse(processed.contextMessages);
      }
    } catch (error) {
      // 忽略解析错误
    }
    try {
      // 反序列化 matchedRules 字段
      if (processed.matchedRules && typeof processed.matchedRules === 'string') {
        processed.matchedRules = JSON.parse(processed.matchedRules);
      }
    } catch (error) {
      // 忽略解析错误
    }
    try {
      // 反序列化 entities 字段
      if (processed.entities && typeof processed.entities === 'string') {
        processed.entities = JSON.parse(processed.entities);
      }
    } catch (error) {
      // 忽略解析错误
    }
    try {
      // 反序列化 relationships 字段
      if (processed.relationships && typeof processed.relationships === 'string') {
        processed.relationships = JSON.parse(processed.relationships);
      }
    } catch (error) {
      // 忽略解析错误
    }
    try {
      // 反序列化 metadata 嵌套字段
      if (processed.metadata && typeof processed.metadata === 'string') {
        processed.metadata = JSON.parse(processed.metadata);
      }
    } catch (error) {
      // 忽略解析错误
    }
    try {
      // 反序列化 actions 字段
      if (processed.actions && typeof processed.actions === 'string') {
        processed.actions = JSON.parse(processed.actions);
      }
    } catch (error) {
      // 忽略解析错误
    }
    return processed;
  }

  /**
   * 获取云端实体数量
   */
  async getEntityCount() {
    if (!this.client) return 0;
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return 0;
      const result = await collection.get({
        limit: 1
      });
      return result.ids?.length || 0;
    } catch (error) {
      console.error('获取实体数量失败:', error);
      return 0;
    }
  }

  /**
   * 备份关系数据到云端
   */
  async backupRelationships(relationshipData) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return false;
      const backupId = `graph-backup-${Date.now()}`;
      const backupContent = JSON.stringify({
        ...relationshipData,
        backupTime: Date.now()
      });
      const embedding = await getEmbeddingViaOffscreen(backupContent);
      const chromaMetadata = this.serializeChromaMetadata({
        type: 'graph_backup',
        backupTime: Date.now(),
        relationshipCount: relationshipData.relationships.length
      });
      await collection.add({
        ids: [backupId],
        documents: [backupContent],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      console.log(`☁️ 关系数据已备份: ${backupId}`);
      return true;
    } catch (error) {
      console.error('备份关系数据失败:', error);
      return false;
    }
  }

  /**
   * 从云端恢复关系数据
   */
  async restoreRelationships() {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return null;

      // 查找最新备份
      const result = await collection.get({
        where: {
          type: 'graph_backup'
        },
        include: ['metadatas', 'documents']
      });
      if (!result.ids || result.ids.length === 0) {
        console.log('📭 云端没有找到关系数据备份');
        return null;
      }

      // 获取最新备份
      const latestBackupIndex = result.metadatas.map((meta, index) => ({
        meta,
        index
      })).sort((a, b) => (b.meta.backupTime || 0) - (a.meta.backupTime || 0))[0].index;
      const backupContent = result.documents[latestBackupIndex];
      const backupData = JSON.parse(backupContent);
      console.log(`📥 恢复关系数据: ${backupData.relationships?.length || 0} 个关系`);
      return {
        relationships: backupData.relationships || [],
        entityToRelations: backupData.entityToRelations || [],
        typeToEntities: backupData.typeToEntities || []
      };
    } catch (error) {
      console.error('恢复关系数据失败:', error);
      return null;
    }
  }

  /**
   * 批量操作
   */
  async batchStore(items) {
    this.ensureInitialized();
    let success = 0;
    let failed = 0;
    const batches = this.chunkArray(items, this.config.batchSize);
    for (const batch of batches) {
      try {
        await Promise.all(batch.map(async item => {
          try {
            switch (item.type) {
              case 'entity':
                await this.storeEntity(item.data);
                break;
              case 'message':
                await this.storeMessage(item.data);
                break;
              case 'webpage':
                await this.storeWebpage(item.data);
                break;
            }
            success++;
          } catch (error) {
            failed++;
            console.error(`批量存储失败 (${item.type}):`, error);
          }
        }));
      } catch (error) {
        failed += batch.length;
        console.error('批量存储失败:', error);
      }
    }
    return {
      success,
      failed
    };
  }

  // ==================== 私有方法 ====================

  /**
   * 🆕 生成实体ID - 移入内部方法
   */
  generateEntityId(type, name) {
    const sanitizedType = type.replace(/[^a-zA-Z0-9]/g, '');
    const sanitizedName = this.sanitizeName(name);
    const shortUuid = esm_browser_v4().substring(0, 8);
    return `${sanitizedType}_${sanitizedName}_${shortUuid}`;
  }

  /**
   * 清理实体名称，处理中文和特殊字符
   */
  sanitizeName(name) {
    if (!name || name.trim() === '') {
      return 'entity';
    }

    // 简单的中文转拼音映射（部分常用字符）
    const chineseToPinyin = {
      '项目': 'xiangmu',
      '文档': 'wendang',
      '人员': 'renyuan',
      '主题': 'zhuti',
      '任务': 'renwu',
      '团队': 'tuandui',
      '公司': 'gongsi',
      '系统': 'xitong',
      '数据': 'shuju',
      '功能': 'gongneng',
      '需求': 'xuqiu',
      '设计': 'sheji',
      '开发': 'kaifa',
      '测试': 'ceshi',
      '部署': 'bushu',
      '维护': 'weihu',
      '管理': 'guanli',
      '分析': 'fenxi',
      '报告': 'baogao',
      '会议': 'huiyi',
      '刘': 'liu',
      '陈': 'chen',
      '王': 'wang',
      '李': 'li',
      '张': 'zhang',
      '赵': 'zhao',
      '孙': 'sun',
      '周': 'zhou',
      '吴': 'wu',
      '郑': 'zheng'
    };
    let cleanName = name.trim();

    // 替换中文词汇为拼音
    for (const [chinese, pinyin] of Object.entries(chineseToPinyin)) {
      cleanName = cleanName.replace(new RegExp(chinese, 'g'), pinyin);
    }

    // 移除其他中文字符（通过Unicode范围）
    cleanName = cleanName.replace(/[\u4e00-\u9fff]/g, '');

    // 只保留字母、数字和连字符
    cleanName = cleanName.replace(/[^a-zA-Z0-9\-_]/g, '');

    // 移除多余的连字符和下划线
    cleanName = cleanName.replace(/[-_]+/g, '_');

    // 移除开头和结尾的连字符和下划线
    cleanName = cleanName.replace(/^[-_]+|[-_]+$/g, '');

    // 限制长度并确保不为空
    if (cleanName.length === 0) {
      cleanName = 'entity';
    } else if (cleanName.length > 15) {
      cleanName = cleanName.substring(0, 15);
    }

    // 确保以字母开头
    if (!/^[a-zA-Z]/.test(cleanName)) {
      cleanName = 'entity_' + cleanName;
    }
    return cleanName.toLowerCase();
  }
  async initializeCollections() {
    if (!this.client) throw new Error('ChromaDB 客户端未初始化');

    // ChromaDB v3: 显式指定嵌入函数，防止默认加载 @chroma-core/default-embed
    const nullEmbeddingFunction = new NullEmbeddingFunction();
    for (const collectionType of this.config.collections) {
      const collectionName = `${this.username}-${collectionType}`;
      try {
        const collection = await this.client.getOrCreateCollection({
          name: collectionName,
          embeddingFunction: nullEmbeddingFunction,
          metadata: {
            "hnsw:space": "cosine"
          } // 明确指定使用余弦距离
        });
        this.collections.set(collectionName, collection);
        console.log(`✅ 集合已初始化: ${collectionName}`);
      } catch (error) {
        console.error(`❌ 初始化集合失败: ${collectionName}`, error);
      }
    }
  }
  async getUserInfo() {
    try {
      const result = await chrome.storage.local.get(['userinfo']);
      return result.userinfo || {
        username: 'default-user'
      };
    } catch (error) {
      console.warn('获取用户信息失败，使用默认值');
      return {
        username: 'default-user'
      };
    }
  }
  async buildEntity(entityData) {
    try {
      const {
        id,
        document,
        distance,
        relevanceScore,
        collectionName
      } = entityData;
      const metadata = this.deserializeEntityFromMetadata(entityData.metadata);
      if (collectionName.includes('graph-entities')) {
        return {
          id,
          type: metadata.type || 'Document',
          name: metadata.name || '未知实体',
          document,
          properties: typeof metadata.properties === 'string' ? JSON.parse(metadata.properties || '{}') : metadata.properties || {},
          created: metadata.created || Date.now(),
          updated: metadata.updated || Date.now(),
          accessCount: metadata.accessCount || 0,
          lastAccessed: metadata.lastAccessed || Date.now(),
          importance: metadata.importance || 0.5,
          tags: metadata.tags || [],
          status: metadata.status || 'active',
          statistic: metadata.statistic || {
            conversations: 0,
            projects: 0,
            participants: 0,
            resources: 0,
            documents: 0,
            webpages: 0,
            relationships: 0,
            topics: 0,
            jiraTickets: 0
          },
          relatedData: metadata.relatedData || {
            conversations: [],
            webpages: [],
            resources: [],
            projects: [],
            people: [],
            topics: [],
            jiraTickets: [],
            cooccurringEntities: []
          },
          // 添加搜索相关信息
          ...(distance !== undefined && {
            searchDistance: distance
          }),
          ...(relevanceScore !== undefined && {
            relevanceScore
          })
        };
      }

      // 从其他集合构建虚拟实体
      return {
        id: id || `virtual_${Date.now()}_${Math.random()}`,
        type: 'Document',
        name: metadata.name || '相关内容',
        document: document || '相关内容',
        properties: {
          ...metadata,
          ...(document && {
            originalDocument: document
          }),
          collectionSource: collectionName
        },
        created: metadata.created || Date.now(),
        updated: metadata.updated || Date.now(),
        accessCount: metadata.accessCount || 1,
        lastAccessed: metadata.lastAccessed || Date.now(),
        importance: metadata.importance || 0.3,
        tags: metadata.tags || [],
        status: metadata.status || 'active',
        statistic: metadata.statistic || {
          conversations: 0,
          projects: 0,
          participants: 0,
          resources: 0,
          documents: 0,
          webpages: 0,
          relationships: 0,
          topics: 0,
          jiraTickets: 0
        },
        relatedData: metadata.relatedData || {
          conversations: [],
          webpages: [],
          resources: [],
          projects: [],
          people: [],
          topics: [],
          jiraTickets: [],
          cooccurringEntities: []
        },
        // 添加搜索相关信息
        ...(distance !== undefined && {
          searchDistance: distance
        }),
        ...(relevanceScore !== undefined && {
          relevanceScore
        })
      };
    } catch (error) {
      console.error('构建实体失败:', error);
      return null;
    }
  }
  chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

  /**
   * 存储用户画像到云端
   */
  async storeUserProfile(userId, profile) {
    this.ensureInitialized();
    try {
      // 获取或创建用户画像集合
      const collectionName = `${this.username}-userprofiles`;
      let collection = this.collections.get(collectionName);
      if (!collection) {
        collection = await this.client.getOrCreateCollection({
          name: collectionName,
          metadata: {
            type: 'user_profiles',
            "hnsw:space": "cosine"
          },
          embeddingFunction: new NullEmbeddingFunction()
        });
        this.collections.set(collectionName, collection);
      }

      // 为用户画像创建向量表示
      const profileText = this.createProfileText(profile);
      const embedding = await getEmbeddingViaOffscreen(profileText);

      // 存储用户画像
      const chromaMetadata = this.serializeChromaMetadata({
        userId: userId,
        lastUpdated: profile.lastUpdated,
        createdAt: profile.createdAt,
        totalInteractions: profile.statistics.totalInteractions,
        profileData: JSON.stringify(profile)
      });
      await collection.upsert({
        ids: [userId],
        documents: [profileText],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      console.log(`✅ 用户画像 ${userId} 已存储到云端`);
      return true;
    } catch (error) {
      console.error('存储用户画像到云端失败:', error);
      return false;
    }
  }

  /**
   * 从云端获取用户画像
   */
  async getUserProfile(userId) {
    this.ensureInitialized();
    try {
      const collectionName = `${this.username}-userprofiles`;
      const collection = this.collections.get(collectionName);
      if (!collection) {
        return null;
      }
      const result = await collection.get({
        ids: [userId],
        include: ['metadatas']
      });
      if (result.metadatas && result.metadatas.length > 0) {
        const metadata = this.deserializeChromaMetadata(result.metadatas[0]);
        if (metadata.profileData) {
          return JSON.parse(metadata.profileData);
        }
      }
      return null;
    } catch (error) {
      console.error('从云端获取用户画像失败:', error);
      return null;
    }
  }

  // =====================================
  // 🆕 用户档案存储方法
  // =====================================

  /**
   * 存储用户档案记录
   */
  async storeUserprofilesRecord(record) {
    this.ensureInitialized();
    try {
      const collectionName = `${this.username}-userprofiles`;
      let collection = this.collections.get(collectionName);
      if (!collection) {
        collection = await this.client.getOrCreateCollection({
          name: collectionName,
          metadata: {
            type: 'vectorized_user_profiles',
            "hnsw:space": "cosine"
          },
          embeddingFunction: new NullEmbeddingFunction()
        });
        this.collections.set(collectionName, collection);
      }

      // 生成嵌入向量（如果没有提供）
      let embedding = record.embedding;
      if (!embedding) {
        embedding = await getEmbeddingViaOffscreen(record.document);
      }
      const metadata = this.serializeChromaMetadata(record.metadata);

      // 存储记录
      await collection.upsert({
        ids: [record.id],
        documents: [record.document],
        embeddings: [embedding],
        metadatas: [metadata]
      });
      console.log(`✅ 用户档案记录 ${record.id} 已存储`);
      return true;
    } catch (error) {
      console.error('存储用户档案记录失败:', error);
      return false;
    }
  }

  /**
   * 批量存储用户档案记录
   */
  async storeUserprofilesRecordsBatch(records) {
    this.ensureInitialized();
    let successCount = 0;
    const batchSize = this.userprofilesMaintenanceConfig.vector_update.batch_size;
    for (let i = 0; i < records.length; i += batchSize) {
      const batch = records.slice(i, i + batchSize);
      try {
        const collectionName = `${this.username}-userprofiles`;
        let collection = this.collections.get(collectionName);
        if (!collection) {
          collection = await this.client.getOrCreateCollection({
            name: collectionName,
            metadata: {
              type: 'vectorized_user_profiles',
              "hnsw:space": "cosine"
            },
            embeddingFunction: new NullEmbeddingFunction()
          });
          this.collections.set(collectionName, collection);
        }

        // 准备批量数据
        const ids = batch.map(r => r.id);
        const documents = batch.map(r => r.document);
        const metadatas = batch.map(r => this.serializeChromaMetadata(r.metadata));

        // 生成嵌入向量
        const embeddings = await Promise.all(batch.map(r => r.embedding || getEmbeddingViaOffscreen(r.document)));

        // 批量存储
        await collection.upsert({
          ids,
          documents,
          embeddings,
          metadatas: metadatas
        });
        successCount += batch.length;
        console.log(`✅ 批量存储 ${batch.length} 条用户档案记录`);
      } catch (error) {
        console.error(`批量存储失败 (batch ${Math.floor(i / batchSize) + 1}):`, error);
      }
    }
    return successCount;
  }

  /**
   * 查找相似用户
   */
  async findSimilarUsers(currentUserId, query) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const {
      record_types,
      limit = 10,
      similarity_threshold = 0.6
    } = options;
    const queryResult = await this.searchByVector(query, undefined, {
      collections: ['userprofiles'],
      returnType: 'userprofiles',
      where: {
        record_type: {
          $in: record_types
        },
        user_id: {
          $ne: currentUserId
        }
      },
      minRelevanceScore: similarity_threshold,
      limit: 100
    });

    // 按用户聚合结果
    const userMatches = new Map();
    queryResult.data.forEach((record, index) => {
      const userId = record.metadata.user_id;
      const similarity = record.relevanceScore || 0;
      if (!userMatches.has(userId)) {
        userMatches.set(userId, {
          similarity_scores: [],
          matching_categories: new Set(),
          matching_items: []
        });
      }
      const userMatch = userMatches.get(userId);
      userMatch.similarity_scores.push(similarity);
      userMatch.matching_categories.add(record.metadata.record_type);
      if ('name' in record.metadata) {
        userMatch.matching_items.push(record.metadata.name);
      }
    });

    // 计算综合相似度并格式化结果
    const results = [];
    for (const [userId, matches] of Array.from(userMatches.entries())) {
      const avgSimilarity = matches.similarity_scores.reduce((sum, score) => sum + score, 0) / matches.similarity_scores.length;
      results.push({
        user_id: userId,
        similarity_score: avgSimilarity,
        matching_categories: Array.from(matches.matching_categories).map(category => ({
          category: category,
          similarity: avgSimilarity,
          matching_items: matches.matching_items
        })),
        total_matches: matches.similarity_scores.length
      });
    }
    return results.sort((a, b) => b.similarity_score - a.similarity_score).slice(0, limit);
  }

  /**
   * 删除用户的档案记录
   */
  async deleteUserProfilesRecords(userId) {
    this.ensureInitialized();
    try {
      const collectionName = `${this.username}-userprofiles`;
      const collection = this.collections.get(collectionName);
      if (!collection) {
        return true; // 集合不存在，认为删除成功
      }

      // 查找用户的所有记录
      const userRecords = await collection.get({
        where: {
          user_id: userId
        },
        include: ['metadatas']
      });
      if (userRecords.ids && userRecords.ids.length > 0) {
        // 批量删除
        await collection.delete({
          ids: userRecords.ids
        });
        console.log(`🗑️ 删除用户 ${userId} 的 ${userRecords.ids.length} 条用户档案记录`);
      }
      return true;
    } catch (error) {
      console.error('删除用户档案记录失败:', error);
      return false;
    }
  }

  /**
   * 获取用户档案存储统计信息
   */
  async getUserprofilesStorageStats() {
    this.ensureInitialized();
    try {
      const collectionName = `${this.username}-userprofiles`;
      const collection = this.collections.get(collectionName);
      if (!collection) {
        return {
          total_records: 0,
          records_by_type: {},
          records_by_user: {},
          storage_size_mb: 0,
          last_maintenance: 0,
          health_score: 1.0
        };
      }

      // 获取所有记录的元数据
      const allRecords = await collection.get({
        include: ['metadatas']
      });
      const stats = {
        total_records: allRecords.ids?.length || 0,
        records_by_type: {},
        records_by_user: {},
        storage_size_mb: 0,
        last_maintenance: 0,
        health_score: 1.0
      };
      if (allRecords.metadatas) {
        allRecords.metadatas.forEach(metadata => {
          const meta = metadata;

          // 按类型统计
          const recordType = meta.record_type || 'unknown';
          stats.records_by_type[recordType] = (stats.records_by_type[recordType] || 0) + 1;

          // 按用户统计
          const userId = meta.user_id || 'unknown';
          stats.records_by_user[userId] = (stats.records_by_user[userId] || 0) + 1;
        });
      }

      // 估算存储大小（简化计算）
      stats.storage_size_mb = Math.round(stats.total_records * 0.1); // 假设每条记录约0.1MB

      // 计算健康度（基于记录分布和完整性）
      const typeCount = Object.keys(stats.records_by_type).length;
      const userCount = Object.keys(stats.records_by_user).length;
      stats.health_score = Math.min(1.0, typeCount * userCount / (stats.total_records || 1));
      return stats;
    } catch (error) {
      console.error('获取用户档案存储统计失败:', error);
      return {
        total_records: 0,
        records_by_type: {},
        records_by_user: {},
        storage_size_mb: 0,
        last_maintenance: 0,
        health_score: 0
      };
    }
  }

  /**
   * 用户档案数据维护
   */
  async performUserprofilesMaintenance() {
    this.ensureInitialized();
    const result = {
      cleaned_records: 0,
      updated_records: 0,
      created_summaries: 0,
      errors: []
    };
    try {
      const collectionName = `${this.username}-userprofiles`;
      const collection = this.collections.get(collectionName);
      if (!collection) {
        return result;
      }
      console.log('🔧 开始用户档案数据维护...');

      // 1. 清理过期/低权重记录
      try {
        const cleanupThreshold = Date.now() - this.userprofilesMaintenanceConfig.cleanup_thresholds.max_age_days * 24 * 60 * 60 * 1000;
        const oldRecords = await collection.get({
          where: {
            $or: [{
              updated_at: {
                $lt: cleanupThreshold
              }
            }, {
              current_weight: {
                $lt: this.userprofilesMaintenanceConfig.cleanup_thresholds.min_weight
              }
            }]
          },
          include: ['metadatas']
        });
        if (oldRecords.ids && oldRecords.ids.length > 0) {
          await collection.delete({
            ids: oldRecords.ids
          });
          result.cleaned_records = oldRecords.ids.length;
          console.log(`🗑️ 清理了 ${result.cleaned_records} 条过期记录`);
        }
      } catch (error) {
        result.errors.push(`清理记录失败: ${error}`);
      }

      // 2. 更新向量表示（重新计算embedding）
      if (this.userprofilesMaintenanceConfig.vector_update.enable_batch_update) {
        try {
          // 找到需要更新的记录（这里简化为随机选择部分记录）
          const allRecords = await collection.get({
            limit: this.userprofilesMaintenanceConfig.vector_update.batch_size,
            include: ['documents', 'metadatas']
          });
          if (allRecords.documents && allRecords.metadatas && allRecords.ids) {
            const updatedEmbeddings = await Promise.all(allRecords.documents[0].map(doc => getEmbeddingViaOffscreen(doc)));
            await collection.upsert({
              ids: allRecords.ids,
              documents: allRecords.documents[0],
              embeddings: updatedEmbeddings,
              metadatas: allRecords.metadatas[0]
            });
            result.updated_records = allRecords.ids.length;
            console.log(`🔄 更新了 ${result.updated_records} 条记录的向量表示`);
          }
        } catch (error) {
          result.errors.push(`更新向量失败: ${error}`);
        }
      }

      // 3. 生成用户概要记录
      if (this.userprofilesMaintenanceConfig.aggregation_rules.enable_auto_summary) {
        try {
          const userStats = await this.getUserprofilesStorageStats();
          for (const userId of Object.keys(userStats.records_by_user)) {
            // 检查是否需要创建或更新概要
            const existingSummary = await collection.get({
              where: {
                user_id: userId,
                record_type: 'user_summary'
              },
              limit: 1
            });
            if (!existingSummary.ids || existingSummary.ids.length === 0) {
              // 创建新的用户概要
              const summaryRecord = await this.generateUserSummaryRecord(userId);
              if (summaryRecord) {
                await this.storeUserprofilesRecord(summaryRecord);
                result.created_summaries++;
              }
            }
          }
          console.log(`📊 创建了 ${result.created_summaries} 个用户概要记录`);
        } catch (error) {
          result.errors.push(`生成概要失败: ${error}`);
        }
      }
      console.log('✅ 用户档案数据维护完成');
      return result;
    } catch (error) {
      console.error('用户档案数据维护失败:', error);
      result.errors.push(`维护过程失败: ${error}`);
      return result;
    }
  }

  /**
   * 生成用户概要记录
   */
  async generateUserSummaryRecord(userId) {
    try {
      // 获取用户的所有记录
      const userRecords = await this.queryUserprofiles({
        user_id: userId,
        limit: 1000,
        record_types: ['interest_item', 'behavior_pattern', 'social_relationship', 'expertise_area']
      });
      if (userRecords.records.length === 0) {
        return null;
      }

      // 统计分析
      const recordsByType = userRecords.records.reduce((acc, record) => {
        const type = record.metadata.record_type;
        acc[type] = (acc[type] || 0) + 1;
        return acc;
      }, {});

      // 计算权重分布
      const weights = userRecords.records.map(r => r.metadata.current_weight).filter(w => typeof w === 'number');
      const weightDistribution = {
        high_weight_items: weights.filter(w => w > 0.7).length,
        medium_weight_items: weights.filter(w => w >= 0.3 && w <= 0.7).length,
        low_weight_items: weights.filter(w => w < 0.3).length
      };

      // 生成概要文本
      const summaryText = `用户 ${userId} 的画像概要：
        总记录数: ${userRecords.records.length}
        记录类型分布: ${Object.entries(recordsByType).map(_ref3 => {
        let [type, count] = _ref3;
        return `${type}: ${count}`;
      }).join(', ')}
        权重分布: 高权重${weightDistribution.high_weight_items}项, 中权重${weightDistribution.medium_weight_items}项, 低权重${weightDistribution.low_weight_items}项
        活跃领域: ${Object.keys(recordsByType).join(', ')}`;
      const summaryRecord = {
        id: `${userId}_summary_${Date.now()}`,
        document: summaryText,
        metadata: {
          record_type: 'user_summary',
          summary_type: 'overall',
          user_id: userId,
          created_at: Date.now(),
          updated_at: Date.now(),
          total_records: userRecords.records.length,
          summary_period: {
            start: Math.min(...userRecords.records.map(r => r.metadata.created_at)),
            end: Date.now()
          },
          weight_distribution: weightDistribution,
          activity_metrics: {
            avg_daily_interactions: weights.length / 30,
            // 简化计算
            peak_activity_hour: 9,
            // 简化为固定值
            active_days_count: Math.min(30, weights.length)
          },
          growth_trends: {
            new_interests_per_month: 0,
            skill_development_rate: 0,
            social_network_growth: 0
          },
          auto_generated: true,
          generation_algorithm: 'v1.0'
        }
      };
      return summaryRecord;
    } catch (error) {
      console.error('生成用户概要记录失败:', error);
      return null;
    }
  }

  /**
   * 创建用户画像的文本表示（用于向量化）
   */
  createProfileText(profile) {
    const parts = [];

    // 用户ID和基本信息
    parts.push(`用户: ${profile.userId}`);

    // 兴趣项目
    if (profile.interests.projects.length > 0) {
      parts.push('关注项目: ' + profile.interests.projects.slice(0, 5).map(p => `${p.name}(权重:${p.currentWeight.toFixed(2)})`).join(', '));
    }

    // 关注人员
    if (profile.interests.people.length > 0) {
      parts.push('关注人员: ' + profile.interests.people.slice(0, 5).map(p => `${p.name}(权重:${p.currentWeight.toFixed(2)})`).join(', '));
    }

    // 技术栈
    if (profile.interests.technologies.length > 0) {
      parts.push('技术栈: ' + profile.interests.technologies.slice(0, 5).map(t => `${t.name}(权重:${t.currentWeight.toFixed(2)})`).join(', '));
    }

    // 主题
    if (profile.interests.topics.length > 0) {
      parts.push('关注主题: ' + profile.interests.topics.slice(0, 5).map(t => `${t.name}(权重:${t.currentWeight.toFixed(2)})`).join(', '));
    }

    // 专业领域
    if (profile.derivedPreferences.expertiseAreas.length > 0) {
      parts.push('专业领域: ' + profile.derivedPreferences.expertiseAreas.join(', '));
    }

    // 统计信息
    parts.push(`总交互次数: ${profile.statistics.totalInteractions}`);
    parts.push(`日均活动: ${profile.statistics.averageDailyActivity.toFixed(1)}`);
    return parts.join('\n');
  }

  /**
   * 备份关系数据到独立的关系集合
   */
  async backupRelationshipsToCollection(relationshipData) {
    this.ensureInitialized();
    try {
      if (!relationshipData.relationships || relationshipData.relationships.length === 0) {
        console.log('📭 没有关系数据需要备份');
        return true;
      }
      const relationshipCollectionName = `${this.username}-graph-relationships`;

      // 获取或创建关系集合
      let relationshipCollection;
      try {
        relationshipCollection = await this.client.getOrCreateCollection({
          name: relationshipCollectionName,
          metadata: {
            type: 'relationships',
            "hnsw:space": "cosine"
          },
          embeddingFunction: new NullEmbeddingFunction()
        });
      } catch (error) {
        console.error('❌ 无法创建关系集合:', error);
        return false;
      }
      const relationships = relationshipData.relationships || [];
      let storedCount = 0;

      // 按实体类型和时间进行分组存储，减少数据量
      const groupedRelationships = this.groupRelationshipsForStorage(relationships);
      for (const [groupKey, groupData] of Object.entries(groupedRelationships)) {
        try {
          const groupDoc = {
            id: `rel-group-${groupKey}-${Date.now()}`,
            groupKey,
            relationshipCount: groupData.relationships.length,
            timeRange: groupData.timeRange,
            entityTypes: groupData.entityTypes,
            relationshipTypes: groupData.relationshipTypes,
            createdAt: Date.now(),
            data: JSON.stringify(groupData.relationships)
          };

          // 为文档内容生成向量（用于检索）
          const searchableContent = [`关系组 ${groupKey}`, `实体类型: ${groupData.entityTypes.join(', ')}`, `关系类型: ${groupData.relationshipTypes.join(', ')}`, `时间范围: ${new Date(groupData.timeRange.start).toLocaleDateString()} - ${new Date(groupData.timeRange.end).toLocaleDateString()}`].join('\n');
          const embedding = await getEmbeddingViaOffscreen(searchableContent);
          await relationshipCollection.add({
            ids: [groupDoc.id],
            documents: [searchableContent],
            embeddings: [embedding],
            metadatas: [groupDoc]
          });
          storedCount += groupData.relationships.length;
        } catch (error) {
          console.error(`❌ 存储关系组 ${groupKey} 失败:`, error);
        }
      }
      console.log(`☁️ 关系数据已备份到独立集合: ${storedCount} 个关系，${Object.keys(groupedRelationships).length} 个分组`);
      return true;
    } catch (error) {
      console.error('❌ 云端备份关系数据失败:', error);
      return false;
    }
  }

  /**
   * 按类型和时间对关系进行分组，优化存储和检索
   */
  groupRelationshipsForStorage(relationships) {
    const groups = {};
    const timeSpan = 7 * 24 * 60 * 60 * 1000; // 7天为一组

    for (const [id, relationship] of relationships) {
      if (!relationship) continue;

      // 计算时间分组
      const timestamp = relationship.created || Date.now();
      const timeGroup = Math.floor(timestamp / timeSpan);

      // 获取实体类型（从 ID 推断）
      const fromType = this.getEntityTypeFromId(relationship.fromId);
      const toType = this.getEntityTypeFromId(relationship.toId);
      const entityTypesKey = [fromType, toType].sort().join('-');

      // 生成分组键：实体类型_关系类型_时间组
      const groupKey = `${entityTypesKey}_${relationship.type}_${timeGroup}`;
      if (!groups[groupKey]) {
        groups[groupKey] = {
          relationships: [],
          timeRange: {
            start: timeGroup * timeSpan,
            end: (timeGroup + 1) * timeSpan
          },
          entityTypes: [fromType, toType],
          relationshipTypes: new Set()
        };
      }
      groups[groupKey].relationships.push([id, relationship]);
      groups[groupKey].relationshipTypes.add(relationship.type);
    }

    // 转换 Set 为 Array
    Object.values(groups).forEach(group => {
      group.relationshipTypes = Array.from(group.relationshipTypes);
    });
    return groups;
  }

  /**
   * 从实体ID推断实体类型
   */
  getEntityTypeFromId(entityId) {
    if (!entityId) return 'Unknown';
    const parts = entityId.split('_');
    return parts[0] || 'Unknown';
  }

  /**
   * 将复杂元数据转换为 ChromaDB 兼容的格式
   * ChromaDB 只支持 string, number, boolean, null 类型
   */
  serializeChromaMetadata(metadata) {
    const converted = {};
    if (!metadata) return converted;

    // 递归处理函数
    const processValue = (key, value) => {
      if (value === null || value === undefined) {
        converted[key] = '';
      } else if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
        converted[key] = value;
      } else if (Array.isArray(value)) {
        // 数组转换为JSON字符串
        converted[key] = JSON.stringify(value);
      } else if (typeof value === 'object') {
        // 对象转换为JSON字符串
        converted[key] = JSON.stringify(value);
      } else {
        // 其他类型转换为字符串
        converted[key] = String(value);
      }
    };

    // 处理顶级字段
    for (const [key, value] of Object.entries(metadata)) {
      processValue(key, value);
    }
    return converted;
  }

  /**
   * 🆕 通用的ChromaDB metadata反序列化函数
   * 可以处理任意类型的metadata，自动判断字段类型并进行相应转换
   */
  deserializeChromaMetadata(metadata, defaultValues) {
    if (!metadata) return defaultValues || {};

    // 通用字段处理：自动判断字段类型并进行相应转换
    const processField = (value, fieldName, defaultValue) => {
      // 如果值为空，返回默认值
      if (value === null || value === undefined || value === '') {
        return defaultValue;
      }

      // 如果已经是正确类型，直接返回
      if (typeof value !== 'string') {
        return value;
      }

      // 尝试解析为 JSON（数组或对象）
      if (value.startsWith('{') && value.endsWith('}') || value.startsWith('[') && value.endsWith(']')) {
        try {
          return JSON.parse(value);
        } catch (error) {
          console.warn(`字段 ${fieldName} JSON解析失败:`, error);
          return defaultValue;
        }
      }

      // 判断是否为时间戳字段，如果是数字字符串且字段名包含时间相关词汇
      const timeFields = ['created', 'updated', 'lastAccessed', 'lastContact', 'lastDocumentUpdate', 'created_at', 'updated_at', 'timestamp', 'datetime', 'extractedAt'];
      if (timeFields.includes(fieldName) && /^\d+$/.test(value)) {
        return parseInt(value, 10);
      }

      // 判断是否为数字字段
      const numberFields = ['accessCount', 'importance', 'hotness', 'criticalityScore', 'current_weight', 'relevanceScore', 'total_interactions', 'total_records'];
      if (numberFields.includes(fieldName) && /^-?\d*\.?\d+$/.test(value)) {
        return parseFloat(value);
      }

      // 布尔字段处理
      if (value === 'true') return true;
      if (value === 'false') return false;

      // 其他情况保持字符串
      return value;
    };
    try {
      // 从默认值开始或创建新对象
      const result = defaultValues ? {
        ...defaultValues
      } : {};

      // 处理metadata中的所有字段
      for (const key in metadata) {
        if (metadata[key] !== undefined) {
          result[key] = processField(metadata[key], key, result[key]);
        }
      }
      return result;
    } catch (error) {
      console.error('反序列化ChromaDB metadata失败:', error);
      return defaultValues || {};
    }
  }

  /**
   * 🆕 从ChromaDB metadata反序列化实体（使用通用反序列化函数）
   */
  deserializeEntityFromMetadata(metadata) {
    // 默认值定义
    const defaults = {
      id: '',
      type: 'Document',
      name: '',
      document: '',
      properties: {},
      created: Date.now(),
      updated: Date.now(),
      accessCount: 0,
      lastAccessed: Date.now(),
      importance: 0.5,
      tags: [],
      status: 'active',
      statistic: {
        conversations: 0,
        projects: 0,
        participants: 0,
        resources: 0,
        documents: 0,
        webpages: 0,
        relationships: 0,
        topics: 0,
        jiraTickets: 0
      },
      relatedData: {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      },
      hotness: 0,
      criticalityScore: 0,
      lastDocumentUpdate: Date.now(),
      expertise: []
    };
    return this.deserializeChromaMetadata(metadata, defaults);
  }

  /**
   * 将基础 MemoryEntity 扩展为包含完整缓存数据的实体
   */
  async extendEntityToDetailCache(entity) {
    this.ensureInitialized();
    try {
      // 获取相关项目：优先使用 entity.relatedData.projects，否则向量搜索
      let relatedProjects = [];
      if (entity.relatedData?.projects && entity.relatedData.projects.length > 0) {
        // 使用现有的相关项目数据
        relatedProjects = entity.relatedData.projects.map(project => ({
          id: project.id || `project_${Date.now()}`,
          name: project.name || project.projectName || '未知项目',
          status: project.status || '开发中',
          description: project.document || `项目: ${project.name || project.projectName || '未命名项目'}`
        }));
        console.log(`📁 使用实体现有的项目数据: ${relatedProjects.length} 个`);
      } else {
        // 向量搜索相关项目
        try {
          const projectSearchResults = await this.searchByVector(`${entity.name} 项目`, 'Project', {
            limit: 5,
            returnType: 'entities'
          });
          relatedProjects = projectSearchResults.data.map(project => ({
            id: project.id,
            name: project.name || '未知项目',
            status: project.properties?.status || project.status || '开发中',
            description: project.document || `项目: ${project.name || '未命名项目'}`
          }));
          console.log(`🔍 通过向量搜索找到相关项目: ${relatedProjects.length} 个`);
        } catch (error) {
          console.warn('搜索相关项目失败:', error);
          relatedProjects = [];
        }
      }

      // 获取相关资源：优先使用 entity.relatedData.resources，否则向量搜索
      let relatedResources = [];
      if (entity.relatedData?.resources && entity.relatedData.resources.length > 0) {
        // 使用现有的相关资源数据
        relatedResources = entity.relatedData.resources.map(resource => ({
          id: resource.id || `resource_${Date.now()}`,
          name: resource.name || resource.title || '文档资源',
          type: resource.type || '文档',
          url: resource.url || '#'
        }));
        console.log(`📄 使用实体现有的资源数据: ${relatedResources.length} 个`);
      } else {
        // 向量搜索相关文档资源
        try {
          const resourceSearchResults = await this.searchByVector(`${entity.name} 文档 资源`, 'Document', {
            limit: 5,
            returnType: 'entities'
          });
          relatedResources = resourceSearchResults.data.map(doc => ({
            id: doc.id,
            name: doc.name || '文档资源',
            type: '文档',
            url: doc.properties?.url || '#'
          }));
          console.log(`🔍 通过向量搜索找到相关资源: ${relatedResources.length} 个`);
        } catch (error) {
          console.warn('搜索相关资源失败:', error);
          relatedResources = [];
        }
      }

      // 获取相关对话：优先使用 entity.relatedData.conversations，扩展缺失信息，否则使用 getSimilarMessages 搜索
      let latestConversations = [];
      if (entity.relatedData?.conversations && entity.relatedData.conversations.length > 0) {
        // 使用现有的对话数据，并扩展缺失的详细信息
        console.log(`💬 处理实体现有的对话数据: ${entity.relatedData.conversations.length} 个`);
        for (const conv of entity.relatedData.conversations) {
          const relatedDataConv = {
            ...conv
          };

          // 如果缺少 contextMessages 或 originalContent，尝试通过 getMessage 扩展
          if (!relatedDataConv.contextMessages || relatedDataConv.contextMessages.length === 0 || !relatedDataConv.content) {
            try {
              const messageData = await this.getMessage(relatedDataConv.id);
              if (messageData) {
                // 从检索到的文档中获取 content
                if (!relatedDataConv.content && messageData.content) {
                  relatedDataConv.content = messageData.content;
                }

                // 从 metadata 中获取 contextMessages
                if (!relatedDataConv.contextMessages || relatedDataConv.contextMessages.length === 0) {
                  if (messageData.contextMessages && messageData.contextMessages.length > 0) {
                    relatedDataConv.contextMessages = messageData.contextMessages;
                  } else {
                    relatedDataConv.contextMessages = [{
                      id: messageData.id,
                      sender: messageData.sender,
                      content: messageData.content,
                      datetime: messageData.datetime,
                      isMainMessage: true
                    }];
                  }
                }

                // 补充其他缺失字段
                relatedDataConv.summary = messageData.summary;
                relatedDataConv.groupName = messageData.groupName;
                relatedDataConv.groupUrl = messageData.groupUrl;
                relatedDataConv.groupId = messageData.groupId;
                relatedDataConv.matchedRules = messageData.matchedRules;
                relatedDataConv.replyAdvice = messageData.replyAdvice;
                console.log(`🔍 通过 getMessage 扩展了对话 ${relatedDataConv.id} 的详细信息`);
              }
            } catch (error) {
              console.warn(`扩展对话 ${relatedDataConv.id} 详细信息失败:`, error);
            }
          }
          latestConversations.push(relatedDataConv);
        }
        console.log(`💬 完成对话数据处理: ${latestConversations.length} 个，其中扩展了详细信息`);
      } else {
        // 使用新的 getSimilarMessages 方法搜索相关对话
        try {
          latestConversations = await this.getSimilarMessages(entity.name, {
            limit: 5,
            minRelevanceScore: 0.3,
            sortBy: 'relevance',
            sortOrder: 'desc'
          });
          console.log(`🔍 通过 getSimilarMessages 找到相关对话: ${latestConversations.length} 个`);
        } catch (error) {
          console.warn('搜索相关对话失败:', error);
          latestConversations = [];
        }
      }

      // 获取相关网页记录：优先使用 entity.relatedData.webpages，否则从对话中提取
      let latestWebpages = [];
      if (entity.relatedData?.webpages && entity.relatedData.webpages.length > 0) {
        // 使用现有的网页数据
        latestWebpages = entity.relatedData.webpages.map(webpage => ({
          id: webpage.id || `web_${Date.now()}`,
          title: webpage.title || webpage.name || `${entity.name}相关网页`,
          url: webpage.url || '#',
          type: webpage.type || 'webpage',
          datetime: webpage.datetime || webpage.visitTime || new Date().toISOString(),
          summary: webpage.summary || webpage.description || `与${entity.name}相关的内容`,
          tags: webpage.tags || [entity.name, '网页']
        }));
        console.log(`🌐 使用实体现有的网页数据: ${latestWebpages.length} 个`);
      } else {
        // 向量搜索相关网页记录
        try {
          const webpageSearchResults = await this.searchByVector(`${entity.name} 文档 资源`, 'Document', {
            limit: 5,
            returnType: 'entities'
          });
          latestWebpages = webpageSearchResults.data.map(webpage => ({
            id: webpage.id,
            name: webpage.name || '网页资源',
            type: '网页',
            url: webpage.properties?.url || '#'
          }));
          console.log(`🔍 通过向量搜索找到相关资源: ${latestWebpages.length} 个`);
        } catch (error) {
          console.warn('搜索相关资源失败:', error);
          latestWebpages = [];
        }
      }

      // 获取相关人员和主题：优先使用现有数据
      const relatedPeople = entity.relatedData?.people ? entity.relatedData.people.slice(0, 5) : [];
      const relatedTopics = entity.relatedData?.topics ? entity.relatedData.topics.slice(0, 5) : [];
      const jiraTickets = entity.relatedData?.jiraTickets ? entity.relatedData.jiraTickets.slice(0, 5) : [];
      const cooccurringEntities = entity.relatedData?.cooccurringEntities ? entity.relatedData.cooccurringEntities.slice(0, 10) : [];

      // 统计参与者：优先从 people 数据，否则从对话中统计
      let participantCount = 1;
      if (relatedPeople.length > 0) {
        participantCount = relatedPeople.length;
      } else {
        participantCount = new Set(latestConversations.map(conv => conv.sender)).size || 1;
      }

      // 构建扩展后的实体详情
      const result = {
        ...entity,
        statistic: {
          conversations: latestConversations.length,
          projects: relatedProjects.length,
          participants: participantCount,
          resources: relatedResources.length,
          documents: relatedResources.filter(r => r.type === '文档').length,
          webpages: latestWebpages.length,
          relationships: entity.properties?.relationshipsCount || 0,
          topics: relatedTopics.length,
          jiraTickets: jiraTickets.length
        },
        recentDataDetails: {
          conversations: latestConversations,
          webpages: latestWebpages,
          resources: relatedResources,
          projects: relatedProjects,
          people: relatedPeople,
          topics: relatedTopics,
          jiraTickets: jiraTickets,
          cooccurringEntities: cooccurringEntities
        },
        relatedParticipants: [],
        // 由 LocalStorage 在本地填充
        cachedAt: Date.now()
      };

      // 输出数据获取总结
      console.log(`✅ 实体详情扩展完成 [${entity.name}]:`, {
        conversations: `${latestConversations.length} 个`,
        projects: `${relatedProjects.length} 个`,
        resources: `${relatedResources.length} 个`,
        webpages: `${latestWebpages.length} 个`,
        people: `${relatedPeople.length} 个`,
        topics: `${relatedTopics.length} 个`,
        jiraTickets: `${jiraTickets.length} 个`,
        participants: `${participantCount} 人`
      });
      return result;
    } catch (error) {
      console.error('扩展实体详情失败:', error);
      // 返回基础实体和默认值
      return {
        ...entity,
        statistic: {
          conversations: 0,
          projects: 0,
          participants: 1,
          resources: 0,
          documents: 0,
          webpages: 0,
          relationships: 0,
          topics: 0,
          jiraTickets: 0
        },
        recentDataDetails: {
          conversations: [],
          webpages: [],
          resources: [],
          projects: [],
          people: [],
          topics: [],
          jiraTickets: [],
          cooccurringEntities: []
        },
        relatedParticipants: [],
        cachedAt: Date.now()
      };
    }
  }

  /**
   * 批量更新实体的统计信息
   */
  async batchUpdateEntityStatistics(updates) {
    this.ensureInitialized();
    if (!updates || updates.length === 0) {
      console.log('📊 没有统计信息需要更新');
      return;
    }
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) {
        throw new Error('graph-entities 集合未找到');
      }
      console.log(`📊 开始批量更新 ${updates.length} 个实体的统计信息...`);

      // 分批处理，避免一次性操作过多
      const batchSize = 50;
      for (let i = 0; i < updates.length; i += batchSize) {
        const batch = updates.slice(i, i + batchSize);
        try {
          // 获取当前批次的实体
          const entityIds = batch.map(u => u.entityId);
          const existingEntities = await collection.get({
            ids: entityIds,
            include: ['metadatas']
          });
          if (!existingEntities.ids || existingEntities.ids.length === 0) {
            console.log(`📊 批次 ${i / batchSize + 1}: 没有找到对应的实体`);
            continue;
          }

          // 准备更新的元数据
          const updateMetadatas = [];
          const updateIds = [];
          for (let j = 0; j < existingEntities.ids.length; j++) {
            const entityId = existingEntities.ids[j];
            const updateInfo = batch.find(u => u.entityId === entityId);
            if (updateInfo && existingEntities.metadatas) {
              const currentMetadata = existingEntities.metadatas[j];

              // 更新统计信息
              const updatedMetadata = {
                ...currentMetadata,
                statistic: JSON.stringify(updateInfo.statistic),
                lastStatisticUpdate: updateInfo.lastUpdated,
                updated: Date.now()
              };
              updateMetadatas.push(this.serializeChromaMetadata(updatedMetadata));
              updateIds.push(entityId);
            }
          }
          if (updateIds.length > 0) {
            // 执行批量更新
            await collection.update({
              ids: updateIds,
              metadatas: updateMetadatas
            });
            console.log(`📊 批次 ${i / batchSize + 1}: 成功更新 ${updateIds.length} 个实体的统计信息`);
          }
        } catch (batchError) {
          console.error(`📊 批次 ${i / batchSize + 1} 更新失败:`, batchError);
        }
      }
      console.log(`📊 批量统计信息更新完成`);
    } catch (error) {
      console.error('📊 批量更新实体统计信息失败:', error);
      throw error;
    }
  }

  /**
   * 🆕 生成自然语言描述 - 用于向量搜索的丰富上下文
   */
  async generateNaturalLanguageDescription(entity) {
    const parts = [];

    // 基础信息
    parts.push(`${entity.name}是一个${entity.type}实体。`);

    // 类型特定信息
    switch (entity.type) {
      case 'Person':
        if (entity.role) parts.push(`担任${entity.role}角色。`);
        if (entity.team) parts.push(`属于${entity.team}团队。`);
        if (entity.expertise && entity.expertise.length > 0) {
          parts.push(`专业领域包括：${entity.expertise.join('、')}。`);
        }
        break;
      case 'Project':
        if (entity.properties?.status) parts.push(`项目状态：${entity.properties.status}。`);
        break;
      case 'Topic':
        if (entity.properties?.category) parts.push(`话题分类：${entity.properties.category}。`);
        break;
    }

    // 🆕 关联数据的自然语言描述
    const {
      relatedData
    } = entity;

    // 最近的对话情况
    if (relatedData?.conversations && relatedData.conversations.length > 0) {
      const recentConversations = relatedData.conversations.slice(0, 5); // 取最近5条
      parts.push(`最近的相关讨论包括：`);
      recentConversations.forEach(conv => {
        parts.push(`- ${conv.sender}在${conv.groupName || '聊天'}中提到：${conv.summary}`);
      });
    }

    // 关联的项目
    if (relatedData?.projects && relatedData.projects.length > 0) {
      const topProjects = relatedData.projects.slice(0, 3);
      parts.push(`与以下项目相关：${topProjects.map(p => `${p.name}(${p.status})`).join('、')}。`);
    }

    // 关联的人员
    if (relatedData?.people && relatedData.people.length > 0) {
      const topPeople = relatedData.people.slice(0, 5);
      parts.push(`经常与这些人员合作：${topPeople.map(p => `${p.name}(${p.role})`).join('、')}。`);
    }

    // 关联的话题
    if (relatedData?.topics && relatedData.topics.length > 0) {
      const topTopics = relatedData.topics.slice(0, 3);
      parts.push(`相关讨论话题：${topTopics.map(t => t.name).join('、')}。`);
    }

    // JIRA工作项
    if (relatedData?.jiraTickets && relatedData.jiraTickets.length > 0) {
      const activeTickets = relatedData.jiraTickets.filter(t => t.status !== 'Done').slice(0, 3);
      if (activeTickets.length > 0) {
        parts.push(`相关的工作项：${activeTickets.map(t => `${t.key}: ${t.summary}`).join('；')}。`);
      }
    }

    // 网页资源
    if (relatedData?.webpages && relatedData.webpages.length > 0) {
      const recentPages = relatedData.webpages.slice(0, 3);
      parts.push(`相关网页资源：${recentPages.map(w => w.title).join('、')}。`);
    }

    // 其他相关实体
    if (relatedData?.cooccurringEntities && relatedData.cooccurringEntities.length > 0) {
      const topEntities = relatedData.cooccurringEntities.slice(0, 5);
      parts.push(`经常与这些概念一起出现：${topEntities.map(e => e.name).join('、')}。`);
    }

    // 统计信息
    const stats = entity.statistic;
    if (stats) {
      const activeParts = [];
      if (stats.conversations > 0) activeParts.push(`${stats.conversations}次对话`);
      if (stats.projects > 0) activeParts.push(`${stats.projects}个项目`);
      if (stats.participants > 0) activeParts.push(`${stats.participants}位参与者`);
      if (stats.jiraTickets > 0) activeParts.push(`${stats.jiraTickets}个工作项`);
      if (activeParts.length > 0) {
        parts.push(`总体活跃度：${activeParts.join('、')}。`);
      }
    }

    // 重要性和标签
    if (entity.importance > 0.7) {
      parts.push(`这是一个高优先级项目。`);
    }
    if (entity.tags && entity.tags.length > 0) {
      parts.push(`标签：${entity.tags.join('、')}。`);
    }
    return parts.join(' ');
  }

  /**
   * 🆕 计算实体热度评分 (0-1)
   */
  calculateEntityHotness(entity) {
    const now = Date.now();
    const dayMs = 24 * 60 * 60 * 1000;

    // 1. 最近活动频率（权重40%）
    let recentActivityScore = 0;
    const recentConversations = entity.relatedData?.conversations?.filter(c => now - new Date(c.datetime).getTime() < 7 * dayMs).length || 0;
    recentActivityScore = Math.min(recentConversations / 10, 1); // 7天内10条消息=满分

    // 2. 访问频率（权重30%）
    const daysSinceCreated = Math.max(1, (now - entity.created) / dayMs);
    const accessFrequency = (entity.accessCount || 0) / daysSinceCreated;
    const accessScore = Math.min(accessFrequency * 5, 1); // 每天5次访问=满分

    // 3. 关联数据丰富度（权重20%）
    const totalRelations = (entity.relatedData?.conversations?.length || 0) + (entity.relatedData?.projects?.length || 0) * 2 + (entity.relatedData?.people?.length || 0) + (entity.relatedData?.jiraTickets?.length || 0);
    const richnessScore = Math.min(totalRelations / 30, 1); // 30个关联=满分

    // 4. 最近更新（权重10%）
    const daysSinceUpdate = (now - entity.updated) / dayMs;
    const freshnessScore = Math.max(0, 1 - daysSinceUpdate / 7); // 7天内=满分

    return recentActivityScore * 0.4 + accessScore * 0.3 + richnessScore * 0.2 + freshnessScore * 0.1;
  }

  /**
   * 🆕 计算实体关键性评分 (0-1)
   */
  calculateEntityCriticality(entity) {
    let userImportanceBoost = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
    // 1. 基础重要性（权重50%）
    const baseImportance = entity.importance || 0.5;

    // 2. 用户明确标记（权重30%）
    const userBoostScore = Math.min(userImportanceBoost, 1);

    // 3. 关联项目重要性（权重15%）
    let projectImportanceScore = 0;
    if (entity.relatedData?.projects && entity.relatedData.projects.length > 0) {
      const activeProjects = entity.relatedData.projects.filter(p => p.status !== 'Completed');
      projectImportanceScore = Math.min(activeProjects.length / 3, 1); // 3个活跃项目=满分
    }

    // 4. 关联人员重要性（权重5%）
    const peopleImportanceScore = Math.min((entity.relatedData?.people?.length || 0) / 10, 1);
    return baseImportance * 0.5 + userBoostScore * 0.3 + projectImportanceScore * 0.15 + peopleImportanceScore * 0.05;
  }

  /**
   * 🆕 从消息元数据构建实体关联数据
   */
  buildEntityRelatedDataFromMessage(entityName, entityType, messageMetadata, extractedEntities, messageId) {
    const entityKey = entityType + '_' + entityName;
    const relatedData = {
      conversations: [],
      webpages: [],
      resources: [],
      projects: [],
      people: [],
      topics: [],
      jiraTickets: [],
      cooccurringEntities: []
    };

    // 1. 添加当前消息
    if (messageMetadata) {
      relatedData.conversations.push({
        id: messageId,
        summary: messageMetadata.summary || messageMetadata.content?.substring(0, 100) + '...',
        sender: messageMetadata.sender || messageMetadata.source || 'unknown',
        groupId: messageMetadata.groupId || '',
        groupName: messageMetadata.groupName || '未知群组',
        groupUrl: messageMetadata.groupUrl || '#',
        datetime: messageMetadata.datetime || new Date().toISOString(),
        relevanceScore: 0.9 // 来源消息相关性最高
      });
    }

    // 2. 添加同消息中的其他实体作为共现实体
    extractedEntities.forEach(otherEntity => {
      const key = otherEntity.type + '_' + otherEntity.name;
      if (key !== entityKey) {
        // 为没有 id 的实体生成临时 ID
        const tempId = `temp_${otherEntity.type}_${otherEntity.name}_${Date.now()}`;
        relatedData.cooccurringEntities.push({
          id: tempId,
          name: otherEntity.name,
          type: otherEntity.type,
          relevanceScore: 0.8 // 同消息共现的相关性较高
        });

        // 根据类型添加到对应的关联数据中
        switch (otherEntity.type) {
          case 'Person':
            relatedData.people.push({
              id: tempId,
              name: otherEntity.name,
              role: otherEntity.properties?.role || '',
              team: otherEntity.properties?.team || '',
              expertise: otherEntity.properties?.expertise || [],
              lastContact: Date.now(),
              relevanceScore: 0.8
            });
            break;
          case 'Project':
            relatedData.projects.push({
              id: tempId,
              name: otherEntity.name,
              description: otherEntity.document || '',
              status: otherEntity.properties?.status || 'Active',
              relevanceScore: 0.8
            });
            break;
          case 'Topic':
            relatedData.topics.push({
              id: tempId,
              name: otherEntity.name,
              summary: otherEntity.document || `关于${otherEntity.name}的讨论`,
              category: otherEntity.properties?.category || '技术讨论',
              relevanceScore: 0.8
            });
            break;
          case 'Task':
            // 假设Task类型是JIRA ticket
            relatedData.jiraTickets.push({
              id: tempId,
              key: otherEntity.properties?.key || otherEntity.name,
              summary: otherEntity.document || otherEntity.name,
              status: otherEntity.properties?.status || 'In Progress',
              assignee: otherEntity.properties?.assignee || '',
              dueDate: otherEntity.properties?.dueDate || Date.now(),
              priority: otherEntity.properties?.priority || 'Medium',
              relevanceScore: 0.8
            });
            break;
          case 'Document':
            relatedData.resources.push({
              id: tempId,
              summary: otherEntity.document || `文档：${otherEntity.name}`,
              name: otherEntity.name,
              type: 'document',
              url: otherEntity.properties?.url,
              relevanceScore: 0.7
            });
            break;
        }
      }
    });
    return relatedData;
  }

  /**
   * 🆕 从消息元数据提取实体信息
   */
  extractEntitiesFromMetadata(metadata, messageId) {
    const entities = [];
    if (metadata.entities) {
      // 提取人员实体
      if (metadata.entities.people) {
        for (const person of metadata.entities.people) {
          entities.push({
            type: 'Person',
            name: person.name,
            document: `人员: ${person.name}`,
            role: person.role,
            team: person.team,
            expertise: person.expertise,
            properties: {
              mentioned_context: person.mentioned_context,
              source: 'message_analysis',
              groupName: metadata.groupName || '',
              messageId: messageId,
              datetime: metadata.datetime || Date.now()
            },
            importance: 0.7,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }

      // 提取项目实体
      if (metadata.entities.projects) {
        for (const project of metadata.entities.projects) {
          entities.push({
            type: 'Project',
            name: project.name,
            document: `项目: ${project.name}`,
            properties: {
              status: project.status,
              related_people: project.related_people,
              source: 'message_analysis',
              groupName: metadata.groupName || '',
              messageId: messageId,
              timestamp: metadata.timestamp || Date.now()
            },
            importance: 0.8,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }

      // 提取话题实体
      if (metadata.entities.topics) {
        for (const topic of metadata.entities.topics) {
          entities.push({
            type: 'Topic',
            name: topic.name,
            document: `话题: ${topic.name}`,
            properties: {
              category: topic.category,
              keywords: topic.keywords,
              source: 'message_analysis',
              groupName: metadata.groupName || '',
              messageId: messageId,
              timestamp: metadata.timestamp || Date.now()
            },
            importance: 0.5,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }

      // 提取文档/资源实体
      if (metadata.entities.documents || metadata.entities.resources) {
        const documentsList = [...(metadata.entities.documents || []), ...(metadata.entities.resources || [])];
        for (const doc of documentsList) {
          entities.push({
            type: 'Document',
            name: doc.name || doc.title,
            document: `文档: ${doc.name || doc.title}`,
            properties: {
              url: doc.url,
              type: doc.type || 'document',
              description: doc.description,
              source: 'message_analysis',
              groupName: metadata.groupName || '',
              messageId: messageId,
              timestamp: metadata.timestamp || Date.now()
            },
            importance: 0.6,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }

      // 提取技术实体
      if (metadata.entities.technologies || metadata.entities.tools) {
        const techList = [...(metadata.entities.technologies || []), ...(metadata.entities.tools || [])];
        for (const tech of techList) {
          entities.push({
            type: 'Technology',
            name: tech.name,
            document: `技术: ${tech.name}`,
            properties: {
              category: tech.category,
              version: tech.version,
              usage_context: tech.usage_context,
              source: 'message_analysis',
              groupName: metadata.groupName || '',
              type: 'technology',
              messageId: messageId,
              timestamp: metadata.timestamp || Date.now()
            },
            importance: 0.6,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }

      // 提取组织实体
      if (metadata.groupName && metadata.groupName !== 'SM AI') {
        entities.push({
          type: 'Organization',
          name: metadata.groupName,
          document: `组织: ${metadata.groupName}`,
          properties: {
            groupId: metadata.groupId,
            source: 'message_analysis',
            type: 'team',
            messageId: messageId,
            timestamp: metadata.timestamp || Date.now()
          },
          importance: 0.6,
          accessCount: 1,
          lastAccessed: Date.now(),
          tags: [],
          statistic: {
            conversations: 0,
            projects: 0,
            participants: 0,
            resources: 0,
            documents: 0,
            webpages: 0,
            relationships: 0,
            topics: 0,
            jiraTickets: 0
          },
          relatedData: {
            conversations: [],
            webpages: [],
            resources: [],
            projects: [],
            people: [],
            topics: [],
            jiraTickets: [],
            cooccurringEntities: []
          }
        });
      }
    }
    return entities;
  }

  /**
   * 🆕 更新实体关联数据 - 从消息分析中提取实体并更新其关联信息
   */
  async updateEntitiesWithRelatedData(messageMetadata, messageId) {
    console.log(`🔗 开始从消息 ${messageId} 更新实体关联数据...`);
    try {
      // 1. 从消息元数据提取实体
      const extractedEntities = this.extractEntitiesFromMetadata(messageMetadata, messageId);
      if (extractedEntities.length === 0) {
        console.log('📭 消息中未发现实体，跳过关联数据更新');
        return;
      }
      console.log(`📝 从消息中提取到 ${extractedEntities.length} 个实体: ${extractedEntities.map(e => `${e.name}(${e.type})`).join(', ')}`);

      // 2. 为每个实体构建和更新关联数据
      for (const entity of extractedEntities) {
        try {
          // 为当前实体构建关联数据
          const relatedDataForEntity = this.buildEntityRelatedDataFromMessage(entity.name, entity.type, messageMetadata, extractedEntities, messageId);

          // 计算实体热度和重要性
          const entityWithRelatedData = {
            ...entity,
            created: Date.now(),
            // 确保有created属性
            updated: Date.now(),
            relatedData: relatedDataForEntity
          };

          // 更新热度和关键性评分
          entityWithRelatedData.hotness = this.calculateEntityHotness(entityWithRelatedData);
          entityWithRelatedData.criticalityScore = this.calculateEntityCriticality(entityWithRelatedData, 0);

          // 检查是否存在相似的实体（使用新的 getSimilarEntities 方法）
          const similarEntities = await this.getSimilarEntities(entityWithRelatedData);
          const existingEntity = similarEntities.length > 0 ? similarEntities[0] : null;
          if (existingEntity) {
            console.log(`🔄 找到相似实体: ${entity.name} -> ${existingEntity.name}, 相似度: ${existingEntity.relevanceScore?.toFixed(3)}`);
            // 更新现有实体的关联数据
            const updateData = {
              relatedData: relatedDataForEntity,
              hotness: entityWithRelatedData.hotness,
              criticalityScore: entityWithRelatedData.criticalityScore,
              lastAccessed: Date.now(),
              accessCount: (existingEntity.accessCount || 0) + 1
            };
            const updateResult = await memorySystem.updateEntity(existingEntity.id, updateData);
            console.log(`🔄 实体关联数据更新: ${entity.name} -> ${existingEntity.name}, 成功: ${updateResult.success ? '✅' : '❌'}`);
          } else {
            await this.getSimilarEntities(entityWithRelatedData);
            // 存储新实体（包含完整关联数据）
            const newEntity = {
              ...entityWithRelatedData,
              created: Date.now(),
              updated: Date.now(),
              accessCount: 1,
              lastAccessed: Date.now(),
              statistic: {
                conversations: relatedDataForEntity.conversations?.length || 0,
                projects: relatedDataForEntity.projects?.length || 0,
                participants: relatedDataForEntity.people?.length || 0,
                resources: relatedDataForEntity.resources?.length || 0,
                documents: relatedDataForEntity.resources?.filter(r => r.type === 'document')?.length || 0,
                webpages: relatedDataForEntity.webpages?.length || 0,
                topics: relatedDataForEntity.topics?.length || 0,
                jiraTickets: relatedDataForEntity.jiraTickets?.length || 0,
                relationships: relatedDataForEntity.cooccurringEntities?.length || 0
              }
            };
            const storeResult = await memorySystem.storeEntity(newEntity);
            console.log(`🆕 新实体存储: ${entity.name}, 成功: ${storeResult.success ? '✅' : '❌'}`);
          }
        } catch (entityError) {
          console.error(`❌ 更新实体 ${entity.name} 关联数据失败:`, entityError);
        }
      }
      console.log(`✅ 所有实体关联数据更新完成`);
    } catch (error) {
      console.error('🚨 更新实体关联数据过程中发生错误:', error);
    }
  }

  /**
   * 🆕 存储独立用户配置（自定义Prompt和分析偏好）
   */
  async storeIndependentUserConfig(config) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-user-config`);
      if (!collection) {
        console.warn('用户配置集合不存在，尝试创建...');
        // 尝试创建集合
        try {
          await this.client.createCollection({
            name: `${this.username}-user-config`,
            metadata: {
              type: 'user-config'
            }
          });
          this.collections.set(`${this.username}-user-config`, await this.client.getCollection({
            name: `${this.username}-user-config`
          }));
        } catch (createError) {
          console.error('创建用户配置集合失败:', createError);
          return false;
        }
      }
      const configCollection = this.collections.get(`${this.username}-user-config`);
      const configId = `config-${this.username}`;
      const embedding = await getEmbeddingViaOffscreen(`user config: ${JSON.stringify(config).substring(0, 100)}`);
      await configCollection.upsert({
        ids: [configId],
        documents: [`User configuration for ${this.username}`],
        embeddings: [embedding],
        metadatas: [{
          userId: this.username,
          configType: 'independent_user_config',
          lastUpdated: Date.now(),
          version: config.version || '1.0',
          configData: JSON.stringify(config)
        }]
      });
      console.log('独立用户配置已存储到云端');
      return true;
    } catch (error) {
      console.error('存储独立用户配置失败:', error);
      return false;
    }
  }

  /**
   * 🆕 获取独立用户配置
   */
  async getIndependentUserConfig() {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-user-config`);
      if (!collection) {
        console.log('用户配置集合不存在');
        return null;
      }
      const configId = `config-${this.username}`;
      const result = await collection.get({
        ids: [configId],
        include: ['metadatas']
      });
      if (result.metadatas && result.metadatas.length > 0) {
        const metadata = result.metadatas[0];
        if (metadata && metadata.configData) {
          console.log('从云端获取独立用户配置成功');
          return JSON.parse(metadata.configData);
        }
      }
      console.log('云端未找到独立用户配置');
      return null;
    } catch (error) {
      console.error('获取独立用户配置失败:', error);
      return null;
    }
  }

  // ==================== ChromaDB 包装方法(暂不启用) ====================

  /**
   * 包装 collection.get 方法，自动反序列化 metadata
   */
  async wrappedCollectionGet(collection, params) {
    const result = await collection.get(params);

    // 自动反序列化 metadata（创建新对象以避免只读属性错误）
    if (result.metadatas) {
      return {
        ...result,
        metadatas: result.metadatas.map(metadata => this.deserializeChromaMetadata(metadata))
      };
    }
    return result;
  }

  /**
   * 包装 collection.query 方法，自动反序列化 metadata
   */
  async wrappedCollectionQuery(collection, params) {
    const result = await collection.query(params);

    // 自动反序列化 metadata（创建新对象以避免只读属性错误）
    if (result.metadatas) {
      return {
        ...result,
        metadatas: result.metadatas.map(metadataArray => metadataArray.map(metadata => this.deserializeChromaMetadata(metadata)))
      };
    }
    return result;
  }

  /**
   * 包装 collection.add 方法，自动序列化 metadata
   */
  async wrappedCollectionAdd(collection, params) {
    const wrappedParams = {
      ...params
    };

    // 自动序列化 metadata
    if (wrappedParams.metadatas) {
      wrappedParams.metadatas = wrappedParams.metadatas.map(metadata => this.serializeChromaMetadata(metadata));
    }
    return await collection.add(wrappedParams);
  }

  /**
   * 包装 collection.update 方法，自动序列化 metadata
   */
  async wrappedCollectionUpdate(collection, params) {
    const wrappedParams = {
      ...params
    };

    // 自动序列化 metadata
    if (wrappedParams.metadatas) {
      wrappedParams.metadatas = wrappedParams.metadatas.map(metadata => this.serializeChromaMetadata(metadata));
    }
    return await collection.update(wrappedParams);
  }

  /**
   * 包装 collection.upsert 方法，自动序列化 metadata
   */
  async wrappedCollectionUpsert(collection, params) {
    const wrappedParams = {
      ...params
    };

    // 自动序列化 metadata
    if (wrappedParams.metadatas) {
      wrappedParams.metadatas = wrappedParams.metadatas.map(metadata => this.serializeChromaMetadata(metadata));
    }
    return await collection.upsert(wrappedParams);
  }

  /**
   * 包装 collection.delete 方法（不需要序列化/反序列化）
   */
  async wrappedCollectionDelete(collection, params) {
    return await collection.delete(params);
  }
}
;// CONCATENATED MODULE: ./src/storage/LocalStorage.ts
/**
 * 本地缓存管理器
 * 专门管理 Chrome Storage 缓存，包括实体基础信息、关系索引和最近数据
 */

// 统一的缓存实体详情接口 - 包含所有本地缓存数据

// 关系类型定义

// 缓存键前缀
const CACHE_KEYS = {
  ENTITIES: 'cache_entities',
  // 统一存储 CachedEntityDetail 格式，移除 RECENT_DATA
  ENTITY_INDEX: 'cache_entity_index',
  TYPE_INDEX: 'cache_type_index',
  RELATIONSHIPS: 'cache_relationships',
  RELATIONSHIP_INDEX: 'cache_relationship_index',
  STATISTICS: 'cache_statistics'
};

// 缓存配置

// 实体索引

// 类型索引

// 关系索引

/**
 * 本地存储管理器
 */
class LocalStorage {
  constructor() {
    this.memoryEntities = new Map();
    this.memoryRelationships = new Map();
    this.isInitialized = false;
    this.config = {
      maxEntitiesInMemory: 1000,
      // 内存中最多保存1000个实体
      maxRecentDataPerEntity: 5,
      // 每个实体最多保存5条最近数据
      statisticsCacheDuration: 30 * 60 * 1000,
      // 30分钟
      recentDataCacheDuration: 6 * 60 * 60 * 1000,
      // 6小时
      // 新增：最近数据同步配置
      enableRecentDataSync: true,
      // 启用基于关系的最近数据同步
      recentDataSyncBatchSize: 10,
      // 每批处理10个实体的最近数据
      recentDataQueryLimit: 5 // 每个实体最多查询5条最近数据
    };
  }

  /**
   * 初始化本地缓存
   */
  async initialize() {
    try {
      console.log('💾 初始化本地缓存...');

      // 加载实体到内存
      await this.loadEntitiesToMemory();

      // 加载关系到内存
      await this.loadRelationshipsToMemory();

      // 启动定期清理
      this.startPeriodicCleanup();
      this.isInitialized = true;
      console.log('✅ 本地缓存初始化完成');
      return true;
    } catch (error) {
      console.error('❌ 本地缓存初始化失败:', error);
      return false;
    }
  }

  // ==================== 实体缓存管理 ====================

  /**
   * 获取实体详情（统一的CachedEntityDetail格式，先内存后存储）
   */
  async getEntity(entityId) {
    this.ensureInitialized();

    // 从存储获取完整的 CachedEntityDetail
    try {
      const result = await chrome.storage.local.get(`${CACHE_KEYS.ENTITIES}_${entityId}`);
      const entity = result[`${CACHE_KEYS.ENTITIES}_${entityId}`];
      if (entity) {
        // 更新访问时间
        entity.lastAccessed = Date.now();
        entity.accessCount = (entity.accessCount || 0) + 1;

        // 确保实体包含所有必要的字段
        this.ensureDetailEntityFields(entity);

        // 同步基础实体到内存（如果空间允许）
        if (this.memoryEntities.size < this.config.maxEntitiesInMemory) {
          const baseEntity = this.convertToBaseEntity(entity);
          this.memoryEntities.set(entityId, baseEntity);
        }
        return entity;
      }
    } catch (error) {
      console.error('从存储获取实体失败:', error);
    }
    return null;
  }

  /**
   * 按类型查询实体
   */
  async queryEntitiesByType(type) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    this.ensureInitialized();
    const startTime = Date.now();
    const {
      limit = 50,
      offset = 0,
      sortBy = 'lastAccessed',
      sortOrder = 'desc'
    } = options;
    try {
      // 获取类型索引
      const typeIndex = await this.getTypeIndex();
      const entityIds = typeIndex[type] || [];
      const entities = [];

      // 获取实体数据
      for (const entityId of entityIds) {
        const entity = await this.getEntity(entityId);
        if (entity) {
          entities.push(entity);
        }
      }

      // 排序
      entities.sort((a, b) => {
        const aValue = a[sortBy];
        const bValue = b[sortBy];
        return sortOrder === 'desc' ? bValue - aValue : aValue - bValue;
      });

      // 分页
      const paginatedEntities = entities.slice(offset, offset + limit);
      return {
        data: paginatedEntities,
        total: entities.length,
        source: 'local',
        cached: true,
        queryTime: Date.now() - startTime
      };
    } catch (error) {
      console.error('按类型查询实体失败:', error);
      return {
        data: [],
        total: 0,
        source: 'local',
        cached: true,
        queryTime: Date.now() - startTime
      };
    }
  }

  /**
   * 搜索实体（本地模糊搜索）
   */
  async searchEntities(searchTerm, type) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    this.ensureInitialized();
    const startTime = Date.now();
    const {
      limit = 20
    } = options;
    try {
      const entities = [];
      const searchLower = searchTerm.toLowerCase();

      // 从内存搜索
      for (const entity of Array.from(this.memoryEntities.values())) {
        if (type && entity.type !== type) continue;
        const matchesName = entity.name.toLowerCase().includes(searchLower);
        const matchesDescription = entity.description?.toLowerCase().includes(searchLower);
        const matchesTags = entity.tags?.some(tag => tag.toLowerCase().includes(searchLower));
        if (matchesName || matchesDescription || matchesTags) {
          entities.push(entity);
        }
      }

      // 如果内存中结果不够，从存储搜索
      if (entities.length < limit) {
        // 这里可以实现更复杂的存储搜索逻辑
        // 暂时先返回内存结果
      }

      // 按相关性排序（简单实现）
      entities.sort((a, b) => {
        const aScore = this.calculateRelevanceScore(a, searchTerm);
        const bScore = this.calculateRelevanceScore(b, searchTerm);
        return bScore - aScore;
      });
      return {
        data: entities.slice(0, limit),
        total: entities.length,
        source: 'local',
        cached: true,
        queryTime: Date.now() - startTime
      };
    } catch (error) {
      console.error('搜索实体失败:', error);
      return {
        data: [],
        total: 0,
        source: 'local',
        cached: true,
        queryTime: Date.now() - startTime
      };
    }
  }

  /**
   * 缓存实体（统一存储为CachedEntityDetail格式）
   */
  async cacheEntity(entity) {
    this.ensureInitialized();
    try {
      // 转换为 CachedEntityDetail 格式
      const detailEntity = this.isCachedEntityDetail(entity) ? entity : this.convertToDetailEntity(entity);

      // 确保包含所有必要字段
      this.ensureDetailEntityFields(detailEntity);

      // 存储到持久化存储（统一使用 CachedEntityDetail 格式）
      await chrome.storage.local.set({
        [`${CACHE_KEYS.ENTITIES}_${entity.id}`]: detailEntity
      });

      // 加载基础实体到内存（如果空间允许）
      const baseEntity = this.convertToBaseEntity(detailEntity);
      if (this.memoryEntities.size < this.config.maxEntitiesInMemory) {
        this.memoryEntities.set(entity.id, baseEntity);
      } else {
        // 移除最少使用的实体
        const lruEntity = this.findLRUEntity();
        if (lruEntity) {
          this.memoryEntities.delete(lruEntity.id);
        }
        this.memoryEntities.set(entity.id, baseEntity);
      }

      // 更新索引
      await this.updateEntityIndex(baseEntity);
    } catch (error) {
      console.error('缓存实体失败:', error);
    }
  }

  /**
   * 获取所有缓存的实体
   */
  async getAllEntities() {
    this.ensureInitialized();
    try {
      const entities = [];

      // 从内存获取所有实体
      for (const entity of Array.from(this.memoryEntities.values())) {
        entities.push(entity);
      }

      // 如果内存中没有实体，从存储中加载
      if (entities.length === 0) {
        const entityIndex = await this.getEntityIndex();
        for (const entityId of Object.keys(entityIndex)) {
          const entity = await this.getEntity(entityId);
          if (entity) {
            entities.push(entity);
          }
        }
      }
      console.log(`📦 从本地缓存获取了 ${entities.length} 个实体`);
      return entities;
    } catch (error) {
      console.error('获取所有本地实体失败:', error);
      return [];
    }
  }

  /**
   * 批量缓存实体
   */
  async batchCacheEntities(entities) {
    this.ensureInitialized();
    try {
      // 批量存储
      const storageData = {};
      for (const entity of entities) {
        storageData[`${CACHE_KEYS.ENTITIES}_${entity.id}`] = entity;
      }
      await chrome.storage.local.set(storageData);

      // 更新内存和索引
      for (const entity of entities) {
        if (this.memoryEntities.size < this.config.maxEntitiesInMemory) {
          this.memoryEntities.set(entity.id, entity);
        }
        await this.updateEntityIndex(entity);
      }
    } catch (error) {
      console.error('批量缓存实体失败:', error);
    }
  }

  // ==================== 关系缓存管理 ====================

  /**
   * 获取关系网络
   */
  async getRelationshipNetwork(entityId) {
    let depth = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
    this.ensureInitialized();
    try {
      const visitedEntities = new Set();
      const foundEntities = [];
      const foundRelationships = [];
      await this.traverseRelationships(entityId, depth, visitedEntities, foundEntities, foundRelationships);
      return {
        entities: foundEntities,
        relationships: foundRelationships
      };
    } catch (error) {
      console.error('获取关系网络失败:', error);
      return {
        entities: [],
        relationships: []
      };
    }
  }

  /**
   * 🆕 存储关系（对外接口）
   */
  async storeRelationship(relationship) {
    await this.cacheRelationship(relationship);
  }

  /**
   * 缓存关系
   */
  async cacheRelationship(relationship) {
    this.ensureInitialized();
    try {
      // 存储到持久化存储
      await chrome.storage.local.set({
        [`${CACHE_KEYS.RELATIONSHIPS}_${relationship.id}`]: relationship
      });

      // 加载到内存
      this.memoryRelationships.set(relationship.id, relationship);

      // 更新关系索引
      await this.updateRelationshipIndex(relationship);

      // 🆕 更新聚合关系数据（用于同步）
      await this.updateAggregatedRelationshipData();
    } catch (error) {
      console.error('缓存关系失败:', error);
    }
  }

  /**
   * 恢复关系数据（新设备同步）- 简化版
   */
  async restoreRelationshipData(relationshipData) {
    this.ensureInitialized();
    try {
      console.log('🔄 恢复关系数据到本地缓存...');

      // 1. 恢复关系数据
      const relationshipMap = new Map();
      const entityRelationsMap = new Map();
      for (const [id, relationship] of relationshipData.relationships) {
        relationshipMap.set(id, relationship);

        // 构建实体-关系映射
        if (!entityRelationsMap.has(relationship.fromId)) {
          entityRelationsMap.set(relationship.fromId, new Set());
        }
        if (!entityRelationsMap.has(relationship.toId)) {
          entityRelationsMap.set(relationship.toId, new Set());
        }
        entityRelationsMap.get(relationship.fromId).add(id);
        entityRelationsMap.get(relationship.toId).add(id);
      }

      // 2. 批量保存关系到存储
      const relationshipStorageData = {};
      for (const [id, relationship] of Array.from(relationshipMap.entries())) {
        relationshipStorageData[`${CACHE_KEYS.RELATIONSHIPS}_${id}`] = relationship;
      }
      await chrome.storage.local.set(relationshipStorageData);

      // 3. 更新内存中的关系
      this.memoryRelationships = relationshipMap;

      // 4. 保存关系索引
      const relationshipIndexData = {
        relationships: Array.from(relationshipMap.entries()),
        entityToRelations: Array.from(entityRelationsMap.entries()).map(_ref => {
          let [key, value] = _ref;
          return [key, Array.from(value)];
        })
      };
      await chrome.storage.local.set({
        [CACHE_KEYS.RELATIONSHIP_INDEX]: relationshipIndexData
      });
      console.log(`✅ 恢复了 ${relationshipMap.size} 个关系到本地缓存`);

      // 🆕 更新聚合关系数据（用于同步）
      await this.updateAggregatedRelationshipData();
    } catch (error) {
      console.error('恢复关系数据失败:', error);
    }
  }

  /**
   * 🆕 获取简化的关系数据备份
   */
  async getSimplifiedRelationshipData() {
    const fullData = await this.getRelationshipBackupData();
    if (!fullData) return null;
    return {
      relationships: fullData.relationships,
      typeToEntities: fullData.typeToEntities
    };
  }

  /**
   * 获取完整的关系数据备份（包含entityToRelations）
   */
  async getRelationshipBackupData() {
    this.ensureInitialized();
    try {
      // 1. 获取关系数据
      const relationships = Array.from(this.memoryRelationships.entries());
      if (relationships.length === 0) {
        return null;
      }

      // 2. 获取类型索引
      const typeIndex = await this.getTypeIndex();
      const typeToEntities = Array.from(Object.entries(typeIndex)).map(_ref2 => {
        let [key, value] = _ref2;
        return [key, Array.from(value)];
      });

      // 3. 获取关系索引（entityToRelations）
      const relationshipIndex = await this.getRelationshipIndex();
      const entityToRelations = Array.from(Object.entries(relationshipIndex));
      return {
        relationships,
        entityToRelations,
        typeToEntities
      };
    } catch (error) {
      console.error('获取关系备份数据失败:', error);
      return null;
    }
  }

  // ==================== 最近数据缓存 ====================

  /**
   * 更新实体的详细数据（统一存储到ENTITIES）
   */
  async updateRecentData(entityId, type, data) {
    this.ensureInitialized();
    try {
      let entityDetail = await this.getEntity(entityId);
      if (!entityDetail) {
        // 如果实体不存在，创建一个基础的 CachedEntityDetail
        entityDetail = {
          id: entityId,
          type: 'Topic',
          // 默认类型，后续可以根据需要调整
          name: entityId,
          document: '',
          properties: {},
          created: Date.now(),
          updated: Date.now(),
          accessCount: 0,
          lastAccessed: Date.now(),
          importance: 0.5,
          statistic: {
            conversations: 0,
            projects: 0,
            participants: 1,
            resources: 0,
            documents: 0,
            webpages: 0,
            relationships: 0,
            topics: 0,
            jiraTickets: 0
          },
          relatedData: {
            conversations: [],
            webpages: [],
            resources: [],
            projects: [],
            people: [],
            topics: [],
            jiraTickets: [],
            cooccurringEntities: []
          },
          cachedAt: Date.now(),
          recentDataDetails: {
            conversations: [],
            webpages: [],
            resources: [],
            projects: [],
            people: [],
            topics: [],
            jiraTickets: [],
            cooccurringEntities: []
          },
          relatedParticipants: [],
          lastUpdated: Date.now()
        };
      }

      // 添加新数据到对应数组的开头（只保留最近5条）
      if (type === 'conversation') {
        entityDetail.recentDataDetails.conversations.unshift(data);
        if (entityDetail.recentDataDetails.conversations.length > 5) {
          entityDetail.recentDataDetails.conversations = entityDetail.recentDataDetails.conversations.slice(0, 5);
        }
      } else if (type === 'resource') {
        entityDetail.recentDataDetails.resources.unshift(data);
        if (entityDetail.recentDataDetails.resources.length > 5) {
          entityDetail.recentDataDetails.resources = entityDetail.recentDataDetails.resources.slice(0, 5);
        }
      } else if (type === 'project') {
        entityDetail.recentDataDetails.projects.unshift(data);
        if (entityDetail.recentDataDetails.projects.length > 5) {
          entityDetail.recentDataDetails.projects = entityDetail.recentDataDetails.projects.slice(0, 5);
        }
      } else {
        // webpage
        entityDetail.recentDataDetails.webpages.unshift(data);
        if (entityDetail.recentDataDetails.webpages.length > 5) {
          entityDetail.recentDataDetails.webpages = entityDetail.recentDataDetails.webpages.slice(0, 5);
        }
      }
      entityDetail.lastUpdated = Date.now();
      entityDetail.updated = Date.now();

      // 重新计算统计字段
      this.recalculateUIFields(entityDetail);

      // 保存更新到统一的ENTITIES存储
      await this.cacheEntity(entityDetail);
    } catch (error) {
      console.error('更新实体详细数据失败:', error);
    }
  }

  /**
   * 🆕 基于本地关系数据批量更新实体的最近数据缓存
   */
  async batchUpdateRecentDataCacheFromRelations(entities) {
    if (!this.config.enableRecentDataSync) {
      return 0;
    }
    let updatedCount = 0;
    const batches = this.chunkArray(entities, this.config.recentDataSyncBatchSize);
    for (const batch of batches) {
      // 并行处理批内实体，但控制并发数量
      const promises = batch.map(entity => this.updateEntityRecentDataFromRelations(entity));
      const results = await Promise.allSettled(promises);

      // 统计成功更新的数量
      for (const result of results) {
        if (result.status === 'fulfilled' && result.value) {
          updatedCount++;
        }
      }

      // 批间延迟，避免过度负载
      if (batches.length > 1) {
        await this.delay(50); // 减少延迟，因为本地查询更快
      }
    }
    return updatedCount;
  }

  /**
   * 🆕 基于本地关系数据更新单个实体的最近数据缓存
   */
  async updateEntityRecentDataFromRelations(entity) {
    try {
      const entityName = entity.name;
      let hasUpdates = false;

      // 🔗 1. 获取实体的关系网络（深度1，只获取直接相关的实体）
      const relationshipNetwork = await this.getRelationshipNetwork(entity.id, 1);
      if (relationshipNetwork.relationships.length === 0) {
        // console.log(`实体 ${entityName} 没有发现关系数据`);
        return false;
      }

      // 📊 2. 按数据来源分类关系
      const relationshipsBySource = {
        conversations: [],
        webpages: [],
        projects: [],
        resources: []
      };
      for (const relationship of relationshipNetwork.relationships) {
        const properties = relationship.properties || {};
        const source = properties.source;
        const discoveredAt = properties.discoveredAt || relationship.created;

        // 构建基础数据对象
        const baseData = {
          id: properties.messageId || properties.webpageId || properties.projectId || relationship.id,
          relationshipId: relationship.id,
          timestamp: discoveredAt,
          relationType: relationship.type,
          strength: relationship.strength
        };

        // 根据数据来源分类
        switch (source) {
          case 'message':
            relationshipsBySource.conversations.push({
              ...baseData,
              content: `通过关系"${relationship.type}"发现的相关消息`,
              summary: `与${this.getRelatedEntityName(relationship, entity.id)}的关系`,
              sender: 'system',
              // 可以后续优化为从原始消息获取
              messageId: properties.messageId
            });
            break;
          case 'webpage':
            relationshipsBySource.webpages.push({
              ...baseData,
              title: `通过关系"${relationship.type}"发现的相关网页`,
              url: properties.url || '',
              summary: `与${this.getRelatedEntityName(relationship, entity.id)}的关系`,
              visitTime: discoveredAt,
              domain: properties.domain || 'unknown'
            });
            break;
          case 'project':
            relationshipsBySource.projects.push({
              ...baseData,
              name: `通过关系"${relationship.type}"发现的相关项目`,
              description: `与${this.getRelatedEntityName(relationship, entity.id)}的关系`,
              status: properties.status || 'active'
            });
            break;
          default:
            // 其他类型归类为资源
            relationshipsBySource.resources.push({
              ...baseData,
              name: `通过关系"${relationship.type}"发现的相关资源`,
              description: `与${this.getRelatedEntityName(relationship, entity.id)}的关系`,
              type: source || 'unknown'
            });
            break;
        }
      }

      // 📝 3. 批量更新最近数据缓存
      const updatePromises = [];

      // 更新conversations
      if (relationshipsBySource.conversations.length > 0) {
        const sortedConversations = relationshipsBySource.conversations.sort((a, b) => b.timestamp - a.timestamp).slice(0, this.config.recentDataQueryLimit);
        for (const conversation of sortedConversations) {
          updatePromises.push(this.updateRecentData(entity.id, 'conversation', conversation));
        }
        hasUpdates = true;
      }

      // 更新webpages
      if (relationshipsBySource.webpages.length > 0) {
        const sortedWebpages = relationshipsBySource.webpages.sort((a, b) => b.timestamp - a.timestamp).slice(0, this.config.recentDataQueryLimit);
        for (const webpage of sortedWebpages) {
          updatePromises.push(this.updateRecentData(entity.id, 'webpage', webpage));
        }
        hasUpdates = true;
      }

      // 更新projects
      if (relationshipsBySource.projects.length > 0) {
        const sortedProjects = relationshipsBySource.projects.sort((a, b) => b.timestamp - a.timestamp).slice(0, this.config.recentDataQueryLimit);
        for (const project of sortedProjects) {
          updatePromises.push(this.updateRecentData(entity.id, 'project', project));
        }
        hasUpdates = true;
      }

      // 更新resources
      if (relationshipsBySource.resources.length > 0) {
        const sortedResources = relationshipsBySource.resources.sort((a, b) => b.timestamp - a.timestamp).slice(0, this.config.recentDataQueryLimit);
        for (const resource of sortedResources) {
          updatePromises.push(this.updateRecentData(entity.id, 'resource', resource));
        }
        hasUpdates = true;
      }

      // 🚀 4. 并行执行所有更新
      if (updatePromises.length > 0) {
        await Promise.allSettled(updatePromises);
        console.log(`📝 基于${relationshipNetwork.relationships.length}个关系更新了实体 ${entityName} 的最近数据缓存`);
      }
      return hasUpdates;
    } catch (error) {
      console.error(`基于关系数据更新实体 ${entity.name} 的最近数据缓存失败:`, error);
      return false;
    }
  }

  /**
   * 🔗 获取关系中相关实体的名称
   */
  getRelatedEntityName(relationship, currentEntityId) {
    const relatedEntityId = relationship.fromId === currentEntityId ? relationship.toId : relationship.fromId;

    // 从实体ID中提取可读名称（简化版）
    const namePart = relatedEntityId.split('_').slice(1).join(' ');
    return namePart || relatedEntityId;
  }

  /**
   * 🆕 更新聚合关系数据到本地存储（用于云端同步）- 简化版
   */
  async updateAggregatedRelationshipData() {
    this.ensureInitialized();
    try {
      // 🆕 获取简化的关系数据
      const backupData = await this.getSimplifiedRelationshipData();
      if (backupData) {
        // 存储简化的关系数据
        await chrome.storage.local.set({
          'cache_graph_relationships': {
            relationships: backupData.relationships,
            typeToEntities: backupData.typeToEntities,
            lastUpdated: Date.now()
            // 🚫 移除冗余的 entityToRelations
          }
        });
        console.log(`📊 更新聚合关系数据: ${backupData.relationships.length} 个关系`);
      }
    } catch (error) {
      console.error('更新聚合关系数据失败:', error);
    }
  }

  // ==================== 主题详情缓存 ====================

  // ==================== 实体格式转换辅助方法 ====================

  /**
   * 确保 CachedEntityDetail 包含所有必要字段
   */
  ensureDetailEntityFields(entity) {
    if (!entity.recentDataDetails) {
      entity.recentDataDetails = {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      };
    }
    if (!entity.relatedParticipants) entity.relatedParticipants = [];
    if (!entity.statistic) {
      entity.statistic = {
        conversations: entity.recentDataDetails.conversations.length,
        projects: entity.recentDataDetails.projects.length,
        participants: entity.relatedParticipants.length,
        resources: entity.recentDataDetails.resources.length,
        documents: entity.recentDataDetails.resources.filter(r => r.type === '文档').length,
        webpages: entity.recentDataDetails.webpages.length,
        relationships: 0,
        topics: entity.recentDataDetails.topics.length,
        jiraTickets: entity.recentDataDetails.jiraTickets.length
      };
    }
    if (!entity.cachedAt) entity.cachedAt = Date.now();
    if (!entity.lastUpdated) entity.lastUpdated = Date.now();
  }

  /**
   * 将 CachedEntityDetail 转换为基础的 MemoryEntity（用于内存存储）
   */
  convertToBaseEntity(detailEntity) {
    return {
      id: detailEntity.id,
      type: detailEntity.type,
      name: detailEntity.name,
      description: detailEntity.description,
      properties: detailEntity.properties,
      created: detailEntity.created,
      updated: detailEntity.updated,
      accessCount: detailEntity.accessCount,
      lastAccessed: detailEntity.lastAccessed,
      importance: detailEntity.importance,
      tags: detailEntity.tags,
      status: detailEntity.status,
      searchDistance: detailEntity.searchDistance,
      relevanceScore: detailEntity.relevanceScore,
      statistic: detailEntity.statistic,
      relatedData: detailEntity.relatedData
    };
  }

  /**
   * 将基础 MemoryEntity 转换为 CachedEntityDetail
   */
  convertToDetailEntity(baseEntity) {
    const detailEntity = {
      ...baseEntity,
      cachedAt: Date.now(),
      recentDataDetails: {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      },
      relatedParticipants: [],
      lastUpdated: Date.now()
    };
    this.ensureDetailEntityFields(detailEntity);
    return detailEntity;
  }

  /**
   * 检查实体是否为 CachedEntityDetail 格式
   */
  isCachedEntityDetail(entity) {
    return 'recentDataDetails' in entity && 'cachedAt' in entity;
  }

  // ==================== 统计信息缓存 ====================

  /**
   * 获取实体统计信息
   */
  async getEntityStatistics() {
    this.ensureInitialized();
    try {
      const result = await chrome.storage.local.get(CACHE_KEYS.STATISTICS);
      const cached = result[CACHE_KEYS.STATISTICS];
      if (cached && Date.now() - cached.cachedAt < this.config.statisticsCacheDuration) {
        return cached.data;
      }

      // 重新计算统计信息
      return await this.calculateStatistics();
    } catch (error) {
      console.error('获取统计信息失败:', error);
      return {
        entityCounts: {},
        totalEntities: 0,
        totalRelationships: 0,
        entitiesCreatedToday: 0,
        entitiesCreatedThisWeek: 0,
        entitiesCreatedThisMonth: 0,
        topEntitiesByType: {}
      };
    }
  }

  // ==================== 缓存管理 ====================

  /**
   * 清理过期缓存
   */
  async clearExpiredCache() {
    this.ensureInitialized();
    try {
      const now = Date.now();
      const allKeys = await this.getAllCacheKeys();
      const keysToRemove = [];
      for (const key of allKeys) {
        if (key.startsWith(CACHE_KEYS.ENTITIES)) {
          const result = await chrome.storage.local.get(key);
          const data = result[key];

          // 只清理有 cachedAt 字段的 CachedEntityDetail 实体（表示有详细缓存数据）
          if (data && data.cachedAt && this.isCachedEntityDetail(data)) {
            const age = now - data.cachedAt;
            const maxAge = this.config.recentDataCacheDuration;
            if (age > maxAge) {
              keysToRemove.push(key);
            }
          }
        }
      }
      if (keysToRemove.length > 0) {
        await chrome.storage.local.remove(keysToRemove);
        console.log(`🧹 清理了 ${keysToRemove.length} 个过期缓存项`);
      }
    } catch (error) {
      console.error('清理过期缓存失败:', error);
    }
  }

  /**
   * 获取缓存大小
   */
  async getCacheSize() {
    try {
      const result = await chrome.storage.local.getBytesInUse();
      return result;
    } catch (error) {
      console.error('获取缓存大小失败:', error);
      return 0;
    }
  }

  // ==================== 私有方法 ====================

  async loadEntitiesToMemory() {
    try {
      const entityIndex = await this.getEntityIndex();
      const entityIds = Object.keys(entityIndex);
      let loadedCount = 0;
      for (const entityId of entityIds) {
        if (loadedCount >= this.config.maxEntitiesInMemory) break;
        const result = await chrome.storage.local.get(`${CACHE_KEYS.ENTITIES}_${entityId}`);
        const entity = result[`${CACHE_KEYS.ENTITIES}_${entityId}`];
        if (entity) {
          this.memoryEntities.set(entityId, entity);
          loadedCount++;
        }
      }
      console.log(`📥 加载了 ${loadedCount} 个实体到内存`);
    } catch (error) {
      console.error('加载实体到内存失败:', error);
    }
  }
  async loadRelationshipsToMemory() {
    try {
      const relationshipIndex = await this.getRelationshipIndex();
      const allRelationshipIds = Object.values(relationshipIndex).flat();
      for (const relationshipId of allRelationshipIds) {
        const result = await chrome.storage.local.get(`${CACHE_KEYS.RELATIONSHIPS}_${relationshipId}`);
        const relationship = result[`${CACHE_KEYS.RELATIONSHIPS}_${relationshipId}`];
        if (relationship) {
          this.memoryRelationships.set(relationshipId, relationship);
        }
      }
      console.log(`📥 加载了 ${this.memoryRelationships.size} 个关系到内存`);
    } catch (error) {
      console.error('加载关系到内存失败:', error);
    }
  }
  async getEntityIndex() {
    try {
      const result = await chrome.storage.local.get(CACHE_KEYS.ENTITY_INDEX);
      return result[CACHE_KEYS.ENTITY_INDEX] || {};
    } catch (error) {
      console.error('获取实体索引失败:', error);
      return {};
    }
  }
  async getTypeIndex() {
    try {
      const result = await chrome.storage.local.get(CACHE_KEYS.TYPE_INDEX);
      return result[CACHE_KEYS.TYPE_INDEX] || {};
    } catch (error) {
      console.error('获取类型索引失败:', error);
      return {};
    }
  }
  async getRelationshipIndex() {
    try {
      const result = await chrome.storage.local.get(CACHE_KEYS.RELATIONSHIP_INDEX);
      return result[CACHE_KEYS.RELATIONSHIP_INDEX] || {};
    } catch (error) {
      console.error('获取关系索引失败:', error);
      return {};
    }
  }
  async updateEntityIndex(entity) {
    try {
      const entityIndex = await this.getEntityIndex();
      const typeIndex = await this.getTypeIndex();

      // 更新实体索引
      entityIndex[entity.id] = {
        type: entity.type,
        name: entity.name,
        lastAccessed: entity.lastAccessed,
        inMemory: this.memoryEntities.has(entity.id)
      };

      // 更新类型索引
      if (!typeIndex[entity.type]) {
        typeIndex[entity.type] = [];
      }
      if (!typeIndex[entity.type].includes(entity.id)) {
        typeIndex[entity.type].push(entity.id);
      }
      await chrome.storage.local.set({
        [CACHE_KEYS.ENTITY_INDEX]: entityIndex,
        [CACHE_KEYS.TYPE_INDEX]: typeIndex
      });
    } catch (error) {
      console.error('更新实体索引失败:', error);
    }
  }
  async updateRelationshipIndex(relationship) {
    try {
      const relationshipIndex = await this.getRelationshipIndex();

      // 为源实体和目标实体添加关系引用
      if (!relationshipIndex[relationship.fromId]) {
        relationshipIndex[relationship.fromId] = [];
      }
      if (!relationshipIndex[relationship.fromId].includes(relationship.id)) {
        relationshipIndex[relationship.fromId].push(relationship.id);
      }
      if (!relationshipIndex[relationship.toId]) {
        relationshipIndex[relationship.toId] = [];
      }
      if (!relationshipIndex[relationship.toId].includes(relationship.id)) {
        relationshipIndex[relationship.toId].push(relationship.id);
      }
      await chrome.storage.local.set({
        [CACHE_KEYS.RELATIONSHIP_INDEX]: relationshipIndex
      });
    } catch (error) {
      console.error('更新关系索引失败:', error);
    }
  }
  findLRUEntity() {
    let lruEntity = null;
    let lruTime = Date.now();
    for (const entity of Array.from(this.memoryEntities.values())) {
      if (entity.lastAccessed < lruTime) {
        lruTime = entity.lastAccessed;
        lruEntity = entity;
      }
    }
    return lruEntity;
  }
  calculateRelevanceScore(entity, searchTerm) {
    let score = 0;
    const searchLower = searchTerm.toLowerCase();

    // 名称匹配（权重最高）
    if (entity.name.toLowerCase().includes(searchLower)) {
      score += 10;
      if (entity.name.toLowerCase().startsWith(searchLower)) {
        score += 5; // 前缀匹配加分
      }
    }

    // 描述匹配
    if (entity.description?.toLowerCase().includes(searchLower)) {
      score += 3;
    }

    // 标签匹配
    entity.tags?.forEach(tag => {
      if (tag.toLowerCase().includes(searchLower)) {
        score += 2;
      }
    });

    // 重要性加权
    score *= entity.importance || 0.5;
    return score;
  }
  async traverseRelationships(entityId, remainingDepth, visited, foundEntities, foundRelationships) {
    if (remainingDepth <= 0 || visited.has(entityId)) return;
    visited.add(entityId);

    // 获取当前实体（可能不存在）
    const entity = await this.getEntity(entityId);
    if (entity) {
      foundEntities.push(entity);
    } else {
      console.warn(`关系遍历中发现缺失实体: ${entityId}`);
    }

    // 获取相关关系
    const relationshipIndex = await this.getRelationshipIndex();
    const relationshipIds = relationshipIndex[entityId] || [];
    for (const relationshipId of relationshipIds) {
      const relationship = this.memoryRelationships.get(relationshipId);
      if (relationship) {
        // 🆕 优化：区分实体-实体关系和实体-消息关系
        const isEntityMessageRelation = relationship.type === 'discovered_in';
        if (isEntityMessageRelation) {
          // 对于实体-消息关系，只验证实体端
          const entitySideId = relationship.fromId === entityId ? relationship.fromId : relationship.toId;
          const messageSideId = relationship.fromId === entityId ? relationship.toId : relationship.fromId;
          if (await this.getEntity(entitySideId)) {
            foundRelationships.push(relationship);
            console.log(`🔗 发现实体-消息关系: ${entitySideId} -> ${messageSideId.slice(0, 8)}`);
          }

          // 实体-消息关系不继续递归遍历
        } else {
          // 对于实体-实体关系，验证两端实体
          const fromEntity = await this.getEntity(relationship.fromId);
          const toEntity = await this.getEntity(relationship.toId);
          if (fromEntity || toEntity) {
            foundRelationships.push(relationship);

            // 递归遍历相关实体
            const relatedEntityId = relationship.fromId === entityId ? relationship.toId : relationship.fromId;
            if (await this.getEntity(relatedEntityId)) {
              await this.traverseRelationships(relatedEntityId, remainingDepth - 1, visited, foundEntities, foundRelationships);
            }
          }
        }
      }
    }
  }
  async calculateStatistics() {
    const now = Date.now();
    const today = new Date().toDateString();
    const thisWeek = now - 7 * 24 * 60 * 60 * 1000;
    const thisMonth = now - 30 * 24 * 60 * 60 * 1000;
    const entityCounts = {};
    let totalEntities = 0;
    let entitiesCreatedToday = 0;
    let entitiesCreatedThisWeek = 0;
    let entitiesCreatedThisMonth = 0;
    const topEntitiesByType = {};

    // 统计内存中的实体
    for (const entity of Array.from(this.memoryEntities.values())) {
      totalEntities++;
      entityCounts[entity.type] = (entityCounts[entity.type] || 0) + 1;

      // 时间统计
      const entityDate = new Date(entity.created).toDateString();
      if (entityDate === today) entitiesCreatedToday++;
      if (entity.created >= thisWeek) entitiesCreatedThisWeek++;
      if (entity.created >= thisMonth) entitiesCreatedThisMonth++;

      // 顶级实体
      if (!topEntitiesByType[entity.type]) {
        topEntitiesByType[entity.type] = [];
      }
      topEntitiesByType[entity.type].push(entity);
    }

    // 对每种类型的实体按重要性排序，取前5个
    for (const type in topEntitiesByType) {
      topEntitiesByType[type] = topEntitiesByType[type].sort((a, b) => b.importance - a.importance).slice(0, 5);
    }
    const statistics = {
      entityCounts,
      totalEntities,
      totalRelationships: this.memoryRelationships.size,
      entitiesCreatedToday,
      entitiesCreatedThisWeek,
      entitiesCreatedThisMonth,
      topEntitiesByType
    };

    // 缓存统计信息
    await chrome.storage.local.set({
      [CACHE_KEYS.STATISTICS]: {
        data: statistics,
        cachedAt: now
      }
    });
    return statistics;
  }
  async getAllCacheKeys() {
    try {
      const allKeys = await chrome.storage.local.get();
      return Object.keys(allKeys).filter(key => key.startsWith('cache_'));
    } catch (error) {
      console.error('获取所有缓存键失败:', error);
      return [];
    }
  }
  startPeriodicCleanup() {
    // 每小时清理一次过期缓存
    setInterval(() => {
      this.clearExpiredCache();
    }, 60 * 60 * 1000);
  }
  chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }
  async delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * 创建空的扩展缓存对象
   */
  createEmptyExtendedCache(entityId) {
    return {
      lastUpdated: Date.now(),
      cachedAt: Date.now(),
      // 关联数据字段
      relatedData: {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      },
      recentDataDetails: {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      },
      expertise: [],
      // 统计字段
      statistic: {
        conversations: 0,
        projects: 0,
        participants: 0,
        resources: 0,
        documents: 0,
        webpages: 0,
        relationships: 0,
        topics: 0,
        jiraTickets: 0
      }
    };
  }

  /**
   * 确保缓存数据包含所有必要的UI字段
   */
  ensureUIFields(cache) {
    // 如果缺少UI字段，重新计算
    if (!cache.statistic || !cache.recentDataDetails) {
      this.recalculateUIFields(cache);
    }
  }

  /**
   * 重新计算UI字段
   */
  recalculateUIFields(cache) {
    // 确保缓存字段存在（使用正确的字段名）
    if (!cache.recentDataDetails) {
      cache.recentDataDetails = {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      };
    }

    // 更新统计字段到 statistic 对象中
    if (!cache.statistic) {
      cache.statistic = {
        conversations: 0,
        projects: 0,
        participants: 0,
        resources: 0,
        documents: 0,
        webpages: 0,
        relationships: 0,
        topics: 0,
        jiraTickets: 0
      };
    }

    // 重新计算统计字段
    cache.statistic.conversations = cache.recentDataDetails.conversations.length;
    cache.statistic.webpages = cache.recentDataDetails.webpages.length;
    cache.statistic.resources = cache.recentDataDetails.resources.length;
    cache.statistic.projects = cache.recentDataDetails.projects.length;
    cache.statistic.topics = cache.recentDataDetails.topics.length;
    cache.statistic.jiraTickets = cache.recentDataDetails.jiraTickets.length;

    // 确保必要字段存在
    if (!cache.expertise) cache.expertise = [];
    if (!cache.lastUpdated) cache.lastUpdated = Date.now();
  }

  /**
   * 获取所有本地缓存的实体数据（用于统计信息上传）
   */
  async getAllRecentDataEntries() {
    this.ensureInitialized();
    try {
      const entityEntries = [];

      // 获取所有键，然后过滤出 ENTITIES 相关的键
      const allKeys = await this.getAllCacheKeys();
      for (const key of allKeys) {
        if (key.startsWith(CACHE_KEYS.ENTITIES + '_')) {
          try {
            const result = await chrome.storage.local.get(key);
            const data = result[key];
            if (data && this.isCachedEntityDetail(data)) {
              // 检查数据是否过期
              const now = Date.now();
              if (data.cachedAt && now - data.cachedAt < this.config.recentDataCacheDuration) {
                entityEntries.push(data);
              }
            }
          } catch (error) {
            console.error(`解析缓存数据失败 (${key}):`, error);
          }
        }
      }
      console.log(`📊 找到 ${entityEntries.length} 个本地缓存实体`);
      return entityEntries;
    } catch (error) {
      console.error('获取所有本地缓存数据失败:', error);
      return [];
    }
  }
  ensureInitialized() {
    if (!this.isInitialized) {
      throw new Error('本地缓存未初始化');
    }
  }
}
;// CONCATENATED MODULE: ./src/storage/EntitySimilarityTool.ts
/**
 * 实体相似性管理工具
 * 负责实体的相似性判断、自动合并和用户确认流程
 */

/**
 * 实体相似性管理器
 */
class EntitySimilarityTool {
  constructor() {
    this.pendingMerges = new Map();
    this.mergeCandidatesCache = new Map();
    // 相似性阈值配置
    this.THRESHOLDS = {
      AUTO_MERGE: 0.9,
      // 自动合并阈值
      CANDIDATE_MARK: 0.7,
      // 候选标记阈值
      DEEP_ANALYSIS: 0.75 // 深度分析确认阈值
    };
    this.loadPendingMerges();
  }

  /**
   * 处理新实体（主入口）
   */
  async processEntity(entity) {
    const now = Date.now();
    const fullEntity = {
      ...entity,
      id: entity.type + '_' + entity.name,
      created: now,
      updated: now,
      accessCount: 0,
      lastAccessed: now,
      importance: entity.importance || 0.5
    };

    // 进行相似性检查
    const similarityResult = await this.quickSimilarityCheck(fullEntity);
    const processedEntity = {
      ...fullEntity,
      action: similarityResult.action,
      targetId: similarityResult.targetEntity?.id,
      mergeReason: similarityResult.reasoning
    };
    return processedEntity;
  }

  /**
   * 批量处理实体
   */
  async processEntities(entities) {
    const results = [];
    for (const entity of entities) {
      try {
        const processed = await this.processEntity(entity);
        results.push(processed);
      } catch (error) {
        console.error('处理实体失败:', error);
        // 继续处理其他实体
      }
    }
    return results;
  }

  /**
   * 实时简单相似性判断
   */
  async quickSimilarityCheck(newEntity) {
    try {
      // 1. 查找候选实体
      const candidates = await this.findCandidateEntities(newEntity);
      if (candidates.length === 0) {
        return {
          action: 'create_new',
          confidence: 0
        };
      }

      // 2. 计算与每个候选的相似度
      let bestMatch = null;
      for (const candidate of candidates) {
        const similarity = this.calculateQuickSimilarity(newEntity, candidate);
        if (!bestMatch || similarity > bestMatch.similarity) {
          bestMatch = {
            entity: candidate,
            similarity
          };
        }
      }
      if (!bestMatch) {
        return {
          action: 'create_new',
          confidence: 0
        };
      }

      // 3. 根据阈值决定行动
      if (bestMatch.similarity > this.THRESHOLDS.AUTO_MERGE) {
        return {
          action: 'auto_merge',
          targetEntity: bestMatch.entity,
          confidence: bestMatch.similarity,
          reasoning: '高相似度自动合并'
        };
      } else if (bestMatch.similarity > this.THRESHOLDS.CANDIDATE_MARK) {
        return {
          action: 'mark_candidate',
          targetEntity: bestMatch.entity,
          confidence: bestMatch.similarity,
          reasoning: '中等相似度，标记为候选'
        };
      } else {
        return {
          action: 'create_new',
          confidence: bestMatch.similarity,
          reasoning: '相似度较低，创建新实体'
        };
      }
    } catch (error) {
      console.error('快速相似性检查失败:', error);
      return {
        action: 'create_new',
        confidence: 0,
        reasoning: '检查失败，创建新实体'
      };
    }
  }

  /**
   * 查找候选实体（简化版本）
   */
  async findCandidateEntities(entity) {
    // 这里是简化版本，实际实现中需要从缓存中查找相同类型的实体
    const cacheKey = `candidates_${entity.type}`;
    if (this.mergeCandidatesCache.has(cacheKey)) {
      return this.mergeCandidatesCache.get(cacheKey);
    }

    // 在实际实现中，这里应该从 LocalCache 中获取相同类型的实体
    // 暂时返回空数组
    return [];
  }

  /**
   * 计算快速相似度
   */
  calculateQuickSimilarity(entity1, entity2) {
    let similarity = 0;

    // 类型必须相同
    if (entity1.type !== entity2.type) {
      return 0;
    }

    // 名称相似度（权重50%）
    const nameSimilarity = this.stringSimilarity(entity1.name, entity2.name);
    similarity += nameSimilarity * 0.5;

    // 描述相似度（权重30%）
    if (entity1.description && entity2.description) {
      const descSimilarity = this.stringSimilarity(entity1.description, entity2.description);
      similarity += descSimilarity * 0.3;
    }

    // 属性相似度（权重20%）
    const propsSimilarity = this.propertiesSimilarity(entity1.properties, entity2.properties);
    similarity += propsSimilarity * 0.2;
    return similarity;
  }

  /**
   * 字符串相似度计算
   */
  stringSimilarity(str1, str2) {
    if (str1 === str2) return 1;
    if (!str1 || !str2) return 0;
    const longer = str1.length > str2.length ? str1 : str2;
    const shorter = str1.length > str2.length ? str2 : str1;
    if (longer.length === 0) return 1;

    // 简化的编辑距离算法
    const editDistance = this.levenshteinDistance(str1.toLowerCase(), str2.toLowerCase());
    return (longer.length - editDistance) / longer.length;
  }

  /**
   * 计算编辑距离
   */
  levenshteinDistance(str1, str2) {
    const matrix = [];
    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i];
    }
    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j;
    }
    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
        }
      }
    }
    return matrix[str2.length][str1.length];
  }

  /**
   * 属性相似度计算
   */
  propertiesSimilarity(props1, props2) {
    const keys1 = Object.keys(props1);
    const keys2 = Object.keys(props2);
    const allKeys = new Set([...keys1, ...keys2]);
    if (allKeys.size === 0) return 1;
    let matchingProps = 0;
    for (const key of allKeys) {
      const val1 = props1[key];
      const val2 = props2[key];
      if (val1 !== undefined && val2 !== undefined) {
        if (typeof val1 === 'string' && typeof val2 === 'string') {
          const similarity = this.stringSimilarity(val1, val2);
          if (similarity > 0.8) matchingProps++;
        } else if (val1 === val2) {
          matchingProps++;
        }
      }
    }
    return matchingProps / allKeys.size;
  }

  /**
   * 获取待处理的合并候选
   */
  async getPendingMerges() {
    return Array.from(this.pendingMerges.values());
  }

  /**
   * 确认合并
   */
  async confirmMerge(mergeId) {
    const mergePair = this.pendingMerges.get(mergeId);
    if (!mergePair) return false;
    try {
      mergePair.status = 'approved';
      await this.savePendingMerges();
      return true;
    } catch (error) {
      console.error('确认合并失败:', error);
      return false;
    }
  }

  /**
   * 拒绝合并
   */
  async rejectMerge(mergeId) {
    const mergePair = this.pendingMerges.get(mergeId);
    if (!mergePair) return false;
    try {
      mergePair.status = 'rejected';
      this.pendingMerges.delete(mergeId);
      await this.savePendingMerges();
      return true;
    } catch (error) {
      console.error('拒绝合并失败:', error);
      return false;
    }
  }

  /**
   * 保存待处理合并到存储
   */
  async savePendingMerges() {
    try {
      const data = Array.from(this.pendingMerges.entries());
      await chrome.storage.local.set({
        'pending_entity_merges': data
      });
    } catch (error) {
      console.error('保存待处理合并失败:', error);
    }
  }

  /**
   * 从存储加载待处理合并
   */
  async loadPendingMerges() {
    try {
      const result = await chrome.storage.local.get('pending_entity_merges');
      if (result.pending_entity_merges) {
        this.pendingMerges = new Map(result.pending_entity_merges);
      }
    } catch (error) {
      console.error('加载待处理合并失败:', error);
    }
  }

  /**
   * 调整阈值
   */
  adjustThresholds(newThresholds) {
    Object.assign(this.THRESHOLDS, newThresholds);
  }

  /**
   * 获取统计信息
   */
  getStatistics() {
    return {
      pendingMerges: this.pendingMerges.size,
      thresholds: {
        ...this.THRESHOLDS
      }
    };
  }
}

// 导出单例实例
const entitySimilarityTool = new EntitySimilarityTool();
;// CONCATENATED MODULE: ./src/storage/SystemMaintenanceTool.ts
/**
 * 系统维护工具
 * 负责健康监控、定时维护、数据清理等任务
 */

// 策略层接口定义（用于与 MemorySystem 交互）

/**
 * 系统维护工具
 */
class SystemMaintenanceTool {
  // 实体数量阈值

  constructor(cloudStorage, localStorage, strategyLayer) {
    this.isMonitoringActive = false;
    this.monitoringInterval = null;
    this.maintenanceInterval = null;
    this.MONITORING_INTERVAL = 5 * 60 * 1000;
    // 5分钟
    this.MAINTENANCE_INTERVAL = 6 * 60 * 60 * 1000;
    // 6小时
    this.CACHE_CLEANUP_THRESHOLD = 1000;
    this.cloudStorage = cloudStorage;
    this.localStorage = localStorage;
    this.strategyLayer = strategyLayer;
  }

  /**
   * 启动系统监控
   */
  startMonitoring() {
    if (this.isMonitoringActive) {
      console.log('⚠️ 系统监控已经在运行');
      return;
    }
    this.isMonitoringActive = true;

    // 启动健康监控
    this.monitoringInterval = setInterval(async () => {
      try {
        await this.performHealthCheck();
      } catch (error) {
        console.error('健康检查失败:', error);
      }
    }, this.MONITORING_INTERVAL);

    // 启动定期维护
    this.maintenanceInterval = setInterval(async () => {
      try {
        await this.performAutomaticMaintenance();
      } catch (error) {
        console.error('自动维护失败:', error);
      }
    }, this.MAINTENANCE_INTERVAL);
    console.log('🔍 系统监控已启动');
  }

  /**
   * 停止系统监控
   */
  stopMonitoring() {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
    if (this.maintenanceInterval) {
      clearInterval(this.maintenanceInterval);
      this.maintenanceInterval = null;
    }
    this.isMonitoringActive = false;
    console.log('🔍 系统监控已停止');
  }

  /**
   * 执行健康检查
   */
  async performHealthCheck() {
    const startTime = Date.now();
    const status = {
      timestamp: startTime,
      cloudStorage: {
        available: false,
        connected: false,
        entityCount: 0,
        lastSync: 0,
        errors: []
      },
      localCache: {
        available: false,
        entityCount: 0,
        relationshipCount: 0,
        cacheSize: 0,
        lastCleanup: 0,
        errors: []
      },
      overall: {
        status: 'offline',
        score: 0,
        issues: [],
        recommendations: []
      }
    };
    try {
      // 1. 检查云端存储
      await this.checkCloudStorageHealth(status);

      // 2. 检查本地缓存
      await this.checkLocalCacheHealth(status);

      // 3. 计算整体健康状态
      this.calculateOverallHealth(status);

      // 4. 生成建议
      this.generateRecommendations(status);

      // 5. 保存健康记录
      await this.saveHealthMetrics(status);
      console.log(`🏥 健康检查完成 - 状态: ${status.overall.status}, 评分: ${status.overall.score}`);
      return status;
    } catch (error) {
      console.error('❌ 健康检查失败:', error);
      status.overall.status = 'critical';
      status.overall.issues.push(`健康检查失败: ${error.message}`);
      return status;
    }
  }

  /**
   * 检查云端存储健康状态
   */
  async checkCloudStorageHealth(status) {
    try {
      status.cloudStorage.available = true;
      status.cloudStorage.connected = await this.cloudStorage.isConnected();
      if (status.cloudStorage.connected) {
        status.cloudStorage.entityCount = await this.cloudStorage.getEntityCount();
        status.cloudStorage.lastSync = await this.strategyLayer.getLastSyncTime();
      } else {
        status.cloudStorage.errors.push('云端存储连接失败');
      }
    } catch (error) {
      status.cloudStorage.errors.push(`云端存储检查失败: ${error.message}`);
    }
  }

  /**
   * 检查本地缓存健康状态
   */
  async checkLocalCacheHealth(status) {
    try {
      status.localCache.available = true;
      status.localCache.cacheSize = await this.localStorage.getCacheSize();

      // 获取实体统计
      const entityStats = await this.localStorage.getEntityStatistics();
      status.localCache.entityCount = entityStats.totalEntities;
      status.localCache.relationshipCount = entityStats.totalRelationships;

      // 检查缓存大小
      if (status.localCache.cacheSize > 4 * 1024 * 1024) {
        // 4MB
        status.localCache.errors.push('本地缓存大小超过4MB，建议清理');
      }

      // 检查实体数量
      if (status.localCache.entityCount > this.CACHE_CLEANUP_THRESHOLD) {
        status.localCache.errors.push(`实体数量过多(${status.localCache.entityCount})，建议清理`);
      }
    } catch (error) {
      status.localCache.errors.push(`本地缓存检查失败: ${error.message}`);
    }
  }

  /**
   * 计算整体健康状态
   */
  calculateOverallHealth(status) {
    let score = 100;
    const issues = [];

    // 云端存储健康度检查
    if (!status.cloudStorage.connected) {
      score -= 30;
      issues.push('云端存储连接异常');
    }

    // 本地缓存健康度检查
    if (status.localCache.errors.length > 0) {
      score -= 20;
      issues.push('本地缓存存在问题');
    }

    // 同步状态检查
    const lastSyncAge = Date.now() - status.cloudStorage.lastSync;
    if (lastSyncAge > 24 * 60 * 60 * 1000) {
      // 超过24小时
      score -= 25;
      issues.push('超过24小时未同步');
    }

    // 缓存大小检查
    if (status.localCache.cacheSize > 3 * 1024 * 1024) {
      // 3MB
      score -= 15;
      issues.push('本地缓存占用空间过大');
    }

    // 确定状态
    if (score >= 90) {
      status.overall.status = 'healthy';
    } else if (score >= 70) {
      status.overall.status = 'warning';
    } else if (score >= 40) {
      status.overall.status = 'critical';
    } else {
      status.overall.status = 'offline';
    }
    status.overall.score = Math.max(0, score);
    status.overall.issues = issues;
  }

  /**
   * 生成维护建议
   */
  generateRecommendations(status) {
    const recommendations = [];
    if (!status.cloudStorage.connected) {
      recommendations.push('检查网络连接，重新连接云端存储');
    }
    if (status.localCache.cacheSize > 3 * 1024 * 1024) {
      recommendations.push('执行缓存清理，释放本地存储空间');
    }
    if (status.localCache.entityCount > this.CACHE_CLEANUP_THRESHOLD) {
      recommendations.push('清理旧实体数据，保持缓存效率');
    }
    const lastSyncAge = Date.now() - status.cloudStorage.lastSync;
    if (lastSyncAge > 12 * 60 * 60 * 1000) {
      // 超过12小时
      recommendations.push('执行数据同步，保持数据一致性');
    }
    if (status.localCache.relationshipCount > 500) {
      recommendations.push('备份关系数据到云端，防止数据丢失');
    }
    status.overall.recommendations = recommendations;
  }

  /**
   * 执行自动维护
   */
  async performAutomaticMaintenance() {
    const startTime = Date.now();
    const result = {
      success: false,
      tasksCompleted: [],
      tasksFailed: [],
      cleanedEntities: 0,
      cleanedRelationships: 0,
      freedSpace: 0,
      totalTime: 0,
      nextMaintenanceTime: Date.now() + this.MAINTENANCE_INTERVAL
    };
    try {
      console.log('🔧 开始自动维护...');

      // 1. 清理过期缓存
      try {
        await this.localStorage.clearExpiredCache();
        result.tasksCompleted.push('清理过期缓存');
      } catch (error) {
        result.tasksFailed.push('清理过期缓存失败');
      }

      // 2. 检查并执行新设备同步
      try {
        const syncResult = await this.strategyLayer.performInitialSyncIfNeeded();
        if (syncResult.syncPerformed) {
          result.tasksCompleted.push(`新设备同步: ${syncResult.entitiesDownloaded} 个实体`);
        }
      } catch (error) {
        result.tasksFailed.push('新设备同步检查失败');
      }

      // 3. 备份关系数据（每天一次）
      try {
        const lastBackup = await this.getLastBackupTime();
        if (Date.now() - lastBackup > 24 * 60 * 60 * 1000) {
          const relationshipData = await this.localStorage.getRelationshipBackupData();
          if (relationshipData) {
            const backupSuccess = await this.cloudStorage.backupRelationships(relationshipData);
            if (backupSuccess) {
              result.tasksCompleted.push('备份关系数据');
              await this.setLastBackupTime(Date.now());
            } else {
              result.tasksFailed.push('备份关系数据失败');
            }
          }
        }
      } catch (error) {
        result.tasksFailed.push('关系数据备份失败');
      }

      // 4. 计算释放的空间
      const finalCacheSize = await this.localStorage.getCacheSize();
      result.freedSpace = Math.max(0, finalCacheSize);
      result.success = result.tasksFailed.length === 0;
      result.totalTime = Date.now() - startTime;
      console.log(`🔧 自动维护完成 - 成功: ${result.tasksCompleted.length}, 失败: ${result.tasksFailed.length}`);
      return result;
    } catch (error) {
      console.error('❌ 自动维护失败:', error);
      result.tasksFailed.push(`维护过程异常: ${error.message}`);
      result.totalTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 手动执行完整维护
   */
  async performFullMaintenance(options) {
    const startTime = Date.now();
    const opts = {
      cleanupEntities: true,
      cleanupRelationships: true,
      forceSync: false,
      backupData: true,
      ...options
    };
    const result = {
      success: false,
      tasksCompleted: [],
      tasksFailed: [],
      cleanedEntities: 0,
      cleanedRelationships: 0,
      freedSpace: 0,
      totalTime: 0,
      nextMaintenanceTime: Date.now() + this.MAINTENANCE_INTERVAL
    };
    try {
      console.log('🔧 开始完整维护...');
      const initialCacheSize = await this.localStorage.getCacheSize();

      // 1. 清理过期缓存
      try {
        await this.localStorage.clearExpiredCache();
        result.tasksCompleted.push('清理过期缓存');
      } catch (error) {
        result.tasksFailed.push('清理过期缓存失败');
      }

      // 2. 强制同步（如果请求）
      if (opts.forceSync) {
        try {
          await this.strategyLayer.syncCache();
          result.tasksCompleted.push('强制同步缓存');
        } catch (error) {
          result.tasksFailed.push('强制同步失败');
        }
      }

      // 3. 备份数据（如果请求）
      if (opts.backupData) {
        try {
          const relationshipData = await this.localStorage.getRelationshipBackupData();
          if (relationshipData) {
            const backupSuccess = await this.cloudStorage.backupRelationships(relationshipData);
            if (backupSuccess) {
              result.tasksCompleted.push('备份关系数据');
            } else {
              result.tasksFailed.push('备份关系数据失败');
            }
          }
        } catch (error) {
          result.tasksFailed.push('数据备份失败');
        }
      }

      // 4. 计算释放的空间
      const finalCacheSize = await this.localStorage.getCacheSize();
      result.freedSpace = initialCacheSize - finalCacheSize;
      result.success = result.tasksFailed.length === 0;
      result.totalTime = Date.now() - startTime;
      console.log(`🔧 完整维护完成 - 成功: ${result.tasksCompleted.length}, 失败: ${result.tasksFailed.length}`);
      return result;
    } catch (error) {
      console.error('❌ 完整维护失败:', error);
      result.tasksFailed.push(`维护过程异常: ${error.message}`);
      result.totalTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 保存健康指标
   */
  async saveHealthMetrics(status) {
    try {
      await chrome.storage.local.set({
        'system_health_status': status,
        'system_health_timestamp': status.timestamp
      });
    } catch (error) {
      console.error('保存健康指标失败:', error);
    }
  }

  /**
   * 获取最后备份时间
   */
  async getLastBackupTime() {
    try {
      const result = await chrome.storage.local.get('last_backup_time');
      return result.last_backup_time || 0;
    } catch (error) {
      return 0;
    }
  }

  /**
   * 设置最后备份时间
   */
  async setLastBackupTime(time) {
    try {
      await chrome.storage.local.set({
        'last_backup_time': time
      });
    } catch (error) {
      console.error('设置备份时间失败:', error);
    }
  }

  /**
   * 获取系统状态
   */
  getSystemStatus() {
    return {
      isMonitoring: this.isMonitoringActive,
      monitoringInterval: this.MONITORING_INTERVAL,
      maintenanceInterval: this.MAINTENANCE_INTERVAL,
      nextMaintenance: Date.now() + this.MAINTENANCE_INTERVAL
    };
  }
}

// 创建工厂函数
function createSystemMaintenanceTool(cloudStorage, localStorage, strategyLayer) {
  return new SystemMaintenanceTool(cloudStorage, localStorage, strategyLayer);
}
;// CONCATENATED MODULE: ./src/services/UserProfileManager.ts
/**
 * 用户画像管理器
 * 负责分散式向量存储的用户画像管理
 */


class UserProfileManager {
  // 5分钟缓存过期

  constructor(userId, cloudStorage) {
    this.displayName = '';
    this.recordsCache = new Map();
    this.lastCacheUpdate = 0;
    this.cacheExpiryTime = 5 * 60 * 1000;
    this.userId = userId || 'default_user'; // 临时默认值，将在initialize中更新
    this.cloudStorage = cloudStorage || new CloudStorage();
  }

  /**
   * 初始化管理器
   */
  async initialize() {
    try {
      // 获取真实的用户信息
      await this.loadUserInfo();

      // 确保CloudStorage已连接
      if (!(await this.cloudStorage.isConnected())) {
        await this.cloudStorage.initialize();
      }

      // 初始化缓存
      await this.refreshCache();
      console.log(`✅ 用户画像管理器初始化成功: ${this.userId} (${this.displayName})`);
      return true;
    } catch (error) {
      console.error('用户画像管理器初始化失败:', error);
      return false;
    }
  }

  /**
   * 从localStorage加载用户信息
   */
  async loadUserInfo() {
    try {
      const result = await chrome.storage.local.get(['userinfo']);
      const userinfo = result.userinfo;
      if (userinfo) {
        // 使用username作为userId，fullName作为显示名
        this.userId = userinfo.username || userinfo.extensionId || 'default_user';
        this.displayName = userinfo.fullName || userinfo.username || 'Unknown User';
        console.log(`📝 用户信息加载成功: ${this.userId} (${this.displayName})`);
      } else {
        console.warn('⚠️ 未找到用户信息，使用默认值');
        this.userId = 'default_user';
        this.displayName = 'Default User';
      }
    } catch (error) {
      console.error('获取用户信息失败:', error);
      // 保持默认值
      this.userId = 'default_user';
      this.displayName = 'Default User';
    }
  }

  /**
   * 更新用户画像（兼容旧接口）
   */
  async updateProfile(update) {
    try {
      // 1. 更新兴趣项
      const interestSuccess = await this.updateInterestItem(update);
      if (!interestSuccess) {
        console.warn(`Failed to update interest item for ${update.targetItem.name}`);
      }

      // 2. 更新行为模式
      await this.updateBehaviorPattern({
        userId: update.userId,
        actionType: update.action.actionType,
        timestamp: update.action.timestamp,
        context: update.action.context || '',
        targetType: update.targetItem.type,
        targetId: update.targetItem.id
      });

      // 3. 更新统计数据（通过行为记录自动统计）
      await this.updateUserStatistics(update.action);

      // 4. 重新计算衍生偏好（基于最新的向量化数据）
      await this.recalculateDerivedPreferences();
      console.log(`✅ Profile updated successfully for ${update.targetItem.name}`);
    } catch (error) {
      console.error('Failed to update profile:', error);
      throw new Error(`Failed to update profile for ${update.targetItem.name}: ${error.message}`);
    }
  }

  /**
   * 更新用户统计数据
   */
  async updateUserStatistics(action) {
    try {
      const statsRecordId = `${this.userId}_user_summary_statistics`;

      // 查找现有统计记录
      let existingStats = this.recordsCache.get(statsRecordId);
      if (!existingStats) {
        // 尝试从云端获取
        const queryResult = await this.cloudStorage.searchByVector('user statistics', undefined, {
          collections: ['userprofiles'],
          returnType: 'userprofiles',
          where: {
            user_id: this.userId,
            record_type: {
              $in: ['user_summary']
            },
            summary_type: 'statistics'
          },
          limit: 1
        });
        if (queryResult.data.length > 0) {
          existingStats = queryResult.data[0];
          this.recordsCache.set(statsRecordId, existingStats);
        }
      }
      if (!existingStats) {
        // 创建新的统计记录
        existingStats = {
          id: statsRecordId,
          document: `用户 ${this.userId} 的统计数据汇总`,
          metadata: {
            record_type: 'user_summary',
            user_id: this.userId,
            created_at: Date.now(),
            updated_at: Date.now(),
            summary_type: 'statistics',
            total_interactions: 1,
            daily_activity_average: 1,
            most_active_day: new Date().toISOString().split('T')[0],
            top_interaction_types: {
              [action.actionType]: 1
            },
            last_activity: action.timestamp
          }
        };
      } else {
        // 更新统计数据
        const metadata = existingStats.metadata;
        metadata.total_interactions = (metadata.total_interactions || 0) + 1;
        metadata.updated_at = Date.now();
        metadata.last_activity = action.timestamp;

        // 更新交互类型统计
        const topTypes = metadata.top_interaction_types || {};
        topTypes[action.actionType] = (topTypes[action.actionType] || 0) + 1;
        metadata.top_interaction_types = topTypes;

        // 计算日平均活动
        const daysSinceCreated = Math.max(1, Math.floor((Date.now() - metadata.created_at) / (24 * 60 * 60 * 1000)));
        metadata.daily_activity_average = metadata.total_interactions / daysSinceCreated;

        // 更新文档描述
        existingStats.document = `用户 ${this.userId} 的统计数据汇总：总交互${metadata.total_interactions}次，日均活动${metadata.daily_activity_average.toFixed(1)}次`;
      }

      // 存储更新后的统计记录
      await this.cloudStorage.storeUserprofilesRecord(existingStats);
      this.recordsCache.set(statsRecordId, existingStats);
    } catch (error) {
      console.error('Failed to update user statistics:', error);
    }
  }

  /**
   * 重新计算衍生偏好
   */
  async recalculateDerivedPreferences() {
    try {
      const preferencesRecordId = `${this.userId}_user_summary_preferences`;

      // 获取用户的所有兴趣项记录
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item' && record.metadata.user_id === this.userId);
      if (interestRecords.length === 0) return;

      // 分析偏好项目类型
      const projectTypes = new Map();
      const expertiseAreas = new Map();
      const collaborators = new Map();
      interestRecords.forEach(record => {
        const metadata = record.metadata;

        // 统计项目类型偏好
        if (metadata.interest_category === 'project' && metadata.project_type) {
          projectTypes.set(metadata.project_type, (projectTypes.get(metadata.project_type) || 0) + metadata.current_weight);
        }

        // 统计专业领域
        if (metadata.interest_category === 'technology' && metadata.technology_stack) {
          metadata.technology_stack.forEach(tech => {
            expertiseAreas.set(tech, (expertiseAreas.get(tech) || 0) + metadata.current_weight);
          });
        }

        // 统计协作者
        if (metadata.interest_category === 'person') {
          collaborators.set(metadata.name, (collaborators.get(metadata.name) || 0) + metadata.current_weight);
        }
      });

      // 生成偏好记录
      const preferencesRecord = {
        id: preferencesRecordId,
        document: `用户 ${this.userId} 的衍生偏好分析：` + `偏好项目类型${Array.from(projectTypes.keys()).slice(0, 3).join('、')}，` + `专业领域包括${Array.from(expertiseAreas.keys()).slice(0, 5).join('、')}，` + `主要协作者有${Array.from(collaborators.keys()).slice(0, 3).join('、')}`,
        metadata: {
          record_type: 'user_summary',
          user_id: this.userId,
          created_at: this.recordsCache.get(preferencesRecordId)?.metadata.created_at || Date.now(),
          updated_at: Date.now(),
          summary_type: 'derived_preferences',
          preferred_project_types: Array.from(projectTypes.entries()).sort((a, b) => b[1] - a[1]).slice(0, 5).map(_ref => {
            let [type] = _ref;
            return type;
          }),
          expertise_areas: Array.from(expertiseAreas.entries()).sort((a, b) => b[1] - a[1]).slice(0, 10).map(_ref2 => {
            let [area] = _ref2;
            return area;
          }),
          key_collaborators: Array.from(collaborators.entries()).sort((a, b) => b[1] - a[1]).slice(0, 10).map(_ref3 => {
            let [name] = _ref3;
            return name;
          }),
          risk_sensitivity: this.calculateRiskSensitivity(interestRecords),
          update_frequency: this.calculateUpdateFrequency(interestRecords)
        }
      };

      // 存储偏好记录
      await this.cloudStorage.storeUserprofilesRecord(preferencesRecord);
      this.recordsCache.set(preferencesRecordId, preferencesRecord);
    } catch (error) {
      console.error('Failed to recalculate derived preferences:', error);
    }
  }

  /**
   * 计算风险敏感度
   */
  calculateRiskSensitivity(interestRecords) {
    const totalWeight = interestRecords.reduce((sum, record) => sum + record.metadata.current_weight, 0);
    const diversityScore = new Set(interestRecords.map(r => r.metadata.interest_category)).size;
    if (diversityScore >= 4 && totalWeight > 5) return 'low';
    if (diversityScore >= 2 && totalWeight > 3) return 'medium';
    return 'high';
  }

  /**
   * 计算更新频率模式
   */
  calculateUpdateFrequency(interestRecords) {
    const now = Date.now();
    const recentUpdates = interestRecords.filter(record => now - record.metadata.last_accessed < 7 * 24 * 60 * 60 * 1000).length;
    if (recentUpdates >= 10) return 'daily';
    if (recentUpdates >= 3) return 'weekly';
    return 'monthly';
  }

  /**
   * 更新兴趣项
   */
  async updateInterestItem(update) {
    try {
      const {
        targetItem,
        action
      } = update;
      const recordId = `${this.userId}_interest_${targetItem.type}_${this.sanitizeId(targetItem.id)}`;

      // 查找现有记录
      let existingRecord = this.recordsCache.get(recordId);
      if (!existingRecord) {
        // 尝试从云端获取
        const queryResult = await this.cloudStorage.queryUserprofiles({
          user_id: this.userId,
          record_types: ['interest_item'],
          metadata_filters: {
            name: targetItem.name,
            interest_category: targetItem.type
          }
        });
        if (queryResult.records.length > 0) {
          existingRecord = queryResult.records[0];
          this.recordsCache.set(recordId, existingRecord);
        }
      }
      if (existingRecord) {
        // 更新现有记录
        await this.updateExistingInterestRecord(existingRecord, action);
      } else {
        // 创建新记录
        await this.createNewInterestRecord(recordId, targetItem, action);
      }
      return true;
    } catch (error) {
      console.error('更新兴趣项失败:', error);
      return false;
    }
  }

  /**
   * 更新行为模式
   */
  async updateBehaviorPattern(data) {
    try {
      const recordId = `${this.userId}_behavior_pattern_${data.actionType}_${Date.now()}`;

      // 创建行为模式记录
      const behaviorRecord = {
        id: recordId,
        document: this.generateBehaviorPatternDocument(data),
        metadata: {
          record_type: 'behavior_pattern',
          user_id: this.userId,
          created_at: data.timestamp,
          updated_at: data.timestamp,
          pattern_type: this.getPatternType(data.actionType),
          // 根据行为类型设置相应的元数据
          ...this.getBehaviorSpecificMetadata(data)
        }
      };

      // 存储记录
      await this.cloudStorage.storeUserprofilesRecord(behaviorRecord);
      this.recordsCache.set(recordId, behaviorRecord);
      return true;
    } catch (error) {
      console.error('更新行为模式失败:', error);
      return false;
    }
  }

  /**
   * 查询兴趣项
   */
  async queryInterestItems() {
    let options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    try {
      const {
        category,
        searchQuery = '',
        limit = 20,
        sortBy = 'weight'
      } = options;

      // 构建查询选项
      const queryOptions = {
        user_id: this.userId,
        record_types: ['interest_item'],
        limit
      };
      if (category) {
        queryOptions.metadata_filters = {
          interest_category: category
        };
      }

      // 执行查询
      const result = await this.cloudStorage.searchByVector(searchQuery, undefined, {
        collections: ['userprofiles'],
        returnType: 'userprofiles',
        where: queryOptions.metadata_filters || {},
        limit: queryOptions.limit || 20
      });

      // 类型转换和排序
      const interestRecords = result.data;
      return this.sortInterestItems(interestRecords, sortBy);
    } catch (error) {
      console.error('查询兴趣项失败:', error);
      return [];
    }
  }

  /**
   * 查找相似用户
   */
  async findSimilarUsers() {
    let options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    try {
      const {
        limit = 10,
        similarityThreshold = 0.3
      } = options;

      // 获取用户的主要兴趣描述
      const userInterests = await this.queryInterestItems({
        limit: 10,
        sortBy: 'weight'
      });
      const queryText = userInterests.map(item => item.document).join(' ');
      if (!queryText.trim()) {
        return [];
      }

      // 查找相似用户
      return await this.cloudStorage.findSimilarUsers(this.userId, queryText, {
        record_types: ['interest_item'],
        limit,
        similarity_threshold: similarityThreshold
      });
    } catch (error) {
      console.error('查找相似用户失败:', error);
      return [];
    }
  }

  /**
   * 根据行为模式查找用户
   */
  async findUsersByBehaviorPattern(patternType) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    // 占位符实现，后续可扩展
    return [];
  }

  /**
   * 查找话题相关兴趣
   */
  async findTopicRelatedInterests(topic) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    try {
      const {
        limit = 10
      } = options;
      const result = await this.cloudStorage.searchByVector(topic, undefined, {
        collections: ['userprofiles'],
        returnType: 'userprofiles',
        where: {
          user_id: this.userId,
          record_type: {
            $in: ['interest_item']
          }
        },
        limit
      });
      return result.data;
    } catch (error) {
      console.error('查找话题相关兴趣失败:', error);
      return [];
    }
  }

  /**
   * 生成用户画像分析
   */
  async generateAnalysis() {
    try {
      await this.refreshCacheIfNeeded();
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item');
      const behaviorRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'behavior_pattern');
      const topItemsByCategory = this.getTopItemsByCategory(interestRecords);
      const behaviorAnalysis = this.analyzeBehaviorPatterns(behaviorRecords);
      return {
        userId: this.userId,
        timestamp: Date.now(),
        // 当前最关注的内容
        topInterests: {
          projects: topItemsByCategory.project?.map(item => item.name) || [],
          people: topItemsByCategory.person?.map(item => item.name) || [],
          topics: topItemsByCategory.topic?.map(item => item.name) || []
        },
        // 预测的兴趣
        predictedInterests: this.predictInterests(interestRecords),
        // 行为洞察
        insights: {
          workingPattern: behaviorAnalysis.activeHours?.length > 0 ? `主要活跃时间：${behaviorAnalysis.activeHours.join('、')}点` : '暂无数据',
          collaborationStyle: behaviorAnalysis.communicationStyle || 'semi-formal',
          focusAreas: topItemsByCategory.technology?.map(item => item.name) || [],
          suggestedContent: this.generateContentSuggestions(interestRecords)
        }
      };
    } catch (error) {
      console.error('生成用户画像分析失败:', error);
      throw error;
    }
  }

  /**
   * 获取画像统计信息
   */
  async getProfileStats() {
    try {
      await this.refreshCacheIfNeeded();
      const records = Array.from(this.recordsCache.values());
      const recordsByType = {};
      let lastActivity = 0;
      records.forEach(record => {
        const type = record.metadata.record_type;
        recordsByType[type] = (recordsByType[type] || 0) + 1;
        if (record.metadata.last_accessed && record.metadata.last_accessed > lastActivity) {
          lastActivity = record.metadata.last_accessed;
        }
      });

      // 简单的健康度计算
      const healthScore = Math.min(records.length / 50, 1); // 假设50个记录为满分

      return {
        totalRecords: records.length,
        recordsByType,
        lastActivity,
        healthScore
      };
    } catch (error) {
      console.error('获取画像统计失败:', error);
      return {
        totalRecords: 0,
        recordsByType: {},
        lastActivity: 0,
        healthScore: 0
      };
    }
  }

  /**
   * 刷新缓存
   */
  async refreshCache() {
    try {
      const result = await this.cloudStorage.queryUserprofiles({
        user_id: this.userId,
        limit: 1000 // 获取用户的所有记录
      });
      this.recordsCache.clear();
      result.records.forEach(record => {
        this.recordsCache.set(record.id, record);
      });
      this.lastCacheUpdate = Date.now();
      console.log(`缓存已刷新，加载了 ${result.records.length} 条记录`);
    } catch (error) {
      console.error('刷新缓存失败:', error);
    }
  }

  /**
   * 按需刷新缓存
   */
  async refreshCacheIfNeeded() {
    if (Date.now() - this.lastCacheUpdate > this.cacheExpiryTime) {
      await this.refreshCache();
    }
  }

  // =================== 以下为兼容旧接口的方法 ===================

  /**
   * 获取用户画像（向后兼容）
   */
  async getProfile() {
    try {
      await this.refreshCacheIfNeeded();
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item');
      const behaviorRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'behavior_pattern');
      const summaryRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'user_summary');
      if (interestRecords.length === 0) {
        return null;
      }

      // 重构用户画像对象
      return {
        userId: this.userId,
        createdAt: Math.min(...interestRecords.map(r => r.metadata.created_at)),
        lastUpdated: Math.max(...interestRecords.map(r => r.metadata.updated_at)),
        interests: this.reconstructInterestItems(interestRecords),
        behaviorPatterns: this.reconstructBehaviorPatterns(behaviorRecords),
        derivedPreferences: this.reconstructDerivedPreferences(summaryRecords),
        statistics: this.calculateStatistics(interestRecords, summaryRecords)
      };
    } catch (error) {
      console.error('获取用户画像失败:', error);
      return null;
    }
  }

  /**
   * 设置明确重要性
   */
  async setExplicitImportance(itemId, type, importance) {
    try {
      const recordId = `${this.userId}_interest_${type}_${this.sanitizeId(itemId)}`;
      const record = this.recordsCache.get(recordId);
      if (record) {
        record.metadata.explicit_importance = importance;
        record.metadata.updated_at = Date.now();
        await this.cloudStorage.storeUserprofilesRecord(record);
        return true;
      }
      return false;
    } catch (error) {
      console.error('设置明确重要性失败:', error);
      return false;
    }
  }

  /**
   * 应用权重衰减
   */
  async applyWeightDecay() {
    try {
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item');
      const now = Date.now();
      const oneDay = 24 * 60 * 60 * 1000;
      for (const record of interestRecords) {
        const daysSinceLastAccess = (now - (record.metadata.last_accessed || record.metadata.created_at)) / oneDay;

        // 简单的衰减公式
        const decayFactor = Math.exp(-daysSinceLastAccess / 30); // 30天为衰减周期
        record.metadata.current_weight *= decayFactor;
        record.metadata.updated_at = now;
        await this.cloudStorage.storeUserprofilesRecord(record);
      }
      console.log(`权重衰减应用完成，更新了 ${interestRecords.length} 条记录`);
    } catch (error) {
      console.error('应用权重衰减失败:', error);
    }
  }

  /**
   * 融合用户上下文配置
   */
  async fuseUserContextConfig(userContextConfig) {
    try {
      const configRecordId = `${this.userId}_user_summary_context_config`;
      const configRecord = {
        id: configRecordId,
        document: `用户 ${this.userId} 的上下文配置：${JSON.stringify(userContextConfig)}`,
        metadata: {
          record_type: 'user_summary',
          user_id: this.userId,
          created_at: Date.now(),
          updated_at: Date.now(),
          summary_type: 'user_context_config',
          user_context_config: userContextConfig
        }
      };
      await this.cloudStorage.storeUserprofilesRecord(configRecord);
      this.recordsCache.set(configRecordId, configRecord);
      return true;
    } catch (error) {
      console.error('融合用户上下文配置失败:', error);
      return false;
    }
  }

  /**
   * 自适应权重调整
   */
  async adaptiveWeightAdjustment() {
    try {
      // 这是一个简化的实现，真实场景下会更复杂
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item');

      // 基于访问频率调整权重
      for (const record of interestRecords) {
        const accessFrequency = record.metadata.access_count / Math.max(1, (Date.now() - record.metadata.first_seen) / (24 * 60 * 60 * 1000));

        // 高频访问的项目增加权重
        if (accessFrequency > 1) {
          record.metadata.current_weight = Math.min(1, record.metadata.current_weight * 1.1);
        }
        record.metadata.updated_at = Date.now();
        await this.cloudStorage.storeUserprofilesRecord(record);
      }
    } catch (error) {
      console.error('自适应权重调整失败:', error);
    }
  }

  /**
   * 生成主动推荐
   */
  async generateProactiveRecommendations() {
    try {
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item');

      // 简化的推荐算法
      const recommendations = [];

      // 基于技术栈推荐相关技术
      const techItems = interestRecords.filter(r => r.metadata.interest_category === 'technology');
      const topTech = techItems.sort((a, b) => b.metadata.current_weight - a.metadata.current_weight)[0];
      if (topTech) {
        recommendations.push({
          id: `tech_learning_${topTech.metadata.name}`,
          type: 'learning',
          title: `${topTech.metadata.name} 高级特性`,
          description: `学习更多关于 ${topTech.metadata.name} 的高级用法和最佳实践`,
          reason: `基于您对 ${topTech.metadata.name} 的高度关注`,
          confidence: 0.8,
          priority: 'medium'
        });
      }
      return recommendations.slice(0, 5);
    } catch (error) {
      console.error('生成主动推荐失败:', error);
      return [];
    }
  }

  /**
   * 融合兴趣项权重
   */
  getFusedInterestItems(items) {
    return items.map(item => {
      const explicitWeight = item.explicitImportance || 0;
      const implicitWeight = item.currentWeight || item.weight || 0;

      // 融合公式：明确重要性占40%，隐式权重占60%
      const fusedWeight = explicitWeight * 0.4 + implicitWeight * 0.6;
      return {
        ...item,
        weight: fusedWeight,
        currentWeight: fusedWeight
      };
    });
  }

  // =================== 私有辅助方法 ===================

  /**
   * 更新现有兴趣记录
   */
  async updateExistingInterestRecord(record, action) {
    const metadata = record.metadata;

    // 更新访问统计
    metadata.access_count += 1;
    metadata.last_accessed = action.timestamp;
    metadata.updated_at = action.timestamp;

    // 更新权重
    const actionWeight = this.getActionWeight(action.actionType);
    metadata.current_weight = Math.min(1, metadata.current_weight + actionWeight * 0.1);

    // 更新最近行为
    if (!metadata.recent_action_types.includes(action.actionType)) {
      metadata.recent_action_types.push(action.actionType);
      // 保持最近5种行为类型
      if (metadata.recent_action_types.length > 5) {
        metadata.recent_action_types.shift();
      }
    }

    // 更新交互模式
    metadata.interaction_patterns.view_frequency += action.actionType === 'view' ? 1 : 0;
    metadata.interaction_patterns.edit_frequency += action.actionType === 'edit' ? 1 : 0;
    metadata.interaction_patterns.share_frequency += action.actionType === 'mention' ? 1 : 0;

    // 重新生成文档描述
    record.document = this.generateInterestItemDocument(metadata);

    // 存储更新
    await this.cloudStorage.storeUserprofilesRecord(record);
    this.recordsCache.set(record.id, record);
  }

  /**
   * 创建新兴趣记录
   */
  async createNewInterestRecord(recordId, targetItem, action) {
    const actionWeight = this.getActionWeight(action.actionType);
    const newRecord = {
      id: recordId,
      document: '',
      // 将在下面生成
      metadata: {
        record_type: 'interest_item',
        user_id: this.userId,
        created_at: action.timestamp,
        updated_at: action.timestamp,
        last_accessed: action.timestamp,
        interest_category: targetItem.type,
        name: targetItem.name,
        current_weight: actionWeight,
        access_count: 1,
        first_seen: action.timestamp,
        recent_action_types: [action.actionType],
        interaction_patterns: {
          view_frequency: action.actionType === 'view' ? 1 : 0,
          edit_frequency: action.actionType === 'edit' ? 1 : 0,
          share_frequency: action.actionType === 'mention' ? 1 : 0
        },
        trend: 'stable',
        // 从targetItem.metadata复制特定字段
        ...(targetItem.metadata?.projectType && {
          project_type: targetItem.metadata.projectType
        }),
        ...(targetItem.metadata?.role && {
          person_role: targetItem.metadata.role
        }),
        ...(targetItem.metadata?.stack && {
          technology_stack: [targetItem.metadata.stack]
        }),
        ...(targetItem.metadata?.keywords && {
          topic_keywords: targetItem.metadata.keywords
        })
      }
    };

    // 生成文档描述
    newRecord.document = this.generateInterestItemDocument(newRecord.metadata);

    // 存储记录
    await this.cloudStorage.storeUserprofilesRecord(newRecord);
    this.recordsCache.set(recordId, newRecord);
  }

  /**
   * 生成兴趣项文档描述
   */
  generateInterestItemDocument(metadata) {
    const category = metadata.interest_category;
    const name = metadata.name;
    const weight = metadata.current_weight;
    let description = `${category}: ${name}`;

    // 添加类型特定信息
    if (category === 'project' && metadata.project_type) {
      description += ` (项目类型: ${metadata.project_type})`;
    } else if (category === 'person' && metadata.person_role) {
      description += ` (角色: ${metadata.person_role})`;
    } else if (category === 'technology' && metadata.technology_stack) {
      description += ` (技术栈: ${metadata.technology_stack.join(', ')})`;
    } else if (category === 'topic' && metadata.topic_keywords) {
      description += ` (关键词: ${metadata.topic_keywords.join(', ')})`;
    }
    description += ` - 权重: ${weight.toFixed(2)}, 访问次数: ${metadata.access_count}`;
    return description;
  }

  /**
   * 生成行为模式文档描述
   */
  generateBehaviorPatternDocument(data) {
    return `用户行为: ${data.actionType} 在 ${data.targetType} "${data.targetId}" 上，上下文: ${data.context}`;
  }

  /**
   * 获取行为模式类型
   */
  getPatternType(actionType) {
    // 简化的映射
    if (['view', 'edit', 'create'].includes(actionType)) return 'work_pattern';
    if (['mention', 'search'].includes(actionType)) return 'communication_style';
    return 'time_preference';
  }

  /**
   * 获取行为特定元数据
   */
  getBehaviorSpecificMetadata(data) {
    const hour = new Date(data.timestamp).getHours();
    return {
      active_hours: [hour],
      formality_level: 'semi-formal',
      response_speed: 'normal'
    };
  }

  /**
   * 排序兴趣项
   */
  sortInterestItems(records, sortBy) {
    return records.sort((a, b) => {
      switch (sortBy) {
        case 'weight':
          return b.metadata.current_weight - a.metadata.current_weight;
        case 'frequency':
          return b.metadata.access_count - a.metadata.access_count;
        case 'recent':
          return (b.metadata.last_accessed || 0) - (a.metadata.last_accessed || 0);
        default:
          return 0;
      }
    });
  }

  /**
   * 获取行为权重
   */
  getActionWeight(actionType) {
    const weights = {
      'view': 0.1,
      'edit': 0.3,
      'create': 0.5,
      'link': 0.2,
      'mention': 0.2,
      'search': 0.15,
      'favorite': 0.4
    };
    return weights[actionType] || 0.1;
  }

  /**
   * 按类别获取顶级项目
   */
  getTopItemsByCategory(records) {
    const byCategory = {};
    records.forEach(record => {
      const category = record.metadata.interest_category;
      if (!byCategory[category]) {
        byCategory[category] = [];
      }
      byCategory[category].push(record);
    });
    const result = {};
    Object.keys(byCategory).forEach(category => {
      result[category] = byCategory[category].sort((a, b) => b.metadata.current_weight - a.metadata.current_weight).slice(0, 5).map(record => ({
        name: record.metadata.name,
        weight: record.metadata.current_weight,
        accessCount: record.metadata.access_count
      }));
    });
    return result;
  }

  /**
   * 计算兴趣分布
   */
  calculateInterestDistribution(records) {
    const distribution = {};
    const total = records.length;
    records.forEach(record => {
      const category = record.metadata.interest_category;
      distribution[category] = (distribution[category] || 0) + 1;
    });

    // 转换为百分比
    Object.keys(distribution).forEach(key => {
      distribution[key] = distribution[key] / total;
    });
    return distribution;
  }

  /**
   * 分析行为模式
   */
  analyzeBehaviorPatterns(records) {
    // 简化的行为分析
    const timeData = records.filter(r => r.metadata.pattern_type === 'time_preference');
    const now = Date.now();
    const socialRecords = records.filter(r => r.metadata.pattern_type === 'communication_style');
    return {
      activeHours: timeData.length > 0 ? timeData[0].metadata.active_hours : [],
      communicationStyle: socialRecords.length > 0 ? socialRecords[0].metadata.formality_level : 'semi-formal',
      responseSpeed: socialRecords.length > 0 ? socialRecords[0].metadata.response_speed : 'normal'
    };
  }

  /**
   * 预测兴趣
   */
  predictInterests(records) {
    // 基于现有兴趣的简单预测
    const techRecords = records.filter(r => r.metadata.interest_category === 'technology');
    const topTech = techRecords.sort((a, b) => b.metadata.current_weight - a.metadata.current_weight)[0];
    if (topTech) {
      return [{
        item: `${topTech.metadata.name} 进阶应用`,
        type: 'technology',
        confidence: 0.8,
        reason: `基于您对 ${topTech.metadata.name} 的高度关注`
      }];
    }
    return [];
  }

  /**
   * 生成内容建议
   */
  generateContentSuggestions(records) {
    const suggestions = [];
    const topRecords = records.sort((a, b) => b.metadata.current_weight - a.metadata.current_weight).slice(0, 3);
    topRecords.forEach(record => {
      suggestions.push(`关于 ${record.metadata.name} 的深度内容`);
    });
    return suggestions;
  }

  /**
   * 计算分析置信度
   */
  calculateAnalysisConfidence(records) {
    if (records.length === 0) return 0;
    const totalInteractions = records.reduce((sum, r) => sum + r.metadata.access_count, 0);
    const avgWeight = records.reduce((sum, r) => sum + r.metadata.current_weight, 0) / records.length;

    // 简单的置信度计算
    return Math.min(1, totalInteractions / 100 * 0.5 + avgWeight * 0.5);
  }

  /**
   * 重构兴趣项（用于向后兼容）
   */
  reconstructInterestItems(records) {
    const interests = {
      projects: [],
      people: [],
      topics: [],
      technologies: [],
      documents: [],
      jiraTickets: []
    };
    records.forEach(record => {
      const metadata = record.metadata;
      const item = {
        id: record.id,
        type: metadata.interest_category,
        name: metadata.name,
        firstSeen: metadata.first_seen,
        lastAccessed: metadata.last_accessed || metadata.updated_at,
        accessCount: metadata.access_count,
        currentWeight: metadata.current_weight,
        decayFactor: 1.0,
        userActions: [],
        // 简化处理
        explicitImportance: metadata.explicit_importance,
        metadata: {
          projectType: metadata.project_type,
          role: metadata.person_role,
          stack: metadata.technology_stack?.[0],
          keywords: metadata.topic_keywords
        }
      };
      const categoryMap = {
        'project': 'projects',
        'person': 'people',
        'topic': 'topics',
        'technology': 'technologies',
        'document': 'documents',
        'jira': 'jiraTickets'
      };
      const category = categoryMap[metadata.interest_category];
      if (category && interests[category]) {
        interests[category].push(item);
      }
    });
    return interests;
  }

  /**
   * 重构行为模式（用于向后兼容）
   */
  reconstructBehaviorPatterns(records) {
    return {
      activeTimeZones: [],
      primaryWorkAreas: [],
      communicationStyle: {
        formality: 'semi-formal',
        detailLevel: 'medium',
        responseSpeed: 'normal',
        preferredChannels: ['email', 'chat']
      },
      toolUsageFrequency: []
    };
  }

  /**
   * 重构衍生偏好（用于向后兼容）
   */
  reconstructDerivedPreferences(summaryRecords) {
    const preferencesRecord = summaryRecords.find(r => r.metadata.summary_type === 'derived_preferences');
    if (preferencesRecord) {
      return {
        preferredProjectTypes: preferencesRecord.metadata.preferred_project_types || [],
        keyCollaborators: preferencesRecord.metadata.key_collaborators || [],
        expertiseAreas: preferencesRecord.metadata.expertise_areas || [],
        riskSensitivity: preferencesRecord.metadata.risk_sensitivity || 'medium',
        updateFrequency: preferencesRecord.metadata.update_frequency || 'weekly'
      };
    }
    return {
      preferredProjectTypes: [],
      keyCollaborators: [],
      expertiseAreas: [],
      riskSensitivity: 'medium',
      updateFrequency: 'weekly'
    };
  }

  /**
   * 计算统计信息（用于向后兼容）
   */
  calculateStatistics(interestRecords, summaryRecords) {
    const statsRecord = summaryRecords.find(r => r.metadata.summary_type === 'statistics');
    if (statsRecord) {
      return {
        totalInteractions: statsRecord.metadata.total_interactions || 0,
        averageDailyActivity: statsRecord.metadata.daily_activity_average || 0,
        mostActiveDay: statsRecord.metadata.most_active_day || '',
        topInteractionTypes: statsRecord.metadata.top_interaction_types || {}
      };
    }

    // 从兴趣记录计算基本统计
    const totalInteractions = interestRecords.reduce((sum, r) => sum + r.metadata.access_count, 0);
    return {
      totalInteractions,
      averageDailyActivity: totalInteractions / Math.max(1, interestRecords.length),
      mostActiveDay: new Date().toISOString().split('T')[0],
      topInteractionTypes: {
        view: totalInteractions
      }
    };
  }

  /**
   * 清理ID用于存储
   */
  sanitizeId(id) {
    return id.replace(/[^a-zA-Z0-9_-]/g, '_');
  }
}
;// CONCATENATED MODULE: ./src/memory.ts
/**
 * 统一记忆系统接口层
 * 提供清晰的读取和存储接口，管理本地缓存和云端存储
 */






// 重新导出接口供其他模块使用



// 查询结果接口

// 存储结果接口

// 查询选项

// 向量搜索选项

// 实体类型信息接口

// 实体类型配置
const ENTITY_TYPE_CONFIG = {
  'Person': {
    name: '人物',
    icon: '👥',
    description: '团队成员、联系人、项目相关人员等'
  },
  'Project': {
    name: '项目',
    icon: '🚀',
    description: '工作项目、产品开发、研究项目等'
  },
  'Task': {
    name: '任务',
    icon: '📋',
    description: '具体工作任务、待办事项、行动项等'
  },
  'Organization': {
    name: '组织',
    icon: '🏢',
    description: '公司、部门、团队、客户组织等'
  },
  'Document': {
    name: '文档',
    icon: '📄',
    description: '文件、资料、规范、报告等'
  },
  'Technology': {
    name: '技术',
    icon: '🔧',
    description: '技术栈、工具、框架、平台等'
  },
  'Topic': {
    name: '主题',
    icon: '💡',
    description: '讨论话题、知识领域、专业概念等'
  }
};

// 策略配置

// 性能指标

/**
 * 统一记忆系统管理器 - 现在直接充当策略层
 */
class MemorySystem {
  // 添加初始化Promise

  constructor() {
    this.userProfileManager = null;
    this.isInitialized = false;
    this.alarmListenerAdded = false;
    this.backgroundSyncStarted = false;
    this.isSyncing = false;
    this.initializationPromise = null;
    this.cloudStorage = new CloudStorage();
    this.localStorage = new LocalStorage();
    this.entitySimilarityTool = new EntitySimilarityTool();
    // 暂时延迟初始化 systemMaintenanceTool，在 initialize 方法中初始化
    this.systemMaintenanceTool = null;

    // 初始化策略配置
    this.config = {
      preferLocalForEntityQueries: true,
      localSearchThreshold: 5,
      cloudFallbackTimeout: 5000,
      requireCloudSuccess: false,
      retryAttempts: 3,
      retryDelay: 1000,
      syncInterval: 30 * 60 * 1000,
      // 30分钟
      maxSyncBatchSize: 50,
      prioritizeRecentData: true
    };

    // 初始化性能指标
    this.metrics = {
      totalQueries: 0,
      localHits: 0,
      cloudHits: 0,
      averageLocalTime: 0,
      averageCloudTime: 0,
      cacheHitRate: 0,
      lastReset: Date.now()
    };
  }

  /**
   * 初始化记忆系统（纯粹的初始化逻辑）
   */
  async performInitialization() {
    try {
      console.log('🧠 初始化记忆系统...');

      // 并行初始化各组件
      const [cloudInit, localInit] = await Promise.all([this.cloudStorage.initialize(), this.localStorage.initialize()]);

      // 加载配置和指标
      await this.loadConfig();
      await this.loadMetrics();
      this.isInitialized = cloudInit && localInit;
      if (this.isInitialized) {
        console.log('✅ 记忆系统初始化完成');

        // 初始化系统维护工具（需要 memorySystem 实例，所以在这里初始化）
        this.systemMaintenanceTool = createSystemMaintenanceTool(this.cloudStorage, this.localStorage, this // 传入自身作为策略层
        );

        // 启动后台同步
        this.startBackgroundSync();
        // 启动系统监控
        this.systemMaintenanceTool.startMonitoring();

        // 初始化用户画像管理器
        await this.initializeUserProfile();
      } else {
        console.error('❌ 记忆系统初始化失败');
      }
      return this.isInitialized;
    } catch (error) {
      console.error('❌ 记忆系统初始化异常:', error);
      this.isInitialized = false; // 确保失败时重置状态
      return false;
    }
  }

  /**
   * 初始化记忆系统（公共接口）
   */
  async initialize() {
    // 如果已经在初始化中，返回现有的Promise
    if (this.initializationPromise) {
      console.log('⚠️ 记忆系统正在初始化中，等待完成...');
      return this.initializationPromise;
    }

    // 防止重复初始化
    if (this.isInitialized) {
      console.log('⚠️ 记忆系统已初始化，跳过重复初始化');
      return true;
    }

    // 创建并缓存初始化Promise
    this.initializationPromise = this.performInitialization().finally(() => {
      // 无论成功失败，都清除Promise缓存
      this.initializationPromise = null;
    });
    return this.initializationPromise;
  }

  // ==================== 读取接口 ====================

  /**
   * 查询实体（普通查询，智能策略）
   */
  async queryEntities(type, searchTerm) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const startTime = Date.now();
    this.metrics.totalQueries++;
    try {
      // 如果有搜索词且长度大于2，考虑使用向量搜索
      if (searchTerm && searchTerm.length > 2) {
        const cloudResult = await this.cloudStorage.searchByVector(searchTerm, type, options);
        // 缓存结果到本地
        await this.cacheCloudResults(cloudResult.data);
        // 扩展实体信息
        const extendedData = await this.extendEntitiesFromCache(cloudResult.data);
        return {
          ...cloudResult,
          data: extendedData
        };
      }

      // 设置默认分页参数（第一页30条数据）
      const queryOptions = {
        ...options,
        limit: options.limit || 30,
        offset: options.offset || 0
      };

      // 优先查询云端获取分页数据
      const cloudResult = await this.queryFromCloud(type, searchTerm, queryOptions);
      this.updateMetrics('cloud', Date.now() - startTime);

      // 缓存结果到本地
      await this.cacheCloudResults(cloudResult.data);

      // 扩展实体信息：合并recent data
      const extendedData = await this.extendEntitiesFromCache(cloudResult.data);
      console.log(`🎯 MemorySystem.queryEntities: 查询到 ${cloudResult.data.length} 个实体，扩展信息后 ${extendedData.length} 个`);
      return {
        ...cloudResult,
        data: extendedData
      };
    } catch (error) {
      console.error('查询实体失败:', error);

      // 出错时尝试返回本地结果
      if (type) {
        const fallbackResult = await this.queryFromLocal(type, searchTerm, options);
        const extendedData = await this.extendEntitiesFromCache(fallbackResult.data);
        return {
          ...fallbackResult,
          data: extendedData,
          source: 'local'
        };
      }
      return {
        data: [],
        total: 0,
        source: 'local',
        cached: true,
        queryTime: Date.now() - startTime
      };
    }
  }

  /**
   * 向量搜索（直接云端查询）
   */
  async searchByVector(query, type) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.cloudStorage.searchByVector(query, type, options);
  }

  /**
   * 获取实体详情（优先本地，包含详细信息补充）
   */
  async getEntityDetails(entityId) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      // 先从本地获取
      const localEntity = await this.localStorage.getEntity(entityId);
      if (localEntity) {
        this.metrics.localHits++;
        // 检查是否需要补充详细信息
        return await this.enrichEntityWithDetails(localEntity);
      }

      // 本地没有，从云端获取
      const entity = await this.cloudStorage.getEntity(entityId);
      if (entity) {
        // 缓存到本地并补充详细信息
        await this.localStorage.cacheEntity(entity);
        this.metrics.cloudHits++;
        return await this.enrichEntityWithDetails(entity);
      }
      return null;
    } catch (error) {
      console.error('获取实体详情失败:', error);
      return null;
    }
  }

  /**
   * 为实体补充详细信息（特别是 recent data）
   */
  async enrichEntityWithDetails(entity) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      // 首先尝试从本地缓存获取详细信息
      const cachedDetails = await this.localStorage.getEntity(entity.id);

      // 检查是否缺少 recent data（没有讨论、资源、项目）
      const hasRecentData = cachedDetails && (cachedDetails.recentDataDetails?.conversations && cachedDetails.recentDataDetails.conversations.length > 0 || cachedDetails.recentDataDetails?.resources && cachedDetails.recentDataDetails.resources.length > 0 || cachedDetails.recentDataDetails?.projects && cachedDetails.recentDataDetails.projects.length > 0);
      if (hasRecentData && cachedDetails) {
        return cachedDetails;
      }

      // 如果缺少详细信息，从云端扩展实体信息
      console.log(`🔍 为实体 ${entity.id} 补充详细信息...`);
      const extendedEntity = await this.cloudStorage.extendEntityToDetailCache(entity);

      // 更新本地缓存
      await this.localStorage.cacheEntity(extendedEntity);
      return extendedEntity;
    } catch (error) {
      console.error(`补充实体 ${entity.id} 详细信息失败:`, error);

      // 失败时返回基础扩展版本
      return {
        ...entity,
        cachedAt: Date.now(),
        recentDataDetails: {
          conversations: [],
          webpages: [],
          resources: [],
          projects: [],
          people: [],
          topics: [],
          jiraTickets: [],
          cooccurringEntities: []
        },
        relatedParticipants: []
      };
    }
  }

  /**
   * 批量为实体补充详细信息
   */
  async enrichEntitiesWithDetails(entities) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const enrichedEntities = [];
    for (const entity of entities) {
      const enrichedEntity = await this.enrichEntityWithDetails(entity);
      enrichedEntities.push(enrichedEntity);
    }
    return enrichedEntities;
  }

  /**
   * 获取实体类型统计
   */
  async getEntityStatistics() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.localStorage.getEntityStatistics();
  }

  /**
   * 获取实体类型信息列表
   */
  async getEntityTypes() {
    try {
      const entityTypes = [];

      // 获取实体统计信息，包含各类型的数量
      const statistics = await this.getEntityStatistics();
      const entityCounts = statistics.entityCounts;

      // 遍历所有已知的实体类型
      for (const [type, count] of Object.entries(entityCounts)) {
        const config = ENTITY_TYPE_CONFIG[type];
        if (config) {
          entityTypes.push({
            type,
            name: config.name,
            icon: config.icon,
            count,
            description: config.description
          });
        } else {
          // 未知类型，使用默认配置
          entityTypes.push({
            type,
            name: type,
            icon: '📂',
            count,
            description: `自定义类型: ${type}`
          });
        }
      }

      // 按数量排序
      entityTypes.sort((a, b) => b.count - a.count);
      console.log(`📋 获取实体类型列表: ${entityTypes.length}个类型`);
      return entityTypes;
    } catch (error) {
      console.error('获取实体类型失败:', error);
      return [];
    }
  }

  /**
   * 搜索实体
   */
  async searchEntities(query, entityType) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (query.length > 2) {
      // 使用向量搜索 - 确保返回实体格式
      const vectorOptions = {
        ...options,
        returnType: 'entities',
        // 确保返回实体格式
        sortBy: 'relevance' // 默认按相关度排序
      };
      return this.searchByVector(query, entityType, vectorOptions);
    } else {
      // 使用普通查询
      return this.queryEntities(entityType, query, options);
    }
  }

  /**
   * 获取关系网络
   */
  async getRelationships(entityId) {
    let depth = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.localStorage.getRelationshipNetwork(entityId, depth);
  }

  /**
   * 获取时间轴数据
   */
  async getTimeline() {
    let limit = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 50;
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.cloudStorage.getTimeline(limit);
  }

  /**
   * 查询实体相关的详细消息（包含contextMessages等完整数据）
   */
  async queryEntityMessages(entityName, options) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }

    // 使用增强的 searchByVector 方法，专门搜索消息并返回原始数据格式
    const result = await this.cloudStorage.searchByVector(entityName, undefined, {
      collections: ['messages'],
      // 只搜索消息集合
      returnType: 'messages',
      // 返回原始数据格式
      limit: options?.limit,
      sortBy: options?.sortBy,
      sortOrder: options?.sortOrder,
      timeRange: options?.timeRange,
      minRelevanceScore: options?.minRelevanceScore
    });
    return result.data || [];
  }

  // ==================== 存储接口 ====================

  /**
   * 存储实体（先云端后本地）
   */
  async storeEntity(entity) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const startTime = Date.now();
    const result = {
      success: false,
      entityId: '',
      cloudStored: false,
      localCached: false,
      relationshipsCreated: 0,
      processingTime: 0,
      errors: []
    };
    try {
      // 构建完整实体
      const fullEntity = {
        ...entity,
        id: '',
        created: Date.now(),
        updated: Date.now(),
        accessCount: 0,
        lastAccessed: Date.now()
      };

      // 1. 先存储到云端
      let attempts = 0;
      while (attempts < this.config.retryAttempts) {
        try {
          const entityId = await this.cloudStorage.storeEntity(fullEntity);
          if (entityId) {
            fullEntity.id = entityId;
            result.entityId = entityId;
            result.cloudStored = true;
            break;
          }
        } catch (error) {
          console.warn(`云端存储尝试 ${attempts + 1} 失败:`, error);
          if (attempts < this.config.retryAttempts - 1) {
            await this.delay(this.config.retryDelay * (attempts + 1));
          }
        }
        attempts++;
      }

      // 2. 更新本地缓存
      try {
        await this.localStorage.cacheEntity(fullEntity);
        result.localCached = true;
      } catch (error) {
        console.warn('本地缓存失败:', error);
        result.errors?.push('本地缓存失败');
      }

      // 确定成功条件
      if (this.config.requireCloudSuccess) {
        result.success = result.cloudStored && result.localCached;
      } else {
        result.success = result.cloudStored || result.localCached;
      }
      result.processingTime = Date.now() - startTime;
      console.log(`💾 实体存储完成: ${result.entityId || fullEntity.id}`, {
        cloudStored: result.cloudStored,
        localCached: result.localCached,
        success: result.success
      });
      return result;
    } catch (error) {
      console.error('存储实体失败:', error);
      result.errors?.push(error.message);
      result.processingTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 存储消息（先云端后本地）- 🆕 统一接口，包含实体关联数据处理
   */
  async storeMessage(messageData) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const startTime = Date.now();
    const result = {
      success: false,
      entityId: messageData.id,
      cloudStored: false,
      localCached: false,
      relationshipsCreated: 0,
      processingTime: 0,
      errors: []
    };
    try {
      // 1. 存储消息到云端（实体数据已包含在metadata中）
      const cloudSuccess = await this.cloudStorage.storeMessage(messageData);
      result.cloudStored = cloudSuccess;

      // 2. 🆕 更新实体关联数据（从metadata中提取实体并更新关联信息）
      if (result.cloudStored) {
        try {
          await this.cloudStorage.updateEntitiesWithRelatedData(messageData.metadata, messageData.id);
          console.log(`🔗 实体关联数据更新完成: ${messageData.id}`);
        } catch (entityError) {
          console.error('🚨 更新实体关联数据失败:', entityError);
          result.errors?.push(`Entity update failed: ${entityError.message}`);
          // 不影响整体存储成功状态，仅记录错误
        }
      }
      result.success = result.cloudStored;
      result.processingTime = Date.now() - startTime;

      // 3. 同时更新用户画像
      if (result.success && this.userProfileManager && messageData.metadata?.entities) {
        try {
          // 将实体对象转换为数组格式
          const entitiesArray = this.cloudStorage.extractEntitiesFromMetadata(messageData.metadata, messageData.id);
          if (entitiesArray.length > 0) {
            // 根据消息匹配规则智能推断actionType
            const actionType = this.inferActionTypeFromMessageData(messageData);
            await this.updateUserProfileFromEntities(entitiesArray, {
              actionType,
              timestamp: Date.now(),
              context: 'message_analysis',
              metadata: {
                messageId: messageData.id,
                sender: messageData.metadata?.sender || 'unknown',
                matchedRules: messageData.metadata?.matchedRules,
                groupName: messageData.metadata?.groupName
              }
            });
          }
        } catch (profileError) {
          console.error('⚠️ 更新用户画像失败:', profileError);
          result.errors?.push(`Profile update failed: ${profileError.message}`);
          // 不影响整体存储成功状态，仅记录错误
        }
      }
      console.log(`✅ 消息完整存储完成: ${messageData.id}, 成功: ${result.success ? '✅' : '❌'}, 处理时间: ${result.processingTime}ms`);
      return result;
    } catch (error) {
      console.error('存储消息失败:', error);
      result.errors?.push(error.message);
      result.processingTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 存储网页数据
   */
  async storeWebpage(webpageData) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const startTime = Date.now();
    const result = {
      success: false,
      entityId: webpageData.id,
      cloudStored: false,
      localCached: false,
      relationshipsCreated: 0,
      processingTime: 0,
      errors: []
    };
    try {
      // 1. 存储网页到云端
      const cloudSuccess = await this.cloudStorage.storeWebpage(webpageData);
      result.cloudStored = cloudSuccess;

      // 2. 处理实体（如果有）
      if (webpageData.entities && webpageData.entities.length > 0) {
        for (const entityData of webpageData.entities) {
          const entityResult = await this.storeEntity(entityData);
          if (entityResult.success) {
            result.relationshipsCreated++;

            // 更新相关实体的最近数据缓存
            await this.localStorage.updateRecentData(entityResult.entityId, 'webpage', {
              id: webpageData.id,
              title: webpageData.title,
              url: webpageData.url,
              summary: webpageData.content.substring(0, 200),
              visitTime: Date.now(),
              domain: new URL(webpageData.url).hostname
            });
          }
        }
      }
      result.success = result.cloudStored;
      result.processingTime = Date.now() - startTime;

      // 同时更新用户画像
      if (result.success && this.userProfileManager && webpageData.entities) {
        await this.updateUserProfileFromEntities(webpageData.entities, {
          actionType: 'view',
          timestamp: Date.now(),
          context: 'webpage_analysis',
          metadata: {
            webpageId: webpageData.id,
            url: webpageData.url,
            title: webpageData.title,
            domain: new URL(webpageData.url).hostname
          }
        });
      }
      return result;
    } catch (error) {
      console.error('存储网页失败:', error);
      result.errors?.push(error.message);
      result.processingTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 更新实体（同步更新本地和云端）
   */
  async updateEntity(entityId, updates) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const startTime = Date.now();
    const result = {
      success: false,
      entityId,
      cloudStored: false,
      localCached: false,
      relationshipsCreated: 0,
      processingTime: 0,
      errors: []
    };
    try {
      // 添加更新时间
      const updatedData = {
        ...updates,
        updated: Date.now()
      };

      // 1. 更新云端
      const cloudSuccess = await this.cloudStorage.updateEntity(entityId, updatedData);
      result.cloudStored = cloudSuccess;

      // 2. 更新本地缓存
      const localEntity = await this.localStorage.getEntity(entityId);
      if (localEntity) {
        const updatedEntity = {
          ...localEntity,
          ...updatedData
        };
        await this.localStorage.cacheEntity(updatedEntity);
        result.localCached = true;
      }
      result.success = result.cloudStored || result.localCached;
      result.processingTime = Date.now() - startTime;
      return result;
    } catch (error) {
      console.error('更新实体失败:', error);
      result.errors?.push(error.message);
      result.processingTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 删除实体（同步删除本地和云端）
   */
  async deleteEntity(entityId) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      // 并行删除云端和本地
      const [cloudSuccess, localSuccess] = await Promise.allSettled([this.cloudStorage.deleteEntity(entityId), this.removeFromLocalCache(entityId)]);
      return cloudSuccess.status === 'fulfilled' && cloudSuccess.value || localSuccess.status === 'fulfilled' && localSuccess.value;
    } catch (error) {
      console.error('删除实体失败:', error);
      return false;
    }
  }

  /**
   * 批量存储实体
   */
  async batchStoreEntities(entities) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const results = [];
    let successCount = 0;
    let failedCount = 0;

    // 分批处理
    const batches = this.chunkArray(entities, this.config.maxSyncBatchSize);
    for (const batch of batches) {
      const batchPromises = batch.map(entity => this.storeEntity(entity));
      const batchResults = await Promise.allSettled(batchPromises);
      for (const settledResult of batchResults) {
        if (settledResult.status === 'fulfilled') {
          const result = settledResult.value;
          results.push(result);
          if (result.success) {
            successCount++;
          } else {
            failedCount++;
          }
        } else {
          failedCount++;
          results.push({
            success: false,
            entityId: `failed_${Date.now()}`,
            cloudStored: false,
            localCached: false,
            relationshipsCreated: 0,
            processingTime: 0,
            errors: [settledResult.reason?.message || '未知错误']
          });
        }
      }
    }
    return {
      success: successCount,
      failed: failedCount,
      results
    };
  }

  // ==================== 缓存管理接口 ====================

  /**
   * 更新实体的最近数据缓存
   */
  async updateRecentData(entityId, type, data) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.localStorage.updateRecentData(entityId, type, data);
  }

  /**
   * 🆕 同步实体类型统计数据到本地缓存
   */
  async syncEntityCountsToCache(entities) {
    try {
      // 统计各类型实体数量
      const entityCounts = {
        'Person': 0,
        'Project': 0,
        'Task': 0,
        'Organization': 0,
        'Document': 0,
        'Technology': 0,
        'Topic': 0
      };

      // 遍历实体并统计
      entities.forEach(entity => {
        if (Object.prototype.hasOwnProperty.call(entityCounts, entity.type)) {
          entityCounts[entity.type]++;
        } else {
          // 如果有新的类型，也记录下来
          entityCounts[entity.type] = (entityCounts[entity.type] || 0) + 1;
        }
      });

      // 保存到本地缓存
      const statistics = {
        entityCounts,
        lastUpdated: Date.now(),
        totalEntities: entities.length
      };
      await chrome.storage.local.set({
        'cache_statistics': statistics
      });
      console.log(`📊 实体统计数据已缓存:`, entityCounts);
    } catch (error) {
      console.error('📊 同步实体统计数据失败:', error);
    }
  }

  /**
   * 清理过期缓存
   */
  async clearExpiredCache() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.localStorage.clearExpiredCache();
  }

  /**
   * 强制同步缓存
   */
  async syncCache() {
    if (this.isSyncing) {
      console.log('⏭️ 同步程序还在进行，跳过本次同步');
      return;
    }
    this.isSyncing = true;
    console.log('🔄 执行定时同步...');
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      console.log('🔄 开始同步缓存...');

      // 执行云端到本地单向同步
      await this.performCloudToLocalSync();

      // 上传本地统计信息到云端
      await this.uploadLocalStatisticsToCloud();

      // 清理过期缓存
      await this.localStorage.clearExpiredCache();

      // 更新最后同步时间
      await chrome.storage.local.set({
        'cache_last_sync_time': Date.now()
      });
      console.log('✅ 缓存同步完成');
    } catch (error) {
      console.error('❌ 缓存同步失败:', error);
    }
    this.isSyncing = false;
  }

  /**
   * 新设备初始同步
   */
  async performInitialSyncIfNeeded() {
    const result = {
      isNewDevice: false,
      syncPerformed: false,
      entitiesDownloaded: 0,
      relationshipsRestored: 0
    };
    try {
      // 检查是否是新设备
      const lastSyncData = await chrome.storage.local.get(['cache_last_sync_time', 'cache_device_initialized']);
      const isNewDevice = !lastSyncData.cache_device_initialized;
      result.isNewDevice = isNewDevice;
      if (isNewDevice) {
        console.log('🆕 检测到新设备，开始初始同步...');

        // 从云端拉取实体
        const {
          data: cloudEntities
        } = await this.cloudStorage.queryEntities();
        result.entitiesDownloaded = cloudEntities.length;
        if (cloudEntities.length > 0) {
          await this.localStorage.batchCacheEntities(cloudEntities);
        }

        // 恢复关系数据
        const relationshipData = await this.cloudStorage.restoreRelationships();
        if (relationshipData) {
          await this.localStorage.restoreRelationshipData(relationshipData);
          result.relationshipsRestored = relationshipData.relationships.length;
        }

        // 标记设备已初始化
        await chrome.storage.local.set({
          cache_device_initialized: true,
          cache_last_sync_time: Date.now()
        });
        result.syncPerformed = true;
        console.log(`✅ 新设备初始同步完成: ${result.entitiesDownloaded} 个实体, ${result.relationshipsRestored} 个关系`);
      }
      return result;
    } catch (error) {
      console.error('新设备初始同步失败:', error);
      return result;
    }
  }

  /**
   * 备份关系数据到云端
   */
  async backupRelationships() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      // 获取本地关系数据
      const relationshipData = await this.localStorage.getRelationshipBackupData();
      if (!relationshipData) {
        console.log('⚠️ 没有关系数据需要备份');
        return false;
      }
      return await this.cloudStorage.backupRelationships(relationshipData);
    } catch (error) {
      console.error('备份关系数据失败:', error);
      return false;
    }
  }

  /**
   * 创建实体关系
   */
  async createRelationship(relationship) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      const fullRelationship = {
        id: `rel_${relationship.fromId}_${relationship.toId}_${relationship.type}_${Date.now()}`,
        type: relationship.type,
        fromId: relationship.fromId,
        toId: relationship.toId,
        properties: relationship.properties || {},
        strength: relationship.strength || 0.7,
        created: Date.now(),
        updated: Date.now()
      };
      await this.localStorage.cacheRelationship(fullRelationship);
      return true;
    } catch (error) {
      console.error('创建关系失败:', error);
      return false;
    }
  }

  /**
   * 实体时间轴
   */
  async getEntityTimeline(entityId, options) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }

    // 这里可以根据需要实现时间轴逻辑
    // 目前返回空数组，可以根据实际需求扩展
    return [];
  }

  /**
   * 获取系统状态
   */
  async getSystemStatus() {
    return {
      isInitialized: this.isInitialized,
      cloudConnected: await this.cloudStorage.isConnected(),
      localCacheSize: await this.localStorage.getCacheSize(),
      lastSyncTime: await this.getLastSyncTime(),
      performance: await this.getPerformanceMetrics()
    };
  }

  // ==================== 实体相似性管理接口 ====================

  /**
   * 处理实体相似性检测
   */
  async processEntitySimilarity(entity) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.entitySimilarityTool.processEntity(entity);
  }

  /**
   * 批量处理实体相似性
   */
  async processEntitiesSimilarity(entities) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.entitySimilarityTool.processEntities(entities);
  }

  /**
   * 获取待处理的实体合并候选
   */
  async getPendingEntityMerges() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.entitySimilarityTool.getPendingMerges();
  }

  /**
   * 确认实体合并
   */
  async confirmEntityMerge(mergeId) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.entitySimilarityTool.confirmMerge(mergeId);
  }

  /**
   * 拒绝实体合并
   */
  async rejectEntityMerge(mergeId) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.entitySimilarityTool.rejectMerge(mergeId);
  }

  /**
   * 获取实体相似性统计
   */
  getEntitySimilarityStats() {
    return this.entitySimilarityTool.getStatistics();
  }

  // ==================== 系统维护接口 ====================

  /**
   * 执行系统健康检查
   */
  async performHealthCheck() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.systemMaintenanceTool.performHealthCheck();
  }

  /**
   * 执行完整系统维护
   */
  async performSystemMaintenance(options) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.systemMaintenanceTool.performFullMaintenance(options);
  }

  /**
   * 获取维护工具状态
   */
  getMaintenanceStatus() {
    return this.systemMaintenanceTool.getSystemStatus();
  }

  // ==================== 用户画像接口 ====================

  /**
   * 获取用户画像
   */
  async getUserProfile() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      return {
        profile: null,
        analysis: null
      };
    }
    try {
      const profile = await this.userProfileManager.getProfile();
      const analysis = await this.userProfileManager.generateAnalysis();
      return {
        profile,
        analysis
      };
    } catch (error) {
      console.error('获取用户画像失败:', error);
      return {
        profile: null,
        analysis: null
      };
    }
  }

  /**
   * 更新用户画像
   */
  async updateUserProfile(update) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      console.warn('用户画像管理器未初始化');
      return false;
    }
    try {
      await this.userProfileManager.updateProfile(update);
      return true;
    } catch (error) {
      console.error('更新用户画像失败:', error);
      return false;
    }
  }

  /**
   * 设置用户明确重要性
   */
  async setUserExplicitImportance(itemId, type, importance) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      return false;
    }
    try {
      await this.userProfileManager.setExplicitImportance(itemId, type, importance);
      return true;
    } catch (error) {
      console.error('设置用户重要性失败:', error);
      return false;
    }
  }

  /**
   * 应用用户画像权重衰变
   */
  async applyUserProfileDecay() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (this.userProfileManager) {
      await this.userProfileManager.applyWeightDecay();
    }
  }

  /**
   * 🆕 融合用户上下文配置到用户画像
   */
  async fuseUserContextConfig(userContextConfig) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      return false;
    }
    try {
      const success = await this.userProfileManager.fuseUserContextConfig(userContextConfig);
      if (success) {
        // 融合成功后执行自适应权重调整
        await this.userProfileManager.adaptiveWeightAdjustment();
      }
      return success;
    } catch (error) {
      console.error('融合用户上下文配置失败:', error);
      return false;
    }
  }

  /**
   * 🆕 执行权重自适应调整
   */
  async adaptiveWeightAdjustment() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (this.userProfileManager) {
      try {
        await this.userProfileManager.adaptiveWeightAdjustment();
      } catch (error) {
        console.error('权重自适应调整失败:', error);
      }
    }
  }

  /**
   * 🆕 生成主动推荐内容
   */
  async generateProactiveRecommendations() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      return [];
    }
    try {
      return await this.userProfileManager.generateProactiveRecommendations();
    } catch (error) {
      console.error('生成主动推荐失败:', error);
      return [];
    }
  }

  /**
   * 🆕 获取融合后的用户画像
   * 返回应用了加权融合算法的兴趣列表
   */
  async getFusedUserProfile() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      return {
        profile: null,
        analysis: null,
        fusedInterests: null
      };
    }
    try {
      const {
        profile,
        analysis
      } = await this.getUserProfile();
      if (!profile) {
        return {
          profile: null,
          analysis: null,
          fusedInterests: null
        };
      }

      // 应用加权融合算法到各个兴趣类别
      const fusedInterests = {
        projects: this.userProfileManager.getFusedInterestItems(profile.interests.projects || []),
        people: this.userProfileManager.getFusedInterestItems(profile.interests.people || []),
        topics: this.userProfileManager.getFusedInterestItems(profile.interests.topics || []),
        jiraTickets: this.userProfileManager.getFusedInterestItems(profile.interests.jiraTickets || []),
        technologies: this.userProfileManager.getFusedInterestItems(profile.interests.technologies || []),
        documents: this.userProfileManager.getFusedInterestItems(profile.interests.documents || [])
      };
      return {
        profile: {
          ...profile,
          interests: fusedInterests
        },
        analysis,
        fusedInterests
      };
    } catch (error) {
      console.error('获取融合用户画像失败:', error);
      return {
        profile: null,
        analysis: null,
        fusedInterests: null
      };
    }
  }

  /**
   * 🆕 存储独立用户配置到云端
   */
  async storeIndependentUserConfig(config) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      const success = await this.cloudStorage.storeIndependentUserConfig(config);
      return success;
    } catch (error) {
      console.error('存储独立用户配置失败:', error);
      return false;
    }
  }

  /**
   * 🆕 获取独立用户配置
   */
  async getIndependentUserConfig() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      const config = await this.cloudStorage.getIndependentUserConfig();
      return config;
    } catch (error) {
      console.error('获取独立用户配置失败:', error);
      return null;
    }
  }

  /**
   * 获取最后同步时间
   */
  async getLastSyncTime() {
    try {
      const result = await chrome.storage.local.get('cache_last_sync_time');
      return result.cache_last_sync_time || 0;
    } catch (error) {
      return 0;
    }
  }

  /**
   * 获取性能指标
   */
  async getPerformanceMetrics() {
    return {
      averageQueryTime: (this.metrics.averageLocalTime + this.metrics.averageCloudTime) / 2,
      cacheHitRate: this.metrics.cacheHitRate
    };
  }

  // ==================== 私有方法 ====================

  /**
   * 启动后台同步 - 现在包含用户画像权重衰变逻辑
   */
  startBackgroundSync() {
    // 防止重复启动
    if (this.backgroundSyncStarted) {
      console.log('⚠️ 后台同步已启动，跳过重复启动');
      return;
    }

    // 检查是否在background script环境中
    const isBackground = typeof ServiceWorkerGlobalScope !== 'undefined' && self instanceof ServiceWorkerGlobalScope;
    if (!isBackground) {
      console.log('⚠️ 非background环境，跳过后台同步启动');
      return;
    }

    // 使用 Chrome alarms API 进行后台同步和权重衰变
    const syncAlarmName = 'memory-system-sync';
    const decayAlarmName = 'user-profile-decay';
    chrome.alarms.clear(syncAlarmName, () => {
      // 创建同步 alarm，每5分钟同步一次
      chrome.alarms.create(syncAlarmName, {
        periodInMinutes: this.config.syncInterval / (60 * 1000)
      });
      console.log(`🔄 后台同步已启动，间隔: ${this.config.syncInterval / (60 * 1000)} 分钟`);
    });
    chrome.alarms.clear(decayAlarmName, () => {
      // 创建权重衰变 alarm，每24小时执行一次
      chrome.alarms.create(decayAlarmName, {
        periodInMinutes: 24 * 60 // 24小时
      });
      console.log(`🧠 用户画像权重衰变已启动，间隔: 24小时`);
    });

    // 标记为已启动
    this.backgroundSyncStarted = true;

    // 在启动定时任务时直接运行一次，但添加防抖
    console.log('🔄 首次执行定时同步...');
    this.syncCache().catch(error => {
      console.error('后台同步失败:', error);
    });

    // 首次执行权重衰变
    console.log('🧠 首次执行权重衰变...');
    this.applyUserProfileDecay().catch(error => {
      console.error('权重衰变失败:', error);
    });

    // 监听 alarm 事件
    this.setupAlarmListener();
  }

  /**
   * 设置 alarm 监听器
   */
  setupAlarmListener() {
    // 避免重复添加监听器
    if (this.alarmListenerAdded) {
      return;
    }
    chrome.alarms.onAlarm.addListener(alarm => {
      if (alarm.name === 'memory-system-sync') {
        console.log('🔄 执行定时同步...');
        this.syncCache().catch(error => {
          console.error('后台同步失败:', error);
        });
      } else if (alarm.name === 'user-profile-decay') {
        console.log('🧠 执行定时权重衰变...');
        this.applyUserProfileDecay().catch(error => {
          console.error('定时权重衰变失败:', error);
        });
      }
    });
    this.alarmListenerAdded = true;
    console.log('🎯 alarm 监听器已设置（同步 + 权重衰变）');
  }

  /**
   * 执行用户画像权重衰变
   */

  /**
   * 清理实体名称，处理中文和特殊字符
   */
  sanitizeEntityName(name) {
    if (!name || name.trim() === '') {
      return 'entity';
    }

    // 简单的中文转拼音映射（部分常用字符）
    const chineseToPinyin = {
      '项目': 'xiangmu',
      '文档': 'wendang',
      '人员': 'renyuan',
      '主题': 'zhuti',
      '任务': 'renwu',
      '团队': 'tuandui',
      '公司': 'gongsi',
      '系统': 'xitong',
      '数据': 'shuju',
      '功能': 'gongneng',
      '需求': 'xuqiu',
      '设计': 'sheji',
      '开发': 'kaifa',
      '测试': 'ceshi',
      '部署': 'bushu',
      '维护': 'weihu',
      '管理': 'guanli',
      '分析': 'fenxi',
      '报告': 'baogao',
      '会议': 'huiyi'
    };
    let cleanName = name.trim();

    // 替换中文词汇为拼音
    for (const [chinese, pinyin] of Object.entries(chineseToPinyin)) {
      cleanName = cleanName.replace(new RegExp(chinese, 'g'), pinyin);
    }

    // 移除其他中文字符（通过Unicode范围）
    cleanName = cleanName.replace(/[\u4e00-\u9fff]/g, '');

    // 只保留字母、数字和连字符
    cleanName = cleanName.replace(/[^a-zA-Z0-9\-_]/g, '');

    // 移除多余的连字符和下划线
    cleanName = cleanName.replace(/[-_]+/g, '_');

    // 移除开头和结尾的连字符和下划线
    cleanName = cleanName.replace(/^[-_]+|[-_]+$/g, '');

    // 限制长度并确保不为空
    if (cleanName.length === 0) {
      cleanName = 'entity';
    } else if (cleanName.length > 20) {
      cleanName = cleanName.substring(0, 20);
    }

    // 确保以字母开头
    if (!/^[a-zA-Z]/.test(cleanName)) {
      cleanName = 'entity_' + cleanName;
    }
    return cleanName.toLowerCase();
  }
  async queryFromLocal(type, searchTerm) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    if (type) {
      return this.localStorage.queryEntitiesByType(type, options);
    } else if (searchTerm) {
      return this.localStorage.searchEntities(searchTerm, type, options);
    } else {
      // 返回所有实体（分页）
      return {
        data: [],
        total: 0,
        source: 'local',
        cached: true,
        queryTime: 0
      };
    }
  }
  async queryFromCloud(type, searchTerm) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    // 如果有搜索词且长度大于2，使用向量搜索获得更好的语义匹配
    if (searchTerm && searchTerm.length > 2 && !type) {
      // 转换为向量搜索选项
      const vectorOptions = {
        limit: options.limit,
        offset: options.offset,
        useCache: options.useCache,
        includeCounts: options.includeCounts,
        sortBy: options.sortBy === 'relevance' ? 'relevance' : options.sortBy === 'importance' ? 'importance' : 'relevance',
        sortOrder: options.sortOrder
      };
      return this.cloudStorage.searchByVector(searchTerm, type, vectorOptions);
    }

    // 使用新的云端实体查询接口，支持按type过滤
    return this.cloudStorage.queryEntities(type, searchTerm, options);
  }
  async cacheCloudResults(entities) {
    try {
      if (entities.length > 0) {
        await this.localStorage.batchCacheEntities(entities);
      }
    } catch (error) {
      console.error('缓存云端结果失败:', error);
    }
  }
  async removeFromLocalCache(entityId) {
    try {
      await chrome.storage.local.remove(`cache_entities_${entityId}`);
      // 这里还需要更新索引等，但为了简化暂时省略
      return true;
    } catch (error) {
      console.error('从本地缓存删除失败:', error);
      return false;
    }
  }
  updateMetrics(source, queryTime) {
    if (source === 'local' || source === 'hybrid') {
      this.metrics.localHits++;
      this.metrics.averageLocalTime = (this.metrics.averageLocalTime * (this.metrics.localHits - 1) + queryTime) / this.metrics.localHits;
    }
    if (source === 'cloud' || source === 'hybrid') {
      this.metrics.cloudHits++;
      this.metrics.averageCloudTime = (this.metrics.averageCloudTime * (this.metrics.cloudHits - 1) + queryTime) / this.metrics.cloudHits;
    }

    // 更新缓存命中率
    this.metrics.cacheHitRate = this.metrics.localHits / this.metrics.totalQueries;
  }
  async loadConfig() {
    try {
      const result = await chrome.storage.local.get('cache_strategy_config');
      if (result.cache_strategy_config) {
        this.config = {
          ...this.config,
          ...result.cache_strategy_config
        };
      }
    } catch (error) {
      console.warn('加载缓存策略配置失败，使用默认配置');
    }
  }
  async loadMetrics() {
    try {
      const result = await chrome.storage.local.get('cache_strategy_metrics');
      if (result.cache_strategy_metrics) {
        this.metrics = {
          ...this.metrics,
          ...result.cache_strategy_metrics
        };
      }
    } catch (error) {
      console.warn('加载性能指标失败，使用默认值');
    }
  }
  async delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

  /**
   * 从缓存扩展实体信息：直接合并缓存数据（简化版）
   */
  async extendEntitiesFromCache(entities) {
    const extendedEntities = [];
    for (const entity of entities) {
      const extendedEntity = {
        ...entity,
        cachedAt: Date.now(),
        // 初始化必要的数组字段
        recentDataDetails: {
          conversations: [],
          webpages: [],
          resources: [],
          projects: [],
          people: [],
          topics: [],
          jiraTickets: [],
          cooccurringEntities: []
        },
        relatedParticipants: []
      };
      try {
        // 获取扩展缓存数据
        const cacheData = await this.localStorage.getEntity(entity.id);
        if (cacheData) {
          // 直接合并缓存数据到实体对象
          Object.assign(extendedEntity, cacheData);
        } else {
          // 没有缓存数据时，设置默认值  
          this.setDefaultExtendedFields(extendedEntity, entity);
        }
      } catch (error) {
        console.error(`扩展实体 ${entity.id} 信息失败:`, error);
        // 设置默认值
        this.setDefaultExtendedFields(extendedEntity, entity);
      }
      extendedEntities.push(extendedEntity);
    }
    return extendedEntities;
  }

  /**
   * 设置扩展字段的默认值
   */
  setDefaultExtendedFields(extendedEntity, entity) {
    // 设置必要的数组字段默认值
    if (!extendedEntity.recentDataDetails) {
      extendedEntity.recentDataDetails = {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      };
    }

    // 确保统计字段存在
    if (!extendedEntity.statistic) {
      extendedEntity.statistic = {
        conversations: 0,
        projects: 0,
        participants: 1,
        resources: 0,
        documents: 0,
        webpages: 0,
        relationships: entity.properties?.relationshipsCount || 0,
        topics: 0,
        jiraTickets: 0
      };
    }

    // 根据实体类型设置特定默认值
    if (entity.type === 'Person') {
      extendedEntity.role = entity.properties?.role || '团队成员';
      extendedEntity.team = entity.properties?.team || '';
      extendedEntity.expertise = entity.properties?.expertise || entity.tags || [];
    }
    if (entity.type === 'Project') {
      extendedEntity.isHighlighted = entity.properties?.isHighlighted || false;
    }
  }

  /**
   * 执行云端到本地单向同步 - 只从云端拉取数据到本地缓存
   */
  async performCloudToLocalSync() {
    try {
      const lastSyncData = await chrome.storage.local.get('cache_last_sync_time');
      const lastSyncTime = lastSyncData.cache_last_sync_time || 0;

      // 如果距离上次同步不足5分钟，跳过同步
      if (Date.now() - lastSyncTime < 5 * 60 * 1000) {
        console.log('⏭️ 距离上次单向同步不足5分钟，跳过');
        return;
      }
      console.log('📥 开始云端到本地单向同步...');
      let syncedEntities = 0;
      let recentDataUpdated = 0;

      // 1. 从云端拉取所有实体
      const {
        data: cloudEntities
      } = await this.cloudStorage.queryEntities();

      // 2. 批量同步云端实体到本地
      const cloudBatches = this.chunkArray(cloudEntities, 20); // 每批最多20个
      const entitiesToUpdate = [];
      for (const batch of cloudBatches) {
        for (const entity of batch) {
          const localEntity = await this.localStorage.getEntity(entity.id);
          if (!localEntity || localEntity.updated < entity.updated) {
            // 🔄 缓存实体到本地
            await this.localStorage.cacheEntity(entity);
            syncedEntities++;
            entitiesToUpdate.push(entity);
          }
        }

        // 批间延迟，避免阻塞
        if (cloudBatches.length > 1) {
          await this.delay(100);
        }
      }

      // 3. 🆕 关联数据现在直接存储在 MemoryEntity.relatedData 中，无需单独同步关系
      console.log(`📊 实体关联数据已通过 MemoryEntity.relatedData 同步，无需额外关系处理`);
      if (entitiesToUpdate.length > 0) {
        recentDataUpdated = entitiesToUpdate.length;
      }

      // 4. 🆕 统计所有实体类型的数量并缓存到本地
      await this.syncEntityCountsToCache(cloudEntities);
      console.log(`✅ 单向同步完成: 同步了${syncedEntities}个实体，更新了${recentDataUpdated}个实体的最近数据缓存`);
    } catch (error) {
      console.error('❌ 云端到本地同步失败:', error);
    }
  }

  /**
   * 上传本地统计信息到云端
   */
  async uploadLocalStatisticsToCloud() {
    try {
      console.log('📊 开始上传本地统计信息到云端...');

      // 获取所有本地缓存的实体
      const recentDataEntries = await this.localStorage.getAllRecentDataEntries();
      if (!recentDataEntries || recentDataEntries.length === 0) {
        console.log('📊 没有本地统计信息需要上传');
        return;
      }

      // 收集需要更新的统计信息
      const statisticsUpdates = [];
      for (const entry of recentDataEntries) {
        try {
          // 计算当前统计信息
          const updatedStatistic = entry.statistic;
          statisticsUpdates.push({
            entityId: entry.id,
            statistic: updatedStatistic,
            lastUpdated: entry.lastUpdated || Date.now()
          });
        } catch (error) {
          console.error(`处理实体 ${entry.id} 统计信息失败:`, error);
        }
      }
      if (statisticsUpdates.length === 0) {
        console.log('📊 没有有效的统计信息需要上传');
        return;
      }

      // 批量更新云端实体的统计信息
      await this.cloudStorage.batchUpdateEntityStatistics(statisticsUpdates);
      console.log(`📊 成功上传 ${statisticsUpdates.length} 个实体的统计信息`);
    } catch (error) {
      console.error('📊 上传统计信息失败:', error);
    }
  }

  /**
   * 初始化用户画像管理器
   */
  async initializeUserProfile() {
    try {
      // 重用现有的 CloudStorage 实例，避免重复初始化
      // UserProfileManager 现在会在 initialize() 时自动获取用户信息
      this.userProfileManager = new UserProfileManager(undefined, this.cloudStorage);
      await this.userProfileManager.initialize();
      console.log('✅ 用户画像管理器初始化成功');
    } catch (error) {
      console.error('❌ 用户画像管理器初始化失败:', error);
      // 不要抛出异常，允许记忆系统继续运行
    }
  }

  /**
   * 根据消息数据智能推断用户行为类型
   */
  inferActionTypeFromMessageData(messageData) {
    // 优先使用LLM分析提供的用户关系类型
    const userRelationType = messageData.metadata?.user_relation_type;
    if (userRelationType) {
      return this.mapUserRelationTypeToActionType(userRelationType);
    }
    const matchedRules = messageData.metadata?.matchedRules || [];
    const sender = messageData.metadata?.sender || '';
    const messageContent = messageData.content || '';

    // 检查是否明确提到用户
    const mentionKeywords = ['@我', '@你', '提到我', '需要你', '你来', '你的'];
    const hasMention = mentionKeywords.some(keyword => messageContent.includes(keyword));
    if (hasMention) {
      return 'mention';
    }

    // 根据匹配规则推断行为类型
    for (const rule of matchedRules) {
      const lowerRule = rule.toLowerCase();

      // 项目相关消息 - 通常是查看项目进展
      if (lowerRule.includes('recording') || lowerRule.includes('project') || lowerRule.includes('dependencies')) {
        return 'view';
      }

      // 政策消息 - 通常需要关注/查看
      if (lowerRule.includes('政策') || lowerRule.includes('policy') || lowerRule.includes('规定')) {
        return 'view';
      }

      // 特定人员消息 - 算作查看行为
      if (lowerRule.includes('sophia') || lowerRule.includes('jinmei') || lowerRule.includes('发送的所有消息')) {
        return 'view';
      }

      // 明确@我的消息
      if (lowerRule.includes('@我') || lowerRule.includes('mention')) {
        return 'mention';
      }
    }

    // 默认返回view（浏览/关注）
    return 'view';
  }

  /**
   * 将LLM分析的用户关系类型映射到actionType
   */
  mapUserRelationTypeToActionType(userRelationType) {
    const lowerType = userRelationType.toLowerCase();
    if (lowerType.includes('mention')) {
      return 'mention';
    } else if (lowerType.includes('project_related')) {
      return 'view';
    } else if (lowerType.includes('policy_related')) {
      return 'view';
    } else if (lowerType.includes('person_tracking')) {
      return 'view'; // 改为view而不是social
    } else if (lowerType.includes('general_interest')) {
      return 'view';
    }

    // 默认返回view
    return 'view';
  }

  /**
   * 从实体列表更新用户画像
   */
  async updateUserProfileFromEntities(entities, baseAction) {
    if (!this.userProfileManager) return;
    try {
      for (const entity of entities) {
        // 映射实体类型到用户画像类型
        let profileType;
        switch (entity.type) {
          case 'Person':
            profileType = 'person';
            break;
          case 'Project':
            profileType = 'project';
            break;
          case 'Task':
            profileType = 'jira';
            break;
          case 'Technology':
            profileType = 'technology';
            break;
          case 'Document':
            profileType = 'document';
            break;
          case 'Topic':
          default:
            profileType = 'topic';
            break;
        }

        // 根据实体类型调整权重
        let weight = 0.1; // 默认权重
        switch (profileType) {
          case 'project':
            weight *= 1.5; // 项目权重更高
            break;
          case 'person':
            weight *= 1.3; // 人员权重稍高
            break;
          case 'jira':
            weight *= 1.2; // JIRA 权重稍高
            break;
          default:
            break;
        }
        const action = {
          ...baseAction,
          weight
        };
        await this.userProfileManager.updateProfile({
          userId: this.userProfileManager.userId,
          action,
          targetItem: {
            id: entity.name.replace(/\s+/g, '_').toLowerCase(),
            type: profileType,
            name: entity.name,
            metadata: {
              entityType: entity.type,
              document: entity.document,
              importance: entity.importance,
              tags: entity.tags
            }
          }
        });
      }
    } catch (error) {
      console.error('从实体更新用户画像失败:', error);
    }
  }
}

// 导出单例实例
const memorySystem = new MemorySystem();
;// CONCATENATED MODULE: ./src/modals/memory.tsx




// 实体类型配置（中文映射）
const memory_ENTITY_TYPE_CONFIG = {
  'Person': {
    name: '人物',
    icon: '👥',
    description: '团队成员、联系人、项目相关人员等'
  },
  'Project': {
    name: '项目',
    icon: '🚀',
    description: '工作项目、产品开发、研究项目等'
  },
  'Task': {
    name: '任务',
    icon: '📋',
    description: '具体工作任务、待办事项、行动项等'
  },
  'Organization': {
    name: '组织',
    icon: '🏢',
    description: '公司、部门、团队、客户组织等'
  },
  'Document': {
    name: '文档',
    icon: '📄',
    description: '文件、资料、规范、报告等'
  },
  'Technology': {
    name: '技术',
    icon: '🔧',
    description: '技术栈、工具、框架、平台等'
  },
  'Topic': {
    name: '主题',
    icon: '💡',
    description: '讨论话题、知识领域、专业概念等'
  }
};

// 扩展Window接口

// 数据接口定义

// 实体记忆查询组件
const MemoryInterface = () => {
  // 状态管理
  const [activeView, setActiveView] = (0,react.useState)('overview');
  const [selectedEntityType, setSelectedEntityType] = (0,react.useState)('overview');
  const [selectedEntity, setSelectedEntity] = (0,react.useState)(null);
  const [selectedTopic, setSelectedTopic] = (0,react.useState)(null);
  const [searchQuery, setSearchQuery] = (0,react.useState)('');
  const [isLoading, setIsLoading] = (0,react.useState)(false);
  const [entities, setEntities] = (0,react.useState)([]);
  const [timeline, setTimeline] = (0,react.useState)([]);
  const [overviewStats, setOverviewStats] = (0,react.useState)(null);
  const [entityTypes, setEntityTypes] = (0,react.useState)([]);

  // 用户画像相关状态
  const [userProfileManager, setUserProfileManager] = (0,react.useState)(null);
  const [userProfile, setUserProfile] = (0,react.useState)(null);
  const [userProfileAnalysis, setUserProfileAnalysis] = (0,react.useState)(null);
  const [topicDetailData, setTopicDetailData] = (0,react.useState)(null);
  const [activeTopicTab, setActiveTopicTab] = (0,react.useState)('overview');

  // 聊天记录相关状态
  const [chatSearchQuery, setChatSearchQuery] = (0,react.useState)('');
  const [chatFilter, setChatFilter] = (0,react.useState)('all');
  const [chatPage, setChatPage] = (0,react.useState)(1);
  const [chatPageSize] = (0,react.useState)(10);
  const [expandedConversations, setExpandedConversations] = (0,react.useState)(new Set());

  // 主题最新讨论缓存
  const [topicDiscussions, setTopicDiscussions] = (0,react.useState)({});

  // 实体类型配置在文件顶部定义

  // 映射实体类型到用户画像类型
  const mapEntityTypeToProfileType = entityType => {
    const mapping = {
      'Person': 'person',
      'Project': 'project',
      'Task': 'jira',
      'Organization': 'person',
      'Document': 'document',
      'Technology': 'technology',
      'Topic': 'topic'
    };
    return mapping[entityType] || 'topic';
  };

  // 初始化数据
  (0,react.useEffect)(() => {
    initializeMemoryInterface();

    // 额外的安全措施：延迟隐藏loading overlay以防初始化过快
    const hideLoadingTimeout = setTimeout(() => {
      const loadingOverlay = document.getElementById('loading-overlay');
      if (loadingOverlay && !loadingOverlay.classList.contains('hidden')) {
        loadingOverlay.classList.add('hidden');
        console.log('⏰ 延迟隐藏加载遮罩（安全措施）');
      }
    }, 2000);

    // 清理定时器
    return () => {
      clearTimeout(hideLoadingTimeout);
    };
  }, []);

  // 监听搜索变化
  (0,react.useEffect)(() => {
    if (searchQuery.length > 2) {
      performSearch(searchQuery);
    }
  }, [searchQuery]);

  // 初始化接口
  const initializeMemoryInterface = async () => {
    setIsLoading(true);
    console.log('🚀 开始初始化记忆界面...');
    try {
      // 初始化记忆系统
      console.log('🧠 初始化记忆系统...');
      const memoryInitialized = await memorySystem.initialize();
      if (!memoryInitialized) {
        console.warn('⚠️ 记忆系统初始化失败，将使用降级模式');
      }

      // 初始化用户画像系统（通过统一的记忆系统接口）
      console.log('👤 初始化用户画像系统...');
      try {
        const profileData = await memorySystem.getUserProfile();
        setUserProfile(profileData.profile);
        setUserProfileAnalysis(profileData.analysis);
        setUserProfileManager(true); // 标记已初始化
        console.log('✅ 用户画像系统初始化成功');
      } catch (error) {
        console.error('❌ 用户画像系统初始化失败:', error);
      }

      // 加载概览统计
      console.log('📊 加载概览统计...');
      await loadOverviewStats();

      // 加载实体类型统计
      console.log('📋 加载实体类型...');
      await loadEntityTypes();

      // 加载最近时间轴
      if (activeView === 'timeline') {
        console.log('⏰ 加载时间轴...');
        await loadRecentTimeline();
      }
      console.log('✅ 记忆界面初始化完成');
    } catch (error) {
      console.error('❌ 初始化记忆界面失败:', error);
    } finally {
      setIsLoading(false);

      // 直接操作DOM隐藏HTML中的加载遮罩
      const loadingOverlay = document.getElementById('loading-overlay');
      if (loadingOverlay) {
        loadingOverlay.classList.add('hidden');
        console.log('📱 加载遮罩已隐藏');
      }
    }
  };

  // 加载概览统计
  const loadOverviewStats = async () => {
    try {
      console.log('📊 请求实体统计数据...');
      const response = await chrome.runtime.sendMessage({
        type: 'GET_ENTITY_STATISTICS'
      });
      console.log('📊 实体统计响应:', response);
      if (response && response.success) {
        console.log('📊 设置概览统计数据:', response.data);
        setOverviewStats(response.data);
      } else {
        console.warn('📊 获取实体统计失败:', response?.error);
      }
    } catch (error) {
      console.error('❌ 加载概览统计失败:', error);
      // 设置默认数据
      const defaultStats = {
        totalEntities: 0,
        totalRelationships: 0,
        entitiesCreatedToday: 0,
        entitiesCreatedThisWeek: 0,
        entitiesCreatedThisMonth: 0,
        entityCounts: {},
        topEntitiesByType: {}
      };
      console.log('📊 使用默认统计数据:', defaultStats);
      setOverviewStats(defaultStats);
    }
  };

  // 加载实体类型
  const loadEntityTypes = async () => {
    try {
      const response = await chrome.runtime.sendMessage({
        type: 'GET_ENTITY_TYPES'
      });
      if (response && response.success) {
        // 使用新的API响应格式
        if (response.data.entityTypes && Array.isArray(response.data.entityTypes)) {
          const types = response.data.entityTypes.map(entityType => ({
            type: entityType.type,
            name: entityType.name,
            icon: entityType.icon,
            count: entityType.count
          }));
          setEntityTypes(types);
        } else {
          // 向后兼容：使用entityCounts
          console.log('📋 使用向后兼容格式:', response.data.entityCounts);
          const types = Object.entries(response.data.entityCounts || {}).map(_ref => {
            let [type, count] = _ref;
            return {
              type,
              name: memory_ENTITY_TYPE_CONFIG[type]?.name || type,
              icon: memory_ENTITY_TYPE_CONFIG[type]?.icon || '📂',
              count: count
            };
          });
          console.log('📋 设置兼容格式实体类型:', types);
          setEntityTypes(types);
        }
      } else {
        console.warn('📋 获取实体类型失败:', response?.error);
      }
    } catch (error) {
      console.error('❌ 加载实体类型失败:', error);
      // 设置默认类型
      const defaultTypes = Object.entries(memory_ENTITY_TYPE_CONFIG).map(_ref2 => {
        let [type, config] = _ref2;
        return {
          type,
          name: config.name,
          icon: config.icon,
          count: 0
        };
      });
      console.log('📋 使用默认实体类型:', defaultTypes);
      setEntityTypes(defaultTypes);
    }
  };

  // 按类型加载实体
  const loadEntitiesByType = async entityType => {
    setIsLoading(true);
    try {
      const response = await chrome.runtime.sendMessage({
        type: 'GET_ENTITIES_BY_TYPE',
        entityType,
        limit: 50
      });
      if (response && response.success) {
        const entitiesData = response.data || [];
        setEntities(entitiesData);

        // 如果是Topic类型，加载每个主题的最新讨论
        if (entityType === 'Topic') {
          await loadTopicDiscussions(entitiesData);
        }
      }
    } catch (error) {
      console.error('加载实体失败:', error);
      setEntities([]);
    } finally {
      setIsLoading(false);
    }
  };

  // 加载主题最新讨论（优化版：优先使用本地缓存）
  const loadTopicDiscussions = async topics => {
    const discussions = {};
    const topicsNeedingCloudQuery = [];

    // 1. 先尝试从本地缓存获取数据
    for (const topic of topics.slice(0, 10)) {
      // 限制并发数量
      try {
        // 获取缓存的最近数据
        const cachedData = await memorySystem.getEntityDetails(topic.id);
        if (cachedData && cachedData.recentDataDetails?.conversations?.length > 0) {
          // 使用缓存数据，取最新的2条
          discussions[topic.id] = cachedData.recentDataDetails.conversations.slice(0, 2);
          console.log(`📦 主题 ${topic.name} 使用缓存数据 (${cachedData.recentDataDetails.conversations.length} 条)`);
        } else {
          // 缓存中没有数据，需要从云端查询
          topicsNeedingCloudQuery.push(topic);
        }
      } catch (error) {
        console.warn(`获取主题 ${topic.id} 的缓存数据失败:`, error);
        topicsNeedingCloudQuery.push(topic);
      }
    }

    // 2. 对没有缓存的主题进行云端查询（批量处理以提高性能）
    if (topicsNeedingCloudQuery.length > 0) {
      console.log(`☁️ 需要从云端查询 ${topicsNeedingCloudQuery.length} 个主题的数据`);

      // 限制并发数量，避免一次性发起太多请求
      const batchSize = 3;
      for (let i = 0; i < topicsNeedingCloudQuery.length; i += batchSize) {
        const batch = topicsNeedingCloudQuery.slice(i, i + batchSize);
        await Promise.allSettled(batch.map(async topic => {
          try {
            const response = await chrome.runtime.sendMessage({
              type: 'GET_TOPIC_DETAIL',
              topicId: topic.id
            });
            if (response && response.success && response.data.conversations) {
              // 取最新的2条讨论
              const recentConversations = response.data.conversations.slice(0, 2);
              discussions[topic.id] = recentConversations;

              // 缓存前5条数据到本地，供下次使用
              const conversationsToCache = response.data.conversations.slice(0, 5);
              for (const conversation of conversationsToCache) {
                await memorySystem.updateRecentData(topic.id, 'conversation', conversation);
              }
              console.log(`☁️ 主题 ${topic.name} 从云端获取并缓存了 ${conversationsToCache.length} 条数据`);
            } else {
              discussions[topic.id] = [];
            }
          } catch (error) {
            console.warn(`从云端加载主题 ${topic.id} 的讨论失败:`, error);
            discussions[topic.id] = [];
          }
        }));

        // 小延迟避免请求过于密集
        if (i + batchSize < topicsNeedingCloudQuery.length) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }
    }
    setTopicDiscussions(discussions);
    const cachedCount = topics.length - topicsNeedingCloudQuery.length;
    const cloudCount = topicsNeedingCloudQuery.length;
    console.log(`📊 主题讨论加载完成: ${cachedCount} 个使用缓存, ${cloudCount} 个从云端获取`);
  };

  // 执行搜索
  const performSearch = async query => {
    setIsLoading(true);
    try {
      const response = await chrome.runtime.sendMessage({
        type: 'SEARCH_ENTITIES',
        query,
        entityType: selectedEntityType !== 'overview' && selectedEntityType !== 'timeline' ? selectedEntityType : undefined,
        limit: 30
      });
      if (response && response.success) {
        setEntities(response.data || []);
      }
    } catch (error) {
      console.error('搜索实体失败:', error);
      setEntities([]);
    } finally {
      setIsLoading(false);
    }
  };

  // 加载最近时间轴
  const loadRecentTimeline = async () => {
    setIsLoading(true);
    try {
      const response = await chrome.runtime.sendMessage({
        type: 'GET_RECENT_TIMELINE',
        limit: 50
      });
      if (response && response.success) {
        setTimeline(response.data || []);
      }
    } catch (error) {
      console.error('加载时间轴失败:', error);
      setTimeline([]);
    } finally {
      setIsLoading(false);
    }
  };

  // 选择实体类型
  const handleEntityTypeSelect = type => {
    setSelectedEntityType(type);
    setSelectedEntity(null);
    setSearchQuery('');
    if (type === 'overview') {
      setActiveView('overview');
    } else if (type === 'timeline') {
      setActiveView('timeline');
      loadRecentTimeline();
    } else {
      setActiveView('entity-detail');
      loadEntitiesByType(type);
    }
  };

  // 查看实体详情
  const handleEntityClick = async entity => {
    // 记录用户行为到画像系统
    if (userProfileManager) {
      try {
        const userAction = {
          actionType: 'view',
          timestamp: Date.now(),
          context: 'memory_interface',
          weight: 0.1,
          metadata: {
            source: 'entity_list',
            entityType: entity.type
          }
        };
        await memorySystem.updateUserProfile({
          userId: 'default_user',
          action: userAction,
          targetItem: {
            id: entity.id,
            type: mapEntityTypeToProfileType(entity.type),
            name: entity.name,
            metadata: {
              description: entity.description,
              importance: entity.importance,
              tags: entity.tags
            }
          }
        });
      } catch (error) {
        console.error('Failed to update user profile:', error);
      }
    }
    if (entity.type === 'Topic') {
      // 如果是主题，显示主题详情页
      await handleTopicClick(entity);
    } else {
      setSelectedEntity(entity);

      // 更新访问统计
      try {
        await chrome.runtime.sendMessage({
          type: 'UPDATE_ENTITY_ACCESS',
          entityId: entity.id
        });
      } catch (error) {
        console.error('更新实体访问失败:', error);
      }
    }
  };

  // 查看主题详情
  const handleTopicClick = async topic => {
    setSelectedTopic(topic);
    setActiveView('topic-detail');
    setActiveTopicTab('overview');

    // 加载主题详情数据
    await loadTopicDetailData(topic.id);

    // 更新访问统计
    try {
      await chrome.runtime.sendMessage({
        type: 'UPDATE_ENTITY_ACCESS',
        entityId: topic.id
      });
    } catch (error) {
      console.error('更新主题访问失败:', error);
    }
  };

  // 加载主题详情数据（优化版：使用缓存策略）
  const loadTopicDetailData = async topicId => {
    setIsLoading(true);
    try {
      // 1. 先尝试从统一缓存获取完整的主题详情（使用 RECENT_DATA 替代 TOPIC_DETAILS）
      const cachedTopicDetails = await memorySystem.getEntityDetails(topicId);
      if (cachedTopicDetails) {
        console.log(`📦 主题详情页使用统一缓存数据: ${topicId}`);
        setTopicDetailData(cachedTopicDetails);
        setIsLoading(false);
        return;
      }

      // 2. 缓存不存在，从云端获取数据
      console.log(`☁️ 从云端获取主题详情: ${topicId}`);
      const response = await chrome.runtime.sendMessage({
        type: 'GET_TOPIC_DETAIL',
        topicId: topicId
      });
      if (response && response.success) {
        const topicData = response.data;
        setTopicDetailData(topicData);

        // 3. 数据已由 memoryMessageHandler.ts 自动缓存到统一的 RECENT_DATA，无需重复缓存

        console.log(`💾 主题详情已通过统一缓存机制存储: ${topicId}`);
      } else {
        // 如果后端接口不存在，使用模拟数据
        console.log(`🎭 使用模拟数据: ${topicId}`);
        const mockTopicData = {
          overview: {
            discussions: 12,
            projects: 5,
            participants: 8,
            resources: 15
          },
          relatedProjects: [{
            id: 'project-1',
            name: 'Personal-AI',
            status: '开发中',
            description: 'Chrome扩展智能助手'
          }, {
            id: 'project-2',
            name: 'Automation Tools',
            status: '规划中',
            description: 'CI/CD自动化工具链'
          }],
          relatedResources: [{
            id: 'resource-1',
            name: 'AI开发最佳实践',
            type: '技术文档',
            url: '#'
          }, {
            id: 'resource-2',
            name: '自动化工具指南',
            type: '教程',
            url: '#'
          }],
          latestConversations: [{
            id: 'conv-1',
            sender: '张三',
            group: '技术讨论组',
            time: '30分钟前',
            summary: '分享了最新的AI实现方案和技术心得',
            context: [{
              sender: '李四',
              content: '这个AI方案看起来很有潜力',
              time: '35分钟前'
            }, {
              sender: '张三',
              content: '是的，我们可以在下个版本中集成',
              time: '30分钟前',
              isMainMessage: true
            }]
          }],
          latestWebpages: [{
            id: 'webpage-1',
            title: 'AI开发技术文档',
            url: 'https://example.com/ai-docs',
            type: 'docs',
            visitTime: '2小时前',
            summary: '详细介绍了AI开发的关键技术和实现方法',
            tags: ['AI', '技术文档', '开发指南']
          }]
        };
        setTopicDetailData(mockTopicData);
      }
    } catch (error) {
      console.error('加载主题详情失败:', error);
      setTopicDetailData(null);
    } finally {
      setIsLoading(false);
    }
  };

  // 返回主题列表
  const handleBackToTopicList = () => {
    setActiveView('entity-detail');
    setSelectedTopic(null);
    setTopicDetailData(null);
  };

  // 执行搜索
  const handleSearch = () => {
    if (searchQuery.trim()) {
      performSearch(searchQuery.trim());
    }
  };

  // 处理搜索输入
  const handleSearchKeyPress = e => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  // 调试功能
  const handleDiagnoseData = async () => {
    console.log('🔍 开始诊断数据状态...');
    try {
      const response = await chrome.runtime.sendMessage({
        type: 'DIAGNOSE_ENTITY_DATA'
      });
      console.log('🔍 诊断结果:', response);
      if (response.success) {
        const diagnosis = response.data;
        alert(`诊断结果：
实体数量: ${diagnosis.entitiesCount}
关系数量: ${diagnosis.relationshipsCount}
实体类型: ${diagnosis.entityTypes.join(', ')}

问题: ${diagnosis.issues.join('; ')}
建议: ${diagnosis.suggestions.join('; ')}`);
      }
    } catch (error) {
      console.error('诊断失败:', error);
      alert('诊断失败: ' + error.message);
    }
  };
  const handleInitializeSampleData = async () => {
    if (!confirm('确定要初始化示例数据吗？这将创建一些测试实体和关系。')) {
      return;
    }
    console.log('🚀 开始初始化示例数据...');
    try {
      const response = await chrome.runtime.sendMessage({
        type: 'INITIALIZE_SAMPLE_DATA'
      });
      console.log('🚀 初始化结果:', response);
      if (response.success) {
        alert(response.data.message);
        // 刷新界面数据
        await initializeMemoryInterface();
      } else {
        alert('初始化失败: ' + (response.error || response.data?.message));
      }
    } catch (error) {
      console.error('初始化失败:', error);
      alert('初始化失败: ' + error.message);
    }
  };
  const handleRebuildIndexes = async () => {
    if (!confirm('确定要重建实体索引吗？')) {
      return;
    }
    console.log('🔄 开始重建索引...');
    try {
      const response = await chrome.runtime.sendMessage({
        type: 'REBUILD_ENTITY_INDEXES'
      });
      console.log('🔄 重建结果:', response);
      alert(response.message);
      if (response.success) {
        // 刷新界面数据
        await initializeMemoryInterface();
      }
    } catch (error) {
      console.error('重建失败:', error);
      alert('重建失败: ' + error.message);
    }
  };

  // 格式化时间
  const formatTime = timestamp => {
    const now = Date.now();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    if (minutes < 60) return `${minutes}分钟前`;
    if (hours < 24) return `${hours}小时前`;
    if (days < 30) return `${days}天前`;
    return new Date(timestamp).toLocaleDateString();
  };

  // 标记为重点项目
  const handleMarkAsHighlightProject = async entity => {
    try {
      // 获取现有的重点项目列表
      const result = await chrome.storage.local.get('highlightProjects');
      const highlightProjects = result.highlightProjects || [];

      // 检查是否已经是重点项目
      const isAlreadyHighlighted = highlightProjects.some(p => p.id === entity.id);
      if (isAlreadyHighlighted) {
        // 移除重点标记
        const updatedProjects = highlightProjects.filter(p => p.id !== entity.id);
        await chrome.storage.local.set({
          highlightProjects: updatedProjects
        });

        // 可以显示一个提示
        alert(`已将 "${entity.name}" 从重点项目中移除`);
      } else {
        // 添加为重点项目
        const projectInfo = {
          id: entity.id,
          name: entity.name,
          description: entity.description,
          addedAt: Date.now(),
          lastViewed: entity.lastAccessed,
          importance: entity.importance,
          tags: entity.tags || []
        };
        const updatedProjects = [...highlightProjects, projectInfo];
        await chrome.storage.local.set({
          highlightProjects: updatedProjects
        });

        // 设置实体标签，标记为重点项目
        await chrome.runtime.sendMessage({
          type: 'SET_ENTITY_TAGS',
          entityId: entity.id,
          tags: [...(entity.tags || []), 'highlight-project']
        });
        alert(`已将 "${entity.name}" 标记为重点项目`);
      }

      // 刷新当前视图
      if (selectedEntityType === 'Project') {
        loadEntitiesByType('Project');
      }
    } catch (error) {
      console.error('标记重点项目失败:', error);
      alert('操作失败，请稍后重试');
    }
  };

  // 打开项目仪表盘
  const openProjectDashboard = async entity => {
    try {
      // 先确保项目在重点项目列表中
      const result = await chrome.storage.local.get('highlightProjects');
      const highlightProjects = result.highlightProjects || [];
      const isHighlighted = highlightProjects.some(p => p.id === entity.id);
      if (!isHighlighted) {
        // 如果不在重点项目中，询问是否添加
        const shouldAdd = confirm(`"${entity.name}" 不在重点项目列表中，是否添加并打开仪表盘？`);
        if (shouldAdd) {
          await handleMarkAsHighlightProject(entity);
        }
      }

      // 打开项目仪表盘
      const dashboardUrl = chrome.runtime.getURL(`project-dashboard.html?projectId=${entity.id}&projectName=${encodeURIComponent(entity.name)}`);

      // 使用弹窗方式打开
      chrome.windows.create({
        url: dashboardUrl,
        type: 'popup',
        width: 1200,
        height: 900,
        focused: true
      });
    } catch (error) {
      console.error('打开项目仪表盘失败:', error);
      alert('打开仪表盘失败，请稍后重试');
    }
  };

  // 获取实体图标
  const getEntityIcon = type => {
    return memory_ENTITY_TYPE_CONFIG[type]?.icon || '📂';
  };

  // 获取时间轴事件图标
  const getTimelineIcon = type => {
    const icons = {
      'message': '💬',
      'webpage': '🌐',
      'relation_created': '🔗',
      'entity_updated': '📝'
    };
    return icons[type] || '📅';
  };

  // 聊天记录相关函数
  const handleChatSearch = query => {
    setChatSearchQuery(query);
    setChatPage(1); // 重置到第一页
  };
  const handleChatFilter = filter => {
    setChatFilter(filter);
    setChatPage(1); // 重置到第一页
  };
  const toggleConversationExpand = conversationId => {
    const newExpanded = new Set(expandedConversations);
    if (newExpanded.has(conversationId)) {
      newExpanded.delete(conversationId);
    } else {
      // 收缩其他展开的对话
      newExpanded.clear();
      newExpanded.add(conversationId);
    }
    setExpandedConversations(newExpanded);
  };
  const getFilteredConversations = () => {
    if (!topicDetailData?.conversations) return [];
    let filtered = topicDetailData.conversations;

    // 应用搜索过滤
    if (chatSearchQuery.trim()) {
      const query = chatSearchQuery.toLowerCase();
      filtered = filtered.filter(conv => conv.summary.toLowerCase().includes(query) || conv.sender.toLowerCase().includes(query) || conv.group.toLowerCase().includes(query) || conv.originalContent?.toLowerCase().includes(query));
    }

    // 应用群组过滤
    if (chatFilter !== 'all') {
      filtered = filtered.filter(conv => {
        switch (chatFilter) {
          case 'team':
            return conv.group.includes('团队') || conv.group.includes('Team');
          case 'project':
            return conv.group.includes('项目') || conv.group.includes('Project');
          case 'tech':
            return conv.group.includes('技术') || conv.group.includes('Tech') || conv.group.includes('开发');
          default:
            return true;
        }
      });
    }
    return filtered;
  };
  const getPaginatedConversations = () => {
    const filtered = getFilteredConversations();
    const startIndex = (chatPage - 1) * chatPageSize;
    const endIndex = startIndex + chatPageSize;
    return filtered.slice(startIndex, endIndex);
  };
  const getTotalChatPages = () => {
    const filtered = getFilteredConversations();
    return Math.ceil(filtered.length / chatPageSize);
  };
  const highlightText = (text, searchQuery) => {
    if (!searchQuery.trim()) return text;
    const regex = new RegExp(`(${searchQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    return text.replace(regex, '<mark class="highlight">$1</mark>');
  };
  return /*#__PURE__*/react.createElement("div", {
    className: "memory-container"
  }, /*#__PURE__*/react.createElement("div", {
    className: "sidebar"
  }, /*#__PURE__*/react.createElement("div", {
    className: "sidebar-header"
  }, /*#__PURE__*/react.createElement("div", {
    className: "logo"
  }, "\uD83E\uDDE0 \u8BB0\u5FC6\u67E5\u8BE2\u7CFB\u7EDF")), /*#__PURE__*/react.createElement("div", {
    className: "entity-types"
  }, /*#__PURE__*/react.createElement("div", {
    className: `entity-type ${selectedEntityType === 'overview' ? 'active' : ''}`,
    onClick: () => handleEntityTypeSelect('overview')
  }, /*#__PURE__*/react.createElement("div", {
    className: "entity-icon"
  }, "\uD83C\uDFE0"), /*#__PURE__*/react.createElement("div", {
    className: "entity-name"
  }, "\u9996\u9875\u6982\u89C8")), /*#__PURE__*/react.createElement("div", {
    className: `entity-type ${selectedEntityType === 'timeline' ? 'active' : ''}`,
    onClick: () => handleEntityTypeSelect('timeline')
  }, /*#__PURE__*/react.createElement("div", {
    className: "entity-icon"
  }, "\u23F0"), /*#__PURE__*/react.createElement("div", {
    className: "entity-name"
  }, "\u65F6\u95F4\u8F74")), /*#__PURE__*/react.createElement("div", {
    className: `entity-type ${activeView === 'user-profile' ? 'active' : ''}`,
    onClick: () => setActiveView('user-profile')
  }, /*#__PURE__*/react.createElement("div", {
    className: "entity-icon"
  }, "\uD83D\uDC64"), /*#__PURE__*/react.createElement("div", {
    className: "entity-name"
  }, "\u7528\u6237\u753B\u50CF")), /*#__PURE__*/react.createElement("hr", {
    className: "sidebar-divider"
  }), entityTypes.map(entityType => /*#__PURE__*/react.createElement("div", {
    key: entityType.type,
    className: `entity-type ${selectedEntityType === entityType.type ? 'active' : ''}`,
    onClick: () => handleEntityTypeSelect(entityType.type)
  }, /*#__PURE__*/react.createElement("div", {
    className: "entity-icon"
  }, entityType.icon), /*#__PURE__*/react.createElement("div", {
    className: "entity-name"
  }, entityType.name), /*#__PURE__*/react.createElement("div", {
    className: "entity-count"
  }, entityType.count))))), /*#__PURE__*/react.createElement("div", {
    className: "main-content"
  }, /*#__PURE__*/react.createElement("div", {
    className: "search-header"
  }, /*#__PURE__*/react.createElement("div", {
    className: "search-box"
  }, /*#__PURE__*/react.createElement("div", {
    className: "search-icon"
  }, "\uD83D\uDD0D"), /*#__PURE__*/react.createElement("input", {
    type: "text",
    className: "search-input",
    placeholder: "\u641C\u7D22\u4EFB\u4F55\u5185\u5BB9\u3001\u5B9E\u4F53\u6216\u5173\u952E\u8BCD...",
    value: searchQuery,
    onChange: e => setSearchQuery(e.target.value),
    onKeyPress: handleSearchKeyPress
  })), /*#__PURE__*/react.createElement("div", {
    className: "filter-btn",
    onClick: handleSearch
  }, "\uD83D\uDCCA \u641C\u7D22"), /*#__PURE__*/react.createElement("div", {
    className: "filter-btn",
    onClick: () => setSearchQuery('')
  }, "\uD83D\uDD04 \u91CD\u7F6E"), /*#__PURE__*/react.createElement("div", {
    className: "filter-btn debug-btn",
    onClick: handleDiagnoseData,
    title: "\u8BCA\u65AD\u6570\u636E\u72B6\u6001"
  }, "\uD83D\uDD0D \u8BCA\u65AD"), /*#__PURE__*/react.createElement("div", {
    className: "filter-btn debug-btn",
    onClick: handleInitializeSampleData,
    title: "\u521D\u59CB\u5316\u793A\u4F8B\u6570\u636E"
  }, "\uD83D\uDE80 \u793A\u4F8B\u6570\u636E"), /*#__PURE__*/react.createElement("div", {
    className: "filter-btn debug-btn",
    onClick: handleRebuildIndexes,
    title: "\u91CD\u5EFA\u7D22\u5F15"
  }, "\uD83D\uDD04 \u91CD\u5EFA\u7D22\u5F15")), activeView === 'overview' && /*#__PURE__*/react.createElement("div", {
    className: "overview-section"
  }, /*#__PURE__*/react.createElement("div", {
    className: "greeting-card"
  }, /*#__PURE__*/react.createElement("div", {
    className: "greeting-title"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83C\uDF05"), /*#__PURE__*/react.createElement("span", null, "\u6B22\u8FCE\u6765\u5230\u8BB0\u5FC6\u67E5\u8BE2\u7CFB\u7EDF")), /*#__PURE__*/react.createElement("div", {
    className: "greeting-content"
  }, /*#__PURE__*/react.createElement("p", null, "\u60A8\u7684\u4E2A\u4EBA\u77E5\u8BC6\u56FE\u8C31\u4E2D\u5305\u542B:"), /*#__PURE__*/react.createElement("ul", {
    className: "quick-summary"
  }, /*#__PURE__*/react.createElement("li", null, "\uD83D\uDCCA ", overviewStats?.totalEntities || 0, " \u4E2A\u5B9E\u4F53\uFF0C", overviewStats?.totalRelationships || 0, " \u4E2A\u5173\u7CFB"), /*#__PURE__*/react.createElement("li", null, "\uD83D\uDCC8 \u4ECA\u65E5\u65B0\u589E ", overviewStats?.entitiesCreatedToday || 0, " \u4E2A\u5B9E\u4F53"), /*#__PURE__*/react.createElement("li", null, "\uD83D\uDCC5 \u672C\u5468\u65B0\u589E ", overviewStats?.entitiesCreatedThisWeek || 0, " \u4E2A\u5B9E\u4F53"), /*#__PURE__*/react.createElement("li", null, "\uD83D\uDCC6 \u672C\u6708\u65B0\u589E ", overviewStats?.entitiesCreatedThisMonth || 0, " \u4E2A\u5B9E\u4F53")), /*#__PURE__*/react.createElement("p", null, "\u70B9\u51FB\u5DE6\u4FA7\u7C7B\u522B\u5F00\u59CB\u63A2\u7D22\u60A8\u7684\u8BB0\u5FC6 \uD83D\uDC48"))), /*#__PURE__*/react.createElement("div", {
    className: "content-grid"
  }, /*#__PURE__*/react.createElement("div", {
    className: "content-card",
    onClick: () => handleEntityTypeSelect('Project')
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-title"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDE80"), /*#__PURE__*/react.createElement("span", null, "\u4ECA\u65E5\u91CD\u70B9\u9879\u76EE")), /*#__PURE__*/react.createElement("div", {
    className: "card-badge"
  }, entityTypes.find(t => t.type === 'Project')?.count || 0, " \u4E2A\u6D3B\u8DC3")), /*#__PURE__*/react.createElement("div", {
    className: "card-content"
  }, "\u6700\u8FD1\u6D3B\u8DC3\u7684\u9879\u76EE\u548C\u76F8\u5173\u4FE1\u606F"), /*#__PURE__*/react.createElement("div", {
    className: "info-list"
  }, /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDD25"), /*#__PURE__*/react.createElement("span", null, "Personal-AI - Chrome \u6269\u5C55\u5F00\u53D1"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "2 \u5C0F\u65F6\u524D")), /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDCCA"), /*#__PURE__*/react.createElement("span", null, "Data Pipeline - \u6027\u80FD\u4F18\u5316"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "5 \u5C0F\u65F6\u524D")), /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83C\uDFA8"), /*#__PURE__*/react.createElement("span", null, "Design System - \u7EC4\u4EF6\u5E93\u66F4\u65B0"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "1 \u5929\u524D"))), /*#__PURE__*/react.createElement("div", {
    className: "view-more-btn"
  }, /*#__PURE__*/react.createElement("span", null, "\u67E5\u770B\u6240\u6709\u9879\u76EE"), /*#__PURE__*/react.createElement("span", null, "\u2192"))), /*#__PURE__*/react.createElement("div", {
    className: "content-card",
    onClick: () => handleEntityTypeSelect('Topic')
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-title"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDCA1"), /*#__PURE__*/react.createElement("span", null, "\u70ED\u95E8\u4E3B\u9898\u8BA8\u8BBA")), /*#__PURE__*/react.createElement("div", {
    className: "card-badge"
  }, entityTypes.find(t => t.type === 'Topic')?.count || 0, " \u4E2A\u6D3B\u8DC3")), /*#__PURE__*/react.createElement("div", {
    className: "card-content"
  }, "\u6700\u8FD1\u8BA8\u8BBA\u9891\u7E41\u7684\u8BDD\u9898\u548C\u89C2\u70B9"), /*#__PURE__*/react.createElement("div", {
    className: "info-list"
  }, /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83E\uDD16"), /*#__PURE__*/react.createElement("span", null, "AI \u5DE5\u4F5C\u6D41\u81EA\u52A8\u5316\u5B9E\u8DF5"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "30 \u5206\u949F\u524D")), /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\u26A1"), /*#__PURE__*/react.createElement("span", null, "\u524D\u7AEF\u6027\u80FD\u4F18\u5316\u7B56\u7565"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "2 \u5C0F\u65F6\u524D")), /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83C\uDFAF"), /*#__PURE__*/react.createElement("span", null, "\u4EA7\u54C1\u8BBE\u8BA1\u601D\u7EF4\u65B9\u6CD5"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "4 \u5C0F\u65F6\u524D"))), /*#__PURE__*/react.createElement("div", {
    className: "view-more-btn"
  }, /*#__PURE__*/react.createElement("span", null, "\u67E5\u770B\u6240\u6709\u4E3B\u9898"), /*#__PURE__*/react.createElement("span", null, "\u2192"))), /*#__PURE__*/react.createElement("div", {
    className: "content-card",
    onClick: () => handleEntityTypeSelect('People')
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-title"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDC65"), /*#__PURE__*/react.createElement("span", null, "\u91CD\u8981\u8054\u7CFB\u4EBA\u52A8\u6001")), /*#__PURE__*/react.createElement("div", {
    className: "card-badge"
  }, "\u65B0\u6D88\u606F")), /*#__PURE__*/react.createElement("div", {
    className: "card-content"
  }, "\u6765\u81EA\u540C\u4E8B\u548C\u5408\u4F5C\u4F19\u4F34\u7684\u91CD\u8981\u66F4\u65B0"), /*#__PURE__*/react.createElement("div", {
    className: "info-list"
  }, /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDC64"), /*#__PURE__*/react.createElement("span", null, "\u5F20\u4E09 - \u4EE3\u7801\u5BA1\u67E5\u53CD\u9988"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "1 \u5C0F\u65F6\u524D")), /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDC64"), /*#__PURE__*/react.createElement("span", null, "\u674E\u56DB - \u8BBE\u8BA1\u7A3F\u66F4\u65B0\u901A\u77E5"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "3 \u5C0F\u65F6\u524D")), /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDC64"), /*#__PURE__*/react.createElement("span", null, "\u738B\u4E94 - \u4F1A\u8BAE\u7EAA\u8981\u5206\u4EAB"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "6 \u5C0F\u65F6\u524D"))), /*#__PURE__*/react.createElement("div", {
    className: "view-more-btn"
  }, /*#__PURE__*/react.createElement("span", null, "\u67E5\u770B\u6240\u6709\u8054\u7CFB\u4EBA"), /*#__PURE__*/react.createElement("span", null, "\u2192"))), /*#__PURE__*/react.createElement("div", {
    className: "content-card"
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-title"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83C\uDFAF"), /*#__PURE__*/react.createElement("span", null, "AI \u63A8\u8350\u5185\u5BB9")), /*#__PURE__*/react.createElement("div", {
    className: "card-badge"
  }, "\u667A\u80FD\u63A8\u8350")), /*#__PURE__*/react.createElement("div", {
    className: "card-content"
  }, "\u57FA\u4E8E\u4F60\u7684\u5174\u8DA3\u548C\u5DE5\u4F5C\u4E60\u60EF\u63A8\u8350\u7684\u5185\u5BB9"), /*#__PURE__*/react.createElement("div", {
    className: "info-list"
  }, /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDCD6"), /*#__PURE__*/react.createElement("span", null, "\u300AClean Architecture\u300B\u8BFB\u4E66\u7B14\u8BB0\u590D\u4E60"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "\u63A8\u8350")), /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDD27"), /*#__PURE__*/react.createElement("span", null, "Webpack 5 \u8FC1\u79FB\u6307\u5357"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "\u63A8\u8350")), /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDCA1"), /*#__PURE__*/react.createElement("span", null, "React 18 \u65B0\u7279\u6027\u603B\u7ED3"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "\u63A8\u8350"))), /*#__PURE__*/react.createElement("div", {
    className: "view-more-btn"
  }, /*#__PURE__*/react.createElement("span", null, "\u67E5\u770B\u66F4\u591A\u63A8\u8350"), /*#__PURE__*/react.createElement("span", null, "\u2192"))), /*#__PURE__*/react.createElement("div", {
    className: "content-card"
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-title"
  }, /*#__PURE__*/react.createElement("span", null, "\u23F0"), /*#__PURE__*/react.createElement("span", null, "\u4ECA\u65E5\u63D0\u9192\u4E8B\u9879")), /*#__PURE__*/react.createElement("div", {
    className: "card-badge"
  }, "3 \u9879\u5F85\u529E")), /*#__PURE__*/react.createElement("div", {
    className: "card-content"
  }, "\u6765\u81EA\u65E5\u5386\u3001Jira \u548C AI \u751F\u6210\u7684\u5F85\u529E\u4E8B\u9879"), /*#__PURE__*/react.createElement("div", {
    className: "info-list"
  }, /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83C\uDFAF"), /*#__PURE__*/react.createElement("span", null, "\u5B8C\u6210 Personal-AI \u7684\u5355\u5143\u6D4B\u8BD5"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "\u4ECA\u5929")), /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDCDE"), /*#__PURE__*/react.createElement("span", null, "\u4E0E\u4EA7\u54C1\u56E2\u961F\u7684\u540C\u6B65\u4F1A\u8BAE"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "14:00")), /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDCDD"), /*#__PURE__*/react.createElement("span", null, "\u66F4\u65B0\u9879\u76EE\u6587\u6863"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "\u660E\u5929"))), /*#__PURE__*/react.createElement("div", {
    className: "view-more-btn"
  }, /*#__PURE__*/react.createElement("span", null, "\u67E5\u770B\u5B8C\u6574\u65E5\u7A0B"), /*#__PURE__*/react.createElement("span", null, "\u2192"))), /*#__PURE__*/react.createElement("div", {
    className: "content-card"
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-title"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83C\uDF10"), /*#__PURE__*/react.createElement("span", null, "\u6700\u8FD1\u6D4F\u89C8\u8BB0\u5F55")), /*#__PURE__*/react.createElement("div", {
    className: "card-badge"
  }, "\u6280\u672F\u6587\u6863")), /*#__PURE__*/react.createElement("div", {
    className: "card-content"
  }, "\u4F60\u6700\u8FD1\u67E5\u770B\u7684\u6280\u672F\u6587\u6863\u548C\u5B66\u4E60\u8D44\u6E90"), /*#__PURE__*/react.createElement("div", {
    className: "info-list"
  }, /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDCD8"), /*#__PURE__*/react.createElement("span", null, "React Query \u5B98\u65B9\u6587\u6863"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "2 \u5C0F\u65F6\u524D")), /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83C\uDFA8"), /*#__PURE__*/react.createElement("span", null, "Figma API \u5F00\u53D1\u6307\u5357"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "\u6628\u5929")), /*#__PURE__*/react.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/react.createElement("span", null, "\u26A1"), /*#__PURE__*/react.createElement("span", null, "Vite \u6784\u5EFA\u4F18\u5316\u6280\u5DE7"), /*#__PURE__*/react.createElement("span", {
    className: "info-time"
  }, "2 \u5929\u524D"))), /*#__PURE__*/react.createElement("div", {
    className: "view-more-btn"
  }, /*#__PURE__*/react.createElement("span", null, "\u67E5\u770B\u6D4F\u89C8\u5386\u53F2"), /*#__PURE__*/react.createElement("span", null, "\u2192"))))), activeView === 'timeline' && /*#__PURE__*/react.createElement("div", {
    className: "timeline-view"
  }, /*#__PURE__*/react.createElement("h2", null, "\u23F0 \u6700\u8FD1\u6D3B\u52A8\u65F6\u95F4\u8F74"), isLoading ? /*#__PURE__*/react.createElement("div", {
    className: "loading-container"
  }, /*#__PURE__*/react.createElement("div", {
    className: "loading-spinner"
  }), /*#__PURE__*/react.createElement("span", null, "\u52A0\u8F7D\u65F6\u95F4\u8F74\u6570\u636E...")) : /*#__PURE__*/react.createElement("div", {
    className: "timeline-container"
  }, timeline.map((event, index) => /*#__PURE__*/react.createElement("div", {
    key: event.id,
    className: "timeline-item"
  }, /*#__PURE__*/react.createElement("div", {
    className: "timeline-dot"
  }, getTimelineIcon(event.type)), /*#__PURE__*/react.createElement("div", {
    className: "timeline-content"
  }, /*#__PURE__*/react.createElement("div", {
    className: "timeline-time"
  }, formatTime(event.timestamp)), /*#__PURE__*/react.createElement("div", {
    className: "content-card"
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-title"
  }, event.title), /*#__PURE__*/react.createElement("div", {
    className: "card-content"
  }, event.content), event.source && /*#__PURE__*/react.createElement("div", {
    className: "event-source"
  }, "\u6765\u6E90: ", event.source))))), timeline.length === 0 && /*#__PURE__*/react.createElement("div", {
    className: "empty-state"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDCED"), /*#__PURE__*/react.createElement("p", null, "\u6682\u65E0\u65F6\u95F4\u8F74\u6570\u636E")))), activeView === 'topic-detail' && selectedTopic && /*#__PURE__*/react.createElement("div", {
    className: "topic-detail"
  }, /*#__PURE__*/react.createElement("div", {
    className: "detail-header"
  }, /*#__PURE__*/react.createElement("button", {
    className: "back-btn",
    onClick: handleBackToTopicList
  }, /*#__PURE__*/react.createElement("span", null, "\u2190"), /*#__PURE__*/react.createElement("span", null, "\u8FD4\u56DE\u4E3B\u9898\u5217\u8868")), /*#__PURE__*/react.createElement("div", {
    className: "topic-header"
  }, /*#__PURE__*/react.createElement("div", {
    className: "topic-avatar"
  }, getEntityIcon(selectedTopic.type)), /*#__PURE__*/react.createElement("div", {
    className: "topic-info"
  }, /*#__PURE__*/react.createElement("h2", null, selectedTopic.name), /*#__PURE__*/react.createElement("div", {
    className: "topic-meta"
  }, /*#__PURE__*/react.createElement("span", {
    className: "meta-item"
  }, "\uD83D\uDCC8 ", topicDetailData?.overview?.discussions || 0, " \u6761\u8BA8\u8BBA"), /*#__PURE__*/react.createElement("span", {
    className: "meta-item"
  }, "\uD83D\uDD17 ", topicDetailData?.overview?.projects || 0, " \u4E2A\u5173\u8054\u9879\u76EE"), /*#__PURE__*/react.createElement("span", {
    className: "meta-item"
  }, "\u23F0 \u6700\u540E\u66F4\u65B0\uFF1A", formatTime(selectedTopic.lastAccessed || Date.now())))), /*#__PURE__*/react.createElement("div", {
    className: "topic-actions"
  }, /*#__PURE__*/react.createElement("button", {
    className: "action-btn"
  }, "\uD83D\uDCDD \u7F16\u8F91\u4E3B\u9898"), /*#__PURE__*/react.createElement("button", {
    className: "action-btn"
  }, "\uD83D\uDD17 \u6DFB\u52A0\u5173\u8054")))), /*#__PURE__*/react.createElement("div", {
    className: "topic-detail-content"
  }, /*#__PURE__*/react.createElement("div", {
    className: "tab-navigation"
  }, /*#__PURE__*/react.createElement("button", {
    className: `tab-btn ${activeTopicTab === 'overview' ? 'active' : ''}`,
    onClick: () => setActiveTopicTab('overview')
  }, "\uD83D\uDCCA \u6982\u89C8"), /*#__PURE__*/react.createElement("button", {
    className: `tab-btn ${activeTopicTab === 'projects' ? 'active' : ''}`,
    onClick: () => setActiveTopicTab('projects')
  }, "\uD83D\uDE80 \u76F8\u5173\u9879\u76EE"), /*#__PURE__*/react.createElement("button", {
    className: `tab-btn ${activeTopicTab === 'resources' ? 'active' : ''}`,
    onClick: () => setActiveTopicTab('resources')
  }, "\uD83D\uDCDA \u76F8\u5173\u8D44\u6E90"), /*#__PURE__*/react.createElement("button", {
    className: `tab-btn ${activeTopicTab === 'conversations' ? 'active' : ''}`,
    onClick: () => setActiveTopicTab('conversations')
  }, "\uD83D\uDCAC \u804A\u5929\u8BB0\u5F55"), /*#__PURE__*/react.createElement("button", {
    className: `tab-btn ${activeTopicTab === 'webpages' ? 'active' : ''}`,
    onClick: () => setActiveTopicTab('webpages')
  }, "\uD83C\uDF10 \u7F51\u9875\u8BB0\u5F55")), activeTopicTab === 'overview' && /*#__PURE__*/react.createElement("div", {
    className: "tab-content active"
  }, /*#__PURE__*/react.createElement("div", {
    className: "overview-grid"
  }, /*#__PURE__*/react.createElement("div", {
    className: "summary-card"
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-title"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDCC8"), /*#__PURE__*/react.createElement("span", null, "\u4E3B\u9898\u7EDF\u8BA1"))), /*#__PURE__*/react.createElement("div", {
    className: "stats-grid"
  }, /*#__PURE__*/react.createElement("div", {
    className: "stat-item"
  }, /*#__PURE__*/react.createElement("div", {
    className: "stat-number"
  }, topicDetailData?.overview?.discussions || 0), /*#__PURE__*/react.createElement("div", {
    className: "stat-label"
  }, "\u8BA8\u8BBA\u6761\u6570")), /*#__PURE__*/react.createElement("div", {
    className: "stat-item"
  }, /*#__PURE__*/react.createElement("div", {
    className: "stat-number"
  }, topicDetailData?.overview?.projects || 0), /*#__PURE__*/react.createElement("div", {
    className: "stat-label"
  }, "\u76F8\u5173\u9879\u76EE")), /*#__PURE__*/react.createElement("div", {
    className: "stat-item"
  }, /*#__PURE__*/react.createElement("div", {
    className: "stat-number"
  }, topicDetailData?.overview?.participants || 0), /*#__PURE__*/react.createElement("div", {
    className: "stat-label"
  }, "\u53C2\u4E0E\u4EBA\u5458")), /*#__PURE__*/react.createElement("div", {
    className: "stat-item"
  }, /*#__PURE__*/react.createElement("div", {
    className: "stat-number"
  }, topicDetailData?.overview?.resources || 0), /*#__PURE__*/react.createElement("div", {
    className: "stat-label"
  }, "\u76F8\u5173\u8D44\u6E90")))))), activeTopicTab === 'projects' && /*#__PURE__*/react.createElement("div", {
    className: "tab-content active"
  }, /*#__PURE__*/react.createElement("div", {
    className: "section-header"
  }, /*#__PURE__*/react.createElement("h3", null, "\uD83D\uDCC2 \u76F8\u5173\u9879\u76EE"), /*#__PURE__*/react.createElement("button", {
    className: "add-btn"
  }, "+ \u6DFB\u52A0\u9879\u76EE")), /*#__PURE__*/react.createElement("div", {
    className: "items-grid"
  }, topicDetailData?.relatedProjects?.map(project => /*#__PURE__*/react.createElement("div", {
    key: project.id,
    className: "item-card"
  }, /*#__PURE__*/react.createElement("div", {
    className: "item-header"
  }, /*#__PURE__*/react.createElement("div", {
    className: "item-title"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDE80"), /*#__PURE__*/react.createElement("span", null, project.name)), /*#__PURE__*/react.createElement("div", {
    className: "item-actions"
  }, /*#__PURE__*/react.createElement("button", {
    className: "item-action",
    title: "\u53D6\u6D88\u5173\u8054"
  }, "\u274C"))), /*#__PURE__*/react.createElement("div", {
    className: "item-content"
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-badge-container"
  }, /*#__PURE__*/react.createElement("span", {
    className: "card-badge"
  }, project.status)), /*#__PURE__*/react.createElement("p", null, project.description)))))), activeTopicTab === 'resources' && /*#__PURE__*/react.createElement("div", {
    className: "tab-content active"
  }, /*#__PURE__*/react.createElement("div", {
    className: "section-header"
  }, /*#__PURE__*/react.createElement("h3", null, "\uD83D\uDCDA \u76F8\u5173\u8D44\u6E90"), /*#__PURE__*/react.createElement("button", {
    className: "add-btn"
  }, "+ \u6DFB\u52A0\u8D44\u6E90")), /*#__PURE__*/react.createElement("div", {
    className: "items-grid"
  }, topicDetailData?.relatedResources?.map(resource => /*#__PURE__*/react.createElement("div", {
    key: resource.id,
    className: "item-card"
  }, /*#__PURE__*/react.createElement("div", {
    className: "item-header"
  }, /*#__PURE__*/react.createElement("div", {
    className: "item-title"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDCDA"), /*#__PURE__*/react.createElement("span", null, resource.name)), /*#__PURE__*/react.createElement("div", {
    className: "item-actions"
  }, /*#__PURE__*/react.createElement("button", {
    className: "item-action",
    title: "\u5220\u9664\u8D44\u6E90"
  }, "\u274C"))), /*#__PURE__*/react.createElement("div", {
    className: "item-content"
  }, /*#__PURE__*/react.createElement("div", {
    className: "card-badge-container"
  }, /*#__PURE__*/react.createElement("span", {
    className: "card-badge"
  }, resource.type)), /*#__PURE__*/react.createElement("p", null, /*#__PURE__*/react.createElement("a", {
    href: resource.url,
    style: {
      color: '#60a5fa'
    }
  }, "\u67E5\u770B\u8D44\u6E90"))))))), activeTopicTab === 'conversations' && /*#__PURE__*/react.createElement("div", {
    className: "tab-content active"
  }, /*#__PURE__*/react.createElement("div", {
    className: "section-header"
  }, /*#__PURE__*/react.createElement("h3", null, "\uD83D\uDCAC \u804A\u5929\u8BB0\u5F55"), /*#__PURE__*/react.createElement("div", {
    className: "search-controls"
  }, /*#__PURE__*/react.createElement("input", {
    type: "text",
    className: "search-input",
    placeholder: "\u641C\u7D22\u804A\u5929\u8BB0\u5F55...",
    value: chatSearchQuery,
    onChange: e => handleChatSearch(e.target.value)
  }), /*#__PURE__*/react.createElement("select", {
    className: "filter-select",
    value: chatFilter,
    onChange: e => handleChatFilter(e.target.value)
  }, /*#__PURE__*/react.createElement("option", {
    value: "all"
  }, "\u5168\u90E8\u7FA4\u7EC4"), /*#__PURE__*/react.createElement("option", {
    value: "team"
  }, "\u56E2\u961F\u7FA4"), /*#__PURE__*/react.createElement("option", {
    value: "project"
  }, "\u9879\u76EE\u7FA4"), /*#__PURE__*/react.createElement("option", {
    value: "tech"
  }, "\u6280\u672F\u8BA8\u8BBA")))), /*#__PURE__*/react.createElement("div", {
    className: "conversations-list"
  }, getPaginatedConversations().map(conv => {
    const isExpanded = expandedConversations.has(conv.id);
    return /*#__PURE__*/react.createElement("div", {
      key: conv.id,
      className: `conversation-item ${isExpanded ? 'expanded' : ''}`
    }, /*#__PURE__*/react.createElement("div", {
      className: "conversation-header"
    }, /*#__PURE__*/react.createElement("div", {
      className: "conversation-meta"
    }, /*#__PURE__*/react.createElement("div", {
      className: "sender-avatar"
    }, conv.sender.charAt(0)), /*#__PURE__*/react.createElement("div", {
      className: "sender-info"
    }, /*#__PURE__*/react.createElement("div", {
      className: "sender-name"
    }, conv.sender), /*#__PURE__*/react.createElement("div", {
      className: "group-name"
    }, conv.group))), /*#__PURE__*/react.createElement("div", {
      className: "conversation-time"
    }, conv.time)), /*#__PURE__*/react.createElement("div", {
      className: "conversation-summary",
      dangerouslySetInnerHTML: {
        __html: highlightText(conv.summary, chatSearchQuery)
      }
    }), conv.matchedRules && conv.matchedRules.length > 0 && /*#__PURE__*/react.createElement("div", {
      className: "matched-rules"
    }, /*#__PURE__*/react.createElement("span", {
      className: "rules-label"
    }, "\u5339\u914D\u89C4\u5219:"), conv.matchedRules.map((rule, index) => /*#__PURE__*/react.createElement("span", {
      key: index,
      className: "rule-tag"
    }, rule))), /*#__PURE__*/react.createElement("div", {
      className: `context-indicator ${isExpanded ? 'expanded' : ''}`,
      onClick: () => toggleConversationExpand(conv.id)
    }, /*#__PURE__*/react.createElement("span", {
      className: "indicator-text"
    }, isExpanded ? '🔼 收起上下文' : `🔍 查看上下文 (${conv.context?.length || 0} 条相关消息)`)), isExpanded && conv.context && conv.context.length > 0 && /*#__PURE__*/react.createElement("div", {
      className: "context-content expanded"
    }, /*#__PURE__*/react.createElement("div", {
      className: "context-divider"
    }), conv.context.map((contextMsg, index) => /*#__PURE__*/react.createElement("div", {
      key: index,
      className: `context-item ${contextMsg.isMainMessage ? 'main-message' : ''}`
    }, /*#__PURE__*/react.createElement("div", {
      className: "context-header"
    }, /*#__PURE__*/react.createElement("div", {
      className: "context-sender"
    }, contextMsg.sender), /*#__PURE__*/react.createElement("div", {
      className: "context-time"
    }, contextMsg.time || contextMsg.datetime)), /*#__PURE__*/react.createElement("div", {
      className: "context-content-text",
      dangerouslySetInnerHTML: {
        __html: contextMsg.isMainMessage ? highlightText(contextMsg.content, chatSearchQuery) : contextMsg.content
      }
    }))), conv.teamUrl && /*#__PURE__*/react.createElement("div", {
      className: "context-actions"
    }, /*#__PURE__*/react.createElement("a", {
      href: conv.teamUrl,
      target: "_blank",
      rel: "noopener noreferrer",
      className: "view-in-team-btn"
    }, "\uD83D\uDD17 \u5728\u56E2\u961F\u4E2D\u67E5\u770B\u5B8C\u6574\u5BF9\u8BDD"))));
  })), getTotalChatPages() > 1 && /*#__PURE__*/react.createElement("div", {
    className: "pagination"
  }, /*#__PURE__*/react.createElement("button", {
    className: "page-btn",
    disabled: chatPage === 1,
    onClick: () => setChatPage(chatPage - 1)
  }, "\u4E0A\u4E00\u9875"), /*#__PURE__*/react.createElement("span", {
    className: "page-info"
  }, "\u7B2C ", chatPage, " \u9875\uFF0C\u5171 ", getTotalChatPages(), " \u9875 (", getFilteredConversations().length, " \u6761\u8BB0\u5F55)"), /*#__PURE__*/react.createElement("button", {
    className: "page-btn",
    disabled: chatPage === getTotalChatPages(),
    onClick: () => setChatPage(chatPage + 1)
  }, "\u4E0B\u4E00\u9875"))), activeTopicTab === 'webpages' && /*#__PURE__*/react.createElement("div", {
    className: "tab-content active"
  }, /*#__PURE__*/react.createElement("div", {
    className: "section-header"
  }, /*#__PURE__*/react.createElement("h3", null, "\uD83C\uDF10 \u7F51\u9875\u8BB0\u5F55"), /*#__PURE__*/react.createElement("div", {
    className: "search-controls"
  }, /*#__PURE__*/react.createElement("input", {
    type: "text",
    className: "search-input",
    placeholder: "\u641C\u7D22\u7F51\u9875\u8BB0\u5F55..."
  }), /*#__PURE__*/react.createElement("select", {
    className: "filter-select"
  }, /*#__PURE__*/react.createElement("option", {
    value: "all"
  }, "\u5168\u90E8\u7C7B\u578B"), /*#__PURE__*/react.createElement("option", {
    value: "docs"
  }, "\u6587\u6863"), /*#__PURE__*/react.createElement("option", {
    value: "blog"
  }, "\u535A\u5BA2"), /*#__PURE__*/react.createElement("option", {
    value: "github"
  }, "GitHub")))), /*#__PURE__*/react.createElement("div", {
    className: "webpages-list"
  }, topicDetailData?.webpages?.map(webpage => /*#__PURE__*/react.createElement("div", {
    key: webpage.id,
    className: "webpage-item"
  }, /*#__PURE__*/react.createElement("div", {
    className: "webpage-header"
  }, /*#__PURE__*/react.createElement("div", {
    className: "webpage-icon"
  }, "\uD83C\uDF10"), /*#__PURE__*/react.createElement("div", {
    className: "webpage-info"
  }, /*#__PURE__*/react.createElement("div", {
    className: "webpage-title"
  }, webpage.title), /*#__PURE__*/react.createElement("div", {
    className: "webpage-url"
  }, webpage.url), /*#__PURE__*/react.createElement("div", {
    className: "webpage-meta"
  }, /*#__PURE__*/react.createElement("span", null, "\u8BBF\u95EE\u65F6\u95F4\uFF1A", webpage.visitTime)))), /*#__PURE__*/react.createElement("div", {
    className: "webpage-content"
  }, webpage.summary), /*#__PURE__*/react.createElement("div", {
    className: "webpage-tags"
  }, webpage.tags?.map((tag, index) => /*#__PURE__*/react.createElement("span", {
    key: index,
    className: "webpage-tag"
  }, tag))))))))), activeView === 'entity-detail' && /*#__PURE__*/react.createElement("div", {
    className: "entity-detail"
  }, /*#__PURE__*/react.createElement("div", {
    className: "entity-header"
  }, /*#__PURE__*/react.createElement("div", {
    className: "entity-avatar"
  }, getEntityIcon(selectedEntityType)), /*#__PURE__*/react.createElement("div", {
    className: "entity-info"
  }, /*#__PURE__*/react.createElement("h2", null, memory_ENTITY_TYPE_CONFIG[selectedEntityType]?.name || selectedEntityType), /*#__PURE__*/react.createElement("div", {
    className: "entity-meta"
  }, "\u5171 ", entities.length, " \u4E2A", memory_ENTITY_TYPE_CONFIG[selectedEntityType]?.name || '实体', searchQuery && ` • 搜索: "${searchQuery}"`))), isLoading ? /*#__PURE__*/react.createElement("div", {
    className: "loading-container"
  }, /*#__PURE__*/react.createElement("div", {
    className: "loading-spinner"
  }), /*#__PURE__*/react.createElement("span", null, "\u52A0\u8F7D\u5B9E\u4F53\u6570\u636E...")) : /*#__PURE__*/react.createElement("div", {
    className: "entities-grid"
  }, entities.map(entity => /*#__PURE__*/react.createElement("div", {
    key: entity.id,
    className: "entity-card",
    onClick: () => handleEntityClick(entity)
  }, /*#__PURE__*/react.createElement("div", {
    className: "entity-card-header"
  }, /*#__PURE__*/react.createElement("div", {
    className: "entity-card-title"
  }, /*#__PURE__*/react.createElement("span", null, getEntityIcon(entity.type)), /*#__PURE__*/react.createElement("span", null, entity.name)), entity.importance !== undefined && /*#__PURE__*/react.createElement("div", {
    className: "importance-indicator"
  }, /*#__PURE__*/react.createElement("div", {
    className: "importance-bar",
    style: {
      width: `${entity.importance * 100}%`
    }
  }))), entity.description && /*#__PURE__*/react.createElement("div", {
    className: "entity-description"
  }, entity.description), /*#__PURE__*/react.createElement("div", {
    className: "entity-stats"
  }, /*#__PURE__*/react.createElement("div", {
    className: "stat-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDD17"), /*#__PURE__*/react.createElement("span", null, entity.relationshipsCount || 0, " \u5173\u7CFB")), /*#__PURE__*/react.createElement("div", {
    className: "stat-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDCAC"), /*#__PURE__*/react.createElement("span", null, entity.relatedMessagesCount || 0, " \u6D88\u606F")), /*#__PURE__*/react.createElement("div", {
    className: "stat-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83C\uDF10"), /*#__PURE__*/react.createElement("span", null, entity.relatedWebpagesCount || 0, " \u7F51\u9875")), /*#__PURE__*/react.createElement("div", {
    className: "stat-item"
  }, /*#__PURE__*/react.createElement("span", null, "\uD83D\uDC41\uFE0F"), /*#__PURE__*/react.createElement("span", null, entity.accessCount || 0, " \u8BBF\u95EE"))), entity.type === 'Topic' && /*#__PURE__*/react.createElement("div", {
    className: "topic-preview"
  }, /*#__PURE__*/react.createElement("h4", {
    className: "preview-title"
  }, "\uD83D\uDCAC \u6700\u65B0\u8BA8\u8BBA"), /*#__PURE__*/react.createElement("div", {
    className: "preview-messages"
  }, topicDiscussions[entity.id] && topicDiscussions[entity.id].length > 0 ? topicDiscussions[entity.id].map((conversation, idx) => /*#__PURE__*/react.createElement("div", {
    key: idx,
    className: "preview-message"
  }, /*#__PURE__*/react.createElement("span", {
    className: "message-sender"
  }, conversation.sender), /*#__PURE__*/react.createElement("span", {
    className: "message-content"
  }, conversation.summary.length > 30 ? conversation.summary.substring(0, 30) + '...' : conversation.summary), /*#__PURE__*/react.createElement("span", {
    className: "message-time"
  }, conversation.time))) : /*#__PURE__*/react.createElement("div", {
    className: "preview-message"
  }, /*#__PURE__*/react.createElement("span", {
    className: "message-content",
    style: {
      color: '#888',
      fontStyle: 'italic'
    }
  }, "\u6682\u65E0\u76F8\u5173\u8BA8\u8BBA"))), /*#__PURE__*/react.createElement("h4", {
    className: "preview-title"
  }, "\uD83D\uDD17 \u5173\u8054\u9879\u76EE"), /*#__PURE__*/react.createElement("div", {
    className: "preview-projects"
  }, /*#__PURE__*/react.createElement("div", {
    className: "preview-project"
  }, /*#__PURE__*/react.createElement("span", {
    className: "project-icon"
  }, "\uD83D\uDE80"), /*#__PURE__*/react.createElement("span", {
    className: "project-name"
  }, "Personal-AI"), /*#__PURE__*/react.createElement("span", {
    className: "project-status"
  }, "\u5F00\u53D1\u4E2D")), /*#__PURE__*/react.createElement("div", {
    className: "preview-project"
  }, /*#__PURE__*/react.createElement("span", {
    className: "project-icon"
  }, "\uD83D\uDD27"), /*#__PURE__*/react.createElement("span", {
    className: "project-name"
  }, "Automation Tools"), /*#__PURE__*/react.createElement("span", {
    className: "project-status"
  }, "\u89C4\u5212\u4E2D"))), /*#__PURE__*/react.createElement("h4", {
    className: "preview-title"
  }, "\uD83D\uDCDA \u76F8\u5173\u8D44\u6E90"), /*#__PURE__*/react.createElement("div", {
    className: "preview-resources"
  }, /*#__PURE__*/react.createElement("div", {
    className: "preview-resource"
  }, /*#__PURE__*/react.createElement("span", {
    className: "resource-icon"
  }, "\uD83D\uDCD6"), /*#__PURE__*/react.createElement("span", {
    className: "resource-name"
  }, "\u6280\u672F\u6587\u6863")), /*#__PURE__*/react.createElement("div", {
    className: "preview-resource"
  }, /*#__PURE__*/react.createElement("span", {
    className: "resource-icon"
  }, "\uD83D\uDCA1"), /*#__PURE__*/react.createElement("span", {
    className: "resource-name"
  }, "\u6700\u4F73\u5B9E\u8DF5")))), entity.type === 'Project' && /*#__PURE__*/react.createElement("div", {
    className: "project-actions"
  }, /*#__PURE__*/react.createElement("button", {
    className: "project-action-btn highlight",
    onClick: e => {
      e.stopPropagation();
      handleMarkAsHighlightProject(entity);
    },
    title: "\u6807\u8BB0\u4E3A\u91CD\u70B9\u9879\u76EE"
  }, "\u2B50 \u91CD\u70B9\u9879\u76EE"), /*#__PURE__*/react.createElement("button", {
    className: "project-action-btn dashboard",
    onClick: e => {
      e.stopPropagation();
      openProjectDashboard(entity);
    },
    title: "\u6253\u5F00\u9879\u76EE\u4EEA\u8868\u76D8"
  }, "\uD83D\uDCCA \u4EEA\u8868\u76D8")), entity.tags && entity.tags.length > 0 && /*#__PURE__*/react.createElement("div", {
    className: "entity-tags"
  }, entity.tags.slice(0, 3).map((tag, index) => /*#__PURE__*/react.createElement("span", {
    key: index,
    className: "entity-tag"
  }, tag)), entity.tags.length > 3 && /*#__PURE__*/react.createElement("span", {
    className: "entity-tag more-tags"
  }, "+", entity.tags.length - 3)), /*#__PURE__*/react.createElement("div", {
    className: "entity-footer"
  }, /*#__PURE__*/react.createElement("span", {
    className: "last-accessed"
  }, "\u6700\u540E\u8BBF\u95EE: ", formatTime(entity.lastAccessed || Date.now())), entity.status && /*#__PURE__*/react.createElement("span", {
    className: `status-indicator ${entity.status}`
  }, entity.status)))), entities.length === 0 && !isLoading && /*#__PURE__*/react.createElement("div", {
    className: "empty-state"
  }, /*#__PURE__*/react.createElement("span", null, getEntityIcon(selectedEntityType)), /*#__PURE__*/react.createElement("p", null, "\u6682\u65E0", memory_ENTITY_TYPE_CONFIG[selectedEntityType]?.name || '实体', "\u6570\u636E"), searchQuery && /*#__PURE__*/react.createElement("p", null, "\u5C1D\u8BD5\u4FEE\u6539\u641C\u7D22\u6761\u4EF6\u6216\u6E05\u7A7A\u641C\u7D22\u6846")))), activeView === 'user-profile' && /*#__PURE__*/react.createElement("div", {
    className: "user-profile-section"
  }, /*#__PURE__*/react.createElement("div", {
    className: "profile-header"
  }, /*#__PURE__*/react.createElement("h2", null, "\uD83D\uDC64 \u7528\u6237\u753B\u50CF\u5206\u6790"), /*#__PURE__*/react.createElement("p", null, "\u57FA\u4E8E\u60A8\u7684\u884C\u4E3A\u6A21\u5F0F\u548C\u5174\u8DA3\u504F\u597D\u751F\u6210\u7684\u4E2A\u6027\u5316\u753B\u50CF")), userProfile && userProfileAnalysis ? /*#__PURE__*/react.createElement("div", {
    className: "profile-content"
  }, /*#__PURE__*/react.createElement("div", {
    className: "profile-card"
  }, /*#__PURE__*/react.createElement("h3", null, "\uD83C\uDFAF \u5F53\u524D\u5173\u6CE8\u91CD\u70B9"), /*#__PURE__*/react.createElement("div", {
    className: "interest-grid"
  }, /*#__PURE__*/react.createElement("div", {
    className: "interest-category"
  }, /*#__PURE__*/react.createElement("h4", null, "\uD83D\uDCC1 \u9879\u76EE"), /*#__PURE__*/react.createElement("div", {
    className: "interest-list"
  }, userProfileAnalysis.topInterests.projects.map((project, idx) => /*#__PURE__*/react.createElement("div", {
    key: idx,
    className: "interest-item"
  }, /*#__PURE__*/react.createElement("span", {
    className: "interest-icon"
  }, "\uD83D\uDE80"), /*#__PURE__*/react.createElement("span", null, project))))), /*#__PURE__*/react.createElement("div", {
    className: "interest-category"
  }, /*#__PURE__*/react.createElement("h4", null, "\uD83D\uDC65 \u4EBA\u5458"), /*#__PURE__*/react.createElement("div", {
    className: "interest-list"
  }, userProfileAnalysis.topInterests.people.map((person, idx) => /*#__PURE__*/react.createElement("div", {
    key: idx,
    className: "interest-item"
  }, /*#__PURE__*/react.createElement("span", {
    className: "interest-icon"
  }, "\uD83D\uDC64"), /*#__PURE__*/react.createElement("span", null, person))))), /*#__PURE__*/react.createElement("div", {
    className: "interest-category"
  }, /*#__PURE__*/react.createElement("h4", null, "\uD83D\uDCA1 \u4E3B\u9898"), /*#__PURE__*/react.createElement("div", {
    className: "interest-list"
  }, userProfileAnalysis.topInterests.topics.map((topic, idx) => /*#__PURE__*/react.createElement("div", {
    key: idx,
    className: "interest-item"
  }, /*#__PURE__*/react.createElement("span", {
    className: "interest-icon"
  }, "\uD83D\uDCAD"), /*#__PURE__*/react.createElement("span", null, topic))))))), /*#__PURE__*/react.createElement("div", {
    className: "profile-card"
  }, /*#__PURE__*/react.createElement("h3", null, "\uD83D\uDD0D \u884C\u4E3A\u6D1E\u5BDF"), /*#__PURE__*/react.createElement("div", {
    className: "insights-grid"
  }, /*#__PURE__*/react.createElement("div", {
    className: "insight-item"
  }, /*#__PURE__*/react.createElement("h4", null, "\u23F0 \u5DE5\u4F5C\u6A21\u5F0F"), /*#__PURE__*/react.createElement("p", null, userProfileAnalysis.insights.workingPattern)), /*#__PURE__*/react.createElement("div", {
    className: "insight-item"
  }, /*#__PURE__*/react.createElement("h4", null, "\uD83E\uDD1D \u534F\u4F5C\u98CE\u683C"), /*#__PURE__*/react.createElement("p", null, userProfileAnalysis.insights.collaborationStyle)), /*#__PURE__*/react.createElement("div", {
    className: "insight-item"
  }, /*#__PURE__*/react.createElement("h4", null, "\uD83C\uDF93 \u4E13\u4E1A\u9886\u57DF"), /*#__PURE__*/react.createElement("div", {
    className: "tag-list"
  }, userProfileAnalysis.insights.focusAreas.map((area, idx) => /*#__PURE__*/react.createElement("span", {
    key: idx,
    className: "focus-tag"
  }, area)))))), /*#__PURE__*/react.createElement("div", {
    className: "profile-card"
  }, /*#__PURE__*/react.createElement("h3", null, "\uD83D\uDCA1 \u667A\u80FD\u63A8\u8350"), /*#__PURE__*/react.createElement("div", {
    className: "suggestions-list"
  }, userProfileAnalysis.insights.suggestedContent.map((suggestion, idx) => /*#__PURE__*/react.createElement("div", {
    key: idx,
    className: "suggestion-item"
  }, /*#__PURE__*/react.createElement("span", {
    className: "suggestion-icon"
  }, "\uD83D\uDCCC"), /*#__PURE__*/react.createElement("span", null, suggestion))))), userProfileAnalysis.predictedInterests.length > 0 && /*#__PURE__*/react.createElement("div", {
    className: "profile-card"
  }, /*#__PURE__*/react.createElement("h3", null, "\uD83D\uDD2E \u9884\u6D4B\u60A8\u53EF\u80FD\u611F\u5174\u8DA3\u7684\u5185\u5BB9"), /*#__PURE__*/react.createElement("div", {
    className: "predictions-list"
  }, userProfileAnalysis.predictedInterests.map((prediction, idx) => /*#__PURE__*/react.createElement("div", {
    key: idx,
    className: "prediction-item"
  }, /*#__PURE__*/react.createElement("div", {
    className: "prediction-header"
  }, /*#__PURE__*/react.createElement("span", {
    className: "prediction-type"
  }, prediction.type), /*#__PURE__*/react.createElement("span", {
    className: "prediction-confidence"
  }, "\u7F6E\u4FE1\u5EA6: ", Math.round(prediction.confidence * 100), "%")), /*#__PURE__*/react.createElement("div", {
    className: "prediction-content"
  }, /*#__PURE__*/react.createElement("strong", null, prediction.item), /*#__PURE__*/react.createElement("p", null, prediction.reason)))))), /*#__PURE__*/react.createElement("div", {
    className: "profile-card"
  }, /*#__PURE__*/react.createElement("h3", null, "\uD83D\uDCCA \u6D3B\u52A8\u7EDF\u8BA1"), /*#__PURE__*/react.createElement("div", {
    className: "stats-grid"
  }, /*#__PURE__*/react.createElement("div", {
    className: "stat-card"
  }, /*#__PURE__*/react.createElement("div", {
    className: "stat-value"
  }, userProfile.statistics.totalInteractions), /*#__PURE__*/react.createElement("div", {
    className: "stat-label"
  }, "\u603B\u4EA4\u4E92\u6B21\u6570")), /*#__PURE__*/react.createElement("div", {
    className: "stat-card"
  }, /*#__PURE__*/react.createElement("div", {
    className: "stat-value"
  }, userProfile.statistics.averageDailyActivity.toFixed(1)), /*#__PURE__*/react.createElement("div", {
    className: "stat-label"
  }, "\u65E5\u5747\u6D3B\u52A8")), /*#__PURE__*/react.createElement("div", {
    className: "stat-card"
  }, /*#__PURE__*/react.createElement("div", {
    className: "stat-value"
  }, userProfile.interests.projects.length), /*#__PURE__*/react.createElement("div", {
    className: "stat-label"
  }, "\u5173\u6CE8\u9879\u76EE\u6570")), /*#__PURE__*/react.createElement("div", {
    className: "stat-card"
  }, /*#__PURE__*/react.createElement("div", {
    className: "stat-value"
  }, userProfile.interests.people.length), /*#__PURE__*/react.createElement("div", {
    className: "stat-label"
  }, "\u534F\u4F5C\u4EBA\u5458\u6570"))))) : /*#__PURE__*/react.createElement("div", {
    className: "loading-container"
  }, /*#__PURE__*/react.createElement("div", {
    className: "loading-spinner"
  }), /*#__PURE__*/react.createElement("span", null, "\u52A0\u8F7D\u7528\u6237\u753B\u50CF\u6570\u636E...")))), /*#__PURE__*/react.createElement("style", null, `
        .memory-container {
          display: flex;
          min-height: 100vh;
          font-family: 'SF Pro Display', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          background: linear-gradient(135deg, #0c0c0c 0%, #1a1a2e 50%, #16213e 100%);
          color: #ffffff;
        }

        /* 左侧导航样式 */
        .sidebar {
          width: 280px;
          background: rgba(15, 23, 42, 0.8);
          backdrop-filter: blur(20px);
          border-right: 1px solid rgba(148, 163, 184, 0.1);
          padding: 2rem 0;
        }

        .sidebar-header {
          padding: 0 2rem 2rem;
          border-bottom: 1px solid rgba(148, 163, 184, 0.1);
        }

        .logo {
          font-size: 1.5rem;
          font-weight: 700;
          background: linear-gradient(135deg, #60a5fa, #a78bfa);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .entity-types {
          padding: 1.5rem 0;
        }

        .entity-type {
          display: flex;
          align-items: center;
          padding: 0.75rem 2rem;
          margin: 0.25rem 0;
          cursor: pointer;
          transition: all 0.3s ease;
          border-left: 3px solid transparent;
        }

        .entity-type:hover {
          background: rgba(59, 130, 246, 0.1);
          border-left-color: #60a5fa;
        }

        .entity-type.active {
          background: rgba(59, 130, 246, 0.2);
          border-left-color: #60a5fa;
        }

        .entity-icon {
          width: 1.5rem;
          height: 1.5rem;
          margin-right: 0.75rem;
          font-size: 1.2rem;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .entity-name {
          font-weight: 500;
          flex: 1;
          font-size: 1rem;
        }

        .entity-count {
          background: rgba(59, 130, 246, 0.2);
          color: #60a5fa;
          padding: 0.25rem 0.5rem;
          border-radius: 0.75rem;
          font-size: 0.875rem;
          font-weight: 600;
        }

        .sidebar-divider {
          margin: 1rem 0;
          border: none;
          border-top: 1px solid rgba(148, 163, 184, 0.1);
        }

        /* 主内容区样式 */
        .main-content {
          flex: 1;
          padding: 2rem;
          overflow-y: auto;
        }

        /* 搜索头部样式 */
        .search-header {
          display: flex;
          align-items: center;
          gap: 1rem;
          margin-bottom: 2rem;
        }

        .search-box {
          flex: 1;
          position: relative;
        }

        .search-input {
          width: 100%;
          padding: 0.75rem 1rem 0.75rem 3rem;
          background: rgba(15, 23, 42, 0.6);
          border: 1px solid rgba(148, 163, 184, 0.2);
          border-radius: 0.75rem;
          color: #ffffff;
          font-size: 1rem;
          transition: all 0.3s ease;
        }

        .search-input:focus {
          outline: none;
          border-color: #60a5fa;
          box-shadow: 0 0 0 3px rgba(96, 165, 250, 0.1);
        }

        .search-input::placeholder {
          color: #64748b;
        }

        .search-icon {
          position: absolute;
          left: 1rem;
          top: 50%;
          transform: translateY(-50%);
          color: #64748b;
        }

        .filter-btn {
          padding: 0.75rem 1.5rem;
          background: rgba(59, 130, 246, 0.1);
          border: 1px solid rgba(59, 130, 246, 0.3);
          border-radius: 0.75rem;
          color: #60a5fa;
          cursor: pointer;
          transition: all 0.3s ease;
          white-space: nowrap;
        }

        .filter-btn:hover {
          background: rgba(59, 130, 246, 0.2);
        }

        .filter-btn.debug-btn {
          background: rgba(255, 165, 0, 0.1);
          border-color: rgba(255, 165, 0, 0.3);
          color: #ffb366;
          font-size: 0.75rem;
        }

        .filter-btn.debug-btn:hover {
          background: rgba(255, 165, 0, 0.2);
        }

        /* 概览部分样式 */
        .overview-section {
          animation: fadeInUp 0.6s ease-out;
        }

        .greeting-card {
          background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(147, 51, 234, 0.1));
          border: 1px solid rgba(59, 130, 246, 0.2);
          border-radius: 1rem;
          padding: 2rem;
          margin-bottom: 2rem;
          backdrop-filter: blur(10px);
        }

        .greeting-title {
          font-size: 1.75rem;
          font-weight: 600;
          margin-bottom: 1rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .greeting-content {
          color: #cbd5e1;
          line-height: 1.6;
          font-size: 1.1rem;
        }

        .quick-summary {
          list-style: none;
          margin: 1rem 0;
          padding: 0;
        }

        .quick-summary li {
          padding: 0.5rem 0;
          border-left: 3px solid #60a5fa;
          padding-left: 1rem;
          margin: 0.5rem 0;
        }

        /* 内容网格样式 */
        .content-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
          gap: 1.5rem;
          margin-bottom: 2rem;
        }

        .content-card {
          background: rgba(15, 23, 42, 0.6);
          border: 1px solid rgba(148, 163, 184, 0.1);
          border-radius: 1rem;
          padding: 1.5rem;
          transition: all 0.3s ease;
          backdrop-filter: blur(10px);
          cursor: pointer;
        }

        .content-card:hover {
          transform: translateY(-2px);
          border-color: rgba(59, 130, 246, 0.3);
          box-shadow: 0 8px 32px rgba(59, 130, 246, 0.1);
        }

        .card-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 1rem;
        }

        .card-title {
          font-size: 1.1rem;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .card-badge {
          background: rgba(59, 130, 246, 0.2);
          color: #60a5fa;
          padding: 0.25rem 0.75rem;
          border-radius: 1rem;
          font-size: 0.875rem;
          font-weight: 500;
        }

        .card-content {
          color: #cbd5e1;
          line-height: 1.5;
          margin-bottom: 1rem;
          font-size: 1rem;
        }

        .info-list {
          margin: 1rem 0;
        }

        .info-item {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem 0;
          border-bottom: 1px solid rgba(148, 163, 184, 0.1);
          transition: all 0.3s ease;
        }

        .info-item:hover {
          background: rgba(59, 130, 246, 0.05);
          border-radius: 0.5rem;
          padding-left: 0.5rem;
        }

        .info-item:last-child {
          border-bottom: none;
        }

        .info-time {
          color: #64748b;
          font-size: 0.875rem;
          margin-left: auto;
        }

        .view-more-btn {
          display: inline-flex;
          align-items: center;
          gap: 0.5rem;
          color: #60a5fa;
          font-size: 0.875rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .view-more-btn:hover {
          color: #93c5fd;
        }

        /* 时间轴样式 */
        .timeline-view {
          animation: fadeInUp 0.6s ease-out;
        }

        .timeline-view h2 {
          margin-bottom: 2rem;
          font-size: 1.5rem;
          font-weight: 600;
        }

        .timeline-container {
          position: relative;
        }

        .timeline-item {
          display: flex;
          gap: 1rem;
          margin-bottom: 1.5rem;
          position: relative;
        }

        .timeline-item:not(:last-child)::before {
          content: '';
          position: absolute;
          left: 1.25rem;
          top: 3rem;
          width: 2px;
          height: calc(100% + 1rem);
          background: linear-gradient(to bottom, #60a5fa, rgba(96, 165, 250, 0.3));
        }

        .timeline-dot {
          width: 2.5rem;
          height: 2.5rem;
          border-radius: 50%;
          background: linear-gradient(135deg, #60a5fa, #a78bfa);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1rem;
          color: white;
          flex-shrink: 0;
          z-index: 1;
        }

        .timeline-content {
          flex: 1;
        }

        .timeline-time {
          color: #64748b;
          font-size: 0.875rem;
          margin-bottom: 0.5rem;
        }

        .event-source {
          color: #94a3b8;
          font-size: 0.75rem;
          margin-top: 0.5rem;
        }

        /* 实体详情样式 */
        .entity-detail {
          animation: fadeInUp 0.6s ease-out;
        }

        .entity-header {
          display: flex;
          align-items: center;
          gap: 1rem;
          margin-bottom: 2rem;
          padding-bottom: 1rem;
          border-bottom: 1px solid rgba(148, 163, 184, 0.1);
        }

        .entity-avatar {
          width: 3rem;
          height: 3rem;
          border-radius: 50%;
          background: linear-gradient(135deg, #60a5fa, #a78bfa);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.5rem;
        }

        .entity-info h2 {
          font-size: 1.75rem;
          font-weight: 600;
          margin-bottom: 0.25rem;
        }

        .entity-meta {
          color: #64748b;
          font-size: 1rem;
        }

        /* 实体网格样式 */
        .entities-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
          gap: 1rem;
        }

        .entity-card {
          background: rgba(15, 23, 42, 0.6);
          border: 1px solid rgba(148, 163, 184, 0.1);
          border-radius: 0.75rem;
          padding: 1rem;
          transition: all 0.3s ease;
          cursor: pointer;
        }

        .entity-card:hover {
          border-color: rgba(59, 130, 246, 0.3);
          transform: translateY(-2px);
        }

        .entity-card-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 0.5rem;
        }

        .entity-card-title {
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-size: 1.1rem;
        }

        .importance-indicator {
          width: 60px;
          height: 4px;
          background: rgba(148, 163, 184, 0.2);
          border-radius: 2px;
          overflow: hidden;
        }

        .importance-bar {
          height: 100%;
          background: linear-gradient(90deg, #60a5fa, #a78bfa);
          transition: width 0.3s ease;
        }

        .entity-description {
          color: #cbd5e1;
          font-size: 0.875rem;
          line-height: 1.5;
          margin-bottom: 0.75rem;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .entity-stats {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 0.5rem;
          margin-bottom: 0.75rem;
        }

        .stat-item {
          display: flex;
          align-items: center;
          gap: 0.25rem;
          font-size: 0.75rem;
          color: #94a3b8;
        }

        .entity-tags {
          display: flex;
          gap: 0.25rem;
          flex-wrap: wrap;
          margin-bottom: 0.75rem;
        }

        .entity-tag {
          padding: 0.125rem 0.375rem;
          background: rgba(59, 130, 246, 0.2);
          color: #60a5fa;
          border-radius: 0.25rem;
          font-size: 0.625rem;
        }

        .entity-tag.more-tags {
          background: rgba(148, 163, 184, 0.2);
          color: #94a3b8;
        }

        .entity-footer {
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 0.75rem;
          color: #64748b;
        }

        /* 主题预览样式 */
        .topic-preview {
          margin-top: 1rem;
          border-top: 1px solid rgba(148, 163, 184, 0.1);
          padding-top: 1rem;
        }

        .preview-title {
          font-size: 0.875rem;
          font-weight: 600;
          color: #60a5fa;
          margin-bottom: 0.5rem;
          margin-top: 0.75rem;
        }

        .preview-title:first-child {
          margin-top: 0;
        }

        .preview-messages, .preview-projects, .preview-resources {
          margin-bottom: 0.75rem;
        }

        .preview-message {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.375rem 0;
          border-bottom: 1px solid rgba(148, 163, 184, 0.05);
          font-size: 0.75rem;
        }

        .preview-message:last-child {
          border-bottom: none;
        }

        .message-sender {
          font-weight: 600;
          color: #93c5fd;
          min-width: 3rem;
        }

        .message-content {
          flex: 1;
          color: #cbd5e1;
        }

        .message-time {
          color: #64748b;
          font-size: 0.625rem;
          min-width: 4rem;
          text-align: right;
        }

        .preview-project, .preview-resource {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.25rem 0;
          font-size: 0.75rem;
        }

        .project-icon, .resource-icon {
          width: 1rem;
          font-size: 0.875rem;
        }

        .project-name, .resource-name {
          flex: 1;
          color: #cbd5e1;
        }

        .project-status {
          padding: 0.125rem 0.375rem;
          background: rgba(59, 130, 246, 0.2);
          color: #60a5fa;
          border-radius: 0.25rem;
          font-size: 0.625rem;
        }

        /* 项目操作按钮样式 */
        .project-actions {
          display: flex;
          gap: 0.5rem;
          margin-bottom: 0.75rem;
        }

        .project-action-btn {
          padding: 0.375rem 0.75rem;
          border: none;
          border-radius: 0.375rem;
          font-size: 0.75rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.3s ease;
          flex: 1;
        }

        .project-action-btn.highlight {
          background: linear-gradient(135deg, #f59e0b, #d97706);
          color: white;
        }

        .project-action-btn.highlight:hover {
          background: linear-gradient(135deg, #d97706, #b45309);
          transform: translateY(-1px);
        }

        .project-action-btn.dashboard {
          background: linear-gradient(135deg, #6366f1, #8b5cf6);
          color: white;
        }

        .project-action-btn.dashboard:hover {
          background: linear-gradient(135deg, #4f46e5, #7c3aed);
          transform: translateY(-1px);
        }

        .last-accessed {
          color: #64748b;
        }

        .status-indicator {
          padding: 0.125rem 0.375rem;
          border-radius: 0.25rem;
          font-size: 0.625rem;
          font-weight: 500;
        }

        .status-indicator.active {
          background: rgba(34, 197, 94, 0.2);
          color: #22c55e;
        }

        .status-indicator.inactive {
          background: rgba(148, 163, 184, 0.2);
          color: #94a3b8;
        }

        /* 加载和空状态样式 */
        .loading-container {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 3rem;
          color: #94a3b8;
        }

        .loading-spinner {
          width: 2rem;
          height: 2rem;
          border: 2px solid rgba(96, 165, 250, 0.3);
          border-top: 2px solid #60a5fa;
          border-radius: 50%;
          animation: spin 1s linear infinite;
          margin-bottom: 1rem;
        }

        .empty-state {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 3rem;
          color: #94a3b8;
          text-align: center;
        }

        .empty-state span {
          font-size: 3rem;
          margin-bottom: 1rem;
        }

        /* 动画 */
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }

        /* 主题详情页样式 */
        .topic-detail {
          animation: fadeInUp 0.6s ease-out;
        }

        .detail-header {
          margin-bottom: 2rem;
        }

        .back-btn {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          background: rgba(59, 130, 246, 0.1);
          border: 1px solid rgba(59, 130, 246, 0.3);
          border-radius: 0.5rem;
          padding: 0.75rem 1.5rem;
          color: #60a5fa;
          cursor: pointer;
          transition: all 0.3s ease;
          margin-bottom: 1.5rem;
        }

        .back-btn:hover {
          background: rgba(59, 130, 246, 0.2);
        }

        .topic-header {
          display: flex;
          align-items: center;
          gap: 1.5rem;
          background: rgba(15, 23, 42, 0.6);
          border: 1px solid rgba(148, 163, 184, 0.1);
          border-radius: 1rem;
          padding: 2rem;
          backdrop-filter: blur(10px);
        }

        .topic-avatar {
          width: 4rem;
          height: 4rem;
          border-radius: 1rem;
          background: linear-gradient(135deg, #60a5fa, #a78bfa);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 2rem;
          flex-shrink: 0;
        }

        .topic-info {
          flex: 1;
        }

        .topic-info h2 {
          font-size: 1.75rem;
          font-weight: 600;
          margin-bottom: 0.75rem;
        }

        .topic-meta {
          display: flex;
          gap: 1.5rem;
          flex-wrap: wrap;
        }

        .meta-item {
          color: #94a3b8;
          font-size: 0.875rem;
        }

        .topic-actions {
          display: flex;
          gap: 0.75rem;
        }

        .action-btn {
          padding: 0.75rem 1.5rem;
          background: rgba(59, 130, 246, 0.1);
          border: 1px solid rgba(59, 130, 246, 0.3);
          border-radius: 0.5rem;
          color: #60a5fa;
          cursor: pointer;
          transition: all 0.3s ease;
          white-space: nowrap;
        }

        .action-btn:hover {
          background: rgba(59, 130, 246, 0.2);
        }

        /* 选项卡样式 */
        .tab-navigation {
          display: flex;
          gap: 0.5rem;
          margin-bottom: 2rem;
          border-bottom: 1px solid rgba(148, 163, 184, 0.1);
          padding-bottom: 1rem;
          overflow-x: auto;
        }

        .tab-btn {
          padding: 0.75rem 1.5rem;
          background: transparent;
          border: none;
          border-radius: 0.5rem;
          color: #94a3b8;
          cursor: pointer;
          transition: all 0.3s ease;
          white-space: nowrap;
          font-size: 0.875rem;
        }

        .tab-btn.active {
          background: rgba(59, 130, 246, 0.2);
          color: #60a5fa;
        }

        .tab-btn:hover:not(.active) {
          background: rgba(59, 130, 246, 0.1);
          color: #93c5fd;
        }

        /* 选项卡内容 */
        .tab-content {
          display: block;
          animation: fadeInUp 0.4s ease-out;
        }

        /* 概览页面 */
        .overview-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
          gap: 1.5rem;
        }

        .summary-card {
          background: rgba(15, 23, 42, 0.6);
          border: 1px solid rgba(148, 163, 184, 0.1);
          border-radius: 1rem;
          padding: 1.5rem;
          backdrop-filter: blur(10px);
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 1rem;
          margin-top: 1rem;
        }

        .stat-item {
          text-align: center;
          padding: 1rem;
          background: rgba(59, 130, 246, 0.1);
          border-radius: 0.75rem;
        }

        .stat-number {
          font-size: 1.75rem;
          font-weight: 700;
          color: #60a5fa;
        }

        .stat-label {
          font-size: 0.875rem;
          color: #94a3b8;
          margin-top: 0.25rem;
        }

        /* 列表项样式 */
        .section-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 1.5rem;
        }

        .section-header h3 {
          font-size: 1.25rem;
          font-weight: 600;
        }

        .add-btn {
          padding: 0.75rem 1.5rem;
          background: rgba(34, 197, 94, 0.1);
          border: 1px solid rgba(34, 197, 94, 0.3);
          border-radius: 0.5rem;
          color: #22c55e;
          cursor: pointer;
          transition: all 0.3s ease;
          font-size: 1rem;
        }

        .add-btn:hover {
          background: rgba(34, 197, 94, 0.2);
        }

        .items-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
          gap: 1rem;
        }

        .item-card {
          background: rgba(15, 23, 42, 0.6);
          border: 1px solid rgba(148, 163, 184, 0.1);
          border-radius: 0.75rem;
          padding: 1rem;
          transition: all 0.3s ease;
          cursor: pointer;
        }

        .item-card:hover {
          border-color: rgba(59, 130, 246, 0.3);
          transform: translateY(-2px);
        }

        .item-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 0.5rem;
        }

        .item-title {
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-size: 1.1rem;
        }

        .item-actions {
          display: flex;
          gap: 0.25rem;
        }

        .item-action {
          padding: 0.25rem;
          background: transparent;
          border: none;
          border-radius: 0.25rem;
          color: #94a3b8;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .item-action:hover {
          background: rgba(239, 68, 68, 0.1);
          color: #ef4444;
        }

        .item-content {
          color: #cbd5e1;
          font-size: 1rem;
          line-height: 1.5;
        }

        .card-badge-container {
          margin-bottom: 0.5rem;
        }

        /* 搜索控件 */
        .search-controls {
          display: flex;
          gap: 1rem;
          align-items: center;
        }

        .filter-select {
          padding: 0.75rem;
          background: rgba(15, 23, 42, 0.6);
          border: 1px solid rgba(148, 163, 184, 0.2);
          border-radius: 0.5rem;
          color: #ffffff;
          min-width: 120px;
          font-size: 1rem;
        }

        /* 聊天记录样式 */
        .conversations-list {
          margin-bottom: 2rem;
        }

        .conversation-item {
          background: rgba(15, 23, 42, 0.6);
          border: 1px solid rgba(148, 163, 184, 0.1);
          border-radius: 0.75rem;
          padding: 1rem;
          margin-bottom: 1rem;
          position: relative;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .conversation-item:hover {
          border-color: rgba(59, 130, 246, 0.3);
        }

        .conversation-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 0.75rem;
        }

        .conversation-meta {
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .sender-avatar {
          width: 2.5rem;
          height: 2.5rem;
          border-radius: 50%;
          background: linear-gradient(135deg, #60a5fa, #a78bfa);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1rem;
        }

        .sender-info {
          display: flex;
          flex-direction: column;
          gap: 0.25rem;
        }

        .sender-name {
          font-weight: 600;
          font-size: 1rem;
        }

        .group-name {
          font-size: 0.875rem;
          color: #94a3b8;
        }

        .conversation-time {
          font-size: 0.875rem;
          color: #64748b;
        }

        .conversation-summary {
          color: #cbd5e1;
          line-height: 1.5;
          margin-bottom: 0.5rem;
          font-size: 1rem;
        }

        /* 匹配规则样式 */
        .matched-rules {
          margin: 0.75rem 0;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          flex-wrap: wrap;
        }

        .rules-label {
          font-size: 0.875rem;
          color: #94a3b8;
          font-weight: 500;
        }

        .rule-tag {
          background: rgba(34, 197, 94, 0.2);
          color: #4ade80;
          padding: 0.25rem 0.5rem;
          border-radius: 0.375rem;
          font-size: 0.75rem;
          font-weight: 500;
        }

        /* 上下文指示器样式 */
        .context-indicator {
          margin-top: 0.75rem;
          padding: 0.5rem 0.75rem;
          background: rgba(59, 130, 246, 0.1);
          border: 1px solid rgba(59, 130, 246, 0.3);
          border-radius: 0.5rem;
          cursor: pointer;
          transition: all 0.3s ease;
          user-select: none;
        }

        .context-indicator:hover {
          background: rgba(59, 130, 246, 0.2);
          border-color: rgba(59, 130, 246, 0.5);
        }

        .context-indicator.expanded {
          background: rgba(59, 130, 246, 0.2);
          border-color: rgba(59, 130, 246, 0.4);
        }

        .indicator-text {
          font-size: 0.875rem;
          color: #60a5fa;
          font-weight: 500;
        }

        /* 上下文内容样式 */
        .context-content {
          max-height: 0;
          overflow: hidden;
          transition: max-height 0.3s ease;
        }

        .context-content.expanded {
          max-height: 500px;
          overflow-y: auto;
        }

        .context-divider {
          height: 1px;
          background: linear-gradient(90deg, transparent, rgba(148, 163, 184, 0.3), transparent);
          margin: 1rem 0;
        }

        .context-item {
          background: rgba(30, 41, 59, 0.4);
          border: 1px solid rgba(148, 163, 184, 0.1);
          border-radius: 0.5rem;
          padding: 0.75rem;
          margin-bottom: 0.5rem;
          transition: all 0.3s ease;
        }

        .context-item:last-child {
          margin-bottom: 0;
        }

        .context-item.main-message {
          border-color: rgba(34, 197, 94, 0.3);
          background: rgba(34, 197, 94, 0.1);
        }

        .context-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 0.5rem;
        }

        .context-sender {
          font-weight: 600;
          font-size: 0.875rem;
          color: #e2e8f0;
        }

        .context-time {
          font-size: 0.75rem;
          color: #94a3b8;
        }

        .context-content-text {
          color: #cbd5e1;
          line-height: 1.5;
          font-size: 0.875rem;
        }

        .context-actions {
          margin-top: 1rem;
          padding-top: 0.75rem;
          border-top: 1px solid rgba(148, 163, 184, 0.1);
        }

        .view-in-team-btn {
          display: inline-flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem 1rem;
          background: rgba(59, 130, 246, 0.1);
          border: 1px solid rgba(59, 130, 246, 0.3);
          border-radius: 0.5rem;
          color: #60a5fa;
          text-decoration: none;
          font-size: 0.875rem;
          font-weight: 500;
          transition: all 0.3s ease;
        }

        .view-in-team-btn:hover {
          background: rgba(59, 130, 246, 0.2);
          border-color: rgba(59, 130, 246, 0.5);
          transform: translateY(-1px);
        }

        /* 高亮样式 */
        .highlight {
          background: rgba(251, 191, 36, 0.3);
          color: #fbbf24;
          padding: 0.125rem 0.25rem;
          border-radius: 0.25rem;
          font-weight: 600;
        }

        /* 分页样式改进 */
        .pagination {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 1rem;
          margin-top: 2rem;
          padding: 1rem 0;
          border-top: 1px solid rgba(148, 163, 184, 0.1);
        }

        .page-btn {
          background: rgba(59, 130, 246, 0.1);
          border: 1px solid rgba(59, 130, 246, 0.3);
          border-radius: 0.5rem;
          color: #60a5fa;
          padding: 0.5rem 1rem;
          font-size: 0.875rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .page-btn:hover:not(:disabled) {
          background: rgba(59, 130, 246, 0.2);
          border-color: rgba(59, 130, 246, 0.5);
          transform: translateY(-1px);
        }

        .page-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .page-info {
          font-size: 0.875rem;
          color: #94a3b8;
          font-weight: 500;
        }

        /* 网页记录样式 */
        .webpages-list {
          margin-bottom: 2rem;
        }

        .webpage-item {
          background: rgba(15, 23, 42, 0.6);
          border: 1px solid rgba(148, 163, 184, 0.1);
          border-radius: 0.75rem;
          padding: 1rem;
          margin-bottom: 1rem;
          transition: all 0.3s ease;
        }

        .webpage-item:hover {
          border-color: rgba(59, 130, 246, 0.3);
          transform: translateY(-1px);
        }

        .webpage-header {
          display: flex;
          align-items: flex-start;
          gap: 1rem;
          margin-bottom: 0.75rem;
        }

        .webpage-icon {
          width: 2.5rem;
          height: 2.5rem;
          border-radius: 0.5rem;
          background: linear-gradient(135deg, #60a5fa, #a78bfa);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.25rem;
          flex-shrink: 0;
        }

        .webpage-info {
          flex: 1;
          min-width: 0;
        }

        .webpage-title {
          font-weight: 600;
          margin-bottom: 0.25rem;
          font-size: 1.1rem;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .webpage-url {
          font-size: 0.875rem;
          color: #60a5fa;
          margin-bottom: 0.5rem;
          word-break: break-all;
        }

        .webpage-meta {
          display: flex;
          gap: 1rem;
          font-size: 0.875rem;
          color: #94a3b8;
        }

        .webpage-content {
          color: #cbd5e1;
          font-size: 1rem;
          line-height: 1.5;
          margin-bottom: 0.75rem;
          display: -webkit-box;
          -webkit-line-clamp: 3;
          line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .webpage-tags {
          display: flex;
          gap: 0.5rem;
          flex-wrap: wrap;
        }

        .webpage-tag {
          padding: 0.25rem 0.5rem;
          background: rgba(59, 130, 246, 0.2);
          color: #60a5fa;
          border-radius: 0.25rem;
          font-size: 0.875rem;
        }
        
        /* 用户画像样式 */
        .user-profile-section {
          max-width: 1200px;
          margin: 0 auto;
        }
        
        .profile-header {
          text-align: center;
          margin-bottom: 3rem;
        }
        
        .profile-header h2 {
          font-size: 2.5rem;
          font-weight: 700;
          background: linear-gradient(135deg, #60a5fa, #a78bfa);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          margin-bottom: 1rem;
        }
        
        .profile-header p {
          color: #94a3b8;
          font-size: 1.1rem;
        }
        
        .profile-content {
          display: grid;
          gap: 2rem;
        }
        
        .profile-card {
          background: rgba(30, 41, 59, 0.8);
          backdrop-filter: blur(10px);
          border: 1px solid rgba(148, 163, 184, 0.2);
          border-radius: 1rem;
          padding: 2rem;
          transition: all 0.3s ease;
        }
        
        .profile-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        
        .profile-card h3 {
          font-size: 1.5rem;
          font-weight: 600;
          margin-bottom: 1.5rem;
          color: #e2e8f0;
        }
        
        .interest-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 1.5rem;
        }
        
        .interest-category h4 {
          color: #94a3b8;
          font-size: 1rem;
          margin-bottom: 1rem;
        }
        
        .interest-list {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
        }
        
        .interest-item {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          padding: 0.75rem 1rem;
          background: rgba(59, 130, 246, 0.1);
          border-radius: 0.5rem;
          transition: all 0.2s ease;
        }
        
        .interest-item:hover {
          background: rgba(59, 130, 246, 0.2);
          transform: translateX(4px);
        }
        
        .insights-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 1.5rem;
        }
        
        .insight-item {
          padding: 1.25rem;
          background: rgba(15, 23, 42, 0.6);
          border-radius: 0.75rem;
          border: 1px solid rgba(148, 163, 184, 0.1);
        }
        
        .insight-item h4 {
          color: #60a5fa;
          margin-bottom: 0.75rem;
          font-size: 1.1rem;
        }
        
        .insight-item p {
          color: #cbd5e1;
          line-height: 1.6;
        }
        
        .tag-list {
          display: flex;
          flex-wrap: wrap;
          gap: 0.5rem;
        }
        
        .focus-tag {
          padding: 0.25rem 0.75rem;
          background: rgba(139, 92, 246, 0.2);
          color: #a78bfa;
          border-radius: 1rem;
          font-size: 0.875rem;
        }
        
        .suggestions-list {
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }
        
        .suggestion-item {
          display: flex;
          align-items: center;
          gap: 1rem;
          padding: 1rem 1.25rem;
          background: rgba(16, 185, 129, 0.1);
          border-radius: 0.75rem;
          border: 1px solid rgba(16, 185, 129, 0.2);
          transition: all 0.2s ease;
        }
        
        .suggestion-item:hover {
          background: rgba(16, 185, 129, 0.2);
          transform: translateX(4px);
        }
        
        .predictions-list {
          display: grid;
          gap: 1rem;
        }
        
        .prediction-item {
          padding: 1.25rem;
          background: rgba(251, 191, 36, 0.1);
          border-radius: 0.75rem;
          border: 1px solid rgba(251, 191, 36, 0.2);
        }
        
        .prediction-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 0.75rem;
        }
        
        .prediction-type {
          padding: 0.25rem 0.75rem;
          background: rgba(251, 191, 36, 0.2);
          color: #fbbf24;
          border-radius: 0.5rem;
          font-size: 0.875rem;
          text-transform: uppercase;
        }
        
        .prediction-confidence {
          color: #94a3b8;
          font-size: 0.875rem;
        }
        
        .prediction-content strong {
          color: #f3f4f6;
          display: block;
          margin-bottom: 0.5rem;
        }
        
        .prediction-content p {
          color: #cbd5e1;
          font-size: 0.9rem;
        }
        
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 1rem;
        }
        
        .stat-card {
          padding: 1.5rem;
          background: rgba(15, 23, 42, 0.6);
          border-radius: 0.75rem;
          text-align: center;
          border: 1px solid rgba(148, 163, 184, 0.1);
        }
        
        .stat-value {
          font-size: 2rem;
          font-weight: 700;
          color: #60a5fa;
          margin-bottom: 0.5rem;
        }
        
        .stat-label {
          color: #94a3b8;
          font-size: 0.875rem;
        }

        /* 响应式设计 */
        @media (max-width: 768px) {
          .memory-container {
            flex-direction: column;
          }

          .sidebar {
            width: 100%;
            height: auto;
            position: static;
          }

          .main-content {
            padding: 1rem;
          }

          .content-grid,
          .entities-grid {
            grid-template-columns: 1fr;
          }

          .search-header {
            flex-direction: column;
            gap: 0.5rem;
          }

          .search-box {
            width: 100%;
          }

          .topic-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
          }

          .topic-actions {
            width: 100%;
            justify-content: stretch;
          }

          .action-btn {
            flex: 1;
          }

          .tab-navigation {
            overflow-x: auto;
          }
        }
      `));
};

// 用户画像功能已集成到统一的记忆系统中

// 导出用户画像相关功能，通过统一的记忆系统接口
window.getUserProfile = async () => {
  try {
    await memorySystem.initialize();
    return await memorySystem.getUserProfile();
  } catch (error) {
    console.error('Failed to get user profile:', error);
    return {
      profile: null,
      analysis: null
    };
  }
};

// 创建全局更新用户画像的函数
window.updateUserProfile = async update => {
  try {
    await memorySystem.initialize();
    return await memorySystem.updateUserProfile(update);
  } catch (error) {
    console.error('Failed to update user profile:', error);
    return false;
  }
};

// 创建全局设置用户重要性的函数
window.setUserExplicitImportance = async (itemId, type, importance) => {
  try {
    await memorySystem.initialize();
    return await memorySystem.setUserExplicitImportance(itemId, type, importance);
  } catch (error) {
    console.error('Failed to set user importance:', error);
    return false;
  }
};

// 渲染组件
react_dom.render(/*#__PURE__*/react.createElement(react.StrictMode, null, /*#__PURE__*/react.createElement(MemoryInterface, null)), document.getElementById('memory-root'));
})();

/******/ })()
;
//# sourceMappingURL=memory.js.map