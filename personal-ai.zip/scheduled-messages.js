/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 5228:
/***/ ((module) => {

/*
object-assign
(c) Sindre Sorhus
@license MIT
*/


/* eslint-disable no-unused-vars */
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;

function toObject(val) {
	if (val === null || val === undefined) {
		throw new TypeError('Object.assign cannot be called with null or undefined');
	}

	return Object(val);
}

function shouldUseNative() {
	try {
		if (!Object.assign) {
			return false;
		}

		// Detect buggy property enumeration order in older V8 versions.

		// https://bugs.chromium.org/p/v8/issues/detail?id=4118
		var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
		test1[5] = 'de';
		if (Object.getOwnPropertyNames(test1)[0] === '5') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test2 = {};
		for (var i = 0; i < 10; i++) {
			test2['_' + String.fromCharCode(i)] = i;
		}
		var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
			return test2[n];
		});
		if (order2.join('') !== '0123456789') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test3 = {};
		'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
			test3[letter] = letter;
		});
		if (Object.keys(Object.assign({}, test3)).join('') !==
				'abcdefghijklmnopqrst') {
			return false;
		}

		return true;
	} catch (err) {
		// We don't expect any of the above to throw, but better to be safe.
		return false;
	}
}

module.exports = shouldUseNative() ? Object.assign : function (target, source) {
	var from;
	var to = toObject(target);
	var symbols;

	for (var s = 1; s < arguments.length; s++) {
		from = Object(arguments[s]);

		for (var key in from) {
			if (hasOwnProperty.call(from, key)) {
				to[key] = from[key];
			}
		}

		if (getOwnPropertySymbols) {
			symbols = getOwnPropertySymbols(from);
			for (var i = 0; i < symbols.length; i++) {
				if (propIsEnumerable.call(from, symbols[i])) {
					to[symbols[i]] = from[symbols[i]];
				}
			}
		}
	}

	return to;
};


/***/ }),

/***/ 2551:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var __webpack_unused_export__;
/** @license React v17.0.2
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/*
 Modernizr 3.0.0pre (Custom Build) | MIT
*/
var aa=__webpack_require__(6540),m=__webpack_require__(5228),r=__webpack_require__(9982);function y(a){for(var b="https://reactjs.org/docs/error-decoder.html?invariant="+a,c=1;c<arguments.length;c++)b+="&args[]="+encodeURIComponent(arguments[c]);return"Minified React error #"+a+"; visit "+b+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}if(!aa)throw Error(y(227));var ba=new Set,ca={};function da(a,b){ea(a,b);ea(a+"Capture",b)}
function ea(a,b){ca[a]=b;for(a=0;a<b.length;a++)ba.add(b[a])}
var fa=!("undefined"===typeof window||"undefined"===typeof window.document||"undefined"===typeof window.document.createElement),ha=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,ia=Object.prototype.hasOwnProperty,
ja={},ka={};function la(a){if(ia.call(ka,a))return!0;if(ia.call(ja,a))return!1;if(ha.test(a))return ka[a]=!0;ja[a]=!0;return!1}function ma(a,b,c,d){if(null!==c&&0===c.type)return!1;switch(typeof b){case "function":case "symbol":return!0;case "boolean":if(d)return!1;if(null!==c)return!c.acceptsBooleans;a=a.toLowerCase().slice(0,5);return"data-"!==a&&"aria-"!==a;default:return!1}}
function na(a,b,c,d){if(null===b||"undefined"===typeof b||ma(a,b,c,d))return!0;if(d)return!1;if(null!==c)switch(c.type){case 3:return!b;case 4:return!1===b;case 5:return isNaN(b);case 6:return isNaN(b)||1>b}return!1}function B(a,b,c,d,e,f,g){this.acceptsBooleans=2===b||3===b||4===b;this.attributeName=d;this.attributeNamespace=e;this.mustUseProperty=c;this.propertyName=a;this.type=b;this.sanitizeURL=f;this.removeEmptyString=g}var D={};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a){D[a]=new B(a,0,!1,a,null,!1,!1)});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(a){var b=a[0];D[b]=new B(b,1,!1,a[1],null,!1,!1)});["contentEditable","draggable","spellCheck","value"].forEach(function(a){D[a]=new B(a,2,!1,a.toLowerCase(),null,!1,!1)});
["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(a){D[a]=new B(a,2,!1,a,null,!1,!1)});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a){D[a]=new B(a,3,!1,a.toLowerCase(),null,!1,!1)});
["checked","multiple","muted","selected"].forEach(function(a){D[a]=new B(a,3,!0,a,null,!1,!1)});["capture","download"].forEach(function(a){D[a]=new B(a,4,!1,a,null,!1,!1)});["cols","rows","size","span"].forEach(function(a){D[a]=new B(a,6,!1,a,null,!1,!1)});["rowSpan","start"].forEach(function(a){D[a]=new B(a,5,!1,a.toLowerCase(),null,!1,!1)});var oa=/[\-:]([a-z])/g;function pa(a){return a[1].toUpperCase()}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a){var b=a.replace(oa,
pa);D[b]=new B(b,1,!1,a,null,!1,!1)});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a){var b=a.replace(oa,pa);D[b]=new B(b,1,!1,a,"http://www.w3.org/1999/xlink",!1,!1)});["xml:base","xml:lang","xml:space"].forEach(function(a){var b=a.replace(oa,pa);D[b]=new B(b,1,!1,a,"http://www.w3.org/XML/1998/namespace",!1,!1)});["tabIndex","crossOrigin"].forEach(function(a){D[a]=new B(a,1,!1,a.toLowerCase(),null,!1,!1)});
D.xlinkHref=new B("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);["src","href","action","formAction"].forEach(function(a){D[a]=new B(a,1,!1,a.toLowerCase(),null,!0,!0)});
function qa(a,b,c,d){var e=D.hasOwnProperty(b)?D[b]:null;var f=null!==e?0===e.type:d?!1:!(2<b.length)||"o"!==b[0]&&"O"!==b[0]||"n"!==b[1]&&"N"!==b[1]?!1:!0;f||(na(b,c,e,d)&&(c=null),d||null===e?la(b)&&(null===c?a.removeAttribute(b):a.setAttribute(b,""+c)):e.mustUseProperty?a[e.propertyName]=null===c?3===e.type?!1:"":c:(b=e.attributeName,d=e.attributeNamespace,null===c?a.removeAttribute(b):(e=e.type,c=3===e||4===e&&!0===c?"":""+c,d?a.setAttributeNS(d,b,c):a.setAttribute(b,c))))}
var ra=aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,sa=60103,ta=60106,ua=60107,wa=60108,xa=60114,ya=60109,za=60110,Aa=60112,Ba=60113,Ca=60120,Da=60115,Ea=60116,Fa=60121,Ga=60128,Ha=60129,Ia=60130,Ja=60131;
if("function"===typeof Symbol&&Symbol.for){var E=Symbol.for;sa=E("react.element");ta=E("react.portal");ua=E("react.fragment");wa=E("react.strict_mode");xa=E("react.profiler");ya=E("react.provider");za=E("react.context");Aa=E("react.forward_ref");Ba=E("react.suspense");Ca=E("react.suspense_list");Da=E("react.memo");Ea=E("react.lazy");Fa=E("react.block");E("react.scope");Ga=E("react.opaque.id");Ha=E("react.debug_trace_mode");Ia=E("react.offscreen");Ja=E("react.legacy_hidden")}
var Ka="function"===typeof Symbol&&Symbol.iterator;function La(a){if(null===a||"object"!==typeof a)return null;a=Ka&&a[Ka]||a["@@iterator"];return"function"===typeof a?a:null}var Ma;function Na(a){if(void 0===Ma)try{throw Error();}catch(c){var b=c.stack.trim().match(/\n( *(at )?)/);Ma=b&&b[1]||""}return"\n"+Ma+a}var Oa=!1;
function Pa(a,b){if(!a||Oa)return"";Oa=!0;var c=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(b)if(b=function(){throw Error();},Object.defineProperty(b.prototype,"props",{set:function(){throw Error();}}),"object"===typeof Reflect&&Reflect.construct){try{Reflect.construct(b,[])}catch(k){var d=k}Reflect.construct(a,[],b)}else{try{b.call()}catch(k){d=k}a.call(b.prototype)}else{try{throw Error();}catch(k){d=k}a()}}catch(k){if(k&&d&&"string"===typeof k.stack){for(var e=k.stack.split("\n"),
f=d.stack.split("\n"),g=e.length-1,h=f.length-1;1<=g&&0<=h&&e[g]!==f[h];)h--;for(;1<=g&&0<=h;g--,h--)if(e[g]!==f[h]){if(1!==g||1!==h){do if(g--,h--,0>h||e[g]!==f[h])return"\n"+e[g].replace(" at new "," at ");while(1<=g&&0<=h)}break}}}finally{Oa=!1,Error.prepareStackTrace=c}return(a=a?a.displayName||a.name:"")?Na(a):""}
function Qa(a){switch(a.tag){case 5:return Na(a.type);case 16:return Na("Lazy");case 13:return Na("Suspense");case 19:return Na("SuspenseList");case 0:case 2:case 15:return a=Pa(a.type,!1),a;case 11:return a=Pa(a.type.render,!1),a;case 22:return a=Pa(a.type._render,!1),a;case 1:return a=Pa(a.type,!0),a;default:return""}}
function Ra(a){if(null==a)return null;if("function"===typeof a)return a.displayName||a.name||null;if("string"===typeof a)return a;switch(a){case ua:return"Fragment";case ta:return"Portal";case xa:return"Profiler";case wa:return"StrictMode";case Ba:return"Suspense";case Ca:return"SuspenseList"}if("object"===typeof a)switch(a.$$typeof){case za:return(a.displayName||"Context")+".Consumer";case ya:return(a._context.displayName||"Context")+".Provider";case Aa:var b=a.render;b=b.displayName||b.name||"";
return a.displayName||(""!==b?"ForwardRef("+b+")":"ForwardRef");case Da:return Ra(a.type);case Fa:return Ra(a._render);case Ea:b=a._payload;a=a._init;try{return Ra(a(b))}catch(c){}}return null}function Sa(a){switch(typeof a){case "boolean":case "number":case "object":case "string":case "undefined":return a;default:return""}}function Ta(a){var b=a.type;return(a=a.nodeName)&&"input"===a.toLowerCase()&&("checkbox"===b||"radio"===b)}
function Ua(a){var b=Ta(a)?"checked":"value",c=Object.getOwnPropertyDescriptor(a.constructor.prototype,b),d=""+a[b];if(!a.hasOwnProperty(b)&&"undefined"!==typeof c&&"function"===typeof c.get&&"function"===typeof c.set){var e=c.get,f=c.set;Object.defineProperty(a,b,{configurable:!0,get:function(){return e.call(this)},set:function(a){d=""+a;f.call(this,a)}});Object.defineProperty(a,b,{enumerable:c.enumerable});return{getValue:function(){return d},setValue:function(a){d=""+a},stopTracking:function(){a._valueTracker=
null;delete a[b]}}}}function Va(a){a._valueTracker||(a._valueTracker=Ua(a))}function Wa(a){if(!a)return!1;var b=a._valueTracker;if(!b)return!0;var c=b.getValue();var d="";a&&(d=Ta(a)?a.checked?"true":"false":a.value);a=d;return a!==c?(b.setValue(a),!0):!1}function Xa(a){a=a||("undefined"!==typeof document?document:void 0);if("undefined"===typeof a)return null;try{return a.activeElement||a.body}catch(b){return a.body}}
function Ya(a,b){var c=b.checked;return m({},b,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:null!=c?c:a._wrapperState.initialChecked})}function Za(a,b){var c=null==b.defaultValue?"":b.defaultValue,d=null!=b.checked?b.checked:b.defaultChecked;c=Sa(null!=b.value?b.value:c);a._wrapperState={initialChecked:d,initialValue:c,controlled:"checkbox"===b.type||"radio"===b.type?null!=b.checked:null!=b.value}}function $a(a,b){b=b.checked;null!=b&&qa(a,"checked",b,!1)}
function ab(a,b){$a(a,b);var c=Sa(b.value),d=b.type;if(null!=c)if("number"===d){if(0===c&&""===a.value||a.value!=c)a.value=""+c}else a.value!==""+c&&(a.value=""+c);else if("submit"===d||"reset"===d){a.removeAttribute("value");return}b.hasOwnProperty("value")?bb(a,b.type,c):b.hasOwnProperty("defaultValue")&&bb(a,b.type,Sa(b.defaultValue));null==b.checked&&null!=b.defaultChecked&&(a.defaultChecked=!!b.defaultChecked)}
function cb(a,b,c){if(b.hasOwnProperty("value")||b.hasOwnProperty("defaultValue")){var d=b.type;if(!("submit"!==d&&"reset"!==d||void 0!==b.value&&null!==b.value))return;b=""+a._wrapperState.initialValue;c||b===a.value||(a.value=b);a.defaultValue=b}c=a.name;""!==c&&(a.name="");a.defaultChecked=!!a._wrapperState.initialChecked;""!==c&&(a.name=c)}
function bb(a,b,c){if("number"!==b||Xa(a.ownerDocument)!==a)null==c?a.defaultValue=""+a._wrapperState.initialValue:a.defaultValue!==""+c&&(a.defaultValue=""+c)}function db(a){var b="";aa.Children.forEach(a,function(a){null!=a&&(b+=a)});return b}function eb(a,b){a=m({children:void 0},b);if(b=db(b.children))a.children=b;return a}
function fb(a,b,c,d){a=a.options;if(b){b={};for(var e=0;e<c.length;e++)b["$"+c[e]]=!0;for(c=0;c<a.length;c++)e=b.hasOwnProperty("$"+a[c].value),a[c].selected!==e&&(a[c].selected=e),e&&d&&(a[c].defaultSelected=!0)}else{c=""+Sa(c);b=null;for(e=0;e<a.length;e++){if(a[e].value===c){a[e].selected=!0;d&&(a[e].defaultSelected=!0);return}null!==b||a[e].disabled||(b=a[e])}null!==b&&(b.selected=!0)}}
function gb(a,b){if(null!=b.dangerouslySetInnerHTML)throw Error(y(91));return m({},b,{value:void 0,defaultValue:void 0,children:""+a._wrapperState.initialValue})}function hb(a,b){var c=b.value;if(null==c){c=b.children;b=b.defaultValue;if(null!=c){if(null!=b)throw Error(y(92));if(Array.isArray(c)){if(!(1>=c.length))throw Error(y(93));c=c[0]}b=c}null==b&&(b="");c=b}a._wrapperState={initialValue:Sa(c)}}
function ib(a,b){var c=Sa(b.value),d=Sa(b.defaultValue);null!=c&&(c=""+c,c!==a.value&&(a.value=c),null==b.defaultValue&&a.defaultValue!==c&&(a.defaultValue=c));null!=d&&(a.defaultValue=""+d)}function jb(a){var b=a.textContent;b===a._wrapperState.initialValue&&""!==b&&null!==b&&(a.value=b)}var kb={html:"http://www.w3.org/1999/xhtml",mathml:"http://www.w3.org/1998/Math/MathML",svg:"http://www.w3.org/2000/svg"};
function lb(a){switch(a){case "svg":return"http://www.w3.org/2000/svg";case "math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function mb(a,b){return null==a||"http://www.w3.org/1999/xhtml"===a?lb(b):"http://www.w3.org/2000/svg"===a&&"foreignObject"===b?"http://www.w3.org/1999/xhtml":a}
var nb,ob=function(a){return"undefined"!==typeof MSApp&&MSApp.execUnsafeLocalFunction?function(b,c,d,e){MSApp.execUnsafeLocalFunction(function(){return a(b,c,d,e)})}:a}(function(a,b){if(a.namespaceURI!==kb.svg||"innerHTML"in a)a.innerHTML=b;else{nb=nb||document.createElement("div");nb.innerHTML="<svg>"+b.valueOf().toString()+"</svg>";for(b=nb.firstChild;a.firstChild;)a.removeChild(a.firstChild);for(;b.firstChild;)a.appendChild(b.firstChild)}});
function pb(a,b){if(b){var c=a.firstChild;if(c&&c===a.lastChild&&3===c.nodeType){c.nodeValue=b;return}}a.textContent=b}
var qb={animationIterationCount:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,
floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},rb=["Webkit","ms","Moz","O"];Object.keys(qb).forEach(function(a){rb.forEach(function(b){b=b+a.charAt(0).toUpperCase()+a.substring(1);qb[b]=qb[a]})});function sb(a,b,c){return null==b||"boolean"===typeof b||""===b?"":c||"number"!==typeof b||0===b||qb.hasOwnProperty(a)&&qb[a]?(""+b).trim():b+"px"}
function tb(a,b){a=a.style;for(var c in b)if(b.hasOwnProperty(c)){var d=0===c.indexOf("--"),e=sb(c,b[c],d);"float"===c&&(c="cssFloat");d?a.setProperty(c,e):a[c]=e}}var ub=m({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});
function vb(a,b){if(b){if(ub[a]&&(null!=b.children||null!=b.dangerouslySetInnerHTML))throw Error(y(137,a));if(null!=b.dangerouslySetInnerHTML){if(null!=b.children)throw Error(y(60));if(!("object"===typeof b.dangerouslySetInnerHTML&&"__html"in b.dangerouslySetInnerHTML))throw Error(y(61));}if(null!=b.style&&"object"!==typeof b.style)throw Error(y(62));}}
function wb(a,b){if(-1===a.indexOf("-"))return"string"===typeof b.is;switch(a){case "annotation-xml":case "color-profile":case "font-face":case "font-face-src":case "font-face-uri":case "font-face-format":case "font-face-name":case "missing-glyph":return!1;default:return!0}}function xb(a){a=a.target||a.srcElement||window;a.correspondingUseElement&&(a=a.correspondingUseElement);return 3===a.nodeType?a.parentNode:a}var yb=null,zb=null,Ab=null;
function Bb(a){if(a=Cb(a)){if("function"!==typeof yb)throw Error(y(280));var b=a.stateNode;b&&(b=Db(b),yb(a.stateNode,a.type,b))}}function Eb(a){zb?Ab?Ab.push(a):Ab=[a]:zb=a}function Fb(){if(zb){var a=zb,b=Ab;Ab=zb=null;Bb(a);if(b)for(a=0;a<b.length;a++)Bb(b[a])}}function Gb(a,b){return a(b)}function Hb(a,b,c,d,e){return a(b,c,d,e)}function Ib(){}var Jb=Gb,Kb=!1,Lb=!1;function Mb(){if(null!==zb||null!==Ab)Ib(),Fb()}
function Nb(a,b,c){if(Lb)return a(b,c);Lb=!0;try{return Jb(a,b,c)}finally{Lb=!1,Mb()}}
function Ob(a,b){var c=a.stateNode;if(null===c)return null;var d=Db(c);if(null===d)return null;c=d[b];a:switch(b){case "onClick":case "onClickCapture":case "onDoubleClick":case "onDoubleClickCapture":case "onMouseDown":case "onMouseDownCapture":case "onMouseMove":case "onMouseMoveCapture":case "onMouseUp":case "onMouseUpCapture":case "onMouseEnter":(d=!d.disabled)||(a=a.type,d=!("button"===a||"input"===a||"select"===a||"textarea"===a));a=!d;break a;default:a=!1}if(a)return null;if(c&&"function"!==
typeof c)throw Error(y(231,b,typeof c));return c}var Pb=!1;if(fa)try{var Qb={};Object.defineProperty(Qb,"passive",{get:function(){Pb=!0}});window.addEventListener("test",Qb,Qb);window.removeEventListener("test",Qb,Qb)}catch(a){Pb=!1}function Rb(a,b,c,d,e,f,g,h,k){var l=Array.prototype.slice.call(arguments,3);try{b.apply(c,l)}catch(n){this.onError(n)}}var Sb=!1,Tb=null,Ub=!1,Vb=null,Wb={onError:function(a){Sb=!0;Tb=a}};function Xb(a,b,c,d,e,f,g,h,k){Sb=!1;Tb=null;Rb.apply(Wb,arguments)}
function Yb(a,b,c,d,e,f,g,h,k){Xb.apply(this,arguments);if(Sb){if(Sb){var l=Tb;Sb=!1;Tb=null}else throw Error(y(198));Ub||(Ub=!0,Vb=l)}}function Zb(a){var b=a,c=a;if(a.alternate)for(;b.return;)b=b.return;else{a=b;do b=a,0!==(b.flags&1026)&&(c=b.return),a=b.return;while(a)}return 3===b.tag?c:null}function $b(a){if(13===a.tag){var b=a.memoizedState;null===b&&(a=a.alternate,null!==a&&(b=a.memoizedState));if(null!==b)return b.dehydrated}return null}function ac(a){if(Zb(a)!==a)throw Error(y(188));}
function bc(a){var b=a.alternate;if(!b){b=Zb(a);if(null===b)throw Error(y(188));return b!==a?null:a}for(var c=a,d=b;;){var e=c.return;if(null===e)break;var f=e.alternate;if(null===f){d=e.return;if(null!==d){c=d;continue}break}if(e.child===f.child){for(f=e.child;f;){if(f===c)return ac(e),a;if(f===d)return ac(e),b;f=f.sibling}throw Error(y(188));}if(c.return!==d.return)c=e,d=f;else{for(var g=!1,h=e.child;h;){if(h===c){g=!0;c=e;d=f;break}if(h===d){g=!0;d=e;c=f;break}h=h.sibling}if(!g){for(h=f.child;h;){if(h===
c){g=!0;c=f;d=e;break}if(h===d){g=!0;d=f;c=e;break}h=h.sibling}if(!g)throw Error(y(189));}}if(c.alternate!==d)throw Error(y(190));}if(3!==c.tag)throw Error(y(188));return c.stateNode.current===c?a:b}function cc(a){a=bc(a);if(!a)return null;for(var b=a;;){if(5===b.tag||6===b.tag)return b;if(b.child)b.child.return=b,b=b.child;else{if(b===a)break;for(;!b.sibling;){if(!b.return||b.return===a)return null;b=b.return}b.sibling.return=b.return;b=b.sibling}}return null}
function dc(a,b){for(var c=a.alternate;null!==b;){if(b===a||b===c)return!0;b=b.return}return!1}var ec,fc,gc,hc,ic=!1,jc=[],kc=null,lc=null,mc=null,nc=new Map,oc=new Map,pc=[],qc="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
function rc(a,b,c,d,e){return{blockedOn:a,domEventName:b,eventSystemFlags:c|16,nativeEvent:e,targetContainers:[d]}}function sc(a,b){switch(a){case "focusin":case "focusout":kc=null;break;case "dragenter":case "dragleave":lc=null;break;case "mouseover":case "mouseout":mc=null;break;case "pointerover":case "pointerout":nc.delete(b.pointerId);break;case "gotpointercapture":case "lostpointercapture":oc.delete(b.pointerId)}}
function tc(a,b,c,d,e,f){if(null===a||a.nativeEvent!==f)return a=rc(b,c,d,e,f),null!==b&&(b=Cb(b),null!==b&&fc(b)),a;a.eventSystemFlags|=d;b=a.targetContainers;null!==e&&-1===b.indexOf(e)&&b.push(e);return a}
function uc(a,b,c,d,e){switch(b){case "focusin":return kc=tc(kc,a,b,c,d,e),!0;case "dragenter":return lc=tc(lc,a,b,c,d,e),!0;case "mouseover":return mc=tc(mc,a,b,c,d,e),!0;case "pointerover":var f=e.pointerId;nc.set(f,tc(nc.get(f)||null,a,b,c,d,e));return!0;case "gotpointercapture":return f=e.pointerId,oc.set(f,tc(oc.get(f)||null,a,b,c,d,e)),!0}return!1}
function vc(a){var b=wc(a.target);if(null!==b){var c=Zb(b);if(null!==c)if(b=c.tag,13===b){if(b=$b(c),null!==b){a.blockedOn=b;hc(a.lanePriority,function(){r.unstable_runWithPriority(a.priority,function(){gc(c)})});return}}else if(3===b&&c.stateNode.hydrate){a.blockedOn=3===c.tag?c.stateNode.containerInfo:null;return}}a.blockedOn=null}
function xc(a){if(null!==a.blockedOn)return!1;for(var b=a.targetContainers;0<b.length;){var c=yc(a.domEventName,a.eventSystemFlags,b[0],a.nativeEvent);if(null!==c)return b=Cb(c),null!==b&&fc(b),a.blockedOn=c,!1;b.shift()}return!0}function zc(a,b,c){xc(a)&&c.delete(b)}
function Ac(){for(ic=!1;0<jc.length;){var a=jc[0];if(null!==a.blockedOn){a=Cb(a.blockedOn);null!==a&&ec(a);break}for(var b=a.targetContainers;0<b.length;){var c=yc(a.domEventName,a.eventSystemFlags,b[0],a.nativeEvent);if(null!==c){a.blockedOn=c;break}b.shift()}null===a.blockedOn&&jc.shift()}null!==kc&&xc(kc)&&(kc=null);null!==lc&&xc(lc)&&(lc=null);null!==mc&&xc(mc)&&(mc=null);nc.forEach(zc);oc.forEach(zc)}
function Bc(a,b){a.blockedOn===b&&(a.blockedOn=null,ic||(ic=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,Ac)))}
function Cc(a){function b(b){return Bc(b,a)}if(0<jc.length){Bc(jc[0],a);for(var c=1;c<jc.length;c++){var d=jc[c];d.blockedOn===a&&(d.blockedOn=null)}}null!==kc&&Bc(kc,a);null!==lc&&Bc(lc,a);null!==mc&&Bc(mc,a);nc.forEach(b);oc.forEach(b);for(c=0;c<pc.length;c++)d=pc[c],d.blockedOn===a&&(d.blockedOn=null);for(;0<pc.length&&(c=pc[0],null===c.blockedOn);)vc(c),null===c.blockedOn&&pc.shift()}
function Dc(a,b){var c={};c[a.toLowerCase()]=b.toLowerCase();c["Webkit"+a]="webkit"+b;c["Moz"+a]="moz"+b;return c}var Ec={animationend:Dc("Animation","AnimationEnd"),animationiteration:Dc("Animation","AnimationIteration"),animationstart:Dc("Animation","AnimationStart"),transitionend:Dc("Transition","TransitionEnd")},Fc={},Gc={};
fa&&(Gc=document.createElement("div").style,"AnimationEvent"in window||(delete Ec.animationend.animation,delete Ec.animationiteration.animation,delete Ec.animationstart.animation),"TransitionEvent"in window||delete Ec.transitionend.transition);function Hc(a){if(Fc[a])return Fc[a];if(!Ec[a])return a;var b=Ec[a],c;for(c in b)if(b.hasOwnProperty(c)&&c in Gc)return Fc[a]=b[c];return a}
var Ic=Hc("animationend"),Jc=Hc("animationiteration"),Kc=Hc("animationstart"),Lc=Hc("transitionend"),Mc=new Map,Nc=new Map,Oc=["abort","abort",Ic,"animationEnd",Jc,"animationIteration",Kc,"animationStart","canplay","canPlay","canplaythrough","canPlayThrough","durationchange","durationChange","emptied","emptied","encrypted","encrypted","ended","ended","error","error","gotpointercapture","gotPointerCapture","load","load","loadeddata","loadedData","loadedmetadata","loadedMetadata","loadstart","loadStart",
"lostpointercapture","lostPointerCapture","playing","playing","progress","progress","seeking","seeking","stalled","stalled","suspend","suspend","timeupdate","timeUpdate",Lc,"transitionEnd","waiting","waiting"];function Pc(a,b){for(var c=0;c<a.length;c+=2){var d=a[c],e=a[c+1];e="on"+(e[0].toUpperCase()+e.slice(1));Nc.set(d,b);Mc.set(d,e);da(e,[d])}}var Qc=r.unstable_now;Qc();var F=8;
function Rc(a){if(0!==(1&a))return F=15,1;if(0!==(2&a))return F=14,2;if(0!==(4&a))return F=13,4;var b=24&a;if(0!==b)return F=12,b;if(0!==(a&32))return F=11,32;b=192&a;if(0!==b)return F=10,b;if(0!==(a&256))return F=9,256;b=3584&a;if(0!==b)return F=8,b;if(0!==(a&4096))return F=7,4096;b=4186112&a;if(0!==b)return F=6,b;b=62914560&a;if(0!==b)return F=5,b;if(a&67108864)return F=4,67108864;if(0!==(a&134217728))return F=3,134217728;b=805306368&a;if(0!==b)return F=2,b;if(0!==(1073741824&a))return F=1,1073741824;
F=8;return a}function Sc(a){switch(a){case 99:return 15;case 98:return 10;case 97:case 96:return 8;case 95:return 2;default:return 0}}function Tc(a){switch(a){case 15:case 14:return 99;case 13:case 12:case 11:case 10:return 98;case 9:case 8:case 7:case 6:case 4:case 5:return 97;case 3:case 2:case 1:return 95;case 0:return 90;default:throw Error(y(358,a));}}
function Uc(a,b){var c=a.pendingLanes;if(0===c)return F=0;var d=0,e=0,f=a.expiredLanes,g=a.suspendedLanes,h=a.pingedLanes;if(0!==f)d=f,e=F=15;else if(f=c&134217727,0!==f){var k=f&~g;0!==k?(d=Rc(k),e=F):(h&=f,0!==h&&(d=Rc(h),e=F))}else f=c&~g,0!==f?(d=Rc(f),e=F):0!==h&&(d=Rc(h),e=F);if(0===d)return 0;d=31-Vc(d);d=c&((0>d?0:1<<d)<<1)-1;if(0!==b&&b!==d&&0===(b&g)){Rc(b);if(e<=F)return b;F=e}b=a.entangledLanes;if(0!==b)for(a=a.entanglements,b&=d;0<b;)c=31-Vc(b),e=1<<c,d|=a[c],b&=~e;return d}
function Wc(a){a=a.pendingLanes&-1073741825;return 0!==a?a:a&1073741824?1073741824:0}function Xc(a,b){switch(a){case 15:return 1;case 14:return 2;case 12:return a=Yc(24&~b),0===a?Xc(10,b):a;case 10:return a=Yc(192&~b),0===a?Xc(8,b):a;case 8:return a=Yc(3584&~b),0===a&&(a=Yc(4186112&~b),0===a&&(a=512)),a;case 2:return b=Yc(805306368&~b),0===b&&(b=268435456),b}throw Error(y(358,a));}function Yc(a){return a&-a}function Zc(a){for(var b=[],c=0;31>c;c++)b.push(a);return b}
function $c(a,b,c){a.pendingLanes|=b;var d=b-1;a.suspendedLanes&=d;a.pingedLanes&=d;a=a.eventTimes;b=31-Vc(b);a[b]=c}var Vc=Math.clz32?Math.clz32:ad,bd=Math.log,cd=Math.LN2;function ad(a){return 0===a?32:31-(bd(a)/cd|0)|0}var dd=r.unstable_UserBlockingPriority,ed=r.unstable_runWithPriority,fd=!0;function gd(a,b,c,d){Kb||Ib();var e=hd,f=Kb;Kb=!0;try{Hb(e,a,b,c,d)}finally{(Kb=f)||Mb()}}function id(a,b,c,d){ed(dd,hd.bind(null,a,b,c,d))}
function hd(a,b,c,d){if(fd){var e;if((e=0===(b&4))&&0<jc.length&&-1<qc.indexOf(a))a=rc(null,a,b,c,d),jc.push(a);else{var f=yc(a,b,c,d);if(null===f)e&&sc(a,d);else{if(e){if(-1<qc.indexOf(a)){a=rc(f,a,b,c,d);jc.push(a);return}if(uc(f,a,b,c,d))return;sc(a,d)}jd(a,b,d,null,c)}}}}
function yc(a,b,c,d){var e=xb(d);e=wc(e);if(null!==e){var f=Zb(e);if(null===f)e=null;else{var g=f.tag;if(13===g){e=$b(f);if(null!==e)return e;e=null}else if(3===g){if(f.stateNode.hydrate)return 3===f.tag?f.stateNode.containerInfo:null;e=null}else f!==e&&(e=null)}}jd(a,b,d,e,c);return null}var kd=null,ld=null,md=null;
function nd(){if(md)return md;var a,b=ld,c=b.length,d,e="value"in kd?kd.value:kd.textContent,f=e.length;for(a=0;a<c&&b[a]===e[a];a++);var g=c-a;for(d=1;d<=g&&b[c-d]===e[f-d];d++);return md=e.slice(a,1<d?1-d:void 0)}function od(a){var b=a.keyCode;"charCode"in a?(a=a.charCode,0===a&&13===b&&(a=13)):a=b;10===a&&(a=13);return 32<=a||13===a?a:0}function pd(){return!0}function qd(){return!1}
function rd(a){function b(b,d,e,f,g){this._reactName=b;this._targetInst=e;this.type=d;this.nativeEvent=f;this.target=g;this.currentTarget=null;for(var c in a)a.hasOwnProperty(c)&&(b=a[c],this[c]=b?b(f):f[c]);this.isDefaultPrevented=(null!=f.defaultPrevented?f.defaultPrevented:!1===f.returnValue)?pd:qd;this.isPropagationStopped=qd;return this}m(b.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():"unknown"!==typeof a.returnValue&&
(a.returnValue=!1),this.isDefaultPrevented=pd)},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():"unknown"!==typeof a.cancelBubble&&(a.cancelBubble=!0),this.isPropagationStopped=pd)},persist:function(){},isPersistent:pd});return b}
var sd={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(a){return a.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},td=rd(sd),ud=m({},sd,{view:0,detail:0}),vd=rd(ud),wd,xd,yd,Ad=m({},ud,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:zd,button:0,buttons:0,relatedTarget:function(a){return void 0===a.relatedTarget?a.fromElement===a.srcElement?a.toElement:a.fromElement:a.relatedTarget},movementX:function(a){if("movementX"in
a)return a.movementX;a!==yd&&(yd&&"mousemove"===a.type?(wd=a.screenX-yd.screenX,xd=a.screenY-yd.screenY):xd=wd=0,yd=a);return wd},movementY:function(a){return"movementY"in a?a.movementY:xd}}),Bd=rd(Ad),Cd=m({},Ad,{dataTransfer:0}),Dd=rd(Cd),Ed=m({},ud,{relatedTarget:0}),Fd=rd(Ed),Gd=m({},sd,{animationName:0,elapsedTime:0,pseudoElement:0}),Hd=rd(Gd),Id=m({},sd,{clipboardData:function(a){return"clipboardData"in a?a.clipboardData:window.clipboardData}}),Jd=rd(Id),Kd=m({},sd,{data:0}),Ld=rd(Kd),Md={Esc:"Escape",
Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Nd={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",
119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Od={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Pd(a){var b=this.nativeEvent;return b.getModifierState?b.getModifierState(a):(a=Od[a])?!!b[a]:!1}function zd(){return Pd}
var Qd=m({},ud,{key:function(a){if(a.key){var b=Md[a.key]||a.key;if("Unidentified"!==b)return b}return"keypress"===a.type?(a=od(a),13===a?"Enter":String.fromCharCode(a)):"keydown"===a.type||"keyup"===a.type?Nd[a.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:zd,charCode:function(a){return"keypress"===a.type?od(a):0},keyCode:function(a){return"keydown"===a.type||"keyup"===a.type?a.keyCode:0},which:function(a){return"keypress"===
a.type?od(a):"keydown"===a.type||"keyup"===a.type?a.keyCode:0}}),Rd=rd(Qd),Sd=m({},Ad,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Td=rd(Sd),Ud=m({},ud,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:zd}),Vd=rd(Ud),Wd=m({},sd,{propertyName:0,elapsedTime:0,pseudoElement:0}),Xd=rd(Wd),Yd=m({},Ad,{deltaX:function(a){return"deltaX"in a?a.deltaX:"wheelDeltaX"in a?-a.wheelDeltaX:0},
deltaY:function(a){return"deltaY"in a?a.deltaY:"wheelDeltaY"in a?-a.wheelDeltaY:"wheelDelta"in a?-a.wheelDelta:0},deltaZ:0,deltaMode:0}),Zd=rd(Yd),$d=[9,13,27,32],ae=fa&&"CompositionEvent"in window,be=null;fa&&"documentMode"in document&&(be=document.documentMode);var ce=fa&&"TextEvent"in window&&!be,de=fa&&(!ae||be&&8<be&&11>=be),ee=String.fromCharCode(32),fe=!1;
function ge(a,b){switch(a){case "keyup":return-1!==$d.indexOf(b.keyCode);case "keydown":return 229!==b.keyCode;case "keypress":case "mousedown":case "focusout":return!0;default:return!1}}function he(a){a=a.detail;return"object"===typeof a&&"data"in a?a.data:null}var ie=!1;function je(a,b){switch(a){case "compositionend":return he(b);case "keypress":if(32!==b.which)return null;fe=!0;return ee;case "textInput":return a=b.data,a===ee&&fe?null:a;default:return null}}
function ke(a,b){if(ie)return"compositionend"===a||!ae&&ge(a,b)?(a=nd(),md=ld=kd=null,ie=!1,a):null;switch(a){case "paste":return null;case "keypress":if(!(b.ctrlKey||b.altKey||b.metaKey)||b.ctrlKey&&b.altKey){if(b.char&&1<b.char.length)return b.char;if(b.which)return String.fromCharCode(b.which)}return null;case "compositionend":return de&&"ko"!==b.locale?null:b.data;default:return null}}
var le={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function me(a){var b=a&&a.nodeName&&a.nodeName.toLowerCase();return"input"===b?!!le[a.type]:"textarea"===b?!0:!1}function ne(a,b,c,d){Eb(d);b=oe(b,"onChange");0<b.length&&(c=new td("onChange","change",null,c,d),a.push({event:c,listeners:b}))}var pe=null,qe=null;function re(a){se(a,0)}function te(a){var b=ue(a);if(Wa(b))return a}
function ve(a,b){if("change"===a)return b}var we=!1;if(fa){var xe;if(fa){var ye="oninput"in document;if(!ye){var ze=document.createElement("div");ze.setAttribute("oninput","return;");ye="function"===typeof ze.oninput}xe=ye}else xe=!1;we=xe&&(!document.documentMode||9<document.documentMode)}function Ae(){pe&&(pe.detachEvent("onpropertychange",Be),qe=pe=null)}function Be(a){if("value"===a.propertyName&&te(qe)){var b=[];ne(b,qe,a,xb(a));a=re;if(Kb)a(b);else{Kb=!0;try{Gb(a,b)}finally{Kb=!1,Mb()}}}}
function Ce(a,b,c){"focusin"===a?(Ae(),pe=b,qe=c,pe.attachEvent("onpropertychange",Be)):"focusout"===a&&Ae()}function De(a){if("selectionchange"===a||"keyup"===a||"keydown"===a)return te(qe)}function Ee(a,b){if("click"===a)return te(b)}function Fe(a,b){if("input"===a||"change"===a)return te(b)}function Ge(a,b){return a===b&&(0!==a||1/a===1/b)||a!==a&&b!==b}var He="function"===typeof Object.is?Object.is:Ge,Ie=Object.prototype.hasOwnProperty;
function Je(a,b){if(He(a,b))return!0;if("object"!==typeof a||null===a||"object"!==typeof b||null===b)return!1;var c=Object.keys(a),d=Object.keys(b);if(c.length!==d.length)return!1;for(d=0;d<c.length;d++)if(!Ie.call(b,c[d])||!He(a[c[d]],b[c[d]]))return!1;return!0}function Ke(a){for(;a&&a.firstChild;)a=a.firstChild;return a}
function Le(a,b){var c=Ke(a);a=0;for(var d;c;){if(3===c.nodeType){d=a+c.textContent.length;if(a<=b&&d>=b)return{node:c,offset:b-a};a=d}a:{for(;c;){if(c.nextSibling){c=c.nextSibling;break a}c=c.parentNode}c=void 0}c=Ke(c)}}function Me(a,b){return a&&b?a===b?!0:a&&3===a.nodeType?!1:b&&3===b.nodeType?Me(a,b.parentNode):"contains"in a?a.contains(b):a.compareDocumentPosition?!!(a.compareDocumentPosition(b)&16):!1:!1}
function Ne(){for(var a=window,b=Xa();b instanceof a.HTMLIFrameElement;){try{var c="string"===typeof b.contentWindow.location.href}catch(d){c=!1}if(c)a=b.contentWindow;else break;b=Xa(a.document)}return b}function Oe(a){var b=a&&a.nodeName&&a.nodeName.toLowerCase();return b&&("input"===b&&("text"===a.type||"search"===a.type||"tel"===a.type||"url"===a.type||"password"===a.type)||"textarea"===b||"true"===a.contentEditable)}
var Pe=fa&&"documentMode"in document&&11>=document.documentMode,Qe=null,Re=null,Se=null,Te=!1;
function Ue(a,b,c){var d=c.window===c?c.document:9===c.nodeType?c:c.ownerDocument;Te||null==Qe||Qe!==Xa(d)||(d=Qe,"selectionStart"in d&&Oe(d)?d={start:d.selectionStart,end:d.selectionEnd}:(d=(d.ownerDocument&&d.ownerDocument.defaultView||window).getSelection(),d={anchorNode:d.anchorNode,anchorOffset:d.anchorOffset,focusNode:d.focusNode,focusOffset:d.focusOffset}),Se&&Je(Se,d)||(Se=d,d=oe(Re,"onSelect"),0<d.length&&(b=new td("onSelect","select",null,b,c),a.push({event:b,listeners:d}),b.target=Qe)))}
Pc("cancel cancel click click close close contextmenu contextMenu copy copy cut cut auxclick auxClick dblclick doubleClick dragend dragEnd dragstart dragStart drop drop focusin focus focusout blur input input invalid invalid keydown keyDown keypress keyPress keyup keyUp mousedown mouseDown mouseup mouseUp paste paste pause pause play play pointercancel pointerCancel pointerdown pointerDown pointerup pointerUp ratechange rateChange reset reset seeked seeked submit submit touchcancel touchCancel touchend touchEnd touchstart touchStart volumechange volumeChange".split(" "),
0);Pc("drag drag dragenter dragEnter dragexit dragExit dragleave dragLeave dragover dragOver mousemove mouseMove mouseout mouseOut mouseover mouseOver pointermove pointerMove pointerout pointerOut pointerover pointerOver scroll scroll toggle toggle touchmove touchMove wheel wheel".split(" "),1);Pc(Oc,2);for(var Ve="change selectionchange textInput compositionstart compositionend compositionupdate".split(" "),We=0;We<Ve.length;We++)Nc.set(Ve[We],0);ea("onMouseEnter",["mouseout","mouseover"]);
ea("onMouseLeave",["mouseout","mouseover"]);ea("onPointerEnter",["pointerout","pointerover"]);ea("onPointerLeave",["pointerout","pointerover"]);da("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));da("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));da("onBeforeInput",["compositionend","keypress","textInput","paste"]);da("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));
da("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));da("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Xe="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Ye=new Set("cancel close invalid load scroll toggle".split(" ").concat(Xe));
function Ze(a,b,c){var d=a.type||"unknown-event";a.currentTarget=c;Yb(d,b,void 0,a);a.currentTarget=null}
function se(a,b){b=0!==(b&4);for(var c=0;c<a.length;c++){var d=a[c],e=d.event;d=d.listeners;a:{var f=void 0;if(b)for(var g=d.length-1;0<=g;g--){var h=d[g],k=h.instance,l=h.currentTarget;h=h.listener;if(k!==f&&e.isPropagationStopped())break a;Ze(e,h,l);f=k}else for(g=0;g<d.length;g++){h=d[g];k=h.instance;l=h.currentTarget;h=h.listener;if(k!==f&&e.isPropagationStopped())break a;Ze(e,h,l);f=k}}}if(Ub)throw a=Vb,Ub=!1,Vb=null,a;}
function G(a,b){var c=$e(b),d=a+"__bubble";c.has(d)||(af(b,a,2,!1),c.add(d))}var bf="_reactListening"+Math.random().toString(36).slice(2);function cf(a){a[bf]||(a[bf]=!0,ba.forEach(function(b){Ye.has(b)||df(b,!1,a,null);df(b,!0,a,null)}))}
function df(a,b,c,d){var e=4<arguments.length&&void 0!==arguments[4]?arguments[4]:0,f=c;"selectionchange"===a&&9!==c.nodeType&&(f=c.ownerDocument);if(null!==d&&!b&&Ye.has(a)){if("scroll"!==a)return;e|=2;f=d}var g=$e(f),h=a+"__"+(b?"capture":"bubble");g.has(h)||(b&&(e|=4),af(f,a,e,b),g.add(h))}
function af(a,b,c,d){var e=Nc.get(b);switch(void 0===e?2:e){case 0:e=gd;break;case 1:e=id;break;default:e=hd}c=e.bind(null,b,c,a);e=void 0;!Pb||"touchstart"!==b&&"touchmove"!==b&&"wheel"!==b||(e=!0);d?void 0!==e?a.addEventListener(b,c,{capture:!0,passive:e}):a.addEventListener(b,c,!0):void 0!==e?a.addEventListener(b,c,{passive:e}):a.addEventListener(b,c,!1)}
function jd(a,b,c,d,e){var f=d;if(0===(b&1)&&0===(b&2)&&null!==d)a:for(;;){if(null===d)return;var g=d.tag;if(3===g||4===g){var h=d.stateNode.containerInfo;if(h===e||8===h.nodeType&&h.parentNode===e)break;if(4===g)for(g=d.return;null!==g;){var k=g.tag;if(3===k||4===k)if(k=g.stateNode.containerInfo,k===e||8===k.nodeType&&k.parentNode===e)return;g=g.return}for(;null!==h;){g=wc(h);if(null===g)return;k=g.tag;if(5===k||6===k){d=f=g;continue a}h=h.parentNode}}d=d.return}Nb(function(){var d=f,e=xb(c),g=[];
a:{var h=Mc.get(a);if(void 0!==h){var k=td,x=a;switch(a){case "keypress":if(0===od(c))break a;case "keydown":case "keyup":k=Rd;break;case "focusin":x="focus";k=Fd;break;case "focusout":x="blur";k=Fd;break;case "beforeblur":case "afterblur":k=Fd;break;case "click":if(2===c.button)break a;case "auxclick":case "dblclick":case "mousedown":case "mousemove":case "mouseup":case "mouseout":case "mouseover":case "contextmenu":k=Bd;break;case "drag":case "dragend":case "dragenter":case "dragexit":case "dragleave":case "dragover":case "dragstart":case "drop":k=
Dd;break;case "touchcancel":case "touchend":case "touchmove":case "touchstart":k=Vd;break;case Ic:case Jc:case Kc:k=Hd;break;case Lc:k=Xd;break;case "scroll":k=vd;break;case "wheel":k=Zd;break;case "copy":case "cut":case "paste":k=Jd;break;case "gotpointercapture":case "lostpointercapture":case "pointercancel":case "pointerdown":case "pointermove":case "pointerout":case "pointerover":case "pointerup":k=Td}var w=0!==(b&4),z=!w&&"scroll"===a,u=w?null!==h?h+"Capture":null:h;w=[];for(var t=d,q;null!==
t;){q=t;var v=q.stateNode;5===q.tag&&null!==v&&(q=v,null!==u&&(v=Ob(t,u),null!=v&&w.push(ef(t,v,q))));if(z)break;t=t.return}0<w.length&&(h=new k(h,x,null,c,e),g.push({event:h,listeners:w}))}}if(0===(b&7)){a:{h="mouseover"===a||"pointerover"===a;k="mouseout"===a||"pointerout"===a;if(h&&0===(b&16)&&(x=c.relatedTarget||c.fromElement)&&(wc(x)||x[ff]))break a;if(k||h){h=e.window===e?e:(h=e.ownerDocument)?h.defaultView||h.parentWindow:window;if(k){if(x=c.relatedTarget||c.toElement,k=d,x=x?wc(x):null,null!==
x&&(z=Zb(x),x!==z||5!==x.tag&&6!==x.tag))x=null}else k=null,x=d;if(k!==x){w=Bd;v="onMouseLeave";u="onMouseEnter";t="mouse";if("pointerout"===a||"pointerover"===a)w=Td,v="onPointerLeave",u="onPointerEnter",t="pointer";z=null==k?h:ue(k);q=null==x?h:ue(x);h=new w(v,t+"leave",k,c,e);h.target=z;h.relatedTarget=q;v=null;wc(e)===d&&(w=new w(u,t+"enter",x,c,e),w.target=q,w.relatedTarget=z,v=w);z=v;if(k&&x)b:{w=k;u=x;t=0;for(q=w;q;q=gf(q))t++;q=0;for(v=u;v;v=gf(v))q++;for(;0<t-q;)w=gf(w),t--;for(;0<q-t;)u=
gf(u),q--;for(;t--;){if(w===u||null!==u&&w===u.alternate)break b;w=gf(w);u=gf(u)}w=null}else w=null;null!==k&&hf(g,h,k,w,!1);null!==x&&null!==z&&hf(g,z,x,w,!0)}}}a:{h=d?ue(d):window;k=h.nodeName&&h.nodeName.toLowerCase();if("select"===k||"input"===k&&"file"===h.type)var J=ve;else if(me(h))if(we)J=Fe;else{J=De;var K=Ce}else(k=h.nodeName)&&"input"===k.toLowerCase()&&("checkbox"===h.type||"radio"===h.type)&&(J=Ee);if(J&&(J=J(a,d))){ne(g,J,c,e);break a}K&&K(a,h,d);"focusout"===a&&(K=h._wrapperState)&&
K.controlled&&"number"===h.type&&bb(h,"number",h.value)}K=d?ue(d):window;switch(a){case "focusin":if(me(K)||"true"===K.contentEditable)Qe=K,Re=d,Se=null;break;case "focusout":Se=Re=Qe=null;break;case "mousedown":Te=!0;break;case "contextmenu":case "mouseup":case "dragend":Te=!1;Ue(g,c,e);break;case "selectionchange":if(Pe)break;case "keydown":case "keyup":Ue(g,c,e)}var Q;if(ae)b:{switch(a){case "compositionstart":var L="onCompositionStart";break b;case "compositionend":L="onCompositionEnd";break b;
case "compositionupdate":L="onCompositionUpdate";break b}L=void 0}else ie?ge(a,c)&&(L="onCompositionEnd"):"keydown"===a&&229===c.keyCode&&(L="onCompositionStart");L&&(de&&"ko"!==c.locale&&(ie||"onCompositionStart"!==L?"onCompositionEnd"===L&&ie&&(Q=nd()):(kd=e,ld="value"in kd?kd.value:kd.textContent,ie=!0)),K=oe(d,L),0<K.length&&(L=new Ld(L,a,null,c,e),g.push({event:L,listeners:K}),Q?L.data=Q:(Q=he(c),null!==Q&&(L.data=Q))));if(Q=ce?je(a,c):ke(a,c))d=oe(d,"onBeforeInput"),0<d.length&&(e=new Ld("onBeforeInput",
"beforeinput",null,c,e),g.push({event:e,listeners:d}),e.data=Q)}se(g,b)})}function ef(a,b,c){return{instance:a,listener:b,currentTarget:c}}function oe(a,b){for(var c=b+"Capture",d=[];null!==a;){var e=a,f=e.stateNode;5===e.tag&&null!==f&&(e=f,f=Ob(a,c),null!=f&&d.unshift(ef(a,f,e)),f=Ob(a,b),null!=f&&d.push(ef(a,f,e)));a=a.return}return d}function gf(a){if(null===a)return null;do a=a.return;while(a&&5!==a.tag);return a?a:null}
function hf(a,b,c,d,e){for(var f=b._reactName,g=[];null!==c&&c!==d;){var h=c,k=h.alternate,l=h.stateNode;if(null!==k&&k===d)break;5===h.tag&&null!==l&&(h=l,e?(k=Ob(c,f),null!=k&&g.unshift(ef(c,k,h))):e||(k=Ob(c,f),null!=k&&g.push(ef(c,k,h))));c=c.return}0!==g.length&&a.push({event:b,listeners:g})}function jf(){}var kf=null,lf=null;function mf(a,b){switch(a){case "button":case "input":case "select":case "textarea":return!!b.autoFocus}return!1}
function nf(a,b){return"textarea"===a||"option"===a||"noscript"===a||"string"===typeof b.children||"number"===typeof b.children||"object"===typeof b.dangerouslySetInnerHTML&&null!==b.dangerouslySetInnerHTML&&null!=b.dangerouslySetInnerHTML.__html}var of="function"===typeof setTimeout?setTimeout:void 0,pf="function"===typeof clearTimeout?clearTimeout:void 0;function qf(a){1===a.nodeType?a.textContent="":9===a.nodeType&&(a=a.body,null!=a&&(a.textContent=""))}
function rf(a){for(;null!=a;a=a.nextSibling){var b=a.nodeType;if(1===b||3===b)break}return a}function sf(a){a=a.previousSibling;for(var b=0;a;){if(8===a.nodeType){var c=a.data;if("$"===c||"$!"===c||"$?"===c){if(0===b)return a;b--}else"/$"===c&&b++}a=a.previousSibling}return null}var tf=0;function uf(a){return{$$typeof:Ga,toString:a,valueOf:a}}var vf=Math.random().toString(36).slice(2),wf="__reactFiber$"+vf,xf="__reactProps$"+vf,ff="__reactContainer$"+vf,yf="__reactEvents$"+vf;
function wc(a){var b=a[wf];if(b)return b;for(var c=a.parentNode;c;){if(b=c[ff]||c[wf]){c=b.alternate;if(null!==b.child||null!==c&&null!==c.child)for(a=sf(a);null!==a;){if(c=a[wf])return c;a=sf(a)}return b}a=c;c=a.parentNode}return null}function Cb(a){a=a[wf]||a[ff];return!a||5!==a.tag&&6!==a.tag&&13!==a.tag&&3!==a.tag?null:a}function ue(a){if(5===a.tag||6===a.tag)return a.stateNode;throw Error(y(33));}function Db(a){return a[xf]||null}
function $e(a){var b=a[yf];void 0===b&&(b=a[yf]=new Set);return b}var zf=[],Af=-1;function Bf(a){return{current:a}}function H(a){0>Af||(a.current=zf[Af],zf[Af]=null,Af--)}function I(a,b){Af++;zf[Af]=a.current;a.current=b}var Cf={},M=Bf(Cf),N=Bf(!1),Df=Cf;
function Ef(a,b){var c=a.type.contextTypes;if(!c)return Cf;var d=a.stateNode;if(d&&d.__reactInternalMemoizedUnmaskedChildContext===b)return d.__reactInternalMemoizedMaskedChildContext;var e={},f;for(f in c)e[f]=b[f];d&&(a=a.stateNode,a.__reactInternalMemoizedUnmaskedChildContext=b,a.__reactInternalMemoizedMaskedChildContext=e);return e}function Ff(a){a=a.childContextTypes;return null!==a&&void 0!==a}function Gf(){H(N);H(M)}function Hf(a,b,c){if(M.current!==Cf)throw Error(y(168));I(M,b);I(N,c)}
function If(a,b,c){var d=a.stateNode;a=b.childContextTypes;if("function"!==typeof d.getChildContext)return c;d=d.getChildContext();for(var e in d)if(!(e in a))throw Error(y(108,Ra(b)||"Unknown",e));return m({},c,d)}function Jf(a){a=(a=a.stateNode)&&a.__reactInternalMemoizedMergedChildContext||Cf;Df=M.current;I(M,a);I(N,N.current);return!0}function Kf(a,b,c){var d=a.stateNode;if(!d)throw Error(y(169));c?(a=If(a,b,Df),d.__reactInternalMemoizedMergedChildContext=a,H(N),H(M),I(M,a)):H(N);I(N,c)}
var Lf=null,Mf=null,Nf=r.unstable_runWithPriority,Of=r.unstable_scheduleCallback,Pf=r.unstable_cancelCallback,Qf=r.unstable_shouldYield,Rf=r.unstable_requestPaint,Sf=r.unstable_now,Tf=r.unstable_getCurrentPriorityLevel,Uf=r.unstable_ImmediatePriority,Vf=r.unstable_UserBlockingPriority,Wf=r.unstable_NormalPriority,Xf=r.unstable_LowPriority,Yf=r.unstable_IdlePriority,Zf={},$f=void 0!==Rf?Rf:function(){},ag=null,bg=null,cg=!1,dg=Sf(),O=1E4>dg?Sf:function(){return Sf()-dg};
function eg(){switch(Tf()){case Uf:return 99;case Vf:return 98;case Wf:return 97;case Xf:return 96;case Yf:return 95;default:throw Error(y(332));}}function fg(a){switch(a){case 99:return Uf;case 98:return Vf;case 97:return Wf;case 96:return Xf;case 95:return Yf;default:throw Error(y(332));}}function gg(a,b){a=fg(a);return Nf(a,b)}function hg(a,b,c){a=fg(a);return Of(a,b,c)}function ig(){if(null!==bg){var a=bg;bg=null;Pf(a)}jg()}
function jg(){if(!cg&&null!==ag){cg=!0;var a=0;try{var b=ag;gg(99,function(){for(;a<b.length;a++){var c=b[a];do c=c(!0);while(null!==c)}});ag=null}catch(c){throw null!==ag&&(ag=ag.slice(a+1)),Of(Uf,ig),c;}finally{cg=!1}}}var kg=ra.ReactCurrentBatchConfig;function lg(a,b){if(a&&a.defaultProps){b=m({},b);a=a.defaultProps;for(var c in a)void 0===b[c]&&(b[c]=a[c]);return b}return b}var mg=Bf(null),ng=null,og=null,pg=null;function qg(){pg=og=ng=null}
function rg(a){var b=mg.current;H(mg);a.type._context._currentValue=b}function sg(a,b){for(;null!==a;){var c=a.alternate;if((a.childLanes&b)===b)if(null===c||(c.childLanes&b)===b)break;else c.childLanes|=b;else a.childLanes|=b,null!==c&&(c.childLanes|=b);a=a.return}}function tg(a,b){ng=a;pg=og=null;a=a.dependencies;null!==a&&null!==a.firstContext&&(0!==(a.lanes&b)&&(ug=!0),a.firstContext=null)}
function vg(a,b){if(pg!==a&&!1!==b&&0!==b){if("number"!==typeof b||1073741823===b)pg=a,b=1073741823;b={context:a,observedBits:b,next:null};if(null===og){if(null===ng)throw Error(y(308));og=b;ng.dependencies={lanes:0,firstContext:b,responders:null}}else og=og.next=b}return a._currentValue}var wg=!1;function xg(a){a.updateQueue={baseState:a.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null},effects:null}}
function yg(a,b){a=a.updateQueue;b.updateQueue===a&&(b.updateQueue={baseState:a.baseState,firstBaseUpdate:a.firstBaseUpdate,lastBaseUpdate:a.lastBaseUpdate,shared:a.shared,effects:a.effects})}function zg(a,b){return{eventTime:a,lane:b,tag:0,payload:null,callback:null,next:null}}function Ag(a,b){a=a.updateQueue;if(null!==a){a=a.shared;var c=a.pending;null===c?b.next=b:(b.next=c.next,c.next=b);a.pending=b}}
function Bg(a,b){var c=a.updateQueue,d=a.alternate;if(null!==d&&(d=d.updateQueue,c===d)){var e=null,f=null;c=c.firstBaseUpdate;if(null!==c){do{var g={eventTime:c.eventTime,lane:c.lane,tag:c.tag,payload:c.payload,callback:c.callback,next:null};null===f?e=f=g:f=f.next=g;c=c.next}while(null!==c);null===f?e=f=b:f=f.next=b}else e=f=b;c={baseState:d.baseState,firstBaseUpdate:e,lastBaseUpdate:f,shared:d.shared,effects:d.effects};a.updateQueue=c;return}a=c.lastBaseUpdate;null===a?c.firstBaseUpdate=b:a.next=
b;c.lastBaseUpdate=b}
function Cg(a,b,c,d){var e=a.updateQueue;wg=!1;var f=e.firstBaseUpdate,g=e.lastBaseUpdate,h=e.shared.pending;if(null!==h){e.shared.pending=null;var k=h,l=k.next;k.next=null;null===g?f=l:g.next=l;g=k;var n=a.alternate;if(null!==n){n=n.updateQueue;var A=n.lastBaseUpdate;A!==g&&(null===A?n.firstBaseUpdate=l:A.next=l,n.lastBaseUpdate=k)}}if(null!==f){A=e.baseState;g=0;n=l=k=null;do{h=f.lane;var p=f.eventTime;if((d&h)===h){null!==n&&(n=n.next={eventTime:p,lane:0,tag:f.tag,payload:f.payload,callback:f.callback,
next:null});a:{var C=a,x=f;h=b;p=c;switch(x.tag){case 1:C=x.payload;if("function"===typeof C){A=C.call(p,A,h);break a}A=C;break a;case 3:C.flags=C.flags&-4097|64;case 0:C=x.payload;h="function"===typeof C?C.call(p,A,h):C;if(null===h||void 0===h)break a;A=m({},A,h);break a;case 2:wg=!0}}null!==f.callback&&(a.flags|=32,h=e.effects,null===h?e.effects=[f]:h.push(f))}else p={eventTime:p,lane:h,tag:f.tag,payload:f.payload,callback:f.callback,next:null},null===n?(l=n=p,k=A):n=n.next=p,g|=h;f=f.next;if(null===
f)if(h=e.shared.pending,null===h)break;else f=h.next,h.next=null,e.lastBaseUpdate=h,e.shared.pending=null}while(1);null===n&&(k=A);e.baseState=k;e.firstBaseUpdate=l;e.lastBaseUpdate=n;Dg|=g;a.lanes=g;a.memoizedState=A}}function Eg(a,b,c){a=b.effects;b.effects=null;if(null!==a)for(b=0;b<a.length;b++){var d=a[b],e=d.callback;if(null!==e){d.callback=null;d=c;if("function"!==typeof e)throw Error(y(191,e));e.call(d)}}}var Fg=(new aa.Component).refs;
function Gg(a,b,c,d){b=a.memoizedState;c=c(d,b);c=null===c||void 0===c?b:m({},b,c);a.memoizedState=c;0===a.lanes&&(a.updateQueue.baseState=c)}
var Kg={isMounted:function(a){return(a=a._reactInternals)?Zb(a)===a:!1},enqueueSetState:function(a,b,c){a=a._reactInternals;var d=Hg(),e=Ig(a),f=zg(d,e);f.payload=b;void 0!==c&&null!==c&&(f.callback=c);Ag(a,f);Jg(a,e,d)},enqueueReplaceState:function(a,b,c){a=a._reactInternals;var d=Hg(),e=Ig(a),f=zg(d,e);f.tag=1;f.payload=b;void 0!==c&&null!==c&&(f.callback=c);Ag(a,f);Jg(a,e,d)},enqueueForceUpdate:function(a,b){a=a._reactInternals;var c=Hg(),d=Ig(a),e=zg(c,d);e.tag=2;void 0!==b&&null!==b&&(e.callback=
b);Ag(a,e);Jg(a,d,c)}};function Lg(a,b,c,d,e,f,g){a=a.stateNode;return"function"===typeof a.shouldComponentUpdate?a.shouldComponentUpdate(d,f,g):b.prototype&&b.prototype.isPureReactComponent?!Je(c,d)||!Je(e,f):!0}
function Mg(a,b,c){var d=!1,e=Cf;var f=b.contextType;"object"===typeof f&&null!==f?f=vg(f):(e=Ff(b)?Df:M.current,d=b.contextTypes,f=(d=null!==d&&void 0!==d)?Ef(a,e):Cf);b=new b(c,f);a.memoizedState=null!==b.state&&void 0!==b.state?b.state:null;b.updater=Kg;a.stateNode=b;b._reactInternals=a;d&&(a=a.stateNode,a.__reactInternalMemoizedUnmaskedChildContext=e,a.__reactInternalMemoizedMaskedChildContext=f);return b}
function Ng(a,b,c,d){a=b.state;"function"===typeof b.componentWillReceiveProps&&b.componentWillReceiveProps(c,d);"function"===typeof b.UNSAFE_componentWillReceiveProps&&b.UNSAFE_componentWillReceiveProps(c,d);b.state!==a&&Kg.enqueueReplaceState(b,b.state,null)}
function Og(a,b,c,d){var e=a.stateNode;e.props=c;e.state=a.memoizedState;e.refs=Fg;xg(a);var f=b.contextType;"object"===typeof f&&null!==f?e.context=vg(f):(f=Ff(b)?Df:M.current,e.context=Ef(a,f));Cg(a,c,e,d);e.state=a.memoizedState;f=b.getDerivedStateFromProps;"function"===typeof f&&(Gg(a,b,f,c),e.state=a.memoizedState);"function"===typeof b.getDerivedStateFromProps||"function"===typeof e.getSnapshotBeforeUpdate||"function"!==typeof e.UNSAFE_componentWillMount&&"function"!==typeof e.componentWillMount||
(b=e.state,"function"===typeof e.componentWillMount&&e.componentWillMount(),"function"===typeof e.UNSAFE_componentWillMount&&e.UNSAFE_componentWillMount(),b!==e.state&&Kg.enqueueReplaceState(e,e.state,null),Cg(a,c,e,d),e.state=a.memoizedState);"function"===typeof e.componentDidMount&&(a.flags|=4)}var Pg=Array.isArray;
function Qg(a,b,c){a=c.ref;if(null!==a&&"function"!==typeof a&&"object"!==typeof a){if(c._owner){c=c._owner;if(c){if(1!==c.tag)throw Error(y(309));var d=c.stateNode}if(!d)throw Error(y(147,a));var e=""+a;if(null!==b&&null!==b.ref&&"function"===typeof b.ref&&b.ref._stringRef===e)return b.ref;b=function(a){var b=d.refs;b===Fg&&(b=d.refs={});null===a?delete b[e]:b[e]=a};b._stringRef=e;return b}if("string"!==typeof a)throw Error(y(284));if(!c._owner)throw Error(y(290,a));}return a}
function Rg(a,b){if("textarea"!==a.type)throw Error(y(31,"[object Object]"===Object.prototype.toString.call(b)?"object with keys {"+Object.keys(b).join(", ")+"}":b));}
function Sg(a){function b(b,c){if(a){var d=b.lastEffect;null!==d?(d.nextEffect=c,b.lastEffect=c):b.firstEffect=b.lastEffect=c;c.nextEffect=null;c.flags=8}}function c(c,d){if(!a)return null;for(;null!==d;)b(c,d),d=d.sibling;return null}function d(a,b){for(a=new Map;null!==b;)null!==b.key?a.set(b.key,b):a.set(b.index,b),b=b.sibling;return a}function e(a,b){a=Tg(a,b);a.index=0;a.sibling=null;return a}function f(b,c,d){b.index=d;if(!a)return c;d=b.alternate;if(null!==d)return d=d.index,d<c?(b.flags=2,
c):d;b.flags=2;return c}function g(b){a&&null===b.alternate&&(b.flags=2);return b}function h(a,b,c,d){if(null===b||6!==b.tag)return b=Ug(c,a.mode,d),b.return=a,b;b=e(b,c);b.return=a;return b}function k(a,b,c,d){if(null!==b&&b.elementType===c.type)return d=e(b,c.props),d.ref=Qg(a,b,c),d.return=a,d;d=Vg(c.type,c.key,c.props,null,a.mode,d);d.ref=Qg(a,b,c);d.return=a;return d}function l(a,b,c,d){if(null===b||4!==b.tag||b.stateNode.containerInfo!==c.containerInfo||b.stateNode.implementation!==c.implementation)return b=
Wg(c,a.mode,d),b.return=a,b;b=e(b,c.children||[]);b.return=a;return b}function n(a,b,c,d,f){if(null===b||7!==b.tag)return b=Xg(c,a.mode,d,f),b.return=a,b;b=e(b,c);b.return=a;return b}function A(a,b,c){if("string"===typeof b||"number"===typeof b)return b=Ug(""+b,a.mode,c),b.return=a,b;if("object"===typeof b&&null!==b){switch(b.$$typeof){case sa:return c=Vg(b.type,b.key,b.props,null,a.mode,c),c.ref=Qg(a,null,b),c.return=a,c;case ta:return b=Wg(b,a.mode,c),b.return=a,b}if(Pg(b)||La(b))return b=Xg(b,
a.mode,c,null),b.return=a,b;Rg(a,b)}return null}function p(a,b,c,d){var e=null!==b?b.key:null;if("string"===typeof c||"number"===typeof c)return null!==e?null:h(a,b,""+c,d);if("object"===typeof c&&null!==c){switch(c.$$typeof){case sa:return c.key===e?c.type===ua?n(a,b,c.props.children,d,e):k(a,b,c,d):null;case ta:return c.key===e?l(a,b,c,d):null}if(Pg(c)||La(c))return null!==e?null:n(a,b,c,d,null);Rg(a,c)}return null}function C(a,b,c,d,e){if("string"===typeof d||"number"===typeof d)return a=a.get(c)||
null,h(b,a,""+d,e);if("object"===typeof d&&null!==d){switch(d.$$typeof){case sa:return a=a.get(null===d.key?c:d.key)||null,d.type===ua?n(b,a,d.props.children,e,d.key):k(b,a,d,e);case ta:return a=a.get(null===d.key?c:d.key)||null,l(b,a,d,e)}if(Pg(d)||La(d))return a=a.get(c)||null,n(b,a,d,e,null);Rg(b,d)}return null}function x(e,g,h,k){for(var l=null,t=null,u=g,z=g=0,q=null;null!==u&&z<h.length;z++){u.index>z?(q=u,u=null):q=u.sibling;var n=p(e,u,h[z],k);if(null===n){null===u&&(u=q);break}a&&u&&null===
n.alternate&&b(e,u);g=f(n,g,z);null===t?l=n:t.sibling=n;t=n;u=q}if(z===h.length)return c(e,u),l;if(null===u){for(;z<h.length;z++)u=A(e,h[z],k),null!==u&&(g=f(u,g,z),null===t?l=u:t.sibling=u,t=u);return l}for(u=d(e,u);z<h.length;z++)q=C(u,e,z,h[z],k),null!==q&&(a&&null!==q.alternate&&u.delete(null===q.key?z:q.key),g=f(q,g,z),null===t?l=q:t.sibling=q,t=q);a&&u.forEach(function(a){return b(e,a)});return l}function w(e,g,h,k){var l=La(h);if("function"!==typeof l)throw Error(y(150));h=l.call(h);if(null==
h)throw Error(y(151));for(var t=l=null,u=g,z=g=0,q=null,n=h.next();null!==u&&!n.done;z++,n=h.next()){u.index>z?(q=u,u=null):q=u.sibling;var w=p(e,u,n.value,k);if(null===w){null===u&&(u=q);break}a&&u&&null===w.alternate&&b(e,u);g=f(w,g,z);null===t?l=w:t.sibling=w;t=w;u=q}if(n.done)return c(e,u),l;if(null===u){for(;!n.done;z++,n=h.next())n=A(e,n.value,k),null!==n&&(g=f(n,g,z),null===t?l=n:t.sibling=n,t=n);return l}for(u=d(e,u);!n.done;z++,n=h.next())n=C(u,e,z,n.value,k),null!==n&&(a&&null!==n.alternate&&
u.delete(null===n.key?z:n.key),g=f(n,g,z),null===t?l=n:t.sibling=n,t=n);a&&u.forEach(function(a){return b(e,a)});return l}return function(a,d,f,h){var k="object"===typeof f&&null!==f&&f.type===ua&&null===f.key;k&&(f=f.props.children);var l="object"===typeof f&&null!==f;if(l)switch(f.$$typeof){case sa:a:{l=f.key;for(k=d;null!==k;){if(k.key===l){switch(k.tag){case 7:if(f.type===ua){c(a,k.sibling);d=e(k,f.props.children);d.return=a;a=d;break a}break;default:if(k.elementType===f.type){c(a,k.sibling);
d=e(k,f.props);d.ref=Qg(a,k,f);d.return=a;a=d;break a}}c(a,k);break}else b(a,k);k=k.sibling}f.type===ua?(d=Xg(f.props.children,a.mode,h,f.key),d.return=a,a=d):(h=Vg(f.type,f.key,f.props,null,a.mode,h),h.ref=Qg(a,d,f),h.return=a,a=h)}return g(a);case ta:a:{for(k=f.key;null!==d;){if(d.key===k)if(4===d.tag&&d.stateNode.containerInfo===f.containerInfo&&d.stateNode.implementation===f.implementation){c(a,d.sibling);d=e(d,f.children||[]);d.return=a;a=d;break a}else{c(a,d);break}else b(a,d);d=d.sibling}d=
Wg(f,a.mode,h);d.return=a;a=d}return g(a)}if("string"===typeof f||"number"===typeof f)return f=""+f,null!==d&&6===d.tag?(c(a,d.sibling),d=e(d,f),d.return=a,a=d):(c(a,d),d=Ug(f,a.mode,h),d.return=a,a=d),g(a);if(Pg(f))return x(a,d,f,h);if(La(f))return w(a,d,f,h);l&&Rg(a,f);if("undefined"===typeof f&&!k)switch(a.tag){case 1:case 22:case 0:case 11:case 15:throw Error(y(152,Ra(a.type)||"Component"));}return c(a,d)}}var Yg=Sg(!0),Zg=Sg(!1),$g={},ah=Bf($g),bh=Bf($g),ch=Bf($g);
function dh(a){if(a===$g)throw Error(y(174));return a}function eh(a,b){I(ch,b);I(bh,a);I(ah,$g);a=b.nodeType;switch(a){case 9:case 11:b=(b=b.documentElement)?b.namespaceURI:mb(null,"");break;default:a=8===a?b.parentNode:b,b=a.namespaceURI||null,a=a.tagName,b=mb(b,a)}H(ah);I(ah,b)}function fh(){H(ah);H(bh);H(ch)}function gh(a){dh(ch.current);var b=dh(ah.current);var c=mb(b,a.type);b!==c&&(I(bh,a),I(ah,c))}function hh(a){bh.current===a&&(H(ah),H(bh))}var P=Bf(0);
function ih(a){for(var b=a;null!==b;){if(13===b.tag){var c=b.memoizedState;if(null!==c&&(c=c.dehydrated,null===c||"$?"===c.data||"$!"===c.data))return b}else if(19===b.tag&&void 0!==b.memoizedProps.revealOrder){if(0!==(b.flags&64))return b}else if(null!==b.child){b.child.return=b;b=b.child;continue}if(b===a)break;for(;null===b.sibling;){if(null===b.return||b.return===a)return null;b=b.return}b.sibling.return=b.return;b=b.sibling}return null}var jh=null,kh=null,lh=!1;
function mh(a,b){var c=nh(5,null,null,0);c.elementType="DELETED";c.type="DELETED";c.stateNode=b;c.return=a;c.flags=8;null!==a.lastEffect?(a.lastEffect.nextEffect=c,a.lastEffect=c):a.firstEffect=a.lastEffect=c}function oh(a,b){switch(a.tag){case 5:var c=a.type;b=1!==b.nodeType||c.toLowerCase()!==b.nodeName.toLowerCase()?null:b;return null!==b?(a.stateNode=b,!0):!1;case 6:return b=""===a.pendingProps||3!==b.nodeType?null:b,null!==b?(a.stateNode=b,!0):!1;case 13:return!1;default:return!1}}
function ph(a){if(lh){var b=kh;if(b){var c=b;if(!oh(a,b)){b=rf(c.nextSibling);if(!b||!oh(a,b)){a.flags=a.flags&-1025|2;lh=!1;jh=a;return}mh(jh,c)}jh=a;kh=rf(b.firstChild)}else a.flags=a.flags&-1025|2,lh=!1,jh=a}}function qh(a){for(a=a.return;null!==a&&5!==a.tag&&3!==a.tag&&13!==a.tag;)a=a.return;jh=a}
function rh(a){if(a!==jh)return!1;if(!lh)return qh(a),lh=!0,!1;var b=a.type;if(5!==a.tag||"head"!==b&&"body"!==b&&!nf(b,a.memoizedProps))for(b=kh;b;)mh(a,b),b=rf(b.nextSibling);qh(a);if(13===a.tag){a=a.memoizedState;a=null!==a?a.dehydrated:null;if(!a)throw Error(y(317));a:{a=a.nextSibling;for(b=0;a;){if(8===a.nodeType){var c=a.data;if("/$"===c){if(0===b){kh=rf(a.nextSibling);break a}b--}else"$"!==c&&"$!"!==c&&"$?"!==c||b++}a=a.nextSibling}kh=null}}else kh=jh?rf(a.stateNode.nextSibling):null;return!0}
function sh(){kh=jh=null;lh=!1}var th=[];function uh(){for(var a=0;a<th.length;a++)th[a]._workInProgressVersionPrimary=null;th.length=0}var vh=ra.ReactCurrentDispatcher,wh=ra.ReactCurrentBatchConfig,xh=0,R=null,S=null,T=null,yh=!1,zh=!1;function Ah(){throw Error(y(321));}function Bh(a,b){if(null===b)return!1;for(var c=0;c<b.length&&c<a.length;c++)if(!He(a[c],b[c]))return!1;return!0}
function Ch(a,b,c,d,e,f){xh=f;R=b;b.memoizedState=null;b.updateQueue=null;b.lanes=0;vh.current=null===a||null===a.memoizedState?Dh:Eh;a=c(d,e);if(zh){f=0;do{zh=!1;if(!(25>f))throw Error(y(301));f+=1;T=S=null;b.updateQueue=null;vh.current=Fh;a=c(d,e)}while(zh)}vh.current=Gh;b=null!==S&&null!==S.next;xh=0;T=S=R=null;yh=!1;if(b)throw Error(y(300));return a}function Hh(){var a={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};null===T?R.memoizedState=T=a:T=T.next=a;return T}
function Ih(){if(null===S){var a=R.alternate;a=null!==a?a.memoizedState:null}else a=S.next;var b=null===T?R.memoizedState:T.next;if(null!==b)T=b,S=a;else{if(null===a)throw Error(y(310));S=a;a={memoizedState:S.memoizedState,baseState:S.baseState,baseQueue:S.baseQueue,queue:S.queue,next:null};null===T?R.memoizedState=T=a:T=T.next=a}return T}function Jh(a,b){return"function"===typeof b?b(a):b}
function Kh(a){var b=Ih(),c=b.queue;if(null===c)throw Error(y(311));c.lastRenderedReducer=a;var d=S,e=d.baseQueue,f=c.pending;if(null!==f){if(null!==e){var g=e.next;e.next=f.next;f.next=g}d.baseQueue=e=f;c.pending=null}if(null!==e){e=e.next;d=d.baseState;var h=g=f=null,k=e;do{var l=k.lane;if((xh&l)===l)null!==h&&(h=h.next={lane:0,action:k.action,eagerReducer:k.eagerReducer,eagerState:k.eagerState,next:null}),d=k.eagerReducer===a?k.eagerState:a(d,k.action);else{var n={lane:l,action:k.action,eagerReducer:k.eagerReducer,
eagerState:k.eagerState,next:null};null===h?(g=h=n,f=d):h=h.next=n;R.lanes|=l;Dg|=l}k=k.next}while(null!==k&&k!==e);null===h?f=d:h.next=g;He(d,b.memoizedState)||(ug=!0);b.memoizedState=d;b.baseState=f;b.baseQueue=h;c.lastRenderedState=d}return[b.memoizedState,c.dispatch]}
function Lh(a){var b=Ih(),c=b.queue;if(null===c)throw Error(y(311));c.lastRenderedReducer=a;var d=c.dispatch,e=c.pending,f=b.memoizedState;if(null!==e){c.pending=null;var g=e=e.next;do f=a(f,g.action),g=g.next;while(g!==e);He(f,b.memoizedState)||(ug=!0);b.memoizedState=f;null===b.baseQueue&&(b.baseState=f);c.lastRenderedState=f}return[f,d]}
function Mh(a,b,c){var d=b._getVersion;d=d(b._source);var e=b._workInProgressVersionPrimary;if(null!==e)a=e===d;else if(a=a.mutableReadLanes,a=(xh&a)===a)b._workInProgressVersionPrimary=d,th.push(b);if(a)return c(b._source);th.push(b);throw Error(y(350));}
function Nh(a,b,c,d){var e=U;if(null===e)throw Error(y(349));var f=b._getVersion,g=f(b._source),h=vh.current,k=h.useState(function(){return Mh(e,b,c)}),l=k[1],n=k[0];k=T;var A=a.memoizedState,p=A.refs,C=p.getSnapshot,x=A.source;A=A.subscribe;var w=R;a.memoizedState={refs:p,source:b,subscribe:d};h.useEffect(function(){p.getSnapshot=c;p.setSnapshot=l;var a=f(b._source);if(!He(g,a)){a=c(b._source);He(n,a)||(l(a),a=Ig(w),e.mutableReadLanes|=a&e.pendingLanes);a=e.mutableReadLanes;e.entangledLanes|=a;for(var d=
e.entanglements,h=a;0<h;){var k=31-Vc(h),v=1<<k;d[k]|=a;h&=~v}}},[c,b,d]);h.useEffect(function(){return d(b._source,function(){var a=p.getSnapshot,c=p.setSnapshot;try{c(a(b._source));var d=Ig(w);e.mutableReadLanes|=d&e.pendingLanes}catch(q){c(function(){throw q;})}})},[b,d]);He(C,c)&&He(x,b)&&He(A,d)||(a={pending:null,dispatch:null,lastRenderedReducer:Jh,lastRenderedState:n},a.dispatch=l=Oh.bind(null,R,a),k.queue=a,k.baseQueue=null,n=Mh(e,b,c),k.memoizedState=k.baseState=n);return n}
function Ph(a,b,c){var d=Ih();return Nh(d,a,b,c)}function Qh(a){var b=Hh();"function"===typeof a&&(a=a());b.memoizedState=b.baseState=a;a=b.queue={pending:null,dispatch:null,lastRenderedReducer:Jh,lastRenderedState:a};a=a.dispatch=Oh.bind(null,R,a);return[b.memoizedState,a]}
function Rh(a,b,c,d){a={tag:a,create:b,destroy:c,deps:d,next:null};b=R.updateQueue;null===b?(b={lastEffect:null},R.updateQueue=b,b.lastEffect=a.next=a):(c=b.lastEffect,null===c?b.lastEffect=a.next=a:(d=c.next,c.next=a,a.next=d,b.lastEffect=a));return a}function Sh(a){var b=Hh();a={current:a};return b.memoizedState=a}function Th(){return Ih().memoizedState}function Uh(a,b,c,d){var e=Hh();R.flags|=a;e.memoizedState=Rh(1|b,c,void 0,void 0===d?null:d)}
function Vh(a,b,c,d){var e=Ih();d=void 0===d?null:d;var f=void 0;if(null!==S){var g=S.memoizedState;f=g.destroy;if(null!==d&&Bh(d,g.deps)){Rh(b,c,f,d);return}}R.flags|=a;e.memoizedState=Rh(1|b,c,f,d)}function Wh(a,b){return Uh(516,4,a,b)}function Xh(a,b){return Vh(516,4,a,b)}function Yh(a,b){return Vh(4,2,a,b)}function Zh(a,b){if("function"===typeof b)return a=a(),b(a),function(){b(null)};if(null!==b&&void 0!==b)return a=a(),b.current=a,function(){b.current=null}}
function $h(a,b,c){c=null!==c&&void 0!==c?c.concat([a]):null;return Vh(4,2,Zh.bind(null,b,a),c)}function ai(){}function bi(a,b){var c=Ih();b=void 0===b?null:b;var d=c.memoizedState;if(null!==d&&null!==b&&Bh(b,d[1]))return d[0];c.memoizedState=[a,b];return a}function ci(a,b){var c=Ih();b=void 0===b?null:b;var d=c.memoizedState;if(null!==d&&null!==b&&Bh(b,d[1]))return d[0];a=a();c.memoizedState=[a,b];return a}
function di(a,b){var c=eg();gg(98>c?98:c,function(){a(!0)});gg(97<c?97:c,function(){var c=wh.transition;wh.transition=1;try{a(!1),b()}finally{wh.transition=c}})}
function Oh(a,b,c){var d=Hg(),e=Ig(a),f={lane:e,action:c,eagerReducer:null,eagerState:null,next:null},g=b.pending;null===g?f.next=f:(f.next=g.next,g.next=f);b.pending=f;g=a.alternate;if(a===R||null!==g&&g===R)zh=yh=!0;else{if(0===a.lanes&&(null===g||0===g.lanes)&&(g=b.lastRenderedReducer,null!==g))try{var h=b.lastRenderedState,k=g(h,c);f.eagerReducer=g;f.eagerState=k;if(He(k,h))return}catch(l){}finally{}Jg(a,e,d)}}
var Gh={readContext:vg,useCallback:Ah,useContext:Ah,useEffect:Ah,useImperativeHandle:Ah,useLayoutEffect:Ah,useMemo:Ah,useReducer:Ah,useRef:Ah,useState:Ah,useDebugValue:Ah,useDeferredValue:Ah,useTransition:Ah,useMutableSource:Ah,useOpaqueIdentifier:Ah,unstable_isNewReconciler:!1},Dh={readContext:vg,useCallback:function(a,b){Hh().memoizedState=[a,void 0===b?null:b];return a},useContext:vg,useEffect:Wh,useImperativeHandle:function(a,b,c){c=null!==c&&void 0!==c?c.concat([a]):null;return Uh(4,2,Zh.bind(null,
b,a),c)},useLayoutEffect:function(a,b){return Uh(4,2,a,b)},useMemo:function(a,b){var c=Hh();b=void 0===b?null:b;a=a();c.memoizedState=[a,b];return a},useReducer:function(a,b,c){var d=Hh();b=void 0!==c?c(b):b;d.memoizedState=d.baseState=b;a=d.queue={pending:null,dispatch:null,lastRenderedReducer:a,lastRenderedState:b};a=a.dispatch=Oh.bind(null,R,a);return[d.memoizedState,a]},useRef:Sh,useState:Qh,useDebugValue:ai,useDeferredValue:function(a){var b=Qh(a),c=b[0],d=b[1];Wh(function(){var b=wh.transition;
wh.transition=1;try{d(a)}finally{wh.transition=b}},[a]);return c},useTransition:function(){var a=Qh(!1),b=a[0];a=di.bind(null,a[1]);Sh(a);return[a,b]},useMutableSource:function(a,b,c){var d=Hh();d.memoizedState={refs:{getSnapshot:b,setSnapshot:null},source:a,subscribe:c};return Nh(d,a,b,c)},useOpaqueIdentifier:function(){if(lh){var a=!1,b=uf(function(){a||(a=!0,c("r:"+(tf++).toString(36)));throw Error(y(355));}),c=Qh(b)[1];0===(R.mode&2)&&(R.flags|=516,Rh(5,function(){c("r:"+(tf++).toString(36))},
void 0,null));return b}b="r:"+(tf++).toString(36);Qh(b);return b},unstable_isNewReconciler:!1},Eh={readContext:vg,useCallback:bi,useContext:vg,useEffect:Xh,useImperativeHandle:$h,useLayoutEffect:Yh,useMemo:ci,useReducer:Kh,useRef:Th,useState:function(){return Kh(Jh)},useDebugValue:ai,useDeferredValue:function(a){var b=Kh(Jh),c=b[0],d=b[1];Xh(function(){var b=wh.transition;wh.transition=1;try{d(a)}finally{wh.transition=b}},[a]);return c},useTransition:function(){var a=Kh(Jh)[0];return[Th().current,
a]},useMutableSource:Ph,useOpaqueIdentifier:function(){return Kh(Jh)[0]},unstable_isNewReconciler:!1},Fh={readContext:vg,useCallback:bi,useContext:vg,useEffect:Xh,useImperativeHandle:$h,useLayoutEffect:Yh,useMemo:ci,useReducer:Lh,useRef:Th,useState:function(){return Lh(Jh)},useDebugValue:ai,useDeferredValue:function(a){var b=Lh(Jh),c=b[0],d=b[1];Xh(function(){var b=wh.transition;wh.transition=1;try{d(a)}finally{wh.transition=b}},[a]);return c},useTransition:function(){var a=Lh(Jh)[0];return[Th().current,
a]},useMutableSource:Ph,useOpaqueIdentifier:function(){return Lh(Jh)[0]},unstable_isNewReconciler:!1},ei=ra.ReactCurrentOwner,ug=!1;function fi(a,b,c,d){b.child=null===a?Zg(b,null,c,d):Yg(b,a.child,c,d)}function gi(a,b,c,d,e){c=c.render;var f=b.ref;tg(b,e);d=Ch(a,b,c,d,f,e);if(null!==a&&!ug)return b.updateQueue=a.updateQueue,b.flags&=-517,a.lanes&=~e,hi(a,b,e);b.flags|=1;fi(a,b,d,e);return b.child}
function ii(a,b,c,d,e,f){if(null===a){var g=c.type;if("function"===typeof g&&!ji(g)&&void 0===g.defaultProps&&null===c.compare&&void 0===c.defaultProps)return b.tag=15,b.type=g,ki(a,b,g,d,e,f);a=Vg(c.type,null,d,b,b.mode,f);a.ref=b.ref;a.return=b;return b.child=a}g=a.child;if(0===(e&f)&&(e=g.memoizedProps,c=c.compare,c=null!==c?c:Je,c(e,d)&&a.ref===b.ref))return hi(a,b,f);b.flags|=1;a=Tg(g,d);a.ref=b.ref;a.return=b;return b.child=a}
function ki(a,b,c,d,e,f){if(null!==a&&Je(a.memoizedProps,d)&&a.ref===b.ref)if(ug=!1,0!==(f&e))0!==(a.flags&16384)&&(ug=!0);else return b.lanes=a.lanes,hi(a,b,f);return li(a,b,c,d,f)}
function mi(a,b,c){var d=b.pendingProps,e=d.children,f=null!==a?a.memoizedState:null;if("hidden"===d.mode||"unstable-defer-without-hiding"===d.mode)if(0===(b.mode&4))b.memoizedState={baseLanes:0},ni(b,c);else if(0!==(c&1073741824))b.memoizedState={baseLanes:0},ni(b,null!==f?f.baseLanes:c);else return a=null!==f?f.baseLanes|c:c,b.lanes=b.childLanes=1073741824,b.memoizedState={baseLanes:a},ni(b,a),null;else null!==f?(d=f.baseLanes|c,b.memoizedState=null):d=c,ni(b,d);fi(a,b,e,c);return b.child}
function oi(a,b){var c=b.ref;if(null===a&&null!==c||null!==a&&a.ref!==c)b.flags|=128}function li(a,b,c,d,e){var f=Ff(c)?Df:M.current;f=Ef(b,f);tg(b,e);c=Ch(a,b,c,d,f,e);if(null!==a&&!ug)return b.updateQueue=a.updateQueue,b.flags&=-517,a.lanes&=~e,hi(a,b,e);b.flags|=1;fi(a,b,c,e);return b.child}
function pi(a,b,c,d,e){if(Ff(c)){var f=!0;Jf(b)}else f=!1;tg(b,e);if(null===b.stateNode)null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2),Mg(b,c,d),Og(b,c,d,e),d=!0;else if(null===a){var g=b.stateNode,h=b.memoizedProps;g.props=h;var k=g.context,l=c.contextType;"object"===typeof l&&null!==l?l=vg(l):(l=Ff(c)?Df:M.current,l=Ef(b,l));var n=c.getDerivedStateFromProps,A="function"===typeof n||"function"===typeof g.getSnapshotBeforeUpdate;A||"function"!==typeof g.UNSAFE_componentWillReceiveProps&&
"function"!==typeof g.componentWillReceiveProps||(h!==d||k!==l)&&Ng(b,g,d,l);wg=!1;var p=b.memoizedState;g.state=p;Cg(b,d,g,e);k=b.memoizedState;h!==d||p!==k||N.current||wg?("function"===typeof n&&(Gg(b,c,n,d),k=b.memoizedState),(h=wg||Lg(b,c,h,d,p,k,l))?(A||"function"!==typeof g.UNSAFE_componentWillMount&&"function"!==typeof g.componentWillMount||("function"===typeof g.componentWillMount&&g.componentWillMount(),"function"===typeof g.UNSAFE_componentWillMount&&g.UNSAFE_componentWillMount()),"function"===
typeof g.componentDidMount&&(b.flags|=4)):("function"===typeof g.componentDidMount&&(b.flags|=4),b.memoizedProps=d,b.memoizedState=k),g.props=d,g.state=k,g.context=l,d=h):("function"===typeof g.componentDidMount&&(b.flags|=4),d=!1)}else{g=b.stateNode;yg(a,b);h=b.memoizedProps;l=b.type===b.elementType?h:lg(b.type,h);g.props=l;A=b.pendingProps;p=g.context;k=c.contextType;"object"===typeof k&&null!==k?k=vg(k):(k=Ff(c)?Df:M.current,k=Ef(b,k));var C=c.getDerivedStateFromProps;(n="function"===typeof C||
"function"===typeof g.getSnapshotBeforeUpdate)||"function"!==typeof g.UNSAFE_componentWillReceiveProps&&"function"!==typeof g.componentWillReceiveProps||(h!==A||p!==k)&&Ng(b,g,d,k);wg=!1;p=b.memoizedState;g.state=p;Cg(b,d,g,e);var x=b.memoizedState;h!==A||p!==x||N.current||wg?("function"===typeof C&&(Gg(b,c,C,d),x=b.memoizedState),(l=wg||Lg(b,c,l,d,p,x,k))?(n||"function"!==typeof g.UNSAFE_componentWillUpdate&&"function"!==typeof g.componentWillUpdate||("function"===typeof g.componentWillUpdate&&g.componentWillUpdate(d,
x,k),"function"===typeof g.UNSAFE_componentWillUpdate&&g.UNSAFE_componentWillUpdate(d,x,k)),"function"===typeof g.componentDidUpdate&&(b.flags|=4),"function"===typeof g.getSnapshotBeforeUpdate&&(b.flags|=256)):("function"!==typeof g.componentDidUpdate||h===a.memoizedProps&&p===a.memoizedState||(b.flags|=4),"function"!==typeof g.getSnapshotBeforeUpdate||h===a.memoizedProps&&p===a.memoizedState||(b.flags|=256),b.memoizedProps=d,b.memoizedState=x),g.props=d,g.state=x,g.context=k,d=l):("function"!==typeof g.componentDidUpdate||
h===a.memoizedProps&&p===a.memoizedState||(b.flags|=4),"function"!==typeof g.getSnapshotBeforeUpdate||h===a.memoizedProps&&p===a.memoizedState||(b.flags|=256),d=!1)}return qi(a,b,c,d,f,e)}
function qi(a,b,c,d,e,f){oi(a,b);var g=0!==(b.flags&64);if(!d&&!g)return e&&Kf(b,c,!1),hi(a,b,f);d=b.stateNode;ei.current=b;var h=g&&"function"!==typeof c.getDerivedStateFromError?null:d.render();b.flags|=1;null!==a&&g?(b.child=Yg(b,a.child,null,f),b.child=Yg(b,null,h,f)):fi(a,b,h,f);b.memoizedState=d.state;e&&Kf(b,c,!0);return b.child}function ri(a){var b=a.stateNode;b.pendingContext?Hf(a,b.pendingContext,b.pendingContext!==b.context):b.context&&Hf(a,b.context,!1);eh(a,b.containerInfo)}
var si={dehydrated:null,retryLane:0};
function ti(a,b,c){var d=b.pendingProps,e=P.current,f=!1,g;(g=0!==(b.flags&64))||(g=null!==a&&null===a.memoizedState?!1:0!==(e&2));g?(f=!0,b.flags&=-65):null!==a&&null===a.memoizedState||void 0===d.fallback||!0===d.unstable_avoidThisFallback||(e|=1);I(P,e&1);if(null===a){void 0!==d.fallback&&ph(b);a=d.children;e=d.fallback;if(f)return a=ui(b,a,e,c),b.child.memoizedState={baseLanes:c},b.memoizedState=si,a;if("number"===typeof d.unstable_expectedLoadTime)return a=ui(b,a,e,c),b.child.memoizedState={baseLanes:c},
b.memoizedState=si,b.lanes=33554432,a;c=vi({mode:"visible",children:a},b.mode,c,null);c.return=b;return b.child=c}if(null!==a.memoizedState){if(f)return d=wi(a,b,d.children,d.fallback,c),f=b.child,e=a.child.memoizedState,f.memoizedState=null===e?{baseLanes:c}:{baseLanes:e.baseLanes|c},f.childLanes=a.childLanes&~c,b.memoizedState=si,d;c=xi(a,b,d.children,c);b.memoizedState=null;return c}if(f)return d=wi(a,b,d.children,d.fallback,c),f=b.child,e=a.child.memoizedState,f.memoizedState=null===e?{baseLanes:c}:
{baseLanes:e.baseLanes|c},f.childLanes=a.childLanes&~c,b.memoizedState=si,d;c=xi(a,b,d.children,c);b.memoizedState=null;return c}function ui(a,b,c,d){var e=a.mode,f=a.child;b={mode:"hidden",children:b};0===(e&2)&&null!==f?(f.childLanes=0,f.pendingProps=b):f=vi(b,e,0,null);c=Xg(c,e,d,null);f.return=a;c.return=a;f.sibling=c;a.child=f;return c}
function xi(a,b,c,d){var e=a.child;a=e.sibling;c=Tg(e,{mode:"visible",children:c});0===(b.mode&2)&&(c.lanes=d);c.return=b;c.sibling=null;null!==a&&(a.nextEffect=null,a.flags=8,b.firstEffect=b.lastEffect=a);return b.child=c}
function wi(a,b,c,d,e){var f=b.mode,g=a.child;a=g.sibling;var h={mode:"hidden",children:c};0===(f&2)&&b.child!==g?(c=b.child,c.childLanes=0,c.pendingProps=h,g=c.lastEffect,null!==g?(b.firstEffect=c.firstEffect,b.lastEffect=g,g.nextEffect=null):b.firstEffect=b.lastEffect=null):c=Tg(g,h);null!==a?d=Tg(a,d):(d=Xg(d,f,e,null),d.flags|=2);d.return=b;c.return=b;c.sibling=d;b.child=c;return d}function yi(a,b){a.lanes|=b;var c=a.alternate;null!==c&&(c.lanes|=b);sg(a.return,b)}
function zi(a,b,c,d,e,f){var g=a.memoizedState;null===g?a.memoizedState={isBackwards:b,rendering:null,renderingStartTime:0,last:d,tail:c,tailMode:e,lastEffect:f}:(g.isBackwards=b,g.rendering=null,g.renderingStartTime=0,g.last=d,g.tail=c,g.tailMode=e,g.lastEffect=f)}
function Ai(a,b,c){var d=b.pendingProps,e=d.revealOrder,f=d.tail;fi(a,b,d.children,c);d=P.current;if(0!==(d&2))d=d&1|2,b.flags|=64;else{if(null!==a&&0!==(a.flags&64))a:for(a=b.child;null!==a;){if(13===a.tag)null!==a.memoizedState&&yi(a,c);else if(19===a.tag)yi(a,c);else if(null!==a.child){a.child.return=a;a=a.child;continue}if(a===b)break a;for(;null===a.sibling;){if(null===a.return||a.return===b)break a;a=a.return}a.sibling.return=a.return;a=a.sibling}d&=1}I(P,d);if(0===(b.mode&2))b.memoizedState=
null;else switch(e){case "forwards":c=b.child;for(e=null;null!==c;)a=c.alternate,null!==a&&null===ih(a)&&(e=c),c=c.sibling;c=e;null===c?(e=b.child,b.child=null):(e=c.sibling,c.sibling=null);zi(b,!1,e,c,f,b.lastEffect);break;case "backwards":c=null;e=b.child;for(b.child=null;null!==e;){a=e.alternate;if(null!==a&&null===ih(a)){b.child=e;break}a=e.sibling;e.sibling=c;c=e;e=a}zi(b,!0,c,null,f,b.lastEffect);break;case "together":zi(b,!1,null,null,void 0,b.lastEffect);break;default:b.memoizedState=null}return b.child}
function hi(a,b,c){null!==a&&(b.dependencies=a.dependencies);Dg|=b.lanes;if(0!==(c&b.childLanes)){if(null!==a&&b.child!==a.child)throw Error(y(153));if(null!==b.child){a=b.child;c=Tg(a,a.pendingProps);b.child=c;for(c.return=b;null!==a.sibling;)a=a.sibling,c=c.sibling=Tg(a,a.pendingProps),c.return=b;c.sibling=null}return b.child}return null}var Bi,Ci,Di,Ei;
Bi=function(a,b){for(var c=b.child;null!==c;){if(5===c.tag||6===c.tag)a.appendChild(c.stateNode);else if(4!==c.tag&&null!==c.child){c.child.return=c;c=c.child;continue}if(c===b)break;for(;null===c.sibling;){if(null===c.return||c.return===b)return;c=c.return}c.sibling.return=c.return;c=c.sibling}};Ci=function(){};
Di=function(a,b,c,d){var e=a.memoizedProps;if(e!==d){a=b.stateNode;dh(ah.current);var f=null;switch(c){case "input":e=Ya(a,e);d=Ya(a,d);f=[];break;case "option":e=eb(a,e);d=eb(a,d);f=[];break;case "select":e=m({},e,{value:void 0});d=m({},d,{value:void 0});f=[];break;case "textarea":e=gb(a,e);d=gb(a,d);f=[];break;default:"function"!==typeof e.onClick&&"function"===typeof d.onClick&&(a.onclick=jf)}vb(c,d);var g;c=null;for(l in e)if(!d.hasOwnProperty(l)&&e.hasOwnProperty(l)&&null!=e[l])if("style"===
l){var h=e[l];for(g in h)h.hasOwnProperty(g)&&(c||(c={}),c[g]="")}else"dangerouslySetInnerHTML"!==l&&"children"!==l&&"suppressContentEditableWarning"!==l&&"suppressHydrationWarning"!==l&&"autoFocus"!==l&&(ca.hasOwnProperty(l)?f||(f=[]):(f=f||[]).push(l,null));for(l in d){var k=d[l];h=null!=e?e[l]:void 0;if(d.hasOwnProperty(l)&&k!==h&&(null!=k||null!=h))if("style"===l)if(h){for(g in h)!h.hasOwnProperty(g)||k&&k.hasOwnProperty(g)||(c||(c={}),c[g]="");for(g in k)k.hasOwnProperty(g)&&h[g]!==k[g]&&(c||
(c={}),c[g]=k[g])}else c||(f||(f=[]),f.push(l,c)),c=k;else"dangerouslySetInnerHTML"===l?(k=k?k.__html:void 0,h=h?h.__html:void 0,null!=k&&h!==k&&(f=f||[]).push(l,k)):"children"===l?"string"!==typeof k&&"number"!==typeof k||(f=f||[]).push(l,""+k):"suppressContentEditableWarning"!==l&&"suppressHydrationWarning"!==l&&(ca.hasOwnProperty(l)?(null!=k&&"onScroll"===l&&G("scroll",a),f||h===k||(f=[])):"object"===typeof k&&null!==k&&k.$$typeof===Ga?k.toString():(f=f||[]).push(l,k))}c&&(f=f||[]).push("style",
c);var l=f;if(b.updateQueue=l)b.flags|=4}};Ei=function(a,b,c,d){c!==d&&(b.flags|=4)};function Fi(a,b){if(!lh)switch(a.tailMode){case "hidden":b=a.tail;for(var c=null;null!==b;)null!==b.alternate&&(c=b),b=b.sibling;null===c?a.tail=null:c.sibling=null;break;case "collapsed":c=a.tail;for(var d=null;null!==c;)null!==c.alternate&&(d=c),c=c.sibling;null===d?b||null===a.tail?a.tail=null:a.tail.sibling=null:d.sibling=null}}
function Gi(a,b,c){var d=b.pendingProps;switch(b.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return null;case 1:return Ff(b.type)&&Gf(),null;case 3:fh();H(N);H(M);uh();d=b.stateNode;d.pendingContext&&(d.context=d.pendingContext,d.pendingContext=null);if(null===a||null===a.child)rh(b)?b.flags|=4:d.hydrate||(b.flags|=256);Ci(b);return null;case 5:hh(b);var e=dh(ch.current);c=b.type;if(null!==a&&null!=b.stateNode)Di(a,b,c,d,e),a.ref!==b.ref&&(b.flags|=128);else{if(!d){if(null===
b.stateNode)throw Error(y(166));return null}a=dh(ah.current);if(rh(b)){d=b.stateNode;c=b.type;var f=b.memoizedProps;d[wf]=b;d[xf]=f;switch(c){case "dialog":G("cancel",d);G("close",d);break;case "iframe":case "object":case "embed":G("load",d);break;case "video":case "audio":for(a=0;a<Xe.length;a++)G(Xe[a],d);break;case "source":G("error",d);break;case "img":case "image":case "link":G("error",d);G("load",d);break;case "details":G("toggle",d);break;case "input":Za(d,f);G("invalid",d);break;case "select":d._wrapperState=
{wasMultiple:!!f.multiple};G("invalid",d);break;case "textarea":hb(d,f),G("invalid",d)}vb(c,f);a=null;for(var g in f)f.hasOwnProperty(g)&&(e=f[g],"children"===g?"string"===typeof e?d.textContent!==e&&(a=["children",e]):"number"===typeof e&&d.textContent!==""+e&&(a=["children",""+e]):ca.hasOwnProperty(g)&&null!=e&&"onScroll"===g&&G("scroll",d));switch(c){case "input":Va(d);cb(d,f,!0);break;case "textarea":Va(d);jb(d);break;case "select":case "option":break;default:"function"===typeof f.onClick&&(d.onclick=
jf)}d=a;b.updateQueue=d;null!==d&&(b.flags|=4)}else{g=9===e.nodeType?e:e.ownerDocument;a===kb.html&&(a=lb(c));a===kb.html?"script"===c?(a=g.createElement("div"),a.innerHTML="<script>\x3c/script>",a=a.removeChild(a.firstChild)):"string"===typeof d.is?a=g.createElement(c,{is:d.is}):(a=g.createElement(c),"select"===c&&(g=a,d.multiple?g.multiple=!0:d.size&&(g.size=d.size))):a=g.createElementNS(a,c);a[wf]=b;a[xf]=d;Bi(a,b,!1,!1);b.stateNode=a;g=wb(c,d);switch(c){case "dialog":G("cancel",a);G("close",a);
e=d;break;case "iframe":case "object":case "embed":G("load",a);e=d;break;case "video":case "audio":for(e=0;e<Xe.length;e++)G(Xe[e],a);e=d;break;case "source":G("error",a);e=d;break;case "img":case "image":case "link":G("error",a);G("load",a);e=d;break;case "details":G("toggle",a);e=d;break;case "input":Za(a,d);e=Ya(a,d);G("invalid",a);break;case "option":e=eb(a,d);break;case "select":a._wrapperState={wasMultiple:!!d.multiple};e=m({},d,{value:void 0});G("invalid",a);break;case "textarea":hb(a,d);e=
gb(a,d);G("invalid",a);break;default:e=d}vb(c,e);var h=e;for(f in h)if(h.hasOwnProperty(f)){var k=h[f];"style"===f?tb(a,k):"dangerouslySetInnerHTML"===f?(k=k?k.__html:void 0,null!=k&&ob(a,k)):"children"===f?"string"===typeof k?("textarea"!==c||""!==k)&&pb(a,k):"number"===typeof k&&pb(a,""+k):"suppressContentEditableWarning"!==f&&"suppressHydrationWarning"!==f&&"autoFocus"!==f&&(ca.hasOwnProperty(f)?null!=k&&"onScroll"===f&&G("scroll",a):null!=k&&qa(a,f,k,g))}switch(c){case "input":Va(a);cb(a,d,!1);
break;case "textarea":Va(a);jb(a);break;case "option":null!=d.value&&a.setAttribute("value",""+Sa(d.value));break;case "select":a.multiple=!!d.multiple;f=d.value;null!=f?fb(a,!!d.multiple,f,!1):null!=d.defaultValue&&fb(a,!!d.multiple,d.defaultValue,!0);break;default:"function"===typeof e.onClick&&(a.onclick=jf)}mf(c,d)&&(b.flags|=4)}null!==b.ref&&(b.flags|=128)}return null;case 6:if(a&&null!=b.stateNode)Ei(a,b,a.memoizedProps,d);else{if("string"!==typeof d&&null===b.stateNode)throw Error(y(166));
c=dh(ch.current);dh(ah.current);rh(b)?(d=b.stateNode,c=b.memoizedProps,d[wf]=b,d.nodeValue!==c&&(b.flags|=4)):(d=(9===c.nodeType?c:c.ownerDocument).createTextNode(d),d[wf]=b,b.stateNode=d)}return null;case 13:H(P);d=b.memoizedState;if(0!==(b.flags&64))return b.lanes=c,b;d=null!==d;c=!1;null===a?void 0!==b.memoizedProps.fallback&&rh(b):c=null!==a.memoizedState;if(d&&!c&&0!==(b.mode&2))if(null===a&&!0!==b.memoizedProps.unstable_avoidThisFallback||0!==(P.current&1))0===V&&(V=3);else{if(0===V||3===V)V=
4;null===U||0===(Dg&134217727)&&0===(Hi&134217727)||Ii(U,W)}if(d||c)b.flags|=4;return null;case 4:return fh(),Ci(b),null===a&&cf(b.stateNode.containerInfo),null;case 10:return rg(b),null;case 17:return Ff(b.type)&&Gf(),null;case 19:H(P);d=b.memoizedState;if(null===d)return null;f=0!==(b.flags&64);g=d.rendering;if(null===g)if(f)Fi(d,!1);else{if(0!==V||null!==a&&0!==(a.flags&64))for(a=b.child;null!==a;){g=ih(a);if(null!==g){b.flags|=64;Fi(d,!1);f=g.updateQueue;null!==f&&(b.updateQueue=f,b.flags|=4);
null===d.lastEffect&&(b.firstEffect=null);b.lastEffect=d.lastEffect;d=c;for(c=b.child;null!==c;)f=c,a=d,f.flags&=2,f.nextEffect=null,f.firstEffect=null,f.lastEffect=null,g=f.alternate,null===g?(f.childLanes=0,f.lanes=a,f.child=null,f.memoizedProps=null,f.memoizedState=null,f.updateQueue=null,f.dependencies=null,f.stateNode=null):(f.childLanes=g.childLanes,f.lanes=g.lanes,f.child=g.child,f.memoizedProps=g.memoizedProps,f.memoizedState=g.memoizedState,f.updateQueue=g.updateQueue,f.type=g.type,a=g.dependencies,
f.dependencies=null===a?null:{lanes:a.lanes,firstContext:a.firstContext}),c=c.sibling;I(P,P.current&1|2);return b.child}a=a.sibling}null!==d.tail&&O()>Ji&&(b.flags|=64,f=!0,Fi(d,!1),b.lanes=33554432)}else{if(!f)if(a=ih(g),null!==a){if(b.flags|=64,f=!0,c=a.updateQueue,null!==c&&(b.updateQueue=c,b.flags|=4),Fi(d,!0),null===d.tail&&"hidden"===d.tailMode&&!g.alternate&&!lh)return b=b.lastEffect=d.lastEffect,null!==b&&(b.nextEffect=null),null}else 2*O()-d.renderingStartTime>Ji&&1073741824!==c&&(b.flags|=
64,f=!0,Fi(d,!1),b.lanes=33554432);d.isBackwards?(g.sibling=b.child,b.child=g):(c=d.last,null!==c?c.sibling=g:b.child=g,d.last=g)}return null!==d.tail?(c=d.tail,d.rendering=c,d.tail=c.sibling,d.lastEffect=b.lastEffect,d.renderingStartTime=O(),c.sibling=null,b=P.current,I(P,f?b&1|2:b&1),c):null;case 23:case 24:return Ki(),null!==a&&null!==a.memoizedState!==(null!==b.memoizedState)&&"unstable-defer-without-hiding"!==d.mode&&(b.flags|=4),null}throw Error(y(156,b.tag));}
function Li(a){switch(a.tag){case 1:Ff(a.type)&&Gf();var b=a.flags;return b&4096?(a.flags=b&-4097|64,a):null;case 3:fh();H(N);H(M);uh();b=a.flags;if(0!==(b&64))throw Error(y(285));a.flags=b&-4097|64;return a;case 5:return hh(a),null;case 13:return H(P),b=a.flags,b&4096?(a.flags=b&-4097|64,a):null;case 19:return H(P),null;case 4:return fh(),null;case 10:return rg(a),null;case 23:case 24:return Ki(),null;default:return null}}
function Mi(a,b){try{var c="",d=b;do c+=Qa(d),d=d.return;while(d);var e=c}catch(f){e="\nError generating stack: "+f.message+"\n"+f.stack}return{value:a,source:b,stack:e}}function Ni(a,b){try{console.error(b.value)}catch(c){setTimeout(function(){throw c;})}}var Oi="function"===typeof WeakMap?WeakMap:Map;function Pi(a,b,c){c=zg(-1,c);c.tag=3;c.payload={element:null};var d=b.value;c.callback=function(){Qi||(Qi=!0,Ri=d);Ni(a,b)};return c}
function Si(a,b,c){c=zg(-1,c);c.tag=3;var d=a.type.getDerivedStateFromError;if("function"===typeof d){var e=b.value;c.payload=function(){Ni(a,b);return d(e)}}var f=a.stateNode;null!==f&&"function"===typeof f.componentDidCatch&&(c.callback=function(){"function"!==typeof d&&(null===Ti?Ti=new Set([this]):Ti.add(this),Ni(a,b));var c=b.stack;this.componentDidCatch(b.value,{componentStack:null!==c?c:""})});return c}var Ui="function"===typeof WeakSet?WeakSet:Set;
function Vi(a){var b=a.ref;if(null!==b)if("function"===typeof b)try{b(null)}catch(c){Wi(a,c)}else b.current=null}function Xi(a,b){switch(b.tag){case 0:case 11:case 15:case 22:return;case 1:if(b.flags&256&&null!==a){var c=a.memoizedProps,d=a.memoizedState;a=b.stateNode;b=a.getSnapshotBeforeUpdate(b.elementType===b.type?c:lg(b.type,c),d);a.__reactInternalSnapshotBeforeUpdate=b}return;case 3:b.flags&256&&qf(b.stateNode.containerInfo);return;case 5:case 6:case 4:case 17:return}throw Error(y(163));}
function Yi(a,b,c){switch(c.tag){case 0:case 11:case 15:case 22:b=c.updateQueue;b=null!==b?b.lastEffect:null;if(null!==b){a=b=b.next;do{if(3===(a.tag&3)){var d=a.create;a.destroy=d()}a=a.next}while(a!==b)}b=c.updateQueue;b=null!==b?b.lastEffect:null;if(null!==b){a=b=b.next;do{var e=a;d=e.next;e=e.tag;0!==(e&4)&&0!==(e&1)&&(Zi(c,a),$i(c,a));a=d}while(a!==b)}return;case 1:a=c.stateNode;c.flags&4&&(null===b?a.componentDidMount():(d=c.elementType===c.type?b.memoizedProps:lg(c.type,b.memoizedProps),a.componentDidUpdate(d,
b.memoizedState,a.__reactInternalSnapshotBeforeUpdate)));b=c.updateQueue;null!==b&&Eg(c,b,a);return;case 3:b=c.updateQueue;if(null!==b){a=null;if(null!==c.child)switch(c.child.tag){case 5:a=c.child.stateNode;break;case 1:a=c.child.stateNode}Eg(c,b,a)}return;case 5:a=c.stateNode;null===b&&c.flags&4&&mf(c.type,c.memoizedProps)&&a.focus();return;case 6:return;case 4:return;case 12:return;case 13:null===c.memoizedState&&(c=c.alternate,null!==c&&(c=c.memoizedState,null!==c&&(c=c.dehydrated,null!==c&&Cc(c))));
return;case 19:case 17:case 20:case 21:case 23:case 24:return}throw Error(y(163));}
function aj(a,b){for(var c=a;;){if(5===c.tag){var d=c.stateNode;if(b)d=d.style,"function"===typeof d.setProperty?d.setProperty("display","none","important"):d.display="none";else{d=c.stateNode;var e=c.memoizedProps.style;e=void 0!==e&&null!==e&&e.hasOwnProperty("display")?e.display:null;d.style.display=sb("display",e)}}else if(6===c.tag)c.stateNode.nodeValue=b?"":c.memoizedProps;else if((23!==c.tag&&24!==c.tag||null===c.memoizedState||c===a)&&null!==c.child){c.child.return=c;c=c.child;continue}if(c===
a)break;for(;null===c.sibling;){if(null===c.return||c.return===a)return;c=c.return}c.sibling.return=c.return;c=c.sibling}}
function bj(a,b){if(Mf&&"function"===typeof Mf.onCommitFiberUnmount)try{Mf.onCommitFiberUnmount(Lf,b)}catch(f){}switch(b.tag){case 0:case 11:case 14:case 15:case 22:a=b.updateQueue;if(null!==a&&(a=a.lastEffect,null!==a)){var c=a=a.next;do{var d=c,e=d.destroy;d=d.tag;if(void 0!==e)if(0!==(d&4))Zi(b,c);else{d=b;try{e()}catch(f){Wi(d,f)}}c=c.next}while(c!==a)}break;case 1:Vi(b);a=b.stateNode;if("function"===typeof a.componentWillUnmount)try{a.props=b.memoizedProps,a.state=b.memoizedState,a.componentWillUnmount()}catch(f){Wi(b,
f)}break;case 5:Vi(b);break;case 4:cj(a,b)}}function dj(a){a.alternate=null;a.child=null;a.dependencies=null;a.firstEffect=null;a.lastEffect=null;a.memoizedProps=null;a.memoizedState=null;a.pendingProps=null;a.return=null;a.updateQueue=null}function ej(a){return 5===a.tag||3===a.tag||4===a.tag}
function fj(a){a:{for(var b=a.return;null!==b;){if(ej(b))break a;b=b.return}throw Error(y(160));}var c=b;b=c.stateNode;switch(c.tag){case 5:var d=!1;break;case 3:b=b.containerInfo;d=!0;break;case 4:b=b.containerInfo;d=!0;break;default:throw Error(y(161));}c.flags&16&&(pb(b,""),c.flags&=-17);a:b:for(c=a;;){for(;null===c.sibling;){if(null===c.return||ej(c.return)){c=null;break a}c=c.return}c.sibling.return=c.return;for(c=c.sibling;5!==c.tag&&6!==c.tag&&18!==c.tag;){if(c.flags&2)continue b;if(null===
c.child||4===c.tag)continue b;else c.child.return=c,c=c.child}if(!(c.flags&2)){c=c.stateNode;break a}}d?gj(a,c,b):hj(a,c,b)}
function gj(a,b,c){var d=a.tag,e=5===d||6===d;if(e)a=e?a.stateNode:a.stateNode.instance,b?8===c.nodeType?c.parentNode.insertBefore(a,b):c.insertBefore(a,b):(8===c.nodeType?(b=c.parentNode,b.insertBefore(a,c)):(b=c,b.appendChild(a)),c=c._reactRootContainer,null!==c&&void 0!==c||null!==b.onclick||(b.onclick=jf));else if(4!==d&&(a=a.child,null!==a))for(gj(a,b,c),a=a.sibling;null!==a;)gj(a,b,c),a=a.sibling}
function hj(a,b,c){var d=a.tag,e=5===d||6===d;if(e)a=e?a.stateNode:a.stateNode.instance,b?c.insertBefore(a,b):c.appendChild(a);else if(4!==d&&(a=a.child,null!==a))for(hj(a,b,c),a=a.sibling;null!==a;)hj(a,b,c),a=a.sibling}
function cj(a,b){for(var c=b,d=!1,e,f;;){if(!d){d=c.return;a:for(;;){if(null===d)throw Error(y(160));e=d.stateNode;switch(d.tag){case 5:f=!1;break a;case 3:e=e.containerInfo;f=!0;break a;case 4:e=e.containerInfo;f=!0;break a}d=d.return}d=!0}if(5===c.tag||6===c.tag){a:for(var g=a,h=c,k=h;;)if(bj(g,k),null!==k.child&&4!==k.tag)k.child.return=k,k=k.child;else{if(k===h)break a;for(;null===k.sibling;){if(null===k.return||k.return===h)break a;k=k.return}k.sibling.return=k.return;k=k.sibling}f?(g=e,h=c.stateNode,
8===g.nodeType?g.parentNode.removeChild(h):g.removeChild(h)):e.removeChild(c.stateNode)}else if(4===c.tag){if(null!==c.child){e=c.stateNode.containerInfo;f=!0;c.child.return=c;c=c.child;continue}}else if(bj(a,c),null!==c.child){c.child.return=c;c=c.child;continue}if(c===b)break;for(;null===c.sibling;){if(null===c.return||c.return===b)return;c=c.return;4===c.tag&&(d=!1)}c.sibling.return=c.return;c=c.sibling}}
function ij(a,b){switch(b.tag){case 0:case 11:case 14:case 15:case 22:var c=b.updateQueue;c=null!==c?c.lastEffect:null;if(null!==c){var d=c=c.next;do 3===(d.tag&3)&&(a=d.destroy,d.destroy=void 0,void 0!==a&&a()),d=d.next;while(d!==c)}return;case 1:return;case 5:c=b.stateNode;if(null!=c){d=b.memoizedProps;var e=null!==a?a.memoizedProps:d;a=b.type;var f=b.updateQueue;b.updateQueue=null;if(null!==f){c[xf]=d;"input"===a&&"radio"===d.type&&null!=d.name&&$a(c,d);wb(a,e);b=wb(a,d);for(e=0;e<f.length;e+=
2){var g=f[e],h=f[e+1];"style"===g?tb(c,h):"dangerouslySetInnerHTML"===g?ob(c,h):"children"===g?pb(c,h):qa(c,g,h,b)}switch(a){case "input":ab(c,d);break;case "textarea":ib(c,d);break;case "select":a=c._wrapperState.wasMultiple,c._wrapperState.wasMultiple=!!d.multiple,f=d.value,null!=f?fb(c,!!d.multiple,f,!1):a!==!!d.multiple&&(null!=d.defaultValue?fb(c,!!d.multiple,d.defaultValue,!0):fb(c,!!d.multiple,d.multiple?[]:"",!1))}}}return;case 6:if(null===b.stateNode)throw Error(y(162));b.stateNode.nodeValue=
b.memoizedProps;return;case 3:c=b.stateNode;c.hydrate&&(c.hydrate=!1,Cc(c.containerInfo));return;case 12:return;case 13:null!==b.memoizedState&&(jj=O(),aj(b.child,!0));kj(b);return;case 19:kj(b);return;case 17:return;case 23:case 24:aj(b,null!==b.memoizedState);return}throw Error(y(163));}function kj(a){var b=a.updateQueue;if(null!==b){a.updateQueue=null;var c=a.stateNode;null===c&&(c=a.stateNode=new Ui);b.forEach(function(b){var d=lj.bind(null,a,b);c.has(b)||(c.add(b),b.then(d,d))})}}
function mj(a,b){return null!==a&&(a=a.memoizedState,null===a||null!==a.dehydrated)?(b=b.memoizedState,null!==b&&null===b.dehydrated):!1}var nj=Math.ceil,oj=ra.ReactCurrentDispatcher,pj=ra.ReactCurrentOwner,X=0,U=null,Y=null,W=0,qj=0,rj=Bf(0),V=0,sj=null,tj=0,Dg=0,Hi=0,uj=0,vj=null,jj=0,Ji=Infinity;function wj(){Ji=O()+500}var Z=null,Qi=!1,Ri=null,Ti=null,xj=!1,yj=null,zj=90,Aj=[],Bj=[],Cj=null,Dj=0,Ej=null,Fj=-1,Gj=0,Hj=0,Ij=null,Jj=!1;function Hg(){return 0!==(X&48)?O():-1!==Fj?Fj:Fj=O()}
function Ig(a){a=a.mode;if(0===(a&2))return 1;if(0===(a&4))return 99===eg()?1:2;0===Gj&&(Gj=tj);if(0!==kg.transition){0!==Hj&&(Hj=null!==vj?vj.pendingLanes:0);a=Gj;var b=4186112&~Hj;b&=-b;0===b&&(a=4186112&~a,b=a&-a,0===b&&(b=8192));return b}a=eg();0!==(X&4)&&98===a?a=Xc(12,Gj):(a=Sc(a),a=Xc(a,Gj));return a}
function Jg(a,b,c){if(50<Dj)throw Dj=0,Ej=null,Error(y(185));a=Kj(a,b);if(null===a)return null;$c(a,b,c);a===U&&(Hi|=b,4===V&&Ii(a,W));var d=eg();1===b?0!==(X&8)&&0===(X&48)?Lj(a):(Mj(a,c),0===X&&(wj(),ig())):(0===(X&4)||98!==d&&99!==d||(null===Cj?Cj=new Set([a]):Cj.add(a)),Mj(a,c));vj=a}function Kj(a,b){a.lanes|=b;var c=a.alternate;null!==c&&(c.lanes|=b);c=a;for(a=a.return;null!==a;)a.childLanes|=b,c=a.alternate,null!==c&&(c.childLanes|=b),c=a,a=a.return;return 3===c.tag?c.stateNode:null}
function Mj(a,b){for(var c=a.callbackNode,d=a.suspendedLanes,e=a.pingedLanes,f=a.expirationTimes,g=a.pendingLanes;0<g;){var h=31-Vc(g),k=1<<h,l=f[h];if(-1===l){if(0===(k&d)||0!==(k&e)){l=b;Rc(k);var n=F;f[h]=10<=n?l+250:6<=n?l+5E3:-1}}else l<=b&&(a.expiredLanes|=k);g&=~k}d=Uc(a,a===U?W:0);b=F;if(0===d)null!==c&&(c!==Zf&&Pf(c),a.callbackNode=null,a.callbackPriority=0);else{if(null!==c){if(a.callbackPriority===b)return;c!==Zf&&Pf(c)}15===b?(c=Lj.bind(null,a),null===ag?(ag=[c],bg=Of(Uf,jg)):ag.push(c),
c=Zf):14===b?c=hg(99,Lj.bind(null,a)):(c=Tc(b),c=hg(c,Nj.bind(null,a)));a.callbackPriority=b;a.callbackNode=c}}
function Nj(a){Fj=-1;Hj=Gj=0;if(0!==(X&48))throw Error(y(327));var b=a.callbackNode;if(Oj()&&a.callbackNode!==b)return null;var c=Uc(a,a===U?W:0);if(0===c)return null;var d=c;var e=X;X|=16;var f=Pj();if(U!==a||W!==d)wj(),Qj(a,d);do try{Rj();break}catch(h){Sj(a,h)}while(1);qg();oj.current=f;X=e;null!==Y?d=0:(U=null,W=0,d=V);if(0!==(tj&Hi))Qj(a,0);else if(0!==d){2===d&&(X|=64,a.hydrate&&(a.hydrate=!1,qf(a.containerInfo)),c=Wc(a),0!==c&&(d=Tj(a,c)));if(1===d)throw b=sj,Qj(a,0),Ii(a,c),Mj(a,O()),b;a.finishedWork=
a.current.alternate;a.finishedLanes=c;switch(d){case 0:case 1:throw Error(y(345));case 2:Uj(a);break;case 3:Ii(a,c);if((c&62914560)===c&&(d=jj+500-O(),10<d)){if(0!==Uc(a,0))break;e=a.suspendedLanes;if((e&c)!==c){Hg();a.pingedLanes|=a.suspendedLanes&e;break}a.timeoutHandle=of(Uj.bind(null,a),d);break}Uj(a);break;case 4:Ii(a,c);if((c&4186112)===c)break;d=a.eventTimes;for(e=-1;0<c;){var g=31-Vc(c);f=1<<g;g=d[g];g>e&&(e=g);c&=~f}c=e;c=O()-c;c=(120>c?120:480>c?480:1080>c?1080:1920>c?1920:3E3>c?3E3:4320>
c?4320:1960*nj(c/1960))-c;if(10<c){a.timeoutHandle=of(Uj.bind(null,a),c);break}Uj(a);break;case 5:Uj(a);break;default:throw Error(y(329));}}Mj(a,O());return a.callbackNode===b?Nj.bind(null,a):null}function Ii(a,b){b&=~uj;b&=~Hi;a.suspendedLanes|=b;a.pingedLanes&=~b;for(a=a.expirationTimes;0<b;){var c=31-Vc(b),d=1<<c;a[c]=-1;b&=~d}}
function Lj(a){if(0!==(X&48))throw Error(y(327));Oj();if(a===U&&0!==(a.expiredLanes&W)){var b=W;var c=Tj(a,b);0!==(tj&Hi)&&(b=Uc(a,b),c=Tj(a,b))}else b=Uc(a,0),c=Tj(a,b);0!==a.tag&&2===c&&(X|=64,a.hydrate&&(a.hydrate=!1,qf(a.containerInfo)),b=Wc(a),0!==b&&(c=Tj(a,b)));if(1===c)throw c=sj,Qj(a,0),Ii(a,b),Mj(a,O()),c;a.finishedWork=a.current.alternate;a.finishedLanes=b;Uj(a);Mj(a,O());return null}
function Vj(){if(null!==Cj){var a=Cj;Cj=null;a.forEach(function(a){a.expiredLanes|=24&a.pendingLanes;Mj(a,O())})}ig()}function Wj(a,b){var c=X;X|=1;try{return a(b)}finally{X=c,0===X&&(wj(),ig())}}function Xj(a,b){var c=X;X&=-2;X|=8;try{return a(b)}finally{X=c,0===X&&(wj(),ig())}}function ni(a,b){I(rj,qj);qj|=b;tj|=b}function Ki(){qj=rj.current;H(rj)}
function Qj(a,b){a.finishedWork=null;a.finishedLanes=0;var c=a.timeoutHandle;-1!==c&&(a.timeoutHandle=-1,pf(c));if(null!==Y)for(c=Y.return;null!==c;){var d=c;switch(d.tag){case 1:d=d.type.childContextTypes;null!==d&&void 0!==d&&Gf();break;case 3:fh();H(N);H(M);uh();break;case 5:hh(d);break;case 4:fh();break;case 13:H(P);break;case 19:H(P);break;case 10:rg(d);break;case 23:case 24:Ki()}c=c.return}U=a;Y=Tg(a.current,null);W=qj=tj=b;V=0;sj=null;uj=Hi=Dg=0}
function Sj(a,b){do{var c=Y;try{qg();vh.current=Gh;if(yh){for(var d=R.memoizedState;null!==d;){var e=d.queue;null!==e&&(e.pending=null);d=d.next}yh=!1}xh=0;T=S=R=null;zh=!1;pj.current=null;if(null===c||null===c.return){V=1;sj=b;Y=null;break}a:{var f=a,g=c.return,h=c,k=b;b=W;h.flags|=2048;h.firstEffect=h.lastEffect=null;if(null!==k&&"object"===typeof k&&"function"===typeof k.then){var l=k;if(0===(h.mode&2)){var n=h.alternate;n?(h.updateQueue=n.updateQueue,h.memoizedState=n.memoizedState,h.lanes=n.lanes):
(h.updateQueue=null,h.memoizedState=null)}var A=0!==(P.current&1),p=g;do{var C;if(C=13===p.tag){var x=p.memoizedState;if(null!==x)C=null!==x.dehydrated?!0:!1;else{var w=p.memoizedProps;C=void 0===w.fallback?!1:!0!==w.unstable_avoidThisFallback?!0:A?!1:!0}}if(C){var z=p.updateQueue;if(null===z){var u=new Set;u.add(l);p.updateQueue=u}else z.add(l);if(0===(p.mode&2)){p.flags|=64;h.flags|=16384;h.flags&=-2981;if(1===h.tag)if(null===h.alternate)h.tag=17;else{var t=zg(-1,1);t.tag=2;Ag(h,t)}h.lanes|=1;break a}k=
void 0;h=b;var q=f.pingCache;null===q?(q=f.pingCache=new Oi,k=new Set,q.set(l,k)):(k=q.get(l),void 0===k&&(k=new Set,q.set(l,k)));if(!k.has(h)){k.add(h);var v=Yj.bind(null,f,l,h);l.then(v,v)}p.flags|=4096;p.lanes=b;break a}p=p.return}while(null!==p);k=Error((Ra(h.type)||"A React component")+" suspended while rendering, but no fallback UI was specified.\n\nAdd a <Suspense fallback=...> component higher in the tree to provide a loading indicator or placeholder to display.")}5!==V&&(V=2);k=Mi(k,h);p=
g;do{switch(p.tag){case 3:f=k;p.flags|=4096;b&=-b;p.lanes|=b;var J=Pi(p,f,b);Bg(p,J);break a;case 1:f=k;var K=p.type,Q=p.stateNode;if(0===(p.flags&64)&&("function"===typeof K.getDerivedStateFromError||null!==Q&&"function"===typeof Q.componentDidCatch&&(null===Ti||!Ti.has(Q)))){p.flags|=4096;b&=-b;p.lanes|=b;var L=Si(p,f,b);Bg(p,L);break a}}p=p.return}while(null!==p)}Zj(c)}catch(va){b=va;Y===c&&null!==c&&(Y=c=c.return);continue}break}while(1)}
function Pj(){var a=oj.current;oj.current=Gh;return null===a?Gh:a}function Tj(a,b){var c=X;X|=16;var d=Pj();U===a&&W===b||Qj(a,b);do try{ak();break}catch(e){Sj(a,e)}while(1);qg();X=c;oj.current=d;if(null!==Y)throw Error(y(261));U=null;W=0;return V}function ak(){for(;null!==Y;)bk(Y)}function Rj(){for(;null!==Y&&!Qf();)bk(Y)}function bk(a){var b=ck(a.alternate,a,qj);a.memoizedProps=a.pendingProps;null===b?Zj(a):Y=b;pj.current=null}
function Zj(a){var b=a;do{var c=b.alternate;a=b.return;if(0===(b.flags&2048)){c=Gi(c,b,qj);if(null!==c){Y=c;return}c=b;if(24!==c.tag&&23!==c.tag||null===c.memoizedState||0!==(qj&1073741824)||0===(c.mode&4)){for(var d=0,e=c.child;null!==e;)d|=e.lanes|e.childLanes,e=e.sibling;c.childLanes=d}null!==a&&0===(a.flags&2048)&&(null===a.firstEffect&&(a.firstEffect=b.firstEffect),null!==b.lastEffect&&(null!==a.lastEffect&&(a.lastEffect.nextEffect=b.firstEffect),a.lastEffect=b.lastEffect),1<b.flags&&(null!==
a.lastEffect?a.lastEffect.nextEffect=b:a.firstEffect=b,a.lastEffect=b))}else{c=Li(b);if(null!==c){c.flags&=2047;Y=c;return}null!==a&&(a.firstEffect=a.lastEffect=null,a.flags|=2048)}b=b.sibling;if(null!==b){Y=b;return}Y=b=a}while(null!==b);0===V&&(V=5)}function Uj(a){var b=eg();gg(99,dk.bind(null,a,b));return null}
function dk(a,b){do Oj();while(null!==yj);if(0!==(X&48))throw Error(y(327));var c=a.finishedWork;if(null===c)return null;a.finishedWork=null;a.finishedLanes=0;if(c===a.current)throw Error(y(177));a.callbackNode=null;var d=c.lanes|c.childLanes,e=d,f=a.pendingLanes&~e;a.pendingLanes=e;a.suspendedLanes=0;a.pingedLanes=0;a.expiredLanes&=e;a.mutableReadLanes&=e;a.entangledLanes&=e;e=a.entanglements;for(var g=a.eventTimes,h=a.expirationTimes;0<f;){var k=31-Vc(f),l=1<<k;e[k]=0;g[k]=-1;h[k]=-1;f&=~l}null!==
Cj&&0===(d&24)&&Cj.has(a)&&Cj.delete(a);a===U&&(Y=U=null,W=0);1<c.flags?null!==c.lastEffect?(c.lastEffect.nextEffect=c,d=c.firstEffect):d=c:d=c.firstEffect;if(null!==d){e=X;X|=32;pj.current=null;kf=fd;g=Ne();if(Oe(g)){if("selectionStart"in g)h={start:g.selectionStart,end:g.selectionEnd};else a:if(h=(h=g.ownerDocument)&&h.defaultView||window,(l=h.getSelection&&h.getSelection())&&0!==l.rangeCount){h=l.anchorNode;f=l.anchorOffset;k=l.focusNode;l=l.focusOffset;try{h.nodeType,k.nodeType}catch(va){h=null;
break a}var n=0,A=-1,p=-1,C=0,x=0,w=g,z=null;b:for(;;){for(var u;;){w!==h||0!==f&&3!==w.nodeType||(A=n+f);w!==k||0!==l&&3!==w.nodeType||(p=n+l);3===w.nodeType&&(n+=w.nodeValue.length);if(null===(u=w.firstChild))break;z=w;w=u}for(;;){if(w===g)break b;z===h&&++C===f&&(A=n);z===k&&++x===l&&(p=n);if(null!==(u=w.nextSibling))break;w=z;z=w.parentNode}w=u}h=-1===A||-1===p?null:{start:A,end:p}}else h=null;h=h||{start:0,end:0}}else h=null;lf={focusedElem:g,selectionRange:h};fd=!1;Ij=null;Jj=!1;Z=d;do try{ek()}catch(va){if(null===
Z)throw Error(y(330));Wi(Z,va);Z=Z.nextEffect}while(null!==Z);Ij=null;Z=d;do try{for(g=a;null!==Z;){var t=Z.flags;t&16&&pb(Z.stateNode,"");if(t&128){var q=Z.alternate;if(null!==q){var v=q.ref;null!==v&&("function"===typeof v?v(null):v.current=null)}}switch(t&1038){case 2:fj(Z);Z.flags&=-3;break;case 6:fj(Z);Z.flags&=-3;ij(Z.alternate,Z);break;case 1024:Z.flags&=-1025;break;case 1028:Z.flags&=-1025;ij(Z.alternate,Z);break;case 4:ij(Z.alternate,Z);break;case 8:h=Z;cj(g,h);var J=h.alternate;dj(h);null!==
J&&dj(J)}Z=Z.nextEffect}}catch(va){if(null===Z)throw Error(y(330));Wi(Z,va);Z=Z.nextEffect}while(null!==Z);v=lf;q=Ne();t=v.focusedElem;g=v.selectionRange;if(q!==t&&t&&t.ownerDocument&&Me(t.ownerDocument.documentElement,t)){null!==g&&Oe(t)&&(q=g.start,v=g.end,void 0===v&&(v=q),"selectionStart"in t?(t.selectionStart=q,t.selectionEnd=Math.min(v,t.value.length)):(v=(q=t.ownerDocument||document)&&q.defaultView||window,v.getSelection&&(v=v.getSelection(),h=t.textContent.length,J=Math.min(g.start,h),g=void 0===
g.end?J:Math.min(g.end,h),!v.extend&&J>g&&(h=g,g=J,J=h),h=Le(t,J),f=Le(t,g),h&&f&&(1!==v.rangeCount||v.anchorNode!==h.node||v.anchorOffset!==h.offset||v.focusNode!==f.node||v.focusOffset!==f.offset)&&(q=q.createRange(),q.setStart(h.node,h.offset),v.removeAllRanges(),J>g?(v.addRange(q),v.extend(f.node,f.offset)):(q.setEnd(f.node,f.offset),v.addRange(q))))));q=[];for(v=t;v=v.parentNode;)1===v.nodeType&&q.push({element:v,left:v.scrollLeft,top:v.scrollTop});"function"===typeof t.focus&&t.focus();for(t=
0;t<q.length;t++)v=q[t],v.element.scrollLeft=v.left,v.element.scrollTop=v.top}fd=!!kf;lf=kf=null;a.current=c;Z=d;do try{for(t=a;null!==Z;){var K=Z.flags;K&36&&Yi(t,Z.alternate,Z);if(K&128){q=void 0;var Q=Z.ref;if(null!==Q){var L=Z.stateNode;switch(Z.tag){case 5:q=L;break;default:q=L}"function"===typeof Q?Q(q):Q.current=q}}Z=Z.nextEffect}}catch(va){if(null===Z)throw Error(y(330));Wi(Z,va);Z=Z.nextEffect}while(null!==Z);Z=null;$f();X=e}else a.current=c;if(xj)xj=!1,yj=a,zj=b;else for(Z=d;null!==Z;)b=
Z.nextEffect,Z.nextEffect=null,Z.flags&8&&(K=Z,K.sibling=null,K.stateNode=null),Z=b;d=a.pendingLanes;0===d&&(Ti=null);1===d?a===Ej?Dj++:(Dj=0,Ej=a):Dj=0;c=c.stateNode;if(Mf&&"function"===typeof Mf.onCommitFiberRoot)try{Mf.onCommitFiberRoot(Lf,c,void 0,64===(c.current.flags&64))}catch(va){}Mj(a,O());if(Qi)throw Qi=!1,a=Ri,Ri=null,a;if(0!==(X&8))return null;ig();return null}
function ek(){for(;null!==Z;){var a=Z.alternate;Jj||null===Ij||(0!==(Z.flags&8)?dc(Z,Ij)&&(Jj=!0):13===Z.tag&&mj(a,Z)&&dc(Z,Ij)&&(Jj=!0));var b=Z.flags;0!==(b&256)&&Xi(a,Z);0===(b&512)||xj||(xj=!0,hg(97,function(){Oj();return null}));Z=Z.nextEffect}}function Oj(){if(90!==zj){var a=97<zj?97:zj;zj=90;return gg(a,fk)}return!1}function $i(a,b){Aj.push(b,a);xj||(xj=!0,hg(97,function(){Oj();return null}))}function Zi(a,b){Bj.push(b,a);xj||(xj=!0,hg(97,function(){Oj();return null}))}
function fk(){if(null===yj)return!1;var a=yj;yj=null;if(0!==(X&48))throw Error(y(331));var b=X;X|=32;var c=Bj;Bj=[];for(var d=0;d<c.length;d+=2){var e=c[d],f=c[d+1],g=e.destroy;e.destroy=void 0;if("function"===typeof g)try{g()}catch(k){if(null===f)throw Error(y(330));Wi(f,k)}}c=Aj;Aj=[];for(d=0;d<c.length;d+=2){e=c[d];f=c[d+1];try{var h=e.create;e.destroy=h()}catch(k){if(null===f)throw Error(y(330));Wi(f,k)}}for(h=a.current.firstEffect;null!==h;)a=h.nextEffect,h.nextEffect=null,h.flags&8&&(h.sibling=
null,h.stateNode=null),h=a;X=b;ig();return!0}function gk(a,b,c){b=Mi(c,b);b=Pi(a,b,1);Ag(a,b);b=Hg();a=Kj(a,1);null!==a&&($c(a,1,b),Mj(a,b))}
function Wi(a,b){if(3===a.tag)gk(a,a,b);else for(var c=a.return;null!==c;){if(3===c.tag){gk(c,a,b);break}else if(1===c.tag){var d=c.stateNode;if("function"===typeof c.type.getDerivedStateFromError||"function"===typeof d.componentDidCatch&&(null===Ti||!Ti.has(d))){a=Mi(b,a);var e=Si(c,a,1);Ag(c,e);e=Hg();c=Kj(c,1);if(null!==c)$c(c,1,e),Mj(c,e);else if("function"===typeof d.componentDidCatch&&(null===Ti||!Ti.has(d)))try{d.componentDidCatch(b,a)}catch(f){}break}}c=c.return}}
function Yj(a,b,c){var d=a.pingCache;null!==d&&d.delete(b);b=Hg();a.pingedLanes|=a.suspendedLanes&c;U===a&&(W&c)===c&&(4===V||3===V&&(W&62914560)===W&&500>O()-jj?Qj(a,0):uj|=c);Mj(a,b)}function lj(a,b){var c=a.stateNode;null!==c&&c.delete(b);b=0;0===b&&(b=a.mode,0===(b&2)?b=1:0===(b&4)?b=99===eg()?1:2:(0===Gj&&(Gj=tj),b=Yc(62914560&~Gj),0===b&&(b=4194304)));c=Hg();a=Kj(a,b);null!==a&&($c(a,b,c),Mj(a,c))}var ck;
ck=function(a,b,c){var d=b.lanes;if(null!==a)if(a.memoizedProps!==b.pendingProps||N.current)ug=!0;else if(0!==(c&d))ug=0!==(a.flags&16384)?!0:!1;else{ug=!1;switch(b.tag){case 3:ri(b);sh();break;case 5:gh(b);break;case 1:Ff(b.type)&&Jf(b);break;case 4:eh(b,b.stateNode.containerInfo);break;case 10:d=b.memoizedProps.value;var e=b.type._context;I(mg,e._currentValue);e._currentValue=d;break;case 13:if(null!==b.memoizedState){if(0!==(c&b.child.childLanes))return ti(a,b,c);I(P,P.current&1);b=hi(a,b,c);return null!==
b?b.sibling:null}I(P,P.current&1);break;case 19:d=0!==(c&b.childLanes);if(0!==(a.flags&64)){if(d)return Ai(a,b,c);b.flags|=64}e=b.memoizedState;null!==e&&(e.rendering=null,e.tail=null,e.lastEffect=null);I(P,P.current);if(d)break;else return null;case 23:case 24:return b.lanes=0,mi(a,b,c)}return hi(a,b,c)}else ug=!1;b.lanes=0;switch(b.tag){case 2:d=b.type;null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2);a=b.pendingProps;e=Ef(b,M.current);tg(b,c);e=Ch(null,b,d,a,e,c);b.flags|=1;if("object"===
typeof e&&null!==e&&"function"===typeof e.render&&void 0===e.$$typeof){b.tag=1;b.memoizedState=null;b.updateQueue=null;if(Ff(d)){var f=!0;Jf(b)}else f=!1;b.memoizedState=null!==e.state&&void 0!==e.state?e.state:null;xg(b);var g=d.getDerivedStateFromProps;"function"===typeof g&&Gg(b,d,g,a);e.updater=Kg;b.stateNode=e;e._reactInternals=b;Og(b,d,a,c);b=qi(null,b,d,!0,f,c)}else b.tag=0,fi(null,b,e,c),b=b.child;return b;case 16:e=b.elementType;a:{null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2);
a=b.pendingProps;f=e._init;e=f(e._payload);b.type=e;f=b.tag=hk(e);a=lg(e,a);switch(f){case 0:b=li(null,b,e,a,c);break a;case 1:b=pi(null,b,e,a,c);break a;case 11:b=gi(null,b,e,a,c);break a;case 14:b=ii(null,b,e,lg(e.type,a),d,c);break a}throw Error(y(306,e,""));}return b;case 0:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),li(a,b,d,e,c);case 1:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),pi(a,b,d,e,c);case 3:ri(b);d=b.updateQueue;if(null===a||null===d)throw Error(y(282));
d=b.pendingProps;e=b.memoizedState;e=null!==e?e.element:null;yg(a,b);Cg(b,d,null,c);d=b.memoizedState.element;if(d===e)sh(),b=hi(a,b,c);else{e=b.stateNode;if(f=e.hydrate)kh=rf(b.stateNode.containerInfo.firstChild),jh=b,f=lh=!0;if(f){a=e.mutableSourceEagerHydrationData;if(null!=a)for(e=0;e<a.length;e+=2)f=a[e],f._workInProgressVersionPrimary=a[e+1],th.push(f);c=Zg(b,null,d,c);for(b.child=c;c;)c.flags=c.flags&-3|1024,c=c.sibling}else fi(a,b,d,c),sh();b=b.child}return b;case 5:return gh(b),null===a&&
ph(b),d=b.type,e=b.pendingProps,f=null!==a?a.memoizedProps:null,g=e.children,nf(d,e)?g=null:null!==f&&nf(d,f)&&(b.flags|=16),oi(a,b),fi(a,b,g,c),b.child;case 6:return null===a&&ph(b),null;case 13:return ti(a,b,c);case 4:return eh(b,b.stateNode.containerInfo),d=b.pendingProps,null===a?b.child=Yg(b,null,d,c):fi(a,b,d,c),b.child;case 11:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),gi(a,b,d,e,c);case 7:return fi(a,b,b.pendingProps,c),b.child;case 8:return fi(a,b,b.pendingProps.children,
c),b.child;case 12:return fi(a,b,b.pendingProps.children,c),b.child;case 10:a:{d=b.type._context;e=b.pendingProps;g=b.memoizedProps;f=e.value;var h=b.type._context;I(mg,h._currentValue);h._currentValue=f;if(null!==g)if(h=g.value,f=He(h,f)?0:("function"===typeof d._calculateChangedBits?d._calculateChangedBits(h,f):1073741823)|0,0===f){if(g.children===e.children&&!N.current){b=hi(a,b,c);break a}}else for(h=b.child,null!==h&&(h.return=b);null!==h;){var k=h.dependencies;if(null!==k){g=h.child;for(var l=
k.firstContext;null!==l;){if(l.context===d&&0!==(l.observedBits&f)){1===h.tag&&(l=zg(-1,c&-c),l.tag=2,Ag(h,l));h.lanes|=c;l=h.alternate;null!==l&&(l.lanes|=c);sg(h.return,c);k.lanes|=c;break}l=l.next}}else g=10===h.tag?h.type===b.type?null:h.child:h.child;if(null!==g)g.return=h;else for(g=h;null!==g;){if(g===b){g=null;break}h=g.sibling;if(null!==h){h.return=g.return;g=h;break}g=g.return}h=g}fi(a,b,e.children,c);b=b.child}return b;case 9:return e=b.type,f=b.pendingProps,d=f.children,tg(b,c),e=vg(e,
f.unstable_observedBits),d=d(e),b.flags|=1,fi(a,b,d,c),b.child;case 14:return e=b.type,f=lg(e,b.pendingProps),f=lg(e.type,f),ii(a,b,e,f,d,c);case 15:return ki(a,b,b.type,b.pendingProps,d,c);case 17:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2),b.tag=1,Ff(d)?(a=!0,Jf(b)):a=!1,tg(b,c),Mg(b,d,e),Og(b,d,e,c),qi(null,b,d,!0,a,c);case 19:return Ai(a,b,c);case 23:return mi(a,b,c);case 24:return mi(a,b,c)}throw Error(y(156,b.tag));
};function ik(a,b,c,d){this.tag=a;this.key=c;this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null;this.index=0;this.ref=null;this.pendingProps=b;this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null;this.mode=d;this.flags=0;this.lastEffect=this.firstEffect=this.nextEffect=null;this.childLanes=this.lanes=0;this.alternate=null}function nh(a,b,c,d){return new ik(a,b,c,d)}function ji(a){a=a.prototype;return!(!a||!a.isReactComponent)}
function hk(a){if("function"===typeof a)return ji(a)?1:0;if(void 0!==a&&null!==a){a=a.$$typeof;if(a===Aa)return 11;if(a===Da)return 14}return 2}
function Tg(a,b){var c=a.alternate;null===c?(c=nh(a.tag,b,a.key,a.mode),c.elementType=a.elementType,c.type=a.type,c.stateNode=a.stateNode,c.alternate=a,a.alternate=c):(c.pendingProps=b,c.type=a.type,c.flags=0,c.nextEffect=null,c.firstEffect=null,c.lastEffect=null);c.childLanes=a.childLanes;c.lanes=a.lanes;c.child=a.child;c.memoizedProps=a.memoizedProps;c.memoizedState=a.memoizedState;c.updateQueue=a.updateQueue;b=a.dependencies;c.dependencies=null===b?null:{lanes:b.lanes,firstContext:b.firstContext};
c.sibling=a.sibling;c.index=a.index;c.ref=a.ref;return c}
function Vg(a,b,c,d,e,f){var g=2;d=a;if("function"===typeof a)ji(a)&&(g=1);else if("string"===typeof a)g=5;else a:switch(a){case ua:return Xg(c.children,e,f,b);case Ha:g=8;e|=16;break;case wa:g=8;e|=1;break;case xa:return a=nh(12,c,b,e|8),a.elementType=xa,a.type=xa,a.lanes=f,a;case Ba:return a=nh(13,c,b,e),a.type=Ba,a.elementType=Ba,a.lanes=f,a;case Ca:return a=nh(19,c,b,e),a.elementType=Ca,a.lanes=f,a;case Ia:return vi(c,e,f,b);case Ja:return a=nh(24,c,b,e),a.elementType=Ja,a.lanes=f,a;default:if("object"===
typeof a&&null!==a)switch(a.$$typeof){case ya:g=10;break a;case za:g=9;break a;case Aa:g=11;break a;case Da:g=14;break a;case Ea:g=16;d=null;break a;case Fa:g=22;break a}throw Error(y(130,null==a?a:typeof a,""));}b=nh(g,c,b,e);b.elementType=a;b.type=d;b.lanes=f;return b}function Xg(a,b,c,d){a=nh(7,a,d,b);a.lanes=c;return a}function vi(a,b,c,d){a=nh(23,a,d,b);a.elementType=Ia;a.lanes=c;return a}function Ug(a,b,c){a=nh(6,a,null,b);a.lanes=c;return a}
function Wg(a,b,c){b=nh(4,null!==a.children?a.children:[],a.key,b);b.lanes=c;b.stateNode={containerInfo:a.containerInfo,pendingChildren:null,implementation:a.implementation};return b}
function jk(a,b,c){this.tag=b;this.containerInfo=a;this.finishedWork=this.pingCache=this.current=this.pendingChildren=null;this.timeoutHandle=-1;this.pendingContext=this.context=null;this.hydrate=c;this.callbackNode=null;this.callbackPriority=0;this.eventTimes=Zc(0);this.expirationTimes=Zc(-1);this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0;this.entanglements=Zc(0);this.mutableSourceEagerHydrationData=null}
function kk(a,b,c){var d=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;return{$$typeof:ta,key:null==d?null:""+d,children:a,containerInfo:b,implementation:c}}
function lk(a,b,c,d){var e=b.current,f=Hg(),g=Ig(e);a:if(c){c=c._reactInternals;b:{if(Zb(c)!==c||1!==c.tag)throw Error(y(170));var h=c;do{switch(h.tag){case 3:h=h.stateNode.context;break b;case 1:if(Ff(h.type)){h=h.stateNode.__reactInternalMemoizedMergedChildContext;break b}}h=h.return}while(null!==h);throw Error(y(171));}if(1===c.tag){var k=c.type;if(Ff(k)){c=If(c,k,h);break a}}c=h}else c=Cf;null===b.context?b.context=c:b.pendingContext=c;b=zg(f,g);b.payload={element:a};d=void 0===d?null:d;null!==
d&&(b.callback=d);Ag(e,b);Jg(e,g,f);return g}function mk(a){a=a.current;if(!a.child)return null;switch(a.child.tag){case 5:return a.child.stateNode;default:return a.child.stateNode}}function nk(a,b){a=a.memoizedState;if(null!==a&&null!==a.dehydrated){var c=a.retryLane;a.retryLane=0!==c&&c<b?c:b}}function ok(a,b){nk(a,b);(a=a.alternate)&&nk(a,b)}function pk(){return null}
function qk(a,b,c){var d=null!=c&&null!=c.hydrationOptions&&c.hydrationOptions.mutableSources||null;c=new jk(a,b,null!=c&&!0===c.hydrate);b=nh(3,null,null,2===b?7:1===b?3:0);c.current=b;b.stateNode=c;xg(b);a[ff]=c.current;cf(8===a.nodeType?a.parentNode:a);if(d)for(a=0;a<d.length;a++){b=d[a];var e=b._getVersion;e=e(b._source);null==c.mutableSourceEagerHydrationData?c.mutableSourceEagerHydrationData=[b,e]:c.mutableSourceEagerHydrationData.push(b,e)}this._internalRoot=c}
qk.prototype.render=function(a){lk(a,this._internalRoot,null,null)};qk.prototype.unmount=function(){var a=this._internalRoot,b=a.containerInfo;lk(null,a,null,function(){b[ff]=null})};function rk(a){return!(!a||1!==a.nodeType&&9!==a.nodeType&&11!==a.nodeType&&(8!==a.nodeType||" react-mount-point-unstable "!==a.nodeValue))}
function sk(a,b){b||(b=a?9===a.nodeType?a.documentElement:a.firstChild:null,b=!(!b||1!==b.nodeType||!b.hasAttribute("data-reactroot")));if(!b)for(var c;c=a.lastChild;)a.removeChild(c);return new qk(a,0,b?{hydrate:!0}:void 0)}
function tk(a,b,c,d,e){var f=c._reactRootContainer;if(f){var g=f._internalRoot;if("function"===typeof e){var h=e;e=function(){var a=mk(g);h.call(a)}}lk(b,g,a,e)}else{f=c._reactRootContainer=sk(c,d);g=f._internalRoot;if("function"===typeof e){var k=e;e=function(){var a=mk(g);k.call(a)}}Xj(function(){lk(b,g,a,e)})}return mk(g)}ec=function(a){if(13===a.tag){var b=Hg();Jg(a,4,b);ok(a,4)}};fc=function(a){if(13===a.tag){var b=Hg();Jg(a,67108864,b);ok(a,67108864)}};
gc=function(a){if(13===a.tag){var b=Hg(),c=Ig(a);Jg(a,c,b);ok(a,c)}};hc=function(a,b){return b()};
yb=function(a,b,c){switch(b){case "input":ab(a,c);b=c.name;if("radio"===c.type&&null!=b){for(c=a;c.parentNode;)c=c.parentNode;c=c.querySelectorAll("input[name="+JSON.stringify(""+b)+'][type="radio"]');for(b=0;b<c.length;b++){var d=c[b];if(d!==a&&d.form===a.form){var e=Db(d);if(!e)throw Error(y(90));Wa(d);ab(d,e)}}}break;case "textarea":ib(a,c);break;case "select":b=c.value,null!=b&&fb(a,!!c.multiple,b,!1)}};Gb=Wj;
Hb=function(a,b,c,d,e){var f=X;X|=4;try{return gg(98,a.bind(null,b,c,d,e))}finally{X=f,0===X&&(wj(),ig())}};Ib=function(){0===(X&49)&&(Vj(),Oj())};Jb=function(a,b){var c=X;X|=2;try{return a(b)}finally{X=c,0===X&&(wj(),ig())}};function uk(a,b){var c=2<arguments.length&&void 0!==arguments[2]?arguments[2]:null;if(!rk(b))throw Error(y(200));return kk(a,b,null,c)}var vk={Events:[Cb,ue,Db,Eb,Fb,Oj,{current:!1}]},wk={findFiberByHostInstance:wc,bundleType:0,version:"17.0.2",rendererPackageName:"react-dom"};
var xk={bundleType:wk.bundleType,version:wk.version,rendererPackageName:wk.rendererPackageName,rendererConfig:wk.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:ra.ReactCurrentDispatcher,findHostInstanceByFiber:function(a){a=cc(a);return null===a?null:a.stateNode},findFiberByHostInstance:wk.findFiberByHostInstance||
pk,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null};if("undefined"!==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__){var yk=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!yk.isDisabled&&yk.supportsFiber)try{Lf=yk.inject(xk),Mf=yk}catch(a){}}__webpack_unused_export__=vk;__webpack_unused_export__=uk;
__webpack_unused_export__=function(a){if(null==a)return null;if(1===a.nodeType)return a;var b=a._reactInternals;if(void 0===b){if("function"===typeof a.render)throw Error(y(188));throw Error(y(268,Object.keys(a)));}a=cc(b);a=null===a?null:a.stateNode;return a};__webpack_unused_export__=function(a,b){var c=X;if(0!==(c&48))return a(b);X|=1;try{if(a)return gg(99,a.bind(null,b))}finally{X=c,ig()}};__webpack_unused_export__=function(a,b,c){if(!rk(b))throw Error(y(200));return tk(null,a,b,!0,c)};
exports.render=function(a,b,c){if(!rk(b))throw Error(y(200));return tk(null,a,b,!1,c)};__webpack_unused_export__=function(a){if(!rk(a))throw Error(y(40));return a._reactRootContainer?(Xj(function(){tk(null,null,a,!1,function(){a._reactRootContainer=null;a[ff]=null})}),!0):!1};__webpack_unused_export__=Wj;__webpack_unused_export__=function(a,b){return uk(a,b,2<arguments.length&&void 0!==arguments[2]?arguments[2]:null)};
__webpack_unused_export__=function(a,b,c,d){if(!rk(c))throw Error(y(200));if(null==a||void 0===a._reactInternals)throw Error(y(38));return tk(a,b,c,!1,d)};__webpack_unused_export__="17.0.2";


/***/ }),

/***/ 961:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



function checkDCE() {
  /* global __REACT_DEVTOOLS_GLOBAL_HOOK__ */
  if (
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === 'undefined' ||
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== 'function'
  ) {
    return;
  }
  if (false) {}
  try {
    // Verify that the code above has been dead code eliminated (DCE'd).
    __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
  } catch (err) {
    // DevTools shouldn't crash React, no matter what.
    // We should still report in case we break this code.
    console.error(err);
  }
}

if (true) {
  // DCE check should happen before ReactDOM bundle executes so that
  // DevTools can report bad minification during injection.
  checkDCE();
  module.exports = __webpack_require__(2551);
} else {}


/***/ }),

/***/ 5287:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

/** @license React v17.0.2
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var l=__webpack_require__(5228),n=60103,p=60106;exports.Fragment=60107;exports.StrictMode=60108;exports.Profiler=60114;var q=60109,r=60110,t=60112;exports.Suspense=60113;var u=60115,v=60116;
if("function"===typeof Symbol&&Symbol.for){var w=Symbol.for;n=w("react.element");p=w("react.portal");exports.Fragment=w("react.fragment");exports.StrictMode=w("react.strict_mode");exports.Profiler=w("react.profiler");q=w("react.provider");r=w("react.context");t=w("react.forward_ref");exports.Suspense=w("react.suspense");u=w("react.memo");v=w("react.lazy")}var x="function"===typeof Symbol&&Symbol.iterator;
function y(a){if(null===a||"object"!==typeof a)return null;a=x&&a[x]||a["@@iterator"];return"function"===typeof a?a:null}function z(a){for(var b="https://reactjs.org/docs/error-decoder.html?invariant="+a,c=1;c<arguments.length;c++)b+="&args[]="+encodeURIComponent(arguments[c]);return"Minified React error #"+a+"; visit "+b+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}
var A={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},B={};function C(a,b,c){this.props=a;this.context=b;this.refs=B;this.updater=c||A}C.prototype.isReactComponent={};C.prototype.setState=function(a,b){if("object"!==typeof a&&"function"!==typeof a&&null!=a)throw Error(z(85));this.updater.enqueueSetState(this,a,b,"setState")};C.prototype.forceUpdate=function(a){this.updater.enqueueForceUpdate(this,a,"forceUpdate")};
function D(){}D.prototype=C.prototype;function E(a,b,c){this.props=a;this.context=b;this.refs=B;this.updater=c||A}var F=E.prototype=new D;F.constructor=E;l(F,C.prototype);F.isPureReactComponent=!0;var G={current:null},H=Object.prototype.hasOwnProperty,I={key:!0,ref:!0,__self:!0,__source:!0};
function J(a,b,c){var e,d={},k=null,h=null;if(null!=b)for(e in void 0!==b.ref&&(h=b.ref),void 0!==b.key&&(k=""+b.key),b)H.call(b,e)&&!I.hasOwnProperty(e)&&(d[e]=b[e]);var g=arguments.length-2;if(1===g)d.children=c;else if(1<g){for(var f=Array(g),m=0;m<g;m++)f[m]=arguments[m+2];d.children=f}if(a&&a.defaultProps)for(e in g=a.defaultProps,g)void 0===d[e]&&(d[e]=g[e]);return{$$typeof:n,type:a,key:k,ref:h,props:d,_owner:G.current}}
function K(a,b){return{$$typeof:n,type:a.type,key:b,ref:a.ref,props:a.props,_owner:a._owner}}function L(a){return"object"===typeof a&&null!==a&&a.$$typeof===n}function escape(a){var b={"=":"=0",":":"=2"};return"$"+a.replace(/[=:]/g,function(a){return b[a]})}var M=/\/+/g;function N(a,b){return"object"===typeof a&&null!==a&&null!=a.key?escape(""+a.key):b.toString(36)}
function O(a,b,c,e,d){var k=typeof a;if("undefined"===k||"boolean"===k)a=null;var h=!1;if(null===a)h=!0;else switch(k){case "string":case "number":h=!0;break;case "object":switch(a.$$typeof){case n:case p:h=!0}}if(h)return h=a,d=d(h),a=""===e?"."+N(h,0):e,Array.isArray(d)?(c="",null!=a&&(c=a.replace(M,"$&/")+"/"),O(d,b,c,"",function(a){return a})):null!=d&&(L(d)&&(d=K(d,c+(!d.key||h&&h.key===d.key?"":(""+d.key).replace(M,"$&/")+"/")+a)),b.push(d)),1;h=0;e=""===e?".":e+":";if(Array.isArray(a))for(var g=
0;g<a.length;g++){k=a[g];var f=e+N(k,g);h+=O(k,b,c,f,d)}else if(f=y(a),"function"===typeof f)for(a=f.call(a),g=0;!(k=a.next()).done;)k=k.value,f=e+N(k,g++),h+=O(k,b,c,f,d);else if("object"===k)throw b=""+a,Error(z(31,"[object Object]"===b?"object with keys {"+Object.keys(a).join(", ")+"}":b));return h}function P(a,b,c){if(null==a)return a;var e=[],d=0;O(a,e,"","",function(a){return b.call(c,a,d++)});return e}
function Q(a){if(-1===a._status){var b=a._result;b=b();a._status=0;a._result=b;b.then(function(b){0===a._status&&(b=b.default,a._status=1,a._result=b)},function(b){0===a._status&&(a._status=2,a._result=b)})}if(1===a._status)return a._result;throw a._result;}var R={current:null};function S(){var a=R.current;if(null===a)throw Error(z(321));return a}var T={ReactCurrentDispatcher:R,ReactCurrentBatchConfig:{transition:0},ReactCurrentOwner:G,IsSomeRendererActing:{current:!1},assign:l};
exports.Children={map:P,forEach:function(a,b,c){P(a,function(){b.apply(this,arguments)},c)},count:function(a){var b=0;P(a,function(){b++});return b},toArray:function(a){return P(a,function(a){return a})||[]},only:function(a){if(!L(a))throw Error(z(143));return a}};exports.Component=C;exports.PureComponent=E;exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=T;
exports.cloneElement=function(a,b,c){if(null===a||void 0===a)throw Error(z(267,a));var e=l({},a.props),d=a.key,k=a.ref,h=a._owner;if(null!=b){void 0!==b.ref&&(k=b.ref,h=G.current);void 0!==b.key&&(d=""+b.key);if(a.type&&a.type.defaultProps)var g=a.type.defaultProps;for(f in b)H.call(b,f)&&!I.hasOwnProperty(f)&&(e[f]=void 0===b[f]&&void 0!==g?g[f]:b[f])}var f=arguments.length-2;if(1===f)e.children=c;else if(1<f){g=Array(f);for(var m=0;m<f;m++)g[m]=arguments[m+2];e.children=g}return{$$typeof:n,type:a.type,
key:d,ref:k,props:e,_owner:h}};exports.createContext=function(a,b){void 0===b&&(b=null);a={$$typeof:r,_calculateChangedBits:b,_currentValue:a,_currentValue2:a,_threadCount:0,Provider:null,Consumer:null};a.Provider={$$typeof:q,_context:a};return a.Consumer=a};exports.createElement=J;exports.createFactory=function(a){var b=J.bind(null,a);b.type=a;return b};exports.createRef=function(){return{current:null}};exports.forwardRef=function(a){return{$$typeof:t,render:a}};exports.isValidElement=L;
exports.lazy=function(a){return{$$typeof:v,_payload:{_status:-1,_result:a},_init:Q}};exports.memo=function(a,b){return{$$typeof:u,type:a,compare:void 0===b?null:b}};exports.useCallback=function(a,b){return S().useCallback(a,b)};exports.useContext=function(a,b){return S().useContext(a,b)};exports.useDebugValue=function(){};exports.useEffect=function(a,b){return S().useEffect(a,b)};exports.useImperativeHandle=function(a,b,c){return S().useImperativeHandle(a,b,c)};
exports.useLayoutEffect=function(a,b){return S().useLayoutEffect(a,b)};exports.useMemo=function(a,b){return S().useMemo(a,b)};exports.useReducer=function(a,b,c){return S().useReducer(a,b,c)};exports.useRef=function(a){return S().useRef(a)};exports.useState=function(a){return S().useState(a)};exports.version="17.0.2";


/***/ }),

/***/ 6540:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



if (true) {
  module.exports = __webpack_require__(5287);
} else {}


/***/ }),

/***/ 7463:
/***/ ((__unused_webpack_module, exports) => {

/** @license React v0.20.2
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f,g,h,k;if("object"===typeof performance&&"function"===typeof performance.now){var l=performance;exports.unstable_now=function(){return l.now()}}else{var p=Date,q=p.now();exports.unstable_now=function(){return p.now()-q}}
if("undefined"===typeof window||"function"!==typeof MessageChannel){var t=null,u=null,w=function(){if(null!==t)try{var a=exports.unstable_now();t(!0,a);t=null}catch(b){throw setTimeout(w,0),b;}};f=function(a){null!==t?setTimeout(f,0,a):(t=a,setTimeout(w,0))};g=function(a,b){u=setTimeout(a,b)};h=function(){clearTimeout(u)};exports.unstable_shouldYield=function(){return!1};k=exports.unstable_forceFrameRate=function(){}}else{var x=window.setTimeout,y=window.clearTimeout;if("undefined"!==typeof console){var z=
window.cancelAnimationFrame;"function"!==typeof window.requestAnimationFrame&&console.error("This browser doesn't support requestAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills");"function"!==typeof z&&console.error("This browser doesn't support cancelAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills")}var A=!1,B=null,C=-1,D=5,E=0;exports.unstable_shouldYield=function(){return exports.unstable_now()>=
E};k=function(){};exports.unstable_forceFrameRate=function(a){0>a||125<a?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):D=0<a?Math.floor(1E3/a):5};var F=new MessageChannel,G=F.port2;F.port1.onmessage=function(){if(null!==B){var a=exports.unstable_now();E=a+D;try{B(!0,a)?G.postMessage(null):(A=!1,B=null)}catch(b){throw G.postMessage(null),b;}}else A=!1};f=function(a){B=a;A||(A=!0,G.postMessage(null))};g=function(a,b){C=
x(function(){a(exports.unstable_now())},b)};h=function(){y(C);C=-1}}function H(a,b){var c=a.length;a.push(b);a:for(;;){var d=c-1>>>1,e=a[d];if(void 0!==e&&0<I(e,b))a[d]=b,a[c]=e,c=d;else break a}}function J(a){a=a[0];return void 0===a?null:a}
function K(a){var b=a[0];if(void 0!==b){var c=a.pop();if(c!==b){a[0]=c;a:for(var d=0,e=a.length;d<e;){var m=2*(d+1)-1,n=a[m],v=m+1,r=a[v];if(void 0!==n&&0>I(n,c))void 0!==r&&0>I(r,n)?(a[d]=r,a[v]=c,d=v):(a[d]=n,a[m]=c,d=m);else if(void 0!==r&&0>I(r,c))a[d]=r,a[v]=c,d=v;else break a}}return b}return null}function I(a,b){var c=a.sortIndex-b.sortIndex;return 0!==c?c:a.id-b.id}var L=[],M=[],N=1,O=null,P=3,Q=!1,R=!1,S=!1;
function T(a){for(var b=J(M);null!==b;){if(null===b.callback)K(M);else if(b.startTime<=a)K(M),b.sortIndex=b.expirationTime,H(L,b);else break;b=J(M)}}function U(a){S=!1;T(a);if(!R)if(null!==J(L))R=!0,f(V);else{var b=J(M);null!==b&&g(U,b.startTime-a)}}
function V(a,b){R=!1;S&&(S=!1,h());Q=!0;var c=P;try{T(b);for(O=J(L);null!==O&&(!(O.expirationTime>b)||a&&!exports.unstable_shouldYield());){var d=O.callback;if("function"===typeof d){O.callback=null;P=O.priorityLevel;var e=d(O.expirationTime<=b);b=exports.unstable_now();"function"===typeof e?O.callback=e:O===J(L)&&K(L);T(b)}else K(L);O=J(L)}if(null!==O)var m=!0;else{var n=J(M);null!==n&&g(U,n.startTime-b);m=!1}return m}finally{O=null,P=c,Q=!1}}var W=k;exports.unstable_IdlePriority=5;
exports.unstable_ImmediatePriority=1;exports.unstable_LowPriority=4;exports.unstable_NormalPriority=3;exports.unstable_Profiling=null;exports.unstable_UserBlockingPriority=2;exports.unstable_cancelCallback=function(a){a.callback=null};exports.unstable_continueExecution=function(){R||Q||(R=!0,f(V))};exports.unstable_getCurrentPriorityLevel=function(){return P};exports.unstable_getFirstCallbackNode=function(){return J(L)};
exports.unstable_next=function(a){switch(P){case 1:case 2:case 3:var b=3;break;default:b=P}var c=P;P=b;try{return a()}finally{P=c}};exports.unstable_pauseExecution=function(){};exports.unstable_requestPaint=W;exports.unstable_runWithPriority=function(a,b){switch(a){case 1:case 2:case 3:case 4:case 5:break;default:a=3}var c=P;P=a;try{return b()}finally{P=c}};
exports.unstable_scheduleCallback=function(a,b,c){var d=exports.unstable_now();"object"===typeof c&&null!==c?(c=c.delay,c="number"===typeof c&&0<c?d+c:d):c=d;switch(a){case 1:var e=-1;break;case 2:e=250;break;case 5:e=1073741823;break;case 4:e=1E4;break;default:e=5E3}e=c+e;a={id:N++,callback:b,priorityLevel:a,startTime:c,expirationTime:e,sortIndex:-1};c>d?(a.sortIndex=c,H(M,a),null===J(L)&&a===J(M)&&(S?h():S=!0,g(U,c-d))):(a.sortIndex=e,H(L,a),R||Q||(R=!0,f(V)));return a};
exports.unstable_wrapCallback=function(a){var b=P;return function(){var c=P;P=b;try{return a.apply(this,arguments)}finally{P=c}}};


/***/ }),

/***/ 9982:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



if (true) {
  module.exports = __webpack_require__(7463);
} else {}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = (chunkId) => {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.u = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + ".js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/load script */
/******/ 	(() => {
/******/ 		var inProgress = {};
/******/ 		var dataWebpackPrefix = "personal-ai:";
/******/ 		// loadScript function to load a script via script tag
/******/ 		__webpack_require__.l = (url, done, key, chunkId) => {
/******/ 			if(inProgress[url]) { inProgress[url].push(done); return; }
/******/ 			var script, needAttach;
/******/ 			if(key !== undefined) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				for(var i = 0; i < scripts.length; i++) {
/******/ 					var s = scripts[i];
/******/ 					if(s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) { script = s; break; }
/******/ 				}
/******/ 			}
/******/ 			if(!script) {
/******/ 				needAttach = true;
/******/ 				script = document.createElement('script');
/******/ 		
/******/ 				script.charset = 'utf-8';
/******/ 				script.timeout = 120;
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.setAttribute("data-webpack", dataWebpackPrefix + key);
/******/ 		
/******/ 				script.src = url;
/******/ 			}
/******/ 			inProgress[url] = [done];
/******/ 			var onScriptComplete = (prev, event) => {
/******/ 				// avoid mem leaks in IE.
/******/ 				script.onerror = script.onload = null;
/******/ 				clearTimeout(timeout);
/******/ 				var doneFns = inProgress[url];
/******/ 				delete inProgress[url];
/******/ 				script.parentNode && script.parentNode.removeChild(script);
/******/ 				doneFns && doneFns.forEach((fn) => (fn(event)));
/******/ 				if(prev) return prev(event);
/******/ 			}
/******/ 			var timeout = setTimeout(onScriptComplete.bind(null, undefined, { type: 'timeout', target: script }), 120000);
/******/ 			script.onerror = onScriptComplete.bind(null, script.onerror);
/******/ 			script.onload = onScriptComplete.bind(null, script.onload);
/******/ 			needAttach && document.head.appendChild(script);
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		__webpack_require__.p = "/";
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			37: 0
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.f.j = (chunkId, promises) => {
/******/ 				// JSONP chunk loading for javascript
/******/ 				var installedChunkData = __webpack_require__.o(installedChunks, chunkId) ? installedChunks[chunkId] : undefined;
/******/ 				if(installedChunkData !== 0) { // 0 means "already installed".
/******/ 		
/******/ 					// a Promise means "currently loading".
/******/ 					if(installedChunkData) {
/******/ 						promises.push(installedChunkData[2]);
/******/ 					} else {
/******/ 						if(true) { // all chunks have JS
/******/ 							// setup Promise in chunk cache
/******/ 							var promise = new Promise((resolve, reject) => (installedChunkData = installedChunks[chunkId] = [resolve, reject]));
/******/ 							promises.push(installedChunkData[2] = promise);
/******/ 		
/******/ 							// start chunk loading
/******/ 							var url = __webpack_require__.p + __webpack_require__.u(chunkId);
/******/ 							// create error before stack unwound to get useful stacktrace later
/******/ 							var error = new Error();
/******/ 							var loadingEnded = (event) => {
/******/ 								if(__webpack_require__.o(installedChunks, chunkId)) {
/******/ 									installedChunkData = installedChunks[chunkId];
/******/ 									if(installedChunkData !== 0) installedChunks[chunkId] = undefined;
/******/ 									if(installedChunkData) {
/******/ 										var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 										var realSrc = event && event.target && event.target.src;
/******/ 										error.message = 'Loading chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 										error.name = 'ChunkLoadError';
/******/ 										error.type = errorType;
/******/ 										error.request = realSrc;
/******/ 										installedChunkData[1](error);
/******/ 									}
/******/ 								}
/******/ 							};
/******/ 							__webpack_require__.l(url, loadingEnded, "chunk-" + chunkId, chunkId);
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 		};
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var chunkIds = data[0];
/******/ 			var moreModules = data[1];
/******/ 			var runtime = data[2];
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 		
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkpersonal_ai"] = self["webpackChunkpersonal_ai"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};

// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(6540);
// EXTERNAL MODULE: ./node_modules/react-dom/index.js
var react_dom = __webpack_require__(961);
;// CONCATENATED MODULE: ./src/scheduled-messages/SheetInitializer.ts
/**
 * Sheet 初始化器
 * 负责一键生成 Google Sheet、AppScript 项目和触发器
 */

class SheetInitializer {
  constructor(token) {
    this.messagesSheetId = 0;
    this.configSheetId = 0;
    this.token = token;
  }

  /**
   * 一键创建定时消息系统
   */
  async createScheduledMessagesSheet() {
    try {
      console.log('开始创建定时消息系统...');

      // 1. 创建 Spreadsheet
      console.log('步骤 1/8: 创建 Spreadsheet...');
      const sheet = await this.createSpreadsheet();

      // 2. 设置共享权限（组织内所有人可编辑）
      console.log('步骤 2/8: 设置共享权限...');
      await this.setPermissions(sheet.spreadsheetId);

      // 3. 设置工作表结构
      console.log('步骤 3/8: 设置工作表结构...');
      await this.setupWorksheets(sheet.spreadsheetId);

      // 4. 创建 AppScript 项目
      console.log('步骤 4/8: 创建 AppScript 项目...');
      const scriptId = await this.createAppScriptProject(sheet.spreadsheetId);

      // 5. 部署为 Web App（必须先部署才能调用 Web App）
      console.log('步骤 5/8: 部署 Web App...');
      const webAppUrl = await this.deployWebApp(scriptId);
      console.log('部署完成，需要用户授权...');

      // 返回需要授权的状态
      // 用户需要在浏览器中打开 Web App URL 并授权
      // 添加 action=authSuccess 参数，授权完成后显示成功页面
      return {
        success: true,
        sheetId: sheet.spreadsheetId,
        sheetUrl: sheet.spreadsheetUrl,
        scriptId,
        webAppUrl,
        needsAuthorization: true,
        authUrl: `${webAppUrl}?action=authSuccess` // 用户需要访问这个 URL 来授权
      };
    } catch (error) {
      console.error('创建定时消息系统失败:', error);
      return {
        success: false,
        sheetId: '',
        sheetUrl: '',
        scriptId: '',
        webAppUrl: '',
        error: error.message || '未知错误'
      };
    }
  }

  /**
   * 创建 Spreadsheet
   */
  async createSpreadsheet() {
    const response = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        properties: {
          title: `Personal AI - 定时消息管理`
        },
        sheets: [{
          properties: {
            title: 'Messages',
            gridProperties: {
              frozenRowCount: 1
            }
          }
        }, {
          properties: {
            title: 'Config',
            gridProperties: {
              frozenRowCount: 1
            }
          }
        }]
      })
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`创建 Spreadsheet 失败: ${error}`);
    }
    const data = await response.json();

    // 保存工作表 ID
    if (data.sheets && data.sheets.length >= 2) {
      this.messagesSheetId = data.sheets[0].properties.sheetId;
      this.configSheetId = data.sheets[1].properties.sheetId;
      console.log(`Messages Sheet ID: ${this.messagesSheetId}, Config Sheet ID: ${this.configSheetId}`);
    }
    return {
      spreadsheetId: data.spreadsheetId,
      spreadsheetUrl: data.spreadsheetUrl
    };
  }

  /**
   * 设置共享权限：组织内所有人可编辑
   */
  async setPermissions(spreadsheetId) {
    try {
      // 获取用户的域名信息
      const userInfo = await this.getUserInfo();
      const domain = userInfo.email.split('@')[1]; // 例如: ringcentral.com

      // 设置权限：组织内所有人可编辑
      const response = await fetch(`https://www.googleapis.com/drive/v3/files/${spreadsheetId}/permissions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          type: 'domain',
          role: 'writer',
          domain: domain,
          allowFileDiscovery: true
        })
      });
      if (!response.ok) {
        const error = await response.text();
        console.warn('设置域权限失败，尝试设置为任何人可编辑:', error);

        // 如果域权限设置失败，尝试设置为"知道链接的任何人可编辑"
        const fallbackResponse = await fetch(`https://www.googleapis.com/drive/v3/files/${spreadsheetId}/permissions`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            type: 'anyone',
            role: 'writer'
          })
        });
        if (!fallbackResponse.ok) {
          const fallbackError = await fallbackResponse.text();
          console.warn('设置共享权限失败:', fallbackError);
          // 不抛出错误，允许继续执行
        } else {
          console.log('✅ 已设置为：知道链接的任何人可编辑');
        }
      } else {
        console.log(`✅ 已设置为：${domain} 域内所有人可编辑`);
      }
    } catch (error) {
      console.warn('设置权限失败:', error);
      // 不抛出错误，允许继续执行
    }
  }

  /**
   * 获取用户信息
   */
  async getUserInfo() {
    const response = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: {
        'Authorization': `Bearer ${this.token}`
      }
    });
    if (!response.ok) {
      throw new Error('无法获取用户信息');
    }
    return await response.json();
  }

  /**
   * 设置工作表结构（表头和格式）
   * 
   * 重要说明：
   * - header 的列名必须与 ScheduledMessage 接口的字段名完全一致
   * - 用户可以在 Google Sheet 中自由调整列的顺序，系统会自动适配
   * - ScheduledMessageService 使用动态列映射机制：
   *   1. 读取时：通过 header 解析每列数据到对应字段
   *   2. 写入时：根据 header 顺序动态生成行数据
   * - 不要修改 header 的列名，但可以随意调整顺序、隐藏列、插入新列
   */
  async setupWorksheets(spreadsheetId) {
    // Messages 表头（移除 Type 和 Target_Type，由程序自动判断）
    // 注意：这里定义的是初始顺序，用户可以在 Sheet 中随意调整
    const messagesHeaders = ['ID', 'Topic', 'Content', 'Schedule_Date', 'Schedule_Time', 'End_Date', 'Repeat_Every', 'Repeat_Unit', 'Repeat_Count', 'Push_Method', 'Glip_User_Name', 'Glip_Team_ID', 'Attachment', 'AI_Endpoint', 'AI_Headers', 'AI_Body', 'Status', 'Last_Exec', 'Next_Exec', 'Exec_Count', 'Exec_Log'];

    // Config 表头
    const configHeaders = ['Key', 'Value'];
    const requests = [
    // 设置 Messages 表头
    {
      updateCells: {
        range: {
          sheetId: this.messagesSheetId,
          startRowIndex: 0,
          endRowIndex: 1,
          startColumnIndex: 0,
          endColumnIndex: messagesHeaders.length
        },
        rows: [{
          values: messagesHeaders.map(header => ({
            userEnteredValue: {
              stringValue: header
            },
            userEnteredFormat: {
              backgroundColor: {
                red: 0.2,
                green: 0.5,
                blue: 0.8
              },
              textFormat: {
                bold: true,
                foregroundColor: {
                  red: 1,
                  green: 1,
                  blue: 1
                }
              }
            }
          }))
        }],
        fields: 'userEnteredValue,userEnteredFormat'
      }
    },
    // 设置 Config 表头
    {
      updateCells: {
        range: {
          sheetId: this.configSheetId,
          startRowIndex: 0,
          endRowIndex: 1,
          startColumnIndex: 0,
          endColumnIndex: 2
        },
        rows: [{
          values: configHeaders.map(header => ({
            userEnteredValue: {
              stringValue: header
            },
            userEnteredFormat: {
              backgroundColor: {
                red: 0.2,
                green: 0.5,
                blue: 0.8
              },
              textFormat: {
                bold: true,
                foregroundColor: {
                  red: 1,
                  green: 1,
                  blue: 1
                }
              }
            }
          }))
        }],
        fields: 'userEnteredValue,userEnteredFormat'
      }
    },
    // 自动调整列宽
    {
      autoResizeDimensions: {
        dimensions: {
          sheetId: this.messagesSheetId,
          dimension: 'COLUMNS',
          startIndex: 0,
          endIndex: messagesHeaders.length
        }
      }
    }];
    const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        requests
      })
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`设置工作表结构失败: ${error}`);
    }
  }

  /**
   * 添加示例数据
   */
  async addSampleData(spreadsheetId) {
    const now = new Date();
    const oneMinuteLater = new Date(now.getTime() + 60 * 1000);
    const sampleMessage = [`msg_welcome_${Date.now()}`,
    // ID
    'Personal AI 欢迎消息',
    // Topic
    '🎉 恭喜！您的定时消息系统已成功初始化！\n\n这是一条测试消息，证明系统运行正常。\n\n您现在可以在管理界面添加更多定时消息。',
    // Content
    this.formatDate(now),
    // Schedule_Date
    this.formatTime(oneMinuteLater),
    // Schedule_Time（填写时间，自动判断为 Hourly 类型）
    '',
    // End_Date
    '',
    // Repeat_Every
    '',
    // Repeat_Unit
    '',
    // Repeat_Count
    'AsMe',
    // Push_Method
    'sync.service',
    // Glip_User_Name
    '',
    // Glip_Team_ID
    '',
    // Attachment
    '',
    // AI_Endpoint
    '',
    // AI_Headers
    '',
    // AI_Body
    'Active',
    // Status
    '',
    // Last_Exec
    this.formatDateTime(oneMinuteLater),
    // Next_Exec
    0,
    // Exec_Count
    '待执行' // Exec_Log
    ];
    const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Messages!A2:U2?valueInputOption=USER_ENTERED`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        values: [sampleMessage]
      })
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`添加示例数据失败: ${error}`);
    }
  }

  /**
   * 创建 AppScript 项目
   */
  async createAppScriptProject(spreadsheetId) {
    // 读取 AppScript 模板代码
    const scriptCode = await this.loadAppScriptTemplate();

    // 创建 Apps Script 项目
    const createResponse = await fetch('https://script.googleapis.com/v1/projects', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        title: 'Personal AI - Scheduled Messages',
        parentId: spreadsheetId
      })
    });
    if (!createResponse.ok) {
      const error = await createResponse.text();
      throw new Error(`创建 AppScript 项目失败: ${error}`);
    }
    const project = await createResponse.json();
    const scriptId = project.scriptId;

    // 上传代码
    const updateResponse = await fetch(`https://script.googleapis.com/v1/projects/${scriptId}/content`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        files: [{
          name: 'Code',
          type: 'SERVER_JS',
          source: scriptCode
        }, {
          name: 'appsscript',
          type: 'JSON',
          source: JSON.stringify({
            timeZone: 'Asia/Shanghai',
            exceptionLogging: 'STACKDRIVER',
            runtimeVersion: 'V8',
            webapp: {
              access: 'ANYONE_ANONYMOUS',
              executeAs: 'USER_DEPLOYING'
            },
            executionApi: {
              access: 'ANYONE'
            }
          })
        }]
      })
    });
    if (!updateResponse.ok) {
      const error = await updateResponse.text();
      throw new Error(`上传 AppScript 代码失败: ${error}`);
    }
    return scriptId;
  }

  /**
   * 加载 AppScript 模板代码
   */
  async loadAppScriptTemplate() {
    // 从 src/scheduled-messages/app-script-template.gs 读取
    // 注意：在 Chrome Extension 中，我们需要将这个文件打包进来
    // 这里我们直接返回代码字符串
    const templateCode = `
// 注意：这里会被实际的模板代码替换
// 在实际构建时，我们会通过 webpack 或其他方式将 .gs 文件内容注入
function minuteTrigger() {
  executeScheduledMessages(['Hourly']);
}

function dailyTrigger() {
  executeScheduledMessages(['Daily', 'Periodic']);
}

// ... 其他函数
`;

    // TODO: 在实际实现中，需要通过 webpack 将 .gs 文件内容作为字符串导入
    // 或者直接在这里内联完整代码

    // 暂时返回一个简化版本（实际应该读取完整模板）
    return await this.getFullAppScriptCode();
  }

  /**
   * 获取完整的 AppScript 代码
   * 从扩展资源中读取模板文件
   */
  async getFullAppScriptCode() {
    try {
      const response = await fetch(chrome.runtime.getURL('app-script-template.gs'));
      if (!response.ok) {
        throw new Error(`无法加载模板文件: HTTP ${response.status}`);
      }
      return await response.text();
    } catch (error) {
      console.error('加载 AppScript 模板文件失败:', error);
      throw new Error(`加载 AppScript 模板文件失败: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * 完成初始化（在用户授权后调用）
   * 创建触发器、添加示例数据并保存配置
   */
  async completeInitialization(sheetId, scriptId, webAppUrl) {
    try {
      // 6. 创建触发器（通过 Web App 调用）
      console.log('步骤 6/8: 创建触发器...');
      const triggers = await this.createTriggers(webAppUrl);

      // 7. 添加示例数据（触发器创建后才能推送）
      console.log('步骤 7/8: 添加示例数据...');
      await this.addSampleData(sheetId);

      // 8. 保存配置
      console.log('步骤 8/8: 保存配置...');
      await this.saveConfig(sheetId, scriptId, webAppUrl, triggers);
      console.log('定时消息系统创建成功！');
      return {
        success: true,
        sheetId,
        sheetUrl: `https://docs.google.com/spreadsheets/d/${sheetId}/edit`,
        scriptId,
        webAppUrl
      };
    } catch (error) {
      console.error('完成初始化失败:', error);
      return {
        success: false,
        sheetId,
        sheetUrl: `https://docs.google.com/spreadsheets/d/${sheetId}/edit`,
        scriptId,
        webAppUrl,
        error: error.message || '未知错误'
      };
    }
  }

  /**
   * 创建触发器
   * 注意：Google Apps Script REST API 不支持直接创建触发器
   * 我们通过调用 Web App 的 setupTriggers 端点来创建触发器
   * 因为 ScriptApp.newTrigger 只能在 Apps Script 环境内部执行
   */
  async createTriggers(webAppUrl) {
    // 通过 Web App 调用 setupTriggers
    const response = await fetch(`${webAppUrl}?action=setupTriggers`, {
      method: 'GET',
      // Web App 部署为 "Anyone" 访问时不需要 Authorization header
      // 但我们仍然可以带上 token 以防万一
      headers: {
        'Authorization': `Bearer ${this.token}`
      }
    });

    // 检查 Content-Type：如果是 HTML，说明需要授权
    const contentType = response.headers.get('content-type');
    if (contentType?.includes('text/html')) {
      console.warn('Web App 返回 HTML，需要用户授权');
      throw new Error('AUTHORIZATION_REQUIRED');
    }
    if (!response.ok) {
      const error = await response.text();
      console.error('创建触发器失败，响应详情:', error);
      throw new Error(`创建触发器失败: HTTP ${response.status} - ${error}`);
    }

    // 尝试解析 JSON
    let result;
    try {
      result = await response.json();
    } catch (jsonError) {
      console.error('无法解析响应为 JSON:', jsonError);
      throw new Error('AUTHORIZATION_REQUIRED');
    }
    if (!result.success) {
      throw new Error(`创建触发器失败: ${result.error || '未知错误'}`);
    }
    console.log('触发器创建成功:', result.message);

    // 返回占位符 ID，因为我们无法从 Web App 获取实际的触发器 ID
    // 但触发器已经在 Apps Script 中成功创建
    return {
      minuteTriggerId: 'created-via-webapp',
      dailyTriggerId: 'created-via-webapp'
    };
  }

  /**
   * 部署为 Web App
   */
  async deployWebApp(scriptId) {
    // 第一步：创建版本
    console.log('创建 AppScript 版本...');
    const versionResponse = await fetch(`https://script.googleapis.com/v1/projects/${scriptId}/versions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        description: 'Initial version for Personal AI Scheduled Messages'
      })
    });
    if (!versionResponse.ok) {
      const error = await versionResponse.text();
      throw new Error(`创建版本失败: ${error}`);
    }
    const version = await versionResponse.json();
    const versionNumber = version.versionNumber;
    console.log(`版本创建成功: ${versionNumber}`);

    // 第二步：基于版本创建部署
    console.log(`基于版本 ${versionNumber} 创建部署...`);
    const deploymentResponse = await fetch(`https://script.googleapis.com/v1/projects/${scriptId}/deployments`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        versionNumber: versionNumber,
        manifestFileName: 'appsscript',
        description: 'Personal AI Scheduled Messages Web App'
      })
    });
    if (!deploymentResponse.ok) {
      const error = await deploymentResponse.text();
      throw new Error(`部署 Web App 失败: ${error}`);
    }
    const deployment = await deploymentResponse.json();
    console.log('部署创建成功:', deployment);

    // 获取 Web App URL
    const webAppUrl = deployment.entryPoints?.[0]?.webApp?.url || '';
    if (!webAppUrl) {
      throw new Error('无法获取 Web App URL，请检查部署配置');
    }
    return webAppUrl;
  }

  /**
   * 保存配置到 Config 工作表和 Chrome Storage
   */
  async saveConfig(spreadsheetId, scriptId, webAppUrl, triggers) {
    const now = new Date();
    const configData = [['minute_trigger_id', triggers.minuteTriggerId], ['daily_trigger_id', triggers.dailyTriggerId], ['web_app_url', webAppUrl], ['sheet_version', '2.0'], ['created_by', 'Personal AI Extension'], ['created_at', this.formatDateTime(now)], ['last_sync_time', this.formatDateTime(now)]];

    // 保存到 Config 工作表
    const sheetResponse = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Config!A2:B8?valueInputOption=USER_ENTERED`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        values: configData
      })
    });
    if (!sheetResponse.ok) {
      console.warn('保存配置到 Sheet 失败');
    }

    // 保存到 Chrome Storage
    const config = {
      sheetId: spreadsheetId,
      sheetUrl: `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`,
      messagesSheetId: this.messagesSheetId,
      // 保存 Messages Sheet ID
      scriptId,
      webAppUrl,
      minute_trigger_id: triggers.minuteTriggerId,
      daily_trigger_id: triggers.dailyTriggerId,
      sheet_version: '2.0',
      created_by: 'Personal AI Extension',
      created_at: this.formatDateTime(now),
      last_sync_time: this.formatDateTime(now)
    };
    await chrome.storage.local.set({
      scheduledMessagesConfig: config
    });
  }

  // 辅助方法

  formatDate(date) {
    return date.toISOString().split('T')[0];
  }
  formatTime(date) {
    return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
  }
  formatDateTime(date) {
    return `${this.formatDate(date)} ${this.formatTime(date)}`;
  }
}
;// CONCATENATED MODULE: ./src/scheduled-messages/components/OneClickSetup.tsx
/**
 * 一键初始化组件
 * 引导用户创建定时消息系统
 */




const OneClickSetup = _ref => {
  let {
    onComplete
  } = _ref;
  const [isInitializing, setIsInitializing] = (0,react.useState)(false);
  const [currentStep, setCurrentStep] = (0,react.useState)('');
  const [manualSheetUrl, setManualSheetUrl] = (0,react.useState)('');
  const [error, setError] = (0,react.useState)('');
  const [authToken, setAuthToken] = (0,react.useState)('');
  const [needsAuth, setNeedsAuth] = (0,react.useState)(false);
  const [authUrl, setAuthUrl] = (0,react.useState)('');
  const [tempResult, setTempResult] = (0,react.useState)(null);
  const handleOneClickSetup = async () => {
    setIsInitializing(true);
    setError('');
    try {
      // 获取 Google OAuth token
      setCurrentStep('正在获取授权...');
      const token = await getAuthToken();
      if (!token) {
        throw new Error('无法获取 Google 授权，请检查账号登录状态');
      }
      setAuthToken(token);

      // 创建 Sheet 和 AppScript
      setCurrentStep('正在创建系统（共8步，当前完成1-5步）...');
      const initializer = new SheetInitializer(token);
      const result = await initializer.createScheduledMessagesSheet();
      if (result.success && result.needsAuthorization) {
        // 需要用户授权
        setTempResult(result);
        setNeedsAuth(true);
        setAuthUrl(result.authUrl || '');
        setCurrentStep('');
        setIsInitializing(false);
      } else if (result.success) {
        setCurrentStep('初始化成功！');
        onComplete(result);
      } else {
        throw new Error(result.error || '初始化失败');
      }
    } catch (err) {
      console.error('初始化失败:', err);
      setError(err.message || '初始化失败，请重试');
      setIsInitializing(false);
    }
  };
  const handleCompleteAuth = async () => {
    if (!tempResult || !authToken) {
      setError('缺少必要信息，请重新初始化');
      return;
    }
    setIsInitializing(true);
    setError('');
    try {
      setCurrentStep('正在完成初始化（第6-8步：创建触发器、添加示例数据、保存配置）...');
      const initializer = new SheetInitializer(authToken);
      const result = await initializer.completeInitialization(tempResult.sheetId, tempResult.scriptId, tempResult.webAppUrl);
      if (result.success) {
        setCurrentStep('初始化成功！');
        onComplete(result);
      } else {
        throw new Error(result.error || '完成初始化失败');
      }
    } catch (err) {
      console.error('完成初始化失败:', err);

      // 检查是否是授权错误
      if (err.message === 'AUTHORIZATION_REQUIRED' || err.message?.includes('AUTHORIZATION_REQUIRED')) {
        setError('⚠️ 检测到您尚未完成授权！请先点击上方"打开授权页面"按钮，在弹出的页面中完成授权操作，然后再点击此按钮继续。');
        setNeedsAuth(true); // 保持在授权界面
      } else {
        setError(err.message || '完成初始化失败，请重试');
        setNeedsAuth(true); // 保持在授权界面，允许重试
      }
      setIsInitializing(false);
    }
  };
  const handleManualBind = async () => {
    if (!manualSheetUrl.trim()) {
      setError('请输入 Sheet URL');
      return;
    }
    try {
      // 从 URL 提取 Sheet ID
      const sheetId = extractSheetId(manualSheetUrl);
      if (!sheetId) {
        throw new Error('无效的 Sheet URL');
      }

      // 保存配置
      await chrome.storage.local.set({
        scheduledMessagesConfig: {
          sheetId,
          sheetUrl: manualSheetUrl,
          sheet_version: '2.0',
          created_by: 'Manual',
          created_at: new Date().toISOString()
        }
      });

      // 刷新页面
      window.location.reload();
    } catch (err) {
      setError(err.message || '绑定失败');
    }
  };
  const getAuthToken = () => {
    return new Promise((resolve, reject) => {
      // 先清除旧 token，强制重新获取以应用新的权限范围
      chrome.identity.getAuthToken({
        interactive: false
      }, oldToken => {
        if (oldToken) {
          chrome.identity.removeCachedAuthToken({
            token: oldToken
          }, () => {
            // 重新获取 token
            chrome.identity.getAuthToken({
              interactive: true
            }, token => {
              if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
              } else {
                resolve(token || '');
              }
            });
          });
        } else {
          // 没有旧 token，直接获取新的
          chrome.identity.getAuthToken({
            interactive: true
          }, token => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve(token || '');
            }
          });
        }
      });
    });
  };
  const extractSheetId = url => {
    const match = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    return match ? match[1] : null;
  };
  return /*#__PURE__*/react.createElement("div", {
    style: styles.container
  }, /*#__PURE__*/react.createElement("div", {
    style: styles.header
  }, /*#__PURE__*/react.createElement("h1", {
    style: styles.title
  }, "\uD83D\uDE80 \u5F00\u59CB\u4F7F\u7528\u5B9A\u65F6\u6D88\u606F\u7BA1\u7406")), /*#__PURE__*/react.createElement("div", {
    style: styles.content
  }, needsAuth ?
  /*#__PURE__*/
  // 授权界面
  react.createElement(react.Fragment, null, !isInitializing ? /*#__PURE__*/react.createElement(react.Fragment, null, error && /*#__PURE__*/react.createElement("div", {
    style: error.includes('尚未完成授权') ? styles.authError : styles.error
  }, error), /*#__PURE__*/react.createElement("div", {
    style: styles.authSection
  }, /*#__PURE__*/react.createElement("h2", {
    style: styles.authTitle
  }, "\uD83D\uDD10 \u9700\u8981\u6388\u6743"), /*#__PURE__*/react.createElement("p", {
    style: styles.authDescription
  }, "\u7CFB\u7EDF\u5DF2\u6210\u529F\u521B\u5EFA Sheet \u548C AppScript\uFF08\u5B8C\u6210\u6B65\u9AA4 1-5/8\uFF09"), /*#__PURE__*/react.createElement("p", {
    style: styles.authDescription
  }, "\u73B0\u5728\u9700\u8981\u60A8\u6388\u6743 Apps Script \u8BBF\u95EE Google \u670D\u52A1\uFF0C\u4E4B\u540E\u5C06\u7EE7\u7EED\u5B8C\u6210\u5269\u4F59\u6B65\u9AA4\u3002"), /*#__PURE__*/react.createElement("div", {
    style: styles.authSteps
  }, /*#__PURE__*/react.createElement("p", {
    style: styles.stepTitle
  }, "\u8BF7\u6309\u7167\u4EE5\u4E0B\u6B65\u9AA4\u64CD\u4F5C\uFF1A"), /*#__PURE__*/react.createElement("ol", {
    style: styles.stepList
  }, /*#__PURE__*/react.createElement("li", null, "\u70B9\u51FB\u4E0B\u65B9\"\u6253\u5F00\u6388\u6743\u9875\u9762\"\u6309\u94AE"), /*#__PURE__*/react.createElement("li", null, "\u5728\u65B0\u6253\u5F00\u7684\u9875\u9762\u4E2D\uFF0C\u70B9\u51FB \"REVIEW PERMISSIONS\" \u6309\u94AE"), /*#__PURE__*/react.createElement("li", null, "\u9009\u62E9\u60A8\u7684 Google \u8D26\u53F7\u5E76\u6388\u6743\u5E94\u7528"), /*#__PURE__*/react.createElement("li", null, "\u6388\u6743\u5B8C\u6210\u540E\uFF0C\u56DE\u5230\u6B64\u9875\u9762\u70B9\u51FB\"\u5B8C\u6210\u521D\u59CB\u5316\"\u6309\u94AE"))), /*#__PURE__*/react.createElement("button", {
    style: styles.primaryButton,
    onClick: () => window.open(authUrl, '_blank'),
    onMouseOver: e => e.currentTarget.style.backgroundColor = '#0056b3',
    onMouseOut: e => e.currentTarget.style.backgroundColor = '#007bff'
  }, "\uD83D\uDD13 \u6253\u5F00\u6388\u6743\u9875\u9762"), /*#__PURE__*/react.createElement("p", {
    style: styles.authNote
  }, "\uD83D\uDCA1 \u63D0\u793A\uFF1A\u5982\u679C\u6388\u6743\u7A97\u53E3\u5DF2\u5173\u95ED\uFF0C\u60A8\u53EF\u4EE5\u968F\u65F6\u91CD\u65B0\u70B9\u51FB\u4E0A\u65B9\u6309\u94AE\u6253\u5F00\u3002"), /*#__PURE__*/react.createElement("p", {
    style: styles.authHint
  }, "\u6388\u6743\u5B8C\u6210\u540E\uFF0C\u70B9\u51FB\u4E0B\u65B9\u6309\u94AE\u7EE7\u7EED\uFF1A"), /*#__PURE__*/react.createElement("button", {
    style: styles.completeButton,
    onClick: handleCompleteAuth,
    onMouseOver: e => e.currentTarget.style.backgroundColor = '#218838',
    onMouseOut: e => e.currentTarget.style.backgroundColor = '#28a745'
  }, "\u2705 \u6211\u5DF2\u5B8C\u6210\u6388\u6743\uFF0C\u7EE7\u7EED\u521D\u59CB\u5316"), tempResult && /*#__PURE__*/react.createElement("div", {
    style: styles.infoBox
  }, /*#__PURE__*/react.createElement("p", {
    style: styles.infoTitle
  }, "\uD83D\uDCCB \u7CFB\u7EDF\u4FE1\u606F\uFF1A"), /*#__PURE__*/react.createElement("p", {
    style: styles.infoItem
  }, "Sheet ID: ", tempResult.sheetId), /*#__PURE__*/react.createElement("p", {
    style: styles.infoItem
  }, /*#__PURE__*/react.createElement("a", {
    href: tempResult.sheetUrl,
    target: "_blank",
    rel: "noopener noreferrer"
  }, "\uD83D\uDCCA \u67E5\u770B Sheet"))))) : /*#__PURE__*/react.createElement("div", {
    style: styles.loading
  }, /*#__PURE__*/react.createElement("div", {
    style: styles.spinner
  }), /*#__PURE__*/react.createElement("p", {
    style: styles.loadingText
  }, currentStep), /*#__PURE__*/react.createElement("p", {
    style: styles.loadingHint
  }, "\u8FD9\u53EF\u80FD\u9700\u8981 10-15 \u79D2\uFF0C\u8BF7\u7A0D\u5019..."))) : !isInitializing ? /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("p", {
    style: styles.description
  }, "\u60A8\u8FD8\u6CA1\u6709\u8BBE\u7F6E\u5B9A\u65F6\u6D88\u606F\u7CFB\u7EDF\u3002"), /*#__PURE__*/react.createElement("div", {
    style: styles.features
  }, /*#__PURE__*/react.createElement("p", {
    style: styles.featureTitle
  }, "\u70B9\u51FB\u4E0B\u65B9\u6309\u94AE\uFF0C\u7CFB\u7EDF\u5C06\u81EA\u52A8\u4E3A\u60A8\uFF1A"), /*#__PURE__*/react.createElement("ul", {
    style: styles.featureList
  }, /*#__PURE__*/react.createElement("li", null, "\u2705 \u521B\u5EFA Google Sheet \u7EF4\u62A4\u8868"), /*#__PURE__*/react.createElement("li", null, "\u2705 \u914D\u7F6E\u81EA\u52A8\u6267\u884C\u811A\u672C"), /*#__PURE__*/react.createElement("li", null, "\u2705 \u8BBE\u7F6E\u5B9A\u65F6\u89E6\u53D1\u5668"), /*#__PURE__*/react.createElement("li", null, "\u2705 \u6DFB\u52A0\u6D4B\u8BD5\u6D88\u606F\uFF08\u4E00\u5206\u949F\u540E\u63A8\u9001\uFF09"))), /*#__PURE__*/react.createElement("button", {
    style: styles.primaryButton,
    onClick: handleOneClickSetup,
    onMouseOver: e => e.currentTarget.style.backgroundColor = '#0056b3',
    onMouseOut: e => e.currentTarget.style.backgroundColor = '#007bff'
  }, "\uD83D\uDE80 \u4E00\u952E\u751F\u6210\u7EF4\u62A4\u8868"), /*#__PURE__*/react.createElement("div", {
    style: styles.divider
  }, /*#__PURE__*/react.createElement("span", {
    style: styles.dividerText
  }, "\u6216\u8005")), /*#__PURE__*/react.createElement("div", {
    style: styles.manualSection
  }, /*#__PURE__*/react.createElement("p", {
    style: styles.manualTitle
  }, "\u5982\u679C\u60A8\u5DF2\u6709\u7EF4\u62A4\u8868\uFF0C\u53EF\u4EE5\u76F4\u63A5\u7ED1\u5B9A\uFF1A"), /*#__PURE__*/react.createElement("div", {
    style: styles.inputGroup
  }, /*#__PURE__*/react.createElement("input", {
    type: "text",
    placeholder: "\u7C98\u8D34 Sheet URL...",
    value: manualSheetUrl,
    onChange: e => setManualSheetUrl(e.target.value),
    style: styles.input
  }), /*#__PURE__*/react.createElement("button", {
    style: styles.secondaryButton,
    onClick: handleManualBind,
    onMouseOver: e => e.currentTarget.style.backgroundColor = '#5a6268',
    onMouseOut: e => e.currentTarget.style.backgroundColor = '#6c757d'
  }, "\u7ED1\u5B9A"))), error && /*#__PURE__*/react.createElement("div", {
    style: styles.error
  }, "\u274C ", error)) : /*#__PURE__*/react.createElement("div", {
    style: styles.loading
  }, /*#__PURE__*/react.createElement("div", {
    style: styles.spinner
  }), /*#__PURE__*/react.createElement("p", {
    style: styles.loadingText
  }, currentStep), /*#__PURE__*/react.createElement("p", {
    style: styles.loadingHint
  }, "\u8FD9\u53EF\u80FD\u9700\u8981 10-15 \u79D2\uFF0C\u8BF7\u7A0D\u5019..."))));
};
const styles = {
  container: {
    maxWidth: '600px',
    margin: '0 auto',
    padding: '40px 20px'
  },
  header: {
    textAlign: 'center',
    marginBottom: '30px'
  },
  title: {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#333',
    margin: 0
  },
  content: {
    backgroundColor: '#fff',
    borderRadius: '12px',
    padding: '40px',
    boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
  },
  description: {
    fontSize: '16px',
    color: '#666',
    textAlign: 'center',
    marginBottom: '30px'
  },
  features: {
    marginBottom: '30px'
  },
  featureTitle: {
    fontSize: '14px',
    color: '#666',
    marginBottom: '10px'
  },
  featureList: {
    listStyle: 'none',
    padding: 0,
    margin: 0
  },
  primaryButton: {
    width: '100%',
    padding: '15px',
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#fff',
    backgroundColor: '#007bff',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    transition: 'background-color 0.3s'
  },
  divider: {
    textAlign: 'center',
    margin: '30px 0',
    position: 'relative'
  },
  dividerText: {
    backgroundColor: '#fff',
    padding: '0 10px',
    color: '#999',
    fontSize: '14px'
  },
  manualSection: {
    marginTop: '20px'
  },
  manualTitle: {
    fontSize: '14px',
    color: '#666',
    marginBottom: '10px'
  },
  inputGroup: {
    display: 'flex',
    gap: '10px'
  },
  input: {
    flex: 1,
    padding: '10px',
    fontSize: '14px',
    border: '1px solid #ddd',
    borderRadius: '6px'
  },
  secondaryButton: {
    padding: '10px 20px',
    fontSize: '14px',
    color: '#fff',
    backgroundColor: '#6c757d',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    transition: 'background-color 0.3s'
  },
  completeButton: {
    padding: '15px',
    fontSize: '16px',
    fontWeight: 'bold',
    color: '#fff',
    backgroundColor: '#28a745',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
    width: '100%'
  },
  error: {
    marginTop: '20px',
    padding: '15px',
    backgroundColor: '#f8d7da',
    color: '#721c24',
    borderRadius: '6px',
    fontSize: '14px'
  },
  authError: {
    marginTop: '20px',
    padding: '20px',
    backgroundColor: '#fff3cd',
    color: '#856404',
    borderRadius: '8px',
    fontSize: '15px',
    fontWeight: 500,
    border: '2px solid #ffc107',
    lineHeight: '1.6'
  },
  loading: {
    textAlign: 'center',
    padding: '40px 20px'
  },
  spinner: {
    width: '50px',
    height: '50px',
    border: '4px solid #f3f3f3',
    borderTop: '4px solid #007bff',
    borderRadius: '50%',
    margin: '0 auto 20px',
    animation: 'spin 1s linear infinite'
  },
  loadingText: {
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '10px'
  },
  loadingHint: {
    fontSize: '14px',
    color: '#999'
  },
  authSection: {
    padding: '20px 0'
  },
  authTitle: {
    fontSize: '22px',
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: '15px'
  },
  authDescription: {
    fontSize: '15px',
    color: '#666',
    textAlign: 'center',
    marginBottom: '10px'
  },
  authSteps: {
    backgroundColor: '#f8f9fa',
    padding: '20px',
    borderRadius: '8px',
    marginBottom: '20px'
  },
  stepTitle: {
    fontSize: '15px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '10px'
  },
  stepList: {
    fontSize: '14px',
    color: '#666',
    lineHeight: '1.8',
    paddingLeft: '20px'
  },
  authNote: {
    fontSize: '13px',
    color: '#888',
    textAlign: 'center',
    marginTop: '10px',
    fontStyle: 'italic'
  },
  authHint: {
    fontSize: '14px',
    color: '#666',
    textAlign: 'center',
    marginTop: '20px',
    marginBottom: '10px'
  },
  infoBox: {
    backgroundColor: '#e7f3ff',
    padding: '15px',
    borderRadius: '6px',
    marginTop: '20px',
    border: '1px solid #b3d7ff'
  },
  infoTitle: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '8px'
  },
  infoItem: {
    fontSize: '13px',
    color: '#666',
    marginBottom: '5px'
  }
};

// 添加 CSS 动画
const styleSheet = document.createElement('style');
styleSheet.textContent = `
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`;
document.head.appendChild(styleSheet);
;// CONCATENATED MODULE: ./src/sheet.ts
class Sheet {
  constructor(token, sheetId, sheetName) {
    this.token = token;
    this.sheetId = sheetId;
    this.sheetName = sheetName;
    this.gid = null;
  }

  /**
   * 从 Google Sheets URL 创建 Sheet 实例（静态工厂方法）
   * @param url Google Sheets URL
   * @param token 认证 token
   * @returns Sheet 实例
   */
  static async fromUrl(url, token) {
    const sheetId = Sheet.extractSheetId(url);
    const gid = Sheet.extractGid(url);
    if (!sheetId) {
      throw new Error('无法从 URL 中提取 Sheet ID');
    }

    // 获取 sheetName
    const sheetName = await Sheet.getSheetNameByGid(token, sheetId, gid);
    const sheet = new Sheet(token, sheetId, sheetName);
    sheet.gid = gid;
    return sheet;
  }
  static async getToken() {
    return new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({
        interactive: true
      }, token => {
        if (chrome.runtime.lastError) reject(chrome.runtime.lastError);else resolve(token);
      });
    });
  }
  static extractSheetId(url) {
    const match = url.match(/\/d\/([a-zA-Z0-9-_]+)/);
    return match ? match[1] : null;
  }
  static extractGid(url) {
    const match = url.match(/[#&]gid=([0-9]+)/);
    return match ? match[1] : null;
  }
  static async getSheetNames(token, sheetId) {
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}`;
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    const json = await res.json();
    return json.sheets;
  }
  static async getSheetNameByGid(token, sheetId, gid) {
    const sheets = await Sheet.getSheetNames(token, sheetId);
    if (gid) {
      const sheet = sheets.find(s => s.properties.sheetId.toString() === gid);
      if (sheet) return sheet.properties.title;
    }
    // 如果找不到对应的gid或gid为null，返回第一个sheet的名称
    return sheets[0].properties.title;
  }
  async readSheet() {
    let valueRenderOption = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'FORMATTED_VALUE';
    const sheetUrl = `https://sheets.googleapis.com/v4/spreadsheets/${this.sheetId}/values/${this.sheetName}?valueRenderOption=${valueRenderOption}`;
    const res = await fetch(sheetUrl, {
      headers: {
        Authorization: `Bearer ${this.token}`
      }
    });
    if (!res.ok) {
      const errorText = await res.text();
      throw new Error(`读取 Sheet 失败 (${res.status}): ${errorText}`);
    }
    const json = await res.json();
    return json.values;
  }
  async writeSheet(values) {
    let position = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'A1';
    const sheetUrl = `https://sheets.googleapis.com/v4/spreadsheets/${this.sheetId}/values/${this.sheetName}!${position}?valueInputOption=USER_ENTERED`;
    const res = await fetch(sheetUrl, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        values
      })
    });
    return res.json();
  }

  // 插入行或列
  async insertDimension(dimension, startIndex, endIndex, sheetId) {
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${this.sheetId}:batchUpdate`;

    // 使用传入的 sheetId 或 this.gid，如果都没有则使用 0（第一个 sheet）
    const targetSheetId = sheetId ?? (this.gid ? parseInt(this.gid) : 0);
    const request = {
      requests: [{
        insertDimension: {
          range: {
            sheetId: targetSheetId,
            dimension,
            startIndex,
            endIndex
          },
          inheritFromBefore: true
        }
      }, {
        addDimensionGroup: {
          range: {
            sheetId: targetSheetId,
            dimension,
            startIndex,
            endIndex
          }
        }
      }]
    };
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(request)
    });
    if (!res.ok) {
      const error = await res.json();
      throw new Error(`插入维度失败: ${error.error?.message || '未知错误'}`);
    }
  }

  /**
   * 读取配置表数据
   * @param sheetName 配置表名称
   * @returns 配置表数据
   */
  async readConfigSheet() {
    let configSheetName = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
    if (!configSheetName) configSheetName = this.sheetName + '_config';
    try {
      const sheetUrl = `https://sheets.googleapis.com/v4/spreadsheets/${this.sheetId}/values/${configSheetName}`;
      const res = await fetch(sheetUrl, {
        headers: {
          Authorization: `Bearer ${this.token}`
        }
      });
      const json = await res.json();
      return json.values;
    } catch (error) {
      console.error('读取配置表失败:', error);
      throw error;
    }
  }

  /**
   * 获取表格的第一行作为表头
   * @returns 表头数组
   */
  async getHeaders() {
    const values = await this.readSheet();
    if (!values || values.length === 0) {
      throw new Error('表格为空');
    }
    return values[0];
  }
  getSheetName() {
    return this.sheetName;
  }
}
;// CONCATENATED MODULE: ./src/scheduled-messages/ScheduledMessageService.ts
/**
 * 定时消息数据服务层
 * 封装 Google Sheets API 的 CRUD 操作
 * 
 * 核心特性：动态列映射
 * ========================
 * 本服务支持动态识别 Google Sheet 的列位置，用户可以随意调整列的顺序：
 * 
 * 1. 读取机制：
 *    - 首先读取 header 行（第一行）获取列名
 *    - 根据 header 的列名和索引创建映射关系
 *    - 解析数据行时，通过列名从对应位置读取值
 * 
 * 2. 写入机制：
 *    - 获取当前的 header 顺序
 *    - 根据 header 顺序动态生成行数据数组
 *    - 自动适配不同的列顺序，确保数据写入正确的列
 * 
 * 3. 缓存优化：
 *    - header 结构会被缓存，避免重复读取
 *    - 同步数据时会清除缓存，确保获取最新的列结构
 * 
 * 4. 向后兼容：
 *    - 支持旧版本的固定列顺序
 *    - 支持用户自定义的列顺序
 *    - 列名保持不变，只是位置可以调整
 * 
 * 使用示例：
 * ```typescript
 * const service = new ScheduledMessageService(token);
 * 
 * // 读取数据 - 自动适配任何列顺序
 * const messages = await service.getAllMessages();
 * 
 * // 创建消息 - 自动根据当前列顺序写入
 * await service.createMessage({
 *   Topic: '测试消息',
 *   Content: '内容',
 *   ...
 * });
 * ```
 */


class ScheduledMessageService {
  // 缓存 header 顺序

  constructor(token) {
    this.config = null;
    this.headerCache = null;
    this.token = token;
  }

  /**
   * 刷新 token
   */
  async refreshToken() {
    return new Promise((resolve, reject) => {
      // 先移除缓存的 token
      chrome.identity.getAuthToken({
        interactive: false
      }, cachedToken => {
        if (cachedToken) {
          chrome.identity.removeCachedAuthToken({
            token: cachedToken
          }, () => {
            // 获取新 token
            chrome.identity.getAuthToken({
              interactive: true
            }, newToken => {
              if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
              } else if (newToken) {
                this.token = newToken;
                resolve(newToken);
              } else {
                reject(new Error('无法获取新 token'));
              }
            });
          });
        } else {
          // 直接获取新 token
          chrome.identity.getAuthToken({
            interactive: true
          }, newToken => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else if (newToken) {
              this.token = newToken;
              resolve(newToken);
            } else {
              reject(new Error('无法获取新 token'));
            }
          });
        }
      });
    });
  }

  /**
   * 执行带自动重试的操作
   * 如果遇到 401 错误，自动刷新 token 并重试一次
   */
  async withTokenRetry(operation) {
    try {
      return await operation();
    } catch (error) {
      const is401Error = error.message?.includes('401') || error.message?.includes('Unauthorized') || error.message?.includes('Invalid Credentials');
      if (is401Error) {
        console.log('🔄 检测到 401 错误，尝试刷新 token...');
        await this.refreshToken();
        console.log('✅ Token 刷新成功，重试请求...');
        return await operation();
      }
      throw error;
    }
  }

  /**
   * 加载配置
   */
  async loadConfig() {
    const result = await chrome.storage.local.get(['scheduledMessagesConfig']);
    this.config = result.scheduledMessagesConfig || null;
    return this.config;
  }

  /**
   * 获取所有消息
   */
  async getAllMessages() {
    if (!this.config) {
      await this.loadConfig();
    }
    if (!this.config) {
      throw new Error('未找到配置，请先初始化系统');
    }
    return await this.withTokenRetry(async () => {
      const sheet = new Sheet(this.token, this.config.sheetId, 'Messages');
      const data = await sheet.readSheet();
      if (!data || data.length === 0) {
        return [];
      }
      const headers = data[0];
      const messages = [];
      let hasUpdates = false;
      for (let i = 1; i < data.length; i++) {
        const row = data[i];
        const message = this.parseRowToMessage(row, headers);
        if (message) {
          // 如果没有 ID，自动生成一个
          if (!message.ID) {
            message.ID = `msg_${Date.now()}_${i}`;
            hasUpdates = true;
            console.log(`自动生成 ID: ${message.ID} (行 ${i + 1})`);
          }

          // 自动判断消息类型（如果没有 Type 字段）
          if (!message.Type) {
            message.Type = this.determineMessageType(message);
          }

          // 如果有更新，写回 Sheet
          if (hasUpdates) {
            const row = await this.messageToRow(message);
            await this.updateRow(i + 1, row);
          }
          messages.push(message);
        }
      }
      if (hasUpdates) {
        console.log('✅ 已自动为缺失 ID 的消息生成 ID');
      }
      return messages;
    });
  }

  /**
   * 根据 ID 获取消息
   */
  async getMessageById(id) {
    const messages = await this.getAllMessages();
    return messages.find(msg => msg.ID === id) || null;
  }

  /**
   * 自动判断消息类型
   */
  determineMessageType(message) {
    // 如果填写了 Repeat_Every 和 Repeat_Unit，判断为 Periodic
    if (message.Repeat_Every && message.Repeat_Unit) {
      return 'Periodic';
    }

    // 如果填写了 Schedule_Time，判断为 Hourly
    if (message.Schedule_Time && message.Schedule_Time.trim()) {
      return 'Hourly';
    }

    // 否则为 Daily（每日早上9点执行）
    return 'Daily';
  }

  /**
   * 创建新消息
   */
  async createMessage(formData) {
    if (!this.config) {
      await this.loadConfig();
    }
    if (!this.config) {
      throw new Error('未找到配置，请先初始化系统');
    }
    const message = {
      ID: `msg_${Date.now()}`,
      ...formData,
      Schedule_Time: formData.Schedule_Time || '',
      // 留空表示每日9点
      Status: 'Active',
      Exec_Count: 0,
      Exec_Log: '待执行'
    };

    // 自动判断类型
    message.Type = this.determineMessageType(message);

    // 计算下次执行时间
    message.Next_Exec = this.calculateNextExecution(message);

    // 添加到 Sheet
    const row = await this.messageToRow(message);
    await this.appendRow(row);
    return message;
  }

  /**
   * 更新消息
   */
  async updateMessage(id, updates) {
    const messages = await this.getAllMessages();
    const index = messages.findIndex(msg => msg.ID === id);
    if (index === -1) {
      throw new Error(`未找到消息: ${id}`);
    }
    const updatedMessage = {
      ...messages[index],
      ...updates
    };

    // 重新计算下次执行时间
    if (updates.Schedule_Date || updates.Schedule_Time || updates.Type || updates.Repeat_Every) {
      updatedMessage.Next_Exec = this.calculateNextExecution(updatedMessage);
    }

    // 更新到 Sheet（行号 = 索引 + 2，因为有表头且从1开始）
    const row = await this.messageToRow(updatedMessage);
    await this.updateRow(index + 2, row);
    return updatedMessage;
  }

  /**
   * 删除消息
   */
  async deleteMessage(id) {
    const messages = await this.getAllMessages();
    const index = messages.findIndex(msg => msg.ID === id);
    if (index === -1) {
      throw new Error(`未找到消息: ${id}`);
    }

    // 删除行（行号 = 索引 + 2）
    await this.deleteRow(index + 2);
  }

  /**
   * 删除所有已完成的消息（Status = 'Done'）
   * @returns {Promise<number>} 删除的消息数量
   */
  async deleteCompletedMessages() {
    const messages = await this.getAllMessages();
    const completedMessages = messages.filter(msg => msg.Status === 'Done');
    if (completedMessages.length === 0) {
      return 0;
    }

    // 从后往前删除，避免索引变化影响
    const sortedIndices = completedMessages.map(msg => messages.findIndex(m => m.ID === msg.ID)).sort((a, b) => b - a);
    for (const index of sortedIndices) {
      await this.deleteRow(index + 2);
    }
    return completedMessages.length;
  }

  /**
   * 暂停/恢复消息
   */
  async toggleMessageStatus(id) {
    const message = await this.getMessageById(id);
    if (!message) {
      throw new Error(`未找到消息: ${id}`);
    }
    const newStatus = message.Status === 'Active' ? 'Paused' : 'Active';
    return await this.updateMessage(id, {
      Status: newStatus
    });
  }

  /**
   * 获取统计信息
   */
  async getStatistics() {
    const messages = await this.getAllMessages();
    const today = new Date().toISOString().split('T')[0];
    return {
      total: messages.length,
      active: messages.filter(m => m.Status === 'Active').length,
      paused: messages.filter(m => m.Status === 'Paused').length,
      completed: messages.filter(m => m.Status === 'Completed').length,
      done: messages.filter(m => m.Status === 'Done').length,
      executedToday: messages.filter(m => m.Last_Exec && m.Last_Exec.startsWith(today)).length
    };
  }

  /**
   * 同步数据（从 Sheet 刷新）
   */
  async syncFromSheet() {
    // 清除 header 缓存，确保获取最新的列结构
    this.clearHeaderCache();
    // 直接返回最新数据即可
    return await this.getAllMessages();
  }

  // ========== 私有方法 ==========

  /**
   * 获取 Sheet 的 Header（带缓存）
   */
  async getHeaders() {
    if (this.headerCache) {
      return this.headerCache;
    }
    if (!this.config) {
      await this.loadConfig();
    }
    if (!this.config) {
      throw new Error('未找到配置，请先初始化系统');
    }
    return await this.withTokenRetry(async () => {
      const sheet = new Sheet(this.token, this.config.sheetId, 'Messages');
      const data = await sheet.readSheet();
      if (!data || data.length === 0) {
        throw new Error('无法读取 Sheet 数据');
      }
      this.headerCache = data[0];
      return this.headerCache;
    });
  }

  /**
   * 清除 header 缓存（在 Sheet 结构可能改变时调用）
   */
  clearHeaderCache() {
    this.headerCache = null;
  }

  /**
   * 解析行数据为消息对象
   */
  parseRowToMessage(row, headers) {
    if (!row || row.length === 0) return null;
    const message = {};
    headers.forEach((header, index) => {
      message[header] = row[index] || '';
    });
    return message;
  }

  /**
   * 将消息对象转换为行数据（根据 header 顺序动态生成）
   */
  async messageToRow(message) {
    const headers = await this.getHeaders();
    const row = [];

    // 根据 header 顺序构建行数据
    for (const header of headers) {
      const value = message[header];

      // 处理不同类型的字段
      if (value === undefined || value === null) {
        row.push('');
      } else if (typeof value === 'number') {
        row.push(value);
      } else {
        row.push(String(value));
      }
    }
    return row;
  }

  /**
   * 追加行
   */
  async appendRow(row) {
    if (!this.config) {
      throw new Error('未找到配置');
    }
    await this.withTokenRetry(async () => {
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${this.config.sheetId}/values/Messages:append?valueInputOption=USER_ENTERED`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          values: [row]
        })
      });
      if (!response.ok) {
        const error = await response.text();
        throw new Error(`添加行失败 (${response.status}): ${error}`);
      }
    });
  }

  /**
   * 更新行（根据 header 数量动态确定列范围）
   */
  async updateRow(rowIndex, row) {
    if (!this.config) {
      throw new Error('未找到配置');
    }
    await this.withTokenRetry(async () => {
      // 获取 header 以确定列数
      const headers = await this.getHeaders();
      const columnCount = headers.length;

      // 将列数转换为字母（A, B, C, ... Z, AA, AB, ...）
      const endColumn = this.numberToColumn(columnCount);
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${this.config.sheetId}/values/Messages!A${rowIndex}:${endColumn}${rowIndex}?valueInputOption=USER_ENTERED`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          values: [row]
        })
      });
      if (!response.ok) {
        const error = await response.text();
        throw new Error(`更新行失败 (${response.status}): ${error}`);
      }
    });
  }

  /**
   * 将数字转换为 Excel 列字母（1 -> A, 2 -> B, 26 -> Z, 27 -> AA）
   */
  numberToColumn(num) {
    let column = '';
    while (num > 0) {
      const remainder = (num - 1) % 26;
      column = String.fromCharCode(65 + remainder) + column;
      num = Math.floor((num - 1) / 26);
    }
    return column;
  }

  /**
   * 获取 Messages Sheet 的 sheetId
   */
  async getMessagesSheetId() {
    // 如果配置中有 messagesSheetId，直接使用
    if (this.config?.messagesSheetId !== undefined) {
      return this.config.messagesSheetId;
    }

    // 否则动态获取
    if (!this.config) {
      throw new Error('未找到配置');
    }
    return await this.withTokenRetry(async () => {
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${this.config.sheetId}?fields=sheets.properties`, {
        headers: {
          'Authorization': `Bearer ${this.token}`
        }
      });
      if (!response.ok) {
        throw new Error(`获取 Sheet 信息失败: ${response.status}`);
      }
      const data = await response.json();
      const messagesSheet = data.sheets.find(s => s.properties.title === 'Messages');
      if (!messagesSheet) {
        throw new Error('未找到 Messages 工作表');
      }
      const sheetId = messagesSheet.properties.sheetId;

      // 缓存到配置中
      this.config.messagesSheetId = sheetId;
      await chrome.storage.local.set({
        scheduledMessagesConfig: this.config
      });
      return sheetId;
    });
  }

  /**
   * 删除行
   */
  async deleteRow(rowIndex) {
    if (!this.config) {
      throw new Error('未找到配置');
    }

    // 获取正确的 sheetId
    const messagesSheetId = await this.getMessagesSheetId();
    await this.withTokenRetry(async () => {
      // 使用 batchUpdate 删除行
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${this.config.sheetId}:batchUpdate`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          requests: [{
            deleteDimension: {
              range: {
                sheetId: messagesSheetId,
                // 使用正确的 sheetId
                dimension: 'ROWS',
                startIndex: rowIndex - 1,
                endIndex: rowIndex
              }
            }
          }]
        })
      });
      if (!response.ok) {
        const error = await response.text();
        throw new Error(`删除行失败 (${response.status}): ${error}`);
      }
    });
  }

  /**
   * 计算下次执行时间
   */
  calculateNextExecution(message) {
    if (message.Type === 'Daily') {
      // Daily 类型只执行一次
      return message.Schedule_Date;
    } else if (message.Type === 'Hourly') {
      // Hourly 类型只执行一次
      return `${message.Schedule_Date} ${message.Schedule_Time}`;
    } else if (message.Type === 'Periodic') {
      // 周期性任务
      if (!message.Schedule_Date || !message.Repeat_Every || !message.Repeat_Unit) {
        return '';
      }
      const startDate = new Date(message.Schedule_Date);
      const now = new Date();
      const nextDate = new Date(startDate);

      // 如果开始日期在未来，返回开始日期
      if (startDate > now) {
        return message.Schedule_Date;
      }

      // 计算下一次执行时间
      const every = message.Repeat_Every;
      const unit = message.Repeat_Unit;
      while (nextDate <= now) {
        if (unit === 'Day') {
          nextDate.setDate(nextDate.getDate() + every);
        } else if (unit === 'Week') {
          nextDate.setDate(nextDate.getDate() + 7 * every);
        } else if (unit === 'Month') {
          nextDate.setMonth(nextDate.getMonth() + every);
        } else if (unit === 'Year') {
          nextDate.setFullYear(nextDate.getFullYear() + every);
        }
      }
      return nextDate.toISOString().split('T')[0];
    }
    return '';
  }
}
;// CONCATENATED MODULE: ./src/scheduled-messages/ScheduledMessagesManager.tsx
/**
 * 定时消息管理主页面
 */






const ScheduledMessagesManager = () => {
  const [isInitialized, setIsInitialized] = (0,react.useState)(false);
  const [isLoading, setIsLoading] = (0,react.useState)(true);
  const [config, setConfig] = (0,react.useState)(null);
  const [messages, setMessages] = (0,react.useState)([]);
  const [statistics, setStatistics] = (0,react.useState)({
    total: 0,
    active: 0,
    paused: 0,
    completed: 0,
    done: 0,
    executedToday: 0
  });
  const [service, setService] = (0,react.useState)(null);
  const [showAddDialog, setShowAddDialog] = (0,react.useState)(false);
  const [isSubmitting, setIsSubmitting] = (0,react.useState)(false);
  const [showBotConfigDialog, setShowBotConfigDialog] = (0,react.useState)(false);
  const [botConfigured, setBotConfigured] = (0,react.useState)(false);
  const [showBotConfigWarning, setShowBotConfigWarning] = (0,react.useState)(false);
  const [filterSelfOnly, setFilterSelfOnly] = (0,react.useState)(false);
  const [currentUsername, setCurrentUsername] = (0,react.useState)('');
  (0,react.useEffect)(() => {
    initializeApp();
    getCurrentUserName();
  }, []);
  const initializeApp = async () => {
    try {
      // 检查是否已初始化
      const result = await chrome.storage.local.get(['scheduledMessagesConfig']);
      const savedConfig = result.scheduledMessagesConfig;
      if (savedConfig && savedConfig.sheetId) {
        setConfig(savedConfig);
        setIsInitialized(true);

        // 检查 Bot 是否已配置（从 scheduledMessagesConfig.botExecutor 读取）
        if (savedConfig.botExecutor && savedConfig.botExecutor.ruleId) {
          setBotConfigured(true);
        }

        // 获取 token 并加载数据
        const token = await getAuthToken();
        if (token) {
          const messageService = new ScheduledMessageService(token);
          setService(messageService);
          await loadMessages(messageService);

          // 加载消息后，验证 Bot 配置是否仍然有效
          await checkBotConfigValidity(savedConfig, messageService);
        }
      } else {
        setIsInitialized(false);
      }
    } catch (error) {
      console.error('初始化应用失败:', error);
    } finally {
      setIsLoading(false);
    }
  };
  const loadMessages = async messageService => {
    try {
      const msgs = await messageService.getAllMessages();
      setMessages(msgs);
      const stats = await messageService.getStatistics();
      setStatistics(stats);
    } catch (error) {
      console.error('加载消息失败:', error);
    }
  };
  const checkBotConfigValidity = async (savedConfig, messageService) => {
    try {
      // 如果没有配置 Bot，跳过检查
      if (!savedConfig.botExecutor || !savedConfig.botExecutor.ruleId) {
        return;
      }

      // 获取所有消息
      const msgs = await messageService.getAllMessages();

      // 检查是否有待推送的 Bot 消息（Active 状态 + Push_Method 为 Bot）
      const hasPendingBotMessages = msgs.some(msg => msg.Status === 'Active' && msg.Push_Method === 'Bot');

      // 如果没有待推送的 Bot 消息，不需要显示警告
      if (!hasPendingBotMessages) {
        setShowBotConfigWarning(false);
        return;
      }

      // 检查 Jira 规则是否还存在
      const {
        JiraAutomationService
      } = await __webpack_require__.e(/* import() */ 244).then(__webpack_require__.bind(__webpack_require__, 7244));
      const jiraService = new JiraAutomationService();
      const ruleExists = await jiraService.checkRuleExists({
        jiraUrl: savedConfig.botExecutor.jiraUrl,
        projectKey: savedConfig.botExecutor.projectKey
      }, savedConfig.botExecutor.ruleId);

      // 如果规则不存在且有待推送的 Bot 消息，显示警告
      if (!ruleExists) {
        console.warn('Bot 推送规则不存在，但有待推送的 Bot 消息');
        setShowBotConfigWarning(true);
        setBotConfigured(false);
      } else {
        setShowBotConfigWarning(false);
      }
    } catch (error) {
      console.error('检查 Bot 配置有效性失败:', error);
      // 检查失败不影响正常使用，不显示警告
    }
  };
  const handleInitializationComplete = result => {
    if (result.success) {
      // 刷新页面重新加载
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    }
  };
  const handleSync = async () => {
    if (!service) return;
    setIsLoading(true);
    try {
      await loadMessages(service);
    } finally {
      setIsLoading(false);
    }
  };
  const handleOpenSheet = () => {
    if (config && config.sheetUrl) {
      window.open(config.sheetUrl, '_blank');
    }
  };
  const handleAddMessage = () => {
    setShowAddDialog(true);
  };
  const handleDeleteMessage = async (id, topic) => {
    if (!service) return;
    if (!confirm(`确定要删除消息 "${topic}" 吗？此操作无法撤销。`)) {
      return;
    }
    setIsLoading(true);
    try {
      await service.deleteMessage(id);
      await loadMessages(service);
      alert('消息已删除');
    } catch (error) {
      console.error('删除消息失败:', error);
      alert(`删除失败: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };
  const handleToggleStatus = async message => {
    if (!service) return;
    setIsLoading(true);
    try {
      await service.toggleMessageStatus(message.ID);
      await loadMessages(service);
    } catch (error) {
      console.error('切换状态失败:', error);
      alert(`切换状态失败: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };
  const handleSubmitNewMessage = async formData => {
    if (!service) return;
    setIsSubmitting(true);
    try {
      await service.createMessage(formData);
      await loadMessages(service);
      setShowAddDialog(false);
      alert('消息创建成功！');
    } catch (error) {
      console.error('创建消息失败:', error);
      alert(`创建失败: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleCleanupCompleted = async () => {
    if (!service) return;
    if (!confirm(`确定要删除所有已完成的消息吗？\n共 ${statistics.done} 条消息将被永久删除。`)) {
      return;
    }
    try {
      const deletedCount = await service.deleteCompletedMessages();
      await loadMessages(service);
      alert(`成功清理 ${deletedCount} 条已完成的消息！`);
    } catch (error) {
      console.error('清理已完成消息失败:', error);
      alert(`清理失败: ${error.message}`);
    }
  };
  const getAuthToken = () => {
    return new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({
        interactive: true
      }, token => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(token || '');
        }
      });
    });
  };
  const getCurrentUserName = async () => {
    try {
      const token = await getAuthToken();
      const response = await fetch('https://www.googleapis.com/oauth2/v1/userinfo?alt=json', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (response.ok) {
        const userInfo = await response.json();
        // userInfo.email 格式如：esone.qiu@ringcentral.com
        const email = userInfo.email || '';
        const username = email.split('@')[0]; // 提取 esone.qiu
        setCurrentUsername(username);
      }
    } catch (error) {
      console.error('获取用户信息失败:', error);
    }
  };

  // 频率格式化函数
  const formatFrequency = message => {
    // 判断是否有重复规则
    if (!message.Repeat_Every || !message.Repeat_Unit) {
      // 一次性任务
      return '推送一次';
    }
    const every = message.Repeat_Every;
    const unit = message.Repeat_Unit;
    const scheduleDate = message.Schedule_Date;
    const scheduleTime = message.Schedule_Time;

    // 根据单位构建频率描述
    let freq = '';
    if (unit === 'Day') {
      if (every === 1) {
        freq = '每天';
      } else {
        freq = `每 ${every} 天`;
      }
    } else if (unit === 'Week') {
      if (every === 1) {
        // 解析 Schedule_Date 获取星期几
        const date = new Date(scheduleDate);
        const weekdays = ['日', '一', '二', '三', '四', '五', '六'];
        const weekday = weekdays[date.getDay()];
        freq = `每周${weekday}`;
      } else {
        freq = `每 ${every} 周`;
      }
    } else if (unit === 'Month') {
      // 从 Schedule_Date 提取日期
      const day = new Date(scheduleDate).getDate();
      if (every === 1) {
        freq = `每月 ${day} 号`;
      } else {
        freq = `每 ${every} 月的 ${day} 号`;
      }
    } else if (unit === 'Year') {
      if (every === 1) {
        const date = new Date(scheduleDate);
        const month = date.getMonth() + 1;
        const day = date.getDate();
        freq = `每年 ${month}/${day}`;
      } else {
        freq = `每 ${every} 年`;
      }
    }

    // 添加时间
    if (scheduleTime) {
      freq += ` ${scheduleTime}`;
    } else {
      freq += ' 早上';
    }
    return freq;
  };

  // 判断消息是否只发给自己
  const isSelfOnlyMessage = message => {
    if (!message.Glip_User_Name || !currentUsername) {
      return false;
    }

    // Glip_User_Name 格式：esone.qiu 或 esone.qiu+john.doe
    const usernames = message.Glip_User_Name.split('+');

    // 只有一个人且是自己
    return usernames.length === 1 && usernames[0] === currentUsername;
  };

  // 根据 Push_Method 显示类型
  const getMessageTypeDisplay = message => {
    // 特殊逻辑：sync.service 显示为系统消息
    if (message.Glip_User_Name === 'sync.service') {
      return '系统消息';
    }
    switch (message.Push_Method) {
      case 'AI':
        return 'AI Report';
      case 'AsMe':
        return '假装我发的';
      case 'Bot':
        return 'Bot 定时';
      default:
        return message.Push_Method;
    }
  };

  // 格式化"发给"列的显示
  const formatRecipient = message => {
    // 优先显示用户名
    if (message.Glip_User_Name && message.Glip_User_Name.trim()) {
      const usernames = message.Glip_User_Name.split('+');
      const formattedNames = usernames.map(name => {
        // esone.qiu -> Esone
        const parts = name.split('.');
        if (parts.length > 0) {
          return parts[0].charAt(0).toUpperCase() + parts[0].slice(1);
        }
        return name;
      });
      return formattedNames.join(', ');
    }

    // 否则显示群组 ID
    if (message.Glip_Team_ID && message.Glip_Team_ID.trim()) {
      return message.Glip_Team_ID;
    }
    return '-';
  };
  if (isLoading) {
    return /*#__PURE__*/react.createElement("div", {
      style: ScheduledMessagesManager_styles.loadingContainer
    }, /*#__PURE__*/react.createElement("div", {
      style: ScheduledMessagesManager_styles.spinner
    }), /*#__PURE__*/react.createElement("p", null, "\u52A0\u8F7D\u4E2D..."));
  }
  if (!isInitialized) {
    return /*#__PURE__*/react.createElement(OneClickSetup, {
      onComplete: handleInitializationComplete
    });
  }
  return /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.container
  }, /*#__PURE__*/react.createElement("header", {
    style: ScheduledMessagesManager_styles.header
  }, /*#__PURE__*/react.createElement("h1", {
    style: ScheduledMessagesManager_styles.title
  }, "\u23F0 \u5B9A\u65F6\u6D88\u606F\u7BA1\u7406"), /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.headerActions
  }, /*#__PURE__*/react.createElement("button", {
    style: ScheduledMessagesManager_styles.addButton,
    onClick: handleAddMessage,
    title: "\u65B0\u589E\u6D88\u606F"
  }, "\u2795 \u65B0\u589E"), /*#__PURE__*/react.createElement("button", {
    style: ScheduledMessagesManager_styles.syncButton,
    onClick: handleSync,
    title: "\u540C\u6B65\u6570\u636E"
  }, "\uD83D\uDD04 \u540C\u6B65"), /*#__PURE__*/react.createElement("button", {
    style: ScheduledMessagesManager_styles.configButton,
    onClick: handleOpenSheet,
    title: "\u6253\u5F00 Sheet"
  }, "\uD83D\uDCCA \u6253\u5F00 Sheet"))), showBotConfigWarning && /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.warningBanner
  }, /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.warningContent
  }, /*#__PURE__*/react.createElement("span", {
    style: ScheduledMessagesManager_styles.warningIcon
  }, "\u26A0\uFE0F"), /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.warningText
  }, /*#__PURE__*/react.createElement("strong", null, "Bot \u63A8\u9001\u914D\u7F6E\u5931\u6548"), /*#__PURE__*/react.createElement("p", {
    style: ScheduledMessagesManager_styles.warningDescription
  }, "\u68C0\u6D4B\u5230\u60A8\u6709\u5F85\u63A8\u9001\u7684 Bot \u6D88\u606F\uFF0C\u4F46 Jira Automation \u89C4\u5219\u5DF2\u4E0D\u5B58\u5728\uFF0C\u9700\u8981\u91CD\u65B0\u914D\u7F6E\u3002"))), /*#__PURE__*/react.createElement("button", {
    style: ScheduledMessagesManager_styles.warningButton,
    onClick: () => setShowBotConfigDialog(true)
  }, "\uD83D\uDD27 \u91CD\u65B0\u914D\u7F6E")), /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.statusBar
  }, /*#__PURE__*/react.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '15px',
      flex: 1
    }
  }, /*#__PURE__*/react.createElement("span", {
    style: ScheduledMessagesManager_styles.statusItem
  }, "\uD83D\uDCCA \u72B6\u6001\uFF1A", /*#__PURE__*/react.createElement("strong", null, "\u5DF2\u521D\u59CB\u5316")), /*#__PURE__*/react.createElement("span", {
    style: ScheduledMessagesManager_styles.statusItem
  }, "\u603B\u8BA1: ", /*#__PURE__*/react.createElement("strong", null, statistics.total)), /*#__PURE__*/react.createElement("span", {
    style: ScheduledMessagesManager_styles.statusItem
  }, "\u6D3B\u8DC3: ", /*#__PURE__*/react.createElement("strong", {
    style: {
      color: '#28a745'
    }
  }, statistics.active)), /*#__PURE__*/react.createElement("span", {
    style: ScheduledMessagesManager_styles.statusItem
  }, "\u6682\u505C: ", /*#__PURE__*/react.createElement("strong", {
    style: {
      color: '#ffc107'
    }
  }, statistics.paused)), /*#__PURE__*/react.createElement("span", {
    style: ScheduledMessagesManager_styles.statusItem
  }, "\u5DF2\u5B8C\u6210: ", /*#__PURE__*/react.createElement("strong", {
    style: {
      color: '#6c757d'
    }
  }, statistics.done)), /*#__PURE__*/react.createElement("span", {
    style: ScheduledMessagesManager_styles.statusItem
  }, "\u4ECA\u65E5\u5DF2\u6267\u884C: ", /*#__PURE__*/react.createElement("strong", {
    style: {
      color: '#007bff'
    }
  }, statistics.executedToday))), /*#__PURE__*/react.createElement("div", {
    style: {
      display: 'flex',
      gap: '10px',
      alignItems: 'center'
    }
  }, statistics.done > 0 && /*#__PURE__*/react.createElement("button", {
    onClick: handleCleanupCompleted,
    style: {
      padding: '6px 12px',
      backgroundColor: '#dc3545',
      color: 'white',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '13px',
      fontWeight: 500
    },
    title: `清理 ${statistics.done} 条已完成的消息`
  }, "\uD83D\uDDD1\uFE0F \u6E05\u7406\u5DF2\u5B8C\u6210 (", statistics.done, ")"), /*#__PURE__*/react.createElement("label", {
    style: {
      display: 'flex',
      alignItems: 'center',
      cursor: 'pointer',
      fontSize: '13px',
      fontWeight: 500,
      color: '#666',
      userSelect: 'none'
    }
  }, /*#__PURE__*/react.createElement("input", {
    type: "checkbox",
    checked: filterSelfOnly,
    onChange: e => setFilterSelfOnly(e.target.checked),
    style: {
      marginRight: '6px',
      cursor: 'pointer'
    }
  }), "\u8FC7\u6EE4\u6389\u4EC5\u53D1\u6211\u7684"))), /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.content
  }, messages.length === 0 ? /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.emptyState
  }, /*#__PURE__*/react.createElement("p", {
    style: ScheduledMessagesManager_styles.emptyText
  }, "\u6682\u65E0\u5B9A\u65F6\u6D88\u606F"), /*#__PURE__*/react.createElement("p", {
    style: ScheduledMessagesManager_styles.emptyHint
  }, "\u8BF7\u5728 ", /*#__PURE__*/react.createElement("a", {
    href: "#",
    onClick: handleOpenSheet
  }, "Google Sheet"), " \u4E2D\u6DFB\u52A0\u6D88\u606F")) : /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.messageList
  }, /*#__PURE__*/react.createElement("table", {
    style: ScheduledMessagesManager_styles.table
  }, /*#__PURE__*/react.createElement("thead", null, /*#__PURE__*/react.createElement("tr", null, /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u7C7B\u578B"), /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u4E3B\u9898"), /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u53D1\u7ED9"), /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u9891\u7387"), /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u4E0B\u6B21\u6267\u884C"), /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u5DF2\u53D1"), /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u72B6\u6001"), /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u64CD\u4F5C"))), /*#__PURE__*/react.createElement("tbody", null, messages.filter(message => {
    // 应用过滤条件
    if (filterSelfOnly && isSelfOnlyMessage(message)) {
      return false;
    }
    return true;
  }).map(message => {
    const displayTitle = message.Topic || (message.Content.length > 30 ? message.Content.substring(0, 30) + '...' : message.Content);
    return /*#__PURE__*/react.createElement("tr", {
      key: message.ID,
      style: ScheduledMessagesManager_styles.tr
    }, /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, /*#__PURE__*/react.createElement("span", {
      style: getTypeStyle(message.Push_Method)
    }, getMessageTypeDisplay(message))), /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td,
      title: message.Content
    }, /*#__PURE__*/react.createElement("span", {
      style: ScheduledMessagesManager_styles.topicText
    }, displayTitle)), /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, formatRecipient(message)), /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, formatFrequency(message)), /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, message.Next_Exec || '-'), /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, message.Exec_Count || 0, " \u6B21"), /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, /*#__PURE__*/react.createElement("span", {
      style: {
        ...getStatusStyle(message.Status),
        cursor: 'pointer'
      },
      onClick: () => handleToggleStatus(message),
      title: `点击切换为${message.Status === 'Active' ? '禁用' : '启用'}`
    }, message.Status)), /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, /*#__PURE__*/react.createElement("button", {
      style: ScheduledMessagesManager_styles.deleteButton,
      onClick: () => handleDeleteMessage(message.ID, displayTitle),
      title: "\u5220\u9664\u6D88\u606F"
    }, "\uD83D\uDDD1\uFE0F")));
  }))))), /*#__PURE__*/react.createElement("footer", {
    style: ScheduledMessagesManager_styles.footer
  }, /*#__PURE__*/react.createElement("p", {
    style: ScheduledMessagesManager_styles.footerText
  }, "\u63D0\u793A\uFF1A\u7F16\u8F91\u6D88\u606F\u8BF7\u5728 ", /*#__PURE__*/react.createElement("a", {
    href: "#",
    onClick: handleOpenSheet
  }, "Google Sheet"), " \u4E2D\u64CD\u4F5C")), showAddDialog && /*#__PURE__*/react.createElement(AddMessageDialog, {
    onSubmit: handleSubmitNewMessage,
    onCancel: () => setShowAddDialog(false),
    isSubmitting: isSubmitting,
    botConfigured: botConfigured,
    onConfigureBot: () => setShowBotConfigDialog(true)
  }), showBotConfigDialog && config && /*#__PURE__*/react.createElement(BotConfigDialog, {
    config: config,
    onClose: () => setShowBotConfigDialog(false),
    onSuccess: () => {
      setBotConfigured(true);
      setShowBotConfigWarning(false);
      setShowBotConfigDialog(false);
      alert('Bot 推送配置成功！');
    }
  }));
};

// 用户名格式化工具函数
const formatUserName = {
  /**
   * 验证用户名格式（必须包含 first name 和 last name）
   */
  validate: input => {
    const trimmed = input.trim();
    if (!trimmed) return false;

    // 支持两种格式：
    // 1. "Esone Qiu" - 空格分隔
    // 2. "esone.qiu" - 点号分隔
    const parts = trimmed.includes('.') ? trimmed.split('.') : trimmed.split(/\s+/);

    // 必须至少有两个部分（first name 和 last name）
    return parts.length >= 2 && parts.every(p => p.length > 0);
  },
  /**
   * 转换为显示格式："Esone Qiu"
   */
  toDisplayFormat: input => {
    const trimmed = input.trim().toLowerCase();

    // 分割：支持空格或点号
    const parts = trimmed.includes('.') ? trimmed.split('.') : trimmed.split(/\s+/);

    // 首字母大写
    return parts.map(part => part.charAt(0).toUpperCase() + part.slice(1)).join(' ');
  },
  /**
   * 转换为存储格式："esone.qiu"
   */
  toStorageFormat: input => {
    const trimmed = input.trim().toLowerCase();

    // 分割：支持空格或点号
    const parts = trimmed.includes('.') ? trimmed.split('.') : trimmed.split(/\s+/);

    // 用点号连接
    return parts.join('.');
  },
  /**
   * 将多个用户名转换为存储格式（用+连接，用于 Glip_User_Name）
   */
  joinForStorage: displayNames => {
    return displayNames.map(name => formatUserName.toStorageFormat(name)).join('+');
  },
  /**
   * 将多个用户名转换为 mentionList 格式（用,连接，用于 AI Report）
   */
  joinForMentionList: displayNames => {
    return displayNames.map(name => formatUserName.toStorageFormat(name)).join(',');
  }
};

// Tags 输入框组件
const TagsInput = _ref => {
  let {
    tags,
    onChange,
    placeholder,
    maxTags,
    disabled
  } = _ref;
  const [inputValue, setInputValue] = (0,react.useState)('');
  const [error, setError] = (0,react.useState)('');
  const handleKeyDown = e => {
    if (e.key === 'Enter' && inputValue.trim()) {
      e.preventDefault();

      // 验证格式
      if (!formatUserName.validate(inputValue)) {
        setError('请输入完整的姓名（如：Esone Qiu 或 esone.qiu）');
        return;
      }
      if (maxTags && tags.length >= maxTags) {
        setError(`最多只能添加 ${maxTags} 个`);
        return;
      }

      // 转换为显示格式
      const displayName = formatUserName.toDisplayFormat(inputValue);

      // 检查是否已存在（避免重复）
      if (tags.includes(displayName)) {
        setError('该用户已添加');
        return;
      }
      onChange([...tags, displayName]);
      setInputValue('');
      setError('');
    } else if (e.key === 'Backspace' && !inputValue && tags.length > 0) {
      onChange(tags.slice(0, -1));
      setError('');
    }
  };
  const handleInputChange = e => {
    setInputValue(e.target.value);
    if (error) setError(''); // 清除错误提示
  };
  const removeTag = indexToRemove => {
    onChange(tags.filter((_, index) => index !== indexToRemove));
    setError('');
  };
  return /*#__PURE__*/react.createElement("div", null, /*#__PURE__*/react.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '8px',
      padding: '8px',
      border: `1px solid ${error ? '#dc3545' : '#ddd'}`,
      borderRadius: '4px',
      minHeight: '42px',
      backgroundColor: disabled ? '#f5f5f5' : '#fff'
    }
  }, tags.map((tag, index) => /*#__PURE__*/react.createElement("span", {
    key: index,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      padding: '4px 8px',
      backgroundColor: '#007bff',
      color: '#fff',
      borderRadius: '4px',
      fontSize: '14px'
    }
  }, tag, /*#__PURE__*/react.createElement("button", {
    onClick: () => removeTag(index),
    disabled: disabled,
    style: {
      marginLeft: '6px',
      background: 'none',
      border: 'none',
      color: '#fff',
      cursor: 'pointer',
      fontSize: '16px',
      padding: '0'
    }
  }, "\xD7"))), /*#__PURE__*/react.createElement("input", {
    type: "text",
    value: inputValue,
    onChange: handleInputChange,
    onKeyDown: handleKeyDown,
    placeholder: tags.length === 0 ? placeholder : '',
    disabled: disabled,
    style: {
      flex: 1,
      border: 'none',
      outline: 'none',
      minWidth: '120px',
      fontSize: '14px',
      backgroundColor: 'transparent'
    }
  })), error && /*#__PURE__*/react.createElement("div", {
    style: {
      color: '#dc3545',
      fontSize: '12px',
      marginTop: '4px'
    }
  }, error));
};

// AI Header 选项
const AVAILABLE_AI_HEADERS = [{
  value: 'Authorization',
  label: 'Authorization (认证)',
  placeholder: 'Bearer token 或 Basic xxx'
}, {
  value: 'Content-Type',
  label: 'Content-Type (内容类型)',
  placeholder: 'application/json'
}, {
  value: 'Accept',
  label: 'Accept (接受类型)',
  placeholder: 'application/json'
}, {
  value: 'X-API-Key',
  label: 'X-API-Key (API密钥)',
  placeholder: 'sk-xxxxxxx'
}, {
  value: 'User-Agent',
  label: 'User-Agent (用户代理)',
  placeholder: 'MyApp/1.0'
}, {
  value: 'X-Request-ID',
  label: 'X-Request-ID (请求ID)',
  placeholder: 'req-12345'
}, {
  value: 'X-Custom-Header',
  label: 'X-Custom-Header (自定义)',
  placeholder: '自定义值'
}];

// AI Header 类型

// 新增消息对话框组件
const AddMessageDialog = _ref2 => {
  let {
    onSubmit,
    onCancel,
    isSubmitting,
    botConfigured,
    onConfigureBot
  } = _ref2;
  const [formData, setFormData] = (0,react.useState)({
    Topic: '',
    Content: '',
    Schedule_Date: new Date().toISOString().split('T')[0],
    Schedule_Time: '',
    Push_Method: 'AsMe',
    Target_Type: 'private',
    Glip_User_Name: '',
    Glip_Team_ID: ''
  });
  const [userTags, setUserTags] = (0,react.useState)([]);
  const [isRepeating, setIsRepeating] = (0,react.useState)(false);
  const [aiReportTemplate, setAiReportTemplate] = (0,react.useState)('ai-report');
  const [aiHeaders, setAiHeaders] = (0,react.useState)([]);

  // AI Report 可视化字段
  const [aiReportJql, setAiReportJql] = (0,react.useState)('');
  const [aiReportOutputs, setAiReportOutputs] = (0,react.useState)({
    noduedate: true,
    overdue: true,
    toTest: true
  });
  const [aiReportTeamId, setAiReportTeamId] = (0,react.useState)('');
  const [aiReportMentionList, setAiReportMentionList] = (0,react.useState)([]);
  const [aiReportExtraText, setAiReportExtraText] = (0,react.useState)('');

  // 三个模板的数据缓存（内存中，关闭页面后失效）
  const templateCacheRef = react.useRef({
    'ai-report': {
      AI_Endpoint: '',
      AI_Headers: '',
      AI_Body: ''
    },
    'pep-report': {
      AI_Endpoint: '',
      AI_Headers: '',
      AI_Body: ''
    },
    'custom': {
      AI_Endpoint: '',
      AI_Headers: '',
      AI_Body: ''
    }
  });

  // AI Report 预设值
  const aiReportPresets = {
    'ai-report': {
      AI_Endpoint: 'POST https://dify.int.rclabenv.com/v1/chat-messages',
      AI_Headers: 'Authorization: Bearer app-hTAaR1jaLnYDITixXRP5qi4Y\nContent-Type: application/json',
      AI_Body: JSON.stringify({
        response_mode: 'blocking',
        user: 'default-user',
        query: '{Topic}',
        inputs: {
          title: '{Topic}',
          outputs: 'noduedate, overdue, toTest',
          jql: '{Content}',
          extraText: '',
          teamId: '{TeamID}',
          mentionList: ''
        }
      }, null, 2)
    },
    'pep-report': {
      AI_Endpoint: 'POST https://gitlab-reviewer.int.rclabenv.com/pep_daily_report',
      AI_Headers: 'Content-Type: application/json',
      AI_Body: JSON.stringify({
        jira_query_id: 111,
        sheet_id: '',
        sheet_name: '',
        team_id: '{TeamID}',
        mention_list: [],
        overallFilterId: '',
        bugFilterid: '',
        ignore_due_soon: true,
        force_running: true,
        missing_due_check_scope: 'all',
        language: '',
        milestones: [{
          abbreviation: 'MR',
          full_name: 'Code Merge',
          goal: '提测所有功能及安排在本Release的Production Bug'
        }, {
          abbreviation: 'FF',
          full_name: 'Feature Freeze',
          goal: '1）完成所有功能测试；2）完成安排在本Release的所有Production和Release Bug (接近FF 2天内的P2 bug可以Regression阶段修复）'
        }, {
          abbreviation: 'CF',
          full_name: 'Code Freeze',
          goal: '完成所有本Release的功能开发、测试和Bug修复。完成Sign off。提供Dogfooding Build'
        }]
      }, null, 2)
    }
  };

  // 处理模板切换
  const handleTemplateChange = newTemplate => {
    // 保存当前模板的数据到缓存
    if (aiReportTemplate === 'ai-report') {
      // ai-report 使用可视化字段，不需要保存 Body
      templateCacheRef.current[aiReportTemplate] = {
        AI_Endpoint: formData.AI_Endpoint || '',
        AI_Headers: formData.AI_Headers || '',
        AI_Body: '' // ai-report 的 Body 会动态生成
      };
    } else {
      templateCacheRef.current[aiReportTemplate] = {
        AI_Endpoint: formData.AI_Endpoint || '',
        AI_Headers: formData.AI_Headers || '',
        AI_Body: formData.AI_Body || ''
      };
    }

    // 切换到新模板
    setAiReportTemplate(newTemplate);

    // 如果新模板有预设值且缓存为空，使用预设值
    if (newTemplate === 'ai-report' && !templateCacheRef.current['ai-report'].AI_Endpoint) {
      const headersStr = aiReportPresets['ai-report'].AI_Headers;
      handleChange('AI_Endpoint', aiReportPresets['ai-report'].AI_Endpoint);
      handleChange('AI_Headers', headersStr);
      // ai-report 的 Body 会通过可视化字段自动生成，不需要手动设置
      setAiHeaders(parseHeadersString(headersStr));
    } else if (newTemplate === 'pep-report' && !templateCacheRef.current['pep-report'].AI_Endpoint) {
      const headersStr = aiReportPresets['pep-report'].AI_Headers;
      handleChange('AI_Endpoint', aiReportPresets['pep-report'].AI_Endpoint);
      handleChange('AI_Headers', headersStr);
      handleChange('AI_Body', aiReportPresets['pep-report'].AI_Body);
      setAiHeaders(parseHeadersString(headersStr));
    } else {
      // 从缓存恢复数据
      const cached = templateCacheRef.current[newTemplate];
      handleChange('AI_Endpoint', cached.AI_Endpoint);
      handleChange('AI_Headers', cached.AI_Headers);
      if (newTemplate !== 'ai-report') {
        handleChange('AI_Body', cached.AI_Body);
      }
      if (newTemplate === 'custom') {
        setAiHeaders(parseHeadersString(cached.AI_Headers));
      }
    }
  };

  // 构建 AI Report Body JSON
  const buildAiReportBody = () => {
    const outputs = Object.entries(aiReportOutputs).filter(_ref3 => {
      let [, enabled] = _ref3;
      return enabled;
    }).map(_ref4 => {
      let [key] = _ref4;
      return key;
    }).join(', ');
    return JSON.stringify({
      response_mode: 'blocking',
      user: 'default-user',
      query: '{Topic}',
      inputs: {
        title: '{Topic}',
        outputs: outputs,
        jql: '{Content}',
        extraText: aiReportExtraText,
        teamId: '{TeamID}',
        mentionList: formatUserName.joinForMentionList(aiReportMentionList)
      }
    }, null, 2);
  };

  // 解析 headers 字符串为数组
  const parseHeadersString = headersStr => {
    if (!headersStr) return [];
    const lines = headersStr.split('\n');
    const headers = [];
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      const colonIndex = trimmed.indexOf(':');
      if (colonIndex === -1) continue;
      const name = trimmed.substring(0, colonIndex).trim();
      const value = trimmed.substring(colonIndex + 1).trim();
      if (name && value) {
        headers.push({
          name,
          value
        });
      }
    }
    return headers;
  };

  // 将 headers 数组转换为字符串
  const formatHeadersToString = headers => {
    return headers.filter(h => h.name && h.value).map(h => `${h.name}: ${h.value}`).join('\n');
  };

  // 当 Push_Method 切换到 AI 时，初始化模板
  react.useEffect(() => {
    if (formData.Push_Method === 'AI' && !formData.AI_Endpoint) {
      setAiReportTemplate('ai-report');
      const headersStr = aiReportPresets['ai-report'].AI_Headers;
      handleChange('AI_Endpoint', aiReportPresets['ai-report'].AI_Endpoint);
      handleChange('AI_Headers', headersStr);
      // ai-report 模板不需要初始化 AI_Body，会通过可视化字段动态生成
      setAiHeaders(parseHeadersString(headersStr));
    }
  }, [formData.Push_Method]);

  // 当 ai-report 的可视化字段变化时，自动更新 Content 和 AI_Body
  react.useEffect(() => {
    if (formData.Push_Method === 'AI' && aiReportTemplate === 'ai-report') {
      // 同步 JQL 到 Content
      handleChange('Content', aiReportJql);
      // 动态构建 AI_Body
      handleChange('AI_Body', buildAiReportBody());
    }
  }, [aiReportJql, aiReportOutputs, aiReportTeamId, aiReportMentionList, aiReportExtraText]);

  // Header 管理函数
  const addAIHeader = () => {
    setAiHeaders([...aiHeaders, {
      name: '',
      value: ''
    }]);
  };
  const updateAIHeaderName = (index, name) => {
    const newHeaders = [...aiHeaders];
    newHeaders[index].name = name;
    setAiHeaders(newHeaders);
    handleChange('AI_Headers', formatHeadersToString(newHeaders));
  };
  const updateAIHeaderValue = (index, value) => {
    const newHeaders = [...aiHeaders];
    newHeaders[index].value = value;
    setAiHeaders(newHeaders);
    handleChange('AI_Headers', formatHeadersToString(newHeaders));
  };
  const removeAIHeader = index => {
    const newHeaders = aiHeaders.filter((_, i) => i !== index);
    setAiHeaders(newHeaders);
    handleChange('AI_Headers', formatHeadersToString(newHeaders));
  };
  const handleSubmit = e => {
    e.preventDefault();

    // 验证必填字段
    if (!formData.Topic || !formData.Schedule_Date) {
      alert('请填写所有必填字段');
      return;
    }

    // 验证推送目标
    if (formData.Push_Method === 'AI') {
      // AI 消息验证
      if (aiReportTemplate === 'ai-report') {
        // ai-report 模板验证 JQL
        if (!aiReportJql.trim()) {
          alert('请填写 JQL 查询');
          return;
        }
      } else {
        // 其他模板验证 Content 和 Body
        if (!formData.Content) {
          alert('请填写消息内容');
          return;
        }
        if (!formData.AI_Endpoint || !formData.AI_Body) {
          alert('请填写 AI Endpoint 和 Body');
          return;
        }
      }
    } else {
      // Bot/AsMe 消息验证
      if (!formData.Content) {
        alert('请填写消息内容');
        return;
      }
      if (formData.Target_Type === 'private' && userTags.length === 0) {
        alert('请至少添加一个接收人');
        return;
      }
      if (formData.Target_Type === 'group' && !formData.Glip_Team_ID) {
        alert('请填写群组 ID');
        return;
      }
    }

    // 验证周期性消息
    if (isRepeating) {
      if (!formData.Repeat_Every || !formData.Repeat_Unit) {
        alert('请完整填写重复设置');
        return;
      }
    }

    // 合并 userTags 到 Glip_User_Name（转换为存储格式：esone.qiu+john.doe）
    // 注意：不传递 Target_Type，由 AppScript 动态判断

    // 处理 AI Report 的 Glip_Team_ID
    let glipTeamId = formData.Glip_Team_ID;
    if (formData.Push_Method === 'AI') {
      if (aiReportTemplate === 'ai-report') {
        // ai-report 模板：使用可视化输入框的值
        glipTeamId = aiReportTeamId;
      } else if (aiReportTemplate === 'pep-report') {
        // pep-report 模板：解析 JSON 提取 team_id
        try {
          const bodyJson = JSON.parse(formData.AI_Body || '{}');
          if (bodyJson.team_id && typeof bodyJson.team_id === 'string' && !bodyJson.team_id.includes('{')) {
            // 如果 team_id 不是变量（不包含 {}），则使用它
            glipTeamId = bodyJson.team_id;
          }
        } catch (e) {
          console.warn('解析 PEP report JSON 失败:', e);
        }
      }
      // custom 模板：不处理，用户自己负责
    }
    const finalFormData = {
      ...formData,
      Glip_User_Name: formData.Push_Method === 'AI' ? undefined : formatUserName.joinForStorage(userTags),
      Glip_Team_ID: glipTeamId,
      Repeat_Every: isRepeating ? formData.Repeat_Every : undefined,
      Repeat_Unit: isRepeating ? formData.Repeat_Unit : undefined,
      Repeat_Count: isRepeating ? formData.Repeat_Count : undefined,
      End_Date: isRepeating ? formData.End_Date : undefined
    };
    onSubmit(finalFormData);
  };
  const handleChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };
  const handleUserTagsChange = tags => {
    setUserTags(tags);
  };
  return /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.overlay
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.dialog
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.header
  }, /*#__PURE__*/react.createElement("h2", {
    style: dialogStyles.title
  }, "\u2795 \u65B0\u589E\u5B9A\u65F6\u6D88\u606F"), /*#__PURE__*/react.createElement("button", {
    style: dialogStyles.closeButton,
    onClick: onCancel
  }, "\u2715")), /*#__PURE__*/react.createElement("form", {
    onSubmit: handleSubmit,
    style: dialogStyles.form
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u6D88\u606F\u4E3B\u9898 *"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "text",
    value: formData.Topic,
    onChange: e => handleChange('Topic', e.target.value),
    placeholder: "\u8F93\u5165\u6D88\u606F\u4E3B\u9898"
  })), !(formData.Push_Method === 'AI' && aiReportTemplate === 'ai-report') && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u6D88\u606F\u5185\u5BB9 *"), /*#__PURE__*/react.createElement("textarea", {
    style: dialogStyles.textarea,
    value: formData.Content,
    onChange: e => handleChange('Content', e.target.value),
    placeholder: "\u8F93\u5165\u6D88\u606F\u5185\u5BB9",
    rows: 4
  })), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formRow
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u6267\u884C\u65E5\u671F *"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "date",
    value: formData.Schedule_Date,
    onChange: e => handleChange('Schedule_Date', e.target.value)
  })), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u6267\u884C\u65F6\u95F4"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "time",
    value: formData.Schedule_Time || '',
    onChange: e => handleChange('Schedule_Time', e.target.value),
    placeholder: "09:00"
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u7559\u7A7A\u5219\u6BCF\u65E5\u65E9\u4E0A 9 \u70B9\u5DE6\u53F3\u63A8\u9001"))), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: {
      ...dialogStyles.label,
      display: 'flex',
      alignItems: 'center',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/react.createElement("input", {
    type: "checkbox",
    checked: isRepeating,
    onChange: e => {
      setIsRepeating(e.target.checked);
      if (e.target.checked) {
        handleChange('Repeat_Every', 1);
        handleChange('Repeat_Unit', 'Week');
      }
    },
    style: {
      marginRight: '8px'
    }
  }), "\u662F\u5426\u91CD\u590D\u63A8\u9001")), isRepeating && /*#__PURE__*/react.createElement("div", {
    style: {
      ...dialogStyles.section,
      backgroundColor: '#f8f9fa',
      padding: '16px',
      borderRadius: '8px'
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formRow
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u6BCF\u9694 *"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "number",
    min: "1",
    value: formData.Repeat_Every || 1,
    onChange: e => handleChange('Repeat_Every', parseInt(e.target.value))
  })), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u91CD\u590D\u5355\u4F4D *"), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.buttonGroup
  }, ['Day', 'Week', 'Month', 'Year'].map(unit => /*#__PURE__*/react.createElement("button", {
    key: unit,
    type: "button",
    style: getButtonStyle(formData.Repeat_Unit === unit),
    onClick: () => handleChange('Repeat_Unit', unit)
  }, unit === 'Day' ? '天' : unit === 'Week' ? '周' : unit === 'Month' ? '月' : '年'))))), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formRow
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u7ED3\u675F\u65E5\u671F\uFF08\u53EF\u9009\uFF09"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "date",
    value: formData.End_Date || '',
    onChange: e => handleChange('End_Date', e.target.value)
  })), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u91CD\u590D\u6B21\u6570\uFF08\u53EF\u9009\uFF09"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "number",
    min: "1",
    value: formData.Repeat_Count || '',
    onChange: e => handleChange('Repeat_Count', e.target.value ? parseInt(e.target.value) : undefined),
    placeholder: "\u7559\u7A7A\u8868\u793A\u65E0\u9650"
  })))), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u63A8\u9001\u65B9\u5F0F *"), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.buttonGroup
  }, /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: getButtonStyle(formData.Push_Method === 'AsMe'),
    onClick: () => handleChange('Push_Method', 'AsMe')
  }, "\uD83D\uDC64 AsMe\uFF08\u4EE5\u6211\u7684\u8EAB\u4EFD\uFF09"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: getButtonStyle(formData.Push_Method === 'Bot'),
    onClick: () => handleChange('Push_Method', 'Bot')
  }, "\uD83E\uDD16 Bot\uFF08\u673A\u5668\u4EBA\uFF09"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: getButtonStyle(formData.Push_Method === 'AI'),
    onClick: () => handleChange('Push_Method', 'AI')
  }, "\uD83E\uDD16 AI Report")), formData.Push_Method === 'Bot' && !botConfigured && /*#__PURE__*/react.createElement("div", {
    style: {
      marginTop: '12px',
      padding: '12px',
      backgroundColor: '#fff3cd',
      borderRadius: '6px',
      border: '1px solid #ffc107'
    }
  }, /*#__PURE__*/react.createElement("p", {
    style: {
      margin: '0 0 10px 0',
      color: '#856404',
      fontSize: '14px'
    }
  }, "\u26A0\uFE0F \u60A8\u8FD8\u672A\u914D\u7F6E Bot \u63A8\u9001\u529F\u80FD\uFF0C\u9700\u8981\u5148\u914D\u7F6E\u624D\u80FD\u4F7F\u7528\u3002"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => {
      onConfigureBot();
    },
    style: {
      padding: '8px 16px',
      backgroundColor: '#ffc107',
      color: '#000',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: 'bold'
    }
  }, "\uD83D\uDD27 \u914D\u7F6E Bot \u540E\u542F\u7528")), formData.Push_Method === 'AI' && !botConfigured && /*#__PURE__*/react.createElement("div", {
    style: {
      marginTop: '12px',
      padding: '12px',
      backgroundColor: '#fff3cd',
      borderRadius: '6px',
      border: '1px solid #ffc107'
    }
  }, /*#__PURE__*/react.createElement("p", {
    style: {
      margin: '0 0 10px 0',
      color: '#856404',
      fontSize: '14px'
    }
  }, "\u26A0\uFE0F AI Report \u529F\u80FD\u9700\u8981\u914D\u7F6E Bot \u63A8\u9001\u529F\u80FD\u624D\u80FD\u4F7F\u7528\u3002"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => {
      onConfigureBot();
    },
    style: {
      padding: '8px 16px',
      backgroundColor: '#ffc107',
      color: '#000',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: 'bold'
    }
  }, "\uD83D\uDD27 \u914D\u7F6E Bot \u540E\u542F\u7528"))), formData.Push_Method === 'AI' && /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u62A5\u544A\u6A21\u677F *"), /*#__PURE__*/react.createElement("select", {
    style: dialogStyles.select,
    value: aiReportTemplate,
    onChange: e => handleTemplateChange(e.target.value)
  }, /*#__PURE__*/react.createElement("option", {
    value: "ai-report"
  }, "AI report"), /*#__PURE__*/react.createElement("option", {
    value: "pep-report"
  }, "PEP report"), /*#__PURE__*/react.createElement("option", {
    value: "custom"
  }, "\u81EA\u5B9A\u4E49"))), aiReportTemplate === 'custom' && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "API Endpoint *"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "text",
    value: formData.AI_Endpoint || '',
    onChange: e => handleChange('AI_Endpoint', e.target.value),
    placeholder: "POST https://example.com/api \u6216 GET https://example.com/api \u6216 https://example.com/api"
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u683C\u5F0F\uFF1APOST/GET URL \u6216\u4EC5 URL\uFF08\u9ED8\u8BA4\u4E3A GET\uFF09")), aiReportTemplate === 'custom' && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "Headers"), /*#__PURE__*/react.createElement("div", {
    style: {
      border: '1px solid #ddd',
      borderRadius: '4px',
      padding: '12px',
      backgroundColor: '#f9f9f9'
    }
  }, aiHeaders.map((header, index) => /*#__PURE__*/react.createElement("div", {
    key: index,
    style: {
      display: 'flex',
      gap: '8px',
      marginBottom: '12px',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/react.createElement("select", {
    value: header.name,
    onChange: e => updateAIHeaderName(index, e.target.value),
    style: {
      ...dialogStyles.select,
      flex: '0 0 200px',
      marginBottom: 0
    }
  }, /*#__PURE__*/react.createElement("option", {
    value: ""
  }, "\u9009\u62E9 Header"), AVAILABLE_AI_HEADERS.map(h => /*#__PURE__*/react.createElement("option", {
    key: h.value,
    value: h.value
  }, h.label))), /*#__PURE__*/react.createElement("input", {
    type: "text",
    value: header.value,
    onChange: e => updateAIHeaderValue(index, e.target.value),
    placeholder: header.name ? AVAILABLE_AI_HEADERS.find(h => h.value === header.name)?.placeholder || 'Header 值' : 'Header 值',
    style: {
      ...dialogStyles.input,
      flex: 1,
      marginBottom: 0
    }
  }), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => removeAIHeader(index),
    style: {
      padding: '8px 12px',
      backgroundColor: '#dc3545',
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '14px',
      whiteSpace: 'nowrap'
    },
    title: "\u5220\u9664\u6B64 Header"
  }, "\uD83D\uDDD1\uFE0F"))), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: addAIHeader,
    style: {
      padding: '8px 16px',
      backgroundColor: '#28a745',
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '14px',
      width: '100%',
      marginTop: aiHeaders.length > 0 ? '4px' : '0'
    }
  }, "\u2795 \u6DFB\u52A0 Header")), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\uD83D\uDCA1 \u63D0\u793A\uFF1A\u53EA\u652F\u6301\u9884\u5B9A\u4E49\u7684 7 \u4E2A header \u540D\u79F0\uFF0C\u9009\u62E9\u540E\u586B\u5199\u5BF9\u5E94\u7684\u503C\u5373\u53EF")), aiReportTemplate === 'ai-report' ?
  /*#__PURE__*/
  /* AI Report 可视化配置 */
  react.createElement("div", {
    style: {
      ...dialogStyles.section,
      backgroundColor: '#f8f9fa',
      padding: '16px',
      borderRadius: '8px'
    }
  }, /*#__PURE__*/react.createElement("h3", {
    style: {
      margin: '0 0 16px 0',
      fontSize: '16px',
      fontWeight: 'bold',
      color: '#333'
    }
  }, "\uD83D\uDCCA AI Report \u914D\u7F6E"), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "JQL \u67E5\u8BE2 *"), /*#__PURE__*/react.createElement("textarea", {
    style: dialogStyles.textarea,
    value: aiReportJql,
    onChange: e => setAiReportJql(e.target.value),
    placeholder: "\u4F8B\u5982\uFF1Aproject = MTR AND status = \"In Progress\"",
    rows: 3
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u6B64\u5185\u5BB9\u4F1A\u81EA\u52A8\u540C\u6B65\u5230\u4E0A\u65B9\u7684\"\u6D88\u606F\u5185\u5BB9\"\u5B57\u6BB5")), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u7248\u5757\u81EA\u5B9A\u4E49"), /*#__PURE__*/react.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '8px'
    }
  }, /*#__PURE__*/react.createElement("label", {
    style: {
      display: 'flex',
      alignItems: 'center',
      cursor: 'pointer',
      fontSize: '14px'
    }
  }, /*#__PURE__*/react.createElement("input", {
    type: "checkbox",
    checked: aiReportOutputs.noduedate,
    onChange: e => setAiReportOutputs({
      ...aiReportOutputs,
      noduedate: e.target.checked
    }),
    style: {
      marginRight: '8px'
    }
  }), "\u5C55\u793A\u6CA1\u586B Duedate \u7684 tickets"), /*#__PURE__*/react.createElement("label", {
    style: {
      display: 'flex',
      alignItems: 'center',
      cursor: 'pointer',
      fontSize: '14px'
    }
  }, /*#__PURE__*/react.createElement("input", {
    type: "checkbox",
    checked: aiReportOutputs.overdue,
    onChange: e => setAiReportOutputs({
      ...aiReportOutputs,
      overdue: e.target.checked
    }),
    style: {
      marginRight: '8px'
    }
  }), "\u5C55\u793A Duedate \u8D85\u65F6\u7684 tickets"), /*#__PURE__*/react.createElement("label", {
    style: {
      display: 'flex',
      alignItems: 'center',
      cursor: 'pointer',
      fontSize: '14px'
    }
  }, /*#__PURE__*/react.createElement("input", {
    type: "checkbox",
    checked: aiReportOutputs.toTest,
    onChange: e => setAiReportOutputs({
      ...aiReportOutputs,
      toTest: e.target.checked
    }),
    style: {
      marginRight: '8px'
    }
  }), "\u5C55\u793A\u5F85 QA \u9A8C\u8BC1\u7684 tickets"))), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "Team ID"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "text",
    value: aiReportTeamId,
    onChange: e => setAiReportTeamId(e.target.value),
    placeholder: "\u4F8B\u5982\uFF1A148192141318"
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u53EF\u9009\uFF0C\u586B\u5165\u540E\u4F1A\u5C06\u62A5\u544A\u53D1\u9001\u5230\u6307\u5B9A\u7FA4\u7EC4")), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "@ \u6210\u5458"), /*#__PURE__*/react.createElement(TagsInput, {
    tags: aiReportMentionList,
    onChange: setAiReportMentionList,
    placeholder: "\u8F93\u5165\u4EBA\u540D\u540E\u6309 Enter \u6DFB\u52A0\uFF0C\u4F8B\u5982\uFF1AEsone Qiu \u6216 esone.qiu"
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u652F\u6301\u683C\u5F0F\uFF1A", /*#__PURE__*/react.createElement("strong", null, "Esone Qiu"), " \u6216 ", /*#__PURE__*/react.createElement("strong", null, "esone.qiu"), "\uFF0C\u6309 Enter \u6DFB\u52A0")), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u5C3E\u90E8\u6DFB\u52A0\u6587\u672C"), /*#__PURE__*/react.createElement("textarea", {
    style: dialogStyles.textarea,
    value: aiReportExtraText,
    onChange: e => setAiReportExtraText(e.target.value),
    placeholder: "\u53EF\u9009\uFF0C\u5728\u62A5\u544A\u672B\u5C3E\u6DFB\u52A0\u81EA\u5B9A\u4E49\u6587\u672C",
    rows: 2
  }))) :
  /*#__PURE__*/
  /* PEP Report 和自定义模板：显示 JSON 输入框 */
  react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "Body *"), /*#__PURE__*/react.createElement("textarea", {
    style: dialogStyles.textarea,
    value: formData.AI_Body || '',
    onChange: e => handleChange('AI_Body', e.target.value),
    placeholder: "{\"key\": \"value\"}",
    rows: 8
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u53EF\u4EE5\u4F7F\u7528 ", "{Topic}", " \u548C ", "{Content}", " \u53D8\u91CF"))), formData.Push_Method !== 'AI' && /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u63A8\u9001\u76EE\u6807 *"), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.buttonGroup
  }, /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: getButtonStyle(formData.Target_Type === 'private'),
    onClick: () => handleChange('Target_Type', 'private')
  }, "\uD83D\uDCAC \u79C1\u53D1\u6D88\u606F"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: getButtonStyle(formData.Target_Type === 'group'),
    onClick: () => handleChange('Target_Type', 'group')
  }, "\uD83D\uDC65 \u7FA4\u7EC4\u6D88\u606F"))), formData.Target_Type === 'private' && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u63A5\u6536\u4EBA *", formData.Push_Method === 'Bot' && /*#__PURE__*/react.createElement("span", {
    style: {
      color: '#dc3545',
      marginLeft: '8px'
    }
  }, "\uFF08Bot \u6A21\u5F0F\u53EA\u80FD\u586B\u4E00\u4E2A\u4EBA\u540D\uFF09")), /*#__PURE__*/react.createElement(TagsInput, {
    tags: userTags,
    onChange: handleUserTagsChange,
    placeholder: "\u8F93\u5165\u4EBA\u540D\u540E\u6309 Enter \u6DFB\u52A0\uFF0C\u4F8B\u5982\uFF1AEsone Qiu \u6216 esone.qiu",
    maxTags: formData.Push_Method === 'Bot' ? 1 : undefined
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u652F\u6301\u683C\u5F0F\uFF1A", /*#__PURE__*/react.createElement("strong", null, "Esone Qiu"), " \u6216 ", /*#__PURE__*/react.createElement("strong", null, "esone.qiu"), "\uFF0C\u6309 Enter \u6DFB\u52A0")), formData.Target_Type === 'group' && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u7FA4\u7EC4 ID *"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "text",
    value: formData.Glip_Team_ID || '',
    onChange: e => handleChange('Glip_Team_ID', e.target.value),
    placeholder: "\u4F8B\u5982\uFF1A148192141318"
  }))), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.actions
  }, /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: dialogStyles.cancelButton,
    onClick: onCancel,
    disabled: isSubmitting
  }, "\u53D6\u6D88"), /*#__PURE__*/react.createElement("button", {
    type: "submit",
    style: dialogStyles.submitButton,
    disabled: isSubmitting
  }, isSubmitting ? '创建中...' : '✅ 创建消息')))));
};

// 按钮选择器样式辅助函数
const getButtonStyle = isSelected => ({
  flex: 1,
  padding: '10px 16px',
  backgroundColor: isSelected ? '#007bff' : '#fff',
  color: isSelected ? '#fff' : '#333',
  border: `2px solid ${isSelected ? '#007bff' : '#ddd'}`,
  borderRadius: '6px',
  cursor: 'pointer',
  fontSize: '14px',
  fontWeight: isSelected ? 'bold' : 'normal',
  transition: 'all 0.2s'
});
const getTypeStyle = pushMethod => {
  const baseStyle = {
    padding: '4px 8px',
    borderRadius: '4px',
    fontSize: '12px',
    fontWeight: 'bold'
  };
  switch (pushMethod) {
    case 'AI':
      return {
        ...baseStyle,
        backgroundColor: '#e3f2fd',
        color: '#1976d2'
      };
    // 蓝色 - AI Report
    case 'AsMe':
      return {
        ...baseStyle,
        backgroundColor: '#f3e5f5',
        color: '#7b1fa2'
      };
    // 紫色 - 假装我发的
    case 'Bot':
      return {
        ...baseStyle,
        backgroundColor: '#fff3e0',
        color: '#f57c00'
      };
    // 橙色 - Bot 定时
    default:
      return {
        ...baseStyle,
        backgroundColor: '#f5f5f5',
        color: '#666'
      };
  }
};
const getStatusStyle = status => {
  const baseStyle = {
    padding: '4px 8px',
    borderRadius: '4px',
    fontSize: '12px',
    fontWeight: 'bold'
  };
  switch (status) {
    case 'Active':
      return {
        ...baseStyle,
        backgroundColor: '#d4edda',
        color: '#155724'
      };
    case 'Paused':
      return {
        ...baseStyle,
        backgroundColor: '#fff3cd',
        color: '#856404'
      };
    case 'Completed':
      return {
        ...baseStyle,
        backgroundColor: '#d1ecf1',
        color: '#0c5460'
      };
    default:
      return {
        ...baseStyle,
        backgroundColor: '#f5f5f5',
        color: '#666'
      };
  }
};
const ScheduledMessagesManager_styles = {
  container: {
    minHeight: '100vh',
    backgroundColor: '#f8f9fa'
  },
  loadingContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '100vh'
  },
  spinner: {
    width: '50px',
    height: '50px',
    border: '4px solid #f3f3f3',
    borderTop: '4px solid #007bff',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite'
  },
  topicText: {
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    maxWidth: '300px',
    display: 'inline-block'
  },
  header: {
    backgroundColor: '#fff',
    padding: '20px',
    borderBottom: '1px solid #e0e0e0',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  title: {
    margin: 0,
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#333'
  },
  headerActions: {
    display: 'flex',
    gap: '10px'
  },
  addButton: {
    padding: '8px 16px',
    backgroundColor: '#28a745',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px'
  },
  syncButton: {
    padding: '8px 16px',
    backgroundColor: '#007bff',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px'
  },
  configButton: {
    padding: '8px 16px',
    backgroundColor: '#6c757d',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px'
  },
  deleteButton: {
    padding: '4px 8px',
    backgroundColor: 'transparent',
    color: '#dc3545',
    border: '1px solid #dc3545',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
    transition: 'all 0.2s'
  },
  warningBanner: {
    backgroundColor: '#fff3cd',
    borderLeft: '4px solid #ffc107',
    padding: '16px 20px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottom: '1px solid #ffc107',
    animation: 'slideDown 0.3s ease-out'
  },
  warningContent: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: '12px',
    flex: 1
  },
  warningIcon: {
    fontSize: '24px',
    lineHeight: 1
  },
  warningText: {
    flex: 1
  },
  warningDescription: {
    margin: '4px 0 0 0',
    fontSize: '13px',
    color: '#856404'
  },
  warningButton: {
    padding: '8px 16px',
    backgroundColor: '#ffc107',
    color: '#000',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold',
    whiteSpace: 'nowrap',
    marginLeft: '16px'
  },
  statusBar: {
    backgroundColor: '#fff',
    padding: '15px 20px',
    borderBottom: '1px solid #e0e0e0',
    display: 'flex',
    gap: '20px'
  },
  statusItem: {
    fontSize: '14px',
    color: '#666'
  },
  content: {
    padding: '20px'
  },
  emptyState: {
    textAlign: 'center',
    padding: '60px 20px',
    backgroundColor: '#fff',
    borderRadius: '8px'
  },
  emptyText: {
    fontSize: '18px',
    color: '#666',
    marginBottom: '10px'
  },
  emptyHint: {
    fontSize: '14px',
    color: '#999'
  },
  messageList: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    overflow: 'hidden'
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse'
  },
  th: {
    padding: '12px',
    textAlign: 'left',
    backgroundColor: '#f8f9fa',
    borderBottom: '2px solid #e0e0e0',
    fontWeight: 'bold',
    fontSize: '14px',
    color: '#333'
  },
  tr: {
    borderBottom: '1px solid #e0e0e0'
  },
  td: {
    padding: '12px',
    fontSize: '14px',
    color: '#666'
  },
  footer: {
    padding: '20px',
    textAlign: 'center'
  },
  footerText: {
    fontSize: '12px',
    color: '#999'
  }
};

// 对话框样式
const dialogStyles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000
  },
  dialog: {
    backgroundColor: '#fff',
    borderRadius: '12px',
    padding: '0',
    maxWidth: '600px',
    width: '90%',
    maxHeight: '90vh',
    overflow: 'auto',
    boxShadow: '0 10px 40px rgba(0, 0, 0, 0.3)'
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '20px',
    borderBottom: '1px solid #e0e0e0'
  },
  title: {
    margin: 0,
    fontSize: '20px',
    fontWeight: 'bold',
    color: '#333'
  },
  closeButton: {
    background: 'transparent',
    border: 'none',
    fontSize: '24px',
    cursor: 'pointer',
    color: '#666',
    padding: '0',
    width: '30px',
    height: '30px'
  },
  form: {
    padding: '20px'
  },
  formGroup: {
    marginBottom: '16px',
    flex: '1'
  },
  formRow: {
    display: 'flex',
    gap: '16px'
  },
  section: {
    marginBottom: '16px'
  },
  buttonGroup: {
    display: 'flex',
    gap: '8px',
    flexWrap: 'wrap'
  },
  label: {
    display: 'block',
    marginBottom: '6px',
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333'
  },
  input: {
    width: '100%',
    padding: '8px 12px',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '14px',
    boxSizing: 'border-box'
  },
  textarea: {
    width: '100%',
    padding: '8px 12px',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '14px',
    resize: 'vertical',
    boxSizing: 'border-box'
  },
  select: {
    width: '100%',
    padding: '8px 12px',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '14px',
    boxSizing: 'border-box'
  },
  hint: {
    display: 'block',
    marginTop: '4px',
    fontSize: '12px',
    color: '#999'
  },
  actions: {
    display: 'flex',
    justifyContent: 'flex-end',
    gap: '10px',
    marginTop: '24px',
    paddingTop: '20px',
    borderTop: '1px solid #e0e0e0'
  },
  cancelButton: {
    padding: '10px 20px',
    backgroundColor: '#6c757d',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px'
  },
  submitButton: {
    padding: '10px 20px',
    backgroundColor: '#28a745',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px'
  }
};

// 添加 CSS 动画
const ScheduledMessagesManager_styleSheet = document.createElement('style');
ScheduledMessagesManager_styleSheet.textContent = `
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
  @keyframes slideDown {
    from {
      opacity: 0;
      transform: translateY(-10px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  button:hover {
    opacity: 0.9;
  }
  button:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;
document.head.appendChild(ScheduledMessagesManager_styleSheet);

// Bot 配置对话框组件
const BotConfigDialog = _ref5 => {
  let {
    config,
    onClose,
    onSuccess
  } = _ref5;
  const [isSubmitting, setIsSubmitting] = (0,react.useState)(false);
  const [error, setError] = (0,react.useState)('');
  const [step, setStep] = (0,react.useState)('input');
  const [jiraUrl, setJiraUrl] = (0,react.useState)('https://jira.ringcentral.com');
  const [projectKey, setProjectKey] = (0,react.useState)('');

  // 使用 ref 跟踪组件是否已挂载
  const isMountedRef = (0,react.useRef)(true);
  (0,react.useEffect)(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);
  const handleSubmit = async e => {
    e.preventDefault();
    if (!projectKey.trim()) {
      setError('请输入 Jira Project Key');
      return;
    }
    setIsSubmitting(true);
    setError('');
    try {
      // 导入服务类
      const {
        JiraAutomationService
      } = await __webpack_require__.e(/* import() */ 244).then(__webpack_require__.bind(__webpack_require__, 7244));
      const jiraService = new JiraAutomationService();

      // 步骤 1: 测试连接
      setStep('testing');
      const testResult = await jiraService.testAccess({
        jiraUrl,
        projectKey: projectKey.toUpperCase()
      });
      if (!testResult.success) {
        throw new Error(testResult.message);
      }

      // 步骤 2: 创建规则
      setStep('creating');
      const ruleResult = await jiraService.createBotExecutorRule({
        jiraUrl,
        projectKey: projectKey.toUpperCase()
      }, config.webAppUrl);

      // 保存配置到 scheduledMessagesConfig.botExecutor
      const updatedConfig = {
        ...config,
        botExecutor: {
          ...ruleResult,
          jiraUrl
        }
      };
      await chrome.storage.local.set({
        scheduledMessagesConfig: updatedConfig
      });
      onSuccess();
    } catch (err) {
      console.error('配置 Bot 失败:', err);
      if (isMountedRef.current) {
        setError(err.message || '配置失败，请重试');
        setStep('input');
      }
    } finally {
      if (isMountedRef.current) {
        setIsSubmitting(false);
      }
    }
  };
  return /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.overlay
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.dialog
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.header
  }, /*#__PURE__*/react.createElement("h2", {
    style: dialogStyles.title
  }, "\uD83E\uDD16 \u914D\u7F6E Bot \u63A8\u9001"), /*#__PURE__*/react.createElement("button", {
    style: dialogStyles.closeButton,
    onClick: onClose,
    disabled: isSubmitting
  }, "\u2715")), /*#__PURE__*/react.createElement("form", {
    onSubmit: handleSubmit,
    style: dialogStyles.form
  }, step === 'input' && /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("div", {
    style: {
      backgroundColor: '#e7f3ff',
      padding: '15px',
      borderRadius: '8px',
      marginBottom: '20px',
      border: '1px solid #b3d7ff'
    }
  }, /*#__PURE__*/react.createElement("p", {
    style: {
      margin: '0 0 8px 0',
      fontSize: '14px',
      fontWeight: 'bold',
      color: '#333'
    }
  }, "\uD83D\uDCCB \u914D\u7F6E\u8BF4\u660E"), /*#__PURE__*/react.createElement("ul", {
    style: {
      margin: 0,
      paddingLeft: '20px',
      fontSize: '13px',
      color: '#666',
      lineHeight: '1.6'
    }
  }, /*#__PURE__*/react.createElement("li", null, "\u9700\u8981\u60A8\u5728 Jira \u4E0A\u6709\u7BA1\u7406\u6743\u9650\u7684\u9879\u76EE"), /*#__PURE__*/react.createElement("li", null, "\u7CFB\u7EDF\u5C06\u5728\u8BE5\u9879\u76EE\u4E0B\u521B\u5EFA\u4E00\u4E2A Automation \u89C4\u5219"), /*#__PURE__*/react.createElement("li", null, "\u8BE5\u89C4\u5219\u6BCF\u5206\u949F\u6267\u884C\u4E00\u6B21\uFF0C\u68C0\u67E5\u5E76\u53D1\u9001 Bot \u6D88\u606F"), /*#__PURE__*/react.createElement("li", null, "\u2705 Bot \u914D\u7F6E\uFF08API \u5730\u5740\u3001Token\u3001ID\uFF09\u5C06\u81EA\u52A8\u4ECE\u6269\u5C55\u8BBE\u7F6E\u4E2D\u8BFB\u53D6\uFF0C\u65E0\u9700\u624B\u52A8\u586B\u5199"))), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "Jira URL *"), /*#__PURE__*/react.createElement("div", {
    style: {
      display: 'flex',
      gap: '8px'
    }
  }, /*#__PURE__*/react.createElement("input", {
    style: {
      ...dialogStyles.input,
      flex: 1
    },
    type: "text",
    value: jiraUrl,
    onChange: e => setJiraUrl(e.target.value),
    placeholder: "https://jira.ringcentral.com"
  }), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => window.open(jiraUrl, '_blank'),
    style: {
      padding: '8px 16px',
      backgroundColor: '#007bff',
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '14px',
      whiteSpace: 'nowrap'
    },
    title: "\u5728\u65B0\u6807\u7B7E\u9875\u4E2D\u6253\u5F00 Jira\uFF08\u9700\u8981\u5148\u767B\u5F55\uFF09"
  }, "\uD83D\uDD17 \u6253\u5F00 Jira")), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u8BF7\u786E\u4FDD\u60A8\u5DF2\u5728\u6D4F\u89C8\u5668\u4E2D\u767B\u5F55\u6B64 Jira \u5B9E\u4F8B")), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "Project Key *"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "text",
    value: projectKey,
    onChange: e => setProjectKey(e.target.value.toUpperCase()),
    placeholder: "MTR",
    maxLength: 10
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u8BF7\u8F93\u5165\u60A8\u6709\u7BA1\u7406\u6743\u9650\u7684\u9879\u76EE Key\uFF0C\u5982\uFF1AMTR")), error && /*#__PURE__*/react.createElement("div", {
    style: {
      padding: '12px',
      backgroundColor: '#f8d7da',
      color: '#721c24',
      borderRadius: '6px',
      fontSize: '14px',
      marginTop: '16px',
      border: '1px solid #f5c6cb'
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: {
      fontWeight: 'bold',
      marginBottom: '6px'
    }
  }, "\u274C \u914D\u7F6E\u5931\u8D25"), /*#__PURE__*/react.createElement("div", {
    style: {
      whiteSpace: 'pre-wrap'
    }
  }, error))), step === 'testing' && /*#__PURE__*/react.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '40px 20px'
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.spinner
  }), /*#__PURE__*/react.createElement("p", {
    style: {
      fontSize: '16px',
      color: '#333',
      marginTop: '20px'
    }
  }, "\u6B63\u5728\u6D4B\u8BD5 Jira \u8FDE\u63A5...")), step === 'creating' && /*#__PURE__*/react.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '40px 20px'
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.spinner
  }), /*#__PURE__*/react.createElement("p", {
    style: {
      fontSize: '16px',
      color: '#333',
      marginTop: '20px'
    }
  }, "\u6B63\u5728\u521B\u5EFA Jira Automation \u89C4\u5219..."), /*#__PURE__*/react.createElement("p", {
    style: {
      fontSize: '13px',
      color: '#999',
      marginTop: '10px'
    }
  }, "\u8FD9\u53EF\u80FD\u9700\u8981\u51E0\u79D2\u949F\uFF0C\u8BF7\u7A0D\u5019...")), step === 'input' && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.actions
  }, /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: dialogStyles.cancelButton,
    onClick: onClose,
    disabled: isSubmitting
  }, "\u53D6\u6D88"), /*#__PURE__*/react.createElement("button", {
    type: "submit",
    style: dialogStyles.submitButton,
    disabled: isSubmitting
  }, isSubmitting ? '配置中...' : '✅ 开始配置')))));
};

// 渲染应用
react_dom.render(/*#__PURE__*/react.createElement(react.StrictMode, null, /*#__PURE__*/react.createElement(ScheduledMessagesManager, null)), document.getElementById('root'));
/******/ })()
;
//# sourceMappingURL=scheduled-messages.js.map