/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 8998:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ConfigSyncService: () => (/* binding */ ConfigSyncService)
/* harmony export */ });
/**
 * 配置同步服务
 * 负责在 Chrome Storage 和 Sheet Config 表之间同步配置
 */

class ConfigSyncService {
  constructor(token) {
    this.token = token;
  }

  /**
   * 从 Sheet Config 表读取配置
   */
  async readConfigFromSheet(sheetId) {
    try {
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/Config!A2:B50`, {
        headers: {
          'Authorization': `Bearer ${this.token}`
        }
      });
      if (!response.ok) {
        throw new Error('读取 Sheet 配置失败');
      }
      const data = await response.json();
      const rows = data.values || [];

      // 将键值对转换为配置对象
      const config = {
        sheetId,
        sheetUrl: `https://docs.google.com/spreadsheets/d/${sheetId}/edit`
      };
      for (const row of rows) {
        const [key, value] = row;
        if (!key || !value) continue;
        switch (key) {
          case 'minute_trigger_id':
            config.minute_trigger_id = value;
            break;
          case 'daily_trigger_id':
            config.daily_trigger_id = value;
            break;
          case 'web_app_url':
            config.webAppUrl = value;
            break;
          case 'script_id':
            config.scriptId = value;
            break;
          case 'sheet_version':
            config.sheet_version = value;
            break;
          case 'created_by':
            config.created_by = value;
            break;
          case 'created_at':
            config.created_at = value;
            break;
          case 'last_sync_time':
            config.last_sync_time = value;
            break;
          case 'messages_sheet_id':
            config.messagesSheetId = parseInt(value);
            break;
          case 'logs_sheet_id':
            config.logsSheetId = parseInt(value);
            break;
          // Bot Executor 配置
          case 'bot_executor_rule_id':
            if (!config.botExecutor) config.botExecutor = {};
            config.botExecutor.ruleId = value;
            break;
          case 'bot_executor_rule_name':
            if (!config.botExecutor) config.botExecutor = {};
            config.botExecutor.ruleName = value;
            break;
          case 'bot_executor_webhook_url':
            if (!config.botExecutor) config.botExecutor = {};
            config.botExecutor.webhookUrl = value;
            break;
          case 'bot_executor_project_key':
            if (!config.botExecutor) config.botExecutor = {};
            config.botExecutor.projectKey = value;
            break;
          case 'bot_executor_jira_url':
            if (!config.botExecutor) config.botExecutor = {};
            config.botExecutor.jiraUrl = value;
            break;
          case 'bot_executor_created_at':
            if (!config.botExecutor) config.botExecutor = {};
            config.botExecutor.createdAt = value;
            break;
          case 'bot_executor_rule_version':
            if (!config.botExecutor) config.botExecutor = {};
            config.botExecutor.ruleVersion = value;
            break;
          case 'bot_executor_rule_last_updated':
            if (!config.botExecutor) config.botExecutor = {};
            config.botExecutor.ruleLastUpdated = value;
            break;
        }
      }
      return config;
    } catch (error) {
      console.error('从 Sheet 读取配置失败:', error);
      throw error;
    }
  }

  /**
   * 保存配置到 Sheet Config 表
   */
  async saveConfigToSheet(config) {
    try {
      const configData = [];

      // 基础配置
      if (config.minute_trigger_id) {
        configData.push(['minute_trigger_id', config.minute_trigger_id]);
      }
      if (config.daily_trigger_id) {
        configData.push(['daily_trigger_id', config.daily_trigger_id]);
      }
      if (config.webAppUrl) {
        configData.push(['web_app_url', config.webAppUrl]);
      }
      if (config.scriptId) {
        configData.push(['script_id', config.scriptId]);
      }
      if (config.sheet_version) {
        configData.push(['sheet_version', config.sheet_version]);
      }
      if (config.created_by) {
        configData.push(['created_by', config.created_by]);
      }
      if (config.created_at) {
        configData.push(['created_at', config.created_at]);
      }
      configData.push(['last_sync_time', new Date().toISOString()]);

      // Messages Sheet ID
      if (config.messagesSheetId !== undefined) {
        configData.push(['messages_sheet_id', config.messagesSheetId.toString()]);
      }

      // Logs Sheet ID
      if (config.logsSheetId !== undefined && config.logsSheetId !== null) {
        configData.push(['logs_sheet_id', config.logsSheetId.toString()]);
      }

      // Bot Executor 配置
      if (config.botExecutor) {
        configData.push(['bot_executor_rule_id', config.botExecutor.ruleId]);
        configData.push(['bot_executor_rule_name', config.botExecutor.ruleName]);
        configData.push(['bot_executor_webhook_url', config.botExecutor.webhookUrl]);
        configData.push(['bot_executor_project_key', config.botExecutor.projectKey]);
        configData.push(['bot_executor_jira_url', config.botExecutor.jiraUrl]);
        configData.push(['bot_executor_created_at', config.botExecutor.createdAt]);
        if (config.botExecutor.ruleVersion) {
          configData.push(['bot_executor_rule_version', config.botExecutor.ruleVersion]);
        }
        if (config.botExecutor.ruleLastUpdated) {
          configData.push(['bot_executor_rule_last_updated', config.botExecutor.ruleLastUpdated]);
        }
      }

      // 更新 Sheet Config 表
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${config.sheetId}/values/Config!A2:B50?valueInputOption=USER_ENTERED`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          values: configData
        })
      });
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`保存配置到 Sheet 失败: ${errorText}`);
      }
      console.log('✅ 配置已同步到 Sheet Config 表');
    } catch (error) {
      console.error('保存配置到 Sheet 失败:', error);
      throw error;
    }
  }

  /**
   * 保存配置到 Chrome Storage
   */
  async saveConfigToStorage(config) {
    await chrome.storage.local.set({
      scheduledMessagesConfig: config
    });
    console.log('✅ 配置已保存到 Chrome Storage');
  }

  /**
   * 从 Chrome Storage 读取配置
   */
  async readConfigFromStorage() {
    const result = await chrome.storage.local.get(['scheduledMessagesConfig']);
    return result.scheduledMessagesConfig || null;
  }

  /**
   * 同步配置：同时保存到 Sheet 和 Chrome Storage
   */
  async syncConfig(config) {
    // 更新 last_sync_time
    config.last_sync_time = new Date().toISOString();

    // 同时保存到两个位置
    await Promise.all([this.saveConfigToSheet(config), this.saveConfigToStorage(config)]);
    console.log('✅ 配置已同步到 Sheet 和 Chrome Storage');
  }

  /**
   * 更新部分配置（仅更新指定字段）
   */
  async updatePartialConfig(updates) {
    // 读取现有配置
    const existingConfig = await this.readConfigFromStorage();
    if (!existingConfig) {
      throw new Error('未找到现有配置');
    }

    // 合并配置
    const updatedConfig = {
      ...existingConfig,
      ...updates,
      last_sync_time: new Date().toISOString()
    };

    // 同步到两个位置
    await this.syncConfig(updatedConfig);
    return updatedConfig;
  }
}

/***/ }),

/***/ 5704:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   H: () => (/* binding */ JIRA_RULE_LAST_UPDATED),
/* harmony export */   JiraAutomationService: () => (/* binding */ JiraAutomationService),
/* harmony export */   l: () => (/* binding */ JIRA_RULE_VERSION)
/* harmony export */ });
/* harmony import */ var _jira_rule_template_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4010);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3922);
/**
 * Jira Automation 服务
 * 负责创建和管理 Bot 推送的 Jira Automation 规则
 */




// Jira Rule 版本信息（从模板的 _metadata 字段读取）
const JIRA_RULE_VERSION = _jira_rule_template_json__WEBPACK_IMPORTED_MODULE_0__._metadata?.version || '1.0.0';
const JIRA_RULE_LAST_UPDATED = _jira_rule_template_json__WEBPACK_IMPORTED_MODULE_0__._metadata?.lastUpdated || '2025-12-04';

// Jira 规则完整对象（从 API 返回）

class JiraAutomationService {
  /**
   * 获取当前用户的 account key
   */
  async getCurrentUserKey(config) {
    const url = `${config.jiraUrl}/rest/api/2/myself`;
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Cache-Control': 'no-cache',
        ...(config.token ? {
          'Authorization': `Bearer ${config.token}`
        } : {})
      },
      credentials: 'include'
    });
    if (!response.ok) {
      throw new Error(`无法获取用户信息 (${response.status}): ${await response.text()}`);
    }
    const userInfo = await response.json();

    // Jira Cloud 使用 accountId，Jira Server/Data Center 使用 key
    const userKey = userInfo.accountId || userInfo.key;
    if (!userKey) {
      throw new Error('无法从用户信息中获取 accountId 或 key');
    }
    console.log('当前用户 Key:', userKey);
    return userKey;
  }

  /**
   * 通过项目 Key 获取项目 ID
   */
  async getProjectId(config) {
    const url = `${config.jiraUrl}/rest/api/2/project/${config.projectKey}`;
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...(config.token ? {
          'Authorization': `Bearer ${config.token}`
        } : {})
      },
      credentials: 'include'
    });
    if (!response.ok) {
      throw new Error(`无法获取项目信息 (${response.status}): ${await response.text()}`);
    }
    const project = await response.json();
    return project.id;
  }

  /**
   * 检查 Jira 登录状态
   */
  async checkJiraLoginStatus(jiraUrl) {
    try {
      const domain = new URL(jiraUrl).hostname;
      const cookies = await chrome.cookies.getAll({
        domain
      });

      // Jira 的主要认证 cookies
      const authCookies = cookies.filter(cookie => cookie.name === 'cloud.session.token' ||
      // Jira Cloud
      cookie.name === 'JSESSIONID' ||
      // Jira Server/Data Center
      cookie.name === 'atlassian.xsrf.token');
      return {
        loggedIn: authCookies.length > 0,
        cookies: authCookies.map(c => c.name)
      };
    } catch (error) {
      console.error('检查 Jira 登录状态失败:', error);
      return {
        loggedIn: false,
        cookies: []
      };
    }
  }

  /**
   * 测试是否能访问 Jira Automation API
   */
  async testAccess(config) {
    try {
      // 先检查登录状态
      const loginStatus = await this.checkJiraLoginStatus(config.jiraUrl);
      console.log('Jira 登录状态:', loginStatus);
      if (!loginStatus.loggedIn && !config.token) {
        return {
          success: false,
          message: '未检测到 Jira 登录状态。请先在浏览器中打开 Jira 并登录，或提供 Personal Access Token。'
        };
      }

      // 获取项目 ID
      console.log('正在获取项目 ID...');
      const projectId = await this.getProjectId(config);
      console.log(`项目 ${config.projectKey} 的 ID: ${projectId}`);
      const url = `${config.jiraUrl}/rest/cb-automation/latest/project/${projectId}/rule`;
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          ...(config.token ? {
            'Authorization': `Bearer ${config.token}`
          } : {})
        },
        credentials: 'include' // 使用 cookies 认证
      });
      console.log('Jira API 响应状态:', response.status);
      if (response.ok) {
        return {
          success: true,
          message: '连接成功！可以访问 Jira Automation API。'
        };
      } else if (response.status === 401 || response.status === 403) {
        const errorText = await response.text();
        console.error('认证失败，响应:', errorText);

        // 提供更详细的错误信息
        if (!loginStatus.loggedIn) {
          return {
            success: false,
            message: '认证失败：未检测到 Jira 登录。请在新标签页中打开 Jira 并完成登录后重试。'
          };
        } else {
          return {
            success: false,
            message: `认证失败：您可能没有项目 ${config.projectKey} 的 Automation 权限。请检查：\n1. 您是否是该项目的管理员\n2. 项目是否启用了 Automation 功能`
          };
        }
      } else if (response.status === 404) {
        return {
          success: false,
          message: `项目不存在：找不到项目 ${config.projectKey}。请检查 Project Key 是否正确。`
        };
      } else {
        const errorText = await response.text();
        return {
          success: false,
          message: `无法访问 Jira Automation API (状态码: ${response.status})\n${errorText}`
        };
      }
    } catch (error) {
      console.error('测试连接失败:', error);
      return {
        success: false,
        message: `连接失败: ${error.message}`
      };
    }
  }

  /**
   * 创建 Bot 执行器规则
   * 每分钟调用 AppScript Web App，获取需要执行的 Bot 消息并推送
   */
  async createBotExecutorRule(config, webAppUrl) {
    // 获取当前用户 Key
    console.log('正在获取当前用户信息...');
    const userKey = await this.getCurrentUserKey(config);
    console.log(`当前用户 Key: ${userKey}`);

    // 获取项目 ID
    console.log('正在获取项目 ID...');
    const projectId = await this.getProjectId(config);
    console.log(`项目 ${config.projectKey} 的 ID: ${projectId}`);

    // 读取 Bot 配置
    console.log('正在读取 Bot 配置...');
    const envConfig = await (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .getEnvConfig */ .Un)();
    const {
      userinfo
    } = await chrome.storage.local.get('userinfo');
    const ruleName = `[${userinfo.fullName.split(' ')[0]}] Scheduled Messages`;
    console.log(`Bot Type: ${envConfig.BOT_TYPE}`);
    console.log(`用户邮箱: ${userinfo.userEmail}`);

    // 从模板创建规则 payload（模板中已包含完整结构和 smart values）
    const templateString = JSON.stringify(_jira_rule_template_json__WEBPACK_IMPORTED_MODULE_0__);
    const rulePayloadString = templateString.replace(/{{RULE_NAME}}/g, ruleName).replace(/{{RULE_VERSION}}/g, JIRA_RULE_VERSION).replace(/{{WEB_APP_URL}}/g, webAppUrl).replace(/{{BOT_API_BASE_URL}}/g, envConfig.BOT_API_BASE_URL).replace(/{{BOT_TOKEN}}/g, envConfig.BOT_TOKEN).replace(/{{BOT_ID}}/g, envConfig.BOT_ID).replace(/{{USER_EMAIL}}/g, userinfo.userEmail).replace(/{{PROJECT_KEY}}/g, config.projectKey).replace(/{{PROJECT_ID}}/g, projectId).replace(/{{USER_KEY}}/g, userKey);
    const rulePayload = JSON.parse(rulePayloadString);

    // 移除 _metadata 字段（这是模板内部使用的，不应发送到 Jira）
    delete rulePayload._metadata;
    console.log('创建 Jira Automation 规则:', ruleName);
    console.log('用户 Key:', userKey);
    console.log('项目 ID:', projectId);
    console.log('Web App URL:', webAppUrl);
    console.log('Bot API Base URL:', envConfig.BOT_API_BASE_URL);
    console.log('Rule Payload:', JSON.stringify(rulePayload, null, 2));
    const url = `${config.jiraUrl}/rest/cb-automation/latest/project/${projectId}/rule`;
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Atlassian-Token': 'no-check',
        ...(config.token ? {
          'Authorization': `Bearer ${config.token}`
        } : {})
      },
      credentials: 'include',
      body: JSON.stringify(rulePayload)
    });
    if (!response.ok) {
      const errorText = await response.text();
      console.error('创建规则失败，响应:', errorText);
      throw new Error(`创建 Jira Automation 规则失败 (${response.status}): ${errorText}`);
    }
    const result = await response.json();
    console.log('创建规则成功:', result);
    return {
      ruleId: String(result.id),
      ruleName: `${ruleName} v${JIRA_RULE_VERSION}`,
      webhookUrl: webAppUrl,
      projectKey: config.projectKey,
      createdAt: new Date().toISOString(),
      ruleVersion: JIRA_RULE_VERSION
    };
  }

  /**
   * 获取项目的所有规则
   */
  async getRules(config) {
    // 获取项目 ID 
    const projectId = await this.getProjectId(config);
    const url = `${config.jiraUrl}/rest/cb-automation/latest/project/${projectId}/rule`;
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...(config.token ? {
          'Authorization': `Bearer ${config.token}`
        } : {})
      },
      credentials: 'include'
    });
    if (!response.ok) {
      throw new Error(`获取规则列表失败 (${response.status})`);
    }
    return await response.json();
  }

  /**
   * 检查规则是否存在
   * 注意：Jira Automation API 不支持直接通过 rule ID 获取单个规则
   * 需要获取项目的所有规则列表，然后查找指定的 rule ID
   */
  async checkRuleExists(config, ruleId) {
    try {
      console.log(`检查规则是否存在: ${ruleId}`);

      // 获取项目的所有规则
      const rules = await this.getRules(config);

      // 在规则列表中查找指定的 rule ID
      const ruleExists = rules.some(rule => rule.id === parseInt(ruleId, 10));
      console.log(`规则 ${ruleId} ${ruleExists ? '存在' : '不存在'}`);
      return ruleExists;
    } catch (error) {
      console.error('检查规则是否存在时出错:', error);
      // 如果获取规则列表失败（可能是权限问题），假定规则存在，避免误报
      return true;
    }
  }

  /**
   * 删除规则
   */
  async deleteRule(config, ruleId) {
    const url = `${config.jiraUrl}/rest/cb-automation/latest/rule/${ruleId}`;
    const response = await fetch(url, {
      method: 'DELETE',
      headers: {
        'X-Atlassian-Token': 'no-check',
        ...(config.token ? {
          'Authorization': `Bearer ${config.token}`
        } : {})
      },
      credentials: 'include'
    });
    if (!response.ok) {
      throw new Error(`删除规则失败 (${response.status})`);
    }
  }

  /**
   * 通过 ID 获取指定规则的完整信息
   * 注意：Jira Automation API 不支持直接通过 rule ID 获取单个规则
   * 需要获取项目的所有规则列表，然后查找指定的 rule ID
   */
  async getRuleById(config, ruleId) {
    try {
      console.log(`获取规则详情: ${ruleId}`);

      // 获取项目的所有规则
      const rules = await this.getRules(config);

      // 在规则列表中查找指定的 rule ID
      const rule = rules.find(r => r.id === parseInt(ruleId, 10));
      if (rule) {
        console.log(`✅ 找到规则 ${ruleId}: ${rule.name}`);
        return rule;
      } else {
        console.log(`❌ 未找到规则 ${ruleId}`);
        return null;
      }
    } catch (error) {
      console.error('获取规则详情时出错:', error);
      throw error;
    }
  }

  /**
   * 更新规则
   * 使用 PUT API 直接更新规则，保持 Rule ID 不变
   * 
   * @param config Jira 配置
   * @param ruleId 规则 ID
   * @param rulePayload 新的规则内容（不含服务器生成的字段如 id, created, updated）
   * @returns 更新后的规则对象
   */
  async updateRule(config, ruleId, rulePayload) {
    // 获取项目 ID
    const projectId = await this.getProjectId(config);

    // 获取现有规则以保留服务器字段
    const existingRule = await this.getRuleById(config, ruleId);
    if (!existingRule) {
      throw new Error(`规则 ${ruleId} 不存在`);
    }

    // 合并现有规则和新 payload
    // 保留服务器生成的字段：id, clientKey, authorAccountId, actorAccountId, created, updated
    const mergedPayload = {
      ...existingRule,
      ...rulePayload,
      // 确保保留这些服务器字段
      id: existingRule.id,
      clientKey: existingRule.clientKey,
      authorAccountId: existingRule.authorAccountId,
      actorAccountId: existingRule.actorAccountId,
      created: existingRule.created,
      updated: existingRule.updated
    };
    console.log(`📝 更新规则 ${ruleId}...`);
    console.log('Rule Payload:', JSON.stringify(mergedPayload, null, 2));
    const url = `${config.jiraUrl}/rest/cb-automation/latest/project/${projectId}/rule/${ruleId}`;
    const response = await fetch(url, {
      method: 'PUT',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'X-Atlassian-Token': 'no-check',
        'Cache-Control': 'no-cache',
        ...(config.token ? {
          'Authorization': `Bearer ${config.token}`
        } : {})
      },
      credentials: 'include',
      body: JSON.stringify(mergedPayload)
    });
    if (!response.ok) {
      const errorText = await response.text();
      console.error('更新规则失败，响应:', errorText);
      throw new Error(`更新 Jira Automation 规则失败 (${response.status}): ${errorText}`);
    }
    const result = await response.json();
    console.log('✅ 规则更新成功:', result.name);
    return result;
  }

  /**
   * 从规则名称中解析版本号
   * 规则名称格式：`[用户名] Scheduled Messages v1.0.0`
   * 
   * @param ruleName 规则名称
   * @returns 版本号，如果无法解析则返回 null
   */
  static parseVersionFromRuleName(ruleName) {
    // 匹配 v 后面的版本号，如 v1.0.0, v2.1.0 等
    const match = ruleName.match(/v(\d+\.\d+\.\d+)/i);
    return match ? match[1] : null;
  }

  /**
   * 获取最新的规则版本号（从模板中读取）
   */
  static getLatestVersion() {
    return JIRA_RULE_VERSION;
  }

  /**
   * 获取规则最后更新日期（从模板中读取）
   */
  static getLatestUpdateDate() {
    return JIRA_RULE_LAST_UPDATED;
  }

  // =====================================================
  // 以下是为 Scheduled Messages 导入功能新增的方法
  // =====================================================

  /**
   * 解析 Scheduled Trigger 的配置信息
   * @param trigger Jira Rule 的 trigger 对象
   * @returns 解析后的调度配置，如果不是 scheduled trigger 则返回 null
   */
  static parseScheduleConfig(trigger) {
    if (!trigger || trigger.type !== 'jira.jql.scheduled') {
      return null;
    }
    const value = trigger.value;
    if (!value || !value.schedule) {
      return null;
    }
    const schedule = value.schedule;
    const executionMode = value.executionMode; // 'nosearch' 或 'jql'

    if (schedule.method === 'CRON') {
      // 解析 Cron 表达式
      return JiraAutomationService.parseCronExpression(schedule.cronExpression, executionMode);
    } else if (schedule.method === 'RATE') {
      // Rate 模式：rate 是间隔数，rateInterval 是间隔分钟数
      // rateInterval: 60 = 分钟, 1440 = 天, 10080 = 周, 43200 = 月（约30天）
      return JiraAutomationService.parseRateConfig(schedule.rate, schedule.rateInterval, executionMode);
    }
    return null;
  }

  /**
   * 解析 Cron 表达式
   * Jira Automation Cron 格式: 秒 分 时 日 月 星期 [年]
   * 例如: "0 9 * * 1-5 ?" = 周一到周五每天 9:00
   */
  static parseCronExpression(cron, executionMode) {
    if (!cron) return null;
    const parts = cron.split(' ');
    if (parts.length < 6) return null;
    const [_seconds, minutes, hours, dayOfMonth, _month, dayOfWeek] = parts;

    // 解析时间
    const timeMinutes = parseInt(minutes, 10) || 0;
    const timeHours = parseInt(hours, 10) || 0;
    const scheduleTime = `${String(timeHours).padStart(2, '0')}:${String(timeMinutes).padStart(2, '0')}`;

    // 解析周期
    let repeatEvery = 1;
    let repeatUnit = 'Day';
    let scheduleDaysOfWeek;

    // 检查是否是每周特定几天
    if (dayOfWeek !== '*' && dayOfWeek !== '?') {
      // 解析星期，支持 1-5, 1,3,5, MON-FRI 等格式
      scheduleDaysOfWeek = JiraAutomationService.parseDaysOfWeek(dayOfWeek);
      if (scheduleDaysOfWeek && scheduleDaysOfWeek.length > 0) {
        repeatUnit = 'Week';
        repeatEvery = 1;
      }
    }

    // 检查是否是每月特定日期
    if (dayOfMonth !== '*' && dayOfMonth !== '?') {
      // 检查是否是每 N 天
      const dayMatch = dayOfMonth.match(/^\*\/(\d+)$/);
      if (dayMatch) {
        repeatEvery = parseInt(dayMatch[1], 10);
        repeatUnit = 'Day';
      } else if (/^\d+$/.test(dayOfMonth)) {
        // 固定日期，视为每月执行
        repeatUnit = 'Month';
        repeatEvery = 1;
      }
    }

    // 计算最近的 Schedule_Date
    const scheduleDate = JiraAutomationService.getNextScheduleDate(timeHours, timeMinutes, repeatUnit, scheduleDaysOfWeek);
    return {
      scheduleDate,
      scheduleTime,
      repeatEvery,
      repeatUnit,
      scheduleDaysOfWeek,
      executionMode,
      triggerMethod: 'CRON',
      originalCron: cron
    };
  }

  /**
   * 解析星期配置
   * 支持格式：1-5, 1,3,5, MON-FRI, MON,WED,FRI
   * 返回数字数组：1=周日, 2=周一, ..., 7=周六（Jira 使用 1-7）
   */
  static parseDaysOfWeek(dayOfWeek) {
    const dayMap = {
      'SUN': 1,
      'MON': 2,
      'TUE': 3,
      'WED': 4,
      'THU': 5,
      'FRI': 6,
      'SAT': 7,
      '1': 1,
      '2': 2,
      '3': 3,
      '4': 4,
      '5': 5,
      '6': 6,
      '7': 7
    };
    const result = [];

    // 处理范围和逗号分隔
    const segments = dayOfWeek.split(',');
    for (const segment of segments) {
      const trimmed = segment.trim().toUpperCase();

      // 检查是否是范围
      if (trimmed.includes('-')) {
        const [start, end] = trimmed.split('-');
        const startNum = dayMap[start.trim()] || parseInt(start.trim(), 10);
        const endNum = dayMap[end.trim()] || parseInt(end.trim(), 10);
        if (!isNaN(startNum) && !isNaN(endNum)) {
          for (let i = startNum; i <= endNum; i++) {
            if (!result.includes(i)) result.push(i);
          }
        }
      } else {
        const num = dayMap[trimmed] || parseInt(trimmed, 10);
        if (!isNaN(num) && !result.includes(num)) {
          result.push(num);
        }
      }
    }
    return result.sort((a, b) => a - b);
  }

  /**
   * 计算最近的调度日期
   */
  static getNextScheduleDate(hours, minutes, repeatUnit, daysOfWeek) {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hours, minutes);
    if (repeatUnit === 'Week' && daysOfWeek && daysOfWeek.length > 0) {
      // 找最近的一个匹配的星期
      // JavaScript Date.getDay(): 0=周日, 1=周一, ..., 6=周六
      // Jira Cron: 1=周日, 2=周一, ..., 7=周六
      const currentJiraDay = now.getDay() + 1; // 转换为 Jira 格式

      // 找今天或之后最近的匹配日
      for (let offset = 0; offset < 7; offset++) {
        const checkDay = (currentJiraDay - 1 + offset) % 7 + 1;
        if (daysOfWeek.includes(checkDay)) {
          const targetDate = new Date(now);
          targetDate.setDate(now.getDate() + offset);

          // 如果是今天但时间已过，继续找下一天
          if (offset === 0 && now > today) {
            continue;
          }
          return targetDate.toISOString().split('T')[0];
        }
      }
    }

    // 默认：如果今天时间已过，用明天
    if (now > today) {
      today.setDate(today.getDate() + 1);
    }
    return today.toISOString().split('T')[0];
  }

  /**
   * 解析 Rate 配置
   */
  static parseRateConfig(rate, rateInterval, executionMode) {
    // rateInterval 是基础单位的分钟数
    // 60 = 分钟, 1440 = 天, 10080 = 周, 43200 = 月

    let repeatUnit = 'Day';
    let repeatEvery = rate;
    if (rateInterval === 1440) {
      // 每 N 天
      repeatUnit = 'Day';
    } else if (rateInterval === 10080) {
      // 每 N 周
      repeatUnit = 'Week';
    } else if (rateInterval === 43200) {
      // 每 N 月
      repeatUnit = 'Month';
    } else if (rateInterval === 60) {
      // 每 N 小时（转换为天）
      repeatUnit = 'Day';
      repeatEvery = 1; // 按天算，精确到小时需要用 cron
    }
    return {
      scheduleDate: undefined,
      // Rate 模式需要从 audit log 获取
      scheduleTime: undefined,
      repeatEvery,
      repeatUnit,
      executionMode,
      triggerMethod: 'RATE',
      rateValue: rate,
      rateInterval
    };
  }

  /**
   * 获取规则的 Audit Log（执行历史）
   */
  async getRuleAuditLog(config, ruleId) {
    let limit = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 50;
    try {
      const projectId = await this.getProjectId(config);
      // 使用正确的 API 路径：/rest/cb-automation/latest/audit/{projectId}?limit={limit}&ruleId={ruleId}&offset=0
      const url = `${config.jiraUrl}/rest/cb-automation/latest/audit/${projectId}?limit=${limit}&ruleId=${ruleId}&offset=0`;
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
          ...(config.token ? {
            'Authorization': `Bearer ${config.token}`
          } : {})
        },
        credentials: 'include'
      });
      if (!response.ok) {
        console.warn(`获取 Audit Log 失败 (${response.status}): ${response.statusText}`);
        return [];
      }
      const data = await response.json();

      // 解析 audit log 数据
      const logs = (data.results || data || []).map(item => ({
        id: item.id,
        timestamp: item.created || item.timestamp,
        state: item.state || item.status,
        duration: item.duration
      }));
      return logs;
    } catch (error) {
      console.error('获取 Audit Log 失败:', error);
      return [];
    }
  }

  /**
   * 获取最近一次成功执行的日期
   */
  async getLastExecutionDate(config, ruleId) {
    const logs = await this.getRuleAuditLog(config, ruleId, 50);

    // 找到最近一次成功执行
    const successLog = logs.find(log => log.state === 'COMPLETED' || log.state === 'SUCCESS');
    if (successLog && successLog.timestamp) {
      // 转换时间戳为日期
      const date = new Date(successLog.timestamp);
      return date.toISOString().split('T')[0];
    }
    return null;
  }

  /**
   * 将 Scheduled Trigger 转换为 Incoming Webhook Trigger
   * 
   * 两步操作：
   * 1. 先获取 securetoken（用于生成 webhook URL）
   * 2. 使用 token 更新 rule 的 trigger 为 incoming webhook
   * 
   * @returns 新生成的 Webhook URL
   */
  async convertToWebhookTrigger(config, ruleId) {
    console.log(`🔄 将规则 ${ruleId} 的 trigger 转换为 incoming webhook...`);

    // 获取项目 ID
    const projectId = await this.getProjectId(config);

    // 获取现有规则
    const existingRule = await this.getRuleById(config, ruleId);
    if (!existingRule) {
      throw new Error(`规则 ${ruleId} 不存在`);
    }

    // 第一步：获取 securetoken
    console.log('📝 步骤1: 获取 securetoken...');
    const tokenUrl = `${config.jiraUrl}/rest/cb-automation/latest/project/${projectId}/securetoken`;
    const tokenResponse = await fetch(tokenUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Cache-Control': 'no-cache',
        ...(config.token ? {
          'Authorization': `Bearer ${config.token}`
        } : {})
      },
      credentials: 'include'
    });
    if (!tokenResponse.ok) {
      const errorText = await tokenResponse.text();
      throw new Error(`获取 securetoken 失败 (${tokenResponse.status}): ${errorText}`);
    }
    const tokenData = await tokenResponse.json();
    const webhookToken = tokenData.token;
    if (!webhookToken) {
      throw new Error('未能获取到 securetoken');
    }
    console.log(`✅ 获取到 securetoken: ${webhookToken.substring(0, 8)}...`);

    // 第二步：使用 token 更新 rule 的 trigger 为 incoming webhook
    console.log('📝 步骤2: 更新 rule trigger 为 incoming webhook...');

    // 创建 incoming webhook trigger，必须包含 webhookToken 和 searchOrProvide
    const webhookTrigger = {
      id: '__NEW__TRIGGER',
      component: 'TRIGGER',
      type: 'jira.incoming.webhook',
      value: {
        webhookToken: webhookToken,
        searchOrProvide: 'provided' // 必须设置，否则会报 null 错误
      }
    };

    // 构建完整的规则更新 payload
    const updatePayload = {
      ...existingRule,
      trigger: webhookTrigger,
      isNewRule: false
    };

    // 直接调用 PUT API 更新规则（不使用 updateRule 方法以避免额外的合并逻辑）
    const updateUrl = `${config.jiraUrl}/rest/cb-automation/latest/project/${projectId}/rule/${ruleId}`;
    const updateResponse = await fetch(updateUrl, {
      method: 'PUT',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
        ...(config.token ? {
          'Authorization': `Bearer ${config.token}`
        } : {})
      },
      credentials: 'include',
      body: JSON.stringify(updatePayload)
    });
    if (!updateResponse.ok) {
      const errorText = await updateResponse.text();
      throw new Error(`更新规则 trigger 失败 (${updateResponse.status}): ${errorText}`);
    }

    // 解析响应确认更新成功
    await updateResponse.json();
    console.log('✅ 规则 trigger 已更新为 incoming webhook');

    // 构建 webhook URL
    // 格式: https://jira.ringcentral.com/rest/cb-automation/latest/hooks/<webhookToken>
    const webhookUrl = `${config.jiraUrl}/rest/cb-automation/latest/hooks/${webhookToken}`;
    console.log(`✅ Webhook URL: ${webhookUrl}`);
    return webhookUrl;
  }

  /**
   * 获取规则的 URL（用于 Automation_Link）
   */
  getRuleUrl(config, ruleId) {
    return `${config.jiraUrl}/jira/software/c/projects/${config.projectKey}/automation#/rule/${ruleId}`;
  }

  /**
   * 将 Incoming Webhook Trigger 转换回 Scheduled Trigger
   * 用于撤销托管时恢复原有的定时触发
   * 
   * @param config Jira 配置
   * @param ruleId 规则 ID
   * @param scheduleConfig 调度配置
   * @returns 更新后的规则
   */
  async convertToScheduledTrigger(config, ruleId, scheduleConfig) {
    console.log(`🔄 将规则 ${ruleId} 的 trigger 转换回 scheduled trigger...`);

    // 获取项目 ID
    const projectId = await this.getProjectId(config);

    // 获取现有规则
    const existingRule = await this.getRuleById(config, ruleId);
    if (!existingRule) {
      throw new Error(`规则 ${ruleId} 不存在`);
    }

    // 生成调度配置
    const schedule = this.generateScheduleConfig(scheduleConfig);
    console.log('📝 生成的调度配置:', JSON.stringify(schedule, null, 2));

    // 创建 scheduled trigger
    const scheduledTrigger = {
      id: '__NEW__TRIGGER',
      component: 'TRIGGER',
      type: 'jira.jql.scheduled',
      value: {
        executionMode: 'nosearch',
        // 使用 nosearch 模式
        schedule: schedule
      }
    };

    // 构建完整的规则更新 payload
    const updatePayload = {
      ...existingRule,
      trigger: scheduledTrigger,
      isNewRule: false
    };

    // 调用 PUT API 更新规则
    const updateUrl = `${config.jiraUrl}/rest/cb-automation/latest/project/${projectId}/rule/${ruleId}`;
    const updateResponse = await fetch(updateUrl, {
      method: 'PUT',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
        ...(config.token ? {
          'Authorization': `Bearer ${config.token}`
        } : {})
      },
      credentials: 'include',
      body: JSON.stringify(updatePayload)
    });
    if (!updateResponse.ok) {
      const errorText = await updateResponse.text();
      throw new Error(`更新规则 trigger 失败 (${updateResponse.status}): ${errorText}`);
    }
    const updatedRule = await updateResponse.json();
    console.log('✅ 规则 trigger 已恢复为 scheduled trigger');
    return updatedRule;
  }

  /**
   * 根据调度配置生成 Jira Automation 的 schedule 对象
   * 优先使用 CRON 方法，如果无法用 CRON 表达则使用 FIXED 方法
   * 
   * 注意：FIXED 方法无法指定具体执行时间，只能指定间隔
   */
  generateScheduleConfig(scheduleConfig) {
    const {
      scheduleTime,
      repeatEvery,
      repeatUnit,
      scheduleDaysOfWeek
    } = scheduleConfig;
    const [hours, minutes] = scheduleTime.split(':').map(Number);

    // 判断是否可以使用 CRON
    // 可以用 CRON 的情况：
    // 1. 每天执行（repeatEvery = 1, repeatUnit = 'Day'）
    // 2. 每 N 天执行（repeatUnit = 'Day', repeatEvery > 1）- 可以用 CRON 的 */N 语法
    // 3. 每周执行（repeatUnit = 'Week', repeatEvery = 1）- 无论是否指定 scheduleDaysOfWeek
    // 4. 每月执行（repeatEvery = 1, repeatUnit = 'Month'）- 需要指定日期，这里用每月1号

    const canUseCron = repeatUnit === 'Day' ||
    // 每天或每 N 天都可以用 CRON
    repeatUnit === 'Week' && repeatEvery === 1 ||
    // 每周执行（每 1 周）
    repeatUnit === 'Month' && repeatEvery === 1;
    if (canUseCron) {
      // 使用 CRON 方法
      const cronExpression = this.generateCronExpression(hours, minutes, repeatUnit, scheduleDaysOfWeek, repeatEvery);
      console.log(`📅 使用 CRON 方法: ${cronExpression}`);
      return {
        method: 'CRON',
        cronExpression: cronExpression,
        rate: 0,
        // CRON 模式下 rate 设为 0
        rateInterval: 60 // 默认值
      };
    } else {
      // 使用 FIXED 方法
      // 注意：FIXED 方法只支持 rate, rateInterval，不支持 rateHour, rateMinute
      // 因此无法指定具体执行时间，只能指定间隔
      // rateInterval 单位是分钟，最大支持 86400 分钟（60 天）
      // - 86400 = 1 天（最大值）
      // - 86400 = 1 周
      // 对于周和月，需要换算成天
      let rate;
      let rateInterval;
      if (repeatUnit === 'Week') {
        // 每 N 周 = 每 (N * 7) 天
        rate = repeatEvery * 7;
        rateInterval = 86400; // 1 天
        console.warn(`⚠️ 使用 FIXED 方法: 每 ${repeatEvery} 周（换算为每 ${rate} 天，无法指定具体执行时间）`);
      } else if (repeatUnit === 'Month') {
        // 每 N 月 = 每 (N * 30) 天
        rate = repeatEvery * 30;
        rateInterval = 86400; // 1 天
        console.warn(`⚠️ 使用 FIXED 方法: 每 ${repeatEvery} 月（换算为每 ${rate} 天，无法指定具体执行时间）`);
      } else {
        // Day 类型不应该走到这里，但作为兜底
        rate = repeatEvery;
        rateInterval = 86400;
        console.warn(`⚠️ 使用 FIXED 方法: 每 ${rate} 天（无法指定具体执行时间）`);
      }

      // FIXED 方法只需要 rate 和 rateInterval
      return {
        method: 'FIXED',
        rate: rate,
        rateInterval: rateInterval,
        cronExpression: '' // FIXED 模式下 cronExpression 为空
      };
    }
  }

  /**
   * 生成 CRON 表达式
   * Jira Automation CRON 格式: seconds minutes hours dayOfMonth month dayOfWeek
   */
  generateCronExpression(hours, minutes, repeatUnit, scheduleDaysOfWeek) {
    let repeatEvery = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 1;
    // 格式: 秒 分 时 日 月 周
    const seconds = '0';
    const minutesPart = String(minutes);
    const hoursPart = String(hours);
    switch (repeatUnit) {
      case 'Day':
        if (repeatEvery === 1) {
          // 每天执行: 0 30 9 * * ?
          return `${seconds} ${minutesPart} ${hoursPart} * * ?`;
        } else {
          // 每 N 天执行: 0 30 9 */N * ?
          return `${seconds} ${minutesPart} ${hoursPart} */${repeatEvery} * ?`;
        }
      case 'Week':
        // 每周特定几天执行: 0 30 9 ? * MON,WED,FRI
        if (scheduleDaysOfWeek && scheduleDaysOfWeek.length > 0) {
          const dayNames = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
          // Jira 的周日是 1，周一是 2，... 周六是 7
          // 转换为 CRON 格式（SUN, MON, TUE, ...）
          const cronDays = scheduleDaysOfWeek.map(d => dayNames[(d - 1) % 7]) // d: 1=SUN, 2=MON, ...
          .join(',');
          return `${seconds} ${minutesPart} ${hoursPart} ? * ${cronDays}`;
        }
        // 默认每周一
        return `${seconds} ${minutesPart} ${hoursPart} ? * MON`;
      case 'Month':
        // 每月1号执行: 0 30 9 1 * ?
        return `${seconds} ${minutesPart} ${hoursPart} 1 * ?`;
      default:
        return `${seconds} ${minutesPart} ${hoursPart} * * ?`;
    }
  }
}

/**
 * 解析后的调度配置
 */

/**
 * 规则执行日志
 */

/***/ }),

/***/ 3922:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Un: () => (/* binding */ getEnvConfig)
/* harmony export */ });
/* unused harmony exports formatDate, uniqBy, showToast, transformGroupLinks, transformPostLinks, defaultEnvConfig, getDefaultEnvConfig, getUserInfo, parseChromaConfig */
// 环境配置类型定义

function formatDate(dateString) {
  const date = new Date(dateString);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}
function uniqBy(array, key) {
  const seen = new Set();
  return array.filter(item => {
    const keyValue = item[key];
    if (seen.has(keyValue)) {
      return false;
    }
    seen.add(keyValue);
    return true;
  });
}
function showToast(message, type, onClose) {
  // 获取或创建容器元素
  const container = document.getElementById('radar-poc-result');
  if (!container) return;

  // 移除现有的 Toast 元素
  const existingToast = container.querySelector('.radar-poc-toast');
  if (existingToast) {
    container.removeChild(existingToast);
  }

  // 创建新的 Toast 元素
  const toast = document.createElement('div');
  toast.className = `radar-poc-toast radar-poc-toast-${type}`;
  const toastInner = document.createElement('div');
  toastInner.className = 'radar-poc-toast-inner';
  toastInner.textContent = message;
  toast.appendChild(toastInner);
  container.appendChild(toast);

  // 设置定时器在 3 秒后关闭 Toast
  const timer = setTimeout(() => {
    if (container.contains(toast)) {
      container.removeChild(toast);
    }
    if (onClose) {
      onClose();
    }
  }, 3000);

  // 返回一个函数以便手动关闭 Toast
  return () => {
    clearTimeout(timer);
    if (container.contains(toast)) {
      container.removeChild(toast);
    }
    if (onClose) {
      onClose();
    }
  };
}
function transformGroupLinks(inputString) {
  const groupLinkPattern = /\[group:(.+):(\d+)\]/g;
  const transformedString = inputString.replace(groupLinkPattern, (match, groupName, groupId) => {
    return `[${groupName}](/messages/${groupId})`;
  });
  return transformedString;
}
function transformPostLinks(inputString) {
  const postLinkPattern = /\[post:(\d+)\]/g;
  let index = 1;
  const transformedString = inputString.replace(postLinkPattern, (match, postId) => {
    return `[[${index++}]](/l${window.location.pathname}/${postId})`;
  });
  return transformedString;
}

// 默认环境配置
const defaultEnvConfig = {
  MESSAGE_ANALYSIS_INTERVAL: Number({"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.MESSAGE_ANALYSIS_INTERVAL) || Number({"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.SCHEDULED_INTERVAL) || 120,
  MESSAGE_CONTEXT_WINDOW: Number({"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.MESSAGE_CONTEXT_WINDOW) || 5,
  SCHEDULED_INTERVAL: Number({"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.SCHEDULED_INTERVAL) || 120,
  // 保留用于向后兼容
  ANALYSIS_TYPE: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.ANALYSIS_TYPE || "filter",
  LLM_TYPE: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.LLM_TYPE || "dify",
  ANALYZE_BY_GROUP: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.ANALYZE_BY_GROUP === "true",
  OLLAMA_BASE_URL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OLLAMA_BASE_URL || "http://localhost:11434",
  OLLAMA_MODEL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OLLAMA_MODEL || "deepseek-r1",
  OLLAMA_REVIEW_MODEL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OLLAMA_REVIEW_MODEL || "llama3.1",
  OLLAMA_QUERY_MODEL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OLLAMA_QUERY_MODEL || "llama3.1",
  DIFY_API_KEY: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.DIFY_API_KEY || "",
  DIFY_REVIEW_API_KEY: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.DIFY_REVIEW_API_KEY || "",
  DIFY_API_BASE_URL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.DIFY_API_BASE_URL || "",
  OPENAI_API_KEY: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OPENAI_API_KEY || "",
  OPENAI_MODEL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OPENAI_MODEL || "",
  OPENAI_REVIEW_MODEL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OPENAI_REVIEW_MODEL || "",
  OPENAI_API_BASE_URL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OPENAI_API_BASE_URL || "",
  GROQ_API_KEY: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.GROQ_API_KEY || "",
  GROQ_MODEL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.GROQ_MODEL || "",
  GROQ_REVIEW_MODEL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.GROQ_REVIEW_MODEL || "",
  BOT_API_BASE_URL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.BOT_API_BASE_URL || "https://botman.int.rclabenv.com/v2",
  BOT_TOKEN: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.BOT_TOKEN || "",
  BOT_ID: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.BOT_ID || "4700372020@37439510.bot.glip.net",
  BOT_TYPE: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.BOT_TYPE || "user",
  TEAM_ID: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.TEAM_ID || "",
  ENABLE_BOT: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.ENABLE_BOT === "true",
  LLM_REVIEW_BEFORE_SEND: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.LLM_REVIEW_BEFORE_SEND === "true",
  ENABLE_CHROMA: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.ENABLE_CHROMA === "true",
  CHROMA_API_URL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.CHROMA_API_URL || "http://localhost:8000",
  // 保留用于兼容
  CHROMA_HOST: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.CHROMA_HOST || "localhost",
  CHROMA_PORT: Number({"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.CHROMA_PORT) || 8000,
  CHROMA_SSL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.CHROMA_SSL === "true",
  CHROMA_COLLECTION_NAME: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.CHROMA_COLLECTION_NAME || "",
  JIRA_BASE_URL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.JIRA_BASE_URL || "https://jira.ringcentral.com",
  JIRA_USERNAME: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.JIRA_USERNAME || "",
  JIRA_API_TOKEN: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.JIRA_API_TOKEN || ""
};

// 获取环境配置，如果可能的话从 storage 获取，否则从 process.env 获取
async function getEnvConfig() {
  try {
    const {
      envConfig
    } = await chrome.storage.local.get(['envConfig']);
    if (envConfig) {
      // 将存储的配置与默认配置合并，确保新增的配置项也会被包含
      return {
        ...defaultEnvConfig,
        ...envConfig
      };
    }
  } catch (error) {
    console.error('获取配置失败:', error);
  }

  // 如果获取失败或没有保存的配置，返回默认值
  return defaultEnvConfig;
}
function getDefaultEnvConfig() {
  return defaultEnvConfig;
}
async function getUserInfo() {
  const {
    userinfo
  } = await chrome.storage.local.get(['userinfo']);
  return userinfo;
}

/**
 * 解析 ChromaDB 连接参数，支持新旧配置格式的兼容
 */
function parseChromaConfig(config) {
  // 如果有新的 host 配置，直接使用
  if (config.CHROMA_HOST && config.CHROMA_HOST !== 'localhost') {
    return {
      host: config.CHROMA_HOST,
      port: config.CHROMA_PORT,
      ssl: config.CHROMA_SSL
    };
  }

  // 如果没有配置新的 host，尝试从旧的 CHROMA_API_URL 解析
  if (config.CHROMA_API_URL) {
    try {
      const url = new URL(config.CHROMA_API_URL);
      return {
        host: url.hostname,
        port: url.port ? parseInt(url.port) : url.protocol === 'https:' ? 443 : 8000,
        ssl: url.protocol === 'https:'
      };
    } catch (error) {
      console.warn('解析 CHROMA_API_URL 失败:', error);
      // 回退到默认值
      return {
        host: 'localhost',
        port: config.CHROMA_PORT || 8000,
        ssl: false
      };
    }
  }

  // 都没有配置，使用默认值
  return {
    host: config.CHROMA_HOST || 'localhost',
    port: config.CHROMA_PORT || 8000,
    ssl: config.CHROMA_SSL || false
  };
}

/***/ }),

/***/ 4146:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



var reactIs = __webpack_require__(3404);

/**
 * Copyright 2015, Yahoo! Inc.
 * Copyrights licensed under the New BSD License. See the accompanying LICENSE file for terms.
 */
var REACT_STATICS = {
  childContextTypes: true,
  contextType: true,
  contextTypes: true,
  defaultProps: true,
  displayName: true,
  getDefaultProps: true,
  getDerivedStateFromError: true,
  getDerivedStateFromProps: true,
  mixins: true,
  propTypes: true,
  type: true
};
var KNOWN_STATICS = {
  name: true,
  length: true,
  prototype: true,
  caller: true,
  callee: true,
  arguments: true,
  arity: true
};
var FORWARD_REF_STATICS = {
  '$$typeof': true,
  render: true,
  defaultProps: true,
  displayName: true,
  propTypes: true
};
var MEMO_STATICS = {
  '$$typeof': true,
  compare: true,
  defaultProps: true,
  displayName: true,
  propTypes: true,
  type: true
};
var TYPE_STATICS = {};
TYPE_STATICS[reactIs.ForwardRef] = FORWARD_REF_STATICS;
TYPE_STATICS[reactIs.Memo] = MEMO_STATICS;

function getStatics(component) {
  // React v16.11 and below
  if (reactIs.isMemo(component)) {
    return MEMO_STATICS;
  } // React v16.12 and above


  return TYPE_STATICS[component['$$typeof']] || REACT_STATICS;
}

var defineProperty = Object.defineProperty;
var getOwnPropertyNames = Object.getOwnPropertyNames;
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var getPrototypeOf = Object.getPrototypeOf;
var objectPrototype = Object.prototype;
function hoistNonReactStatics(targetComponent, sourceComponent, blacklist) {
  if (typeof sourceComponent !== 'string') {
    // don't hoist over string (html) components
    if (objectPrototype) {
      var inheritedComponent = getPrototypeOf(sourceComponent);

      if (inheritedComponent && inheritedComponent !== objectPrototype) {
        hoistNonReactStatics(targetComponent, inheritedComponent, blacklist);
      }
    }

    var keys = getOwnPropertyNames(sourceComponent);

    if (getOwnPropertySymbols) {
      keys = keys.concat(getOwnPropertySymbols(sourceComponent));
    }

    var targetStatics = getStatics(targetComponent);
    var sourceStatics = getStatics(sourceComponent);

    for (var i = 0; i < keys.length; ++i) {
      var key = keys[i];

      if (!KNOWN_STATICS[key] && !(blacklist && blacklist[key]) && !(sourceStatics && sourceStatics[key]) && !(targetStatics && targetStatics[key])) {
        var descriptor = getOwnPropertyDescriptor(sourceComponent, key);

        try {
          // Avoid failures from read-only properties
          defineProperty(targetComponent, key, descriptor);
        } catch (e) {}
      }
    }
  }

  return targetComponent;
}

module.exports = hoistNonReactStatics;


/***/ }),

/***/ 3072:
/***/ ((__unused_webpack_module, exports) => {

/** @license React v16.13.1
 * react-is.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var b="function"===typeof Symbol&&Symbol.for,c=b?Symbol.for("react.element"):60103,d=b?Symbol.for("react.portal"):60106,e=b?Symbol.for("react.fragment"):60107,f=b?Symbol.for("react.strict_mode"):60108,g=b?Symbol.for("react.profiler"):60114,h=b?Symbol.for("react.provider"):60109,k=b?Symbol.for("react.context"):60110,l=b?Symbol.for("react.async_mode"):60111,m=b?Symbol.for("react.concurrent_mode"):60111,n=b?Symbol.for("react.forward_ref"):60112,p=b?Symbol.for("react.suspense"):60113,q=b?
Symbol.for("react.suspense_list"):60120,r=b?Symbol.for("react.memo"):60115,t=b?Symbol.for("react.lazy"):60116,v=b?Symbol.for("react.block"):60121,w=b?Symbol.for("react.fundamental"):60117,x=b?Symbol.for("react.responder"):60118,y=b?Symbol.for("react.scope"):60119;
function z(a){if("object"===typeof a&&null!==a){var u=a.$$typeof;switch(u){case c:switch(a=a.type,a){case l:case m:case e:case g:case f:case p:return a;default:switch(a=a&&a.$$typeof,a){case k:case n:case t:case r:case h:return a;default:return u}}case d:return u}}}function A(a){return z(a)===m}exports.AsyncMode=l;exports.ConcurrentMode=m;exports.ContextConsumer=k;exports.ContextProvider=h;exports.Element=c;exports.ForwardRef=n;exports.Fragment=e;exports.Lazy=t;exports.Memo=r;exports.Portal=d;
exports.Profiler=g;exports.StrictMode=f;exports.Suspense=p;exports.isAsyncMode=function(a){return A(a)||z(a)===l};exports.isConcurrentMode=A;exports.isContextConsumer=function(a){return z(a)===k};exports.isContextProvider=function(a){return z(a)===h};exports.isElement=function(a){return"object"===typeof a&&null!==a&&a.$$typeof===c};exports.isForwardRef=function(a){return z(a)===n};exports.isFragment=function(a){return z(a)===e};exports.isLazy=function(a){return z(a)===t};
exports.isMemo=function(a){return z(a)===r};exports.isPortal=function(a){return z(a)===d};exports.isProfiler=function(a){return z(a)===g};exports.isStrictMode=function(a){return z(a)===f};exports.isSuspense=function(a){return z(a)===p};
exports.isValidElementType=function(a){return"string"===typeof a||"function"===typeof a||a===e||a===m||a===g||a===f||a===p||a===q||"object"===typeof a&&null!==a&&(a.$$typeof===t||a.$$typeof===r||a.$$typeof===h||a.$$typeof===k||a.$$typeof===n||a.$$typeof===w||a.$$typeof===x||a.$$typeof===y||a.$$typeof===v)};exports.typeOf=z;


/***/ }),

/***/ 3404:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



if (true) {
  module.exports = __webpack_require__(3072);
} else {}


/***/ }),

/***/ 5228:
/***/ ((module) => {

/*
object-assign
(c) Sindre Sorhus
@license MIT
*/


/* eslint-disable no-unused-vars */
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;

function toObject(val) {
	if (val === null || val === undefined) {
		throw new TypeError('Object.assign cannot be called with null or undefined');
	}

	return Object(val);
}

function shouldUseNative() {
	try {
		if (!Object.assign) {
			return false;
		}

		// Detect buggy property enumeration order in older V8 versions.

		// https://bugs.chromium.org/p/v8/issues/detail?id=4118
		var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
		test1[5] = 'de';
		if (Object.getOwnPropertyNames(test1)[0] === '5') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test2 = {};
		for (var i = 0; i < 10; i++) {
			test2['_' + String.fromCharCode(i)] = i;
		}
		var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
			return test2[n];
		});
		if (order2.join('') !== '0123456789') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test3 = {};
		'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
			test3[letter] = letter;
		});
		if (Object.keys(Object.assign({}, test3)).join('') !==
				'abcdefghijklmnopqrst') {
			return false;
		}

		return true;
	} catch (err) {
		// We don't expect any of the above to throw, but better to be safe.
		return false;
	}
}

module.exports = shouldUseNative() ? Object.assign : function (target, source) {
	var from;
	var to = toObject(target);
	var symbols;

	for (var s = 1; s < arguments.length; s++) {
		from = Object(arguments[s]);

		for (var key in from) {
			if (hasOwnProperty.call(from, key)) {
				to[key] = from[key];
			}
		}

		if (getOwnPropertySymbols) {
			symbols = getOwnPropertySymbols(from);
			for (var i = 0; i < symbols.length; i++) {
				if (propIsEnumerable.call(from, symbols[i])) {
					to[symbols[i]] = from[symbols[i]];
				}
			}
		}
	}

	return to;
};


/***/ }),

/***/ 2551:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var __webpack_unused_export__;
/** @license React v17.0.2
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/*
 Modernizr 3.0.0pre (Custom Build) | MIT
*/
var aa=__webpack_require__(6540),m=__webpack_require__(5228),r=__webpack_require__(9982);function y(a){for(var b="https://reactjs.org/docs/error-decoder.html?invariant="+a,c=1;c<arguments.length;c++)b+="&args[]="+encodeURIComponent(arguments[c]);return"Minified React error #"+a+"; visit "+b+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}if(!aa)throw Error(y(227));var ba=new Set,ca={};function da(a,b){ea(a,b);ea(a+"Capture",b)}
function ea(a,b){ca[a]=b;for(a=0;a<b.length;a++)ba.add(b[a])}
var fa=!("undefined"===typeof window||"undefined"===typeof window.document||"undefined"===typeof window.document.createElement),ha=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,ia=Object.prototype.hasOwnProperty,
ja={},ka={};function la(a){if(ia.call(ka,a))return!0;if(ia.call(ja,a))return!1;if(ha.test(a))return ka[a]=!0;ja[a]=!0;return!1}function ma(a,b,c,d){if(null!==c&&0===c.type)return!1;switch(typeof b){case "function":case "symbol":return!0;case "boolean":if(d)return!1;if(null!==c)return!c.acceptsBooleans;a=a.toLowerCase().slice(0,5);return"data-"!==a&&"aria-"!==a;default:return!1}}
function na(a,b,c,d){if(null===b||"undefined"===typeof b||ma(a,b,c,d))return!0;if(d)return!1;if(null!==c)switch(c.type){case 3:return!b;case 4:return!1===b;case 5:return isNaN(b);case 6:return isNaN(b)||1>b}return!1}function B(a,b,c,d,e,f,g){this.acceptsBooleans=2===b||3===b||4===b;this.attributeName=d;this.attributeNamespace=e;this.mustUseProperty=c;this.propertyName=a;this.type=b;this.sanitizeURL=f;this.removeEmptyString=g}var D={};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a){D[a]=new B(a,0,!1,a,null,!1,!1)});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(a){var b=a[0];D[b]=new B(b,1,!1,a[1],null,!1,!1)});["contentEditable","draggable","spellCheck","value"].forEach(function(a){D[a]=new B(a,2,!1,a.toLowerCase(),null,!1,!1)});
["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(a){D[a]=new B(a,2,!1,a,null,!1,!1)});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a){D[a]=new B(a,3,!1,a.toLowerCase(),null,!1,!1)});
["checked","multiple","muted","selected"].forEach(function(a){D[a]=new B(a,3,!0,a,null,!1,!1)});["capture","download"].forEach(function(a){D[a]=new B(a,4,!1,a,null,!1,!1)});["cols","rows","size","span"].forEach(function(a){D[a]=new B(a,6,!1,a,null,!1,!1)});["rowSpan","start"].forEach(function(a){D[a]=new B(a,5,!1,a.toLowerCase(),null,!1,!1)});var oa=/[\-:]([a-z])/g;function pa(a){return a[1].toUpperCase()}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a){var b=a.replace(oa,
pa);D[b]=new B(b,1,!1,a,null,!1,!1)});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a){var b=a.replace(oa,pa);D[b]=new B(b,1,!1,a,"http://www.w3.org/1999/xlink",!1,!1)});["xml:base","xml:lang","xml:space"].forEach(function(a){var b=a.replace(oa,pa);D[b]=new B(b,1,!1,a,"http://www.w3.org/XML/1998/namespace",!1,!1)});["tabIndex","crossOrigin"].forEach(function(a){D[a]=new B(a,1,!1,a.toLowerCase(),null,!1,!1)});
D.xlinkHref=new B("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);["src","href","action","formAction"].forEach(function(a){D[a]=new B(a,1,!1,a.toLowerCase(),null,!0,!0)});
function qa(a,b,c,d){var e=D.hasOwnProperty(b)?D[b]:null;var f=null!==e?0===e.type:d?!1:!(2<b.length)||"o"!==b[0]&&"O"!==b[0]||"n"!==b[1]&&"N"!==b[1]?!1:!0;f||(na(b,c,e,d)&&(c=null),d||null===e?la(b)&&(null===c?a.removeAttribute(b):a.setAttribute(b,""+c)):e.mustUseProperty?a[e.propertyName]=null===c?3===e.type?!1:"":c:(b=e.attributeName,d=e.attributeNamespace,null===c?a.removeAttribute(b):(e=e.type,c=3===e||4===e&&!0===c?"":""+c,d?a.setAttributeNS(d,b,c):a.setAttribute(b,c))))}
var ra=aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,sa=60103,ta=60106,ua=60107,wa=60108,xa=60114,ya=60109,za=60110,Aa=60112,Ba=60113,Ca=60120,Da=60115,Ea=60116,Fa=60121,Ga=60128,Ha=60129,Ia=60130,Ja=60131;
if("function"===typeof Symbol&&Symbol.for){var E=Symbol.for;sa=E("react.element");ta=E("react.portal");ua=E("react.fragment");wa=E("react.strict_mode");xa=E("react.profiler");ya=E("react.provider");za=E("react.context");Aa=E("react.forward_ref");Ba=E("react.suspense");Ca=E("react.suspense_list");Da=E("react.memo");Ea=E("react.lazy");Fa=E("react.block");E("react.scope");Ga=E("react.opaque.id");Ha=E("react.debug_trace_mode");Ia=E("react.offscreen");Ja=E("react.legacy_hidden")}
var Ka="function"===typeof Symbol&&Symbol.iterator;function La(a){if(null===a||"object"!==typeof a)return null;a=Ka&&a[Ka]||a["@@iterator"];return"function"===typeof a?a:null}var Ma;function Na(a){if(void 0===Ma)try{throw Error();}catch(c){var b=c.stack.trim().match(/\n( *(at )?)/);Ma=b&&b[1]||""}return"\n"+Ma+a}var Oa=!1;
function Pa(a,b){if(!a||Oa)return"";Oa=!0;var c=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(b)if(b=function(){throw Error();},Object.defineProperty(b.prototype,"props",{set:function(){throw Error();}}),"object"===typeof Reflect&&Reflect.construct){try{Reflect.construct(b,[])}catch(k){var d=k}Reflect.construct(a,[],b)}else{try{b.call()}catch(k){d=k}a.call(b.prototype)}else{try{throw Error();}catch(k){d=k}a()}}catch(k){if(k&&d&&"string"===typeof k.stack){for(var e=k.stack.split("\n"),
f=d.stack.split("\n"),g=e.length-1,h=f.length-1;1<=g&&0<=h&&e[g]!==f[h];)h--;for(;1<=g&&0<=h;g--,h--)if(e[g]!==f[h]){if(1!==g||1!==h){do if(g--,h--,0>h||e[g]!==f[h])return"\n"+e[g].replace(" at new "," at ");while(1<=g&&0<=h)}break}}}finally{Oa=!1,Error.prepareStackTrace=c}return(a=a?a.displayName||a.name:"")?Na(a):""}
function Qa(a){switch(a.tag){case 5:return Na(a.type);case 16:return Na("Lazy");case 13:return Na("Suspense");case 19:return Na("SuspenseList");case 0:case 2:case 15:return a=Pa(a.type,!1),a;case 11:return a=Pa(a.type.render,!1),a;case 22:return a=Pa(a.type._render,!1),a;case 1:return a=Pa(a.type,!0),a;default:return""}}
function Ra(a){if(null==a)return null;if("function"===typeof a)return a.displayName||a.name||null;if("string"===typeof a)return a;switch(a){case ua:return"Fragment";case ta:return"Portal";case xa:return"Profiler";case wa:return"StrictMode";case Ba:return"Suspense";case Ca:return"SuspenseList"}if("object"===typeof a)switch(a.$$typeof){case za:return(a.displayName||"Context")+".Consumer";case ya:return(a._context.displayName||"Context")+".Provider";case Aa:var b=a.render;b=b.displayName||b.name||"";
return a.displayName||(""!==b?"ForwardRef("+b+")":"ForwardRef");case Da:return Ra(a.type);case Fa:return Ra(a._render);case Ea:b=a._payload;a=a._init;try{return Ra(a(b))}catch(c){}}return null}function Sa(a){switch(typeof a){case "boolean":case "number":case "object":case "string":case "undefined":return a;default:return""}}function Ta(a){var b=a.type;return(a=a.nodeName)&&"input"===a.toLowerCase()&&("checkbox"===b||"radio"===b)}
function Ua(a){var b=Ta(a)?"checked":"value",c=Object.getOwnPropertyDescriptor(a.constructor.prototype,b),d=""+a[b];if(!a.hasOwnProperty(b)&&"undefined"!==typeof c&&"function"===typeof c.get&&"function"===typeof c.set){var e=c.get,f=c.set;Object.defineProperty(a,b,{configurable:!0,get:function(){return e.call(this)},set:function(a){d=""+a;f.call(this,a)}});Object.defineProperty(a,b,{enumerable:c.enumerable});return{getValue:function(){return d},setValue:function(a){d=""+a},stopTracking:function(){a._valueTracker=
null;delete a[b]}}}}function Va(a){a._valueTracker||(a._valueTracker=Ua(a))}function Wa(a){if(!a)return!1;var b=a._valueTracker;if(!b)return!0;var c=b.getValue();var d="";a&&(d=Ta(a)?a.checked?"true":"false":a.value);a=d;return a!==c?(b.setValue(a),!0):!1}function Xa(a){a=a||("undefined"!==typeof document?document:void 0);if("undefined"===typeof a)return null;try{return a.activeElement||a.body}catch(b){return a.body}}
function Ya(a,b){var c=b.checked;return m({},b,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:null!=c?c:a._wrapperState.initialChecked})}function Za(a,b){var c=null==b.defaultValue?"":b.defaultValue,d=null!=b.checked?b.checked:b.defaultChecked;c=Sa(null!=b.value?b.value:c);a._wrapperState={initialChecked:d,initialValue:c,controlled:"checkbox"===b.type||"radio"===b.type?null!=b.checked:null!=b.value}}function $a(a,b){b=b.checked;null!=b&&qa(a,"checked",b,!1)}
function ab(a,b){$a(a,b);var c=Sa(b.value),d=b.type;if(null!=c)if("number"===d){if(0===c&&""===a.value||a.value!=c)a.value=""+c}else a.value!==""+c&&(a.value=""+c);else if("submit"===d||"reset"===d){a.removeAttribute("value");return}b.hasOwnProperty("value")?bb(a,b.type,c):b.hasOwnProperty("defaultValue")&&bb(a,b.type,Sa(b.defaultValue));null==b.checked&&null!=b.defaultChecked&&(a.defaultChecked=!!b.defaultChecked)}
function cb(a,b,c){if(b.hasOwnProperty("value")||b.hasOwnProperty("defaultValue")){var d=b.type;if(!("submit"!==d&&"reset"!==d||void 0!==b.value&&null!==b.value))return;b=""+a._wrapperState.initialValue;c||b===a.value||(a.value=b);a.defaultValue=b}c=a.name;""!==c&&(a.name="");a.defaultChecked=!!a._wrapperState.initialChecked;""!==c&&(a.name=c)}
function bb(a,b,c){if("number"!==b||Xa(a.ownerDocument)!==a)null==c?a.defaultValue=""+a._wrapperState.initialValue:a.defaultValue!==""+c&&(a.defaultValue=""+c)}function db(a){var b="";aa.Children.forEach(a,function(a){null!=a&&(b+=a)});return b}function eb(a,b){a=m({children:void 0},b);if(b=db(b.children))a.children=b;return a}
function fb(a,b,c,d){a=a.options;if(b){b={};for(var e=0;e<c.length;e++)b["$"+c[e]]=!0;for(c=0;c<a.length;c++)e=b.hasOwnProperty("$"+a[c].value),a[c].selected!==e&&(a[c].selected=e),e&&d&&(a[c].defaultSelected=!0)}else{c=""+Sa(c);b=null;for(e=0;e<a.length;e++){if(a[e].value===c){a[e].selected=!0;d&&(a[e].defaultSelected=!0);return}null!==b||a[e].disabled||(b=a[e])}null!==b&&(b.selected=!0)}}
function gb(a,b){if(null!=b.dangerouslySetInnerHTML)throw Error(y(91));return m({},b,{value:void 0,defaultValue:void 0,children:""+a._wrapperState.initialValue})}function hb(a,b){var c=b.value;if(null==c){c=b.children;b=b.defaultValue;if(null!=c){if(null!=b)throw Error(y(92));if(Array.isArray(c)){if(!(1>=c.length))throw Error(y(93));c=c[0]}b=c}null==b&&(b="");c=b}a._wrapperState={initialValue:Sa(c)}}
function ib(a,b){var c=Sa(b.value),d=Sa(b.defaultValue);null!=c&&(c=""+c,c!==a.value&&(a.value=c),null==b.defaultValue&&a.defaultValue!==c&&(a.defaultValue=c));null!=d&&(a.defaultValue=""+d)}function jb(a){var b=a.textContent;b===a._wrapperState.initialValue&&""!==b&&null!==b&&(a.value=b)}var kb={html:"http://www.w3.org/1999/xhtml",mathml:"http://www.w3.org/1998/Math/MathML",svg:"http://www.w3.org/2000/svg"};
function lb(a){switch(a){case "svg":return"http://www.w3.org/2000/svg";case "math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function mb(a,b){return null==a||"http://www.w3.org/1999/xhtml"===a?lb(b):"http://www.w3.org/2000/svg"===a&&"foreignObject"===b?"http://www.w3.org/1999/xhtml":a}
var nb,ob=function(a){return"undefined"!==typeof MSApp&&MSApp.execUnsafeLocalFunction?function(b,c,d,e){MSApp.execUnsafeLocalFunction(function(){return a(b,c,d,e)})}:a}(function(a,b){if(a.namespaceURI!==kb.svg||"innerHTML"in a)a.innerHTML=b;else{nb=nb||document.createElement("div");nb.innerHTML="<svg>"+b.valueOf().toString()+"</svg>";for(b=nb.firstChild;a.firstChild;)a.removeChild(a.firstChild);for(;b.firstChild;)a.appendChild(b.firstChild)}});
function pb(a,b){if(b){var c=a.firstChild;if(c&&c===a.lastChild&&3===c.nodeType){c.nodeValue=b;return}}a.textContent=b}
var qb={animationIterationCount:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,
floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},rb=["Webkit","ms","Moz","O"];Object.keys(qb).forEach(function(a){rb.forEach(function(b){b=b+a.charAt(0).toUpperCase()+a.substring(1);qb[b]=qb[a]})});function sb(a,b,c){return null==b||"boolean"===typeof b||""===b?"":c||"number"!==typeof b||0===b||qb.hasOwnProperty(a)&&qb[a]?(""+b).trim():b+"px"}
function tb(a,b){a=a.style;for(var c in b)if(b.hasOwnProperty(c)){var d=0===c.indexOf("--"),e=sb(c,b[c],d);"float"===c&&(c="cssFloat");d?a.setProperty(c,e):a[c]=e}}var ub=m({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});
function vb(a,b){if(b){if(ub[a]&&(null!=b.children||null!=b.dangerouslySetInnerHTML))throw Error(y(137,a));if(null!=b.dangerouslySetInnerHTML){if(null!=b.children)throw Error(y(60));if(!("object"===typeof b.dangerouslySetInnerHTML&&"__html"in b.dangerouslySetInnerHTML))throw Error(y(61));}if(null!=b.style&&"object"!==typeof b.style)throw Error(y(62));}}
function wb(a,b){if(-1===a.indexOf("-"))return"string"===typeof b.is;switch(a){case "annotation-xml":case "color-profile":case "font-face":case "font-face-src":case "font-face-uri":case "font-face-format":case "font-face-name":case "missing-glyph":return!1;default:return!0}}function xb(a){a=a.target||a.srcElement||window;a.correspondingUseElement&&(a=a.correspondingUseElement);return 3===a.nodeType?a.parentNode:a}var yb=null,zb=null,Ab=null;
function Bb(a){if(a=Cb(a)){if("function"!==typeof yb)throw Error(y(280));var b=a.stateNode;b&&(b=Db(b),yb(a.stateNode,a.type,b))}}function Eb(a){zb?Ab?Ab.push(a):Ab=[a]:zb=a}function Fb(){if(zb){var a=zb,b=Ab;Ab=zb=null;Bb(a);if(b)for(a=0;a<b.length;a++)Bb(b[a])}}function Gb(a,b){return a(b)}function Hb(a,b,c,d,e){return a(b,c,d,e)}function Ib(){}var Jb=Gb,Kb=!1,Lb=!1;function Mb(){if(null!==zb||null!==Ab)Ib(),Fb()}
function Nb(a,b,c){if(Lb)return a(b,c);Lb=!0;try{return Jb(a,b,c)}finally{Lb=!1,Mb()}}
function Ob(a,b){var c=a.stateNode;if(null===c)return null;var d=Db(c);if(null===d)return null;c=d[b];a:switch(b){case "onClick":case "onClickCapture":case "onDoubleClick":case "onDoubleClickCapture":case "onMouseDown":case "onMouseDownCapture":case "onMouseMove":case "onMouseMoveCapture":case "onMouseUp":case "onMouseUpCapture":case "onMouseEnter":(d=!d.disabled)||(a=a.type,d=!("button"===a||"input"===a||"select"===a||"textarea"===a));a=!d;break a;default:a=!1}if(a)return null;if(c&&"function"!==
typeof c)throw Error(y(231,b,typeof c));return c}var Pb=!1;if(fa)try{var Qb={};Object.defineProperty(Qb,"passive",{get:function(){Pb=!0}});window.addEventListener("test",Qb,Qb);window.removeEventListener("test",Qb,Qb)}catch(a){Pb=!1}function Rb(a,b,c,d,e,f,g,h,k){var l=Array.prototype.slice.call(arguments,3);try{b.apply(c,l)}catch(n){this.onError(n)}}var Sb=!1,Tb=null,Ub=!1,Vb=null,Wb={onError:function(a){Sb=!0;Tb=a}};function Xb(a,b,c,d,e,f,g,h,k){Sb=!1;Tb=null;Rb.apply(Wb,arguments)}
function Yb(a,b,c,d,e,f,g,h,k){Xb.apply(this,arguments);if(Sb){if(Sb){var l=Tb;Sb=!1;Tb=null}else throw Error(y(198));Ub||(Ub=!0,Vb=l)}}function Zb(a){var b=a,c=a;if(a.alternate)for(;b.return;)b=b.return;else{a=b;do b=a,0!==(b.flags&1026)&&(c=b.return),a=b.return;while(a)}return 3===b.tag?c:null}function $b(a){if(13===a.tag){var b=a.memoizedState;null===b&&(a=a.alternate,null!==a&&(b=a.memoizedState));if(null!==b)return b.dehydrated}return null}function ac(a){if(Zb(a)!==a)throw Error(y(188));}
function bc(a){var b=a.alternate;if(!b){b=Zb(a);if(null===b)throw Error(y(188));return b!==a?null:a}for(var c=a,d=b;;){var e=c.return;if(null===e)break;var f=e.alternate;if(null===f){d=e.return;if(null!==d){c=d;continue}break}if(e.child===f.child){for(f=e.child;f;){if(f===c)return ac(e),a;if(f===d)return ac(e),b;f=f.sibling}throw Error(y(188));}if(c.return!==d.return)c=e,d=f;else{for(var g=!1,h=e.child;h;){if(h===c){g=!0;c=e;d=f;break}if(h===d){g=!0;d=e;c=f;break}h=h.sibling}if(!g){for(h=f.child;h;){if(h===
c){g=!0;c=f;d=e;break}if(h===d){g=!0;d=f;c=e;break}h=h.sibling}if(!g)throw Error(y(189));}}if(c.alternate!==d)throw Error(y(190));}if(3!==c.tag)throw Error(y(188));return c.stateNode.current===c?a:b}function cc(a){a=bc(a);if(!a)return null;for(var b=a;;){if(5===b.tag||6===b.tag)return b;if(b.child)b.child.return=b,b=b.child;else{if(b===a)break;for(;!b.sibling;){if(!b.return||b.return===a)return null;b=b.return}b.sibling.return=b.return;b=b.sibling}}return null}
function dc(a,b){for(var c=a.alternate;null!==b;){if(b===a||b===c)return!0;b=b.return}return!1}var ec,fc,gc,hc,ic=!1,jc=[],kc=null,lc=null,mc=null,nc=new Map,oc=new Map,pc=[],qc="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
function rc(a,b,c,d,e){return{blockedOn:a,domEventName:b,eventSystemFlags:c|16,nativeEvent:e,targetContainers:[d]}}function sc(a,b){switch(a){case "focusin":case "focusout":kc=null;break;case "dragenter":case "dragleave":lc=null;break;case "mouseover":case "mouseout":mc=null;break;case "pointerover":case "pointerout":nc.delete(b.pointerId);break;case "gotpointercapture":case "lostpointercapture":oc.delete(b.pointerId)}}
function tc(a,b,c,d,e,f){if(null===a||a.nativeEvent!==f)return a=rc(b,c,d,e,f),null!==b&&(b=Cb(b),null!==b&&fc(b)),a;a.eventSystemFlags|=d;b=a.targetContainers;null!==e&&-1===b.indexOf(e)&&b.push(e);return a}
function uc(a,b,c,d,e){switch(b){case "focusin":return kc=tc(kc,a,b,c,d,e),!0;case "dragenter":return lc=tc(lc,a,b,c,d,e),!0;case "mouseover":return mc=tc(mc,a,b,c,d,e),!0;case "pointerover":var f=e.pointerId;nc.set(f,tc(nc.get(f)||null,a,b,c,d,e));return!0;case "gotpointercapture":return f=e.pointerId,oc.set(f,tc(oc.get(f)||null,a,b,c,d,e)),!0}return!1}
function vc(a){var b=wc(a.target);if(null!==b){var c=Zb(b);if(null!==c)if(b=c.tag,13===b){if(b=$b(c),null!==b){a.blockedOn=b;hc(a.lanePriority,function(){r.unstable_runWithPriority(a.priority,function(){gc(c)})});return}}else if(3===b&&c.stateNode.hydrate){a.blockedOn=3===c.tag?c.stateNode.containerInfo:null;return}}a.blockedOn=null}
function xc(a){if(null!==a.blockedOn)return!1;for(var b=a.targetContainers;0<b.length;){var c=yc(a.domEventName,a.eventSystemFlags,b[0],a.nativeEvent);if(null!==c)return b=Cb(c),null!==b&&fc(b),a.blockedOn=c,!1;b.shift()}return!0}function zc(a,b,c){xc(a)&&c.delete(b)}
function Ac(){for(ic=!1;0<jc.length;){var a=jc[0];if(null!==a.blockedOn){a=Cb(a.blockedOn);null!==a&&ec(a);break}for(var b=a.targetContainers;0<b.length;){var c=yc(a.domEventName,a.eventSystemFlags,b[0],a.nativeEvent);if(null!==c){a.blockedOn=c;break}b.shift()}null===a.blockedOn&&jc.shift()}null!==kc&&xc(kc)&&(kc=null);null!==lc&&xc(lc)&&(lc=null);null!==mc&&xc(mc)&&(mc=null);nc.forEach(zc);oc.forEach(zc)}
function Bc(a,b){a.blockedOn===b&&(a.blockedOn=null,ic||(ic=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,Ac)))}
function Cc(a){function b(b){return Bc(b,a)}if(0<jc.length){Bc(jc[0],a);for(var c=1;c<jc.length;c++){var d=jc[c];d.blockedOn===a&&(d.blockedOn=null)}}null!==kc&&Bc(kc,a);null!==lc&&Bc(lc,a);null!==mc&&Bc(mc,a);nc.forEach(b);oc.forEach(b);for(c=0;c<pc.length;c++)d=pc[c],d.blockedOn===a&&(d.blockedOn=null);for(;0<pc.length&&(c=pc[0],null===c.blockedOn);)vc(c),null===c.blockedOn&&pc.shift()}
function Dc(a,b){var c={};c[a.toLowerCase()]=b.toLowerCase();c["Webkit"+a]="webkit"+b;c["Moz"+a]="moz"+b;return c}var Ec={animationend:Dc("Animation","AnimationEnd"),animationiteration:Dc("Animation","AnimationIteration"),animationstart:Dc("Animation","AnimationStart"),transitionend:Dc("Transition","TransitionEnd")},Fc={},Gc={};
fa&&(Gc=document.createElement("div").style,"AnimationEvent"in window||(delete Ec.animationend.animation,delete Ec.animationiteration.animation,delete Ec.animationstart.animation),"TransitionEvent"in window||delete Ec.transitionend.transition);function Hc(a){if(Fc[a])return Fc[a];if(!Ec[a])return a;var b=Ec[a],c;for(c in b)if(b.hasOwnProperty(c)&&c in Gc)return Fc[a]=b[c];return a}
var Ic=Hc("animationend"),Jc=Hc("animationiteration"),Kc=Hc("animationstart"),Lc=Hc("transitionend"),Mc=new Map,Nc=new Map,Oc=["abort","abort",Ic,"animationEnd",Jc,"animationIteration",Kc,"animationStart","canplay","canPlay","canplaythrough","canPlayThrough","durationchange","durationChange","emptied","emptied","encrypted","encrypted","ended","ended","error","error","gotpointercapture","gotPointerCapture","load","load","loadeddata","loadedData","loadedmetadata","loadedMetadata","loadstart","loadStart",
"lostpointercapture","lostPointerCapture","playing","playing","progress","progress","seeking","seeking","stalled","stalled","suspend","suspend","timeupdate","timeUpdate",Lc,"transitionEnd","waiting","waiting"];function Pc(a,b){for(var c=0;c<a.length;c+=2){var d=a[c],e=a[c+1];e="on"+(e[0].toUpperCase()+e.slice(1));Nc.set(d,b);Mc.set(d,e);da(e,[d])}}var Qc=r.unstable_now;Qc();var F=8;
function Rc(a){if(0!==(1&a))return F=15,1;if(0!==(2&a))return F=14,2;if(0!==(4&a))return F=13,4;var b=24&a;if(0!==b)return F=12,b;if(0!==(a&32))return F=11,32;b=192&a;if(0!==b)return F=10,b;if(0!==(a&256))return F=9,256;b=3584&a;if(0!==b)return F=8,b;if(0!==(a&4096))return F=7,4096;b=4186112&a;if(0!==b)return F=6,b;b=62914560&a;if(0!==b)return F=5,b;if(a&67108864)return F=4,67108864;if(0!==(a&134217728))return F=3,134217728;b=805306368&a;if(0!==b)return F=2,b;if(0!==(1073741824&a))return F=1,1073741824;
F=8;return a}function Sc(a){switch(a){case 99:return 15;case 98:return 10;case 97:case 96:return 8;case 95:return 2;default:return 0}}function Tc(a){switch(a){case 15:case 14:return 99;case 13:case 12:case 11:case 10:return 98;case 9:case 8:case 7:case 6:case 4:case 5:return 97;case 3:case 2:case 1:return 95;case 0:return 90;default:throw Error(y(358,a));}}
function Uc(a,b){var c=a.pendingLanes;if(0===c)return F=0;var d=0,e=0,f=a.expiredLanes,g=a.suspendedLanes,h=a.pingedLanes;if(0!==f)d=f,e=F=15;else if(f=c&134217727,0!==f){var k=f&~g;0!==k?(d=Rc(k),e=F):(h&=f,0!==h&&(d=Rc(h),e=F))}else f=c&~g,0!==f?(d=Rc(f),e=F):0!==h&&(d=Rc(h),e=F);if(0===d)return 0;d=31-Vc(d);d=c&((0>d?0:1<<d)<<1)-1;if(0!==b&&b!==d&&0===(b&g)){Rc(b);if(e<=F)return b;F=e}b=a.entangledLanes;if(0!==b)for(a=a.entanglements,b&=d;0<b;)c=31-Vc(b),e=1<<c,d|=a[c],b&=~e;return d}
function Wc(a){a=a.pendingLanes&-1073741825;return 0!==a?a:a&1073741824?1073741824:0}function Xc(a,b){switch(a){case 15:return 1;case 14:return 2;case 12:return a=Yc(24&~b),0===a?Xc(10,b):a;case 10:return a=Yc(192&~b),0===a?Xc(8,b):a;case 8:return a=Yc(3584&~b),0===a&&(a=Yc(4186112&~b),0===a&&(a=512)),a;case 2:return b=Yc(805306368&~b),0===b&&(b=268435456),b}throw Error(y(358,a));}function Yc(a){return a&-a}function Zc(a){for(var b=[],c=0;31>c;c++)b.push(a);return b}
function $c(a,b,c){a.pendingLanes|=b;var d=b-1;a.suspendedLanes&=d;a.pingedLanes&=d;a=a.eventTimes;b=31-Vc(b);a[b]=c}var Vc=Math.clz32?Math.clz32:ad,bd=Math.log,cd=Math.LN2;function ad(a){return 0===a?32:31-(bd(a)/cd|0)|0}var dd=r.unstable_UserBlockingPriority,ed=r.unstable_runWithPriority,fd=!0;function gd(a,b,c,d){Kb||Ib();var e=hd,f=Kb;Kb=!0;try{Hb(e,a,b,c,d)}finally{(Kb=f)||Mb()}}function id(a,b,c,d){ed(dd,hd.bind(null,a,b,c,d))}
function hd(a,b,c,d){if(fd){var e;if((e=0===(b&4))&&0<jc.length&&-1<qc.indexOf(a))a=rc(null,a,b,c,d),jc.push(a);else{var f=yc(a,b,c,d);if(null===f)e&&sc(a,d);else{if(e){if(-1<qc.indexOf(a)){a=rc(f,a,b,c,d);jc.push(a);return}if(uc(f,a,b,c,d))return;sc(a,d)}jd(a,b,d,null,c)}}}}
function yc(a,b,c,d){var e=xb(d);e=wc(e);if(null!==e){var f=Zb(e);if(null===f)e=null;else{var g=f.tag;if(13===g){e=$b(f);if(null!==e)return e;e=null}else if(3===g){if(f.stateNode.hydrate)return 3===f.tag?f.stateNode.containerInfo:null;e=null}else f!==e&&(e=null)}}jd(a,b,d,e,c);return null}var kd=null,ld=null,md=null;
function nd(){if(md)return md;var a,b=ld,c=b.length,d,e="value"in kd?kd.value:kd.textContent,f=e.length;for(a=0;a<c&&b[a]===e[a];a++);var g=c-a;for(d=1;d<=g&&b[c-d]===e[f-d];d++);return md=e.slice(a,1<d?1-d:void 0)}function od(a){var b=a.keyCode;"charCode"in a?(a=a.charCode,0===a&&13===b&&(a=13)):a=b;10===a&&(a=13);return 32<=a||13===a?a:0}function pd(){return!0}function qd(){return!1}
function rd(a){function b(b,d,e,f,g){this._reactName=b;this._targetInst=e;this.type=d;this.nativeEvent=f;this.target=g;this.currentTarget=null;for(var c in a)a.hasOwnProperty(c)&&(b=a[c],this[c]=b?b(f):f[c]);this.isDefaultPrevented=(null!=f.defaultPrevented?f.defaultPrevented:!1===f.returnValue)?pd:qd;this.isPropagationStopped=qd;return this}m(b.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():"unknown"!==typeof a.returnValue&&
(a.returnValue=!1),this.isDefaultPrevented=pd)},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():"unknown"!==typeof a.cancelBubble&&(a.cancelBubble=!0),this.isPropagationStopped=pd)},persist:function(){},isPersistent:pd});return b}
var sd={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(a){return a.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},td=rd(sd),ud=m({},sd,{view:0,detail:0}),vd=rd(ud),wd,xd,yd,Ad=m({},ud,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:zd,button:0,buttons:0,relatedTarget:function(a){return void 0===a.relatedTarget?a.fromElement===a.srcElement?a.toElement:a.fromElement:a.relatedTarget},movementX:function(a){if("movementX"in
a)return a.movementX;a!==yd&&(yd&&"mousemove"===a.type?(wd=a.screenX-yd.screenX,xd=a.screenY-yd.screenY):xd=wd=0,yd=a);return wd},movementY:function(a){return"movementY"in a?a.movementY:xd}}),Bd=rd(Ad),Cd=m({},Ad,{dataTransfer:0}),Dd=rd(Cd),Ed=m({},ud,{relatedTarget:0}),Fd=rd(Ed),Gd=m({},sd,{animationName:0,elapsedTime:0,pseudoElement:0}),Hd=rd(Gd),Id=m({},sd,{clipboardData:function(a){return"clipboardData"in a?a.clipboardData:window.clipboardData}}),Jd=rd(Id),Kd=m({},sd,{data:0}),Ld=rd(Kd),Md={Esc:"Escape",
Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Nd={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",
119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Od={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Pd(a){var b=this.nativeEvent;return b.getModifierState?b.getModifierState(a):(a=Od[a])?!!b[a]:!1}function zd(){return Pd}
var Qd=m({},ud,{key:function(a){if(a.key){var b=Md[a.key]||a.key;if("Unidentified"!==b)return b}return"keypress"===a.type?(a=od(a),13===a?"Enter":String.fromCharCode(a)):"keydown"===a.type||"keyup"===a.type?Nd[a.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:zd,charCode:function(a){return"keypress"===a.type?od(a):0},keyCode:function(a){return"keydown"===a.type||"keyup"===a.type?a.keyCode:0},which:function(a){return"keypress"===
a.type?od(a):"keydown"===a.type||"keyup"===a.type?a.keyCode:0}}),Rd=rd(Qd),Sd=m({},Ad,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Td=rd(Sd),Ud=m({},ud,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:zd}),Vd=rd(Ud),Wd=m({},sd,{propertyName:0,elapsedTime:0,pseudoElement:0}),Xd=rd(Wd),Yd=m({},Ad,{deltaX:function(a){return"deltaX"in a?a.deltaX:"wheelDeltaX"in a?-a.wheelDeltaX:0},
deltaY:function(a){return"deltaY"in a?a.deltaY:"wheelDeltaY"in a?-a.wheelDeltaY:"wheelDelta"in a?-a.wheelDelta:0},deltaZ:0,deltaMode:0}),Zd=rd(Yd),$d=[9,13,27,32],ae=fa&&"CompositionEvent"in window,be=null;fa&&"documentMode"in document&&(be=document.documentMode);var ce=fa&&"TextEvent"in window&&!be,de=fa&&(!ae||be&&8<be&&11>=be),ee=String.fromCharCode(32),fe=!1;
function ge(a,b){switch(a){case "keyup":return-1!==$d.indexOf(b.keyCode);case "keydown":return 229!==b.keyCode;case "keypress":case "mousedown":case "focusout":return!0;default:return!1}}function he(a){a=a.detail;return"object"===typeof a&&"data"in a?a.data:null}var ie=!1;function je(a,b){switch(a){case "compositionend":return he(b);case "keypress":if(32!==b.which)return null;fe=!0;return ee;case "textInput":return a=b.data,a===ee&&fe?null:a;default:return null}}
function ke(a,b){if(ie)return"compositionend"===a||!ae&&ge(a,b)?(a=nd(),md=ld=kd=null,ie=!1,a):null;switch(a){case "paste":return null;case "keypress":if(!(b.ctrlKey||b.altKey||b.metaKey)||b.ctrlKey&&b.altKey){if(b.char&&1<b.char.length)return b.char;if(b.which)return String.fromCharCode(b.which)}return null;case "compositionend":return de&&"ko"!==b.locale?null:b.data;default:return null}}
var le={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function me(a){var b=a&&a.nodeName&&a.nodeName.toLowerCase();return"input"===b?!!le[a.type]:"textarea"===b?!0:!1}function ne(a,b,c,d){Eb(d);b=oe(b,"onChange");0<b.length&&(c=new td("onChange","change",null,c,d),a.push({event:c,listeners:b}))}var pe=null,qe=null;function re(a){se(a,0)}function te(a){var b=ue(a);if(Wa(b))return a}
function ve(a,b){if("change"===a)return b}var we=!1;if(fa){var xe;if(fa){var ye="oninput"in document;if(!ye){var ze=document.createElement("div");ze.setAttribute("oninput","return;");ye="function"===typeof ze.oninput}xe=ye}else xe=!1;we=xe&&(!document.documentMode||9<document.documentMode)}function Ae(){pe&&(pe.detachEvent("onpropertychange",Be),qe=pe=null)}function Be(a){if("value"===a.propertyName&&te(qe)){var b=[];ne(b,qe,a,xb(a));a=re;if(Kb)a(b);else{Kb=!0;try{Gb(a,b)}finally{Kb=!1,Mb()}}}}
function Ce(a,b,c){"focusin"===a?(Ae(),pe=b,qe=c,pe.attachEvent("onpropertychange",Be)):"focusout"===a&&Ae()}function De(a){if("selectionchange"===a||"keyup"===a||"keydown"===a)return te(qe)}function Ee(a,b){if("click"===a)return te(b)}function Fe(a,b){if("input"===a||"change"===a)return te(b)}function Ge(a,b){return a===b&&(0!==a||1/a===1/b)||a!==a&&b!==b}var He="function"===typeof Object.is?Object.is:Ge,Ie=Object.prototype.hasOwnProperty;
function Je(a,b){if(He(a,b))return!0;if("object"!==typeof a||null===a||"object"!==typeof b||null===b)return!1;var c=Object.keys(a),d=Object.keys(b);if(c.length!==d.length)return!1;for(d=0;d<c.length;d++)if(!Ie.call(b,c[d])||!He(a[c[d]],b[c[d]]))return!1;return!0}function Ke(a){for(;a&&a.firstChild;)a=a.firstChild;return a}
function Le(a,b){var c=Ke(a);a=0;for(var d;c;){if(3===c.nodeType){d=a+c.textContent.length;if(a<=b&&d>=b)return{node:c,offset:b-a};a=d}a:{for(;c;){if(c.nextSibling){c=c.nextSibling;break a}c=c.parentNode}c=void 0}c=Ke(c)}}function Me(a,b){return a&&b?a===b?!0:a&&3===a.nodeType?!1:b&&3===b.nodeType?Me(a,b.parentNode):"contains"in a?a.contains(b):a.compareDocumentPosition?!!(a.compareDocumentPosition(b)&16):!1:!1}
function Ne(){for(var a=window,b=Xa();b instanceof a.HTMLIFrameElement;){try{var c="string"===typeof b.contentWindow.location.href}catch(d){c=!1}if(c)a=b.contentWindow;else break;b=Xa(a.document)}return b}function Oe(a){var b=a&&a.nodeName&&a.nodeName.toLowerCase();return b&&("input"===b&&("text"===a.type||"search"===a.type||"tel"===a.type||"url"===a.type||"password"===a.type)||"textarea"===b||"true"===a.contentEditable)}
var Pe=fa&&"documentMode"in document&&11>=document.documentMode,Qe=null,Re=null,Se=null,Te=!1;
function Ue(a,b,c){var d=c.window===c?c.document:9===c.nodeType?c:c.ownerDocument;Te||null==Qe||Qe!==Xa(d)||(d=Qe,"selectionStart"in d&&Oe(d)?d={start:d.selectionStart,end:d.selectionEnd}:(d=(d.ownerDocument&&d.ownerDocument.defaultView||window).getSelection(),d={anchorNode:d.anchorNode,anchorOffset:d.anchorOffset,focusNode:d.focusNode,focusOffset:d.focusOffset}),Se&&Je(Se,d)||(Se=d,d=oe(Re,"onSelect"),0<d.length&&(b=new td("onSelect","select",null,b,c),a.push({event:b,listeners:d}),b.target=Qe)))}
Pc("cancel cancel click click close close contextmenu contextMenu copy copy cut cut auxclick auxClick dblclick doubleClick dragend dragEnd dragstart dragStart drop drop focusin focus focusout blur input input invalid invalid keydown keyDown keypress keyPress keyup keyUp mousedown mouseDown mouseup mouseUp paste paste pause pause play play pointercancel pointerCancel pointerdown pointerDown pointerup pointerUp ratechange rateChange reset reset seeked seeked submit submit touchcancel touchCancel touchend touchEnd touchstart touchStart volumechange volumeChange".split(" "),
0);Pc("drag drag dragenter dragEnter dragexit dragExit dragleave dragLeave dragover dragOver mousemove mouseMove mouseout mouseOut mouseover mouseOver pointermove pointerMove pointerout pointerOut pointerover pointerOver scroll scroll toggle toggle touchmove touchMove wheel wheel".split(" "),1);Pc(Oc,2);for(var Ve="change selectionchange textInput compositionstart compositionend compositionupdate".split(" "),We=0;We<Ve.length;We++)Nc.set(Ve[We],0);ea("onMouseEnter",["mouseout","mouseover"]);
ea("onMouseLeave",["mouseout","mouseover"]);ea("onPointerEnter",["pointerout","pointerover"]);ea("onPointerLeave",["pointerout","pointerover"]);da("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));da("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));da("onBeforeInput",["compositionend","keypress","textInput","paste"]);da("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));
da("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));da("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Xe="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Ye=new Set("cancel close invalid load scroll toggle".split(" ").concat(Xe));
function Ze(a,b,c){var d=a.type||"unknown-event";a.currentTarget=c;Yb(d,b,void 0,a);a.currentTarget=null}
function se(a,b){b=0!==(b&4);for(var c=0;c<a.length;c++){var d=a[c],e=d.event;d=d.listeners;a:{var f=void 0;if(b)for(var g=d.length-1;0<=g;g--){var h=d[g],k=h.instance,l=h.currentTarget;h=h.listener;if(k!==f&&e.isPropagationStopped())break a;Ze(e,h,l);f=k}else for(g=0;g<d.length;g++){h=d[g];k=h.instance;l=h.currentTarget;h=h.listener;if(k!==f&&e.isPropagationStopped())break a;Ze(e,h,l);f=k}}}if(Ub)throw a=Vb,Ub=!1,Vb=null,a;}
function G(a,b){var c=$e(b),d=a+"__bubble";c.has(d)||(af(b,a,2,!1),c.add(d))}var bf="_reactListening"+Math.random().toString(36).slice(2);function cf(a){a[bf]||(a[bf]=!0,ba.forEach(function(b){Ye.has(b)||df(b,!1,a,null);df(b,!0,a,null)}))}
function df(a,b,c,d){var e=4<arguments.length&&void 0!==arguments[4]?arguments[4]:0,f=c;"selectionchange"===a&&9!==c.nodeType&&(f=c.ownerDocument);if(null!==d&&!b&&Ye.has(a)){if("scroll"!==a)return;e|=2;f=d}var g=$e(f),h=a+"__"+(b?"capture":"bubble");g.has(h)||(b&&(e|=4),af(f,a,e,b),g.add(h))}
function af(a,b,c,d){var e=Nc.get(b);switch(void 0===e?2:e){case 0:e=gd;break;case 1:e=id;break;default:e=hd}c=e.bind(null,b,c,a);e=void 0;!Pb||"touchstart"!==b&&"touchmove"!==b&&"wheel"!==b||(e=!0);d?void 0!==e?a.addEventListener(b,c,{capture:!0,passive:e}):a.addEventListener(b,c,!0):void 0!==e?a.addEventListener(b,c,{passive:e}):a.addEventListener(b,c,!1)}
function jd(a,b,c,d,e){var f=d;if(0===(b&1)&&0===(b&2)&&null!==d)a:for(;;){if(null===d)return;var g=d.tag;if(3===g||4===g){var h=d.stateNode.containerInfo;if(h===e||8===h.nodeType&&h.parentNode===e)break;if(4===g)for(g=d.return;null!==g;){var k=g.tag;if(3===k||4===k)if(k=g.stateNode.containerInfo,k===e||8===k.nodeType&&k.parentNode===e)return;g=g.return}for(;null!==h;){g=wc(h);if(null===g)return;k=g.tag;if(5===k||6===k){d=f=g;continue a}h=h.parentNode}}d=d.return}Nb(function(){var d=f,e=xb(c),g=[];
a:{var h=Mc.get(a);if(void 0!==h){var k=td,x=a;switch(a){case "keypress":if(0===od(c))break a;case "keydown":case "keyup":k=Rd;break;case "focusin":x="focus";k=Fd;break;case "focusout":x="blur";k=Fd;break;case "beforeblur":case "afterblur":k=Fd;break;case "click":if(2===c.button)break a;case "auxclick":case "dblclick":case "mousedown":case "mousemove":case "mouseup":case "mouseout":case "mouseover":case "contextmenu":k=Bd;break;case "drag":case "dragend":case "dragenter":case "dragexit":case "dragleave":case "dragover":case "dragstart":case "drop":k=
Dd;break;case "touchcancel":case "touchend":case "touchmove":case "touchstart":k=Vd;break;case Ic:case Jc:case Kc:k=Hd;break;case Lc:k=Xd;break;case "scroll":k=vd;break;case "wheel":k=Zd;break;case "copy":case "cut":case "paste":k=Jd;break;case "gotpointercapture":case "lostpointercapture":case "pointercancel":case "pointerdown":case "pointermove":case "pointerout":case "pointerover":case "pointerup":k=Td}var w=0!==(b&4),z=!w&&"scroll"===a,u=w?null!==h?h+"Capture":null:h;w=[];for(var t=d,q;null!==
t;){q=t;var v=q.stateNode;5===q.tag&&null!==v&&(q=v,null!==u&&(v=Ob(t,u),null!=v&&w.push(ef(t,v,q))));if(z)break;t=t.return}0<w.length&&(h=new k(h,x,null,c,e),g.push({event:h,listeners:w}))}}if(0===(b&7)){a:{h="mouseover"===a||"pointerover"===a;k="mouseout"===a||"pointerout"===a;if(h&&0===(b&16)&&(x=c.relatedTarget||c.fromElement)&&(wc(x)||x[ff]))break a;if(k||h){h=e.window===e?e:(h=e.ownerDocument)?h.defaultView||h.parentWindow:window;if(k){if(x=c.relatedTarget||c.toElement,k=d,x=x?wc(x):null,null!==
x&&(z=Zb(x),x!==z||5!==x.tag&&6!==x.tag))x=null}else k=null,x=d;if(k!==x){w=Bd;v="onMouseLeave";u="onMouseEnter";t="mouse";if("pointerout"===a||"pointerover"===a)w=Td,v="onPointerLeave",u="onPointerEnter",t="pointer";z=null==k?h:ue(k);q=null==x?h:ue(x);h=new w(v,t+"leave",k,c,e);h.target=z;h.relatedTarget=q;v=null;wc(e)===d&&(w=new w(u,t+"enter",x,c,e),w.target=q,w.relatedTarget=z,v=w);z=v;if(k&&x)b:{w=k;u=x;t=0;for(q=w;q;q=gf(q))t++;q=0;for(v=u;v;v=gf(v))q++;for(;0<t-q;)w=gf(w),t--;for(;0<q-t;)u=
gf(u),q--;for(;t--;){if(w===u||null!==u&&w===u.alternate)break b;w=gf(w);u=gf(u)}w=null}else w=null;null!==k&&hf(g,h,k,w,!1);null!==x&&null!==z&&hf(g,z,x,w,!0)}}}a:{h=d?ue(d):window;k=h.nodeName&&h.nodeName.toLowerCase();if("select"===k||"input"===k&&"file"===h.type)var J=ve;else if(me(h))if(we)J=Fe;else{J=De;var K=Ce}else(k=h.nodeName)&&"input"===k.toLowerCase()&&("checkbox"===h.type||"radio"===h.type)&&(J=Ee);if(J&&(J=J(a,d))){ne(g,J,c,e);break a}K&&K(a,h,d);"focusout"===a&&(K=h._wrapperState)&&
K.controlled&&"number"===h.type&&bb(h,"number",h.value)}K=d?ue(d):window;switch(a){case "focusin":if(me(K)||"true"===K.contentEditable)Qe=K,Re=d,Se=null;break;case "focusout":Se=Re=Qe=null;break;case "mousedown":Te=!0;break;case "contextmenu":case "mouseup":case "dragend":Te=!1;Ue(g,c,e);break;case "selectionchange":if(Pe)break;case "keydown":case "keyup":Ue(g,c,e)}var Q;if(ae)b:{switch(a){case "compositionstart":var L="onCompositionStart";break b;case "compositionend":L="onCompositionEnd";break b;
case "compositionupdate":L="onCompositionUpdate";break b}L=void 0}else ie?ge(a,c)&&(L="onCompositionEnd"):"keydown"===a&&229===c.keyCode&&(L="onCompositionStart");L&&(de&&"ko"!==c.locale&&(ie||"onCompositionStart"!==L?"onCompositionEnd"===L&&ie&&(Q=nd()):(kd=e,ld="value"in kd?kd.value:kd.textContent,ie=!0)),K=oe(d,L),0<K.length&&(L=new Ld(L,a,null,c,e),g.push({event:L,listeners:K}),Q?L.data=Q:(Q=he(c),null!==Q&&(L.data=Q))));if(Q=ce?je(a,c):ke(a,c))d=oe(d,"onBeforeInput"),0<d.length&&(e=new Ld("onBeforeInput",
"beforeinput",null,c,e),g.push({event:e,listeners:d}),e.data=Q)}se(g,b)})}function ef(a,b,c){return{instance:a,listener:b,currentTarget:c}}function oe(a,b){for(var c=b+"Capture",d=[];null!==a;){var e=a,f=e.stateNode;5===e.tag&&null!==f&&(e=f,f=Ob(a,c),null!=f&&d.unshift(ef(a,f,e)),f=Ob(a,b),null!=f&&d.push(ef(a,f,e)));a=a.return}return d}function gf(a){if(null===a)return null;do a=a.return;while(a&&5!==a.tag);return a?a:null}
function hf(a,b,c,d,e){for(var f=b._reactName,g=[];null!==c&&c!==d;){var h=c,k=h.alternate,l=h.stateNode;if(null!==k&&k===d)break;5===h.tag&&null!==l&&(h=l,e?(k=Ob(c,f),null!=k&&g.unshift(ef(c,k,h))):e||(k=Ob(c,f),null!=k&&g.push(ef(c,k,h))));c=c.return}0!==g.length&&a.push({event:b,listeners:g})}function jf(){}var kf=null,lf=null;function mf(a,b){switch(a){case "button":case "input":case "select":case "textarea":return!!b.autoFocus}return!1}
function nf(a,b){return"textarea"===a||"option"===a||"noscript"===a||"string"===typeof b.children||"number"===typeof b.children||"object"===typeof b.dangerouslySetInnerHTML&&null!==b.dangerouslySetInnerHTML&&null!=b.dangerouslySetInnerHTML.__html}var of="function"===typeof setTimeout?setTimeout:void 0,pf="function"===typeof clearTimeout?clearTimeout:void 0;function qf(a){1===a.nodeType?a.textContent="":9===a.nodeType&&(a=a.body,null!=a&&(a.textContent=""))}
function rf(a){for(;null!=a;a=a.nextSibling){var b=a.nodeType;if(1===b||3===b)break}return a}function sf(a){a=a.previousSibling;for(var b=0;a;){if(8===a.nodeType){var c=a.data;if("$"===c||"$!"===c||"$?"===c){if(0===b)return a;b--}else"/$"===c&&b++}a=a.previousSibling}return null}var tf=0;function uf(a){return{$$typeof:Ga,toString:a,valueOf:a}}var vf=Math.random().toString(36).slice(2),wf="__reactFiber$"+vf,xf="__reactProps$"+vf,ff="__reactContainer$"+vf,yf="__reactEvents$"+vf;
function wc(a){var b=a[wf];if(b)return b;for(var c=a.parentNode;c;){if(b=c[ff]||c[wf]){c=b.alternate;if(null!==b.child||null!==c&&null!==c.child)for(a=sf(a);null!==a;){if(c=a[wf])return c;a=sf(a)}return b}a=c;c=a.parentNode}return null}function Cb(a){a=a[wf]||a[ff];return!a||5!==a.tag&&6!==a.tag&&13!==a.tag&&3!==a.tag?null:a}function ue(a){if(5===a.tag||6===a.tag)return a.stateNode;throw Error(y(33));}function Db(a){return a[xf]||null}
function $e(a){var b=a[yf];void 0===b&&(b=a[yf]=new Set);return b}var zf=[],Af=-1;function Bf(a){return{current:a}}function H(a){0>Af||(a.current=zf[Af],zf[Af]=null,Af--)}function I(a,b){Af++;zf[Af]=a.current;a.current=b}var Cf={},M=Bf(Cf),N=Bf(!1),Df=Cf;
function Ef(a,b){var c=a.type.contextTypes;if(!c)return Cf;var d=a.stateNode;if(d&&d.__reactInternalMemoizedUnmaskedChildContext===b)return d.__reactInternalMemoizedMaskedChildContext;var e={},f;for(f in c)e[f]=b[f];d&&(a=a.stateNode,a.__reactInternalMemoizedUnmaskedChildContext=b,a.__reactInternalMemoizedMaskedChildContext=e);return e}function Ff(a){a=a.childContextTypes;return null!==a&&void 0!==a}function Gf(){H(N);H(M)}function Hf(a,b,c){if(M.current!==Cf)throw Error(y(168));I(M,b);I(N,c)}
function If(a,b,c){var d=a.stateNode;a=b.childContextTypes;if("function"!==typeof d.getChildContext)return c;d=d.getChildContext();for(var e in d)if(!(e in a))throw Error(y(108,Ra(b)||"Unknown",e));return m({},c,d)}function Jf(a){a=(a=a.stateNode)&&a.__reactInternalMemoizedMergedChildContext||Cf;Df=M.current;I(M,a);I(N,N.current);return!0}function Kf(a,b,c){var d=a.stateNode;if(!d)throw Error(y(169));c?(a=If(a,b,Df),d.__reactInternalMemoizedMergedChildContext=a,H(N),H(M),I(M,a)):H(N);I(N,c)}
var Lf=null,Mf=null,Nf=r.unstable_runWithPriority,Of=r.unstable_scheduleCallback,Pf=r.unstable_cancelCallback,Qf=r.unstable_shouldYield,Rf=r.unstable_requestPaint,Sf=r.unstable_now,Tf=r.unstable_getCurrentPriorityLevel,Uf=r.unstable_ImmediatePriority,Vf=r.unstable_UserBlockingPriority,Wf=r.unstable_NormalPriority,Xf=r.unstable_LowPriority,Yf=r.unstable_IdlePriority,Zf={},$f=void 0!==Rf?Rf:function(){},ag=null,bg=null,cg=!1,dg=Sf(),O=1E4>dg?Sf:function(){return Sf()-dg};
function eg(){switch(Tf()){case Uf:return 99;case Vf:return 98;case Wf:return 97;case Xf:return 96;case Yf:return 95;default:throw Error(y(332));}}function fg(a){switch(a){case 99:return Uf;case 98:return Vf;case 97:return Wf;case 96:return Xf;case 95:return Yf;default:throw Error(y(332));}}function gg(a,b){a=fg(a);return Nf(a,b)}function hg(a,b,c){a=fg(a);return Of(a,b,c)}function ig(){if(null!==bg){var a=bg;bg=null;Pf(a)}jg()}
function jg(){if(!cg&&null!==ag){cg=!0;var a=0;try{var b=ag;gg(99,function(){for(;a<b.length;a++){var c=b[a];do c=c(!0);while(null!==c)}});ag=null}catch(c){throw null!==ag&&(ag=ag.slice(a+1)),Of(Uf,ig),c;}finally{cg=!1}}}var kg=ra.ReactCurrentBatchConfig;function lg(a,b){if(a&&a.defaultProps){b=m({},b);a=a.defaultProps;for(var c in a)void 0===b[c]&&(b[c]=a[c]);return b}return b}var mg=Bf(null),ng=null,og=null,pg=null;function qg(){pg=og=ng=null}
function rg(a){var b=mg.current;H(mg);a.type._context._currentValue=b}function sg(a,b){for(;null!==a;){var c=a.alternate;if((a.childLanes&b)===b)if(null===c||(c.childLanes&b)===b)break;else c.childLanes|=b;else a.childLanes|=b,null!==c&&(c.childLanes|=b);a=a.return}}function tg(a,b){ng=a;pg=og=null;a=a.dependencies;null!==a&&null!==a.firstContext&&(0!==(a.lanes&b)&&(ug=!0),a.firstContext=null)}
function vg(a,b){if(pg!==a&&!1!==b&&0!==b){if("number"!==typeof b||1073741823===b)pg=a,b=1073741823;b={context:a,observedBits:b,next:null};if(null===og){if(null===ng)throw Error(y(308));og=b;ng.dependencies={lanes:0,firstContext:b,responders:null}}else og=og.next=b}return a._currentValue}var wg=!1;function xg(a){a.updateQueue={baseState:a.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null},effects:null}}
function yg(a,b){a=a.updateQueue;b.updateQueue===a&&(b.updateQueue={baseState:a.baseState,firstBaseUpdate:a.firstBaseUpdate,lastBaseUpdate:a.lastBaseUpdate,shared:a.shared,effects:a.effects})}function zg(a,b){return{eventTime:a,lane:b,tag:0,payload:null,callback:null,next:null}}function Ag(a,b){a=a.updateQueue;if(null!==a){a=a.shared;var c=a.pending;null===c?b.next=b:(b.next=c.next,c.next=b);a.pending=b}}
function Bg(a,b){var c=a.updateQueue,d=a.alternate;if(null!==d&&(d=d.updateQueue,c===d)){var e=null,f=null;c=c.firstBaseUpdate;if(null!==c){do{var g={eventTime:c.eventTime,lane:c.lane,tag:c.tag,payload:c.payload,callback:c.callback,next:null};null===f?e=f=g:f=f.next=g;c=c.next}while(null!==c);null===f?e=f=b:f=f.next=b}else e=f=b;c={baseState:d.baseState,firstBaseUpdate:e,lastBaseUpdate:f,shared:d.shared,effects:d.effects};a.updateQueue=c;return}a=c.lastBaseUpdate;null===a?c.firstBaseUpdate=b:a.next=
b;c.lastBaseUpdate=b}
function Cg(a,b,c,d){var e=a.updateQueue;wg=!1;var f=e.firstBaseUpdate,g=e.lastBaseUpdate,h=e.shared.pending;if(null!==h){e.shared.pending=null;var k=h,l=k.next;k.next=null;null===g?f=l:g.next=l;g=k;var n=a.alternate;if(null!==n){n=n.updateQueue;var A=n.lastBaseUpdate;A!==g&&(null===A?n.firstBaseUpdate=l:A.next=l,n.lastBaseUpdate=k)}}if(null!==f){A=e.baseState;g=0;n=l=k=null;do{h=f.lane;var p=f.eventTime;if((d&h)===h){null!==n&&(n=n.next={eventTime:p,lane:0,tag:f.tag,payload:f.payload,callback:f.callback,
next:null});a:{var C=a,x=f;h=b;p=c;switch(x.tag){case 1:C=x.payload;if("function"===typeof C){A=C.call(p,A,h);break a}A=C;break a;case 3:C.flags=C.flags&-4097|64;case 0:C=x.payload;h="function"===typeof C?C.call(p,A,h):C;if(null===h||void 0===h)break a;A=m({},A,h);break a;case 2:wg=!0}}null!==f.callback&&(a.flags|=32,h=e.effects,null===h?e.effects=[f]:h.push(f))}else p={eventTime:p,lane:h,tag:f.tag,payload:f.payload,callback:f.callback,next:null},null===n?(l=n=p,k=A):n=n.next=p,g|=h;f=f.next;if(null===
f)if(h=e.shared.pending,null===h)break;else f=h.next,h.next=null,e.lastBaseUpdate=h,e.shared.pending=null}while(1);null===n&&(k=A);e.baseState=k;e.firstBaseUpdate=l;e.lastBaseUpdate=n;Dg|=g;a.lanes=g;a.memoizedState=A}}function Eg(a,b,c){a=b.effects;b.effects=null;if(null!==a)for(b=0;b<a.length;b++){var d=a[b],e=d.callback;if(null!==e){d.callback=null;d=c;if("function"!==typeof e)throw Error(y(191,e));e.call(d)}}}var Fg=(new aa.Component).refs;
function Gg(a,b,c,d){b=a.memoizedState;c=c(d,b);c=null===c||void 0===c?b:m({},b,c);a.memoizedState=c;0===a.lanes&&(a.updateQueue.baseState=c)}
var Kg={isMounted:function(a){return(a=a._reactInternals)?Zb(a)===a:!1},enqueueSetState:function(a,b,c){a=a._reactInternals;var d=Hg(),e=Ig(a),f=zg(d,e);f.payload=b;void 0!==c&&null!==c&&(f.callback=c);Ag(a,f);Jg(a,e,d)},enqueueReplaceState:function(a,b,c){a=a._reactInternals;var d=Hg(),e=Ig(a),f=zg(d,e);f.tag=1;f.payload=b;void 0!==c&&null!==c&&(f.callback=c);Ag(a,f);Jg(a,e,d)},enqueueForceUpdate:function(a,b){a=a._reactInternals;var c=Hg(),d=Ig(a),e=zg(c,d);e.tag=2;void 0!==b&&null!==b&&(e.callback=
b);Ag(a,e);Jg(a,d,c)}};function Lg(a,b,c,d,e,f,g){a=a.stateNode;return"function"===typeof a.shouldComponentUpdate?a.shouldComponentUpdate(d,f,g):b.prototype&&b.prototype.isPureReactComponent?!Je(c,d)||!Je(e,f):!0}
function Mg(a,b,c){var d=!1,e=Cf;var f=b.contextType;"object"===typeof f&&null!==f?f=vg(f):(e=Ff(b)?Df:M.current,d=b.contextTypes,f=(d=null!==d&&void 0!==d)?Ef(a,e):Cf);b=new b(c,f);a.memoizedState=null!==b.state&&void 0!==b.state?b.state:null;b.updater=Kg;a.stateNode=b;b._reactInternals=a;d&&(a=a.stateNode,a.__reactInternalMemoizedUnmaskedChildContext=e,a.__reactInternalMemoizedMaskedChildContext=f);return b}
function Ng(a,b,c,d){a=b.state;"function"===typeof b.componentWillReceiveProps&&b.componentWillReceiveProps(c,d);"function"===typeof b.UNSAFE_componentWillReceiveProps&&b.UNSAFE_componentWillReceiveProps(c,d);b.state!==a&&Kg.enqueueReplaceState(b,b.state,null)}
function Og(a,b,c,d){var e=a.stateNode;e.props=c;e.state=a.memoizedState;e.refs=Fg;xg(a);var f=b.contextType;"object"===typeof f&&null!==f?e.context=vg(f):(f=Ff(b)?Df:M.current,e.context=Ef(a,f));Cg(a,c,e,d);e.state=a.memoizedState;f=b.getDerivedStateFromProps;"function"===typeof f&&(Gg(a,b,f,c),e.state=a.memoizedState);"function"===typeof b.getDerivedStateFromProps||"function"===typeof e.getSnapshotBeforeUpdate||"function"!==typeof e.UNSAFE_componentWillMount&&"function"!==typeof e.componentWillMount||
(b=e.state,"function"===typeof e.componentWillMount&&e.componentWillMount(),"function"===typeof e.UNSAFE_componentWillMount&&e.UNSAFE_componentWillMount(),b!==e.state&&Kg.enqueueReplaceState(e,e.state,null),Cg(a,c,e,d),e.state=a.memoizedState);"function"===typeof e.componentDidMount&&(a.flags|=4)}var Pg=Array.isArray;
function Qg(a,b,c){a=c.ref;if(null!==a&&"function"!==typeof a&&"object"!==typeof a){if(c._owner){c=c._owner;if(c){if(1!==c.tag)throw Error(y(309));var d=c.stateNode}if(!d)throw Error(y(147,a));var e=""+a;if(null!==b&&null!==b.ref&&"function"===typeof b.ref&&b.ref._stringRef===e)return b.ref;b=function(a){var b=d.refs;b===Fg&&(b=d.refs={});null===a?delete b[e]:b[e]=a};b._stringRef=e;return b}if("string"!==typeof a)throw Error(y(284));if(!c._owner)throw Error(y(290,a));}return a}
function Rg(a,b){if("textarea"!==a.type)throw Error(y(31,"[object Object]"===Object.prototype.toString.call(b)?"object with keys {"+Object.keys(b).join(", ")+"}":b));}
function Sg(a){function b(b,c){if(a){var d=b.lastEffect;null!==d?(d.nextEffect=c,b.lastEffect=c):b.firstEffect=b.lastEffect=c;c.nextEffect=null;c.flags=8}}function c(c,d){if(!a)return null;for(;null!==d;)b(c,d),d=d.sibling;return null}function d(a,b){for(a=new Map;null!==b;)null!==b.key?a.set(b.key,b):a.set(b.index,b),b=b.sibling;return a}function e(a,b){a=Tg(a,b);a.index=0;a.sibling=null;return a}function f(b,c,d){b.index=d;if(!a)return c;d=b.alternate;if(null!==d)return d=d.index,d<c?(b.flags=2,
c):d;b.flags=2;return c}function g(b){a&&null===b.alternate&&(b.flags=2);return b}function h(a,b,c,d){if(null===b||6!==b.tag)return b=Ug(c,a.mode,d),b.return=a,b;b=e(b,c);b.return=a;return b}function k(a,b,c,d){if(null!==b&&b.elementType===c.type)return d=e(b,c.props),d.ref=Qg(a,b,c),d.return=a,d;d=Vg(c.type,c.key,c.props,null,a.mode,d);d.ref=Qg(a,b,c);d.return=a;return d}function l(a,b,c,d){if(null===b||4!==b.tag||b.stateNode.containerInfo!==c.containerInfo||b.stateNode.implementation!==c.implementation)return b=
Wg(c,a.mode,d),b.return=a,b;b=e(b,c.children||[]);b.return=a;return b}function n(a,b,c,d,f){if(null===b||7!==b.tag)return b=Xg(c,a.mode,d,f),b.return=a,b;b=e(b,c);b.return=a;return b}function A(a,b,c){if("string"===typeof b||"number"===typeof b)return b=Ug(""+b,a.mode,c),b.return=a,b;if("object"===typeof b&&null!==b){switch(b.$$typeof){case sa:return c=Vg(b.type,b.key,b.props,null,a.mode,c),c.ref=Qg(a,null,b),c.return=a,c;case ta:return b=Wg(b,a.mode,c),b.return=a,b}if(Pg(b)||La(b))return b=Xg(b,
a.mode,c,null),b.return=a,b;Rg(a,b)}return null}function p(a,b,c,d){var e=null!==b?b.key:null;if("string"===typeof c||"number"===typeof c)return null!==e?null:h(a,b,""+c,d);if("object"===typeof c&&null!==c){switch(c.$$typeof){case sa:return c.key===e?c.type===ua?n(a,b,c.props.children,d,e):k(a,b,c,d):null;case ta:return c.key===e?l(a,b,c,d):null}if(Pg(c)||La(c))return null!==e?null:n(a,b,c,d,null);Rg(a,c)}return null}function C(a,b,c,d,e){if("string"===typeof d||"number"===typeof d)return a=a.get(c)||
null,h(b,a,""+d,e);if("object"===typeof d&&null!==d){switch(d.$$typeof){case sa:return a=a.get(null===d.key?c:d.key)||null,d.type===ua?n(b,a,d.props.children,e,d.key):k(b,a,d,e);case ta:return a=a.get(null===d.key?c:d.key)||null,l(b,a,d,e)}if(Pg(d)||La(d))return a=a.get(c)||null,n(b,a,d,e,null);Rg(b,d)}return null}function x(e,g,h,k){for(var l=null,t=null,u=g,z=g=0,q=null;null!==u&&z<h.length;z++){u.index>z?(q=u,u=null):q=u.sibling;var n=p(e,u,h[z],k);if(null===n){null===u&&(u=q);break}a&&u&&null===
n.alternate&&b(e,u);g=f(n,g,z);null===t?l=n:t.sibling=n;t=n;u=q}if(z===h.length)return c(e,u),l;if(null===u){for(;z<h.length;z++)u=A(e,h[z],k),null!==u&&(g=f(u,g,z),null===t?l=u:t.sibling=u,t=u);return l}for(u=d(e,u);z<h.length;z++)q=C(u,e,z,h[z],k),null!==q&&(a&&null!==q.alternate&&u.delete(null===q.key?z:q.key),g=f(q,g,z),null===t?l=q:t.sibling=q,t=q);a&&u.forEach(function(a){return b(e,a)});return l}function w(e,g,h,k){var l=La(h);if("function"!==typeof l)throw Error(y(150));h=l.call(h);if(null==
h)throw Error(y(151));for(var t=l=null,u=g,z=g=0,q=null,n=h.next();null!==u&&!n.done;z++,n=h.next()){u.index>z?(q=u,u=null):q=u.sibling;var w=p(e,u,n.value,k);if(null===w){null===u&&(u=q);break}a&&u&&null===w.alternate&&b(e,u);g=f(w,g,z);null===t?l=w:t.sibling=w;t=w;u=q}if(n.done)return c(e,u),l;if(null===u){for(;!n.done;z++,n=h.next())n=A(e,n.value,k),null!==n&&(g=f(n,g,z),null===t?l=n:t.sibling=n,t=n);return l}for(u=d(e,u);!n.done;z++,n=h.next())n=C(u,e,z,n.value,k),null!==n&&(a&&null!==n.alternate&&
u.delete(null===n.key?z:n.key),g=f(n,g,z),null===t?l=n:t.sibling=n,t=n);a&&u.forEach(function(a){return b(e,a)});return l}return function(a,d,f,h){var k="object"===typeof f&&null!==f&&f.type===ua&&null===f.key;k&&(f=f.props.children);var l="object"===typeof f&&null!==f;if(l)switch(f.$$typeof){case sa:a:{l=f.key;for(k=d;null!==k;){if(k.key===l){switch(k.tag){case 7:if(f.type===ua){c(a,k.sibling);d=e(k,f.props.children);d.return=a;a=d;break a}break;default:if(k.elementType===f.type){c(a,k.sibling);
d=e(k,f.props);d.ref=Qg(a,k,f);d.return=a;a=d;break a}}c(a,k);break}else b(a,k);k=k.sibling}f.type===ua?(d=Xg(f.props.children,a.mode,h,f.key),d.return=a,a=d):(h=Vg(f.type,f.key,f.props,null,a.mode,h),h.ref=Qg(a,d,f),h.return=a,a=h)}return g(a);case ta:a:{for(k=f.key;null!==d;){if(d.key===k)if(4===d.tag&&d.stateNode.containerInfo===f.containerInfo&&d.stateNode.implementation===f.implementation){c(a,d.sibling);d=e(d,f.children||[]);d.return=a;a=d;break a}else{c(a,d);break}else b(a,d);d=d.sibling}d=
Wg(f,a.mode,h);d.return=a;a=d}return g(a)}if("string"===typeof f||"number"===typeof f)return f=""+f,null!==d&&6===d.tag?(c(a,d.sibling),d=e(d,f),d.return=a,a=d):(c(a,d),d=Ug(f,a.mode,h),d.return=a,a=d),g(a);if(Pg(f))return x(a,d,f,h);if(La(f))return w(a,d,f,h);l&&Rg(a,f);if("undefined"===typeof f&&!k)switch(a.tag){case 1:case 22:case 0:case 11:case 15:throw Error(y(152,Ra(a.type)||"Component"));}return c(a,d)}}var Yg=Sg(!0),Zg=Sg(!1),$g={},ah=Bf($g),bh=Bf($g),ch=Bf($g);
function dh(a){if(a===$g)throw Error(y(174));return a}function eh(a,b){I(ch,b);I(bh,a);I(ah,$g);a=b.nodeType;switch(a){case 9:case 11:b=(b=b.documentElement)?b.namespaceURI:mb(null,"");break;default:a=8===a?b.parentNode:b,b=a.namespaceURI||null,a=a.tagName,b=mb(b,a)}H(ah);I(ah,b)}function fh(){H(ah);H(bh);H(ch)}function gh(a){dh(ch.current);var b=dh(ah.current);var c=mb(b,a.type);b!==c&&(I(bh,a),I(ah,c))}function hh(a){bh.current===a&&(H(ah),H(bh))}var P=Bf(0);
function ih(a){for(var b=a;null!==b;){if(13===b.tag){var c=b.memoizedState;if(null!==c&&(c=c.dehydrated,null===c||"$?"===c.data||"$!"===c.data))return b}else if(19===b.tag&&void 0!==b.memoizedProps.revealOrder){if(0!==(b.flags&64))return b}else if(null!==b.child){b.child.return=b;b=b.child;continue}if(b===a)break;for(;null===b.sibling;){if(null===b.return||b.return===a)return null;b=b.return}b.sibling.return=b.return;b=b.sibling}return null}var jh=null,kh=null,lh=!1;
function mh(a,b){var c=nh(5,null,null,0);c.elementType="DELETED";c.type="DELETED";c.stateNode=b;c.return=a;c.flags=8;null!==a.lastEffect?(a.lastEffect.nextEffect=c,a.lastEffect=c):a.firstEffect=a.lastEffect=c}function oh(a,b){switch(a.tag){case 5:var c=a.type;b=1!==b.nodeType||c.toLowerCase()!==b.nodeName.toLowerCase()?null:b;return null!==b?(a.stateNode=b,!0):!1;case 6:return b=""===a.pendingProps||3!==b.nodeType?null:b,null!==b?(a.stateNode=b,!0):!1;case 13:return!1;default:return!1}}
function ph(a){if(lh){var b=kh;if(b){var c=b;if(!oh(a,b)){b=rf(c.nextSibling);if(!b||!oh(a,b)){a.flags=a.flags&-1025|2;lh=!1;jh=a;return}mh(jh,c)}jh=a;kh=rf(b.firstChild)}else a.flags=a.flags&-1025|2,lh=!1,jh=a}}function qh(a){for(a=a.return;null!==a&&5!==a.tag&&3!==a.tag&&13!==a.tag;)a=a.return;jh=a}
function rh(a){if(a!==jh)return!1;if(!lh)return qh(a),lh=!0,!1;var b=a.type;if(5!==a.tag||"head"!==b&&"body"!==b&&!nf(b,a.memoizedProps))for(b=kh;b;)mh(a,b),b=rf(b.nextSibling);qh(a);if(13===a.tag){a=a.memoizedState;a=null!==a?a.dehydrated:null;if(!a)throw Error(y(317));a:{a=a.nextSibling;for(b=0;a;){if(8===a.nodeType){var c=a.data;if("/$"===c){if(0===b){kh=rf(a.nextSibling);break a}b--}else"$"!==c&&"$!"!==c&&"$?"!==c||b++}a=a.nextSibling}kh=null}}else kh=jh?rf(a.stateNode.nextSibling):null;return!0}
function sh(){kh=jh=null;lh=!1}var th=[];function uh(){for(var a=0;a<th.length;a++)th[a]._workInProgressVersionPrimary=null;th.length=0}var vh=ra.ReactCurrentDispatcher,wh=ra.ReactCurrentBatchConfig,xh=0,R=null,S=null,T=null,yh=!1,zh=!1;function Ah(){throw Error(y(321));}function Bh(a,b){if(null===b)return!1;for(var c=0;c<b.length&&c<a.length;c++)if(!He(a[c],b[c]))return!1;return!0}
function Ch(a,b,c,d,e,f){xh=f;R=b;b.memoizedState=null;b.updateQueue=null;b.lanes=0;vh.current=null===a||null===a.memoizedState?Dh:Eh;a=c(d,e);if(zh){f=0;do{zh=!1;if(!(25>f))throw Error(y(301));f+=1;T=S=null;b.updateQueue=null;vh.current=Fh;a=c(d,e)}while(zh)}vh.current=Gh;b=null!==S&&null!==S.next;xh=0;T=S=R=null;yh=!1;if(b)throw Error(y(300));return a}function Hh(){var a={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};null===T?R.memoizedState=T=a:T=T.next=a;return T}
function Ih(){if(null===S){var a=R.alternate;a=null!==a?a.memoizedState:null}else a=S.next;var b=null===T?R.memoizedState:T.next;if(null!==b)T=b,S=a;else{if(null===a)throw Error(y(310));S=a;a={memoizedState:S.memoizedState,baseState:S.baseState,baseQueue:S.baseQueue,queue:S.queue,next:null};null===T?R.memoizedState=T=a:T=T.next=a}return T}function Jh(a,b){return"function"===typeof b?b(a):b}
function Kh(a){var b=Ih(),c=b.queue;if(null===c)throw Error(y(311));c.lastRenderedReducer=a;var d=S,e=d.baseQueue,f=c.pending;if(null!==f){if(null!==e){var g=e.next;e.next=f.next;f.next=g}d.baseQueue=e=f;c.pending=null}if(null!==e){e=e.next;d=d.baseState;var h=g=f=null,k=e;do{var l=k.lane;if((xh&l)===l)null!==h&&(h=h.next={lane:0,action:k.action,eagerReducer:k.eagerReducer,eagerState:k.eagerState,next:null}),d=k.eagerReducer===a?k.eagerState:a(d,k.action);else{var n={lane:l,action:k.action,eagerReducer:k.eagerReducer,
eagerState:k.eagerState,next:null};null===h?(g=h=n,f=d):h=h.next=n;R.lanes|=l;Dg|=l}k=k.next}while(null!==k&&k!==e);null===h?f=d:h.next=g;He(d,b.memoizedState)||(ug=!0);b.memoizedState=d;b.baseState=f;b.baseQueue=h;c.lastRenderedState=d}return[b.memoizedState,c.dispatch]}
function Lh(a){var b=Ih(),c=b.queue;if(null===c)throw Error(y(311));c.lastRenderedReducer=a;var d=c.dispatch,e=c.pending,f=b.memoizedState;if(null!==e){c.pending=null;var g=e=e.next;do f=a(f,g.action),g=g.next;while(g!==e);He(f,b.memoizedState)||(ug=!0);b.memoizedState=f;null===b.baseQueue&&(b.baseState=f);c.lastRenderedState=f}return[f,d]}
function Mh(a,b,c){var d=b._getVersion;d=d(b._source);var e=b._workInProgressVersionPrimary;if(null!==e)a=e===d;else if(a=a.mutableReadLanes,a=(xh&a)===a)b._workInProgressVersionPrimary=d,th.push(b);if(a)return c(b._source);th.push(b);throw Error(y(350));}
function Nh(a,b,c,d){var e=U;if(null===e)throw Error(y(349));var f=b._getVersion,g=f(b._source),h=vh.current,k=h.useState(function(){return Mh(e,b,c)}),l=k[1],n=k[0];k=T;var A=a.memoizedState,p=A.refs,C=p.getSnapshot,x=A.source;A=A.subscribe;var w=R;a.memoizedState={refs:p,source:b,subscribe:d};h.useEffect(function(){p.getSnapshot=c;p.setSnapshot=l;var a=f(b._source);if(!He(g,a)){a=c(b._source);He(n,a)||(l(a),a=Ig(w),e.mutableReadLanes|=a&e.pendingLanes);a=e.mutableReadLanes;e.entangledLanes|=a;for(var d=
e.entanglements,h=a;0<h;){var k=31-Vc(h),v=1<<k;d[k]|=a;h&=~v}}},[c,b,d]);h.useEffect(function(){return d(b._source,function(){var a=p.getSnapshot,c=p.setSnapshot;try{c(a(b._source));var d=Ig(w);e.mutableReadLanes|=d&e.pendingLanes}catch(q){c(function(){throw q;})}})},[b,d]);He(C,c)&&He(x,b)&&He(A,d)||(a={pending:null,dispatch:null,lastRenderedReducer:Jh,lastRenderedState:n},a.dispatch=l=Oh.bind(null,R,a),k.queue=a,k.baseQueue=null,n=Mh(e,b,c),k.memoizedState=k.baseState=n);return n}
function Ph(a,b,c){var d=Ih();return Nh(d,a,b,c)}function Qh(a){var b=Hh();"function"===typeof a&&(a=a());b.memoizedState=b.baseState=a;a=b.queue={pending:null,dispatch:null,lastRenderedReducer:Jh,lastRenderedState:a};a=a.dispatch=Oh.bind(null,R,a);return[b.memoizedState,a]}
function Rh(a,b,c,d){a={tag:a,create:b,destroy:c,deps:d,next:null};b=R.updateQueue;null===b?(b={lastEffect:null},R.updateQueue=b,b.lastEffect=a.next=a):(c=b.lastEffect,null===c?b.lastEffect=a.next=a:(d=c.next,c.next=a,a.next=d,b.lastEffect=a));return a}function Sh(a){var b=Hh();a={current:a};return b.memoizedState=a}function Th(){return Ih().memoizedState}function Uh(a,b,c,d){var e=Hh();R.flags|=a;e.memoizedState=Rh(1|b,c,void 0,void 0===d?null:d)}
function Vh(a,b,c,d){var e=Ih();d=void 0===d?null:d;var f=void 0;if(null!==S){var g=S.memoizedState;f=g.destroy;if(null!==d&&Bh(d,g.deps)){Rh(b,c,f,d);return}}R.flags|=a;e.memoizedState=Rh(1|b,c,f,d)}function Wh(a,b){return Uh(516,4,a,b)}function Xh(a,b){return Vh(516,4,a,b)}function Yh(a,b){return Vh(4,2,a,b)}function Zh(a,b){if("function"===typeof b)return a=a(),b(a),function(){b(null)};if(null!==b&&void 0!==b)return a=a(),b.current=a,function(){b.current=null}}
function $h(a,b,c){c=null!==c&&void 0!==c?c.concat([a]):null;return Vh(4,2,Zh.bind(null,b,a),c)}function ai(){}function bi(a,b){var c=Ih();b=void 0===b?null:b;var d=c.memoizedState;if(null!==d&&null!==b&&Bh(b,d[1]))return d[0];c.memoizedState=[a,b];return a}function ci(a,b){var c=Ih();b=void 0===b?null:b;var d=c.memoizedState;if(null!==d&&null!==b&&Bh(b,d[1]))return d[0];a=a();c.memoizedState=[a,b];return a}
function di(a,b){var c=eg();gg(98>c?98:c,function(){a(!0)});gg(97<c?97:c,function(){var c=wh.transition;wh.transition=1;try{a(!1),b()}finally{wh.transition=c}})}
function Oh(a,b,c){var d=Hg(),e=Ig(a),f={lane:e,action:c,eagerReducer:null,eagerState:null,next:null},g=b.pending;null===g?f.next=f:(f.next=g.next,g.next=f);b.pending=f;g=a.alternate;if(a===R||null!==g&&g===R)zh=yh=!0;else{if(0===a.lanes&&(null===g||0===g.lanes)&&(g=b.lastRenderedReducer,null!==g))try{var h=b.lastRenderedState,k=g(h,c);f.eagerReducer=g;f.eagerState=k;if(He(k,h))return}catch(l){}finally{}Jg(a,e,d)}}
var Gh={readContext:vg,useCallback:Ah,useContext:Ah,useEffect:Ah,useImperativeHandle:Ah,useLayoutEffect:Ah,useMemo:Ah,useReducer:Ah,useRef:Ah,useState:Ah,useDebugValue:Ah,useDeferredValue:Ah,useTransition:Ah,useMutableSource:Ah,useOpaqueIdentifier:Ah,unstable_isNewReconciler:!1},Dh={readContext:vg,useCallback:function(a,b){Hh().memoizedState=[a,void 0===b?null:b];return a},useContext:vg,useEffect:Wh,useImperativeHandle:function(a,b,c){c=null!==c&&void 0!==c?c.concat([a]):null;return Uh(4,2,Zh.bind(null,
b,a),c)},useLayoutEffect:function(a,b){return Uh(4,2,a,b)},useMemo:function(a,b){var c=Hh();b=void 0===b?null:b;a=a();c.memoizedState=[a,b];return a},useReducer:function(a,b,c){var d=Hh();b=void 0!==c?c(b):b;d.memoizedState=d.baseState=b;a=d.queue={pending:null,dispatch:null,lastRenderedReducer:a,lastRenderedState:b};a=a.dispatch=Oh.bind(null,R,a);return[d.memoizedState,a]},useRef:Sh,useState:Qh,useDebugValue:ai,useDeferredValue:function(a){var b=Qh(a),c=b[0],d=b[1];Wh(function(){var b=wh.transition;
wh.transition=1;try{d(a)}finally{wh.transition=b}},[a]);return c},useTransition:function(){var a=Qh(!1),b=a[0];a=di.bind(null,a[1]);Sh(a);return[a,b]},useMutableSource:function(a,b,c){var d=Hh();d.memoizedState={refs:{getSnapshot:b,setSnapshot:null},source:a,subscribe:c};return Nh(d,a,b,c)},useOpaqueIdentifier:function(){if(lh){var a=!1,b=uf(function(){a||(a=!0,c("r:"+(tf++).toString(36)));throw Error(y(355));}),c=Qh(b)[1];0===(R.mode&2)&&(R.flags|=516,Rh(5,function(){c("r:"+(tf++).toString(36))},
void 0,null));return b}b="r:"+(tf++).toString(36);Qh(b);return b},unstable_isNewReconciler:!1},Eh={readContext:vg,useCallback:bi,useContext:vg,useEffect:Xh,useImperativeHandle:$h,useLayoutEffect:Yh,useMemo:ci,useReducer:Kh,useRef:Th,useState:function(){return Kh(Jh)},useDebugValue:ai,useDeferredValue:function(a){var b=Kh(Jh),c=b[0],d=b[1];Xh(function(){var b=wh.transition;wh.transition=1;try{d(a)}finally{wh.transition=b}},[a]);return c},useTransition:function(){var a=Kh(Jh)[0];return[Th().current,
a]},useMutableSource:Ph,useOpaqueIdentifier:function(){return Kh(Jh)[0]},unstable_isNewReconciler:!1},Fh={readContext:vg,useCallback:bi,useContext:vg,useEffect:Xh,useImperativeHandle:$h,useLayoutEffect:Yh,useMemo:ci,useReducer:Lh,useRef:Th,useState:function(){return Lh(Jh)},useDebugValue:ai,useDeferredValue:function(a){var b=Lh(Jh),c=b[0],d=b[1];Xh(function(){var b=wh.transition;wh.transition=1;try{d(a)}finally{wh.transition=b}},[a]);return c},useTransition:function(){var a=Lh(Jh)[0];return[Th().current,
a]},useMutableSource:Ph,useOpaqueIdentifier:function(){return Lh(Jh)[0]},unstable_isNewReconciler:!1},ei=ra.ReactCurrentOwner,ug=!1;function fi(a,b,c,d){b.child=null===a?Zg(b,null,c,d):Yg(b,a.child,c,d)}function gi(a,b,c,d,e){c=c.render;var f=b.ref;tg(b,e);d=Ch(a,b,c,d,f,e);if(null!==a&&!ug)return b.updateQueue=a.updateQueue,b.flags&=-517,a.lanes&=~e,hi(a,b,e);b.flags|=1;fi(a,b,d,e);return b.child}
function ii(a,b,c,d,e,f){if(null===a){var g=c.type;if("function"===typeof g&&!ji(g)&&void 0===g.defaultProps&&null===c.compare&&void 0===c.defaultProps)return b.tag=15,b.type=g,ki(a,b,g,d,e,f);a=Vg(c.type,null,d,b,b.mode,f);a.ref=b.ref;a.return=b;return b.child=a}g=a.child;if(0===(e&f)&&(e=g.memoizedProps,c=c.compare,c=null!==c?c:Je,c(e,d)&&a.ref===b.ref))return hi(a,b,f);b.flags|=1;a=Tg(g,d);a.ref=b.ref;a.return=b;return b.child=a}
function ki(a,b,c,d,e,f){if(null!==a&&Je(a.memoizedProps,d)&&a.ref===b.ref)if(ug=!1,0!==(f&e))0!==(a.flags&16384)&&(ug=!0);else return b.lanes=a.lanes,hi(a,b,f);return li(a,b,c,d,f)}
function mi(a,b,c){var d=b.pendingProps,e=d.children,f=null!==a?a.memoizedState:null;if("hidden"===d.mode||"unstable-defer-without-hiding"===d.mode)if(0===(b.mode&4))b.memoizedState={baseLanes:0},ni(b,c);else if(0!==(c&1073741824))b.memoizedState={baseLanes:0},ni(b,null!==f?f.baseLanes:c);else return a=null!==f?f.baseLanes|c:c,b.lanes=b.childLanes=1073741824,b.memoizedState={baseLanes:a},ni(b,a),null;else null!==f?(d=f.baseLanes|c,b.memoizedState=null):d=c,ni(b,d);fi(a,b,e,c);return b.child}
function oi(a,b){var c=b.ref;if(null===a&&null!==c||null!==a&&a.ref!==c)b.flags|=128}function li(a,b,c,d,e){var f=Ff(c)?Df:M.current;f=Ef(b,f);tg(b,e);c=Ch(a,b,c,d,f,e);if(null!==a&&!ug)return b.updateQueue=a.updateQueue,b.flags&=-517,a.lanes&=~e,hi(a,b,e);b.flags|=1;fi(a,b,c,e);return b.child}
function pi(a,b,c,d,e){if(Ff(c)){var f=!0;Jf(b)}else f=!1;tg(b,e);if(null===b.stateNode)null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2),Mg(b,c,d),Og(b,c,d,e),d=!0;else if(null===a){var g=b.stateNode,h=b.memoizedProps;g.props=h;var k=g.context,l=c.contextType;"object"===typeof l&&null!==l?l=vg(l):(l=Ff(c)?Df:M.current,l=Ef(b,l));var n=c.getDerivedStateFromProps,A="function"===typeof n||"function"===typeof g.getSnapshotBeforeUpdate;A||"function"!==typeof g.UNSAFE_componentWillReceiveProps&&
"function"!==typeof g.componentWillReceiveProps||(h!==d||k!==l)&&Ng(b,g,d,l);wg=!1;var p=b.memoizedState;g.state=p;Cg(b,d,g,e);k=b.memoizedState;h!==d||p!==k||N.current||wg?("function"===typeof n&&(Gg(b,c,n,d),k=b.memoizedState),(h=wg||Lg(b,c,h,d,p,k,l))?(A||"function"!==typeof g.UNSAFE_componentWillMount&&"function"!==typeof g.componentWillMount||("function"===typeof g.componentWillMount&&g.componentWillMount(),"function"===typeof g.UNSAFE_componentWillMount&&g.UNSAFE_componentWillMount()),"function"===
typeof g.componentDidMount&&(b.flags|=4)):("function"===typeof g.componentDidMount&&(b.flags|=4),b.memoizedProps=d,b.memoizedState=k),g.props=d,g.state=k,g.context=l,d=h):("function"===typeof g.componentDidMount&&(b.flags|=4),d=!1)}else{g=b.stateNode;yg(a,b);h=b.memoizedProps;l=b.type===b.elementType?h:lg(b.type,h);g.props=l;A=b.pendingProps;p=g.context;k=c.contextType;"object"===typeof k&&null!==k?k=vg(k):(k=Ff(c)?Df:M.current,k=Ef(b,k));var C=c.getDerivedStateFromProps;(n="function"===typeof C||
"function"===typeof g.getSnapshotBeforeUpdate)||"function"!==typeof g.UNSAFE_componentWillReceiveProps&&"function"!==typeof g.componentWillReceiveProps||(h!==A||p!==k)&&Ng(b,g,d,k);wg=!1;p=b.memoizedState;g.state=p;Cg(b,d,g,e);var x=b.memoizedState;h!==A||p!==x||N.current||wg?("function"===typeof C&&(Gg(b,c,C,d),x=b.memoizedState),(l=wg||Lg(b,c,l,d,p,x,k))?(n||"function"!==typeof g.UNSAFE_componentWillUpdate&&"function"!==typeof g.componentWillUpdate||("function"===typeof g.componentWillUpdate&&g.componentWillUpdate(d,
x,k),"function"===typeof g.UNSAFE_componentWillUpdate&&g.UNSAFE_componentWillUpdate(d,x,k)),"function"===typeof g.componentDidUpdate&&(b.flags|=4),"function"===typeof g.getSnapshotBeforeUpdate&&(b.flags|=256)):("function"!==typeof g.componentDidUpdate||h===a.memoizedProps&&p===a.memoizedState||(b.flags|=4),"function"!==typeof g.getSnapshotBeforeUpdate||h===a.memoizedProps&&p===a.memoizedState||(b.flags|=256),b.memoizedProps=d,b.memoizedState=x),g.props=d,g.state=x,g.context=k,d=l):("function"!==typeof g.componentDidUpdate||
h===a.memoizedProps&&p===a.memoizedState||(b.flags|=4),"function"!==typeof g.getSnapshotBeforeUpdate||h===a.memoizedProps&&p===a.memoizedState||(b.flags|=256),d=!1)}return qi(a,b,c,d,f,e)}
function qi(a,b,c,d,e,f){oi(a,b);var g=0!==(b.flags&64);if(!d&&!g)return e&&Kf(b,c,!1),hi(a,b,f);d=b.stateNode;ei.current=b;var h=g&&"function"!==typeof c.getDerivedStateFromError?null:d.render();b.flags|=1;null!==a&&g?(b.child=Yg(b,a.child,null,f),b.child=Yg(b,null,h,f)):fi(a,b,h,f);b.memoizedState=d.state;e&&Kf(b,c,!0);return b.child}function ri(a){var b=a.stateNode;b.pendingContext?Hf(a,b.pendingContext,b.pendingContext!==b.context):b.context&&Hf(a,b.context,!1);eh(a,b.containerInfo)}
var si={dehydrated:null,retryLane:0};
function ti(a,b,c){var d=b.pendingProps,e=P.current,f=!1,g;(g=0!==(b.flags&64))||(g=null!==a&&null===a.memoizedState?!1:0!==(e&2));g?(f=!0,b.flags&=-65):null!==a&&null===a.memoizedState||void 0===d.fallback||!0===d.unstable_avoidThisFallback||(e|=1);I(P,e&1);if(null===a){void 0!==d.fallback&&ph(b);a=d.children;e=d.fallback;if(f)return a=ui(b,a,e,c),b.child.memoizedState={baseLanes:c},b.memoizedState=si,a;if("number"===typeof d.unstable_expectedLoadTime)return a=ui(b,a,e,c),b.child.memoizedState={baseLanes:c},
b.memoizedState=si,b.lanes=33554432,a;c=vi({mode:"visible",children:a},b.mode,c,null);c.return=b;return b.child=c}if(null!==a.memoizedState){if(f)return d=wi(a,b,d.children,d.fallback,c),f=b.child,e=a.child.memoizedState,f.memoizedState=null===e?{baseLanes:c}:{baseLanes:e.baseLanes|c},f.childLanes=a.childLanes&~c,b.memoizedState=si,d;c=xi(a,b,d.children,c);b.memoizedState=null;return c}if(f)return d=wi(a,b,d.children,d.fallback,c),f=b.child,e=a.child.memoizedState,f.memoizedState=null===e?{baseLanes:c}:
{baseLanes:e.baseLanes|c},f.childLanes=a.childLanes&~c,b.memoizedState=si,d;c=xi(a,b,d.children,c);b.memoizedState=null;return c}function ui(a,b,c,d){var e=a.mode,f=a.child;b={mode:"hidden",children:b};0===(e&2)&&null!==f?(f.childLanes=0,f.pendingProps=b):f=vi(b,e,0,null);c=Xg(c,e,d,null);f.return=a;c.return=a;f.sibling=c;a.child=f;return c}
function xi(a,b,c,d){var e=a.child;a=e.sibling;c=Tg(e,{mode:"visible",children:c});0===(b.mode&2)&&(c.lanes=d);c.return=b;c.sibling=null;null!==a&&(a.nextEffect=null,a.flags=8,b.firstEffect=b.lastEffect=a);return b.child=c}
function wi(a,b,c,d,e){var f=b.mode,g=a.child;a=g.sibling;var h={mode:"hidden",children:c};0===(f&2)&&b.child!==g?(c=b.child,c.childLanes=0,c.pendingProps=h,g=c.lastEffect,null!==g?(b.firstEffect=c.firstEffect,b.lastEffect=g,g.nextEffect=null):b.firstEffect=b.lastEffect=null):c=Tg(g,h);null!==a?d=Tg(a,d):(d=Xg(d,f,e,null),d.flags|=2);d.return=b;c.return=b;c.sibling=d;b.child=c;return d}function yi(a,b){a.lanes|=b;var c=a.alternate;null!==c&&(c.lanes|=b);sg(a.return,b)}
function zi(a,b,c,d,e,f){var g=a.memoizedState;null===g?a.memoizedState={isBackwards:b,rendering:null,renderingStartTime:0,last:d,tail:c,tailMode:e,lastEffect:f}:(g.isBackwards=b,g.rendering=null,g.renderingStartTime=0,g.last=d,g.tail=c,g.tailMode=e,g.lastEffect=f)}
function Ai(a,b,c){var d=b.pendingProps,e=d.revealOrder,f=d.tail;fi(a,b,d.children,c);d=P.current;if(0!==(d&2))d=d&1|2,b.flags|=64;else{if(null!==a&&0!==(a.flags&64))a:for(a=b.child;null!==a;){if(13===a.tag)null!==a.memoizedState&&yi(a,c);else if(19===a.tag)yi(a,c);else if(null!==a.child){a.child.return=a;a=a.child;continue}if(a===b)break a;for(;null===a.sibling;){if(null===a.return||a.return===b)break a;a=a.return}a.sibling.return=a.return;a=a.sibling}d&=1}I(P,d);if(0===(b.mode&2))b.memoizedState=
null;else switch(e){case "forwards":c=b.child;for(e=null;null!==c;)a=c.alternate,null!==a&&null===ih(a)&&(e=c),c=c.sibling;c=e;null===c?(e=b.child,b.child=null):(e=c.sibling,c.sibling=null);zi(b,!1,e,c,f,b.lastEffect);break;case "backwards":c=null;e=b.child;for(b.child=null;null!==e;){a=e.alternate;if(null!==a&&null===ih(a)){b.child=e;break}a=e.sibling;e.sibling=c;c=e;e=a}zi(b,!0,c,null,f,b.lastEffect);break;case "together":zi(b,!1,null,null,void 0,b.lastEffect);break;default:b.memoizedState=null}return b.child}
function hi(a,b,c){null!==a&&(b.dependencies=a.dependencies);Dg|=b.lanes;if(0!==(c&b.childLanes)){if(null!==a&&b.child!==a.child)throw Error(y(153));if(null!==b.child){a=b.child;c=Tg(a,a.pendingProps);b.child=c;for(c.return=b;null!==a.sibling;)a=a.sibling,c=c.sibling=Tg(a,a.pendingProps),c.return=b;c.sibling=null}return b.child}return null}var Bi,Ci,Di,Ei;
Bi=function(a,b){for(var c=b.child;null!==c;){if(5===c.tag||6===c.tag)a.appendChild(c.stateNode);else if(4!==c.tag&&null!==c.child){c.child.return=c;c=c.child;continue}if(c===b)break;for(;null===c.sibling;){if(null===c.return||c.return===b)return;c=c.return}c.sibling.return=c.return;c=c.sibling}};Ci=function(){};
Di=function(a,b,c,d){var e=a.memoizedProps;if(e!==d){a=b.stateNode;dh(ah.current);var f=null;switch(c){case "input":e=Ya(a,e);d=Ya(a,d);f=[];break;case "option":e=eb(a,e);d=eb(a,d);f=[];break;case "select":e=m({},e,{value:void 0});d=m({},d,{value:void 0});f=[];break;case "textarea":e=gb(a,e);d=gb(a,d);f=[];break;default:"function"!==typeof e.onClick&&"function"===typeof d.onClick&&(a.onclick=jf)}vb(c,d);var g;c=null;for(l in e)if(!d.hasOwnProperty(l)&&e.hasOwnProperty(l)&&null!=e[l])if("style"===
l){var h=e[l];for(g in h)h.hasOwnProperty(g)&&(c||(c={}),c[g]="")}else"dangerouslySetInnerHTML"!==l&&"children"!==l&&"suppressContentEditableWarning"!==l&&"suppressHydrationWarning"!==l&&"autoFocus"!==l&&(ca.hasOwnProperty(l)?f||(f=[]):(f=f||[]).push(l,null));for(l in d){var k=d[l];h=null!=e?e[l]:void 0;if(d.hasOwnProperty(l)&&k!==h&&(null!=k||null!=h))if("style"===l)if(h){for(g in h)!h.hasOwnProperty(g)||k&&k.hasOwnProperty(g)||(c||(c={}),c[g]="");for(g in k)k.hasOwnProperty(g)&&h[g]!==k[g]&&(c||
(c={}),c[g]=k[g])}else c||(f||(f=[]),f.push(l,c)),c=k;else"dangerouslySetInnerHTML"===l?(k=k?k.__html:void 0,h=h?h.__html:void 0,null!=k&&h!==k&&(f=f||[]).push(l,k)):"children"===l?"string"!==typeof k&&"number"!==typeof k||(f=f||[]).push(l,""+k):"suppressContentEditableWarning"!==l&&"suppressHydrationWarning"!==l&&(ca.hasOwnProperty(l)?(null!=k&&"onScroll"===l&&G("scroll",a),f||h===k||(f=[])):"object"===typeof k&&null!==k&&k.$$typeof===Ga?k.toString():(f=f||[]).push(l,k))}c&&(f=f||[]).push("style",
c);var l=f;if(b.updateQueue=l)b.flags|=4}};Ei=function(a,b,c,d){c!==d&&(b.flags|=4)};function Fi(a,b){if(!lh)switch(a.tailMode){case "hidden":b=a.tail;for(var c=null;null!==b;)null!==b.alternate&&(c=b),b=b.sibling;null===c?a.tail=null:c.sibling=null;break;case "collapsed":c=a.tail;for(var d=null;null!==c;)null!==c.alternate&&(d=c),c=c.sibling;null===d?b||null===a.tail?a.tail=null:a.tail.sibling=null:d.sibling=null}}
function Gi(a,b,c){var d=b.pendingProps;switch(b.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return null;case 1:return Ff(b.type)&&Gf(),null;case 3:fh();H(N);H(M);uh();d=b.stateNode;d.pendingContext&&(d.context=d.pendingContext,d.pendingContext=null);if(null===a||null===a.child)rh(b)?b.flags|=4:d.hydrate||(b.flags|=256);Ci(b);return null;case 5:hh(b);var e=dh(ch.current);c=b.type;if(null!==a&&null!=b.stateNode)Di(a,b,c,d,e),a.ref!==b.ref&&(b.flags|=128);else{if(!d){if(null===
b.stateNode)throw Error(y(166));return null}a=dh(ah.current);if(rh(b)){d=b.stateNode;c=b.type;var f=b.memoizedProps;d[wf]=b;d[xf]=f;switch(c){case "dialog":G("cancel",d);G("close",d);break;case "iframe":case "object":case "embed":G("load",d);break;case "video":case "audio":for(a=0;a<Xe.length;a++)G(Xe[a],d);break;case "source":G("error",d);break;case "img":case "image":case "link":G("error",d);G("load",d);break;case "details":G("toggle",d);break;case "input":Za(d,f);G("invalid",d);break;case "select":d._wrapperState=
{wasMultiple:!!f.multiple};G("invalid",d);break;case "textarea":hb(d,f),G("invalid",d)}vb(c,f);a=null;for(var g in f)f.hasOwnProperty(g)&&(e=f[g],"children"===g?"string"===typeof e?d.textContent!==e&&(a=["children",e]):"number"===typeof e&&d.textContent!==""+e&&(a=["children",""+e]):ca.hasOwnProperty(g)&&null!=e&&"onScroll"===g&&G("scroll",d));switch(c){case "input":Va(d);cb(d,f,!0);break;case "textarea":Va(d);jb(d);break;case "select":case "option":break;default:"function"===typeof f.onClick&&(d.onclick=
jf)}d=a;b.updateQueue=d;null!==d&&(b.flags|=4)}else{g=9===e.nodeType?e:e.ownerDocument;a===kb.html&&(a=lb(c));a===kb.html?"script"===c?(a=g.createElement("div"),a.innerHTML="<script>\x3c/script>",a=a.removeChild(a.firstChild)):"string"===typeof d.is?a=g.createElement(c,{is:d.is}):(a=g.createElement(c),"select"===c&&(g=a,d.multiple?g.multiple=!0:d.size&&(g.size=d.size))):a=g.createElementNS(a,c);a[wf]=b;a[xf]=d;Bi(a,b,!1,!1);b.stateNode=a;g=wb(c,d);switch(c){case "dialog":G("cancel",a);G("close",a);
e=d;break;case "iframe":case "object":case "embed":G("load",a);e=d;break;case "video":case "audio":for(e=0;e<Xe.length;e++)G(Xe[e],a);e=d;break;case "source":G("error",a);e=d;break;case "img":case "image":case "link":G("error",a);G("load",a);e=d;break;case "details":G("toggle",a);e=d;break;case "input":Za(a,d);e=Ya(a,d);G("invalid",a);break;case "option":e=eb(a,d);break;case "select":a._wrapperState={wasMultiple:!!d.multiple};e=m({},d,{value:void 0});G("invalid",a);break;case "textarea":hb(a,d);e=
gb(a,d);G("invalid",a);break;default:e=d}vb(c,e);var h=e;for(f in h)if(h.hasOwnProperty(f)){var k=h[f];"style"===f?tb(a,k):"dangerouslySetInnerHTML"===f?(k=k?k.__html:void 0,null!=k&&ob(a,k)):"children"===f?"string"===typeof k?("textarea"!==c||""!==k)&&pb(a,k):"number"===typeof k&&pb(a,""+k):"suppressContentEditableWarning"!==f&&"suppressHydrationWarning"!==f&&"autoFocus"!==f&&(ca.hasOwnProperty(f)?null!=k&&"onScroll"===f&&G("scroll",a):null!=k&&qa(a,f,k,g))}switch(c){case "input":Va(a);cb(a,d,!1);
break;case "textarea":Va(a);jb(a);break;case "option":null!=d.value&&a.setAttribute("value",""+Sa(d.value));break;case "select":a.multiple=!!d.multiple;f=d.value;null!=f?fb(a,!!d.multiple,f,!1):null!=d.defaultValue&&fb(a,!!d.multiple,d.defaultValue,!0);break;default:"function"===typeof e.onClick&&(a.onclick=jf)}mf(c,d)&&(b.flags|=4)}null!==b.ref&&(b.flags|=128)}return null;case 6:if(a&&null!=b.stateNode)Ei(a,b,a.memoizedProps,d);else{if("string"!==typeof d&&null===b.stateNode)throw Error(y(166));
c=dh(ch.current);dh(ah.current);rh(b)?(d=b.stateNode,c=b.memoizedProps,d[wf]=b,d.nodeValue!==c&&(b.flags|=4)):(d=(9===c.nodeType?c:c.ownerDocument).createTextNode(d),d[wf]=b,b.stateNode=d)}return null;case 13:H(P);d=b.memoizedState;if(0!==(b.flags&64))return b.lanes=c,b;d=null!==d;c=!1;null===a?void 0!==b.memoizedProps.fallback&&rh(b):c=null!==a.memoizedState;if(d&&!c&&0!==(b.mode&2))if(null===a&&!0!==b.memoizedProps.unstable_avoidThisFallback||0!==(P.current&1))0===V&&(V=3);else{if(0===V||3===V)V=
4;null===U||0===(Dg&134217727)&&0===(Hi&134217727)||Ii(U,W)}if(d||c)b.flags|=4;return null;case 4:return fh(),Ci(b),null===a&&cf(b.stateNode.containerInfo),null;case 10:return rg(b),null;case 17:return Ff(b.type)&&Gf(),null;case 19:H(P);d=b.memoizedState;if(null===d)return null;f=0!==(b.flags&64);g=d.rendering;if(null===g)if(f)Fi(d,!1);else{if(0!==V||null!==a&&0!==(a.flags&64))for(a=b.child;null!==a;){g=ih(a);if(null!==g){b.flags|=64;Fi(d,!1);f=g.updateQueue;null!==f&&(b.updateQueue=f,b.flags|=4);
null===d.lastEffect&&(b.firstEffect=null);b.lastEffect=d.lastEffect;d=c;for(c=b.child;null!==c;)f=c,a=d,f.flags&=2,f.nextEffect=null,f.firstEffect=null,f.lastEffect=null,g=f.alternate,null===g?(f.childLanes=0,f.lanes=a,f.child=null,f.memoizedProps=null,f.memoizedState=null,f.updateQueue=null,f.dependencies=null,f.stateNode=null):(f.childLanes=g.childLanes,f.lanes=g.lanes,f.child=g.child,f.memoizedProps=g.memoizedProps,f.memoizedState=g.memoizedState,f.updateQueue=g.updateQueue,f.type=g.type,a=g.dependencies,
f.dependencies=null===a?null:{lanes:a.lanes,firstContext:a.firstContext}),c=c.sibling;I(P,P.current&1|2);return b.child}a=a.sibling}null!==d.tail&&O()>Ji&&(b.flags|=64,f=!0,Fi(d,!1),b.lanes=33554432)}else{if(!f)if(a=ih(g),null!==a){if(b.flags|=64,f=!0,c=a.updateQueue,null!==c&&(b.updateQueue=c,b.flags|=4),Fi(d,!0),null===d.tail&&"hidden"===d.tailMode&&!g.alternate&&!lh)return b=b.lastEffect=d.lastEffect,null!==b&&(b.nextEffect=null),null}else 2*O()-d.renderingStartTime>Ji&&1073741824!==c&&(b.flags|=
64,f=!0,Fi(d,!1),b.lanes=33554432);d.isBackwards?(g.sibling=b.child,b.child=g):(c=d.last,null!==c?c.sibling=g:b.child=g,d.last=g)}return null!==d.tail?(c=d.tail,d.rendering=c,d.tail=c.sibling,d.lastEffect=b.lastEffect,d.renderingStartTime=O(),c.sibling=null,b=P.current,I(P,f?b&1|2:b&1),c):null;case 23:case 24:return Ki(),null!==a&&null!==a.memoizedState!==(null!==b.memoizedState)&&"unstable-defer-without-hiding"!==d.mode&&(b.flags|=4),null}throw Error(y(156,b.tag));}
function Li(a){switch(a.tag){case 1:Ff(a.type)&&Gf();var b=a.flags;return b&4096?(a.flags=b&-4097|64,a):null;case 3:fh();H(N);H(M);uh();b=a.flags;if(0!==(b&64))throw Error(y(285));a.flags=b&-4097|64;return a;case 5:return hh(a),null;case 13:return H(P),b=a.flags,b&4096?(a.flags=b&-4097|64,a):null;case 19:return H(P),null;case 4:return fh(),null;case 10:return rg(a),null;case 23:case 24:return Ki(),null;default:return null}}
function Mi(a,b){try{var c="",d=b;do c+=Qa(d),d=d.return;while(d);var e=c}catch(f){e="\nError generating stack: "+f.message+"\n"+f.stack}return{value:a,source:b,stack:e}}function Ni(a,b){try{console.error(b.value)}catch(c){setTimeout(function(){throw c;})}}var Oi="function"===typeof WeakMap?WeakMap:Map;function Pi(a,b,c){c=zg(-1,c);c.tag=3;c.payload={element:null};var d=b.value;c.callback=function(){Qi||(Qi=!0,Ri=d);Ni(a,b)};return c}
function Si(a,b,c){c=zg(-1,c);c.tag=3;var d=a.type.getDerivedStateFromError;if("function"===typeof d){var e=b.value;c.payload=function(){Ni(a,b);return d(e)}}var f=a.stateNode;null!==f&&"function"===typeof f.componentDidCatch&&(c.callback=function(){"function"!==typeof d&&(null===Ti?Ti=new Set([this]):Ti.add(this),Ni(a,b));var c=b.stack;this.componentDidCatch(b.value,{componentStack:null!==c?c:""})});return c}var Ui="function"===typeof WeakSet?WeakSet:Set;
function Vi(a){var b=a.ref;if(null!==b)if("function"===typeof b)try{b(null)}catch(c){Wi(a,c)}else b.current=null}function Xi(a,b){switch(b.tag){case 0:case 11:case 15:case 22:return;case 1:if(b.flags&256&&null!==a){var c=a.memoizedProps,d=a.memoizedState;a=b.stateNode;b=a.getSnapshotBeforeUpdate(b.elementType===b.type?c:lg(b.type,c),d);a.__reactInternalSnapshotBeforeUpdate=b}return;case 3:b.flags&256&&qf(b.stateNode.containerInfo);return;case 5:case 6:case 4:case 17:return}throw Error(y(163));}
function Yi(a,b,c){switch(c.tag){case 0:case 11:case 15:case 22:b=c.updateQueue;b=null!==b?b.lastEffect:null;if(null!==b){a=b=b.next;do{if(3===(a.tag&3)){var d=a.create;a.destroy=d()}a=a.next}while(a!==b)}b=c.updateQueue;b=null!==b?b.lastEffect:null;if(null!==b){a=b=b.next;do{var e=a;d=e.next;e=e.tag;0!==(e&4)&&0!==(e&1)&&(Zi(c,a),$i(c,a));a=d}while(a!==b)}return;case 1:a=c.stateNode;c.flags&4&&(null===b?a.componentDidMount():(d=c.elementType===c.type?b.memoizedProps:lg(c.type,b.memoizedProps),a.componentDidUpdate(d,
b.memoizedState,a.__reactInternalSnapshotBeforeUpdate)));b=c.updateQueue;null!==b&&Eg(c,b,a);return;case 3:b=c.updateQueue;if(null!==b){a=null;if(null!==c.child)switch(c.child.tag){case 5:a=c.child.stateNode;break;case 1:a=c.child.stateNode}Eg(c,b,a)}return;case 5:a=c.stateNode;null===b&&c.flags&4&&mf(c.type,c.memoizedProps)&&a.focus();return;case 6:return;case 4:return;case 12:return;case 13:null===c.memoizedState&&(c=c.alternate,null!==c&&(c=c.memoizedState,null!==c&&(c=c.dehydrated,null!==c&&Cc(c))));
return;case 19:case 17:case 20:case 21:case 23:case 24:return}throw Error(y(163));}
function aj(a,b){for(var c=a;;){if(5===c.tag){var d=c.stateNode;if(b)d=d.style,"function"===typeof d.setProperty?d.setProperty("display","none","important"):d.display="none";else{d=c.stateNode;var e=c.memoizedProps.style;e=void 0!==e&&null!==e&&e.hasOwnProperty("display")?e.display:null;d.style.display=sb("display",e)}}else if(6===c.tag)c.stateNode.nodeValue=b?"":c.memoizedProps;else if((23!==c.tag&&24!==c.tag||null===c.memoizedState||c===a)&&null!==c.child){c.child.return=c;c=c.child;continue}if(c===
a)break;for(;null===c.sibling;){if(null===c.return||c.return===a)return;c=c.return}c.sibling.return=c.return;c=c.sibling}}
function bj(a,b){if(Mf&&"function"===typeof Mf.onCommitFiberUnmount)try{Mf.onCommitFiberUnmount(Lf,b)}catch(f){}switch(b.tag){case 0:case 11:case 14:case 15:case 22:a=b.updateQueue;if(null!==a&&(a=a.lastEffect,null!==a)){var c=a=a.next;do{var d=c,e=d.destroy;d=d.tag;if(void 0!==e)if(0!==(d&4))Zi(b,c);else{d=b;try{e()}catch(f){Wi(d,f)}}c=c.next}while(c!==a)}break;case 1:Vi(b);a=b.stateNode;if("function"===typeof a.componentWillUnmount)try{a.props=b.memoizedProps,a.state=b.memoizedState,a.componentWillUnmount()}catch(f){Wi(b,
f)}break;case 5:Vi(b);break;case 4:cj(a,b)}}function dj(a){a.alternate=null;a.child=null;a.dependencies=null;a.firstEffect=null;a.lastEffect=null;a.memoizedProps=null;a.memoizedState=null;a.pendingProps=null;a.return=null;a.updateQueue=null}function ej(a){return 5===a.tag||3===a.tag||4===a.tag}
function fj(a){a:{for(var b=a.return;null!==b;){if(ej(b))break a;b=b.return}throw Error(y(160));}var c=b;b=c.stateNode;switch(c.tag){case 5:var d=!1;break;case 3:b=b.containerInfo;d=!0;break;case 4:b=b.containerInfo;d=!0;break;default:throw Error(y(161));}c.flags&16&&(pb(b,""),c.flags&=-17);a:b:for(c=a;;){for(;null===c.sibling;){if(null===c.return||ej(c.return)){c=null;break a}c=c.return}c.sibling.return=c.return;for(c=c.sibling;5!==c.tag&&6!==c.tag&&18!==c.tag;){if(c.flags&2)continue b;if(null===
c.child||4===c.tag)continue b;else c.child.return=c,c=c.child}if(!(c.flags&2)){c=c.stateNode;break a}}d?gj(a,c,b):hj(a,c,b)}
function gj(a,b,c){var d=a.tag,e=5===d||6===d;if(e)a=e?a.stateNode:a.stateNode.instance,b?8===c.nodeType?c.parentNode.insertBefore(a,b):c.insertBefore(a,b):(8===c.nodeType?(b=c.parentNode,b.insertBefore(a,c)):(b=c,b.appendChild(a)),c=c._reactRootContainer,null!==c&&void 0!==c||null!==b.onclick||(b.onclick=jf));else if(4!==d&&(a=a.child,null!==a))for(gj(a,b,c),a=a.sibling;null!==a;)gj(a,b,c),a=a.sibling}
function hj(a,b,c){var d=a.tag,e=5===d||6===d;if(e)a=e?a.stateNode:a.stateNode.instance,b?c.insertBefore(a,b):c.appendChild(a);else if(4!==d&&(a=a.child,null!==a))for(hj(a,b,c),a=a.sibling;null!==a;)hj(a,b,c),a=a.sibling}
function cj(a,b){for(var c=b,d=!1,e,f;;){if(!d){d=c.return;a:for(;;){if(null===d)throw Error(y(160));e=d.stateNode;switch(d.tag){case 5:f=!1;break a;case 3:e=e.containerInfo;f=!0;break a;case 4:e=e.containerInfo;f=!0;break a}d=d.return}d=!0}if(5===c.tag||6===c.tag){a:for(var g=a,h=c,k=h;;)if(bj(g,k),null!==k.child&&4!==k.tag)k.child.return=k,k=k.child;else{if(k===h)break a;for(;null===k.sibling;){if(null===k.return||k.return===h)break a;k=k.return}k.sibling.return=k.return;k=k.sibling}f?(g=e,h=c.stateNode,
8===g.nodeType?g.parentNode.removeChild(h):g.removeChild(h)):e.removeChild(c.stateNode)}else if(4===c.tag){if(null!==c.child){e=c.stateNode.containerInfo;f=!0;c.child.return=c;c=c.child;continue}}else if(bj(a,c),null!==c.child){c.child.return=c;c=c.child;continue}if(c===b)break;for(;null===c.sibling;){if(null===c.return||c.return===b)return;c=c.return;4===c.tag&&(d=!1)}c.sibling.return=c.return;c=c.sibling}}
function ij(a,b){switch(b.tag){case 0:case 11:case 14:case 15:case 22:var c=b.updateQueue;c=null!==c?c.lastEffect:null;if(null!==c){var d=c=c.next;do 3===(d.tag&3)&&(a=d.destroy,d.destroy=void 0,void 0!==a&&a()),d=d.next;while(d!==c)}return;case 1:return;case 5:c=b.stateNode;if(null!=c){d=b.memoizedProps;var e=null!==a?a.memoizedProps:d;a=b.type;var f=b.updateQueue;b.updateQueue=null;if(null!==f){c[xf]=d;"input"===a&&"radio"===d.type&&null!=d.name&&$a(c,d);wb(a,e);b=wb(a,d);for(e=0;e<f.length;e+=
2){var g=f[e],h=f[e+1];"style"===g?tb(c,h):"dangerouslySetInnerHTML"===g?ob(c,h):"children"===g?pb(c,h):qa(c,g,h,b)}switch(a){case "input":ab(c,d);break;case "textarea":ib(c,d);break;case "select":a=c._wrapperState.wasMultiple,c._wrapperState.wasMultiple=!!d.multiple,f=d.value,null!=f?fb(c,!!d.multiple,f,!1):a!==!!d.multiple&&(null!=d.defaultValue?fb(c,!!d.multiple,d.defaultValue,!0):fb(c,!!d.multiple,d.multiple?[]:"",!1))}}}return;case 6:if(null===b.stateNode)throw Error(y(162));b.stateNode.nodeValue=
b.memoizedProps;return;case 3:c=b.stateNode;c.hydrate&&(c.hydrate=!1,Cc(c.containerInfo));return;case 12:return;case 13:null!==b.memoizedState&&(jj=O(),aj(b.child,!0));kj(b);return;case 19:kj(b);return;case 17:return;case 23:case 24:aj(b,null!==b.memoizedState);return}throw Error(y(163));}function kj(a){var b=a.updateQueue;if(null!==b){a.updateQueue=null;var c=a.stateNode;null===c&&(c=a.stateNode=new Ui);b.forEach(function(b){var d=lj.bind(null,a,b);c.has(b)||(c.add(b),b.then(d,d))})}}
function mj(a,b){return null!==a&&(a=a.memoizedState,null===a||null!==a.dehydrated)?(b=b.memoizedState,null!==b&&null===b.dehydrated):!1}var nj=Math.ceil,oj=ra.ReactCurrentDispatcher,pj=ra.ReactCurrentOwner,X=0,U=null,Y=null,W=0,qj=0,rj=Bf(0),V=0,sj=null,tj=0,Dg=0,Hi=0,uj=0,vj=null,jj=0,Ji=Infinity;function wj(){Ji=O()+500}var Z=null,Qi=!1,Ri=null,Ti=null,xj=!1,yj=null,zj=90,Aj=[],Bj=[],Cj=null,Dj=0,Ej=null,Fj=-1,Gj=0,Hj=0,Ij=null,Jj=!1;function Hg(){return 0!==(X&48)?O():-1!==Fj?Fj:Fj=O()}
function Ig(a){a=a.mode;if(0===(a&2))return 1;if(0===(a&4))return 99===eg()?1:2;0===Gj&&(Gj=tj);if(0!==kg.transition){0!==Hj&&(Hj=null!==vj?vj.pendingLanes:0);a=Gj;var b=4186112&~Hj;b&=-b;0===b&&(a=4186112&~a,b=a&-a,0===b&&(b=8192));return b}a=eg();0!==(X&4)&&98===a?a=Xc(12,Gj):(a=Sc(a),a=Xc(a,Gj));return a}
function Jg(a,b,c){if(50<Dj)throw Dj=0,Ej=null,Error(y(185));a=Kj(a,b);if(null===a)return null;$c(a,b,c);a===U&&(Hi|=b,4===V&&Ii(a,W));var d=eg();1===b?0!==(X&8)&&0===(X&48)?Lj(a):(Mj(a,c),0===X&&(wj(),ig())):(0===(X&4)||98!==d&&99!==d||(null===Cj?Cj=new Set([a]):Cj.add(a)),Mj(a,c));vj=a}function Kj(a,b){a.lanes|=b;var c=a.alternate;null!==c&&(c.lanes|=b);c=a;for(a=a.return;null!==a;)a.childLanes|=b,c=a.alternate,null!==c&&(c.childLanes|=b),c=a,a=a.return;return 3===c.tag?c.stateNode:null}
function Mj(a,b){for(var c=a.callbackNode,d=a.suspendedLanes,e=a.pingedLanes,f=a.expirationTimes,g=a.pendingLanes;0<g;){var h=31-Vc(g),k=1<<h,l=f[h];if(-1===l){if(0===(k&d)||0!==(k&e)){l=b;Rc(k);var n=F;f[h]=10<=n?l+250:6<=n?l+5E3:-1}}else l<=b&&(a.expiredLanes|=k);g&=~k}d=Uc(a,a===U?W:0);b=F;if(0===d)null!==c&&(c!==Zf&&Pf(c),a.callbackNode=null,a.callbackPriority=0);else{if(null!==c){if(a.callbackPriority===b)return;c!==Zf&&Pf(c)}15===b?(c=Lj.bind(null,a),null===ag?(ag=[c],bg=Of(Uf,jg)):ag.push(c),
c=Zf):14===b?c=hg(99,Lj.bind(null,a)):(c=Tc(b),c=hg(c,Nj.bind(null,a)));a.callbackPriority=b;a.callbackNode=c}}
function Nj(a){Fj=-1;Hj=Gj=0;if(0!==(X&48))throw Error(y(327));var b=a.callbackNode;if(Oj()&&a.callbackNode!==b)return null;var c=Uc(a,a===U?W:0);if(0===c)return null;var d=c;var e=X;X|=16;var f=Pj();if(U!==a||W!==d)wj(),Qj(a,d);do try{Rj();break}catch(h){Sj(a,h)}while(1);qg();oj.current=f;X=e;null!==Y?d=0:(U=null,W=0,d=V);if(0!==(tj&Hi))Qj(a,0);else if(0!==d){2===d&&(X|=64,a.hydrate&&(a.hydrate=!1,qf(a.containerInfo)),c=Wc(a),0!==c&&(d=Tj(a,c)));if(1===d)throw b=sj,Qj(a,0),Ii(a,c),Mj(a,O()),b;a.finishedWork=
a.current.alternate;a.finishedLanes=c;switch(d){case 0:case 1:throw Error(y(345));case 2:Uj(a);break;case 3:Ii(a,c);if((c&62914560)===c&&(d=jj+500-O(),10<d)){if(0!==Uc(a,0))break;e=a.suspendedLanes;if((e&c)!==c){Hg();a.pingedLanes|=a.suspendedLanes&e;break}a.timeoutHandle=of(Uj.bind(null,a),d);break}Uj(a);break;case 4:Ii(a,c);if((c&4186112)===c)break;d=a.eventTimes;for(e=-1;0<c;){var g=31-Vc(c);f=1<<g;g=d[g];g>e&&(e=g);c&=~f}c=e;c=O()-c;c=(120>c?120:480>c?480:1080>c?1080:1920>c?1920:3E3>c?3E3:4320>
c?4320:1960*nj(c/1960))-c;if(10<c){a.timeoutHandle=of(Uj.bind(null,a),c);break}Uj(a);break;case 5:Uj(a);break;default:throw Error(y(329));}}Mj(a,O());return a.callbackNode===b?Nj.bind(null,a):null}function Ii(a,b){b&=~uj;b&=~Hi;a.suspendedLanes|=b;a.pingedLanes&=~b;for(a=a.expirationTimes;0<b;){var c=31-Vc(b),d=1<<c;a[c]=-1;b&=~d}}
function Lj(a){if(0!==(X&48))throw Error(y(327));Oj();if(a===U&&0!==(a.expiredLanes&W)){var b=W;var c=Tj(a,b);0!==(tj&Hi)&&(b=Uc(a,b),c=Tj(a,b))}else b=Uc(a,0),c=Tj(a,b);0!==a.tag&&2===c&&(X|=64,a.hydrate&&(a.hydrate=!1,qf(a.containerInfo)),b=Wc(a),0!==b&&(c=Tj(a,b)));if(1===c)throw c=sj,Qj(a,0),Ii(a,b),Mj(a,O()),c;a.finishedWork=a.current.alternate;a.finishedLanes=b;Uj(a);Mj(a,O());return null}
function Vj(){if(null!==Cj){var a=Cj;Cj=null;a.forEach(function(a){a.expiredLanes|=24&a.pendingLanes;Mj(a,O())})}ig()}function Wj(a,b){var c=X;X|=1;try{return a(b)}finally{X=c,0===X&&(wj(),ig())}}function Xj(a,b){var c=X;X&=-2;X|=8;try{return a(b)}finally{X=c,0===X&&(wj(),ig())}}function ni(a,b){I(rj,qj);qj|=b;tj|=b}function Ki(){qj=rj.current;H(rj)}
function Qj(a,b){a.finishedWork=null;a.finishedLanes=0;var c=a.timeoutHandle;-1!==c&&(a.timeoutHandle=-1,pf(c));if(null!==Y)for(c=Y.return;null!==c;){var d=c;switch(d.tag){case 1:d=d.type.childContextTypes;null!==d&&void 0!==d&&Gf();break;case 3:fh();H(N);H(M);uh();break;case 5:hh(d);break;case 4:fh();break;case 13:H(P);break;case 19:H(P);break;case 10:rg(d);break;case 23:case 24:Ki()}c=c.return}U=a;Y=Tg(a.current,null);W=qj=tj=b;V=0;sj=null;uj=Hi=Dg=0}
function Sj(a,b){do{var c=Y;try{qg();vh.current=Gh;if(yh){for(var d=R.memoizedState;null!==d;){var e=d.queue;null!==e&&(e.pending=null);d=d.next}yh=!1}xh=0;T=S=R=null;zh=!1;pj.current=null;if(null===c||null===c.return){V=1;sj=b;Y=null;break}a:{var f=a,g=c.return,h=c,k=b;b=W;h.flags|=2048;h.firstEffect=h.lastEffect=null;if(null!==k&&"object"===typeof k&&"function"===typeof k.then){var l=k;if(0===(h.mode&2)){var n=h.alternate;n?(h.updateQueue=n.updateQueue,h.memoizedState=n.memoizedState,h.lanes=n.lanes):
(h.updateQueue=null,h.memoizedState=null)}var A=0!==(P.current&1),p=g;do{var C;if(C=13===p.tag){var x=p.memoizedState;if(null!==x)C=null!==x.dehydrated?!0:!1;else{var w=p.memoizedProps;C=void 0===w.fallback?!1:!0!==w.unstable_avoidThisFallback?!0:A?!1:!0}}if(C){var z=p.updateQueue;if(null===z){var u=new Set;u.add(l);p.updateQueue=u}else z.add(l);if(0===(p.mode&2)){p.flags|=64;h.flags|=16384;h.flags&=-2981;if(1===h.tag)if(null===h.alternate)h.tag=17;else{var t=zg(-1,1);t.tag=2;Ag(h,t)}h.lanes|=1;break a}k=
void 0;h=b;var q=f.pingCache;null===q?(q=f.pingCache=new Oi,k=new Set,q.set(l,k)):(k=q.get(l),void 0===k&&(k=new Set,q.set(l,k)));if(!k.has(h)){k.add(h);var v=Yj.bind(null,f,l,h);l.then(v,v)}p.flags|=4096;p.lanes=b;break a}p=p.return}while(null!==p);k=Error((Ra(h.type)||"A React component")+" suspended while rendering, but no fallback UI was specified.\n\nAdd a <Suspense fallback=...> component higher in the tree to provide a loading indicator or placeholder to display.")}5!==V&&(V=2);k=Mi(k,h);p=
g;do{switch(p.tag){case 3:f=k;p.flags|=4096;b&=-b;p.lanes|=b;var J=Pi(p,f,b);Bg(p,J);break a;case 1:f=k;var K=p.type,Q=p.stateNode;if(0===(p.flags&64)&&("function"===typeof K.getDerivedStateFromError||null!==Q&&"function"===typeof Q.componentDidCatch&&(null===Ti||!Ti.has(Q)))){p.flags|=4096;b&=-b;p.lanes|=b;var L=Si(p,f,b);Bg(p,L);break a}}p=p.return}while(null!==p)}Zj(c)}catch(va){b=va;Y===c&&null!==c&&(Y=c=c.return);continue}break}while(1)}
function Pj(){var a=oj.current;oj.current=Gh;return null===a?Gh:a}function Tj(a,b){var c=X;X|=16;var d=Pj();U===a&&W===b||Qj(a,b);do try{ak();break}catch(e){Sj(a,e)}while(1);qg();X=c;oj.current=d;if(null!==Y)throw Error(y(261));U=null;W=0;return V}function ak(){for(;null!==Y;)bk(Y)}function Rj(){for(;null!==Y&&!Qf();)bk(Y)}function bk(a){var b=ck(a.alternate,a,qj);a.memoizedProps=a.pendingProps;null===b?Zj(a):Y=b;pj.current=null}
function Zj(a){var b=a;do{var c=b.alternate;a=b.return;if(0===(b.flags&2048)){c=Gi(c,b,qj);if(null!==c){Y=c;return}c=b;if(24!==c.tag&&23!==c.tag||null===c.memoizedState||0!==(qj&1073741824)||0===(c.mode&4)){for(var d=0,e=c.child;null!==e;)d|=e.lanes|e.childLanes,e=e.sibling;c.childLanes=d}null!==a&&0===(a.flags&2048)&&(null===a.firstEffect&&(a.firstEffect=b.firstEffect),null!==b.lastEffect&&(null!==a.lastEffect&&(a.lastEffect.nextEffect=b.firstEffect),a.lastEffect=b.lastEffect),1<b.flags&&(null!==
a.lastEffect?a.lastEffect.nextEffect=b:a.firstEffect=b,a.lastEffect=b))}else{c=Li(b);if(null!==c){c.flags&=2047;Y=c;return}null!==a&&(a.firstEffect=a.lastEffect=null,a.flags|=2048)}b=b.sibling;if(null!==b){Y=b;return}Y=b=a}while(null!==b);0===V&&(V=5)}function Uj(a){var b=eg();gg(99,dk.bind(null,a,b));return null}
function dk(a,b){do Oj();while(null!==yj);if(0!==(X&48))throw Error(y(327));var c=a.finishedWork;if(null===c)return null;a.finishedWork=null;a.finishedLanes=0;if(c===a.current)throw Error(y(177));a.callbackNode=null;var d=c.lanes|c.childLanes,e=d,f=a.pendingLanes&~e;a.pendingLanes=e;a.suspendedLanes=0;a.pingedLanes=0;a.expiredLanes&=e;a.mutableReadLanes&=e;a.entangledLanes&=e;e=a.entanglements;for(var g=a.eventTimes,h=a.expirationTimes;0<f;){var k=31-Vc(f),l=1<<k;e[k]=0;g[k]=-1;h[k]=-1;f&=~l}null!==
Cj&&0===(d&24)&&Cj.has(a)&&Cj.delete(a);a===U&&(Y=U=null,W=0);1<c.flags?null!==c.lastEffect?(c.lastEffect.nextEffect=c,d=c.firstEffect):d=c:d=c.firstEffect;if(null!==d){e=X;X|=32;pj.current=null;kf=fd;g=Ne();if(Oe(g)){if("selectionStart"in g)h={start:g.selectionStart,end:g.selectionEnd};else a:if(h=(h=g.ownerDocument)&&h.defaultView||window,(l=h.getSelection&&h.getSelection())&&0!==l.rangeCount){h=l.anchorNode;f=l.anchorOffset;k=l.focusNode;l=l.focusOffset;try{h.nodeType,k.nodeType}catch(va){h=null;
break a}var n=0,A=-1,p=-1,C=0,x=0,w=g,z=null;b:for(;;){for(var u;;){w!==h||0!==f&&3!==w.nodeType||(A=n+f);w!==k||0!==l&&3!==w.nodeType||(p=n+l);3===w.nodeType&&(n+=w.nodeValue.length);if(null===(u=w.firstChild))break;z=w;w=u}for(;;){if(w===g)break b;z===h&&++C===f&&(A=n);z===k&&++x===l&&(p=n);if(null!==(u=w.nextSibling))break;w=z;z=w.parentNode}w=u}h=-1===A||-1===p?null:{start:A,end:p}}else h=null;h=h||{start:0,end:0}}else h=null;lf={focusedElem:g,selectionRange:h};fd=!1;Ij=null;Jj=!1;Z=d;do try{ek()}catch(va){if(null===
Z)throw Error(y(330));Wi(Z,va);Z=Z.nextEffect}while(null!==Z);Ij=null;Z=d;do try{for(g=a;null!==Z;){var t=Z.flags;t&16&&pb(Z.stateNode,"");if(t&128){var q=Z.alternate;if(null!==q){var v=q.ref;null!==v&&("function"===typeof v?v(null):v.current=null)}}switch(t&1038){case 2:fj(Z);Z.flags&=-3;break;case 6:fj(Z);Z.flags&=-3;ij(Z.alternate,Z);break;case 1024:Z.flags&=-1025;break;case 1028:Z.flags&=-1025;ij(Z.alternate,Z);break;case 4:ij(Z.alternate,Z);break;case 8:h=Z;cj(g,h);var J=h.alternate;dj(h);null!==
J&&dj(J)}Z=Z.nextEffect}}catch(va){if(null===Z)throw Error(y(330));Wi(Z,va);Z=Z.nextEffect}while(null!==Z);v=lf;q=Ne();t=v.focusedElem;g=v.selectionRange;if(q!==t&&t&&t.ownerDocument&&Me(t.ownerDocument.documentElement,t)){null!==g&&Oe(t)&&(q=g.start,v=g.end,void 0===v&&(v=q),"selectionStart"in t?(t.selectionStart=q,t.selectionEnd=Math.min(v,t.value.length)):(v=(q=t.ownerDocument||document)&&q.defaultView||window,v.getSelection&&(v=v.getSelection(),h=t.textContent.length,J=Math.min(g.start,h),g=void 0===
g.end?J:Math.min(g.end,h),!v.extend&&J>g&&(h=g,g=J,J=h),h=Le(t,J),f=Le(t,g),h&&f&&(1!==v.rangeCount||v.anchorNode!==h.node||v.anchorOffset!==h.offset||v.focusNode!==f.node||v.focusOffset!==f.offset)&&(q=q.createRange(),q.setStart(h.node,h.offset),v.removeAllRanges(),J>g?(v.addRange(q),v.extend(f.node,f.offset)):(q.setEnd(f.node,f.offset),v.addRange(q))))));q=[];for(v=t;v=v.parentNode;)1===v.nodeType&&q.push({element:v,left:v.scrollLeft,top:v.scrollTop});"function"===typeof t.focus&&t.focus();for(t=
0;t<q.length;t++)v=q[t],v.element.scrollLeft=v.left,v.element.scrollTop=v.top}fd=!!kf;lf=kf=null;a.current=c;Z=d;do try{for(t=a;null!==Z;){var K=Z.flags;K&36&&Yi(t,Z.alternate,Z);if(K&128){q=void 0;var Q=Z.ref;if(null!==Q){var L=Z.stateNode;switch(Z.tag){case 5:q=L;break;default:q=L}"function"===typeof Q?Q(q):Q.current=q}}Z=Z.nextEffect}}catch(va){if(null===Z)throw Error(y(330));Wi(Z,va);Z=Z.nextEffect}while(null!==Z);Z=null;$f();X=e}else a.current=c;if(xj)xj=!1,yj=a,zj=b;else for(Z=d;null!==Z;)b=
Z.nextEffect,Z.nextEffect=null,Z.flags&8&&(K=Z,K.sibling=null,K.stateNode=null),Z=b;d=a.pendingLanes;0===d&&(Ti=null);1===d?a===Ej?Dj++:(Dj=0,Ej=a):Dj=0;c=c.stateNode;if(Mf&&"function"===typeof Mf.onCommitFiberRoot)try{Mf.onCommitFiberRoot(Lf,c,void 0,64===(c.current.flags&64))}catch(va){}Mj(a,O());if(Qi)throw Qi=!1,a=Ri,Ri=null,a;if(0!==(X&8))return null;ig();return null}
function ek(){for(;null!==Z;){var a=Z.alternate;Jj||null===Ij||(0!==(Z.flags&8)?dc(Z,Ij)&&(Jj=!0):13===Z.tag&&mj(a,Z)&&dc(Z,Ij)&&(Jj=!0));var b=Z.flags;0!==(b&256)&&Xi(a,Z);0===(b&512)||xj||(xj=!0,hg(97,function(){Oj();return null}));Z=Z.nextEffect}}function Oj(){if(90!==zj){var a=97<zj?97:zj;zj=90;return gg(a,fk)}return!1}function $i(a,b){Aj.push(b,a);xj||(xj=!0,hg(97,function(){Oj();return null}))}function Zi(a,b){Bj.push(b,a);xj||(xj=!0,hg(97,function(){Oj();return null}))}
function fk(){if(null===yj)return!1;var a=yj;yj=null;if(0!==(X&48))throw Error(y(331));var b=X;X|=32;var c=Bj;Bj=[];for(var d=0;d<c.length;d+=2){var e=c[d],f=c[d+1],g=e.destroy;e.destroy=void 0;if("function"===typeof g)try{g()}catch(k){if(null===f)throw Error(y(330));Wi(f,k)}}c=Aj;Aj=[];for(d=0;d<c.length;d+=2){e=c[d];f=c[d+1];try{var h=e.create;e.destroy=h()}catch(k){if(null===f)throw Error(y(330));Wi(f,k)}}for(h=a.current.firstEffect;null!==h;)a=h.nextEffect,h.nextEffect=null,h.flags&8&&(h.sibling=
null,h.stateNode=null),h=a;X=b;ig();return!0}function gk(a,b,c){b=Mi(c,b);b=Pi(a,b,1);Ag(a,b);b=Hg();a=Kj(a,1);null!==a&&($c(a,1,b),Mj(a,b))}
function Wi(a,b){if(3===a.tag)gk(a,a,b);else for(var c=a.return;null!==c;){if(3===c.tag){gk(c,a,b);break}else if(1===c.tag){var d=c.stateNode;if("function"===typeof c.type.getDerivedStateFromError||"function"===typeof d.componentDidCatch&&(null===Ti||!Ti.has(d))){a=Mi(b,a);var e=Si(c,a,1);Ag(c,e);e=Hg();c=Kj(c,1);if(null!==c)$c(c,1,e),Mj(c,e);else if("function"===typeof d.componentDidCatch&&(null===Ti||!Ti.has(d)))try{d.componentDidCatch(b,a)}catch(f){}break}}c=c.return}}
function Yj(a,b,c){var d=a.pingCache;null!==d&&d.delete(b);b=Hg();a.pingedLanes|=a.suspendedLanes&c;U===a&&(W&c)===c&&(4===V||3===V&&(W&62914560)===W&&500>O()-jj?Qj(a,0):uj|=c);Mj(a,b)}function lj(a,b){var c=a.stateNode;null!==c&&c.delete(b);b=0;0===b&&(b=a.mode,0===(b&2)?b=1:0===(b&4)?b=99===eg()?1:2:(0===Gj&&(Gj=tj),b=Yc(62914560&~Gj),0===b&&(b=4194304)));c=Hg();a=Kj(a,b);null!==a&&($c(a,b,c),Mj(a,c))}var ck;
ck=function(a,b,c){var d=b.lanes;if(null!==a)if(a.memoizedProps!==b.pendingProps||N.current)ug=!0;else if(0!==(c&d))ug=0!==(a.flags&16384)?!0:!1;else{ug=!1;switch(b.tag){case 3:ri(b);sh();break;case 5:gh(b);break;case 1:Ff(b.type)&&Jf(b);break;case 4:eh(b,b.stateNode.containerInfo);break;case 10:d=b.memoizedProps.value;var e=b.type._context;I(mg,e._currentValue);e._currentValue=d;break;case 13:if(null!==b.memoizedState){if(0!==(c&b.child.childLanes))return ti(a,b,c);I(P,P.current&1);b=hi(a,b,c);return null!==
b?b.sibling:null}I(P,P.current&1);break;case 19:d=0!==(c&b.childLanes);if(0!==(a.flags&64)){if(d)return Ai(a,b,c);b.flags|=64}e=b.memoizedState;null!==e&&(e.rendering=null,e.tail=null,e.lastEffect=null);I(P,P.current);if(d)break;else return null;case 23:case 24:return b.lanes=0,mi(a,b,c)}return hi(a,b,c)}else ug=!1;b.lanes=0;switch(b.tag){case 2:d=b.type;null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2);a=b.pendingProps;e=Ef(b,M.current);tg(b,c);e=Ch(null,b,d,a,e,c);b.flags|=1;if("object"===
typeof e&&null!==e&&"function"===typeof e.render&&void 0===e.$$typeof){b.tag=1;b.memoizedState=null;b.updateQueue=null;if(Ff(d)){var f=!0;Jf(b)}else f=!1;b.memoizedState=null!==e.state&&void 0!==e.state?e.state:null;xg(b);var g=d.getDerivedStateFromProps;"function"===typeof g&&Gg(b,d,g,a);e.updater=Kg;b.stateNode=e;e._reactInternals=b;Og(b,d,a,c);b=qi(null,b,d,!0,f,c)}else b.tag=0,fi(null,b,e,c),b=b.child;return b;case 16:e=b.elementType;a:{null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2);
a=b.pendingProps;f=e._init;e=f(e._payload);b.type=e;f=b.tag=hk(e);a=lg(e,a);switch(f){case 0:b=li(null,b,e,a,c);break a;case 1:b=pi(null,b,e,a,c);break a;case 11:b=gi(null,b,e,a,c);break a;case 14:b=ii(null,b,e,lg(e.type,a),d,c);break a}throw Error(y(306,e,""));}return b;case 0:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),li(a,b,d,e,c);case 1:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),pi(a,b,d,e,c);case 3:ri(b);d=b.updateQueue;if(null===a||null===d)throw Error(y(282));
d=b.pendingProps;e=b.memoizedState;e=null!==e?e.element:null;yg(a,b);Cg(b,d,null,c);d=b.memoizedState.element;if(d===e)sh(),b=hi(a,b,c);else{e=b.stateNode;if(f=e.hydrate)kh=rf(b.stateNode.containerInfo.firstChild),jh=b,f=lh=!0;if(f){a=e.mutableSourceEagerHydrationData;if(null!=a)for(e=0;e<a.length;e+=2)f=a[e],f._workInProgressVersionPrimary=a[e+1],th.push(f);c=Zg(b,null,d,c);for(b.child=c;c;)c.flags=c.flags&-3|1024,c=c.sibling}else fi(a,b,d,c),sh();b=b.child}return b;case 5:return gh(b),null===a&&
ph(b),d=b.type,e=b.pendingProps,f=null!==a?a.memoizedProps:null,g=e.children,nf(d,e)?g=null:null!==f&&nf(d,f)&&(b.flags|=16),oi(a,b),fi(a,b,g,c),b.child;case 6:return null===a&&ph(b),null;case 13:return ti(a,b,c);case 4:return eh(b,b.stateNode.containerInfo),d=b.pendingProps,null===a?b.child=Yg(b,null,d,c):fi(a,b,d,c),b.child;case 11:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),gi(a,b,d,e,c);case 7:return fi(a,b,b.pendingProps,c),b.child;case 8:return fi(a,b,b.pendingProps.children,
c),b.child;case 12:return fi(a,b,b.pendingProps.children,c),b.child;case 10:a:{d=b.type._context;e=b.pendingProps;g=b.memoizedProps;f=e.value;var h=b.type._context;I(mg,h._currentValue);h._currentValue=f;if(null!==g)if(h=g.value,f=He(h,f)?0:("function"===typeof d._calculateChangedBits?d._calculateChangedBits(h,f):1073741823)|0,0===f){if(g.children===e.children&&!N.current){b=hi(a,b,c);break a}}else for(h=b.child,null!==h&&(h.return=b);null!==h;){var k=h.dependencies;if(null!==k){g=h.child;for(var l=
k.firstContext;null!==l;){if(l.context===d&&0!==(l.observedBits&f)){1===h.tag&&(l=zg(-1,c&-c),l.tag=2,Ag(h,l));h.lanes|=c;l=h.alternate;null!==l&&(l.lanes|=c);sg(h.return,c);k.lanes|=c;break}l=l.next}}else g=10===h.tag?h.type===b.type?null:h.child:h.child;if(null!==g)g.return=h;else for(g=h;null!==g;){if(g===b){g=null;break}h=g.sibling;if(null!==h){h.return=g.return;g=h;break}g=g.return}h=g}fi(a,b,e.children,c);b=b.child}return b;case 9:return e=b.type,f=b.pendingProps,d=f.children,tg(b,c),e=vg(e,
f.unstable_observedBits),d=d(e),b.flags|=1,fi(a,b,d,c),b.child;case 14:return e=b.type,f=lg(e,b.pendingProps),f=lg(e.type,f),ii(a,b,e,f,d,c);case 15:return ki(a,b,b.type,b.pendingProps,d,c);case 17:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2),b.tag=1,Ff(d)?(a=!0,Jf(b)):a=!1,tg(b,c),Mg(b,d,e),Og(b,d,e,c),qi(null,b,d,!0,a,c);case 19:return Ai(a,b,c);case 23:return mi(a,b,c);case 24:return mi(a,b,c)}throw Error(y(156,b.tag));
};function ik(a,b,c,d){this.tag=a;this.key=c;this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null;this.index=0;this.ref=null;this.pendingProps=b;this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null;this.mode=d;this.flags=0;this.lastEffect=this.firstEffect=this.nextEffect=null;this.childLanes=this.lanes=0;this.alternate=null}function nh(a,b,c,d){return new ik(a,b,c,d)}function ji(a){a=a.prototype;return!(!a||!a.isReactComponent)}
function hk(a){if("function"===typeof a)return ji(a)?1:0;if(void 0!==a&&null!==a){a=a.$$typeof;if(a===Aa)return 11;if(a===Da)return 14}return 2}
function Tg(a,b){var c=a.alternate;null===c?(c=nh(a.tag,b,a.key,a.mode),c.elementType=a.elementType,c.type=a.type,c.stateNode=a.stateNode,c.alternate=a,a.alternate=c):(c.pendingProps=b,c.type=a.type,c.flags=0,c.nextEffect=null,c.firstEffect=null,c.lastEffect=null);c.childLanes=a.childLanes;c.lanes=a.lanes;c.child=a.child;c.memoizedProps=a.memoizedProps;c.memoizedState=a.memoizedState;c.updateQueue=a.updateQueue;b=a.dependencies;c.dependencies=null===b?null:{lanes:b.lanes,firstContext:b.firstContext};
c.sibling=a.sibling;c.index=a.index;c.ref=a.ref;return c}
function Vg(a,b,c,d,e,f){var g=2;d=a;if("function"===typeof a)ji(a)&&(g=1);else if("string"===typeof a)g=5;else a:switch(a){case ua:return Xg(c.children,e,f,b);case Ha:g=8;e|=16;break;case wa:g=8;e|=1;break;case xa:return a=nh(12,c,b,e|8),a.elementType=xa,a.type=xa,a.lanes=f,a;case Ba:return a=nh(13,c,b,e),a.type=Ba,a.elementType=Ba,a.lanes=f,a;case Ca:return a=nh(19,c,b,e),a.elementType=Ca,a.lanes=f,a;case Ia:return vi(c,e,f,b);case Ja:return a=nh(24,c,b,e),a.elementType=Ja,a.lanes=f,a;default:if("object"===
typeof a&&null!==a)switch(a.$$typeof){case ya:g=10;break a;case za:g=9;break a;case Aa:g=11;break a;case Da:g=14;break a;case Ea:g=16;d=null;break a;case Fa:g=22;break a}throw Error(y(130,null==a?a:typeof a,""));}b=nh(g,c,b,e);b.elementType=a;b.type=d;b.lanes=f;return b}function Xg(a,b,c,d){a=nh(7,a,d,b);a.lanes=c;return a}function vi(a,b,c,d){a=nh(23,a,d,b);a.elementType=Ia;a.lanes=c;return a}function Ug(a,b,c){a=nh(6,a,null,b);a.lanes=c;return a}
function Wg(a,b,c){b=nh(4,null!==a.children?a.children:[],a.key,b);b.lanes=c;b.stateNode={containerInfo:a.containerInfo,pendingChildren:null,implementation:a.implementation};return b}
function jk(a,b,c){this.tag=b;this.containerInfo=a;this.finishedWork=this.pingCache=this.current=this.pendingChildren=null;this.timeoutHandle=-1;this.pendingContext=this.context=null;this.hydrate=c;this.callbackNode=null;this.callbackPriority=0;this.eventTimes=Zc(0);this.expirationTimes=Zc(-1);this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0;this.entanglements=Zc(0);this.mutableSourceEagerHydrationData=null}
function kk(a,b,c){var d=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;return{$$typeof:ta,key:null==d?null:""+d,children:a,containerInfo:b,implementation:c}}
function lk(a,b,c,d){var e=b.current,f=Hg(),g=Ig(e);a:if(c){c=c._reactInternals;b:{if(Zb(c)!==c||1!==c.tag)throw Error(y(170));var h=c;do{switch(h.tag){case 3:h=h.stateNode.context;break b;case 1:if(Ff(h.type)){h=h.stateNode.__reactInternalMemoizedMergedChildContext;break b}}h=h.return}while(null!==h);throw Error(y(171));}if(1===c.tag){var k=c.type;if(Ff(k)){c=If(c,k,h);break a}}c=h}else c=Cf;null===b.context?b.context=c:b.pendingContext=c;b=zg(f,g);b.payload={element:a};d=void 0===d?null:d;null!==
d&&(b.callback=d);Ag(e,b);Jg(e,g,f);return g}function mk(a){a=a.current;if(!a.child)return null;switch(a.child.tag){case 5:return a.child.stateNode;default:return a.child.stateNode}}function nk(a,b){a=a.memoizedState;if(null!==a&&null!==a.dehydrated){var c=a.retryLane;a.retryLane=0!==c&&c<b?c:b}}function ok(a,b){nk(a,b);(a=a.alternate)&&nk(a,b)}function pk(){return null}
function qk(a,b,c){var d=null!=c&&null!=c.hydrationOptions&&c.hydrationOptions.mutableSources||null;c=new jk(a,b,null!=c&&!0===c.hydrate);b=nh(3,null,null,2===b?7:1===b?3:0);c.current=b;b.stateNode=c;xg(b);a[ff]=c.current;cf(8===a.nodeType?a.parentNode:a);if(d)for(a=0;a<d.length;a++){b=d[a];var e=b._getVersion;e=e(b._source);null==c.mutableSourceEagerHydrationData?c.mutableSourceEagerHydrationData=[b,e]:c.mutableSourceEagerHydrationData.push(b,e)}this._internalRoot=c}
qk.prototype.render=function(a){lk(a,this._internalRoot,null,null)};qk.prototype.unmount=function(){var a=this._internalRoot,b=a.containerInfo;lk(null,a,null,function(){b[ff]=null})};function rk(a){return!(!a||1!==a.nodeType&&9!==a.nodeType&&11!==a.nodeType&&(8!==a.nodeType||" react-mount-point-unstable "!==a.nodeValue))}
function sk(a,b){b||(b=a?9===a.nodeType?a.documentElement:a.firstChild:null,b=!(!b||1!==b.nodeType||!b.hasAttribute("data-reactroot")));if(!b)for(var c;c=a.lastChild;)a.removeChild(c);return new qk(a,0,b?{hydrate:!0}:void 0)}
function tk(a,b,c,d,e){var f=c._reactRootContainer;if(f){var g=f._internalRoot;if("function"===typeof e){var h=e;e=function(){var a=mk(g);h.call(a)}}lk(b,g,a,e)}else{f=c._reactRootContainer=sk(c,d);g=f._internalRoot;if("function"===typeof e){var k=e;e=function(){var a=mk(g);k.call(a)}}Xj(function(){lk(b,g,a,e)})}return mk(g)}ec=function(a){if(13===a.tag){var b=Hg();Jg(a,4,b);ok(a,4)}};fc=function(a){if(13===a.tag){var b=Hg();Jg(a,67108864,b);ok(a,67108864)}};
gc=function(a){if(13===a.tag){var b=Hg(),c=Ig(a);Jg(a,c,b);ok(a,c)}};hc=function(a,b){return b()};
yb=function(a,b,c){switch(b){case "input":ab(a,c);b=c.name;if("radio"===c.type&&null!=b){for(c=a;c.parentNode;)c=c.parentNode;c=c.querySelectorAll("input[name="+JSON.stringify(""+b)+'][type="radio"]');for(b=0;b<c.length;b++){var d=c[b];if(d!==a&&d.form===a.form){var e=Db(d);if(!e)throw Error(y(90));Wa(d);ab(d,e)}}}break;case "textarea":ib(a,c);break;case "select":b=c.value,null!=b&&fb(a,!!c.multiple,b,!1)}};Gb=Wj;
Hb=function(a,b,c,d,e){var f=X;X|=4;try{return gg(98,a.bind(null,b,c,d,e))}finally{X=f,0===X&&(wj(),ig())}};Ib=function(){0===(X&49)&&(Vj(),Oj())};Jb=function(a,b){var c=X;X|=2;try{return a(b)}finally{X=c,0===X&&(wj(),ig())}};function uk(a,b){var c=2<arguments.length&&void 0!==arguments[2]?arguments[2]:null;if(!rk(b))throw Error(y(200));return kk(a,b,null,c)}var vk={Events:[Cb,ue,Db,Eb,Fb,Oj,{current:!1}]},wk={findFiberByHostInstance:wc,bundleType:0,version:"17.0.2",rendererPackageName:"react-dom"};
var xk={bundleType:wk.bundleType,version:wk.version,rendererPackageName:wk.rendererPackageName,rendererConfig:wk.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:ra.ReactCurrentDispatcher,findHostInstanceByFiber:function(a){a=cc(a);return null===a?null:a.stateNode},findFiberByHostInstance:wk.findFiberByHostInstance||
pk,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null};if("undefined"!==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__){var yk=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!yk.isDisabled&&yk.supportsFiber)try{Lf=yk.inject(xk),Mf=yk}catch(a){}}__webpack_unused_export__=vk;exports.createPortal=uk;
__webpack_unused_export__=function(a){if(null==a)return null;if(1===a.nodeType)return a;var b=a._reactInternals;if(void 0===b){if("function"===typeof a.render)throw Error(y(188));throw Error(y(268,Object.keys(a)));}a=cc(b);a=null===a?null:a.stateNode;return a};__webpack_unused_export__=function(a,b){var c=X;if(0!==(c&48))return a(b);X|=1;try{if(a)return gg(99,a.bind(null,b))}finally{X=c,ig()}};__webpack_unused_export__=function(a,b,c){if(!rk(b))throw Error(y(200));return tk(null,a,b,!0,c)};
exports.render=function(a,b,c){if(!rk(b))throw Error(y(200));return tk(null,a,b,!1,c)};__webpack_unused_export__=function(a){if(!rk(a))throw Error(y(40));return a._reactRootContainer?(Xj(function(){tk(null,null,a,!1,function(){a._reactRootContainer=null;a[ff]=null})}),!0):!1};__webpack_unused_export__=Wj;__webpack_unused_export__=function(a,b){return uk(a,b,2<arguments.length&&void 0!==arguments[2]?arguments[2]:null)};
__webpack_unused_export__=function(a,b,c,d){if(!rk(c))throw Error(y(200));if(null==a||void 0===a._reactInternals)throw Error(y(38));return tk(a,b,c,!1,d)};__webpack_unused_export__="17.0.2";


/***/ }),

/***/ 961:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



function checkDCE() {
  /* global __REACT_DEVTOOLS_GLOBAL_HOOK__ */
  if (
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === 'undefined' ||
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== 'function'
  ) {
    return;
  }
  if (false) {}
  try {
    // Verify that the code above has been dead code eliminated (DCE'd).
    __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
  } catch (err) {
    // DevTools shouldn't crash React, no matter what.
    // We should still report in case we break this code.
    console.error(err);
  }
}

if (true) {
  // DCE check should happen before ReactDOM bundle executes so that
  // DevTools can report bad minification during injection.
  checkDCE();
  module.exports = __webpack_require__(2551);
} else {}


/***/ }),

/***/ 5287:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

/** @license React v17.0.2
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var l=__webpack_require__(5228),n=60103,p=60106;exports.Fragment=60107;exports.StrictMode=60108;exports.Profiler=60114;var q=60109,r=60110,t=60112;exports.Suspense=60113;var u=60115,v=60116;
if("function"===typeof Symbol&&Symbol.for){var w=Symbol.for;n=w("react.element");p=w("react.portal");exports.Fragment=w("react.fragment");exports.StrictMode=w("react.strict_mode");exports.Profiler=w("react.profiler");q=w("react.provider");r=w("react.context");t=w("react.forward_ref");exports.Suspense=w("react.suspense");u=w("react.memo");v=w("react.lazy")}var x="function"===typeof Symbol&&Symbol.iterator;
function y(a){if(null===a||"object"!==typeof a)return null;a=x&&a[x]||a["@@iterator"];return"function"===typeof a?a:null}function z(a){for(var b="https://reactjs.org/docs/error-decoder.html?invariant="+a,c=1;c<arguments.length;c++)b+="&args[]="+encodeURIComponent(arguments[c]);return"Minified React error #"+a+"; visit "+b+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}
var A={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},B={};function C(a,b,c){this.props=a;this.context=b;this.refs=B;this.updater=c||A}C.prototype.isReactComponent={};C.prototype.setState=function(a,b){if("object"!==typeof a&&"function"!==typeof a&&null!=a)throw Error(z(85));this.updater.enqueueSetState(this,a,b,"setState")};C.prototype.forceUpdate=function(a){this.updater.enqueueForceUpdate(this,a,"forceUpdate")};
function D(){}D.prototype=C.prototype;function E(a,b,c){this.props=a;this.context=b;this.refs=B;this.updater=c||A}var F=E.prototype=new D;F.constructor=E;l(F,C.prototype);F.isPureReactComponent=!0;var G={current:null},H=Object.prototype.hasOwnProperty,I={key:!0,ref:!0,__self:!0,__source:!0};
function J(a,b,c){var e,d={},k=null,h=null;if(null!=b)for(e in void 0!==b.ref&&(h=b.ref),void 0!==b.key&&(k=""+b.key),b)H.call(b,e)&&!I.hasOwnProperty(e)&&(d[e]=b[e]);var g=arguments.length-2;if(1===g)d.children=c;else if(1<g){for(var f=Array(g),m=0;m<g;m++)f[m]=arguments[m+2];d.children=f}if(a&&a.defaultProps)for(e in g=a.defaultProps,g)void 0===d[e]&&(d[e]=g[e]);return{$$typeof:n,type:a,key:k,ref:h,props:d,_owner:G.current}}
function K(a,b){return{$$typeof:n,type:a.type,key:b,ref:a.ref,props:a.props,_owner:a._owner}}function L(a){return"object"===typeof a&&null!==a&&a.$$typeof===n}function escape(a){var b={"=":"=0",":":"=2"};return"$"+a.replace(/[=:]/g,function(a){return b[a]})}var M=/\/+/g;function N(a,b){return"object"===typeof a&&null!==a&&null!=a.key?escape(""+a.key):b.toString(36)}
function O(a,b,c,e,d){var k=typeof a;if("undefined"===k||"boolean"===k)a=null;var h=!1;if(null===a)h=!0;else switch(k){case "string":case "number":h=!0;break;case "object":switch(a.$$typeof){case n:case p:h=!0}}if(h)return h=a,d=d(h),a=""===e?"."+N(h,0):e,Array.isArray(d)?(c="",null!=a&&(c=a.replace(M,"$&/")+"/"),O(d,b,c,"",function(a){return a})):null!=d&&(L(d)&&(d=K(d,c+(!d.key||h&&h.key===d.key?"":(""+d.key).replace(M,"$&/")+"/")+a)),b.push(d)),1;h=0;e=""===e?".":e+":";if(Array.isArray(a))for(var g=
0;g<a.length;g++){k=a[g];var f=e+N(k,g);h+=O(k,b,c,f,d)}else if(f=y(a),"function"===typeof f)for(a=f.call(a),g=0;!(k=a.next()).done;)k=k.value,f=e+N(k,g++),h+=O(k,b,c,f,d);else if("object"===k)throw b=""+a,Error(z(31,"[object Object]"===b?"object with keys {"+Object.keys(a).join(", ")+"}":b));return h}function P(a,b,c){if(null==a)return a;var e=[],d=0;O(a,e,"","",function(a){return b.call(c,a,d++)});return e}
function Q(a){if(-1===a._status){var b=a._result;b=b();a._status=0;a._result=b;b.then(function(b){0===a._status&&(b=b.default,a._status=1,a._result=b)},function(b){0===a._status&&(a._status=2,a._result=b)})}if(1===a._status)return a._result;throw a._result;}var R={current:null};function S(){var a=R.current;if(null===a)throw Error(z(321));return a}var T={ReactCurrentDispatcher:R,ReactCurrentBatchConfig:{transition:0},ReactCurrentOwner:G,IsSomeRendererActing:{current:!1},assign:l};
exports.Children={map:P,forEach:function(a,b,c){P(a,function(){b.apply(this,arguments)},c)},count:function(a){var b=0;P(a,function(){b++});return b},toArray:function(a){return P(a,function(a){return a})||[]},only:function(a){if(!L(a))throw Error(z(143));return a}};exports.Component=C;exports.PureComponent=E;exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=T;
exports.cloneElement=function(a,b,c){if(null===a||void 0===a)throw Error(z(267,a));var e=l({},a.props),d=a.key,k=a.ref,h=a._owner;if(null!=b){void 0!==b.ref&&(k=b.ref,h=G.current);void 0!==b.key&&(d=""+b.key);if(a.type&&a.type.defaultProps)var g=a.type.defaultProps;for(f in b)H.call(b,f)&&!I.hasOwnProperty(f)&&(e[f]=void 0===b[f]&&void 0!==g?g[f]:b[f])}var f=arguments.length-2;if(1===f)e.children=c;else if(1<f){g=Array(f);for(var m=0;m<f;m++)g[m]=arguments[m+2];e.children=g}return{$$typeof:n,type:a.type,
key:d,ref:k,props:e,_owner:h}};exports.createContext=function(a,b){void 0===b&&(b=null);a={$$typeof:r,_calculateChangedBits:b,_currentValue:a,_currentValue2:a,_threadCount:0,Provider:null,Consumer:null};a.Provider={$$typeof:q,_context:a};return a.Consumer=a};exports.createElement=J;exports.createFactory=function(a){var b=J.bind(null,a);b.type=a;return b};exports.createRef=function(){return{current:null}};exports.forwardRef=function(a){return{$$typeof:t,render:a}};exports.isValidElement=L;
exports.lazy=function(a){return{$$typeof:v,_payload:{_status:-1,_result:a},_init:Q}};exports.memo=function(a,b){return{$$typeof:u,type:a,compare:void 0===b?null:b}};exports.useCallback=function(a,b){return S().useCallback(a,b)};exports.useContext=function(a,b){return S().useContext(a,b)};exports.useDebugValue=function(){};exports.useEffect=function(a,b){return S().useEffect(a,b)};exports.useImperativeHandle=function(a,b,c){return S().useImperativeHandle(a,b,c)};
exports.useLayoutEffect=function(a,b){return S().useLayoutEffect(a,b)};exports.useMemo=function(a,b){return S().useMemo(a,b)};exports.useReducer=function(a,b,c){return S().useReducer(a,b,c)};exports.useRef=function(a){return S().useRef(a)};exports.useState=function(a){return S().useState(a)};exports.version="17.0.2";


/***/ }),

/***/ 6540:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



if (true) {
  module.exports = __webpack_require__(5287);
} else {}


/***/ }),

/***/ 7463:
/***/ ((__unused_webpack_module, exports) => {

/** @license React v0.20.2
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f,g,h,k;if("object"===typeof performance&&"function"===typeof performance.now){var l=performance;exports.unstable_now=function(){return l.now()}}else{var p=Date,q=p.now();exports.unstable_now=function(){return p.now()-q}}
if("undefined"===typeof window||"function"!==typeof MessageChannel){var t=null,u=null,w=function(){if(null!==t)try{var a=exports.unstable_now();t(!0,a);t=null}catch(b){throw setTimeout(w,0),b;}};f=function(a){null!==t?setTimeout(f,0,a):(t=a,setTimeout(w,0))};g=function(a,b){u=setTimeout(a,b)};h=function(){clearTimeout(u)};exports.unstable_shouldYield=function(){return!1};k=exports.unstable_forceFrameRate=function(){}}else{var x=window.setTimeout,y=window.clearTimeout;if("undefined"!==typeof console){var z=
window.cancelAnimationFrame;"function"!==typeof window.requestAnimationFrame&&console.error("This browser doesn't support requestAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills");"function"!==typeof z&&console.error("This browser doesn't support cancelAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills")}var A=!1,B=null,C=-1,D=5,E=0;exports.unstable_shouldYield=function(){return exports.unstable_now()>=
E};k=function(){};exports.unstable_forceFrameRate=function(a){0>a||125<a?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):D=0<a?Math.floor(1E3/a):5};var F=new MessageChannel,G=F.port2;F.port1.onmessage=function(){if(null!==B){var a=exports.unstable_now();E=a+D;try{B(!0,a)?G.postMessage(null):(A=!1,B=null)}catch(b){throw G.postMessage(null),b;}}else A=!1};f=function(a){B=a;A||(A=!0,G.postMessage(null))};g=function(a,b){C=
x(function(){a(exports.unstable_now())},b)};h=function(){y(C);C=-1}}function H(a,b){var c=a.length;a.push(b);a:for(;;){var d=c-1>>>1,e=a[d];if(void 0!==e&&0<I(e,b))a[d]=b,a[c]=e,c=d;else break a}}function J(a){a=a[0];return void 0===a?null:a}
function K(a){var b=a[0];if(void 0!==b){var c=a.pop();if(c!==b){a[0]=c;a:for(var d=0,e=a.length;d<e;){var m=2*(d+1)-1,n=a[m],v=m+1,r=a[v];if(void 0!==n&&0>I(n,c))void 0!==r&&0>I(r,n)?(a[d]=r,a[v]=c,d=v):(a[d]=n,a[m]=c,d=m);else if(void 0!==r&&0>I(r,c))a[d]=r,a[v]=c,d=v;else break a}}return b}return null}function I(a,b){var c=a.sortIndex-b.sortIndex;return 0!==c?c:a.id-b.id}var L=[],M=[],N=1,O=null,P=3,Q=!1,R=!1,S=!1;
function T(a){for(var b=J(M);null!==b;){if(null===b.callback)K(M);else if(b.startTime<=a)K(M),b.sortIndex=b.expirationTime,H(L,b);else break;b=J(M)}}function U(a){S=!1;T(a);if(!R)if(null!==J(L))R=!0,f(V);else{var b=J(M);null!==b&&g(U,b.startTime-a)}}
function V(a,b){R=!1;S&&(S=!1,h());Q=!0;var c=P;try{T(b);for(O=J(L);null!==O&&(!(O.expirationTime>b)||a&&!exports.unstable_shouldYield());){var d=O.callback;if("function"===typeof d){O.callback=null;P=O.priorityLevel;var e=d(O.expirationTime<=b);b=exports.unstable_now();"function"===typeof e?O.callback=e:O===J(L)&&K(L);T(b)}else K(L);O=J(L)}if(null!==O)var m=!0;else{var n=J(M);null!==n&&g(U,n.startTime-b);m=!1}return m}finally{O=null,P=c,Q=!1}}var W=k;exports.unstable_IdlePriority=5;
exports.unstable_ImmediatePriority=1;exports.unstable_LowPriority=4;exports.unstable_NormalPriority=3;exports.unstable_Profiling=null;exports.unstable_UserBlockingPriority=2;exports.unstable_cancelCallback=function(a){a.callback=null};exports.unstable_continueExecution=function(){R||Q||(R=!0,f(V))};exports.unstable_getCurrentPriorityLevel=function(){return P};exports.unstable_getFirstCallbackNode=function(){return J(L)};
exports.unstable_next=function(a){switch(P){case 1:case 2:case 3:var b=3;break;default:b=P}var c=P;P=b;try{return a()}finally{P=c}};exports.unstable_pauseExecution=function(){};exports.unstable_requestPaint=W;exports.unstable_runWithPriority=function(a,b){switch(a){case 1:case 2:case 3:case 4:case 5:break;default:a=3}var c=P;P=a;try{return b()}finally{P=c}};
exports.unstable_scheduleCallback=function(a,b,c){var d=exports.unstable_now();"object"===typeof c&&null!==c?(c=c.delay,c="number"===typeof c&&0<c?d+c:d):c=d;switch(a){case 1:var e=-1;break;case 2:e=250;break;case 5:e=1073741823;break;case 4:e=1E4;break;default:e=5E3}e=c+e;a={id:N++,callback:b,priorityLevel:a,startTime:c,expirationTime:e,sortIndex:-1};c>d?(a.sortIndex=c,H(M,a),null===J(L)&&a===J(M)&&(S?h():S=!0,g(U,c-d))):(a.sortIndex=e,H(L,a),R||Q||(R=!0,f(V)));return a};
exports.unstable_wrapCallback=function(a){var b=P;return function(){var c=P;P=b;try{return a.apply(this,arguments)}finally{P=c}}};


/***/ }),

/***/ 9982:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



if (true) {
  module.exports = __webpack_require__(7463);
} else {}


/***/ }),

/***/ 4010:
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"_metadata":{"version":"1.0.0","lastUpdated":"2025-12-04","description":"Personal AI Scheduled Messages Bot Executor Rule Template"},"name":"{{RULE_NAME}} v{{RULE_VERSION}}","state":"ENABLED","description":"Personal AI Bot Executor v{{RULE_VERSION}}","canOtherRuleTrigger":false,"notifyOnError":"FIRSTERROR","authorAccountId":"{{USER_KEY}}","actorAccountId":"{{USER_KEY}}","trigger":{"component":"TRIGGER","schemaVersion":1,"type":"jira.jql.scheduled","value":{"schedule":{"cronExpression":"0 * * * * ?","method":"CRON","rate":0,"rateInterval":60},"jql":"","executionMode":"nosearch","onlyUpdatedIssues":false,"processIssuesInBulk":false},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},"components":[{"component":"CONDITION","schemaVersion":1,"type":"jira.comparator.condition","value":{"first":"{{baseUrl}}","second":"https://jira-","operator":"NOT_CONTAINS"},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},{"component":"ACTION","schemaVersion":2,"type":"jira.issue.outgoing.webhook","value":{"url":"https://heimdall-xmn02.int.rclabenv.com/api/bot/get_release_info/?project=mThor","headers":[{"id":"_header_1762762404581","name":"","value":{"keyOrValue":"","secret":false}}],"sendIssue":false,"contentType":"empty","method":"GET","responseEnabled":true,"usedSecretsKeys":[]},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},{"component":"ACTION","schemaVersion":1,"type":"jira.create.variable","value":{"id":"_customsmartvalue_id_1762762418303","name":{"type":"FREE","value":"mThorReleaseInfo"},"type":"SMART","query":{"type":"SMART","value":"{{webhookResponse.body}}"},"lazy":false},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},{"component":"ACTION","schemaVersion":2,"type":"jira.issue.outgoing.webhook","value":{"url":"https://heimdall-xmn02.int.rclabenv.com/api/bot/get_release_info/?project=Jupiter%20desktop","headers":[{"id":"_header_jupiter_desktop","name":"","value":{"keyOrValue":"","secret":false}}],"sendIssue":false,"contentType":"empty","method":"GET","responseEnabled":true,"usedSecretsKeys":[]},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},{"component":"ACTION","schemaVersion":1,"type":"jira.create.variable","value":{"id":"_customsmartvalue_id_jupiter_desktop","name":{"type":"FREE","value":"jupiterDesktopReleaseInfo"},"type":"SMART","query":{"type":"SMART","value":"{{webhookResponse.body}}"},"lazy":false},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},{"component":"ACTION","schemaVersion":2,"type":"jira.issue.outgoing.webhook","value":{"url":"https://heimdall-xmn02.int.rclabenv.com/api/bot/get_release_info/?project=Jupiter%20web","headers":[{"id":"_header_jupiter_web","name":"","value":{"keyOrValue":"","secret":false}}],"sendIssue":false,"contentType":"empty","method":"GET","responseEnabled":true,"usedSecretsKeys":[]},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},{"component":"ACTION","schemaVersion":1,"type":"jira.create.variable","value":{"id":"_customsmartvalue_id_jupiter_web","name":{"type":"FREE","value":"jupiterWebReleaseInfo"},"type":"SMART","query":{"type":"SMART","value":"{{webhookResponse.body}}"},"lazy":false},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},{"component":"ACTION","schemaVersion":2,"type":"jira.issue.outgoing.webhook","value":{"url":"{{WEB_APP_URL}}?action=getBotMessageCurrentTime&mThor={{mThorReleaseInfo.urlEncode}}&jupiterDesktop={{jupiterDesktopReleaseInfo.urlEncode}}&jupiterWeb={{jupiterWebReleaseInfo.urlEncode}}","headers":[],"sendIssue":false,"contentType":"empty","method":"GET","responseEnabled":true,"usedSecretsKeys":[]},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},{"component":"ACTION","schemaVersion":1,"type":"jira.create.variable","value":{"id":"_customsmartvalue_messageId","name":{"type":"FREE","value":"messageId"},"type":"SMART","query":{"type":"SMART","value":"{{webhookResponse.body.messageId}}"},"lazy":false},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},{"component":"ACTION","schemaVersion":1,"type":"jira.create.variable","value":{"id":"_customsmartvalue_replacedTopic","name":{"type":"FREE","value":"replacedTopic"},"type":"SMART","query":{"type":"SMART","value":"{{webhookResponse.body.topic}}"},"lazy":false},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},{"component":"ACTION","schemaVersion":1,"type":"jira.create.variable","value":{"id":"_customsmartvalue_replacedContent","name":{"type":"FREE","value":"replacedContent"},"type":"SMART","query":{"type":"SMART","value":"{{webhookResponse.body.content}}"},"lazy":false},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},{"component":"CONDITION","schemaVersion":1,"type":"jira.comparator.condition","value":{"first":"{{webhookResponse.body.executed}}","second":"true","operator":"EQUALS"},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},{"component":"CONDITION","schemaVersion":1,"type":"jira.condition.container.block","children":[{"component":"CONDITION_BLOCK","schemaVersion":1,"type":"jira.condition.if.block","value":{"conditionMatchType":"ALL"},"children":[{"component":"ACTION","schemaVersion":2,"type":"jira.issue.outgoing.webhook","value":{"url":"{{BOT_API_BASE_URL}}/user/message","headers":[{"id":"_header_auth","name":"Authorization","value":{"keyOrValue":"Bearer {{BOT_TOKEN}}","secret":false}},{"id":"_header_bot","name":"bot","value":{"keyOrValue":"{{BOT_ID}}","secret":false}}],"sendIssue":false,"contentType":"custom","customBody":"{\\n  \\"email\\": \\"{{initiator.emailAddress}}\\",\\n  \\"message\\": {{webhookResponse.body.content.asJsonString}},\\n  \\"mentionAutoCorrect\\": true,\\n  \\"mention\\": true\\n}","method":"POST","responseEnabled":true,"usedSecretsKeys":[]},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},{"component":"ACTION","schemaVersion":2,"type":"jira.issue.outgoing.webhook","value":{"url":"{{WEB_APP_URL}}?action=markBotMessageExecuted&messageId={{messageId}}&success=true&topic={{replacedTopic.urlEncode}}&content={{replacedContent.urlEncode}}","headers":[],"sendIssue":false,"contentType":"empty","method":"GET","responseEnabled":false,"usedSecretsKeys":[]},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false}],"conditions":[{"component":"CONDITION","schemaVersion":1,"type":"jira.comparator.condition","value":{"first":"{{webhookResponse.body.targetType}}","second":"private","operator":"EQUALS"},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false}],"optimisedIds":[],"newComponent":false},{"component":"CONDITION_BLOCK","schemaVersion":1,"type":"jira.condition.if.block","value":{"conditionMatchType":"ALL"},"children":[{"component":"ACTION","schemaVersion":2,"type":"jira.issue.outgoing.webhook","value":{"url":"{{BOT_API_BASE_URL}}/team/message","headers":[{"id":"_header_auth","name":"Authorization","value":{"keyOrValue":"Bearer {{BOT_TOKEN}}","secret":false}},{"id":"_header_bot","name":"bot","value":{"keyOrValue":"{{BOT_ID}}","secret":false}}],"sendIssue":false,"contentType":"custom","customBody":"{\\n  \\"mentionList\\": [],\\n  \\"isTeamMention\\": false,\\n  \\"teamId\\": \\"{{webhookResponse.body.teamId}}\\",\\n  \\"message\\": {{webhookResponse.body.content.asJsonString}},\\n  \\"skipMentionCheck\\": true\\n}","method":"POST","responseEnabled":true,"usedSecretsKeys":[]},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},{"component":"ACTION","schemaVersion":2,"type":"jira.issue.outgoing.webhook","value":{"url":"{{WEB_APP_URL}}?action=markBotMessageExecuted&messageId={{messageId}}&success=true&topic={{replacedTopic.urlEncode}}&content={{replacedContent.urlEncode}}","headers":[],"sendIssue":false,"contentType":"empty","method":"GET","responseEnabled":false,"usedSecretsKeys":[]},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false}],"conditions":[{"component":"CONDITION","schemaVersion":1,"type":"jira.comparator.condition","value":{"first":"{{webhookResponse.body.targetType}}","second":"group","operator":"EQUALS"},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false}],"optimisedIds":[],"newComponent":false},{"component":"CONDITION_BLOCK","schemaVersion":1,"type":"jira.condition.if.block","value":{"conditionMatchType":"ALL"},"children":[{"component":"ACTION","schemaVersion":3,"type":"jira.issue.outgoing.email","value":{"from":"{{userEmailAddress}}","fromName":"Personal AI","replyTo":"","to":[{"type":"SMART","value":"{{webhookResponse.body.glipEmailAddress}}"}],"cc":[],"bcc":[],"subject":"{{webhookResponse.body.topic}}","body":"{{webhookResponse.body.content}}","mimeType":"text/html","convertLineBreaks":false},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false},{"component":"ACTION","schemaVersion":2,"type":"jira.issue.outgoing.webhook","value":{"url":"{{WEB_APP_URL}}?action=markBotMessageExecuted&messageId={{messageId}}&success=true&topic={{replacedTopic.urlEncode}}&content={{replacedContent.urlEncode}}","headers":[{"id":"_header_1762763239434","name":"","value":{"keyOrValue":"","secret":false}}],"sendIssue":false,"contentType":"empty","method":"GET","responseEnabled":false,"usedSecretsKeys":[]},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false}],"conditions":[{"component":"CONDITION","schemaVersion":1,"type":"jira.comparator.condition","value":{"first":"{{webhookResponse.body.targetType}}","second":"email","operator":"EQUALS"},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false}],"optimisedIds":[],"newComponent":false},{"component":"CONDITION_BLOCK","schemaVersion":1,"type":"jira.condition.if.block","value":{"conditionMatchType":"ALL"},"children":[{"component":"ACTION","schemaVersion":2,"type":"jira.issue.outgoing.webhook","value":{"url":"https://{{webhookResponse.body.aiHost}}/{{webhookResponse.body.aiUri}}","headers":[{"id":"_header_authorization","name":"Authorization","value":{"keyOrValue":"{{webhookResponse.body.aiHeaders.Authorization}}","secret":false}},{"id":"_header_content_type","name":"Content-Type","value":{"keyOrValue":"{{webhookResponse.body.aiHeaders.ContentType}}","secret":false}},{"id":"_header_accept","name":"Accept","value":{"keyOrValue":"{{webhookResponse.body.aiHeaders.Accept}}","secret":false}},{"id":"_header_x_api_key","name":"X-API-Key","value":{"keyOrValue":"{{webhookResponse.body.aiHeaders.XAPIKey}}","secret":false}},{"id":"_header_user_agent","name":"User-Agent","value":{"keyOrValue":"{{webhookResponse.body.aiHeaders.UserAgent}}","secret":false}},{"id":"_header_x_request_id","name":"X-Request-ID","value":{"keyOrValue":"{{webhookResponse.body.aiHeaders.XRequestID}}","secret":false}},{"id":"_header_x_custom","name":"X-Custom-Header","value":{"keyOrValue":"{{webhookResponse.body.aiHeaders.XCustomHeader}}","secret":false}}],"sendIssue":false,"contentType":"empty","method":"GET","responseEnabled":false,"usedSecretsKeys":[]},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false}],"conditions":[{"component":"CONDITION","schemaVersion":1,"type":"jira.comparator.condition","value":{"first":"{{webhookResponse.body.aiMethod}}","second":"GET","operator":"EQUALS"},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false}],"optimisedIds":[],"newComponent":false},{"component":"CONDITION_BLOCK","schemaVersion":1,"type":"jira.condition.if.block","value":{"conditionMatchType":"ALL"},"children":[{"component":"ACTION","schemaVersion":2,"type":"jira.issue.outgoing.webhook","value":{"url":"https://{{webhookResponse.body.aiHost}}/{{webhookResponse.body.aiUri}}","headers":[{"id":"_header_authorization","name":"Authorization","value":{"keyOrValue":"{{webhookResponse.body.aiHeaders.Authorization}}","secret":false}},{"id":"_header_content_type","name":"Content-Type","value":{"keyOrValue":"{{webhookResponse.body.aiHeaders.ContentType}}","secret":false}},{"id":"_header_accept","name":"Accept","value":{"keyOrValue":"{{webhookResponse.body.aiHeaders.Accept}}","secret":false}},{"id":"_header_x_api_key","name":"X-API-Key","value":{"keyOrValue":"{{webhookResponse.body.aiHeaders.XAPIKey}}","secret":false}},{"id":"_header_user_agent","name":"User-Agent","value":{"keyOrValue":"{{webhookResponse.body.aiHeaders.UserAgent}}","secret":false}},{"id":"_header_x_request_id","name":"X-Request-ID","value":{"keyOrValue":"{{webhookResponse.body.aiHeaders.XRequestID}}","secret":false}},{"id":"_header_x_custom","name":"X-Custom-Header","value":{"keyOrValue":"{{webhookResponse.body.aiHeaders.XCustomHeader}}","secret":false}}],"sendIssue":false,"contentType":"custom","customBody":"{{webhookResponse.body.aiBody}}","method":"POST","responseEnabled":false,"usedSecretsKeys":[]},"children":[],"conditions":[],"optimisedIds":[],"newComponent":false}],"conditions":[],"optimisedIds":[],"newComponent":false}],"conditions":[],"optimisedIds":[],"newComponent":false}],"projects":[{"projectId":"{{PROJECT_ID}}","projectTypeKey":"software"}],"labels":[],"tags":[]}');

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/create fake namespace object */
/******/ 	(() => {
/******/ 		var getProto = Object.getPrototypeOf ? (obj) => (Object.getPrototypeOf(obj)) : (obj) => (obj.__proto__);
/******/ 		var leafPrototypes;
/******/ 		// create a fake namespace object
/******/ 		// mode & 1: value is a module id, require it
/******/ 		// mode & 2: merge all properties of value into the ns
/******/ 		// mode & 4: return value when already ns object
/******/ 		// mode & 16: return value when it's Promise-like
/******/ 		// mode & 8|1: behave like require
/******/ 		__webpack_require__.t = function(value, mode) {
/******/ 			if(mode & 1) value = this(value);
/******/ 			if(mode & 8) return value;
/******/ 			if(typeof value === 'object' && value) {
/******/ 				if((mode & 4) && value.__esModule) return value;
/******/ 				if((mode & 16) && typeof value.then === 'function') return value;
/******/ 			}
/******/ 			var ns = Object.create(null);
/******/ 			__webpack_require__.r(ns);
/******/ 			var def = {};
/******/ 			leafPrototypes = leafPrototypes || [null, getProto({}), getProto([]), getProto(getProto)];
/******/ 			for(var current = mode & 2 && value; typeof current == 'object' && !~leafPrototypes.indexOf(current); current = getProto(current)) {
/******/ 				Object.getOwnPropertyNames(current).forEach((key) => (def[key] = () => (value[key])));
/******/ 			}
/******/ 			def['default'] = () => (value);
/******/ 			__webpack_require__.d(ns, def);
/******/ 			return ns;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};

// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(6540);
var react_namespaceObject = /*#__PURE__*/__webpack_require__.t(react, 2);
// EXTERNAL MODULE: ./node_modules/react-dom/index.js
var react_dom = __webpack_require__(961);
;// CONCATENATED MODULE: ./src/scheduled-messages/SheetInitializer.ts
/**
 * Sheet 初始化器
 * 负责一键生成 Google Sheet、AppScript 项目和触发器
 */

/**
 * Messages 表的 Schema 定义
 * 当新增字段时，在 columns 中添加列名，并增加 version
 * 
 * 版本历史：
 * - v2.0: 初始版本
 * - v2.1: 添加 Category 列
 * - v2.2: 添加 Automation_Link 列（支持 Jira Automation Rule 引用）
 */
const MESSAGES_SCHEMA = {
  version: '2.2',
  columns: ['ID', 'Topic', 'Content', 'Schedule_Date', 'Schedule_Time', 'End_Date', 'Repeat_Every', 'Repeat_Unit', 'Repeat_Count', 'Timeline_Project', 'Timeline_Milestone', 'Timeline_Offset', 'Push_Method', 'Glip_User_Name', 'Glip_Team_ID', 'Attachment', 'AI_Endpoint', 'AI_Headers', 'AI_Body', 'Category', 'Automation_Link', 'Status', 'Last_Exec', 'Next_Exec', 'Exec_Count', 'Exec_Log']
};
class SheetInitializer {
  constructor(token) {
    this.messagesSheetId = 0;
    this.configSheetId = 0;
    this.logsSheetId = 0;
    this.deploymentId = '';
    this.token = token;
  }

  /**
   * 一键创建定时消息系统
   */
  async createScheduledMessagesSheet() {
    try {
      console.log('开始创建定时消息系统...');

      // 1. 创建 Spreadsheet
      console.log('步骤 1/8: 创建 Spreadsheet...');
      const sheet = await this.createSpreadsheet();

      // 2. 设置共享权限（组织内所有人可编辑）
      console.log('步骤 2/8: 设置共享权限...');
      await this.setPermissions(sheet.spreadsheetId);

      // 3. 设置工作表结构
      console.log('步骤 3/8: 设置工作表结构...');
      await this.setupWorksheets(sheet.spreadsheetId);

      // 4. 创建 AppScript 项目
      console.log('步骤 4/8: 创建 AppScript 项目...');
      const scriptId = await this.createAppScriptProject(sheet.spreadsheetId);

      // 5. 部署为 Web App（必须先部署才能调用 Web App）
      console.log('步骤 5/8: 部署 Web App...');
      const webAppUrl = await this.deployWebApp(scriptId);
      console.log('部署完成，需要用户授权...');

      // 返回需要授权的状态
      // 用户需要在浏览器中打开 Web App URL 并授权
      // 添加 action=authSuccess 参数，授权完成后显示成功页面
      return {
        success: true,
        sheetId: sheet.spreadsheetId,
        sheetUrl: sheet.spreadsheetUrl,
        scriptId,
        webAppUrl,
        needsAuthorization: true,
        authUrl: `${webAppUrl}?action=authSuccess` // 用户需要访问这个 URL 来授权
      };
    } catch (error) {
      console.error('创建定时消息系统失败:', error);

      // 检查是否是 AppScript API 未开启的错误
      if (error.message === 'APPSCRIPT_API_NOT_ENABLED') {
        return {
          success: false,
          sheetId: '',
          sheetUrl: '',
          scriptId: '',
          webAppUrl: '',
          needsAppScriptAPI: true,
          appScriptAPIUrl: 'https://script.google.com/home/usersettings',
          error: 'AppScript API 未开启'
        };
      }
      return {
        success: false,
        sheetId: '',
        sheetUrl: '',
        scriptId: '',
        webAppUrl: '',
        error: error.message || '未知错误'
      };
    }
  }

  /**
   * 创建 Spreadsheet
   */
  async createSpreadsheet() {
    const userInfo = await this.getUserInfo();
    const response = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        properties: {
          title: `${userInfo.given_name} 的定时消息管理`
        },
        sheets: [{
          properties: {
            title: 'Messages',
            gridProperties: {
              frozenRowCount: 1
            }
          }
        }, {
          properties: {
            title: 'Config',
            gridProperties: {
              frozenRowCount: 1
            }
          }
        }, {
          properties: {
            title: 'Logs',
            gridProperties: {
              frozenRowCount: 1
            }
          }
        }]
      })
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`创建 Spreadsheet 失败: ${error}`);
    }
    const data = await response.json();

    // 保存工作表 ID
    if (data.sheets && data.sheets.length >= 3) {
      this.messagesSheetId = data.sheets[0].properties.sheetId;
      this.configSheetId = data.sheets[1].properties.sheetId;
      this.logsSheetId = data.sheets[2].properties.sheetId;
      console.log(`Messages Sheet ID: ${this.messagesSheetId}, Config Sheet ID: ${this.configSheetId}, Logs Sheet ID: ${this.logsSheetId}`);
    }
    return {
      spreadsheetId: data.spreadsheetId,
      spreadsheetUrl: data.spreadsheetUrl
    };
  }

  /**
   * 设置共享权限：组织内所有人可编辑
   */
  async setPermissions(spreadsheetId) {
    try {
      // 获取用户的域名信息
      const userInfo = await this.getUserInfo();
      const domain = userInfo.email.split('@')[1]; // 例如: ringcentral.com

      // 设置权限：组织内所有人可编辑
      const response = await fetch(`https://www.googleapis.com/drive/v3/files/${spreadsheetId}/permissions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          type: 'domain',
          role: 'writer',
          domain: domain,
          allowFileDiscovery: true
        })
      });
      if (!response.ok) {
        const error = await response.text();
        console.warn('设置域权限失败，尝试设置为任何人可编辑:', error);

        // 如果域权限设置失败，尝试设置为"知道链接的任何人可编辑"
        const fallbackResponse = await fetch(`https://www.googleapis.com/drive/v3/files/${spreadsheetId}/permissions`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            type: 'anyone',
            role: 'writer'
          })
        });
        if (!fallbackResponse.ok) {
          const fallbackError = await fallbackResponse.text();
          console.warn('设置共享权限失败:', fallbackError);
          // 不抛出错误，允许继续执行
        } else {
          console.log('✅ 已设置为：知道链接的任何人可编辑');
        }
      } else {
        console.log(`✅ 已设置为：${domain} 域内所有人可编辑`);
      }
    } catch (error) {
      console.warn('设置权限失败:', error);
      // 不抛出错误，允许继续执行
    }
  }

  /**
   * 获取用户信息
   */
  async getUserInfo() {
    const response = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: {
        'Authorization': `Bearer ${this.token}`
      }
    });
    if (!response.ok) {
      throw new Error('无法获取用户信息');
    }
    return await response.json();
  }

  /**
   * 设置工作表结构（表头和格式）
   * 
   * 重要说明：
   * - header 的列名必须与 ScheduledMessage 接口的字段名完全一致
   * - 用户可以在 Google Sheet 中自由调整列的顺序，系统会自动适配
   * - ScheduledMessageService 使用动态列映射机制：
   *   1. 读取时：通过 header 解析每列数据到对应字段
   *   2. 写入时：根据 header 顺序动态生成行数据
   * - 不要修改 header 的列名，但可以随意调整顺序、隐藏列、插入新列
   */
  async setupWorksheets(spreadsheetId) {
    // Messages 表头（使用 MESSAGES_SCHEMA 中的定义）
    // 注意：用户可以在 Sheet 中随意调整列顺序
    const messagesHeaders = MESSAGES_SCHEMA.columns;

    // Config 表头
    const configHeaders = ['Key', 'Value'];

    // Logs 表头
    const logsHeaders = ['Timestamp', 'Message_ID', 'Topic', 'Content', 'Push_Method', 'Target', 'Status', 'Error', 'Exec_Count'];
    const requests = [
    // 设置 Messages 表头
    {
      updateCells: {
        range: {
          sheetId: this.messagesSheetId,
          startRowIndex: 0,
          endRowIndex: 1,
          startColumnIndex: 0,
          endColumnIndex: messagesHeaders.length
        },
        rows: [{
          values: messagesHeaders.map(header => ({
            userEnteredValue: {
              stringValue: header
            },
            userEnteredFormat: {
              backgroundColor: {
                red: 0.2,
                green: 0.5,
                blue: 0.8
              },
              textFormat: {
                bold: true,
                foregroundColor: {
                  red: 1,
                  green: 1,
                  blue: 1
                }
              }
            }
          }))
        }],
        fields: 'userEnteredValue,userEnteredFormat'
      }
    },
    // 设置 Logs 表头
    {
      updateCells: {
        range: {
          sheetId: this.logsSheetId,
          startRowIndex: 0,
          endRowIndex: 1,
          startColumnIndex: 0,
          endColumnIndex: logsHeaders.length
        },
        rows: [{
          values: logsHeaders.map(header => ({
            userEnteredValue: {
              stringValue: header
            }
          }))
        }],
        fields: 'userEnteredValue,userEnteredFormat'
      }
    },
    // 设置 Config 表头
    {
      updateCells: {
        range: {
          sheetId: this.configSheetId,
          startRowIndex: 0,
          endRowIndex: 1,
          startColumnIndex: 0,
          endColumnIndex: 2
        },
        rows: [{
          values: configHeaders.map(header => ({
            userEnteredValue: {
              stringValue: header
            },
            userEnteredFormat: {
              backgroundColor: {
                red: 0.2,
                green: 0.5,
                blue: 0.8
              },
              textFormat: {
                bold: true,
                foregroundColor: {
                  red: 1,
                  green: 1,
                  blue: 1
                }
              }
            }
          }))
        }],
        fields: 'userEnteredValue,userEnteredFormat'
      }
    },
    // 自动调整列宽
    {
      autoResizeDimensions: {
        dimensions: {
          sheetId: this.messagesSheetId,
          dimension: 'COLUMNS',
          startIndex: 0,
          endIndex: messagesHeaders.length
        }
      }
    },
    // 自动调整 Logs 列宽
    {
      autoResizeDimensions: {
        dimensions: {
          sheetId: this.logsSheetId,
          dimension: 'COLUMNS',
          startIndex: 0,
          endIndex: logsHeaders.length
        }
      }
    }];
    const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        requests
      })
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`设置工作表结构失败: ${error}`);
    }
  }

  /**
   * 添加示例数据
   */
  async addSampleData(spreadsheetId) {
    const now = new Date();
    const oneMinuteLater = new Date(now.getTime() + 60 * 1000);
    const sampleMessage = [`msg_welcome_${Date.now()}`,
    // ID
    'Personal AI 欢迎消息',
    // Topic
    '🎉 恭喜！您的定时消息系统已成功初始化！\n\n这是一条测试消息，证明系统运行正常。\n\n您现在可以在管理界面添加更多定时消息。',
    // Content
    this.formatDate(now),
    // Schedule_Date
    this.formatTime(oneMinuteLater),
    // Schedule_Time（填写时间，自动判断为 Hourly 类型）
    '',
    // End_Date
    '',
    // Repeat_Every
    '',
    // Repeat_Unit
    '',
    // Repeat_Count
    '',
    // Timeline_Project
    '',
    // Timeline_Milestone
    '',
    // Timeline_Offset
    'AsMe',
    // Push_Method
    'sync.service',
    // Glip_User_Name
    '',
    // Glip_Team_ID
    '',
    // Attachment
    '',
    // AI_Endpoint
    '',
    // AI_Headers
    '',
    // AI_Body
    '',
    // Category
    '',
    // Automation_Link (v2.2 新增)
    'Active',
    // Status
    '',
    // Last_Exec
    this.formatDateTime(oneMinuteLater),
    // Next_Exec
    0,
    // Exec_Count
    '待执行' // Exec_Log
    ];
    const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Messages!A2:Z2?valueInputOption=USER_ENTERED`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        values: [sampleMessage]
      })
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`添加示例数据失败: ${error}`);
    }
  }

  /**
   * 创建 AppScript 项目
   */
  async createAppScriptProject(spreadsheetId) {
    // 读取 AppScript 模板代码
    const scriptCode = await this.loadAppScriptTemplate();

    // 创建 Apps Script 项目
    const createResponse = await fetch('https://script.googleapis.com/v1/projects', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        title: 'Personal AI - Scheduled Messages',
        parentId: spreadsheetId
      })
    });
    if (!createResponse.ok) {
      const error = await createResponse.text();

      // 检查是否是因为 AppScript API 未开启（403 错误）
      if (createResponse.status === 403 && error.includes('script.google.com/home/usersettings')) {
        throw new Error('APPSCRIPT_API_NOT_ENABLED');
      }
      throw new Error(`创建 AppScript 项目失败: ${error}`);
    }
    const project = await createResponse.json();
    const scriptId = project.scriptId;

    // 上传代码
    const updateResponse = await fetch(`https://script.googleapis.com/v1/projects/${scriptId}/content`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        files: [{
          name: 'Code',
          type: 'SERVER_JS',
          source: scriptCode
        }, {
          name: 'appsscript',
          type: 'JSON',
          source: JSON.stringify({
            timeZone: 'Asia/Shanghai',
            exceptionLogging: 'STACKDRIVER',
            runtimeVersion: 'V8',
            webapp: {
              access: 'ANYONE_ANONYMOUS',
              executeAs: 'USER_DEPLOYING'
            },
            executionApi: {
              access: 'ANYONE'
            }
          })
        }]
      })
    });
    if (!updateResponse.ok) {
      const error = await updateResponse.text();
      throw new Error(`上传 AppScript 代码失败: ${error}`);
    }
    return scriptId;
  }

  /**
   * 加载 AppScript 模板代码
   */
  async loadAppScriptTemplate() {
    // 从 src/scheduled-messages/app-script-template.gs 读取
    // 注意：在 Chrome Extension 中，我们需要将这个文件打包进来
    // 这里我们直接返回代码字符串
    const _templateCode = `
// 注意：这里会被实际的模板代码替换
// 在实际构建时，我们会通过 webpack 或其他方式将 .gs 文件内容注入
function minuteTrigger() {
  executeScheduledMessages(['Hourly']);
}

function dailyTrigger() {
  executeScheduledMessages(['Daily', 'Periodic']);
}

// ... 其他函数
`;

    // TODO: 在实际实现中，需要通过 webpack 将 .gs 文件内容作为字符串导入
    // 或者直接在这里内联完整代码

    // 暂时返回一个简化版本（实际应该读取完整模板）
    return await this.getFullAppScriptCode();
  }

  /**
   * 获取完整的 AppScript 代码
   * 从扩展资源中读取模板文件
   */
  async getFullAppScriptCode() {
    try {
      const response = await fetch(chrome.runtime.getURL('app-script-template.gs'));
      if (!response.ok) {
        throw new Error(`无法加载模板文件: HTTP ${response.status}`);
      }
      return await response.text();
    } catch (error) {
      console.error('加载 AppScript 模板文件失败:', error);
      throw new Error(`加载 AppScript 模板文件失败: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * 完成初始化（在用户授权后调用）
   * 创建触发器、添加示例数据并保存配置
   */
  async completeInitialization(sheetId, scriptId, webAppUrl) {
    try {
      // 6. 创建触发器（通过 Web App 调用）
      console.log('步骤 6/8: 创建触发器...');
      const triggers = await this.createTriggers(webAppUrl);

      // 7. 添加示例数据（触发器创建后才能推送）
      console.log('步骤 7/8: 添加示例数据...');
      await this.addSampleData(sheetId);

      // 8. 保存配置
      console.log('步骤 8/8: 保存配置...');
      await this.saveConfig(sheetId, scriptId, webAppUrl, triggers);
      console.log('定时消息系统创建成功！');
      return {
        success: true,
        sheetId,
        sheetUrl: `https://docs.google.com/spreadsheets/d/${sheetId}/edit`,
        scriptId,
        webAppUrl
      };
    } catch (error) {
      console.error('完成初始化失败:', error);
      return {
        success: false,
        sheetId,
        sheetUrl: `https://docs.google.com/spreadsheets/d/${sheetId}/edit`,
        scriptId,
        webAppUrl,
        error: error.message || '未知错误'
      };
    }
  }

  /**
   * 创建触发器
   * 注意：Google Apps Script REST API 不支持直接创建触发器
   * 我们通过调用 Web App 的 setupTriggers 端点来创建触发器
   * 因为 ScriptApp.newTrigger 只能在 Apps Script 环境内部执行
   */
  async createTriggers(webAppUrl) {
    // 通过 Web App 调用 setupTriggers
    const response = await fetch(`${webAppUrl}?action=setupTriggers`, {
      method: 'GET',
      // Web App 部署为 "Anyone" 访问时不需要 Authorization header
      // 但我们仍然可以带上 token 以防万一
      headers: {
        'Authorization': `Bearer ${this.token}`
      }
    });

    // 检查 Content-Type：如果是 HTML，说明需要授权
    const contentType = response.headers.get('content-type');
    if (contentType?.includes('text/html')) {
      console.warn('Web App 返回 HTML，需要用户授权');
      throw new Error('AUTHORIZATION_REQUIRED');
    }
    if (!response.ok) {
      const error = await response.text();
      console.error('创建触发器失败，响应详情:', error);
      throw new Error(`创建触发器失败: HTTP ${response.status} - ${error}`);
    }

    // 尝试解析 JSON
    let result;
    try {
      result = await response.json();
    } catch (jsonError) {
      console.error('无法解析响应为 JSON:', jsonError);
      throw new Error('AUTHORIZATION_REQUIRED');
    }
    if (!result.success) {
      throw new Error(`创建触发器失败: ${result.error || '未知错误'}`);
    }
    console.log('触发器创建成功:', result.message);

    // 返回占位符 ID，因为我们无法从 Web App 获取实际的触发器 ID
    // 但触发器已经在 Apps Script 中成功创建
    return {
      minuteTriggerId: 'created-via-webapp',
      dailyTriggerId: 'created-via-webapp'
    };
  }

  /**
   * 部署为 Web App
   */
  async deployWebApp(scriptId) {
    // 第一步：创建版本
    console.log('创建 AppScript 版本...');
    const versionResponse = await fetch(`https://script.googleapis.com/v1/projects/${scriptId}/versions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        description: 'Initial version for Personal AI Scheduled Messages'
      })
    });
    if (!versionResponse.ok) {
      const error = await versionResponse.text();
      throw new Error(`创建版本失败: ${error}`);
    }
    const version = await versionResponse.json();
    const versionNumber = version.versionNumber;
    console.log(`版本创建成功: ${versionNumber}`);

    // 第二步：基于版本创建部署
    console.log(`基于版本 ${versionNumber} 创建部署...`);
    const deploymentResponse = await fetch(`https://script.googleapis.com/v1/projects/${scriptId}/deployments`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        versionNumber: versionNumber,
        manifestFileName: 'appsscript',
        description: 'Personal AI Scheduled Messages Web App'
      })
    });
    if (!deploymentResponse.ok) {
      const error = await deploymentResponse.text();
      throw new Error(`部署 Web App 失败: ${error}`);
    }
    const deployment = await deploymentResponse.json();
    console.log('部署创建成功:', deployment);

    // 获取 Web App URL 和 Deployment ID
    const webAppUrl = deployment.entryPoints?.[0]?.webApp?.url || '';
    if (!webAppUrl) {
      throw new Error('无法获取 Web App URL，请检查部署配置');
    }

    // 保存 deploymentId（用于后续更新）
    this.deploymentId = deployment.deploymentId;
    console.log(`Deployment ID: ${this.deploymentId}`);
    return webAppUrl;
  }

  /**
   * 保存配置到 Config 工作表和 Chrome Storage
   */
  async saveConfig(spreadsheetId, scriptId, webAppUrl, triggers) {
    const now = new Date();

    // 构建配置对象
    const config = {
      sheetId: spreadsheetId,
      sheetUrl: `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`,
      messagesSheetId: this.messagesSheetId,
      // 保存 Messages Sheet ID
      logsSheetId: this.logsSheetId,
      // 保存 Logs Sheet ID
      scriptId,
      webAppUrl,
      deploymentId: this.deploymentId,
      // 保存 Deployment ID（用于更新部署）
      minute_trigger_id: triggers.minuteTriggerId,
      daily_trigger_id: triggers.dailyTriggerId,
      sheet_version: MESSAGES_SCHEMA.version,
      appScriptVersion: '1.0.0',
      // 初始 App Script 版本
      appScriptLastUpdated: this.formatDateTime(now),
      created_by: 'Personal AI Extension',
      created_at: this.formatDateTime(now),
      last_sync_time: this.formatDateTime(now)
    };

    // 使用 ConfigSyncService 同步配置到 Sheet 和 Chrome Storage
    const {
      ConfigSyncService
    } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 8998));
    const syncService = new ConfigSyncService(this.token);
    await syncService.syncConfig(config);
  }

  // 辅助方法

  formatDate(date) {
    return date.toISOString().split('T')[0];
  }
  formatTime(date) {
    return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
  }
  formatDateTime(date) {
    return `${this.formatDate(date)} ${this.formatTime(date)}`;
  }
}
;// CONCATENATED MODULE: ./src/scheduled-messages/components/OneClickSetup.tsx
/**
 * 一键初始化组件
 * 引导用户创建定时消息系统
 */




const OneClickSetup = _ref => {
  let {
    onComplete
  } = _ref;
  const [isInitializing, setIsInitializing] = (0,react.useState)(false);
  const [currentStep, setCurrentStep] = (0,react.useState)('');
  const [manualSheetUrl, setManualSheetUrl] = (0,react.useState)('');
  const [error, setError] = (0,react.useState)('');
  const [authToken, setAuthToken] = (0,react.useState)('');
  const [needsAuth, setNeedsAuth] = (0,react.useState)(false);
  const [authUrl, setAuthUrl] = (0,react.useState)('');
  const [tempResult, setTempResult] = (0,react.useState)(null);
  const [needsAppScriptAPI, setNeedsAppScriptAPI] = (0,react.useState)(false);
  const [appScriptAPIUrl, setAppScriptAPIUrl] = (0,react.useState)('');
  const handleOneClickSetup = async () => {
    setIsInitializing(true);
    setError('');
    try {
      // 获取 Google OAuth token
      setCurrentStep('正在获取授权...');
      const token = await getAuthToken();
      if (!token) {
        throw new Error('无法获取 Google 授权，请检查账号登录状态');
      }
      setAuthToken(token);

      // 创建 Sheet 和 AppScript
      setCurrentStep('正在创建系统（共8步，当前完成1-5步）...');
      const initializer = new SheetInitializer(token);
      const result = await initializer.createScheduledMessagesSheet();
      if (result.success && result.needsAuthorization) {
        // 需要用户授权
        setTempResult(result);
        setNeedsAuth(true);
        setAuthUrl(result.authUrl || '');
        setCurrentStep('');
        setIsInitializing(false);
      } else if (result.success) {
        setCurrentStep('初始化成功！');
        onComplete(result);
      } else if (result.needsAppScriptAPI) {
        // 需要开启 AppScript API
        setNeedsAppScriptAPI(true);
        setAppScriptAPIUrl(result.appScriptAPIUrl || 'https://script.google.com/home/usersettings');
        setCurrentStep('');
        setIsInitializing(false);
      } else {
        throw new Error(result.error || '初始化失败');
      }
    } catch (err) {
      console.error('初始化失败:', err);
      setError(err.message || '初始化失败，请重试');
      setIsInitializing(false);
    }
  };
  const handleCompleteAuth = async () => {
    if (!tempResult || !authToken) {
      setError('缺少必要信息，请重新初始化');
      return;
    }
    setIsInitializing(true);
    setError('');
    try {
      setCurrentStep('正在完成初始化（第6-8步：创建触发器、添加示例数据、保存配置）...');
      const initializer = new SheetInitializer(authToken);
      const result = await initializer.completeInitialization(tempResult.sheetId, tempResult.scriptId, tempResult.webAppUrl);
      if (result.success) {
        setCurrentStep('初始化成功！');
        onComplete(result);
      } else {
        throw new Error(result.error || '完成初始化失败');
      }
    } catch (err) {
      console.error('完成初始化失败:', err);

      // 检查是否是授权错误
      if (err.message === 'AUTHORIZATION_REQUIRED' || err.message?.includes('AUTHORIZATION_REQUIRED')) {
        setError('⚠️ 检测到您尚未完成授权！请先点击上方"打开授权页面"按钮，在弹出的页面中完成授权操作，然后再点击此按钮继续。');
        setNeedsAuth(true); // 保持在授权界面
      } else {
        setError(err.message || '完成初始化失败，请重试');
        setNeedsAuth(true); // 保持在授权界面，允许重试
      }
      setIsInitializing(false);
    }
  };
  const handleManualBind = async () => {
    if (!manualSheetUrl.trim()) {
      setError('请输入 Sheet URL');
      return;
    }
    setIsInitializing(true);
    setError('');
    setCurrentStep('正在从 Sheet 读取配置...');
    try {
      // 从 URL 提取 Sheet ID
      const sheetId = extractSheetId(manualSheetUrl);
      if (!sheetId) {
        throw new Error('无效的 Sheet URL');
      }

      // 获取授权
      const token = await getAuthToken();
      if (!token) {
        throw new Error('无法获取 Google 授权');
      }

      // 使用 ConfigSyncService 从 Sheet 读取完整配置
      const {
        ConfigSyncService
      } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 8998));
      const syncService = new ConfigSyncService(token);
      const sheetConfig = await syncService.readConfigFromSheet(sheetId);

      // 如果 Sheet 中没有配置，创建最小配置
      if (!sheetConfig.sheet_version) {
        console.warn('Sheet Config 表为空，创建最小配置');
        await chrome.storage.local.set({
          scheduledMessagesConfig: {
            sheetId,
            sheetUrl: manualSheetUrl,
            sheet_version: '2.0',
            created_by: 'Manual',
            created_at: new Date().toISOString()
          }
        });
      } else {
        // 保存从 Sheet 读取的完整配置到 Chrome Storage
        await syncService.saveConfigToStorage(sheetConfig);
        console.log('✅ 从 Sheet 读取并绑定配置:', sheetConfig);
      }

      // 刷新页面
      setCurrentStep('配置绑定成功，正在刷新...');
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } catch (err) {
      console.error('绑定 Sheet 失败:', err);
      setError(err.message || '绑定失败，请检查 Sheet 是否存在 Config 工作表');
      setIsInitializing(false);
    }
  };
  const getAuthToken = () => {
    return new Promise((resolve, reject) => {
      // 先清除旧 token，强制重新获取以应用新的权限范围
      chrome.identity.getAuthToken({
        interactive: false
      }, oldToken => {
        if (oldToken) {
          chrome.identity.removeCachedAuthToken({
            token: oldToken
          }, () => {
            // 重新获取 token
            chrome.identity.getAuthToken({
              interactive: true
            }, token => {
              if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
              } else {
                resolve(token || '');
              }
            });
          });
        } else {
          // 没有旧 token，直接获取新的
          chrome.identity.getAuthToken({
            interactive: true
          }, token => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve(token || '');
            }
          });
        }
      });
    });
  };
  const extractSheetId = url => {
    const match = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    return match ? match[1] : null;
  };
  return /*#__PURE__*/react.createElement("div", {
    style: styles.container
  }, /*#__PURE__*/react.createElement("div", {
    style: styles.header
  }, /*#__PURE__*/react.createElement("h1", {
    style: styles.title
  }, "\uD83D\uDE80 \u5F00\u59CB\u4F7F\u7528\u5B9A\u65F6\u6D88\u606F\u7BA1\u7406")), /*#__PURE__*/react.createElement("div", {
    style: styles.content
  }, needsAppScriptAPI ?
  /*#__PURE__*/
  // AppScript API 开启界面
  react.createElement("div", {
    style: styles.apiSection
  }, /*#__PURE__*/react.createElement("h2", {
    style: styles.authTitle
  }, "\u2699\uFE0F \u9700\u8981\u5F00\u542F AppScript API"), /*#__PURE__*/react.createElement("p", {
    style: styles.authDescription
  }, "\u5728\u521B\u5EFA Apps Script \u9879\u76EE\u4E4B\u524D\uFF0C\u60A8\u9700\u8981\u5148\u5F00\u542F Google Apps Script API\u3002"), /*#__PURE__*/react.createElement("div", {
    style: styles.authSteps
  }, /*#__PURE__*/react.createElement("p", {
    style: styles.stepTitle
  }, "\u8BF7\u6309\u7167\u4EE5\u4E0B\u6B65\u9AA4\u64CD\u4F5C\uFF1A"), /*#__PURE__*/react.createElement("ol", {
    style: styles.stepList
  }, /*#__PURE__*/react.createElement("li", null, "\u70B9\u51FB\u4E0B\u65B9\"\u6253\u5F00 AppScript \u8BBE\u7F6E\u9875\u9762\"\u6309\u94AE"), /*#__PURE__*/react.createElement("li", null, "\u5728\u65B0\u6253\u5F00\u7684\u9875\u9762\u4E2D\uFF0C\u627E\u5230 \"Google Apps Script API\" \u8BBE\u7F6E"), /*#__PURE__*/react.createElement("li", null, "\u5C06\u5F00\u5173\u5207\u6362\u5230 \"ON\" \u72B6\u6001"), /*#__PURE__*/react.createElement("li", null, "\u8FD4\u56DE\u6B64\u9875\u9762\uFF0C\u70B9\u51FB\"\u91CD\u65B0\u521D\u59CB\u5316\"\u6309\u94AE\u7EE7\u7EED"))), /*#__PURE__*/react.createElement("button", {
    style: styles.primaryButton,
    onClick: () => window.open(appScriptAPIUrl, '_blank'),
    onMouseOver: e => e.currentTarget.style.backgroundColor = '#0056b3',
    onMouseOut: e => e.currentTarget.style.backgroundColor = '#007bff'
  }, "\u2699\uFE0F \u6253\u5F00 AppScript \u8BBE\u7F6E\u9875\u9762"), /*#__PURE__*/react.createElement("p", {
    style: styles.authNote
  }, "\uD83D\uDCA1 \u63D0\u793A\uFF1A\u5F00\u542F API \u540E\uFF0C\u53EF\u80FD\u9700\u8981\u7B49\u5F85\u51E0\u79D2\u949F\u8BA9\u8BBE\u7F6E\u751F\u6548\u3002"), /*#__PURE__*/react.createElement("p", {
    style: styles.authHint
  }, "\u5F00\u542F API \u540E\uFF0C\u70B9\u51FB\u4E0B\u65B9\u6309\u94AE\u7EE7\u7EED\uFF1A"), /*#__PURE__*/react.createElement("button", {
    style: styles.completeButton,
    onClick: () => {
      setNeedsAppScriptAPI(false);
      setError('');
      handleOneClickSetup();
    },
    onMouseOver: e => e.currentTarget.style.backgroundColor = '#218838',
    onMouseOut: e => e.currentTarget.style.backgroundColor = '#28a745'
  }, "\u2705 \u6211\u5DF2\u5F00\u542F API\uFF0C\u91CD\u65B0\u521D\u59CB\u5316"), error && /*#__PURE__*/react.createElement("div", {
    style: styles.error
  }, "\u274C ", error)) : needsAuth ?
  /*#__PURE__*/
  // 授权界面
  react.createElement(react.Fragment, null, !isInitializing ? /*#__PURE__*/react.createElement(react.Fragment, null, error && /*#__PURE__*/react.createElement("div", {
    style: error.includes('尚未完成授权') ? styles.authError : styles.error
  }, error), /*#__PURE__*/react.createElement("div", {
    style: styles.authSection
  }, /*#__PURE__*/react.createElement("h2", {
    style: styles.authTitle
  }, "\uD83D\uDD10 \u9700\u8981\u6388\u6743"), /*#__PURE__*/react.createElement("p", {
    style: styles.authDescription
  }, "\u7CFB\u7EDF\u5DF2\u6210\u529F\u521B\u5EFA Sheet \u548C AppScript\uFF08\u5B8C\u6210\u6B65\u9AA4 1-5/8\uFF09"), /*#__PURE__*/react.createElement("p", {
    style: styles.authDescription
  }, "\u73B0\u5728\u9700\u8981\u60A8\u6388\u6743 Apps Script \u8BBF\u95EE Google \u670D\u52A1\uFF0C\u4E4B\u540E\u5C06\u7EE7\u7EED\u5B8C\u6210\u5269\u4F59\u6B65\u9AA4\u3002"), /*#__PURE__*/react.createElement("div", {
    style: styles.authSteps
  }, /*#__PURE__*/react.createElement("p", {
    style: styles.stepTitle
  }, "\u8BF7\u6309\u7167\u4EE5\u4E0B\u6B65\u9AA4\u64CD\u4F5C\uFF1A"), /*#__PURE__*/react.createElement("ol", {
    style: styles.stepList
  }, /*#__PURE__*/react.createElement("li", null, "\u70B9\u51FB\u4E0B\u65B9\"\u6253\u5F00\u6388\u6743\u9875\u9762\"\u6309\u94AE"), /*#__PURE__*/react.createElement("li", null, "\u5728\u65B0\u6253\u5F00\u7684\u9875\u9762\u4E2D\uFF0C\u70B9\u51FB \"REVIEW PERMISSIONS\" \u6309\u94AE"), /*#__PURE__*/react.createElement("li", null, "\u9009\u62E9\u60A8\u7684 Google \u8D26\u53F7\u5E76\u6388\u6743\u5E94\u7528"), /*#__PURE__*/react.createElement("li", null, "\u6388\u6743\u5B8C\u6210\u540E\uFF0C\u56DE\u5230\u6B64\u9875\u9762\u70B9\u51FB\"\u5B8C\u6210\u521D\u59CB\u5316\"\u6309\u94AE"))), /*#__PURE__*/react.createElement("button", {
    style: styles.primaryButton,
    onClick: () => window.open(authUrl, '_blank'),
    onMouseOver: e => e.currentTarget.style.backgroundColor = '#0056b3',
    onMouseOut: e => e.currentTarget.style.backgroundColor = '#007bff'
  }, "\uD83D\uDD13 \u6253\u5F00\u6388\u6743\u9875\u9762"), /*#__PURE__*/react.createElement("p", {
    style: styles.authNote
  }, "\uD83D\uDCA1 \u63D0\u793A\uFF1A\u5982\u679C\u6388\u6743\u7A97\u53E3\u5DF2\u5173\u95ED\uFF0C\u60A8\u53EF\u4EE5\u968F\u65F6\u91CD\u65B0\u70B9\u51FB\u4E0A\u65B9\u6309\u94AE\u6253\u5F00\u3002"), /*#__PURE__*/react.createElement("p", {
    style: styles.authHint
  }, "\u6388\u6743\u5B8C\u6210\u540E\uFF0C\u70B9\u51FB\u4E0B\u65B9\u6309\u94AE\u7EE7\u7EED\uFF1A"), /*#__PURE__*/react.createElement("button", {
    style: styles.completeButton,
    onClick: handleCompleteAuth,
    onMouseOver: e => e.currentTarget.style.backgroundColor = '#218838',
    onMouseOut: e => e.currentTarget.style.backgroundColor = '#28a745'
  }, "\u2705 \u6211\u5DF2\u5B8C\u6210\u6388\u6743\uFF0C\u7EE7\u7EED\u521D\u59CB\u5316"), tempResult && /*#__PURE__*/react.createElement("div", {
    style: styles.infoBox
  }, /*#__PURE__*/react.createElement("p", {
    style: styles.infoTitle
  }, "\uD83D\uDCCB \u7CFB\u7EDF\u4FE1\u606F\uFF1A"), /*#__PURE__*/react.createElement("p", {
    style: styles.infoItem
  }, "Sheet ID: ", tempResult.sheetId), /*#__PURE__*/react.createElement("p", {
    style: styles.infoItem
  }, /*#__PURE__*/react.createElement("a", {
    href: tempResult.sheetUrl,
    target: "_blank",
    rel: "noopener noreferrer"
  }, "\uD83D\uDCCA \u67E5\u770B Sheet"))))) : /*#__PURE__*/react.createElement("div", {
    style: styles.loading
  }, /*#__PURE__*/react.createElement("div", {
    style: styles.spinner
  }), /*#__PURE__*/react.createElement("p", {
    style: styles.loadingText
  }, currentStep), /*#__PURE__*/react.createElement("p", {
    style: styles.loadingHint
  }, "\u8FD9\u53EF\u80FD\u9700\u8981 10-15 \u79D2\uFF0C\u8BF7\u7A0D\u5019..."))) : !isInitializing ? /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("p", {
    style: styles.description
  }, "\u60A8\u8FD8\u6CA1\u6709\u8BBE\u7F6E\u5B9A\u65F6\u6D88\u606F\u7CFB\u7EDF\u3002"), /*#__PURE__*/react.createElement("div", {
    style: styles.features
  }, /*#__PURE__*/react.createElement("p", {
    style: styles.featureTitle
  }, "\u70B9\u51FB\u4E0B\u65B9\u6309\u94AE\uFF0C\u7CFB\u7EDF\u5C06\u81EA\u52A8\u4E3A\u60A8\uFF1A"), /*#__PURE__*/react.createElement("ul", {
    style: styles.featureList
  }, /*#__PURE__*/react.createElement("li", null, "\u2705 \u521B\u5EFA Google Sheet \u7EF4\u62A4\u8868"), /*#__PURE__*/react.createElement("li", null, "\u2705 \u914D\u7F6E\u81EA\u52A8\u6267\u884C\u811A\u672C"), /*#__PURE__*/react.createElement("li", null, "\u2705 \u8BBE\u7F6E\u5B9A\u65F6\u89E6\u53D1\u5668"), /*#__PURE__*/react.createElement("li", null, "\u2705 \u6DFB\u52A0\u6D4B\u8BD5\u6D88\u606F\uFF08\u4E00\u5206\u949F\u540E\u63A8\u9001\uFF09"))), /*#__PURE__*/react.createElement("button", {
    style: styles.primaryButton,
    onClick: handleOneClickSetup,
    onMouseOver: e => e.currentTarget.style.backgroundColor = '#0056b3',
    onMouseOut: e => e.currentTarget.style.backgroundColor = '#007bff'
  }, "\uD83D\uDE80 \u4E00\u952E\u751F\u6210\u7EF4\u62A4\u8868"), /*#__PURE__*/react.createElement("div", {
    style: styles.divider
  }, /*#__PURE__*/react.createElement("span", {
    style: styles.dividerText
  }, "\u6216\u8005")), /*#__PURE__*/react.createElement("div", {
    style: styles.manualSection
  }, /*#__PURE__*/react.createElement("p", {
    style: styles.manualTitle
  }, "\u5982\u679C\u60A8\u5DF2\u6709\u7EF4\u62A4\u8868\uFF0C\u53EF\u4EE5\u76F4\u63A5\u7ED1\u5B9A\uFF1A"), /*#__PURE__*/react.createElement("div", {
    style: styles.inputGroup
  }, /*#__PURE__*/react.createElement("input", {
    type: "text",
    placeholder: "\u7C98\u8D34 Sheet URL...",
    value: manualSheetUrl,
    onChange: e => setManualSheetUrl(e.target.value),
    style: styles.input
  }), /*#__PURE__*/react.createElement("button", {
    style: styles.secondaryButton,
    onClick: handleManualBind,
    onMouseOver: e => e.currentTarget.style.backgroundColor = '#5a6268',
    onMouseOut: e => e.currentTarget.style.backgroundColor = '#6c757d'
  }, "\u7ED1\u5B9A"))), error && /*#__PURE__*/react.createElement("div", {
    style: styles.error
  }, "\u274C ", error)) : /*#__PURE__*/react.createElement("div", {
    style: styles.loading
  }, /*#__PURE__*/react.createElement("div", {
    style: styles.spinner
  }), /*#__PURE__*/react.createElement("p", {
    style: styles.loadingText
  }, currentStep), /*#__PURE__*/react.createElement("p", {
    style: styles.loadingHint
  }, "\u8FD9\u53EF\u80FD\u9700\u8981 10-15 \u79D2\uFF0C\u8BF7\u7A0D\u5019..."))));
};
const styles = {
  container: {
    maxWidth: '600px',
    margin: '0 auto',
    padding: '40px 20px'
  },
  header: {
    textAlign: 'center',
    marginBottom: '30px'
  },
  title: {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#333',
    margin: 0
  },
  content: {
    backgroundColor: '#fff',
    borderRadius: '12px',
    padding: '40px',
    boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
  },
  description: {
    fontSize: '16px',
    color: '#666',
    textAlign: 'center',
    marginBottom: '30px'
  },
  features: {
    marginBottom: '30px'
  },
  featureTitle: {
    fontSize: '14px',
    color: '#666',
    marginBottom: '10px'
  },
  featureList: {
    listStyle: 'none',
    padding: 0,
    margin: 0
  },
  primaryButton: {
    width: '100%',
    padding: '15px',
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#fff',
    backgroundColor: '#007bff',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    transition: 'background-color 0.3s'
  },
  divider: {
    textAlign: 'center',
    margin: '30px 0',
    position: 'relative'
  },
  dividerText: {
    backgroundColor: '#fff',
    padding: '0 10px',
    color: '#999',
    fontSize: '14px'
  },
  manualSection: {
    marginTop: '20px'
  },
  manualTitle: {
    fontSize: '14px',
    color: '#666',
    marginBottom: '10px'
  },
  inputGroup: {
    display: 'flex',
    gap: '10px'
  },
  input: {
    flex: 1,
    padding: '10px',
    fontSize: '14px',
    border: '1px solid #ddd',
    borderRadius: '6px'
  },
  secondaryButton: {
    padding: '10px 20px',
    fontSize: '14px',
    color: '#fff',
    backgroundColor: '#6c757d',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    transition: 'background-color 0.3s'
  },
  completeButton: {
    padding: '15px',
    fontSize: '16px',
    fontWeight: 'bold',
    color: '#fff',
    backgroundColor: '#28a745',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
    width: '100%'
  },
  error: {
    marginTop: '20px',
    padding: '15px',
    backgroundColor: '#f8d7da',
    color: '#721c24',
    borderRadius: '6px',
    fontSize: '14px'
  },
  authError: {
    marginTop: '20px',
    padding: '20px',
    backgroundColor: '#fff3cd',
    color: '#856404',
    borderRadius: '8px',
    fontSize: '15px',
    fontWeight: 500,
    border: '2px solid #ffc107',
    lineHeight: '1.6'
  },
  loading: {
    textAlign: 'center',
    padding: '40px 20px'
  },
  spinner: {
    width: '50px',
    height: '50px',
    border: '4px solid #f3f3f3',
    borderTop: '4px solid #007bff',
    borderRadius: '50%',
    margin: '0 auto 20px',
    animation: 'spin 1s linear infinite'
  },
  loadingText: {
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '10px'
  },
  loadingHint: {
    fontSize: '14px',
    color: '#999'
  },
  authSection: {
    padding: '20px 0'
  },
  apiSection: {
    padding: '20px 0'
  },
  authTitle: {
    fontSize: '22px',
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: '15px'
  },
  authDescription: {
    fontSize: '15px',
    color: '#666',
    textAlign: 'center',
    marginBottom: '10px'
  },
  authSteps: {
    backgroundColor: '#f8f9fa',
    padding: '20px',
    borderRadius: '8px',
    marginBottom: '20px'
  },
  stepTitle: {
    fontSize: '15px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '10px'
  },
  stepList: {
    fontSize: '14px',
    color: '#666',
    lineHeight: '1.8',
    paddingLeft: '20px'
  },
  authNote: {
    fontSize: '13px',
    color: '#888',
    textAlign: 'center',
    marginTop: '10px',
    fontStyle: 'italic'
  },
  authHint: {
    fontSize: '14px',
    color: '#666',
    textAlign: 'center',
    marginTop: '20px',
    marginBottom: '10px'
  },
  infoBox: {
    backgroundColor: '#e7f3ff',
    padding: '15px',
    borderRadius: '6px',
    marginTop: '20px',
    border: '1px solid #b3d7ff'
  },
  infoTitle: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '8px'
  },
  infoItem: {
    fontSize: '13px',
    color: '#666',
    marginBottom: '5px'
  }
};

// 添加 CSS 动画
const styleSheet = document.createElement('style');
styleSheet.textContent = `
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`;
document.head.appendChild(styleSheet);
;// CONCATENATED MODULE: ./src/sheet.ts
class Sheet {
  constructor(token, sheetId, sheetName) {
    this.token = token;
    this.sheetId = sheetId;
    this.sheetName = sheetName;
    this.gid = null;
  }

  /**
   * 从 Google Sheets URL 创建 Sheet 实例（静态工厂方法）
   * @param url Google Sheets URL
   * @param token 认证 token
   * @returns Sheet 实例
   */
  static async fromUrl(url, token) {
    const sheetId = Sheet.extractSheetId(url);
    const gid = Sheet.extractGid(url);
    if (!sheetId) {
      throw new Error('无法从 URL 中提取 Sheet ID');
    }

    // 获取 sheetName
    const sheetName = await Sheet.getSheetNameByGid(token, sheetId, gid);
    const sheet = new Sheet(token, sheetId, sheetName);
    sheet.gid = gid;
    return sheet;
  }
  static async getToken() {
    return new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({
        interactive: true
      }, token => {
        if (chrome.runtime.lastError) reject(chrome.runtime.lastError);else resolve(token);
      });
    });
  }
  static extractSheetId(url) {
    const match = url.match(/\/d\/([a-zA-Z0-9-_]+)/);
    return match ? match[1] : null;
  }
  static extractGid(url) {
    const match = url.match(/[#&]gid=([0-9]+)/);
    return match ? match[1] : null;
  }
  static async getSheetNames(token, sheetId) {
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}`;
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    const json = await res.json();
    return json.sheets;
  }
  static async getSheetNameByGid(token, sheetId, gid) {
    const sheets = await Sheet.getSheetNames(token, sheetId);
    if (gid) {
      const sheet = sheets.find(s => s.properties.sheetId.toString() === gid);
      if (sheet) return sheet.properties.title;
    }
    // 如果找不到对应的gid或gid为null，返回第一个sheet的名称
    return sheets[0].properties.title;
  }
  async readSheet() {
    let valueRenderOption = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'FORMATTED_VALUE';
    const sheetUrl = `https://sheets.googleapis.com/v4/spreadsheets/${this.sheetId}/values/${this.sheetName}?valueRenderOption=${valueRenderOption}`;
    const res = await fetch(sheetUrl, {
      headers: {
        Authorization: `Bearer ${this.token}`
      }
    });
    if (!res.ok) {
      const errorText = await res.text();
      throw new Error(`读取 Sheet 失败 (${res.status}): ${errorText}`);
    }
    const json = await res.json();
    return json.values;
  }
  async writeSheet(values) {
    let position = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'A1';
    const sheetUrl = `https://sheets.googleapis.com/v4/spreadsheets/${this.sheetId}/values/${this.sheetName}!${position}?valueInputOption=USER_ENTERED`;
    const res = await fetch(sheetUrl, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        values
      })
    });
    return res.json();
  }

  /**
   * 批量更新多个范围的数据
   * @param updates 更新数据数组，每个元素包含 range 和 values
   * @returns API 响应
   */
  async batchUpdateValues(updates) {
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${this.sheetId}/values:batchUpdate`;
    const data = updates.map(update => ({
      range: `${this.sheetName}!${update.range}`,
      values: update.values
    }));
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        valueInputOption: 'USER_ENTERED',
        data: data
      })
    });
    if (!res.ok) {
      const error = await res.json();
      throw new Error(`批量更新失败: ${error.error?.message || '未知错误'}`);
    }
    return res.json();
  }

  // 插入行或列
  async insertDimension(dimension, startIndex, endIndex, sheetId) {
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${this.sheetId}:batchUpdate`;

    // 使用传入的 sheetId 或 this.gid，如果都没有则使用 0（第一个 sheet）
    const targetSheetId = sheetId ?? (this.gid ? parseInt(this.gid) : 0);
    const request = {
      requests: [{
        insertDimension: {
          range: {
            sheetId: targetSheetId,
            dimension,
            startIndex,
            endIndex
          },
          inheritFromBefore: true
        }
      }, {
        addDimensionGroup: {
          range: {
            sheetId: targetSheetId,
            dimension,
            startIndex,
            endIndex
          }
        }
      }]
    };
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(request)
    });
    if (!res.ok) {
      const error = await res.json();
      throw new Error(`插入维度失败: ${error.error?.message || '未知错误'}`);
    }
  }

  // 删除行或列
  async deleteDimension(dimension, startIndex, endIndex, sheetId) {
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${this.sheetId}:batchUpdate`;

    // 使用传入的 sheetId 或 this.gid，如果都没有则使用 0（第一个 sheet）
    const targetSheetId = sheetId ?? (this.gid ? parseInt(this.gid) : 0);
    const request = {
      requests: [{
        deleteDimension: {
          range: {
            sheetId: targetSheetId,
            dimension,
            startIndex,
            endIndex
          }
        }
      }]
    };
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(request)
    });
    if (!res.ok) {
      const error = await res.json();
      throw new Error(`删除维度失败: ${error.error?.message || '未知错误'}`);
    }
  }

  /**
   * 读取配置表数据
   * @param sheetName 配置表名称
   * @returns 配置表数据
   */
  async readConfigSheet() {
    let configSheetName = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
    if (!configSheetName) configSheetName = this.sheetName + '_config';
    try {
      const sheetUrl = `https://sheets.googleapis.com/v4/spreadsheets/${this.sheetId}/values/${configSheetName}`;
      const res = await fetch(sheetUrl, {
        headers: {
          Authorization: `Bearer ${this.token}`
        }
      });
      const json = await res.json();
      return json.values;
    } catch (error) {
      console.error('读取配置表失败:', error);
      throw error;
    }
  }

  /**
   * 获取表格的第一行作为表头
   * @returns 表头数组
   */
  async getHeaders() {
    const values = await this.readSheet();
    if (!values || values.length === 0) {
      throw new Error('表格为空');
    }
    return values[0];
  }
  getSheetName() {
    return this.sheetName;
  }
  getGid() {
    return this.gid;
  }

  // 移动单行到新位置（保留格式）
  async moveRow(fromRowIndex, toRowIndex, sheetId) {
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${this.sheetId}:batchUpdate`;

    // 使用传入的 sheetId 或 this.gid，如果都没有则使用 0（第一个 sheet）
    const targetSheetId = sheetId ?? (this.gid ? parseInt(this.gid) : 0);

    // moveDimension API: 把 [startIndex, endIndex) 的行移动到 destinationIndex
    // 注意：如果 destinationIndex > startIndex，移动后的位置是 destinationIndex - 1
    // 如果 destinationIndex < startIndex，移动后的位置是 destinationIndex
    const request = {
      requests: [{
        moveDimension: {
          source: {
            sheetId: targetSheetId,
            dimension: 'ROWS',
            startIndex: fromRowIndex,
            endIndex: fromRowIndex + 1
          },
          destinationIndex: toRowIndex > fromRowIndex ? toRowIndex + 1 : toRowIndex
        }
      }]
    };
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(request)
    });
    if (!res.ok) {
      const error = await res.json();
      throw new Error(`移动行失败: ${error.error?.message || '未知错误'}`);
    }
  }
}
;// CONCATENATED MODULE: ./src/scheduled-messages/ScheduledMessageService.ts
/**
 * 定时消息数据服务层
 * 封装 Google Sheets API 的 CRUD 操作
 * 
 * 核心特性：动态列映射
 * ========================
 * 本服务支持动态识别 Google Sheet 的列位置，用户可以随意调整列的顺序：
 * 
 * 1. 读取机制：
 *    - 首先读取 header 行（第一行）获取列名
 *    - 根据 header 的列名和索引创建映射关系
 *    - 解析数据行时，通过列名从对应位置读取值
 * 
 * 2. 写入机制：
 *    - 获取当前的 header 顺序
 *    - 根据 header 顺序动态生成行数据数组
 *    - 自动适配不同的列顺序，确保数据写入正确的列
 * 
 * 3. 缓存优化：
 *    - header 结构会被缓存，避免重复读取
 *    - 同步数据时会清除缓存，确保获取最新的列结构
 * 
 * 4. 向后兼容：
 *    - 支持旧版本的固定列顺序
 *    - 支持用户自定义的列顺序
 *    - 列名保持不变，只是位置可以调整
 * 
 * 使用示例：
 * ```typescript
 * const service = new ScheduledMessageService(token);
 * 
 * // 读取数据 - 自动适配任何列顺序
 * const messages = await service.getAllMessages();
 * 
 * // 创建消息 - 自动根据当前列顺序写入
 * await service.createMessage({
 *   Topic: '测试消息',
 *   Content: '内容',
 *   ...
 * });
 * ```
 */


class ScheduledMessageService {
  // 缓存 header 顺序

  constructor(token) {
    this.config = null;
    this.headerCache = null;
    this.token = token;
  }

  /**
   * 刷新 token
   */
  async refreshToken() {
    return new Promise((resolve, reject) => {
      // 先移除缓存的 token
      chrome.identity.getAuthToken({
        interactive: false
      }, cachedToken => {
        if (cachedToken) {
          chrome.identity.removeCachedAuthToken({
            token: cachedToken
          }, () => {
            // 获取新 token
            chrome.identity.getAuthToken({
              interactive: true
            }, newToken => {
              if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
              } else if (newToken) {
                this.token = newToken;
                resolve(newToken);
              } else {
                reject(new Error('无法获取新 token'));
              }
            });
          });
        } else {
          // 直接获取新 token
          chrome.identity.getAuthToken({
            interactive: true
          }, newToken => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else if (newToken) {
              this.token = newToken;
              resolve(newToken);
            } else {
              reject(new Error('无法获取新 token'));
            }
          });
        }
      });
    });
  }

  /**
   * 执行带自动重试的操作
   * 如果遇到 401 错误，自动刷新 token 并重试一次
   */
  async withTokenRetry(operation) {
    try {
      return await operation();
    } catch (error) {
      const is401Error = error.message?.includes('401') || error.message?.includes('Unauthorized') || error.message?.includes('Invalid Credentials');
      if (is401Error) {
        console.log('🔄 检测到 401 错误，尝试刷新 token...');
        await this.refreshToken();
        console.log('✅ Token 刷新成功，重试请求...');
        return await operation();
      }
      throw error;
    }
  }

  /**
   * 加载配置
   */
  async loadConfig() {
    const result = await chrome.storage.local.get(['scheduledMessagesConfig']);
    this.config = result.scheduledMessagesConfig || null;
    return this.config;
  }

  /**
   * 获取所有消息
   */
  async getAllMessages() {
    if (!this.config) {
      await this.loadConfig();
    }
    if (!this.config) {
      throw new Error('未找到配置，请先初始化系统');
    }
    return await this.withTokenRetry(async () => {
      const sheet = new Sheet(this.token, this.config.sheetId, 'Messages');
      const data = await sheet.readSheet();
      if (!data || data.length === 0) {
        return [];
      }
      const headers = data[0];
      const messages = [];
      let hasUpdates = false;
      for (let i = 1; i < data.length; i++) {
        const row = data[i];
        const message = this.parseRowToMessage(row, headers);
        if (message) {
          // 如果没有 ID，自动生成一个
          if (!message.ID) {
            message.ID = `msg_${Date.now()}_${i}`;
            hasUpdates = true;
            console.log(`自动生成 ID: ${message.ID} (行 ${i + 1})`);
          }

          // 自动判断消息类型（如果没有 Type 字段）
          if (!message.Type) {
            message.Type = this.determineMessageType(message);
          }

          // 如果有更新，写回 Sheet
          if (hasUpdates) {
            const row = await this.messageToRow(message);
            await this.updateRow(i + 1, row);
          }
          messages.push(message);
        }
      }
      if (hasUpdates) {
        console.log('✅ 已自动为缺失 ID 的消息生成 ID');
      }
      return messages;
    });
  }

  /**
   * 根据 ID 获取消息
   */
  async getMessageById(id) {
    const messages = await this.getAllMessages();
    return messages.find(msg => msg.ID === id) || null;
  }

  /**
   * 自动判断消息类型
   */
  determineMessageType(message) {
    // 如果填写了 Repeat_Every 和 Repeat_Unit，判断为 Periodic
    if (message.Repeat_Every && message.Repeat_Unit) {
      return 'Periodic';
    }

    // 如果填写了 Schedule_Time，判断为 Hourly
    if (message.Schedule_Time && message.Schedule_Time.trim()) {
      return 'Hourly';
    }

    // 否则为 Daily（每日早上9点执行）
    return 'Daily';
  }

  /**
   * 创建新消息
   */
  async createMessage(formData) {
    if (!this.config) {
      await this.loadConfig();
    }
    if (!this.config) {
      throw new Error('未找到配置，请先初始化系统');
    }
    const message = {
      ID: `msg_${Date.now()}`,
      ...formData,
      Schedule_Time: formData.Schedule_Time || '',
      // 留空表示每日9点
      Status: 'Active',
      Exec_Count: 0,
      Exec_Log: '待执行'
    };

    // 自动判断类型
    message.Type = this.determineMessageType(message);

    // 计算下次执行时间
    message.Next_Exec = this.calculateNextExecution(message);

    // 添加到 Sheet
    const row = await this.messageToRow(message);
    await this.appendRow(row);
    return message;
  }

  /**
   * 更新消息
   */
  async updateMessage(id, updates) {
    const messages = await this.getAllMessages();
    const index = messages.findIndex(msg => msg.ID === id);
    if (index === -1) {
      throw new Error(`未找到消息: ${id}`);
    }
    const updatedMessage = {
      ...messages[index],
      ...updates
    };

    // 重新计算下次执行时间
    if (updates.Schedule_Date || updates.Schedule_Time || updates.Type || updates.Repeat_Every) {
      updatedMessage.Next_Exec = this.calculateNextExecution(updatedMessage);
    }

    // 更新到 Sheet（行号 = 索引 + 2，因为有表头且从1开始）
    const row = await this.messageToRow(updatedMessage);
    await this.updateRow(index + 2, row);
    return updatedMessage;
  }

  /**
   * 删除消息
   */
  async deleteMessage(id) {
    const messages = await this.getAllMessages();
    const index = messages.findIndex(msg => msg.ID === id);
    if (index === -1) {
      throw new Error(`未找到消息: ${id}`);
    }

    // 删除行（行号 = 索引 + 2）
    await this.deleteRow(index + 2);
  }

  /**
   * 删除所有已完成的消息（Status = 'Done'）
   * @returns {Promise<number>} 删除的消息数量
   */
  async deleteCompletedMessages() {
    const messages = await this.getAllMessages();
    const completedMessages = messages.filter(msg => msg.Status === 'Done');
    if (completedMessages.length === 0) {
      return 0;
    }

    // 从后往前删除，避免索引变化影响
    const sortedIndices = completedMessages.map(msg => messages.findIndex(m => m.ID === msg.ID)).sort((a, b) => b - a);
    for (const index of sortedIndices) {
      await this.deleteRow(index + 2);
    }
    return completedMessages.length;
  }

  /**
   * 暂停/恢复消息
   */
  async toggleMessageStatus(id) {
    const message = await this.getMessageById(id);
    if (!message) {
      throw new Error(`未找到消息: ${id}`);
    }
    const newStatus = message.Status === 'Active' ? 'Paused' : 'Active';

    // 如果从 Done 状态切换到 Active，清空 Last_Exec（允许重新推送）
    const updates = {
      Status: newStatus
    };
    if (message.Status === 'Done' && newStatus === 'Active') {
      updates.Last_Exec = '';
      console.log(`✅ 消息 ${id} 从 Done 切换到 Active，已清空 Last_Exec 以允许重新推送`);
    }
    return await this.updateMessage(id, updates);
  }

  /**
   * 获取统计信息
   */
  async getStatistics() {
    const messages = await this.getAllMessages();
    const today = new Date().toISOString().split('T')[0];
    return {
      total: messages.length,
      active: messages.filter(m => m.Status === 'Active').length,
      paused: messages.filter(m => m.Status === 'Paused').length,
      completed: messages.filter(m => m.Status === 'Completed').length,
      done: messages.filter(m => m.Status === 'Done').length,
      executedToday: messages.filter(m => m.Last_Exec && m.Last_Exec.startsWith(today)).length
    };
  }

  /**
   * 同步数据（从 Sheet 刷新）
   */
  async syncFromSheet() {
    // 清除 header 缓存，确保获取最新的列结构
    this.clearHeaderCache();
    // 直接返回最新数据即可
    return await this.getAllMessages();
  }

  // ========== 私有方法 ==========

  /**
   * 获取 Sheet 的 Header（带缓存）
   */
  async getHeaders() {
    if (this.headerCache) {
      return this.headerCache;
    }
    if (!this.config) {
      await this.loadConfig();
    }
    if (!this.config) {
      throw new Error('未找到配置，请先初始化系统');
    }
    return await this.withTokenRetry(async () => {
      const sheet = new Sheet(this.token, this.config.sheetId, 'Messages');
      const data = await sheet.readSheet();
      if (!data || data.length === 0) {
        throw new Error('无法读取 Sheet 数据');
      }
      this.headerCache = data[0];
      return this.headerCache;
    });
  }

  /**
   * 清除 header 缓存（在 Sheet 结构可能改变时调用）
   */
  clearHeaderCache() {
    this.headerCache = null;
  }

  /**
   * 解析行数据为消息对象
   */
  parseRowToMessage(row, headers) {
    if (!row || row.length === 0) return null;
    const message = {};
    headers.forEach((header, index) => {
      message[header] = row[index] || '';
    });
    return message;
  }

  /**
   * 将消息对象转换为行数据（根据 header 顺序动态生成）
   */
  async messageToRow(message) {
    const headers = await this.getHeaders();
    const row = [];

    // 根据 header 顺序构建行数据
    for (const header of headers) {
      const value = message[header];

      // 处理不同类型的字段
      if (value === undefined || value === null) {
        row.push('');
      } else if (typeof value === 'number') {
        row.push(value);
      } else {
        row.push(String(value));
      }
    }
    return row;
  }

  /**
   * 追加行
   */
  async appendRow(row) {
    if (!this.config) {
      throw new Error('未找到配置');
    }
    await this.withTokenRetry(async () => {
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${this.config.sheetId}/values/Messages:append?valueInputOption=USER_ENTERED`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          values: [row]
        })
      });
      if (!response.ok) {
        const error = await response.text();
        throw new Error(`添加行失败 (${response.status}): ${error}`);
      }
    });
  }

  /**
   * 更新行（根据 header 数量动态确定列范围）
   */
  async updateRow(rowIndex, row) {
    if (!this.config) {
      throw new Error('未找到配置');
    }
    await this.withTokenRetry(async () => {
      // 获取 header 以确定列数
      const headers = await this.getHeaders();
      const columnCount = headers.length;

      // 将列数转换为字母（A, B, C, ... Z, AA, AB, ...）
      const endColumn = this.numberToColumn(columnCount);
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${this.config.sheetId}/values/Messages!A${rowIndex}:${endColumn}${rowIndex}?valueInputOption=USER_ENTERED`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          values: [row]
        })
      });
      if (!response.ok) {
        const error = await response.text();
        throw new Error(`更新行失败 (${response.status}): ${error}`);
      }
    });
  }

  /**
   * 将数字转换为 Excel 列字母（1 -> A, 2 -> B, 26 -> Z, 27 -> AA）
   */
  numberToColumn(num) {
    let column = '';
    while (num > 0) {
      const remainder = (num - 1) % 26;
      column = String.fromCharCode(65 + remainder) + column;
      num = Math.floor((num - 1) / 26);
    }
    return column;
  }

  /**
   * 获取 Messages Sheet 的 sheetId
   */
  async getMessagesSheetId() {
    let forceRefresh = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
    // 如果配置中有 messagesSheetId 且不强制刷新，直接使用
    // 注意：sheetId 可以是 0，这是有效值，所以只检查 undefined
    if (!forceRefresh && this.config?.messagesSheetId !== undefined && this.config.messagesSheetId !== null) {
      return this.config.messagesSheetId;
    }

    // 否则动态获取
    if (!this.config) {
      throw new Error('未找到配置');
    }
    return await this.withTokenRetry(async () => {
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${this.config.sheetId}?fields=sheets.properties`, {
        headers: {
          'Authorization': `Bearer ${this.token}`
        }
      });
      if (!response.ok) {
        throw new Error(`获取 Sheet 信息失败: ${response.status}`);
      }
      const data = await response.json();
      const messagesSheet = data.sheets.find(s => s.properties.title === 'Messages');
      if (!messagesSheet) {
        throw new Error('未找到 Messages 工作表');
      }
      const sheetId = messagesSheet.properties.sheetId;

      // 缓存到配置中
      this.config.messagesSheetId = sheetId;
      await chrome.storage.local.set({
        scheduledMessagesConfig: this.config
      });
      return sheetId;
    });
  }

  /**
   * 删除行
   */
  async deleteRow(rowIndex) {
    if (!this.config) {
      throw new Error('未找到配置');
    }

    // 尝试删除行的内部函数
    const tryDelete = async forceRefreshSheetId => {
      try {
        const messagesSheetId = await this.getMessagesSheetId(forceRefreshSheetId);
        const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${this.config.sheetId}:batchUpdate`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            requests: [{
              deleteDimension: {
                range: {
                  sheetId: messagesSheetId,
                  dimension: 'ROWS',
                  startIndex: rowIndex - 1,
                  endIndex: rowIndex
                }
              }
            }]
          })
        });
        if (!response.ok) {
          const errorText = await response.text();

          // 检查是否是 sheetId 无效的错误
          if (errorText.includes('No grid with id')) {
            // 清除缓存的 sheetId
            if (this.config) {
              console.log(`🔄 检测到 sheetId 无效 (当前值: ${messagesSheetId})，将强制刷新...`);
              this.config.messagesSheetId = undefined;
              await chrome.storage.local.set({
                scheduledMessagesConfig: this.config
              });
            }
            return {
              success: false,
              needsRetry: true,
              error: errorText
            };
          }
          return {
            success: false,
            needsRetry: false,
            error: `删除行失败 (${response.status}): ${errorText}`
          };
        }
        return {
          success: true,
          needsRetry: false
        };
      } catch (error) {
        // 处理 401 错误
        if (error.message?.includes('401') || error.message?.includes('Unauthorized')) {
          throw error; // 让外层的 withTokenRetry 处理
        }
        return {
          success: false,
          needsRetry: false,
          error: error.message
        };
      }
    };

    // 第一次尝试（使用缓存的 sheetId）
    let result = await this.withTokenRetry(() => tryDelete(false));

    // 如果需要重试（sheetId 无效）
    if (!result.success && result.needsRetry) {
      console.log('🔄 重试删除操作（强制刷新 sheetId）...');
      result = await this.withTokenRetry(() => tryDelete(true));
    }

    // 如果仍然失败
    if (!result.success) {
      throw new Error(result.error || '删除行失败');
    }
  }

  /**
   * 计算下次执行时间
   */
  calculateNextExecution(message) {
    // 检查是否为 Timeline 触发
    if (!message.Schedule_Date && message.Timeline_Milestone) {
      // Timeline 触发：返回描述性文本，不计算具体日期
      const milestone = message.Timeline_Milestone;
      const offset = message.Timeline_Offset ?? 0;
      let offsetText = '';
      if (offset === 0) {
        offsetText = '当天';
      } else if (offset === 1) {
        offsetText = '后一天';
      } else if (offset === -1) {
        offsetText = '前一天';
      } else if (offset > 1) {
        offsetText = `后${offset}天`;
      } else if (offset < -1) {
        offsetText = `前${Math.abs(offset)}天`;
      }
      return `${milestone} ${offsetText}`;
    }
    if (message.Type === 'Daily') {
      // Daily 类型只执行一次
      return message.Schedule_Date || '';
    } else if (message.Type === 'Hourly') {
      // Hourly 类型只执行一次
      return `${message.Schedule_Date} ${message.Schedule_Time}`;
    } else if (message.Type === 'Periodic') {
      // 周期性任务
      if (!message.Schedule_Date || !message.Repeat_Every || !message.Repeat_Unit) {
        return '';
      }
      const startDate = new Date(message.Schedule_Date);
      const now = new Date();
      const nextDate = new Date(startDate);

      // 如果开始日期在未来，返回开始日期
      if (startDate > now) {
        return message.Schedule_Date;
      }

      // 计算下一次执行时间
      const every = message.Repeat_Every;
      const unit = message.Repeat_Unit;
      while (nextDate <= now) {
        if (unit === 'Day') {
          nextDate.setDate(nextDate.getDate() + every);
        } else if (unit === 'Week') {
          nextDate.setDate(nextDate.getDate() + 7 * every);
        } else if (unit === 'Month') {
          nextDate.setMonth(nextDate.getMonth() + every);
        } else if (unit === 'Year') {
          nextDate.setFullYear(nextDate.getFullYear() + every);
        }
      }
      return nextDate.toISOString().split('T')[0];
    }
    return '';
  }
}
// EXTERNAL MODULE: ./src/scheduled-messages/ConfigSyncService.ts
var ConfigSyncService = __webpack_require__(8998);
;// CONCATENATED MODULE: ./src/scheduled-messages/AppScriptUpdater.ts
/**
 * App Script 自动更新器
 * 负责检测和更新用户已部署的 App Script 代码
 */


class AppScriptUpdater {
  constructor(token, config) {
    this.config = null;
    this.token = token;
    this.config = config || null;
  }

  /**
   * 从 App Script 模板文件中解析版本信息
   */
  static async parseVersionFromTemplate() {
    // 如果已经缓存，直接返回
    if (AppScriptUpdater.cachedVersionInfo) {
      return AppScriptUpdater.cachedVersionInfo;
    }
    try {
      const response = await fetch(chrome.runtime.getURL('app-script-template.gs'));
      if (!response.ok) {
        throw new Error(`无法加载模板文件: HTTP ${response.status}`);
      }
      const content = await response.text();

      // 解析版本号：var APP_SCRIPT_VERSION = '2.1.0';
      const versionMatch = content.match(/var\s+APP_SCRIPT_VERSION\s*=\s*['"`]([^'"`]+)['"`];/);
      if (!versionMatch) {
        throw new Error('无法找到 APP_SCRIPT_VERSION 定义');
      }

      // 解析更新日期：var APP_SCRIPT_LAST_UPDATED = '2025-12-04';
      const lastUpdatedMatch = content.match(/var\s+APP_SCRIPT_LAST_UPDATED\s*=\s*['"`]([^'"`]+)['"`];/);
      if (!lastUpdatedMatch) {
        throw new Error('无法找到 APP_SCRIPT_LAST_UPDATED 定义');
      }
      const versionInfo = {
        version: versionMatch[1],
        lastUpdated: lastUpdatedMatch[1]
      };

      // 缓存结果
      AppScriptUpdater.cachedVersionInfo = versionInfo;
      console.log(`📦 从模板文件解析到版本信息: ${versionInfo.version} (${versionInfo.lastUpdated})`);
      return versionInfo;
    } catch (error) {
      console.error('解析模板文件版本信息失败:', error);
      // 回退到默认版本
      const fallbackVersion = {
        version: '1.0.0',
        lastUpdated: new Date().toISOString().split('T')[0]
      };
      AppScriptUpdater.cachedVersionInfo = fallbackVersion;
      return fallbackVersion;
    }
  }

  /**
   * 获取最新的 App Script 版本号
   */
  static async getLatestVersion() {
    const versionInfo = await AppScriptUpdater.parseVersionFromTemplate();
    return versionInfo.version;
  }

  /**
   * 检查是否需要更新
   */
  async checkForUpdates() {
    try {
      // 获取最新版本号
      const latestVersion = await AppScriptUpdater.getLatestVersion();
      if (!this.config?.webAppUrl) {
        return {
          needsUpdate: false,
          currentVersion: 'unknown',
          latestVersion,
          error: '未找到 Web App 配置'
        };
      }

      // 从 Web App 获取当前部署的版本
      const currentVersion = await this.getDeployedVersion();

      // 比较版本
      const needsUpdate = this.compareVersions(currentVersion, latestVersion) < 0;
      return {
        needsUpdate,
        currentVersion,
        latestVersion
      };
    } catch (error) {
      console.error('检查更新失败:', error);
      // 发生错误时也需要获取最新版本号
      const latestVersion = await AppScriptUpdater.getLatestVersion().catch(() => '1.0.0');
      return {
        needsUpdate: false,
        currentVersion: 'unknown',
        latestVersion,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * 获取已部署的 App Script 版本
   */
  async getDeployedVersion() {
    if (!this.config?.webAppUrl) {
      throw new Error('未找到 Web App URL');
    }
    try {
      const response = await fetch(`${this.config.webAppUrl}?action=getVersion`, {
        method: 'GET',
        headers: {
          'Cache-Control': 'no-cache'
        }
      });
      if (!response.ok) {
        throw new Error(`获取版本失败: HTTP ${response.status}`);
      }
      const data = await response.json();
      return data.version || '0.0.0';
    } catch (error) {
      console.warn('无法获取已部署的版本，可能是旧版本脚本:', error);
      // 如果 getVersion 端点不存在，说明是旧版本
      return '0.0.0';
    }
  }

  /**
   * 执行更新
   * 使用 deployments.update API 更新现有部署，保持 URL 不变
   */
  async updateAppScript() {
    try {
      if (!this.config?.scriptId) {
        return {
          success: false,
          message: '未找到 Script ID',
          error: 'SCRIPT_ID_NOT_FOUND'
        };
      }
      console.log('开始更新 App Script...');

      // 0. 获取最新版本号
      const latestVersion = await AppScriptUpdater.getLatestVersion();

      // 1. 加载最新的 App Script 模板代码
      const scriptCode = await this.loadAppScriptTemplate();

      // 2. 更新 App Script 项目代码
      await this.updateProjectContent(this.config.scriptId, scriptCode);

      // 3. 创建新版本
      const versionNumber = await this.createVersion(this.config.scriptId, latestVersion);

      // 4. 获取现有的 deployment ID（必须是有 versionNumber 的正式部署，不是 @HEAD）
      const deploymentId = await this.getOrCreateDeploymentId();

      // 5. 更新部署到新版本（保持 URL 不变）
      await this.updateDeployment(this.config.scriptId, deploymentId, versionNumber, latestVersion);

      // 6. 更新配置中的版本信息
      await this.updateConfigVersion(latestVersion);
      console.log('App Script 更新成功！');
      return {
        success: true,
        message: `App Script 已更新到版本 ${latestVersion}`,
        newVersion: latestVersion
      };
    } catch (error) {
      console.error('更新 App Script 失败:', error);
      return {
        success: false,
        message: '更新失败',
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * 加载 App Script 模板代码
   */
  async loadAppScriptTemplate() {
    try {
      const response = await fetch(chrome.runtime.getURL('app-script-template.gs'));
      if (!response.ok) {
        throw new Error(`无法加载模板文件: HTTP ${response.status}`);
      }
      return await response.text();
    } catch (error) {
      console.error('加载 App Script 模板文件失败:', error);
      throw new Error(`加载模板失败: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * 更新 App Script 项目内容
   */
  async updateProjectContent(scriptId, scriptCode) {
    const response = await fetch(`https://script.googleapis.com/v1/projects/${scriptId}/content`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        files: [{
          name: 'Code',
          type: 'SERVER_JS',
          source: scriptCode
        }, {
          name: 'appsscript',
          type: 'JSON',
          source: JSON.stringify({
            timeZone: 'Asia/Shanghai',
            exceptionLogging: 'STACKDRIVER',
            runtimeVersion: 'V8',
            webapp: {
              access: 'ANYONE_ANONYMOUS',
              executeAs: 'USER_DEPLOYING'
            },
            executionApi: {
              access: 'ANYONE'
            }
          })
        }]
      })
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`更新项目内容失败: ${error}`);
    }
    console.log('✅ 项目代码已更新');
  }

  /**
   * 创建新版本
   */
  async createVersion(scriptId, version) {
    const response = await fetch(`https://script.googleapis.com/v1/projects/${scriptId}/versions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        description: `Auto update to version ${version}`
      })
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`创建版本失败: ${error}`);
    }
    const versionResult = await response.json();
    console.log(`✅ 版本创建成功: ${versionResult.versionNumber}`);
    return versionResult.versionNumber;
  }

  /**
   * 获取或创建 Deployment ID
   * 
   * 重要：必须使用有 versionNumber 的正式 deployment，而不是 @HEAD deployment
   * 
   * Deployment 类型：
   * 1. @HEAD Deployment（测试部署）
   *    - 没有 versionNumber
   *    - updateTime 是 1970-01-01T00:00:00Z
   *    - 只读，不能通过 API 修改
   *    - ❌ 不能用于自动更新
   * 
   * 2. 正式版本 Deployment
   *    - 有 versionNumber
   *    - 有正常的 updateTime
   *    - 可以通过 API 更新
   *    - ✅ 用于自动更新
   */
  async getOrCreateDeploymentId() {
    // 优先从配置中读取 deploymentId（兼容老版本）
    if (this.config?.deploymentId) {
      console.log(`使用配置中的 deployment ID: ${this.config.deploymentId}`);

      // 验证这个 deploymentId 是否是正式版本（有 versionNumber）
      try {
        const isValid = await this.verifyDeploymentId(this.config.deploymentId);
        if (isValid) {
          return this.config.deploymentId;
        } else {
          console.warn('⚠️ 配置中的 deployment 是 @HEAD deployment（只读），需要查找正式版本');
        }
      } catch (error) {
        console.warn('⚠️ 验证 deployment ID 失败，重新查找:', error);
      }
    }

    // 从 API 获取 deployments 列表
    if (!this.config?.scriptId) {
      throw new Error('未找到 Script ID');
    }
    const response = await fetch(`https://script.googleapis.com/v1/projects/${this.config.scriptId}/deployments`, {
      headers: {
        'Authorization': `Bearer ${this.token}`
      }
    });
    if (!response.ok) {
      throw new Error('获取 deployments 列表失败');
    }
    const data = await response.json();
    const deployments = data.deployments || [];

    // 查找正式版本的 Web App deployment（必须有 versionNumber）
    const versionedDeployment = deployments.find(d => d.deploymentConfig?.versionNumber &&
    // 必须有 versionNumber
    d.entryPoints?.some(ep => ep.entryPointType === 'WEB_APP'));
    if (versionedDeployment) {
      const deploymentId = versionedDeployment.deploymentId;
      const versionNumber = versionedDeployment.deploymentConfig.versionNumber;
      console.log(`✅ 找到正式版本 deployment: ${deploymentId} (version ${versionNumber})`);

      // 保存到配置
      if (this.config) {
        this.config.deploymentId = deploymentId;
        await this.saveConfigToStorage();
      }
      return deploymentId;
    }

    // 如果没有找到正式版本 deployment，列出所有 deployment 供调试
    console.error('❌ 未找到正式版本的 Web App deployment');
    console.error('所有 deployments:', deployments.map(d => ({
      id: d.deploymentId,
      hasVersion: !!d.deploymentConfig?.versionNumber,
      version: d.deploymentConfig?.versionNumber,
      updateTime: d.updateTime
    })));
    throw new Error('未找到可更新的 Web App deployment（需要有 versionNumber 的正式部署）');
  }

  /**
   * 验证 deployment ID 是否是正式版本（非 @HEAD）
   */
  async verifyDeploymentId(deploymentId) {
    if (!this.config?.scriptId) {
      return false;
    }
    try {
      const response = await fetch(`https://script.googleapis.com/v1/projects/${this.config.scriptId}/deployments/${deploymentId}`, {
        headers: {
          'Authorization': `Bearer ${this.token}`
        }
      });
      if (!response.ok) {
        return false;
      }
      const deployment = await response.json();

      // 检查是否有 versionNumber（正式版本）
      return !!deployment.deploymentConfig?.versionNumber;
    } catch (error) {
      console.warn('验证 deployment 失败:', error);
      return false;
    }
  }

  /**
   * 更新部署（使用 update API 保持 URL 不变）
   */
  async updateDeployment(scriptId, deploymentId, versionNumber, version) {
    const response = await fetch(`https://script.googleapis.com/v1/projects/${scriptId}/deployments/${deploymentId}`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        deploymentConfig: {
          versionNumber: versionNumber,
          manifestFileName: 'appsscript',
          description: `Personal AI Scheduled Messages v${version}`
        }
      })
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`更新部署失败: ${error}`);
    }
    console.log('✅ 部署已更新（URL 保持不变）');
  }

  /**
   * 更新配置中的版本信息
   */
  async updateConfigVersion(version) {
    if (!this.config) {
      return;
    }
    this.config.appScriptVersion = version;
    this.config.appScriptLastUpdated = new Date().toISOString();

    // 保存到 Chrome Storage
    await this.saveConfigToStorage();

    // 同步到 Google Sheet
    await this.syncConfigToSheet();
  }

  /**
   * 保存配置到 Chrome Storage
   */
  async saveConfigToStorage() {
    if (!this.config) {
      return;
    }
    await chrome.storage.local.set({
      scheduledMessagesConfig: this.config
    });
    console.log('✅ 配置已保存到 Chrome Storage');
  }

  /**
   * 同步配置到 Google Sheet
   */
  async syncConfigToSheet() {
    try {
      const syncService = new ConfigSyncService.ConfigSyncService(this.token);
      await syncService.saveConfigToSheet(this.config);
      console.log('✅ 配置已同步到 Google Sheet');
    } catch (error) {
      console.warn('同步配置到 Sheet 失败（不影响功能）:', error);
    }
  }

  /**
   * 比较版本号
   * @returns -1: v1 < v2, 0: v1 = v2, 1: v1 > v2
   */
  compareVersions(v1, v2) {
    const parts1 = v1.split('.').map(Number);
    const parts2 = v2.split('.').map(Number);
    for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
      const num1 = parts1[i] || 0;
      const num2 = parts2[i] || 0;
      if (num1 < num2) return -1;
      if (num1 > num2) return 1;
    }
    return 0;
  }

  /**
   * 静态方法：检查并自动更新 App Script
   * 用于 background script 在扩展启动/更新时调用
   * 
   * @param getToken - 获取 Google OAuth token 的函数
   * @param options - 可选配置
   * @param options.delay - 执行前的延迟时间（毫秒），默认 3000ms
   * @param options.showNotification - 是否显示 Chrome 通知，默认 true
   */
  static async checkAndAutoUpdate(getToken) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    const {
      delay = 3000,
      showNotification = true
    } = options;
    try {
      // 延迟执行，避免与其他初始化冲突
      if (delay > 0) {
        await new Promise(resolve => setTimeout(resolve, delay));
      }

      // 从 Chrome Storage 读取配置
      const result = await chrome.storage.local.get(['scheduledMessagesConfig']);
      const config = result.scheduledMessagesConfig;
      if (!config || !config.scriptId || !config.webAppUrl) {
        console.log('⏭️ 未找到 Scheduled Messages 配置，跳过 App Script 更新检查');
        return;
      }
      console.log('✅ 找到 Scheduled Messages 配置，检查 App Script 版本...');

      // 获取 Google OAuth token
      const token = await getToken();
      if (!token) {
        console.warn('⚠️ 无法获取 Google 授权，跳过 App Script 更新');
        return;
      }

      // 创建更新器实例
      const updater = new AppScriptUpdater(token, config);

      // 检查是否需要更新
      const checkResult = await updater.checkForUpdates();
      if (!checkResult.needsUpdate) {
        console.log(`✅ App Script 已是最新版本 (${checkResult.currentVersion})`);
        return;
      }
      console.log(`🔄 发现新版本: ${checkResult.latestVersion}，当前版本: ${checkResult.currentVersion}`);
      console.log('🚀 开始自动更新 App Script...');

      // 执行更新
      const updateResult = await updater.updateAppScript();
      if (updateResult.success) {
        console.log(`✅ ${updateResult.message}`);

        // 发送成功通知
        if (showNotification) {
          chrome.notifications.create(`appscript-update-success-${Date.now()}`, {
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: 'Personal AI - App Script 已更新',
            message: `定时消息系统已自动更新到最新版本 ${updateResult.newVersion}`,
            priority: 1
          });
        }
      } else {
        console.error(`❌ App Script 更新失败: ${updateResult.error}`);

        // 发送失败通知
        if (showNotification) {
          chrome.notifications.create(`appscript-update-failed-${Date.now()}`, {
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: 'Personal AI - App Script 更新失败',
            message: '定时消息系统更新失败，请手动更新或联系管理员',
            priority: 2
          });
        }
      }
    } catch (error) {
      console.error('❌ checkAndAutoUpdate 执行失败:', error);
    }
  }
}
// 缓存版本信息，避免重复读取文件
AppScriptUpdater.cachedVersionInfo = null;
;// CONCATENATED MODULE: ./src/scheduled-messages/SheetSchemaUpdater.ts
/**
 * Sheet Schema Updater
 * 负责自动检测并更新 Google Sheet 的表结构
 * 
 * 当扩展升级新增字段时，自动为老用户的 Sheet 添加缺失的列
 */


class SheetSchemaUpdater {
  constructor(token, config) {
    this.token = token;
    this.config = config;
  }

  /**
   * 检查并自动更新表结构
   */
  async checkAndUpdate() {
    try {
      console.log('🔍 检查 Sheet 表结构...');

      // 1. 获取当前 Messages 表的表头
      const currentHeaders = await this.getMessagesHeaders();
      console.log('当前表头:', currentHeaders);

      // 2. 比对找出缺失的列
      const missingColumns = MESSAGES_SCHEMA.columns.filter(col => !currentHeaders.includes(col));
      if (missingColumns.length === 0) {
        console.log('✅ Sheet 表结构已是最新');
        return {
          success: true,
          updated: false,
          addedColumns: []
        };
      }
      console.log('📝 发现缺失的列:', missingColumns);

      // 3. 为缺失的列添加到表末尾
      await this.addMissingColumns(currentHeaders, missingColumns);

      // 4. 更新配置中的 sheet_version
      await this.updateSchemaVersion();
      console.log('✅ Sheet 表结构更新完成');
      return {
        success: true,
        updated: true,
        addedColumns: missingColumns
      };
    } catch (error) {
      console.error('❌ Sheet 表结构更新失败:', error);
      return {
        success: false,
        updated: false,
        addedColumns: [],
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * 获取 Messages 表的当前表头
   */
  async getMessagesHeaders() {
    const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${this.config.sheetId}/values/Messages!1:1`, {
      headers: {
        'Authorization': `Bearer ${this.token}`
      }
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`获取表头失败: ${error}`);
    }
    const data = await response.json();
    return data.values?.[0] || [];
  }

  /**
   * 添加缺失的列
   */
  async addMissingColumns(currentHeaders, missingColumns) {
    // 计算新列应该添加的位置（追加到末尾）
    const startColumn = this.columnIndexToLetter(currentHeaders.length);
    const endColumn = this.columnIndexToLetter(currentHeaders.length + missingColumns.length - 1);

    // 添加表头
    const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${this.config.sheetId}/values/Messages!${startColumn}1:${endColumn}1?valueInputOption=USER_ENTERED`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        values: [missingColumns]
      })
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`添加列失败: ${error}`);
    }

    // 设置新列表头的格式（蓝色背景白色加粗字）
    await this.formatNewHeaders(currentHeaders.length, missingColumns.length);
    console.log(`✅ 已添加 ${missingColumns.length} 个新列: ${missingColumns.join(', ')}`);
  }

  /**
   * 设置新表头的格式
   */
  async formatNewHeaders(startIndex, count) {
    const messagesSheetId = this.config.messagesSheetId || 0;
    const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${this.config.sheetId}:batchUpdate`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        requests: [{
          repeatCell: {
            range: {
              sheetId: messagesSheetId,
              startRowIndex: 0,
              endRowIndex: 1,
              startColumnIndex: startIndex,
              endColumnIndex: startIndex + count
            },
            cell: {
              userEnteredFormat: {
                backgroundColor: {
                  red: 0.2,
                  green: 0.5,
                  blue: 0.8
                },
                textFormat: {
                  bold: true,
                  foregroundColor: {
                    red: 1,
                    green: 1,
                    blue: 1
                  }
                }
              }
            },
            fields: 'userEnteredFormat(backgroundColor,textFormat)'
          }
        }]
      })
    });
    if (!response.ok) {
      console.warn('设置表头格式失败，但不影响功能');
    }
  }

  /**
   * 更新配置中的 schema version
   */
  async updateSchemaVersion() {
    const updatedConfig = {
      ...this.config,
      sheet_version: MESSAGES_SCHEMA.version
    };

    // 使用 ConfigSyncService 同步配置
    const {
      ConfigSyncService
    } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 8998));
    const syncService = new ConfigSyncService(this.token);
    await syncService.syncConfig(updatedConfig);
  }

  /**
   * 将列索引转换为字母（0 -> A, 1 -> B, 26 -> AA）
   */
  columnIndexToLetter(index) {
    let letter = '';
    while (index >= 0) {
      letter = String.fromCharCode(index % 26 + 65) + letter;
      index = Math.floor(index / 26) - 1;
    }
    return letter;
  }

  /**
   * 静态方法：检查并自动更新（类似 AppScriptUpdater 的接口）
   */
  static async checkAndAutoUpdate(getAuthToken, options) {
    try {
      // 获取配置
      const result = await chrome.storage.local.get(['scheduledMessagesConfig']);
      const config = result.scheduledMessagesConfig;
      if (!config || !config.sheetId) {
        console.log('未找到定时消息配置，跳过 Sheet Schema 检查');
        return {
          success: true,
          updated: false,
          addedColumns: []
        };
      }

      // 检查是否需要更新
      if (config.sheet_version === MESSAGES_SCHEMA.version) {
        console.log(`Sheet Schema 版本已是最新: ${MESSAGES_SCHEMA.version}`);
        return {
          success: true,
          updated: false,
          addedColumns: []
        };
      }
      console.log(`Sheet Schema 需要更新: ${config.sheet_version || 'unknown'} -> ${MESSAGES_SCHEMA.version}`);

      // 获取 token
      const token = await getAuthToken();

      // 执行更新
      const updater = new SheetSchemaUpdater(token, config);
      const updateResult = await updater.checkAndUpdate();

      // 显示通知
      if (options?.showNotification && updateResult.updated) {
        chrome.notifications?.create({
          type: 'basic',
          iconUrl: chrome.runtime.getURL('icons/icon128.png'),
          title: 'Sheet 表结构已更新',
          message: `已添加新列: ${updateResult.addedColumns.join(', ')}`
        });
      }
      return updateResult;
    } catch (error) {
      console.error('Sheet Schema 自动更新失败:', error);
      return {
        success: false,
        updated: false,
        addedColumns: [],
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }
}
// EXTERNAL MODULE: ./src/scheduled-messages/jira-rule-template.json
var jira_rule_template = __webpack_require__(4010);
// EXTERNAL MODULE: ./src/scheduled-messages/JiraAutomationService.ts
var JiraAutomationService = __webpack_require__(5704);
// EXTERNAL MODULE: ./src/utils.ts
var utils = __webpack_require__(3922);
;// CONCATENATED MODULE: ./src/scheduled-messages/JiraRuleUpdater.ts
/**
 * Jira Automation Rule 自动更新器
 * 负责检测和更新用户已部署的 Jira Automation 规则
 * 
 * 参考 AppScriptUpdater.ts 的架构实现
 */





class JiraRuleUpdater {
  constructor(config) {
    this.config = null;
    this.config = config || null;
    this.jiraService = new JiraAutomationService.JiraAutomationService();
  }

  /**
   * 从模板文件中解析版本信息
   */
  static parseVersionFromTemplate() {
    // 如果已经缓存，直接返回
    if (JiraRuleUpdater.cachedVersionInfo) {
      return JiraRuleUpdater.cachedVersionInfo;
    }

    // 从导入的模板中读取 _metadata
    const metadata = jira_rule_template._metadata;
    if (metadata && metadata.version) {
      const versionInfo = {
        version: metadata.version,
        lastUpdated: metadata.lastUpdated || new Date().toISOString().split('T')[0]
      };

      // 缓存结果
      JiraRuleUpdater.cachedVersionInfo = versionInfo;
      console.log(`📦 从模板文件解析到 Jira Rule 版本信息: ${versionInfo.version} (${versionInfo.lastUpdated})`);
      return versionInfo;
    }

    // 回退到常量版本（从 JiraAutomationService 导出）
    const fallbackVersion = {
      version: JiraAutomationService/* JIRA_RULE_VERSION */.l,
      lastUpdated: JiraAutomationService/* JIRA_RULE_LAST_UPDATED */.H
    };
    JiraRuleUpdater.cachedVersionInfo = fallbackVersion;
    return fallbackVersion;
  }

  /**
   * 获取最新的 Jira Rule 版本号
   */
  static getLatestVersion() {
    const versionInfo = JiraRuleUpdater.parseVersionFromTemplate();
    return versionInfo.version;
  }

  /**
   * 获取最新的更新日期
   */
  static getLatestUpdateDate() {
    const versionInfo = JiraRuleUpdater.parseVersionFromTemplate();
    return versionInfo.lastUpdated;
  }

  /**
   * 检查是否需要更新
   */
  async checkForUpdates() {
    try {
      // 获取最新版本号
      const latestVersion = JiraRuleUpdater.getLatestVersion();
      if (!this.config?.botExecutor?.ruleId || !this.config?.botExecutor?.jiraUrl) {
        return {
          needsUpdate: false,
          currentVersion: 'unknown',
          latestVersion,
          error: '未找到 Bot Executor 配置'
        };
      }

      // 从已部署规则获取当前版本
      const currentVersion = await this.getDeployedVersion();

      // 比较版本
      const needsUpdate = this.compareVersions(currentVersion, latestVersion) < 0;
      return {
        needsUpdate,
        currentVersion,
        latestVersion
      };
    } catch (error) {
      console.error('检查 Jira Rule 更新失败:', error);
      const latestVersion = JiraRuleUpdater.getLatestVersion();
      return {
        needsUpdate: false,
        currentVersion: 'unknown',
        latestVersion,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * 获取已部署的 Jira Rule 版本
   * 通过解析规则名称中的版本号获取
   */
  async getDeployedVersion() {
    if (!this.config?.botExecutor?.ruleId || !this.config?.botExecutor?.jiraUrl) {
      throw new Error('未找到 Bot Executor 配置');
    }
    const jiraConfig = {
      jiraUrl: this.config.botExecutor.jiraUrl,
      projectKey: this.config.botExecutor.projectKey
    };
    try {
      // 获取规则详情
      const rule = await this.jiraService.getRuleById(jiraConfig, this.config.botExecutor.ruleId);
      if (!rule) {
        console.warn('⚠️ 无法获取规则详情，可能规则已被删除');
        return '0.0.0';
      }

      // 从规则名称解析版本号
      const version = JiraAutomationService.JiraAutomationService.parseVersionFromRuleName(rule.name);
      if (version) {
        console.log(`📋 已部署规则版本: ${version}`);
        return version;
      }

      // 如果名称中没有版本号，尝试从配置中读取
      if (this.config.botExecutor.ruleVersion) {
        console.log(`📋 从配置读取规则版本: ${this.config.botExecutor.ruleVersion}`);
        return this.config.botExecutor.ruleVersion;
      }

      // 如果都没有，返回 0.0.0 表示旧版本
      console.warn('⚠️ 无法解析规则版本，假定为旧版本 (0.0.0)');
      return '0.0.0';
    } catch (error) {
      console.warn('获取已部署版本失败:', error);
      return '0.0.0';
    }
  }

  /**
   * 执行更新
   * 使用 PUT API 更新现有规则，保持 Rule ID 不变
   */
  async updateJiraRule() {
    try {
      if (!this.config?.botExecutor?.ruleId || !this.config?.botExecutor?.jiraUrl) {
        return {
          success: false,
          message: '未找到 Bot Executor 配置',
          error: 'BOT_EXECUTOR_NOT_FOUND'
        };
      }
      console.log('🔄 开始更新 Jira Automation Rule...');

      // 0. 获取最新版本号
      const latestVersion = JiraRuleUpdater.getLatestVersion();

      // 1. 准备 Jira 配置
      const jiraConfig = {
        jiraUrl: this.config.botExecutor.jiraUrl,
        projectKey: this.config.botExecutor.projectKey
      };

      // 2. 获取现有规则
      const existingRule = await this.jiraService.getRuleById(jiraConfig, this.config.botExecutor.ruleId);
      if (!existingRule) {
        return {
          success: false,
          message: '规则不存在或已被删除',
          error: 'RULE_NOT_FOUND'
        };
      }

      // 3. 准备新的规则 payload
      const newRulePayload = await this.prepareRulePayload(existingRule);

      // 4. 调用更新 API
      const updatedRule = await this.jiraService.updateRule(jiraConfig, this.config.botExecutor.ruleId, newRulePayload);

      // 5. 更新配置中的版本信息
      await this.updateConfigVersion(latestVersion, updatedRule.name);
      console.log('✅ Jira Automation Rule 更新成功！');
      return {
        success: true,
        message: `Jira Rule 已更新到版本 ${latestVersion}`,
        newVersion: latestVersion
      };
    } catch (error) {
      console.error('❌ 更新 Jira Rule 失败:', error);
      return {
        success: false,
        message: '更新失败',
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * 准备规则 payload
   * 从模板创建新的规则内容，替换占位符
   */
  async prepareRulePayload(existingRule) {
    // 获取环境配置
    const envConfig = await (0,utils/* getEnvConfig */.Un)();
    const {
      userinfo
    } = await chrome.storage.local.get('userinfo');

    // 保持原有的规则名称前缀（用户名部分）
    const nameMatch = existingRule.name.match(/^\[([^\]]+)\]/);
    const userName = nameMatch ? nameMatch[1] : userinfo?.fullName?.split(' ')[0] || 'User';
    const ruleName = `[${userName}] Scheduled Messages`;

    // 获取 Web App URL
    const webAppUrl = this.config?.webAppUrl || this.config?.botExecutor?.webhookUrl || '';

    // 从模板创建规则 payload
    const templateString = JSON.stringify(jira_rule_template);
    const rulePayloadString = templateString.replace(/{{RULE_NAME}}/g, ruleName).replace(/{{RULE_VERSION}}/g, JiraRuleUpdater.getLatestVersion()).replace(/{{WEB_APP_URL}}/g, webAppUrl).replace(/{{BOT_API_BASE_URL}}/g, envConfig.BOT_API_BASE_URL).replace(/{{BOT_TOKEN}}/g, envConfig.BOT_TOKEN).replace(/{{BOT_ID}}/g, envConfig.BOT_ID).replace(/{{USER_EMAIL}}/g, userinfo?.userEmail || '').replace(/{{PROJECT_KEY}}/g, this.config?.botExecutor?.projectKey || '').replace(/{{PROJECT_ID}}/g, String(existingRule.projects?.[0]?.projectId || '')).replace(/{{USER_KEY}}/g, existingRule.authorAccountId || '');
    const rulePayload = JSON.parse(rulePayloadString);

    // 移除 _metadata 字段（这是模板内部使用的，不应发送到 Jira）
    delete rulePayload._metadata;
    return rulePayload;
  }

  /**
   * 更新配置中的版本信息
   */
  async updateConfigVersion(version, ruleName) {
    if (!this.config || !this.config.botExecutor) {
      return;
    }
    this.config.botExecutor.ruleVersion = version;
    this.config.botExecutor.ruleLastUpdated = new Date().toISOString();
    this.config.botExecutor.ruleName = ruleName;

    // 保存到 Chrome Storage
    await this.saveConfigToStorage();

    // 尝试同步到 Google Sheet（不阻塞）
    this.syncConfigToSheet().catch(err => {
      console.warn('同步配置到 Sheet 失败（不影响功能）:', err);
    });
  }

  /**
   * 保存配置到 Chrome Storage
   */
  async saveConfigToStorage() {
    if (!this.config) {
      return;
    }
    await chrome.storage.local.set({
      scheduledMessagesConfig: this.config
    });
    console.log('✅ 配置已保存到 Chrome Storage');
  }

  /**
   * 同步配置到 Google Sheet
   */
  async syncConfigToSheet() {
    try {
      // 获取 Google token
      const token = await new Promise((resolve, reject) => {
        chrome.identity.getAuthToken({
          interactive: false
        }, token => {
          if (chrome.runtime.lastError || !token) {
            reject(new Error(chrome.runtime.lastError?.message || 'No token'));
          } else {
            resolve(token);
          }
        });
      });
      const syncService = new ConfigSyncService.ConfigSyncService(token);
      await syncService.saveConfigToSheet(this.config);
      console.log('✅ 配置已同步到 Google Sheet');
    } catch (error) {
      console.warn('同步配置到 Sheet 失败:', error);
    }
  }

  /**
   * 比较版本号
   * @returns -1: v1 < v2, 0: v1 = v2, 1: v1 > v2
   */
  compareVersions(v1, v2) {
    const parts1 = v1.split('.').map(Number);
    const parts2 = v2.split('.').map(Number);
    for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
      const num1 = parts1[i] || 0;
      const num2 = parts2[i] || 0;
      if (num1 < num2) return -1;
      if (num1 > num2) return 1;
    }
    return 0;
  }

  /**
   * 静态方法：检查并自动更新 Jira Rule
   * 用于 background script 在扩展启动/更新时调用
   * 
   * @param getToken - 获取 Google OAuth token 的函数（可选，用于同步配置）
   * @param options - 可选配置
   * @param options.delay - 执行前的延迟时间（毫秒），默认 5000ms
   * @param options.showNotification - 是否显示 Chrome 通知，默认 true
   */
  static async checkAndAutoUpdate(getToken) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    const {
      delay = 5000,
      showNotification = true
    } = options;
    try {
      // 延迟执行，避免与其他初始化冲突
      if (delay > 0) {
        await new Promise(resolve => setTimeout(resolve, delay));
      }

      // 从 Chrome Storage 读取配置
      const result = await chrome.storage.local.get(['scheduledMessagesConfig']);
      const config = result.scheduledMessagesConfig;
      if (!config || !config.botExecutor?.ruleId || !config.botExecutor?.jiraUrl) {
        console.log('⏭️ 未找到 Jira Bot Executor 配置，跳过 Jira Rule 更新检查');
        return;
      }
      console.log('✅ 找到 Bot Executor 配置，检查 Jira Rule 版本...');

      // 创建更新器实例
      const updater = new JiraRuleUpdater(config);

      // 检查是否需要更新
      const checkResult = await updater.checkForUpdates();
      if (checkResult.error) {
        console.warn(`⚠️ 检查 Jira Rule 更新时出错: ${checkResult.error}`);
        return;
      }
      if (!checkResult.needsUpdate) {
        console.log(`✅ Jira Rule 已是最新版本 (${checkResult.currentVersion})`);
        return;
      }
      console.log(`🔄 发现新版本: ${checkResult.latestVersion}，当前版本: ${checkResult.currentVersion}`);
      console.log('🚀 开始自动更新 Jira Rule...');

      // 执行更新
      const updateResult = await updater.updateJiraRule();
      if (updateResult.success) {
        console.log(`✅ ${updateResult.message}`);

        // 发送成功通知
        if (showNotification) {
          chrome.notifications.create(`jira-rule-update-success-${Date.now()}`, {
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: 'Personal AI - Jira Rule 已更新',
            message: `定时消息 Bot 规则已自动更新到最新版本 ${updateResult.newVersion}`,
            priority: 1
          });
        }
      } else {
        console.error(`❌ Jira Rule 更新失败: ${updateResult.error}`);

        // 发送失败通知
        if (showNotification) {
          chrome.notifications.create(`jira-rule-update-failed-${Date.now()}`, {
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: 'Personal AI - Jira Rule 更新失败',
            message: '定时消息 Bot 规则更新失败，请手动检查或重新配置',
            priority: 2
          });
        }
      }
    } catch (error) {
      console.error('❌ checkAndAutoUpdate 执行失败:', error);
    }
  }
}
// 缓存版本信息，避免重复读取
JiraRuleUpdater.cachedVersionInfo = null;
;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/typeof.js
function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/toPrimitive.js

function toPrimitive(t, r) {
  if ("object" != _typeof(t) || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != _typeof(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/toPropertyKey.js


function toPropertyKey(t) {
  var i = toPrimitive(t, "string");
  return "symbol" == _typeof(i) ? i : i + "";
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/defineProperty.js

function _defineProperty(e, r, t) {
  return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[r] = t, e;
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js

function ownKeys(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e);
    r && (o = o.filter(function (r) {
      return Object.getOwnPropertyDescriptor(e, r).enumerable;
    })), t.push.apply(t, o);
  }
  return t;
}
function objectSpread2_objectSpread2(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = null != arguments[r] ? arguments[r] : {};
    r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
      _defineProperty(e, r, t[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
      Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
    });
  }
  return e;
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/arrayWithHoles.js
function _arrayWithHoles(r) {
  if (Array.isArray(r)) return r;
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/iterableToArrayLimit.js
function _iterableToArrayLimit(r, l) {
  var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (null != t) {
    var e,
      n,
      i,
      u,
      a = [],
      f = !0,
      o = !1;
    try {
      if (i = (t = t.call(r)).next, 0 === l) {
        if (Object(t) !== t) return;
        f = !1;
      } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
    } catch (r) {
      o = !0, n = r;
    } finally {
      try {
        if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
      } finally {
        if (o) throw n;
      }
    }
    return a;
  }
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js

function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/nonIterableRest.js
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js




function _slicedToArray(r, e) {
  return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js
function _objectWithoutPropertiesLoose(r, e) {
  if (null == r) return {};
  var t = {};
  for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
    if (-1 !== e.indexOf(n)) continue;
    t[n] = r[n];
  }
  return t;
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js

function _objectWithoutProperties(e, t) {
  if (null == e) return {};
  var o,
    r,
    i = _objectWithoutPropertiesLoose(e, t);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
  }
  return i;
}

;// CONCATENATED MODULE: ./node_modules/react-select/dist/useStateManager-7e1e8489.esm.js





var _excluded = ["defaultInputValue", "defaultMenuIsOpen", "defaultValue", "inputValue", "menuIsOpen", "onChange", "onInputChange", "onMenuClose", "onMenuOpen", "value"];
function useStateManager(_ref) {
  var _ref$defaultInputValu = _ref.defaultInputValue,
    defaultInputValue = _ref$defaultInputValu === void 0 ? '' : _ref$defaultInputValu,
    _ref$defaultMenuIsOpe = _ref.defaultMenuIsOpen,
    defaultMenuIsOpen = _ref$defaultMenuIsOpe === void 0 ? false : _ref$defaultMenuIsOpe,
    _ref$defaultValue = _ref.defaultValue,
    defaultValue = _ref$defaultValue === void 0 ? null : _ref$defaultValue,
    propsInputValue = _ref.inputValue,
    propsMenuIsOpen = _ref.menuIsOpen,
    propsOnChange = _ref.onChange,
    propsOnInputChange = _ref.onInputChange,
    propsOnMenuClose = _ref.onMenuClose,
    propsOnMenuOpen = _ref.onMenuOpen,
    propsValue = _ref.value,
    restSelectProps = _objectWithoutProperties(_ref, _excluded);
  var _useState = (0,react.useState)(propsInputValue !== undefined ? propsInputValue : defaultInputValue),
    _useState2 = _slicedToArray(_useState, 2),
    stateInputValue = _useState2[0],
    setStateInputValue = _useState2[1];
  var _useState3 = (0,react.useState)(propsMenuIsOpen !== undefined ? propsMenuIsOpen : defaultMenuIsOpen),
    _useState4 = _slicedToArray(_useState3, 2),
    stateMenuIsOpen = _useState4[0],
    setStateMenuIsOpen = _useState4[1];
  var _useState5 = (0,react.useState)(propsValue !== undefined ? propsValue : defaultValue),
    _useState6 = _slicedToArray(_useState5, 2),
    stateValue = _useState6[0],
    setStateValue = _useState6[1];
  var onChange = (0,react.useCallback)(function (value, actionMeta) {
    if (typeof propsOnChange === 'function') {
      propsOnChange(value, actionMeta);
    }
    setStateValue(value);
  }, [propsOnChange]);
  var onInputChange = (0,react.useCallback)(function (value, actionMeta) {
    var newValue;
    if (typeof propsOnInputChange === 'function') {
      newValue = propsOnInputChange(value, actionMeta);
    }
    setStateInputValue(newValue !== undefined ? newValue : value);
  }, [propsOnInputChange]);
  var onMenuOpen = (0,react.useCallback)(function () {
    if (typeof propsOnMenuOpen === 'function') {
      propsOnMenuOpen();
    }
    setStateMenuIsOpen(true);
  }, [propsOnMenuOpen]);
  var onMenuClose = (0,react.useCallback)(function () {
    if (typeof propsOnMenuClose === 'function') {
      propsOnMenuClose();
    }
    setStateMenuIsOpen(false);
  }, [propsOnMenuClose]);
  var inputValue = propsInputValue !== undefined ? propsInputValue : stateInputValue;
  var menuIsOpen = propsMenuIsOpen !== undefined ? propsMenuIsOpen : stateMenuIsOpen;
  var value = propsValue !== undefined ? propsValue : stateValue;
  return objectSpread2_objectSpread2(objectSpread2_objectSpread2({}, restSelectProps), {}, {
    inputValue: inputValue,
    menuIsOpen: menuIsOpen,
    onChange: onChange,
    onInputChange: onInputChange,
    onMenuClose: onMenuClose,
    onMenuOpen: onMenuOpen,
    value: value
  });
}



;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/extends.js
function extends_extends() {
  return extends_extends = Object.assign ? Object.assign.bind() : function (n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, extends_extends.apply(null, arguments);
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js
function _classCallCheck(a, n) {
  if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/createClass.js

function _defineProperties(e, r) {
  for (var t = 0; t < r.length; t++) {
    var o = r[t];
    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, toPropertyKey(o.key), o);
  }
}
function _createClass(e, r, t) {
  return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", {
    writable: !1
  }), e;
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/setPrototypeOf.js
function _setPrototypeOf(t, e) {
  return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) {
    return t.__proto__ = e, t;
  }, _setPrototypeOf(t, e);
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/inherits.js

function _inherits(t, e) {
  if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
  t.prototype = Object.create(e && e.prototype, {
    constructor: {
      value: t,
      writable: !0,
      configurable: !0
    }
  }), Object.defineProperty(t, "prototype", {
    writable: !1
  }), e && _setPrototypeOf(t, e);
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js
function _getPrototypeOf(t) {
  return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) {
    return t.__proto__ || Object.getPrototypeOf(t);
  }, _getPrototypeOf(t);
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/isNativeReflectConstruct.js
function _isNativeReflectConstruct() {
  try {
    var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
  } catch (t) {}
  return (_isNativeReflectConstruct = function _isNativeReflectConstruct() {
    return !!t;
  })();
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js
function _assertThisInitialized(e) {
  if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js


function _possibleConstructorReturn(t, e) {
  if (e && ("object" == _typeof(e) || "function" == typeof e)) return e;
  if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
  return _assertThisInitialized(t);
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/createSuper.js



function _createSuper(t) {
  var r = _isNativeReflectConstruct();
  return function () {
    var e,
      o = _getPrototypeOf(t);
    if (r) {
      var s = _getPrototypeOf(this).constructor;
      e = Reflect.construct(o, arguments, s);
    } else e = o.apply(this, arguments);
    return _possibleConstructorReturn(this, e);
  };
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js

function _arrayWithoutHoles(r) {
  if (Array.isArray(r)) return _arrayLikeToArray(r);
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/iterableToArray.js
function _iterableToArray(r) {
  if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js
function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js




function _toConsumableArray(r) {
  return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
}

;// CONCATENATED MODULE: ./node_modules/@emotion/sheet/dist/emotion-sheet.esm.js
var emotion_sheet_esm_isDevelopment = false;

/*

Based off glamor's StyleSheet, thanks Sunil ❤️

high performance StyleSheet for css-in-js systems

- uses multiple style tags behind the scenes for millions of rules
- uses `insertRule` for appending in production for *much* faster performance

// usage

import { StyleSheet } from '@emotion/sheet'

let styleSheet = new StyleSheet({ key: '', container: document.head })

styleSheet.insert('#box { border: 1px solid red; }')
- appends a css rule into the stylesheet

styleSheet.flush()
- empties the stylesheet of all its contents

*/

function sheetForTag(tag) {
  if (tag.sheet) {
    return tag.sheet;
  } // this weirdness brought to you by firefox

  /* istanbul ignore next */


  for (var i = 0; i < document.styleSheets.length; i++) {
    if (document.styleSheets[i].ownerNode === tag) {
      return document.styleSheets[i];
    }
  } // this function should always return with a value
  // TS can't understand it though so we make it stop complaining here


  return undefined;
}

function createStyleElement(options) {
  var tag = document.createElement('style');
  tag.setAttribute('data-emotion', options.key);

  if (options.nonce !== undefined) {
    tag.setAttribute('nonce', options.nonce);
  }

  tag.appendChild(document.createTextNode(''));
  tag.setAttribute('data-s', '');
  return tag;
}

var StyleSheet = /*#__PURE__*/function () {
  // Using Node instead of HTMLElement since container may be a ShadowRoot
  function StyleSheet(options) {
    var _this = this;

    this._insertTag = function (tag) {
      var before;

      if (_this.tags.length === 0) {
        if (_this.insertionPoint) {
          before = _this.insertionPoint.nextSibling;
        } else if (_this.prepend) {
          before = _this.container.firstChild;
        } else {
          before = _this.before;
        }
      } else {
        before = _this.tags[_this.tags.length - 1].nextSibling;
      }

      _this.container.insertBefore(tag, before);

      _this.tags.push(tag);
    };

    this.isSpeedy = options.speedy === undefined ? !emotion_sheet_esm_isDevelopment : options.speedy;
    this.tags = [];
    this.ctr = 0;
    this.nonce = options.nonce; // key is the value of the data-emotion attribute, it's used to identify different sheets

    this.key = options.key;
    this.container = options.container;
    this.prepend = options.prepend;
    this.insertionPoint = options.insertionPoint;
    this.before = null;
  }

  var _proto = StyleSheet.prototype;

  _proto.hydrate = function hydrate(nodes) {
    nodes.forEach(this._insertTag);
  };

  _proto.insert = function insert(rule) {
    // the max length is how many rules we have per style tag, it's 65000 in speedy mode
    // it's 1 in dev because we insert source maps that map a single rule to a location
    // and you can only have one source map per style tag
    if (this.ctr % (this.isSpeedy ? 65000 : 1) === 0) {
      this._insertTag(createStyleElement(this));
    }

    var tag = this.tags[this.tags.length - 1];

    if (this.isSpeedy) {
      var sheet = sheetForTag(tag);

      try {
        // this is the ultrafast version, works across browsers
        // the big drawback is that the css won't be editable in devtools
        sheet.insertRule(rule, sheet.cssRules.length);
      } catch (e) {
      }
    } else {
      tag.appendChild(document.createTextNode(rule));
    }

    this.ctr++;
  };

  _proto.flush = function flush() {
    this.tags.forEach(function (tag) {
      var _tag$parentNode;

      return (_tag$parentNode = tag.parentNode) == null ? void 0 : _tag$parentNode.removeChild(tag);
    });
    this.tags = [];
    this.ctr = 0;
  };

  return StyleSheet;
}();



;// CONCATENATED MODULE: ./node_modules/stylis/src/Utility.js
/**
 * @param {number}
 * @return {number}
 */
var abs = Math.abs

/**
 * @param {number}
 * @return {string}
 */
var Utility_from = String.fromCharCode

/**
 * @param {object}
 * @return {object}
 */
var Utility_assign = Object.assign

/**
 * @param {string} value
 * @param {number} length
 * @return {number}
 */
function hash (value, length) {
	return Utility_charat(value, 0) ^ 45 ? (((((((length << 2) ^ Utility_charat(value, 0)) << 2) ^ Utility_charat(value, 1)) << 2) ^ Utility_charat(value, 2)) << 2) ^ Utility_charat(value, 3) : 0
}

/**
 * @param {string} value
 * @return {string}
 */
function trim (value) {
	return value.trim()
}

/**
 * @param {string} value
 * @param {RegExp} pattern
 * @return {string?}
 */
function Utility_match (value, pattern) {
	return (value = pattern.exec(value)) ? value[0] : value
}

/**
 * @param {string} value
 * @param {(string|RegExp)} pattern
 * @param {string} replacement
 * @return {string}
 */
function Utility_replace (value, pattern, replacement) {
	return value.replace(pattern, replacement)
}

/**
 * @param {string} value
 * @param {string} search
 * @return {number}
 */
function indexof (value, search) {
	return value.indexOf(search)
}

/**
 * @param {string} value
 * @param {number} index
 * @return {number}
 */
function Utility_charat (value, index) {
	return value.charCodeAt(index) | 0
}

/**
 * @param {string} value
 * @param {number} begin
 * @param {number} end
 * @return {string}
 */
function Utility_substr (value, begin, end) {
	return value.slice(begin, end)
}

/**
 * @param {string} value
 * @return {number}
 */
function Utility_strlen (value) {
	return value.length
}

/**
 * @param {any[]} value
 * @return {number}
 */
function Utility_sizeof (value) {
	return value.length
}

/**
 * @param {any} value
 * @param {any[]} array
 * @return {any}
 */
function Utility_append (value, array) {
	return array.push(value), value
}

/**
 * @param {string[]} array
 * @param {function} callback
 * @return {string}
 */
function Utility_combine (array, callback) {
	return array.map(callback).join('')
}

;// CONCATENATED MODULE: ./node_modules/stylis/src/Tokenizer.js


var line = 1
var column = 1
var Tokenizer_length = 0
var position = 0
var character = 0
var characters = ''

/**
 * @param {string} value
 * @param {object | null} root
 * @param {object | null} parent
 * @param {string} type
 * @param {string[] | string} props
 * @param {object[] | string} children
 * @param {number} length
 */
function node (value, root, parent, type, props, children, length) {
	return {value: value, root: root, parent: parent, type: type, props: props, children: children, line: line, column: column, length: length, return: ''}
}

/**
 * @param {object} root
 * @param {object} props
 * @return {object}
 */
function Tokenizer_copy (root, props) {
	return Utility_assign(node('', null, null, '', null, null, 0), root, {length: -root.length}, props)
}

/**
 * @return {number}
 */
function Tokenizer_char () {
	return character
}

/**
 * @return {number}
 */
function prev () {
	character = position > 0 ? Utility_charat(characters, --position) : 0

	if (column--, character === 10)
		column = 1, line--

	return character
}

/**
 * @return {number}
 */
function next () {
	character = position < Tokenizer_length ? Utility_charat(characters, position++) : 0

	if (column++, character === 10)
		column = 1, line++

	return character
}

/**
 * @return {number}
 */
function peek () {
	return Utility_charat(characters, position)
}

/**
 * @return {number}
 */
function caret () {
	return position
}

/**
 * @param {number} begin
 * @param {number} end
 * @return {string}
 */
function slice (begin, end) {
	return Utility_substr(characters, begin, end)
}

/**
 * @param {number} type
 * @return {number}
 */
function token (type) {
	switch (type) {
		// \0 \t \n \r \s whitespace token
		case 0: case 9: case 10: case 13: case 32:
			return 5
		// ! + , / > @ ~ isolate token
		case 33: case 43: case 44: case 47: case 62: case 64: case 126:
		// ; { } breakpoint token
		case 59: case 123: case 125:
			return 4
		// : accompanied token
		case 58:
			return 3
		// " ' ( [ opening delimit token
		case 34: case 39: case 40: case 91:
			return 2
		// ) ] closing delimit token
		case 41: case 93:
			return 1
	}

	return 0
}

/**
 * @param {string} value
 * @return {any[]}
 */
function alloc (value) {
	return line = column = 1, Tokenizer_length = Utility_strlen(characters = value), position = 0, []
}

/**
 * @param {any} value
 * @return {any}
 */
function dealloc (value) {
	return characters = '', value
}

/**
 * @param {number} type
 * @return {string}
 */
function delimit (type) {
	return trim(slice(position - 1, delimiter(type === 91 ? type + 2 : type === 40 ? type + 1 : type)))
}

/**
 * @param {string} value
 * @return {string[]}
 */
function Tokenizer_tokenize (value) {
	return dealloc(tokenizer(alloc(value)))
}

/**
 * @param {number} type
 * @return {string}
 */
function whitespace (type) {
	while (character = peek())
		if (character < 33)
			next()
		else
			break

	return token(type) > 2 || token(character) > 3 ? '' : ' '
}

/**
 * @param {string[]} children
 * @return {string[]}
 */
function tokenizer (children) {
	while (next())
		switch (token(character)) {
			case 0: append(identifier(position - 1), children)
				break
			case 2: append(delimit(character), children)
				break
			default: append(from(character), children)
		}

	return children
}

/**
 * @param {number} index
 * @param {number} count
 * @return {string}
 */
function escaping (index, count) {
	while (--count && next())
		// not 0-9 A-F a-f
		if (character < 48 || character > 102 || (character > 57 && character < 65) || (character > 70 && character < 97))
			break

	return slice(index, caret() + (count < 6 && peek() == 32 && next() == 32))
}

/**
 * @param {number} type
 * @return {number}
 */
function delimiter (type) {
	while (next())
		switch (character) {
			// ] ) " '
			case type:
				return position
			// " '
			case 34: case 39:
				if (type !== 34 && type !== 39)
					delimiter(character)
				break
			// (
			case 40:
				if (type === 41)
					delimiter(type)
				break
			// \
			case 92:
				next()
				break
		}

	return position
}

/**
 * @param {number} type
 * @param {number} index
 * @return {number}
 */
function commenter (type, index) {
	while (next())
		// //
		if (type + character === 47 + 10)
			break
		// /*
		else if (type + character === 42 + 42 && peek() === 47)
			break

	return '/*' + slice(index, position - 1) + '*' + Utility_from(type === 47 ? type : next())
}

/**
 * @param {number} index
 * @return {string}
 */
function identifier (index) {
	while (!token(peek()))
		next()

	return slice(index, position)
}

;// CONCATENATED MODULE: ./node_modules/stylis/src/Enum.js
var Enum_MS = '-ms-'
var Enum_MOZ = '-moz-'
var Enum_WEBKIT = '-webkit-'

var COMMENT = 'comm'
var Enum_RULESET = 'rule'
var Enum_DECLARATION = 'decl'

var PAGE = '@page'
var MEDIA = '@media'
var IMPORT = '@import'
var CHARSET = '@charset'
var VIEWPORT = '@viewport'
var SUPPORTS = '@supports'
var DOCUMENT = '@document'
var NAMESPACE = '@namespace'
var Enum_KEYFRAMES = '@keyframes'
var FONT_FACE = '@font-face'
var COUNTER_STYLE = '@counter-style'
var FONT_FEATURE_VALUES = '@font-feature-values'
var LAYER = '@layer'

;// CONCATENATED MODULE: ./node_modules/stylis/src/Serializer.js



/**
 * @param {object[]} children
 * @param {function} callback
 * @return {string}
 */
function Serializer_serialize (children, callback) {
	var output = ''
	var length = Utility_sizeof(children)

	for (var i = 0; i < length; i++)
		output += callback(children[i], i, children, callback) || ''

	return output
}

/**
 * @param {object} element
 * @param {number} index
 * @param {object[]} children
 * @param {function} callback
 * @return {string}
 */
function stringify (element, index, children, callback) {
	switch (element.type) {
		case LAYER: if (element.children.length) break
		case IMPORT: case Enum_DECLARATION: return element.return = element.return || element.value
		case COMMENT: return ''
		case Enum_KEYFRAMES: return element.return = element.value + '{' + Serializer_serialize(element.children, callback) + '}'
		case Enum_RULESET: element.value = element.props.join(',')
	}

	return Utility_strlen(children = Serializer_serialize(element.children, callback)) ? element.return = element.value + '{' + children + '}' : ''
}

;// CONCATENATED MODULE: ./node_modules/stylis/src/Middleware.js






/**
 * @param {function[]} collection
 * @return {function}
 */
function middleware (collection) {
	var length = Utility_sizeof(collection)

	return function (element, index, children, callback) {
		var output = ''

		for (var i = 0; i < length; i++)
			output += collection[i](element, index, children, callback) || ''

		return output
	}
}

/**
 * @param {function} callback
 * @return {function}
 */
function rulesheet (callback) {
	return function (element) {
		if (!element.root)
			if (element = element.return)
				callback(element)
	}
}

/**
 * @param {object} element
 * @param {number} index
 * @param {object[]} children
 * @param {function} callback
 */
function prefixer (element, index, children, callback) {
	if (element.length > -1)
		if (!element.return)
			switch (element.type) {
				case DECLARATION: element.return = prefix(element.value, element.length, children)
					return
				case KEYFRAMES:
					return serialize([copy(element, {value: replace(element.value, '@', '@' + WEBKIT)})], callback)
				case RULESET:
					if (element.length)
						return combine(element.props, function (value) {
							switch (match(value, /(::plac\w+|:read-\w+)/)) {
								// :read-(only|write)
								case ':read-only': case ':read-write':
									return serialize([copy(element, {props: [replace(value, /:(read-\w+)/, ':' + MOZ + '$1')]})], callback)
								// :placeholder
								case '::placeholder':
									return serialize([
										copy(element, {props: [replace(value, /:(plac\w+)/, ':' + WEBKIT + 'input-$1')]}),
										copy(element, {props: [replace(value, /:(plac\w+)/, ':' + MOZ + '$1')]}),
										copy(element, {props: [replace(value, /:(plac\w+)/, MS + 'input-$1')]})
									], callback)
							}

							return ''
						})
			}
}

/**
 * @param {object} element
 * @param {number} index
 * @param {object[]} children
 */
function namespace (element) {
	switch (element.type) {
		case RULESET:
			element.props = element.props.map(function (value) {
				return combine(tokenize(value), function (value, index, children) {
					switch (charat(value, 0)) {
						// \f
						case 12:
							return substr(value, 1, strlen(value))
						// \0 ( + > ~
						case 0: case 40: case 43: case 62: case 126:
							return value
						// :
						case 58:
							if (children[++index] === 'global')
								children[index] = '', children[++index] = '\f' + substr(children[index], index = 1, -1)
						// \s
						case 32:
							return index === 1 ? '' : value
						default:
							switch (index) {
								case 0: element = value
									return sizeof(children) > 1 ? '' : value
								case index = sizeof(children) - 1: case 2:
									return index === 2 ? value + element + element : value + element
								default:
									return value
							}
					}
				})
			})
	}
}

;// CONCATENATED MODULE: ./node_modules/stylis/src/Parser.js




/**
 * @param {string} value
 * @return {object[]}
 */
function compile (value) {
	return dealloc(parse('', null, null, null, [''], value = alloc(value), 0, [0], value))
}

/**
 * @param {string} value
 * @param {object} root
 * @param {object?} parent
 * @param {string[]} rule
 * @param {string[]} rules
 * @param {string[]} rulesets
 * @param {number[]} pseudo
 * @param {number[]} points
 * @param {string[]} declarations
 * @return {object}
 */
function parse (value, root, parent, rule, rules, rulesets, pseudo, points, declarations) {
	var index = 0
	var offset = 0
	var length = pseudo
	var atrule = 0
	var property = 0
	var previous = 0
	var variable = 1
	var scanning = 1
	var ampersand = 1
	var character = 0
	var type = ''
	var props = rules
	var children = rulesets
	var reference = rule
	var characters = type

	while (scanning)
		switch (previous = character, character = next()) {
			// (
			case 40:
				if (previous != 108 && Utility_charat(characters, length - 1) == 58) {
					if (indexof(characters += Utility_replace(delimit(character), '&', '&\f'), '&\f') != -1)
						ampersand = -1
					break
				}
			// " ' [
			case 34: case 39: case 91:
				characters += delimit(character)
				break
			// \t \n \r \s
			case 9: case 10: case 13: case 32:
				characters += whitespace(previous)
				break
			// \
			case 92:
				characters += escaping(caret() - 1, 7)
				continue
			// /
			case 47:
				switch (peek()) {
					case 42: case 47:
						Utility_append(comment(commenter(next(), caret()), root, parent), declarations)
						break
					default:
						characters += '/'
				}
				break
			// {
			case 123 * variable:
				points[index++] = Utility_strlen(characters) * ampersand
			// } ; \0
			case 125 * variable: case 59: case 0:
				switch (character) {
					// \0 }
					case 0: case 125: scanning = 0
					// ;
					case 59 + offset: if (ampersand == -1) characters = Utility_replace(characters, /\f/g, '')
						if (property > 0 && (Utility_strlen(characters) - length))
							Utility_append(property > 32 ? declaration(characters + ';', rule, parent, length - 1) : declaration(Utility_replace(characters, ' ', '') + ';', rule, parent, length - 2), declarations)
						break
					// @ ;
					case 59: characters += ';'
					// { rule/at-rule
					default:
						Utility_append(reference = ruleset(characters, root, parent, index, offset, rules, points, type, props = [], children = [], length), rulesets)

						if (character === 123)
							if (offset === 0)
								parse(characters, root, reference, reference, props, rulesets, length, points, children)
							else
								switch (atrule === 99 && Utility_charat(characters, 3) === 110 ? 100 : atrule) {
									// d l m s
									case 100: case 108: case 109: case 115:
										parse(value, reference, reference, rule && Utility_append(ruleset(value, reference, reference, 0, 0, rules, points, type, rules, props = [], length), children), rules, children, length, points, rule ? props : children)
										break
									default:
										parse(characters, reference, reference, reference, [''], children, 0, points, children)
								}
				}

				index = offset = property = 0, variable = ampersand = 1, type = characters = '', length = pseudo
				break
			// :
			case 58:
				length = 1 + Utility_strlen(characters), property = previous
			default:
				if (variable < 1)
					if (character == 123)
						--variable
					else if (character == 125 && variable++ == 0 && prev() == 125)
						continue

				switch (characters += Utility_from(character), character * variable) {
					// &
					case 38:
						ampersand = offset > 0 ? 1 : (characters += '\f', -1)
						break
					// ,
					case 44:
						points[index++] = (Utility_strlen(characters) - 1) * ampersand, ampersand = 1
						break
					// @
					case 64:
						// -
						if (peek() === 45)
							characters += delimit(next())

						atrule = peek(), offset = length = Utility_strlen(type = characters += identifier(caret())), character++
						break
					// -
					case 45:
						if (previous === 45 && Utility_strlen(characters) == 2)
							variable = 0
				}
		}

	return rulesets
}

/**
 * @param {string} value
 * @param {object} root
 * @param {object?} parent
 * @param {number} index
 * @param {number} offset
 * @param {string[]} rules
 * @param {number[]} points
 * @param {string} type
 * @param {string[]} props
 * @param {string[]} children
 * @param {number} length
 * @return {object}
 */
function ruleset (value, root, parent, index, offset, rules, points, type, props, children, length) {
	var post = offset - 1
	var rule = offset === 0 ? rules : ['']
	var size = Utility_sizeof(rule)

	for (var i = 0, j = 0, k = 0; i < index; ++i)
		for (var x = 0, y = Utility_substr(value, post + 1, post = abs(j = points[i])), z = value; x < size; ++x)
			if (z = trim(j > 0 ? rule[x] + ' ' + y : Utility_replace(y, /&\f/g, rule[x])))
				props[k++] = z

	return node(value, root, parent, offset === 0 ? Enum_RULESET : type, props, children, length)
}

/**
 * @param {number} value
 * @param {object} root
 * @param {object?} parent
 * @return {object}
 */
function comment (value, root, parent) {
	return node(value, root, parent, COMMENT, Utility_from(Tokenizer_char()), Utility_substr(value, 2, -2), 0)
}

/**
 * @param {string} value
 * @param {object} root
 * @param {object?} parent
 * @param {number} length
 * @return {object}
 */
function declaration (value, root, parent, length) {
	return node(value, root, parent, Enum_DECLARATION, Utility_substr(value, 0, length), Utility_substr(value, length + 1, -1), length)
}

;// CONCATENATED MODULE: ./node_modules/@emotion/cache/dist/emotion-cache.browser.esm.js





var identifierWithPointTracking = function identifierWithPointTracking(begin, points, index) {
  var previous = 0;
  var character = 0;

  while (true) {
    previous = character;
    character = peek(); // &\f

    if (previous === 38 && character === 12) {
      points[index] = 1;
    }

    if (token(character)) {
      break;
    }

    next();
  }

  return slice(begin, position);
};

var toRules = function toRules(parsed, points) {
  // pretend we've started with a comma
  var index = -1;
  var character = 44;

  do {
    switch (token(character)) {
      case 0:
        // &\f
        if (character === 38 && peek() === 12) {
          // this is not 100% correct, we don't account for literal sequences here - like for example quoted strings
          // stylis inserts \f after & to know when & where it should replace this sequence with the context selector
          // and when it should just concatenate the outer and inner selectors
          // it's very unlikely for this sequence to actually appear in a different context, so we just leverage this fact here
          points[index] = 1;
        }

        parsed[index] += identifierWithPointTracking(position - 1, points, index);
        break;

      case 2:
        parsed[index] += delimit(character);
        break;

      case 4:
        // comma
        if (character === 44) {
          // colon
          parsed[++index] = peek() === 58 ? '&\f' : '';
          points[index] = parsed[index].length;
          break;
        }

      // fallthrough

      default:
        parsed[index] += Utility_from(character);
    }
  } while (character = next());

  return parsed;
};

var getRules = function getRules(value, points) {
  return dealloc(toRules(alloc(value), points));
}; // WeakSet would be more appropriate, but only WeakMap is supported in IE11


var fixedElements = /* #__PURE__ */new WeakMap();
var compat = function compat(element) {
  if (element.type !== 'rule' || !element.parent || // positive .length indicates that this rule contains pseudo
  // negative .length indicates that this rule has been already prefixed
  element.length < 1) {
    return;
  }

  var value = element.value;
  var parent = element.parent;
  var isImplicitRule = element.column === parent.column && element.line === parent.line;

  while (parent.type !== 'rule') {
    parent = parent.parent;
    if (!parent) return;
  } // short-circuit for the simplest case


  if (element.props.length === 1 && value.charCodeAt(0) !== 58
  /* colon */
  && !fixedElements.get(parent)) {
    return;
  } // if this is an implicitly inserted rule (the one eagerly inserted at the each new nested level)
  // then the props has already been manipulated beforehand as they that array is shared between it and its "rule parent"


  if (isImplicitRule) {
    return;
  }

  fixedElements.set(element, true);
  var points = [];
  var rules = getRules(value, points);
  var parentRules = parent.props;

  for (var i = 0, k = 0; i < rules.length; i++) {
    for (var j = 0; j < parentRules.length; j++, k++) {
      element.props[k] = points[i] ? rules[i].replace(/&\f/g, parentRules[j]) : parentRules[j] + " " + rules[i];
    }
  }
};
var removeLabel = function removeLabel(element) {
  if (element.type === 'decl') {
    var value = element.value;

    if ( // charcode for l
    value.charCodeAt(0) === 108 && // charcode for b
    value.charCodeAt(2) === 98) {
      // this ignores label
      element["return"] = '';
      element.value = '';
    }
  }
};

/* eslint-disable no-fallthrough */

function emotion_cache_browser_esm_prefix(value, length) {
  switch (hash(value, length)) {
    // color-adjust
    case 5103:
      return Enum_WEBKIT + 'print-' + value + value;
    // animation, animation-(delay|direction|duration|fill-mode|iteration-count|name|play-state|timing-function)

    case 5737:
    case 4201:
    case 3177:
    case 3433:
    case 1641:
    case 4457:
    case 2921: // text-decoration, filter, clip-path, backface-visibility, column, box-decoration-break

    case 5572:
    case 6356:
    case 5844:
    case 3191:
    case 6645:
    case 3005: // mask, mask-image, mask-(mode|clip|size), mask-(repeat|origin), mask-position, mask-composite,

    case 6391:
    case 5879:
    case 5623:
    case 6135:
    case 4599:
    case 4855: // background-clip, columns, column-(count|fill|gap|rule|rule-color|rule-style|rule-width|span|width)

    case 4215:
    case 6389:
    case 5109:
    case 5365:
    case 5621:
    case 3829:
      return Enum_WEBKIT + value + value;
    // appearance, user-select, transform, hyphens, text-size-adjust

    case 5349:
    case 4246:
    case 4810:
    case 6968:
    case 2756:
      return Enum_WEBKIT + value + Enum_MOZ + value + Enum_MS + value + value;
    // flex, flex-direction

    case 6828:
    case 4268:
      return Enum_WEBKIT + value + Enum_MS + value + value;
    // order

    case 6165:
      return Enum_WEBKIT + value + Enum_MS + 'flex-' + value + value;
    // align-items

    case 5187:
      return Enum_WEBKIT + value + Utility_replace(value, /(\w+).+(:[^]+)/, Enum_WEBKIT + 'box-$1$2' + Enum_MS + 'flex-$1$2') + value;
    // align-self

    case 5443:
      return Enum_WEBKIT + value + Enum_MS + 'flex-item-' + Utility_replace(value, /flex-|-self/, '') + value;
    // align-content

    case 4675:
      return Enum_WEBKIT + value + Enum_MS + 'flex-line-pack' + Utility_replace(value, /align-content|flex-|-self/, '') + value;
    // flex-shrink

    case 5548:
      return Enum_WEBKIT + value + Enum_MS + Utility_replace(value, 'shrink', 'negative') + value;
    // flex-basis

    case 5292:
      return Enum_WEBKIT + value + Enum_MS + Utility_replace(value, 'basis', 'preferred-size') + value;
    // flex-grow

    case 6060:
      return Enum_WEBKIT + 'box-' + Utility_replace(value, '-grow', '') + Enum_WEBKIT + value + Enum_MS + Utility_replace(value, 'grow', 'positive') + value;
    // transition

    case 4554:
      return Enum_WEBKIT + Utility_replace(value, /([^-])(transform)/g, '$1' + Enum_WEBKIT + '$2') + value;
    // cursor

    case 6187:
      return Utility_replace(Utility_replace(Utility_replace(value, /(zoom-|grab)/, Enum_WEBKIT + '$1'), /(image-set)/, Enum_WEBKIT + '$1'), value, '') + value;
    // background, background-image

    case 5495:
    case 3959:
      return Utility_replace(value, /(image-set\([^]*)/, Enum_WEBKIT + '$1' + '$`$1');
    // justify-content

    case 4968:
      return Utility_replace(Utility_replace(value, /(.+:)(flex-)?(.*)/, Enum_WEBKIT + 'box-pack:$3' + Enum_MS + 'flex-pack:$3'), /s.+-b[^;]+/, 'justify') + Enum_WEBKIT + value + value;
    // (margin|padding)-inline-(start|end)

    case 4095:
    case 3583:
    case 4068:
    case 2532:
      return Utility_replace(value, /(.+)-inline(.+)/, Enum_WEBKIT + '$1$2') + value;
    // (min|max)?(width|height|inline-size|block-size)

    case 8116:
    case 7059:
    case 5753:
    case 5535:
    case 5445:
    case 5701:
    case 4933:
    case 4677:
    case 5533:
    case 5789:
    case 5021:
    case 4765:
      // stretch, max-content, min-content, fill-available
      if (Utility_strlen(value) - 1 - length > 6) switch (Utility_charat(value, length + 1)) {
        // (m)ax-content, (m)in-content
        case 109:
          // -
          if (Utility_charat(value, length + 4) !== 45) break;
        // (f)ill-available, (f)it-content

        case 102:
          return Utility_replace(value, /(.+:)(.+)-([^]+)/, '$1' + Enum_WEBKIT + '$2-$3' + '$1' + Enum_MOZ + (Utility_charat(value, length + 3) == 108 ? '$3' : '$2-$3')) + value;
        // (s)tretch

        case 115:
          return ~indexof(value, 'stretch') ? emotion_cache_browser_esm_prefix(Utility_replace(value, 'stretch', 'fill-available'), length) + value : value;
      }
      break;
    // position: sticky

    case 4949:
      // (s)ticky?
      if (Utility_charat(value, length + 1) !== 115) break;
    // display: (flex|inline-flex)

    case 6444:
      switch (Utility_charat(value, Utility_strlen(value) - 3 - (~indexof(value, '!important') && 10))) {
        // stic(k)y
        case 107:
          return Utility_replace(value, ':', ':' + Enum_WEBKIT) + value;
        // (inline-)?fl(e)x

        case 101:
          return Utility_replace(value, /(.+:)([^;!]+)(;|!.+)?/, '$1' + Enum_WEBKIT + (Utility_charat(value, 14) === 45 ? 'inline-' : '') + 'box$3' + '$1' + Enum_WEBKIT + '$2$3' + '$1' + Enum_MS + '$2box$3') + value;
      }

      break;
    // writing-mode

    case 5936:
      switch (Utility_charat(value, length + 11)) {
        // vertical-l(r)
        case 114:
          return Enum_WEBKIT + value + Enum_MS + Utility_replace(value, /[svh]\w+-[tblr]{2}/, 'tb') + value;
        // vertical-r(l)

        case 108:
          return Enum_WEBKIT + value + Enum_MS + Utility_replace(value, /[svh]\w+-[tblr]{2}/, 'tb-rl') + value;
        // horizontal(-)tb

        case 45:
          return Enum_WEBKIT + value + Enum_MS + Utility_replace(value, /[svh]\w+-[tblr]{2}/, 'lr') + value;
      }

      return Enum_WEBKIT + value + Enum_MS + value + value;
  }

  return value;
}

var emotion_cache_browser_esm_prefixer = function prefixer(element, index, children, callback) {
  if (element.length > -1) if (!element["return"]) switch (element.type) {
    case Enum_DECLARATION:
      element["return"] = emotion_cache_browser_esm_prefix(element.value, element.length);
      break;

    case Enum_KEYFRAMES:
      return Serializer_serialize([Tokenizer_copy(element, {
        value: Utility_replace(element.value, '@', '@' + Enum_WEBKIT)
      })], callback);

    case Enum_RULESET:
      if (element.length) return Utility_combine(element.props, function (value) {
        switch (Utility_match(value, /(::plac\w+|:read-\w+)/)) {
          // :read-(only|write)
          case ':read-only':
          case ':read-write':
            return Serializer_serialize([Tokenizer_copy(element, {
              props: [Utility_replace(value, /:(read-\w+)/, ':' + Enum_MOZ + '$1')]
            })], callback);
          // :placeholder

          case '::placeholder':
            return Serializer_serialize([Tokenizer_copy(element, {
              props: [Utility_replace(value, /:(plac\w+)/, ':' + Enum_WEBKIT + 'input-$1')]
            }), Tokenizer_copy(element, {
              props: [Utility_replace(value, /:(plac\w+)/, ':' + Enum_MOZ + '$1')]
            }), Tokenizer_copy(element, {
              props: [Utility_replace(value, /:(plac\w+)/, Enum_MS + 'input-$1')]
            })], callback);
        }

        return '';
      });
  }
};

var defaultStylisPlugins = [emotion_cache_browser_esm_prefixer];

var emotion_cache_browser_esm_createCache = function createCache(options) {
  var key = options.key;

  if (key === 'css') {
    var ssrStyles = document.querySelectorAll("style[data-emotion]:not([data-s])"); // get SSRed styles out of the way of React's hydration
    // document.head is a safe place to move them to(though note document.head is not necessarily the last place they will be)
    // note this very very intentionally targets all style elements regardless of the key to ensure
    // that creating a cache works inside of render of a React component

    Array.prototype.forEach.call(ssrStyles, function (node) {
      // we want to only move elements which have a space in the data-emotion attribute value
      // because that indicates that it is an Emotion 11 server-side rendered style elements
      // while we will already ignore Emotion 11 client-side inserted styles because of the :not([data-s]) part in the selector
      // Emotion 10 client-side inserted styles did not have data-s (but importantly did not have a space in their data-emotion attributes)
      // so checking for the space ensures that loading Emotion 11 after Emotion 10 has inserted some styles
      // will not result in the Emotion 10 styles being destroyed
      var dataEmotionAttribute = node.getAttribute('data-emotion');

      if (dataEmotionAttribute.indexOf(' ') === -1) {
        return;
      }

      document.head.appendChild(node);
      node.setAttribute('data-s', '');
    });
  }

  var stylisPlugins = options.stylisPlugins || defaultStylisPlugins;

  var inserted = {};
  var container;
  var nodesToHydrate = [];

  {
    container = options.container || document.head;
    Array.prototype.forEach.call( // this means we will ignore elements which don't have a space in them which
    // means that the style elements we're looking at are only Emotion 11 server-rendered style elements
    document.querySelectorAll("style[data-emotion^=\"" + key + " \"]"), function (node) {
      var attrib = node.getAttribute("data-emotion").split(' ');

      for (var i = 1; i < attrib.length; i++) {
        inserted[attrib[i]] = true;
      }

      nodesToHydrate.push(node);
    });
  }

  var _insert;

  var omnipresentPlugins = [compat, removeLabel];

  {
    var currentSheet;
    var finalizingPlugins = [stringify, rulesheet(function (rule) {
      currentSheet.insert(rule);
    })];
    var serializer = middleware(omnipresentPlugins.concat(stylisPlugins, finalizingPlugins));

    var stylis = function stylis(styles) {
      return Serializer_serialize(compile(styles), serializer);
    };

    _insert = function insert(selector, serialized, sheet, shouldCache) {
      currentSheet = sheet;

      stylis(selector ? selector + "{" + serialized.styles + "}" : serialized.styles);

      if (shouldCache) {
        cache.inserted[serialized.name] = true;
      }
    };
  }

  var cache = {
    key: key,
    sheet: new StyleSheet({
      key: key,
      container: container,
      nonce: options.nonce,
      speedy: options.speedy,
      prepend: options.prepend,
      insertionPoint: options.insertionPoint
    }),
    nonce: options.nonce,
    inserted: inserted,
    registered: {},
    insert: _insert
  };
  cache.sheet.hydrate(nodesToHydrate);
  return cache;
};



;// CONCATENATED MODULE: ./node_modules/@emotion/utils/dist/emotion-utils.browser.esm.js
var isBrowser = true;

function emotion_utils_browser_esm_getRegisteredStyles(registered, registeredStyles, classNames) {
  var rawClassName = '';
  classNames.split(' ').forEach(function (className) {
    if (registered[className] !== undefined) {
      registeredStyles.push(registered[className] + ";");
    } else if (className) {
      rawClassName += className + " ";
    }
  });
  return rawClassName;
}
var emotion_utils_browser_esm_registerStyles = function registerStyles(cache, serialized, isStringTag) {
  var className = cache.key + "-" + serialized.name;

  if ( // we only need to add the styles to the registered cache if the
  // class name could be used further down
  // the tree but if it's a string tag, we know it won't
  // so we don't have to add it to registered cache.
  // this improves memory usage since we can avoid storing the whole style string
  (isStringTag === false || // we need to always store it if we're in compat mode and
  // in node since emotion-server relies on whether a style is in
  // the registered cache to know whether a style is global or not
  // also, note that this check will be dead code eliminated in the browser
  isBrowser === false ) && cache.registered[className] === undefined) {
    cache.registered[className] = serialized.styles;
  }
};
var emotion_utils_browser_esm_insertStyles = function insertStyles(cache, serialized, isStringTag) {
  emotion_utils_browser_esm_registerStyles(cache, serialized, isStringTag);
  var className = cache.key + "-" + serialized.name;

  if (cache.inserted[serialized.name] === undefined) {
    var current = serialized;

    do {
      cache.insert(serialized === current ? "." + className : '', current, cache.sheet, true);

      current = current.next;
    } while (current !== undefined);
  }
};



;// CONCATENATED MODULE: ./node_modules/@emotion/hash/dist/emotion-hash.esm.js
/* eslint-disable */
// Inspired by https://github.com/garycourt/murmurhash-js
// Ported from https://github.com/aappleby/smhasher/blob/61a0530f28277f2e850bfc39600ce61d02b518de/src/MurmurHash2.cpp#L37-L86
function murmur2(str) {
  // 'm' and 'r' are mixing constants generated offline.
  // They're not really 'magic', they just happen to work well.
  // const m = 0x5bd1e995;
  // const r = 24;
  // Initialize the hash
  var h = 0; // Mix 4 bytes at a time into the hash

  var k,
      i = 0,
      len = str.length;

  for (; len >= 4; ++i, len -= 4) {
    k = str.charCodeAt(i) & 0xff | (str.charCodeAt(++i) & 0xff) << 8 | (str.charCodeAt(++i) & 0xff) << 16 | (str.charCodeAt(++i) & 0xff) << 24;
    k =
    /* Math.imul(k, m): */
    (k & 0xffff) * 0x5bd1e995 + ((k >>> 16) * 0xe995 << 16);
    k ^=
    /* k >>> r: */
    k >>> 24;
    h =
    /* Math.imul(k, m): */
    (k & 0xffff) * 0x5bd1e995 + ((k >>> 16) * 0xe995 << 16) ^
    /* Math.imul(h, m): */
    (h & 0xffff) * 0x5bd1e995 + ((h >>> 16) * 0xe995 << 16);
  } // Handle the last few bytes of the input array


  switch (len) {
    case 3:
      h ^= (str.charCodeAt(i + 2) & 0xff) << 16;

    case 2:
      h ^= (str.charCodeAt(i + 1) & 0xff) << 8;

    case 1:
      h ^= str.charCodeAt(i) & 0xff;
      h =
      /* Math.imul(h, m): */
      (h & 0xffff) * 0x5bd1e995 + ((h >>> 16) * 0xe995 << 16);
  } // Do a few final mixes of the hash to ensure the last few
  // bytes are well-incorporated.


  h ^= h >>> 13;
  h =
  /* Math.imul(h, m): */
  (h & 0xffff) * 0x5bd1e995 + ((h >>> 16) * 0xe995 << 16);
  return ((h ^ h >>> 15) >>> 0).toString(36);
}



;// CONCATENATED MODULE: ./node_modules/@emotion/unitless/dist/emotion-unitless.esm.js
var unitlessKeys = {
  animationIterationCount: 1,
  aspectRatio: 1,
  borderImageOutset: 1,
  borderImageSlice: 1,
  borderImageWidth: 1,
  boxFlex: 1,
  boxFlexGroup: 1,
  boxOrdinalGroup: 1,
  columnCount: 1,
  columns: 1,
  flex: 1,
  flexGrow: 1,
  flexPositive: 1,
  flexShrink: 1,
  flexNegative: 1,
  flexOrder: 1,
  gridRow: 1,
  gridRowEnd: 1,
  gridRowSpan: 1,
  gridRowStart: 1,
  gridColumn: 1,
  gridColumnEnd: 1,
  gridColumnSpan: 1,
  gridColumnStart: 1,
  msGridRow: 1,
  msGridRowSpan: 1,
  msGridColumn: 1,
  msGridColumnSpan: 1,
  fontWeight: 1,
  lineHeight: 1,
  opacity: 1,
  order: 1,
  orphans: 1,
  scale: 1,
  tabSize: 1,
  widows: 1,
  zIndex: 1,
  zoom: 1,
  WebkitLineClamp: 1,
  // SVG-related properties
  fillOpacity: 1,
  floodOpacity: 1,
  stopOpacity: 1,
  strokeDasharray: 1,
  strokeDashoffset: 1,
  strokeMiterlimit: 1,
  strokeOpacity: 1,
  strokeWidth: 1
};



;// CONCATENATED MODULE: ./node_modules/@emotion/memoize/dist/emotion-memoize.esm.js
function memoize(fn) {
  var cache = Object.create(null);
  return function (arg) {
    if (cache[arg] === undefined) cache[arg] = fn(arg);
    return cache[arg];
  };
}



;// CONCATENATED MODULE: ./node_modules/@emotion/serialize/dist/emotion-serialize.esm.js




var emotion_serialize_esm_isDevelopment = false;

var hyphenateRegex = /[A-Z]|^ms/g;
var animationRegex = /_EMO_([^_]+?)_([^]*?)_EMO_/g;

var isCustomProperty = function isCustomProperty(property) {
  return property.charCodeAt(1) === 45;
};

var isProcessableValue = function isProcessableValue(value) {
  return value != null && typeof value !== 'boolean';
};

var processStyleName = /* #__PURE__ */memoize(function (styleName) {
  return isCustomProperty(styleName) ? styleName : styleName.replace(hyphenateRegex, '-$&').toLowerCase();
});

var processStyleValue = function processStyleValue(key, value) {
  switch (key) {
    case 'animation':
    case 'animationName':
      {
        if (typeof value === 'string') {
          return value.replace(animationRegex, function (match, p1, p2) {
            cursor = {
              name: p1,
              styles: p2,
              next: cursor
            };
            return p1;
          });
        }
      }
  }

  if (unitlessKeys[key] !== 1 && !isCustomProperty(key) && typeof value === 'number' && value !== 0) {
    return value + 'px';
  }

  return value;
};

var noComponentSelectorMessage = 'Component selectors can only be used in conjunction with ' + '@emotion/babel-plugin, the swc Emotion plugin, or another Emotion-aware ' + 'compiler transform.';

function handleInterpolation(mergedProps, registered, interpolation) {
  if (interpolation == null) {
    return '';
  }

  var componentSelector = interpolation;

  if (componentSelector.__emotion_styles !== undefined) {

    return componentSelector;
  }

  switch (typeof interpolation) {
    case 'boolean':
      {
        return '';
      }

    case 'object':
      {
        var keyframes = interpolation;

        if (keyframes.anim === 1) {
          cursor = {
            name: keyframes.name,
            styles: keyframes.styles,
            next: cursor
          };
          return keyframes.name;
        }

        var serializedStyles = interpolation;

        if (serializedStyles.styles !== undefined) {
          var next = serializedStyles.next;

          if (next !== undefined) {
            // not the most efficient thing ever but this is a pretty rare case
            // and there will be very few iterations of this generally
            while (next !== undefined) {
              cursor = {
                name: next.name,
                styles: next.styles,
                next: cursor
              };
              next = next.next;
            }
          }

          var styles = serializedStyles.styles + ";";
          return styles;
        }

        return createStringFromObject(mergedProps, registered, interpolation);
      }

    case 'function':
      {
        if (mergedProps !== undefined) {
          var previousCursor = cursor;
          var result = interpolation(mergedProps);
          cursor = previousCursor;
          return handleInterpolation(mergedProps, registered, result);
        }

        break;
      }
  } // finalize string values (regular strings and functions interpolated into css calls)


  var asString = interpolation;

  if (registered == null) {
    return asString;
  }

  var cached = registered[asString];
  return cached !== undefined ? cached : asString;
}

function createStringFromObject(mergedProps, registered, obj) {
  var string = '';

  if (Array.isArray(obj)) {
    for (var i = 0; i < obj.length; i++) {
      string += handleInterpolation(mergedProps, registered, obj[i]) + ";";
    }
  } else {
    for (var key in obj) {
      var value = obj[key];

      if (typeof value !== 'object') {
        var asString = value;

        if (registered != null && registered[asString] !== undefined) {
          string += key + "{" + registered[asString] + "}";
        } else if (isProcessableValue(asString)) {
          string += processStyleName(key) + ":" + processStyleValue(key, asString) + ";";
        }
      } else {
        if (key === 'NO_COMPONENT_SELECTOR' && emotion_serialize_esm_isDevelopment) {
          throw new Error(noComponentSelectorMessage);
        }

        if (Array.isArray(value) && typeof value[0] === 'string' && (registered == null || registered[value[0]] === undefined)) {
          for (var _i = 0; _i < value.length; _i++) {
            if (isProcessableValue(value[_i])) {
              string += processStyleName(key) + ":" + processStyleValue(key, value[_i]) + ";";
            }
          }
        } else {
          var interpolated = handleInterpolation(mergedProps, registered, value);

          switch (key) {
            case 'animation':
            case 'animationName':
              {
                string += processStyleName(key) + ":" + interpolated + ";";
                break;
              }

            default:
              {

                string += key + "{" + interpolated + "}";
              }
          }
        }
      }
    }
  }

  return string;
}

var labelPattern = /label:\s*([^\s;{]+)\s*(;|$)/g; // this is the cursor for keyframes
// keyframes are stored on the SerializedStyles object as a linked list

var cursor;
function emotion_serialize_esm_serializeStyles(args, registered, mergedProps) {
  if (args.length === 1 && typeof args[0] === 'object' && args[0] !== null && args[0].styles !== undefined) {
    return args[0];
  }

  var stringMode = true;
  var styles = '';
  cursor = undefined;
  var strings = args[0];

  if (strings == null || strings.raw === undefined) {
    stringMode = false;
    styles += handleInterpolation(mergedProps, registered, strings);
  } else {
    var asTemplateStringsArr = strings;

    styles += asTemplateStringsArr[0];
  } // we start at 1 since we've already handled the first arg


  for (var i = 1; i < args.length; i++) {
    styles += handleInterpolation(mergedProps, registered, args[i]);

    if (stringMode) {
      var templateStringsArr = strings;

      styles += templateStringsArr[i];
    }
  } // using a global regex with .exec is stateful so lastIndex has to be reset each time


  labelPattern.lastIndex = 0;
  var identifierName = '';
  var match; // https://esbench.com/bench/5b809c2cf2949800a0f61fb5

  while ((match = labelPattern.exec(styles)) !== null) {
    identifierName += '-' + match[1];
  }

  var name = murmur2(styles) + identifierName;

  return {
    name: name,
    styles: styles,
    next: cursor
  };
}



;// CONCATENATED MODULE: ./node_modules/@emotion/use-insertion-effect-with-fallbacks/dist/emotion-use-insertion-effect-with-fallbacks.browser.esm.js


var syncFallback = function syncFallback(create) {
  return create();
};

var useInsertionEffect = react_namespaceObject['useInsertion' + 'Effect'] ? react_namespaceObject['useInsertion' + 'Effect'] : false;
var emotion_use_insertion_effect_with_fallbacks_browser_esm_useInsertionEffectAlwaysWithSyncFallback = useInsertionEffect || syncFallback;
var emotion_use_insertion_effect_with_fallbacks_browser_esm_useInsertionEffectWithLayoutFallback = useInsertionEffect || react.useLayoutEffect;



;// CONCATENATED MODULE: ./node_modules/@emotion/react/dist/emotion-element-f0de968e.browser.esm.js










var emotion_element_f0de968e_browser_esm_isDevelopment = false;

var EmotionCacheContext = /* #__PURE__ */react.createContext( // we're doing this to avoid preconstruct's dead code elimination in this one case
// because this module is primarily intended for the browser and node
// but it's also required in react native and similar environments sometimes
// and we could have a special build just for that
// but this is much easier and the native packages
// might use a different theme context in the future anyway
typeof HTMLElement !== 'undefined' ? /* #__PURE__ */emotion_cache_browser_esm_createCache({
  key: 'css'
}) : null);

var emotion_element_f0de968e_browser_esm_CacheProvider = EmotionCacheContext.Provider;
var __unsafe_useEmotionCache = function useEmotionCache() {
  return useContext(EmotionCacheContext);
};

var emotion_element_f0de968e_browser_esm_withEmotionCache = function withEmotionCache(func) {
  return /*#__PURE__*/(0,react.forwardRef)(function (props, ref) {
    // the cache will never be null in the browser
    var cache = (0,react.useContext)(EmotionCacheContext);
    return func(props, cache, ref);
  });
};

var emotion_element_f0de968e_browser_esm_ThemeContext = /* #__PURE__ */react.createContext({});

var useTheme = function useTheme() {
  return React.useContext(emotion_element_f0de968e_browser_esm_ThemeContext);
};

var getTheme = function getTheme(outerTheme, theme) {
  if (typeof theme === 'function') {
    var mergedTheme = theme(outerTheme);

    return mergedTheme;
  }

  return _extends({}, outerTheme, theme);
};

var createCacheWithTheme = /* #__PURE__ */(/* unused pure expression or super */ null && (weakMemoize(function (outerTheme) {
  return weakMemoize(function (theme) {
    return getTheme(outerTheme, theme);
  });
})));
var ThemeProvider = function ThemeProvider(props) {
  var theme = React.useContext(emotion_element_f0de968e_browser_esm_ThemeContext);

  if (props.theme !== theme) {
    theme = createCacheWithTheme(theme)(props.theme);
  }

  return /*#__PURE__*/React.createElement(emotion_element_f0de968e_browser_esm_ThemeContext.Provider, {
    value: theme
  }, props.children);
};
function withTheme(Component) {
  var componentName = Component.displayName || Component.name || 'Component';
  var WithTheme = /*#__PURE__*/React.forwardRef(function render(props, ref) {
    var theme = React.useContext(emotion_element_f0de968e_browser_esm_ThemeContext);
    return /*#__PURE__*/React.createElement(Component, _extends({
      theme: theme,
      ref: ref
    }, props));
  });
  WithTheme.displayName = "WithTheme(" + componentName + ")";
  return hoistNonReactStatics(WithTheme, Component);
}

var hasOwn = {}.hasOwnProperty;

var typePropName = '__EMOTION_TYPE_PLEASE_DO_NOT_USE__';
var createEmotionProps = function createEmotionProps(type, props) {

  var newProps = {};

  for (var _key in props) {
    if (hasOwn.call(props, _key)) {
      newProps[_key] = props[_key];
    }
  }

  newProps[typePropName] = type; // Runtime labeling is an opt-in feature because:

  return newProps;
};

var Insertion = function Insertion(_ref) {
  var cache = _ref.cache,
      serialized = _ref.serialized,
      isStringTag = _ref.isStringTag;
  emotion_utils_browser_esm_registerStyles(cache, serialized, isStringTag);
  emotion_use_insertion_effect_with_fallbacks_browser_esm_useInsertionEffectAlwaysWithSyncFallback(function () {
    return emotion_utils_browser_esm_insertStyles(cache, serialized, isStringTag);
  });

  return null;
};

var Emotion = /* #__PURE__ */emotion_element_f0de968e_browser_esm_withEmotionCache(function (props, cache, ref) {
  var cssProp = props.css; // so that using `css` from `emotion` and passing the result to the css prop works
  // not passing the registered cache to serializeStyles because it would
  // make certain babel optimisations not possible

  if (typeof cssProp === 'string' && cache.registered[cssProp] !== undefined) {
    cssProp = cache.registered[cssProp];
  }

  var WrappedComponent = props[typePropName];
  var registeredStyles = [cssProp];
  var className = '';

  if (typeof props.className === 'string') {
    className = emotion_utils_browser_esm_getRegisteredStyles(cache.registered, registeredStyles, props.className);
  } else if (props.className != null) {
    className = props.className + " ";
  }

  var serialized = emotion_serialize_esm_serializeStyles(registeredStyles, undefined, react.useContext(emotion_element_f0de968e_browser_esm_ThemeContext));

  className += cache.key + "-" + serialized.name;
  var newProps = {};

  for (var _key2 in props) {
    if (hasOwn.call(props, _key2) && _key2 !== 'css' && _key2 !== typePropName && (!emotion_element_f0de968e_browser_esm_isDevelopment )) {
      newProps[_key2] = props[_key2];
    }
  }

  newProps.className = className;

  if (ref) {
    newProps.ref = ref;
  }

  return /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement(Insertion, {
    cache: cache,
    serialized: serialized,
    isStringTag: typeof WrappedComponent === 'string'
  }), /*#__PURE__*/react.createElement(WrappedComponent, newProps));
});

var Emotion$1 = Emotion;



// EXTERNAL MODULE: ./node_modules/hoist-non-react-statics/dist/hoist-non-react-statics.cjs.js
var hoist_non_react_statics_cjs = __webpack_require__(4146);
;// CONCATENATED MODULE: ./node_modules/@emotion/react/dist/emotion-react.browser.esm.js












var jsx = function jsx(type, props) {
  // eslint-disable-next-line prefer-rest-params
  var args = arguments;

  if (props == null || !hasOwn.call(props, 'css')) {
    return react.createElement.apply(undefined, args);
  }

  var argsLength = args.length;
  var createElementArgArray = new Array(argsLength);
  createElementArgArray[0] = Emotion$1;
  createElementArgArray[1] = createEmotionProps(type, props);

  for (var i = 2; i < argsLength; i++) {
    createElementArgArray[i] = args[i];
  }

  return react.createElement.apply(null, createElementArgArray);
};

(function (_jsx) {
  var JSX;

  (function (_JSX) {})(JSX || (JSX = _jsx.JSX || (_jsx.JSX = {})));
})(jsx || (jsx = {}));

// initial render from browser, insertBefore context.sheet.tags[0] or if a style hasn't been inserted there yet, appendChild
// initial client-side render from SSR, use place of hydrating tag

var Global = /* #__PURE__ */(/* unused pure expression or super */ null && (withEmotionCache(function (props, cache) {

  var styles = props.styles;
  var serialized = serializeStyles([styles], undefined, React.useContext(ThemeContext));
  // but it is based on a constant that will never change at runtime
  // it's effectively like having two implementations and switching them out
  // so it's not actually breaking anything


  var sheetRef = React.useRef();
  useInsertionEffectWithLayoutFallback(function () {
    var key = cache.key + "-global"; // use case of https://github.com/emotion-js/emotion/issues/2675

    var sheet = new cache.sheet.constructor({
      key: key,
      nonce: cache.sheet.nonce,
      container: cache.sheet.container,
      speedy: cache.sheet.isSpeedy
    });
    var rehydrating = false;
    var node = document.querySelector("style[data-emotion=\"" + key + " " + serialized.name + "\"]");

    if (cache.sheet.tags.length) {
      sheet.before = cache.sheet.tags[0];
    }

    if (node !== null) {
      rehydrating = true; // clear the hash so this node won't be recognizable as rehydratable by other <Global/>s

      node.setAttribute('data-emotion', key);
      sheet.hydrate([node]);
    }

    sheetRef.current = [sheet, rehydrating];
    return function () {
      sheet.flush();
    };
  }, [cache]);
  useInsertionEffectWithLayoutFallback(function () {
    var sheetRefCurrent = sheetRef.current;
    var sheet = sheetRefCurrent[0],
        rehydrating = sheetRefCurrent[1];

    if (rehydrating) {
      sheetRefCurrent[1] = false;
      return;
    }

    if (serialized.next !== undefined) {
      // insert keyframes
      insertStyles(cache, serialized.next, true);
    }

    if (sheet.tags.length) {
      // if this doesn't exist then it will be null so the style element will be appended
      var element = sheet.tags[sheet.tags.length - 1].nextElementSibling;
      sheet.before = element;
      sheet.flush();
    }

    cache.insert("", serialized, sheet, false);
  }, [cache, serialized.name]);
  return null;
})));

function css() {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  return emotion_serialize_esm_serializeStyles(args);
}

function keyframes() {
  var insertable = css.apply(void 0, arguments);
  var name = "animation-" + insertable.name;
  return {
    name: name,
    styles: "@keyframes " + name + "{" + insertable.styles + "}",
    anim: 1,
    toString: function toString() {
      return "_EMO_" + this.name + "_" + this.styles + "_EMO_";
    }
  };
}

var classnames = function classnames(args) {
  var len = args.length;
  var i = 0;
  var cls = '';

  for (; i < len; i++) {
    var arg = args[i];
    if (arg == null) continue;
    var toAdd = void 0;

    switch (typeof arg) {
      case 'boolean':
        break;

      case 'object':
        {
          if (Array.isArray(arg)) {
            toAdd = classnames(arg);
          } else {

            toAdd = '';

            for (var k in arg) {
              if (arg[k] && k) {
                toAdd && (toAdd += ' ');
                toAdd += k;
              }
            }
          }

          break;
        }

      default:
        {
          toAdd = arg;
        }
    }

    if (toAdd) {
      cls && (cls += ' ');
      cls += toAdd;
    }
  }

  return cls;
};

function merge(registered, css, className) {
  var registeredStyles = [];
  var rawClassName = getRegisteredStyles(registered, registeredStyles, className);

  if (registeredStyles.length < 2) {
    return className;
  }

  return rawClassName + css(registeredStyles);
}

var emotion_react_browser_esm_Insertion = function Insertion(_ref) {
  var cache = _ref.cache,
      serializedArr = _ref.serializedArr;
  useInsertionEffectAlwaysWithSyncFallback(function () {

    for (var i = 0; i < serializedArr.length; i++) {
      insertStyles(cache, serializedArr[i], false);
    }
  });

  return null;
};

var ClassNames = /* #__PURE__ */(/* unused pure expression or super */ null && (withEmotionCache(function (props, cache) {
  var hasRendered = false;
  var serializedArr = [];

  var css = function css() {
    if (hasRendered && isDevelopment) {
      throw new Error('css can only be used during render');
    }

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    var serialized = serializeStyles(args, cache.registered);
    serializedArr.push(serialized); // registration has to happen here as the result of this might get consumed by `cx`

    registerStyles(cache, serialized, false);
    return cache.key + "-" + serialized.name;
  };

  var cx = function cx() {
    if (hasRendered && isDevelopment) {
      throw new Error('cx can only be used during render');
    }

    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }

    return merge(cache.registered, css, classnames(args));
  };

  var content = {
    css: css,
    cx: cx,
    theme: React.useContext(ThemeContext)
  };
  var ele = props.children(content);
  hasRendered = true;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(emotion_react_browser_esm_Insertion, {
    cache: cache,
    serializedArr: serializedArr
  }), ele);
})));



;// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/taggedTemplateLiteral.js
function _taggedTemplateLiteral(e, t) {
  return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, {
    raw: {
      value: Object.freeze(t)
    }
  }));
}

;// CONCATENATED MODULE: ./node_modules/@floating-ui/utils/dist/floating-ui.utils.mjs
/**
 * Custom positioning reference element.
 * @see https://floating-ui.com/docs/virtual-elements
 */

const sides = (/* unused pure expression or super */ null && (['top', 'right', 'bottom', 'left']));
const alignments = (/* unused pure expression or super */ null && (['start', 'end']));
const placements = /*#__PURE__*/(/* unused pure expression or super */ null && (sides.reduce((acc, side) => acc.concat(side, side + "-" + alignments[0], side + "-" + alignments[1]), [])));
const min = Math.min;
const max = Math.max;
const round = Math.round;
const floor = Math.floor;
const createCoords = v => ({
  x: v,
  y: v
});
const oppositeSideMap = {
  left: 'right',
  right: 'left',
  bottom: 'top',
  top: 'bottom'
};
const oppositeAlignmentMap = {
  start: 'end',
  end: 'start'
};
function clamp(start, value, end) {
  return max(start, min(value, end));
}
function evaluate(value, param) {
  return typeof value === 'function' ? value(param) : value;
}
function getSide(placement) {
  return placement.split('-')[0];
}
function getAlignment(placement) {
  return placement.split('-')[1];
}
function getOppositeAxis(axis) {
  return axis === 'x' ? 'y' : 'x';
}
function getAxisLength(axis) {
  return axis === 'y' ? 'height' : 'width';
}
const yAxisSides = /*#__PURE__*/new Set(['top', 'bottom']);
function getSideAxis(placement) {
  return yAxisSides.has(getSide(placement)) ? 'y' : 'x';
}
function getAlignmentAxis(placement) {
  return getOppositeAxis(getSideAxis(placement));
}
function getAlignmentSides(placement, rects, rtl) {
  if (rtl === void 0) {
    rtl = false;
  }
  const alignment = getAlignment(placement);
  const alignmentAxis = getAlignmentAxis(placement);
  const length = getAxisLength(alignmentAxis);
  let mainAlignmentSide = alignmentAxis === 'x' ? alignment === (rtl ? 'end' : 'start') ? 'right' : 'left' : alignment === 'start' ? 'bottom' : 'top';
  if (rects.reference[length] > rects.floating[length]) {
    mainAlignmentSide = getOppositePlacement(mainAlignmentSide);
  }
  return [mainAlignmentSide, getOppositePlacement(mainAlignmentSide)];
}
function getExpandedPlacements(placement) {
  const oppositePlacement = getOppositePlacement(placement);
  return [getOppositeAlignmentPlacement(placement), oppositePlacement, getOppositeAlignmentPlacement(oppositePlacement)];
}
function getOppositeAlignmentPlacement(placement) {
  return placement.replace(/start|end/g, alignment => oppositeAlignmentMap[alignment]);
}
const lrPlacement = (/* unused pure expression or super */ null && (['left', 'right']));
const rlPlacement = (/* unused pure expression or super */ null && (['right', 'left']));
const tbPlacement = (/* unused pure expression or super */ null && (['top', 'bottom']));
const btPlacement = (/* unused pure expression or super */ null && (['bottom', 'top']));
function getSideList(side, isStart, rtl) {
  switch (side) {
    case 'top':
    case 'bottom':
      if (rtl) return isStart ? rlPlacement : lrPlacement;
      return isStart ? lrPlacement : rlPlacement;
    case 'left':
    case 'right':
      return isStart ? tbPlacement : btPlacement;
    default:
      return [];
  }
}
function getOppositeAxisPlacements(placement, flipAlignment, direction, rtl) {
  const alignment = getAlignment(placement);
  let list = getSideList(getSide(placement), direction === 'start', rtl);
  if (alignment) {
    list = list.map(side => side + "-" + alignment);
    if (flipAlignment) {
      list = list.concat(list.map(getOppositeAlignmentPlacement));
    }
  }
  return list;
}
function getOppositePlacement(placement) {
  return placement.replace(/left|right|bottom|top/g, side => oppositeSideMap[side]);
}
function expandPaddingObject(padding) {
  return {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    ...padding
  };
}
function getPaddingObject(padding) {
  return typeof padding !== 'number' ? expandPaddingObject(padding) : {
    top: padding,
    right: padding,
    bottom: padding,
    left: padding
  };
}
function rectToClientRect(rect) {
  const {
    x,
    y,
    width,
    height
  } = rect;
  return {
    width,
    height,
    top: y,
    left: x,
    right: x + width,
    bottom: y + height,
    x,
    y
  };
}



;// CONCATENATED MODULE: ./node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs
function hasWindow() {
  return typeof window !== 'undefined';
}
function getNodeName(node) {
  if (isNode(node)) {
    return (node.nodeName || '').toLowerCase();
  }
  // Mocked nodes in testing environments may not be instances of Node. By
  // returning `#document` an infinite loop won't occur.
  // https://github.com/floating-ui/floating-ui/issues/2317
  return '#document';
}
function getWindow(node) {
  var _node$ownerDocument;
  return (node == null || (_node$ownerDocument = node.ownerDocument) == null ? void 0 : _node$ownerDocument.defaultView) || window;
}
function getDocumentElement(node) {
  var _ref;
  return (_ref = (isNode(node) ? node.ownerDocument : node.document) || window.document) == null ? void 0 : _ref.documentElement;
}
function isNode(value) {
  if (!hasWindow()) {
    return false;
  }
  return value instanceof Node || value instanceof getWindow(value).Node;
}
function isElement(value) {
  if (!hasWindow()) {
    return false;
  }
  return value instanceof Element || value instanceof getWindow(value).Element;
}
function isHTMLElement(value) {
  if (!hasWindow()) {
    return false;
  }
  return value instanceof HTMLElement || value instanceof getWindow(value).HTMLElement;
}
function isShadowRoot(value) {
  if (!hasWindow() || typeof ShadowRoot === 'undefined') {
    return false;
  }
  return value instanceof ShadowRoot || value instanceof getWindow(value).ShadowRoot;
}
const invalidOverflowDisplayValues = /*#__PURE__*/new Set(['inline', 'contents']);
function isOverflowElement(element) {
  const {
    overflow,
    overflowX,
    overflowY,
    display
  } = floating_ui_utils_dom_getComputedStyle(element);
  return /auto|scroll|overlay|hidden|clip/.test(overflow + overflowY + overflowX) && !invalidOverflowDisplayValues.has(display);
}
const tableElements = /*#__PURE__*/new Set(['table', 'td', 'th']);
function isTableElement(element) {
  return tableElements.has(getNodeName(element));
}
const topLayerSelectors = [':popover-open', ':modal'];
function isTopLayer(element) {
  return topLayerSelectors.some(selector => {
    try {
      return element.matches(selector);
    } catch (_e) {
      return false;
    }
  });
}
const transformProperties = ['transform', 'translate', 'scale', 'rotate', 'perspective'];
const willChangeValues = ['transform', 'translate', 'scale', 'rotate', 'perspective', 'filter'];
const containValues = ['paint', 'layout', 'strict', 'content'];
function isContainingBlock(elementOrCss) {
  const webkit = isWebKit();
  const css = isElement(elementOrCss) ? floating_ui_utils_dom_getComputedStyle(elementOrCss) : elementOrCss;

  // https://developer.mozilla.org/en-US/docs/Web/CSS/Containing_block#identifying_the_containing_block
  // https://drafts.csswg.org/css-transforms-2/#individual-transforms
  return transformProperties.some(value => css[value] ? css[value] !== 'none' : false) || (css.containerType ? css.containerType !== 'normal' : false) || !webkit && (css.backdropFilter ? css.backdropFilter !== 'none' : false) || !webkit && (css.filter ? css.filter !== 'none' : false) || willChangeValues.some(value => (css.willChange || '').includes(value)) || containValues.some(value => (css.contain || '').includes(value));
}
function getContainingBlock(element) {
  let currentNode = getParentNode(element);
  while (isHTMLElement(currentNode) && !isLastTraversableNode(currentNode)) {
    if (isContainingBlock(currentNode)) {
      return currentNode;
    } else if (isTopLayer(currentNode)) {
      return null;
    }
    currentNode = getParentNode(currentNode);
  }
  return null;
}
function isWebKit() {
  if (typeof CSS === 'undefined' || !CSS.supports) return false;
  return CSS.supports('-webkit-backdrop-filter', 'none');
}
const lastTraversableNodeNames = /*#__PURE__*/new Set(['html', 'body', '#document']);
function isLastTraversableNode(node) {
  return lastTraversableNodeNames.has(getNodeName(node));
}
function floating_ui_utils_dom_getComputedStyle(element) {
  return getWindow(element).getComputedStyle(element);
}
function getNodeScroll(element) {
  if (isElement(element)) {
    return {
      scrollLeft: element.scrollLeft,
      scrollTop: element.scrollTop
    };
  }
  return {
    scrollLeft: element.scrollX,
    scrollTop: element.scrollY
  };
}
function getParentNode(node) {
  if (getNodeName(node) === 'html') {
    return node;
  }
  const result =
  // Step into the shadow DOM of the parent of a slotted node.
  node.assignedSlot ||
  // DOM Element detected.
  node.parentNode ||
  // ShadowRoot detected.
  isShadowRoot(node) && node.host ||
  // Fallback.
  getDocumentElement(node);
  return isShadowRoot(result) ? result.host : result;
}
function getNearestOverflowAncestor(node) {
  const parentNode = getParentNode(node);
  if (isLastTraversableNode(parentNode)) {
    return node.ownerDocument ? node.ownerDocument.body : node.body;
  }
  if (isHTMLElement(parentNode) && isOverflowElement(parentNode)) {
    return parentNode;
  }
  return getNearestOverflowAncestor(parentNode);
}
function getOverflowAncestors(node, list, traverseIframes) {
  var _node$ownerDocument2;
  if (list === void 0) {
    list = [];
  }
  if (traverseIframes === void 0) {
    traverseIframes = true;
  }
  const scrollableAncestor = getNearestOverflowAncestor(node);
  const isBody = scrollableAncestor === ((_node$ownerDocument2 = node.ownerDocument) == null ? void 0 : _node$ownerDocument2.body);
  const win = getWindow(scrollableAncestor);
  if (isBody) {
    const frameElement = getFrameElement(win);
    return list.concat(win, win.visualViewport || [], isOverflowElement(scrollableAncestor) ? scrollableAncestor : [], frameElement && traverseIframes ? getOverflowAncestors(frameElement) : []);
  }
  return list.concat(scrollableAncestor, getOverflowAncestors(scrollableAncestor, [], traverseIframes));
}
function getFrameElement(win) {
  return win.parent && Object.getPrototypeOf(win.parent) ? win.frameElement : null;
}



;// CONCATENATED MODULE: ./node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs





function getCssDimensions(element) {
  const css = floating_ui_utils_dom_getComputedStyle(element);
  // In testing environments, the `width` and `height` properties are empty
  // strings for SVG elements, returning NaN. Fallback to `0` in this case.
  let width = parseFloat(css.width) || 0;
  let height = parseFloat(css.height) || 0;
  const hasOffset = isHTMLElement(element);
  const offsetWidth = hasOffset ? element.offsetWidth : width;
  const offsetHeight = hasOffset ? element.offsetHeight : height;
  const shouldFallback = round(width) !== offsetWidth || round(height) !== offsetHeight;
  if (shouldFallback) {
    width = offsetWidth;
    height = offsetHeight;
  }
  return {
    width,
    height,
    $: shouldFallback
  };
}

function unwrapElement(element) {
  return !isElement(element) ? element.contextElement : element;
}

function getScale(element) {
  const domElement = unwrapElement(element);
  if (!isHTMLElement(domElement)) {
    return createCoords(1);
  }
  const rect = domElement.getBoundingClientRect();
  const {
    width,
    height,
    $
  } = getCssDimensions(domElement);
  let x = ($ ? round(rect.width) : rect.width) / width;
  let y = ($ ? round(rect.height) : rect.height) / height;

  // 0, NaN, or Infinity should always fallback to 1.

  if (!x || !Number.isFinite(x)) {
    x = 1;
  }
  if (!y || !Number.isFinite(y)) {
    y = 1;
  }
  return {
    x,
    y
  };
}

const noOffsets = /*#__PURE__*/createCoords(0);
function getVisualOffsets(element) {
  const win = getWindow(element);
  if (!isWebKit() || !win.visualViewport) {
    return noOffsets;
  }
  return {
    x: win.visualViewport.offsetLeft,
    y: win.visualViewport.offsetTop
  };
}
function shouldAddVisualOffsets(element, isFixed, floatingOffsetParent) {
  if (isFixed === void 0) {
    isFixed = false;
  }
  if (!floatingOffsetParent || isFixed && floatingOffsetParent !== getWindow(element)) {
    return false;
  }
  return isFixed;
}

function getBoundingClientRect(element, includeScale, isFixedStrategy, offsetParent) {
  if (includeScale === void 0) {
    includeScale = false;
  }
  if (isFixedStrategy === void 0) {
    isFixedStrategy = false;
  }
  const clientRect = element.getBoundingClientRect();
  const domElement = unwrapElement(element);
  let scale = createCoords(1);
  if (includeScale) {
    if (offsetParent) {
      if (isElement(offsetParent)) {
        scale = getScale(offsetParent);
      }
    } else {
      scale = getScale(element);
    }
  }
  const visualOffsets = shouldAddVisualOffsets(domElement, isFixedStrategy, offsetParent) ? getVisualOffsets(domElement) : createCoords(0);
  let x = (clientRect.left + visualOffsets.x) / scale.x;
  let y = (clientRect.top + visualOffsets.y) / scale.y;
  let width = clientRect.width / scale.x;
  let height = clientRect.height / scale.y;
  if (domElement) {
    const win = getWindow(domElement);
    const offsetWin = offsetParent && isElement(offsetParent) ? getWindow(offsetParent) : offsetParent;
    let currentWin = win;
    let currentIFrame = getFrameElement(currentWin);
    while (currentIFrame && offsetParent && offsetWin !== currentWin) {
      const iframeScale = getScale(currentIFrame);
      const iframeRect = currentIFrame.getBoundingClientRect();
      const css = floating_ui_utils_dom_getComputedStyle(currentIFrame);
      const left = iframeRect.left + (currentIFrame.clientLeft + parseFloat(css.paddingLeft)) * iframeScale.x;
      const top = iframeRect.top + (currentIFrame.clientTop + parseFloat(css.paddingTop)) * iframeScale.y;
      x *= iframeScale.x;
      y *= iframeScale.y;
      width *= iframeScale.x;
      height *= iframeScale.y;
      x += left;
      y += top;
      currentWin = getWindow(currentIFrame);
      currentIFrame = getFrameElement(currentWin);
    }
  }
  return rectToClientRect({
    width,
    height,
    x,
    y
  });
}

// If <html> has a CSS width greater than the viewport, then this will be
// incorrect for RTL.
function getWindowScrollBarX(element, rect) {
  const leftScroll = getNodeScroll(element).scrollLeft;
  if (!rect) {
    return getBoundingClientRect(getDocumentElement(element)).left + leftScroll;
  }
  return rect.left + leftScroll;
}

function getHTMLOffset(documentElement, scroll) {
  const htmlRect = documentElement.getBoundingClientRect();
  const x = htmlRect.left + scroll.scrollLeft - getWindowScrollBarX(documentElement, htmlRect);
  const y = htmlRect.top + scroll.scrollTop;
  return {
    x,
    y
  };
}

function convertOffsetParentRelativeRectToViewportRelativeRect(_ref) {
  let {
    elements,
    rect,
    offsetParent,
    strategy
  } = _ref;
  const isFixed = strategy === 'fixed';
  const documentElement = getDocumentElement(offsetParent);
  const topLayer = elements ? isTopLayer(elements.floating) : false;
  if (offsetParent === documentElement || topLayer && isFixed) {
    return rect;
  }
  let scroll = {
    scrollLeft: 0,
    scrollTop: 0
  };
  let scale = createCoords(1);
  const offsets = createCoords(0);
  const isOffsetParentAnElement = isHTMLElement(offsetParent);
  if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
    if (getNodeName(offsetParent) !== 'body' || isOverflowElement(documentElement)) {
      scroll = getNodeScroll(offsetParent);
    }
    if (isHTMLElement(offsetParent)) {
      const offsetRect = getBoundingClientRect(offsetParent);
      scale = getScale(offsetParent);
      offsets.x = offsetRect.x + offsetParent.clientLeft;
      offsets.y = offsetRect.y + offsetParent.clientTop;
    }
  }
  const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
  return {
    width: rect.width * scale.x,
    height: rect.height * scale.y,
    x: rect.x * scale.x - scroll.scrollLeft * scale.x + offsets.x + htmlOffset.x,
    y: rect.y * scale.y - scroll.scrollTop * scale.y + offsets.y + htmlOffset.y
  };
}

function getClientRects(element) {
  return Array.from(element.getClientRects());
}

// Gets the entire size of the scrollable document area, even extending outside
// of the `<html>` and `<body>` rect bounds if horizontally scrollable.
function getDocumentRect(element) {
  const html = getDocumentElement(element);
  const scroll = getNodeScroll(element);
  const body = element.ownerDocument.body;
  const width = max(html.scrollWidth, html.clientWidth, body.scrollWidth, body.clientWidth);
  const height = max(html.scrollHeight, html.clientHeight, body.scrollHeight, body.clientHeight);
  let x = -scroll.scrollLeft + getWindowScrollBarX(element);
  const y = -scroll.scrollTop;
  if (floating_ui_utils_dom_getComputedStyle(body).direction === 'rtl') {
    x += max(html.clientWidth, body.clientWidth) - width;
  }
  return {
    width,
    height,
    x,
    y
  };
}

// Safety check: ensure the scrollbar space is reasonable in case this
// calculation is affected by unusual styles.
// Most scrollbars leave 15-18px of space.
const SCROLLBAR_MAX = 25;
function getViewportRect(element, strategy) {
  const win = getWindow(element);
  const html = getDocumentElement(element);
  const visualViewport = win.visualViewport;
  let width = html.clientWidth;
  let height = html.clientHeight;
  let x = 0;
  let y = 0;
  if (visualViewport) {
    width = visualViewport.width;
    height = visualViewport.height;
    const visualViewportBased = isWebKit();
    if (!visualViewportBased || visualViewportBased && strategy === 'fixed') {
      x = visualViewport.offsetLeft;
      y = visualViewport.offsetTop;
    }
  }
  const windowScrollbarX = getWindowScrollBarX(html);
  // <html> `overflow: hidden` + `scrollbar-gutter: stable` reduces the
  // visual width of the <html> but this is not considered in the size
  // of `html.clientWidth`.
  if (windowScrollbarX <= 0) {
    const doc = html.ownerDocument;
    const body = doc.body;
    const bodyStyles = getComputedStyle(body);
    const bodyMarginInline = doc.compatMode === 'CSS1Compat' ? parseFloat(bodyStyles.marginLeft) + parseFloat(bodyStyles.marginRight) || 0 : 0;
    const clippingStableScrollbarWidth = Math.abs(html.clientWidth - body.clientWidth - bodyMarginInline);
    if (clippingStableScrollbarWidth <= SCROLLBAR_MAX) {
      width -= clippingStableScrollbarWidth;
    }
  } else if (windowScrollbarX <= SCROLLBAR_MAX) {
    // If the <body> scrollbar is on the left, the width needs to be extended
    // by the scrollbar amount so there isn't extra space on the right.
    width += windowScrollbarX;
  }
  return {
    width,
    height,
    x,
    y
  };
}

const absoluteOrFixed = /*#__PURE__*/new Set(['absolute', 'fixed']);
// Returns the inner client rect, subtracting scrollbars if present.
function getInnerBoundingClientRect(element, strategy) {
  const clientRect = getBoundingClientRect(element, true, strategy === 'fixed');
  const top = clientRect.top + element.clientTop;
  const left = clientRect.left + element.clientLeft;
  const scale = isHTMLElement(element) ? getScale(element) : createCoords(1);
  const width = element.clientWidth * scale.x;
  const height = element.clientHeight * scale.y;
  const x = left * scale.x;
  const y = top * scale.y;
  return {
    width,
    height,
    x,
    y
  };
}
function getClientRectFromClippingAncestor(element, clippingAncestor, strategy) {
  let rect;
  if (clippingAncestor === 'viewport') {
    rect = getViewportRect(element, strategy);
  } else if (clippingAncestor === 'document') {
    rect = getDocumentRect(getDocumentElement(element));
  } else if (isElement(clippingAncestor)) {
    rect = getInnerBoundingClientRect(clippingAncestor, strategy);
  } else {
    const visualOffsets = getVisualOffsets(element);
    rect = {
      x: clippingAncestor.x - visualOffsets.x,
      y: clippingAncestor.y - visualOffsets.y,
      width: clippingAncestor.width,
      height: clippingAncestor.height
    };
  }
  return rectToClientRect(rect);
}
function hasFixedPositionAncestor(element, stopNode) {
  const parentNode = getParentNode(element);
  if (parentNode === stopNode || !isElement(parentNode) || isLastTraversableNode(parentNode)) {
    return false;
  }
  return floating_ui_utils_dom_getComputedStyle(parentNode).position === 'fixed' || hasFixedPositionAncestor(parentNode, stopNode);
}

// A "clipping ancestor" is an `overflow` element with the characteristic of
// clipping (or hiding) child elements. This returns all clipping ancestors
// of the given element up the tree.
function getClippingElementAncestors(element, cache) {
  const cachedResult = cache.get(element);
  if (cachedResult) {
    return cachedResult;
  }
  let result = getOverflowAncestors(element, [], false).filter(el => isElement(el) && getNodeName(el) !== 'body');
  let currentContainingBlockComputedStyle = null;
  const elementIsFixed = floating_ui_utils_dom_getComputedStyle(element).position === 'fixed';
  let currentNode = elementIsFixed ? getParentNode(element) : element;

  // https://developer.mozilla.org/en-US/docs/Web/CSS/Containing_block#identifying_the_containing_block
  while (isElement(currentNode) && !isLastTraversableNode(currentNode)) {
    const computedStyle = floating_ui_utils_dom_getComputedStyle(currentNode);
    const currentNodeIsContaining = isContainingBlock(currentNode);
    if (!currentNodeIsContaining && computedStyle.position === 'fixed') {
      currentContainingBlockComputedStyle = null;
    }
    const shouldDropCurrentNode = elementIsFixed ? !currentNodeIsContaining && !currentContainingBlockComputedStyle : !currentNodeIsContaining && computedStyle.position === 'static' && !!currentContainingBlockComputedStyle && absoluteOrFixed.has(currentContainingBlockComputedStyle.position) || isOverflowElement(currentNode) && !currentNodeIsContaining && hasFixedPositionAncestor(element, currentNode);
    if (shouldDropCurrentNode) {
      // Drop non-containing blocks.
      result = result.filter(ancestor => ancestor !== currentNode);
    } else {
      // Record last containing block for next iteration.
      currentContainingBlockComputedStyle = computedStyle;
    }
    currentNode = getParentNode(currentNode);
  }
  cache.set(element, result);
  return result;
}

// Gets the maximum area that the element is visible in due to any number of
// clipping ancestors.
function getClippingRect(_ref) {
  let {
    element,
    boundary,
    rootBoundary,
    strategy
  } = _ref;
  const elementClippingAncestors = boundary === 'clippingAncestors' ? isTopLayer(element) ? [] : getClippingElementAncestors(element, this._c) : [].concat(boundary);
  const clippingAncestors = [...elementClippingAncestors, rootBoundary];
  const firstClippingAncestor = clippingAncestors[0];
  const clippingRect = clippingAncestors.reduce((accRect, clippingAncestor) => {
    const rect = getClientRectFromClippingAncestor(element, clippingAncestor, strategy);
    accRect.top = max(rect.top, accRect.top);
    accRect.right = min(rect.right, accRect.right);
    accRect.bottom = min(rect.bottom, accRect.bottom);
    accRect.left = max(rect.left, accRect.left);
    return accRect;
  }, getClientRectFromClippingAncestor(element, firstClippingAncestor, strategy));
  return {
    width: clippingRect.right - clippingRect.left,
    height: clippingRect.bottom - clippingRect.top,
    x: clippingRect.left,
    y: clippingRect.top
  };
}

function getDimensions(element) {
  const {
    width,
    height
  } = getCssDimensions(element);
  return {
    width,
    height
  };
}

function getRectRelativeToOffsetParent(element, offsetParent, strategy) {
  const isOffsetParentAnElement = isHTMLElement(offsetParent);
  const documentElement = getDocumentElement(offsetParent);
  const isFixed = strategy === 'fixed';
  const rect = getBoundingClientRect(element, true, isFixed, offsetParent);
  let scroll = {
    scrollLeft: 0,
    scrollTop: 0
  };
  const offsets = createCoords(0);

  // If the <body> scrollbar appears on the left (e.g. RTL systems). Use
  // Firefox with layout.scrollbar.side = 3 in about:config to test this.
  function setLeftRTLScrollbarOffset() {
    offsets.x = getWindowScrollBarX(documentElement);
  }
  if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
    if (getNodeName(offsetParent) !== 'body' || isOverflowElement(documentElement)) {
      scroll = getNodeScroll(offsetParent);
    }
    if (isOffsetParentAnElement) {
      const offsetRect = getBoundingClientRect(offsetParent, true, isFixed, offsetParent);
      offsets.x = offsetRect.x + offsetParent.clientLeft;
      offsets.y = offsetRect.y + offsetParent.clientTop;
    } else if (documentElement) {
      setLeftRTLScrollbarOffset();
    }
  }
  if (isFixed && !isOffsetParentAnElement && documentElement) {
    setLeftRTLScrollbarOffset();
  }
  const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
  const x = rect.left + scroll.scrollLeft - offsets.x - htmlOffset.x;
  const y = rect.top + scroll.scrollTop - offsets.y - htmlOffset.y;
  return {
    x,
    y,
    width: rect.width,
    height: rect.height
  };
}

function isStaticPositioned(element) {
  return floating_ui_utils_dom_getComputedStyle(element).position === 'static';
}

function getTrueOffsetParent(element, polyfill) {
  if (!isHTMLElement(element) || floating_ui_utils_dom_getComputedStyle(element).position === 'fixed') {
    return null;
  }
  if (polyfill) {
    return polyfill(element);
  }
  let rawOffsetParent = element.offsetParent;

  // Firefox returns the <html> element as the offsetParent if it's non-static,
  // while Chrome and Safari return the <body> element. The <body> element must
  // be used to perform the correct calculations even if the <html> element is
  // non-static.
  if (getDocumentElement(element) === rawOffsetParent) {
    rawOffsetParent = rawOffsetParent.ownerDocument.body;
  }
  return rawOffsetParent;
}

// Gets the closest ancestor positioned element. Handles some edge cases,
// such as table ancestors and cross browser bugs.
function getOffsetParent(element, polyfill) {
  const win = getWindow(element);
  if (isTopLayer(element)) {
    return win;
  }
  if (!isHTMLElement(element)) {
    let svgOffsetParent = getParentNode(element);
    while (svgOffsetParent && !isLastTraversableNode(svgOffsetParent)) {
      if (isElement(svgOffsetParent) && !isStaticPositioned(svgOffsetParent)) {
        return svgOffsetParent;
      }
      svgOffsetParent = getParentNode(svgOffsetParent);
    }
    return win;
  }
  let offsetParent = getTrueOffsetParent(element, polyfill);
  while (offsetParent && isTableElement(offsetParent) && isStaticPositioned(offsetParent)) {
    offsetParent = getTrueOffsetParent(offsetParent, polyfill);
  }
  if (offsetParent && isLastTraversableNode(offsetParent) && isStaticPositioned(offsetParent) && !isContainingBlock(offsetParent)) {
    return win;
  }
  return offsetParent || getContainingBlock(element) || win;
}

const getElementRects = async function (data) {
  const getOffsetParentFn = this.getOffsetParent || getOffsetParent;
  const getDimensionsFn = this.getDimensions;
  const floatingDimensions = await getDimensionsFn(data.floating);
  return {
    reference: getRectRelativeToOffsetParent(data.reference, await getOffsetParentFn(data.floating), data.strategy),
    floating: {
      x: 0,
      y: 0,
      width: floatingDimensions.width,
      height: floatingDimensions.height
    }
  };
};

function isRTL(element) {
  return floating_ui_utils_dom_getComputedStyle(element).direction === 'rtl';
}

const platform = {
  convertOffsetParentRelativeRectToViewportRelativeRect,
  getDocumentElement: getDocumentElement,
  getClippingRect,
  getOffsetParent,
  getElementRects,
  getClientRects,
  getDimensions,
  getScale,
  isElement: isElement,
  isRTL
};

function rectsAreEqual(a, b) {
  return a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height;
}

// https://samthor.au/2021/observing-dom/
function observeMove(element, onMove) {
  let io = null;
  let timeoutId;
  const root = getDocumentElement(element);
  function cleanup() {
    var _io;
    clearTimeout(timeoutId);
    (_io = io) == null || _io.disconnect();
    io = null;
  }
  function refresh(skip, threshold) {
    if (skip === void 0) {
      skip = false;
    }
    if (threshold === void 0) {
      threshold = 1;
    }
    cleanup();
    const elementRectForRootMargin = element.getBoundingClientRect();
    const {
      left,
      top,
      width,
      height
    } = elementRectForRootMargin;
    if (!skip) {
      onMove();
    }
    if (!width || !height) {
      return;
    }
    const insetTop = floor(top);
    const insetRight = floor(root.clientWidth - (left + width));
    const insetBottom = floor(root.clientHeight - (top + height));
    const insetLeft = floor(left);
    const rootMargin = -insetTop + "px " + -insetRight + "px " + -insetBottom + "px " + -insetLeft + "px";
    const options = {
      rootMargin,
      threshold: max(0, min(1, threshold)) || 1
    };
    let isFirstUpdate = true;
    function handleObserve(entries) {
      const ratio = entries[0].intersectionRatio;
      if (ratio !== threshold) {
        if (!isFirstUpdate) {
          return refresh();
        }
        if (!ratio) {
          // If the reference is clipped, the ratio is 0. Throttle the refresh
          // to prevent an infinite loop of updates.
          timeoutId = setTimeout(() => {
            refresh(false, 1e-7);
          }, 1000);
        } else {
          refresh(false, ratio);
        }
      }
      if (ratio === 1 && !rectsAreEqual(elementRectForRootMargin, element.getBoundingClientRect())) {
        // It's possible that even though the ratio is reported as 1, the
        // element is not actually fully within the IntersectionObserver's root
        // area anymore. This can happen under performance constraints. This may
        // be a bug in the browser's IntersectionObserver implementation. To
        // work around this, we compare the element's bounding rect now with
        // what it was at the time we created the IntersectionObserver. If they
        // are not equal then the element moved, so we refresh.
        refresh();
      }
      isFirstUpdate = false;
    }

    // Older browsers don't support a `document` as the root and will throw an
    // error.
    try {
      io = new IntersectionObserver(handleObserve, {
        ...options,
        // Handle <iframe>s
        root: root.ownerDocument
      });
    } catch (_e) {
      io = new IntersectionObserver(handleObserve, options);
    }
    io.observe(element);
  }
  refresh(true);
  return cleanup;
}

/**
 * Automatically updates the position of the floating element when necessary.
 * Should only be called when the floating element is mounted on the DOM or
 * visible on the screen.
 * @returns cleanup function that should be invoked when the floating element is
 * removed from the DOM or hidden from the screen.
 * @see https://floating-ui.com/docs/autoUpdate
 */
function autoUpdate(reference, floating, update, options) {
  if (options === void 0) {
    options = {};
  }
  const {
    ancestorScroll = true,
    ancestorResize = true,
    elementResize = typeof ResizeObserver === 'function',
    layoutShift = typeof IntersectionObserver === 'function',
    animationFrame = false
  } = options;
  const referenceEl = unwrapElement(reference);
  const ancestors = ancestorScroll || ancestorResize ? [...(referenceEl ? getOverflowAncestors(referenceEl) : []), ...getOverflowAncestors(floating)] : [];
  ancestors.forEach(ancestor => {
    ancestorScroll && ancestor.addEventListener('scroll', update, {
      passive: true
    });
    ancestorResize && ancestor.addEventListener('resize', update);
  });
  const cleanupIo = referenceEl && layoutShift ? observeMove(referenceEl, update) : null;
  let reobserveFrame = -1;
  let resizeObserver = null;
  if (elementResize) {
    resizeObserver = new ResizeObserver(_ref => {
      let [firstEntry] = _ref;
      if (firstEntry && firstEntry.target === referenceEl && resizeObserver) {
        // Prevent update loops when using the `size` middleware.
        // https://github.com/floating-ui/floating-ui/issues/1740
        resizeObserver.unobserve(floating);
        cancelAnimationFrame(reobserveFrame);
        reobserveFrame = requestAnimationFrame(() => {
          var _resizeObserver;
          (_resizeObserver = resizeObserver) == null || _resizeObserver.observe(floating);
        });
      }
      update();
    });
    if (referenceEl && !animationFrame) {
      resizeObserver.observe(referenceEl);
    }
    resizeObserver.observe(floating);
  }
  let frameId;
  let prevRefRect = animationFrame ? getBoundingClientRect(reference) : null;
  if (animationFrame) {
    frameLoop();
  }
  function frameLoop() {
    const nextRefRect = getBoundingClientRect(reference);
    if (prevRefRect && !rectsAreEqual(prevRefRect, nextRefRect)) {
      update();
    }
    prevRefRect = nextRefRect;
    frameId = requestAnimationFrame(frameLoop);
  }
  update();
  return () => {
    var _resizeObserver2;
    ancestors.forEach(ancestor => {
      ancestorScroll && ancestor.removeEventListener('scroll', update);
      ancestorResize && ancestor.removeEventListener('resize', update);
    });
    cleanupIo == null || cleanupIo();
    (_resizeObserver2 = resizeObserver) == null || _resizeObserver2.disconnect();
    resizeObserver = null;
    if (animationFrame) {
      cancelAnimationFrame(frameId);
    }
  };
}

/**
 * Resolves with an object of overflow side offsets that determine how much the
 * element is overflowing a given clipping boundary on each side.
 * - positive = overflowing the boundary by that number of pixels
 * - negative = how many pixels left before it will overflow
 * - 0 = lies flush with the boundary
 * @see https://floating-ui.com/docs/detectOverflow
 */
const detectOverflow = (/* unused pure expression or super */ null && (detectOverflow$1));

/**
 * Modifies the placement by translating the floating element along the
 * specified axes.
 * A number (shorthand for `mainAxis` or distance), or an axes configuration
 * object may be passed.
 * @see https://floating-ui.com/docs/offset
 */
const offset = (/* unused pure expression or super */ null && (offset$1));

/**
 * Optimizes the visibility of the floating element by choosing the placement
 * that has the most space available automatically, without needing to specify a
 * preferred placement. Alternative to `flip`.
 * @see https://floating-ui.com/docs/autoPlacement
 */
const autoPlacement = (/* unused pure expression or super */ null && (autoPlacement$1));

/**
 * Optimizes the visibility of the floating element by shifting it in order to
 * keep it in view when it will overflow the clipping boundary.
 * @see https://floating-ui.com/docs/shift
 */
const shift = (/* unused pure expression or super */ null && (shift$1));

/**
 * Optimizes the visibility of the floating element by flipping the `placement`
 * in order to keep it in view when the preferred placement(s) will overflow the
 * clipping boundary. Alternative to `autoPlacement`.
 * @see https://floating-ui.com/docs/flip
 */
const flip = (/* unused pure expression or super */ null && (flip$1));

/**
 * Provides data that allows you to change the size of the floating element —
 * for instance, prevent it from overflowing the clipping boundary or match the
 * width of the reference element.
 * @see https://floating-ui.com/docs/size
 */
const size = (/* unused pure expression or super */ null && (size$1));

/**
 * Provides data to hide the floating element in applicable situations, such as
 * when it is not in the same clipping context as the reference element.
 * @see https://floating-ui.com/docs/hide
 */
const hide = (/* unused pure expression or super */ null && (hide$1));

/**
 * Provides data to position an inner element of the floating element so that it
 * appears centered to the reference element.
 * @see https://floating-ui.com/docs/arrow
 */
const arrow = (/* unused pure expression or super */ null && (arrow$1));

/**
 * Provides improved positioning for inline reference elements that can span
 * over multiple lines, such as hyperlinks or range selections.
 * @see https://floating-ui.com/docs/inline
 */
const inline = (/* unused pure expression or super */ null && (inline$1));

/**
 * Built-in `limiter` that will stop `shift()` at a certain point.
 */
const limitShift = (/* unused pure expression or super */ null && (limitShift$1));

/**
 * Computes the `x` and `y` coordinates that will place the floating element
 * next to a given reference element.
 */
const computePosition = (reference, floating, options) => {
  // This caches the expensive `getClippingElementAncestors` function so that
  // multiple lifecycle resets re-use the same result. It only lives for a
  // single call. If other functions become expensive, we can add them as well.
  const cache = new Map();
  const mergedOptions = {
    platform,
    ...options
  };
  const platformWithCache = {
    ...mergedOptions.platform,
    _c: cache
  };
  return computePosition$1(reference, floating, {
    ...mergedOptions,
    platform: platformWithCache
  });
};



;// CONCATENATED MODULE: ./node_modules/use-isomorphic-layout-effect/dist/use-isomorphic-layout-effect.browser.esm.js


var index = react.useLayoutEffect ;



;// CONCATENATED MODULE: ./node_modules/react-select/dist/index-641ee5b8.esm.js













var _excluded$4 = ["className", "clearValue", "cx", "getStyles", "getClassNames", "getValue", "hasValue", "isMulti", "isRtl", "options", "selectOption", "selectProps", "setValue", "theme"];
// ==============================
// NO OP
// ==============================

var noop = function noop() {};

// ==============================
// Class Name Prefixer
// ==============================

/**
 String representation of component state for styling with class names.

 Expects an array of strings OR a string/object pair:
 - className(['comp', 'comp-arg', 'comp-arg-2'])
   @returns 'react-select__comp react-select__comp-arg react-select__comp-arg-2'
 - className('comp', { some: true, state: false })
   @returns 'react-select__comp react-select__comp--some'
*/
function applyPrefixToName(prefix, name) {
  if (!name) {
    return prefix;
  } else if (name[0] === '-') {
    return prefix + name;
  } else {
    return prefix + '__' + name;
  }
}
function classNames(prefix, state) {
  for (var _len = arguments.length, classNameList = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
    classNameList[_key - 2] = arguments[_key];
  }
  var arr = [].concat(classNameList);
  if (state && prefix) {
    for (var key in state) {
      if (state.hasOwnProperty(key) && state[key]) {
        arr.push("".concat(applyPrefixToName(prefix, key)));
      }
    }
  }
  return arr.filter(function (i) {
    return i;
  }).map(function (i) {
    return String(i).trim();
  }).join(' ');
}
// ==============================
// Clean Value
// ==============================

var cleanValue = function cleanValue(value) {
  if (isArray(value)) return value.filter(Boolean);
  if (_typeof(value) === 'object' && value !== null) return [value];
  return [];
};

// ==============================
// Clean Common Props
// ==============================

var cleanCommonProps = function cleanCommonProps(props) {
  //className
  props.className;
    props.clearValue;
    props.cx;
    props.getStyles;
    props.getClassNames;
    props.getValue;
    props.hasValue;
    props.isMulti;
    props.isRtl;
    props.options;
    props.selectOption;
    props.selectProps;
    props.setValue;
    props.theme;
    var innerProps = _objectWithoutProperties(props, _excluded$4);
  return objectSpread2_objectSpread2({}, innerProps);
};

// ==============================
// Get Style Props
// ==============================

var getStyleProps = function getStyleProps(props, name, classNamesState) {
  var cx = props.cx,
    getStyles = props.getStyles,
    getClassNames = props.getClassNames,
    className = props.className;
  return {
    css: getStyles(name, props),
    className: cx(classNamesState !== null && classNamesState !== void 0 ? classNamesState : {}, getClassNames(name, props), className)
  };
};

// ==============================
// Handle Input Change
// ==============================

function handleInputChange(inputValue, actionMeta, onInputChange) {
  if (onInputChange) {
    var _newValue = onInputChange(inputValue, actionMeta);
    if (typeof _newValue === 'string') return _newValue;
  }
  return inputValue;
}

// ==============================
// Scroll Helpers
// ==============================

function isDocumentElement(el) {
  return [document.documentElement, document.body, window].indexOf(el) > -1;
}

// Normalized Scroll Top
// ------------------------------

function normalizedHeight(el) {
  if (isDocumentElement(el)) {
    return window.innerHeight;
  }
  return el.clientHeight;
}

// Normalized scrollTo & scrollTop
// ------------------------------

function getScrollTop(el) {
  if (isDocumentElement(el)) {
    return window.pageYOffset;
  }
  return el.scrollTop;
}
function scrollTo(el, top) {
  // with a scroll distance, we perform scroll on the element
  if (isDocumentElement(el)) {
    window.scrollTo(0, top);
    return;
  }
  el.scrollTop = top;
}

// Get Scroll Parent
// ------------------------------

function getScrollParent(element) {
  var style = getComputedStyle(element);
  var excludeStaticParent = style.position === 'absolute';
  var overflowRx = /(auto|scroll)/;
  if (style.position === 'fixed') return document.documentElement;
  for (var parent = element; parent = parent.parentElement;) {
    style = getComputedStyle(parent);
    if (excludeStaticParent && style.position === 'static') {
      continue;
    }
    if (overflowRx.test(style.overflow + style.overflowY + style.overflowX)) {
      return parent;
    }
  }
  return document.documentElement;
}

// Animated Scroll To
// ------------------------------

/**
  @param t: time (elapsed)
  @param b: initial value
  @param c: amount of change
  @param d: duration
*/
function easeOutCubic(t, b, c, d) {
  return c * ((t = t / d - 1) * t * t + 1) + b;
}
function animatedScrollTo(element, to) {
  var duration = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 200;
  var callback = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : noop;
  var start = getScrollTop(element);
  var change = to - start;
  var increment = 10;
  var currentTime = 0;
  function animateScroll() {
    currentTime += increment;
    var val = easeOutCubic(currentTime, start, change, duration);
    scrollTo(element, val);
    if (currentTime < duration) {
      window.requestAnimationFrame(animateScroll);
    } else {
      callback(element);
    }
  }
  animateScroll();
}

// Scroll Into View
// ------------------------------

function scrollIntoView(menuEl, focusedEl) {
  var menuRect = menuEl.getBoundingClientRect();
  var focusedRect = focusedEl.getBoundingClientRect();
  var overScroll = focusedEl.offsetHeight / 3;
  if (focusedRect.bottom + overScroll > menuRect.bottom) {
    scrollTo(menuEl, Math.min(focusedEl.offsetTop + focusedEl.clientHeight - menuEl.offsetHeight + overScroll, menuEl.scrollHeight));
  } else if (focusedRect.top - overScroll < menuRect.top) {
    scrollTo(menuEl, Math.max(focusedEl.offsetTop - overScroll, 0));
  }
}

// ==============================
// Get bounding client object
// ==============================

// cannot get keys using array notation with DOMRect
function getBoundingClientObj(element) {
  var rect = element.getBoundingClientRect();
  return {
    bottom: rect.bottom,
    height: rect.height,
    left: rect.left,
    right: rect.right,
    top: rect.top,
    width: rect.width
  };
}

// ==============================
// Touch Capability Detector
// ==============================

function isTouchCapable() {
  try {
    document.createEvent('TouchEvent');
    return true;
  } catch (e) {
    return false;
  }
}

// ==============================
// Mobile Device Detector
// ==============================

function isMobileDevice() {
  try {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  } catch (e) {
    return false;
  }
}

// ==============================
// Passive Event Detector
// ==============================

// https://github.com/rafgraph/detect-it/blob/main/src/index.ts#L19-L36
var passiveOptionAccessed = false;
var options = {
  get passive() {
    return passiveOptionAccessed = true;
  }
};
// check for SSR
var w = typeof window !== 'undefined' ? window : {};
if (w.addEventListener && w.removeEventListener) {
  w.addEventListener('p', noop, options);
  w.removeEventListener('p', noop, false);
}
var supportsPassiveEvents = passiveOptionAccessed;
function notNullish(item) {
  return item != null;
}
function isArray(arg) {
  return Array.isArray(arg);
}
function valueTernary(isMulti, multiValue, singleValue) {
  return isMulti ? multiValue : singleValue;
}
function singleValueAsValue(singleValue) {
  return singleValue;
}
function multiValueAsValue(multiValue) {
  return multiValue;
}
var removeProps = function removeProps(propsObj) {
  for (var _len2 = arguments.length, properties = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
    properties[_key2 - 1] = arguments[_key2];
  }
  var propsMap = Object.entries(propsObj).filter(function (_ref) {
    var _ref2 = _slicedToArray(_ref, 1),
      key = _ref2[0];
    return !properties.includes(key);
  });
  return propsMap.reduce(function (newProps, _ref3) {
    var _ref4 = _slicedToArray(_ref3, 2),
      key = _ref4[0],
      val = _ref4[1];
    newProps[key] = val;
    return newProps;
  }, {});
};

var _excluded$3 = ["children", "innerProps"],
  _excluded2$1 = ["children", "innerProps"];
function getMenuPlacement(_ref) {
  var preferredMaxHeight = _ref.maxHeight,
    menuEl = _ref.menuEl,
    minHeight = _ref.minHeight,
    preferredPlacement = _ref.placement,
    shouldScroll = _ref.shouldScroll,
    isFixedPosition = _ref.isFixedPosition,
    controlHeight = _ref.controlHeight;
  var scrollParent = getScrollParent(menuEl);
  var defaultState = {
    placement: 'bottom',
    maxHeight: preferredMaxHeight
  };

  // something went wrong, return default state
  if (!menuEl || !menuEl.offsetParent) return defaultState;

  // we can't trust `scrollParent.scrollHeight` --> it may increase when
  // the menu is rendered
  var _scrollParent$getBoun = scrollParent.getBoundingClientRect(),
    scrollHeight = _scrollParent$getBoun.height;
  var _menuEl$getBoundingCl = menuEl.getBoundingClientRect(),
    menuBottom = _menuEl$getBoundingCl.bottom,
    menuHeight = _menuEl$getBoundingCl.height,
    menuTop = _menuEl$getBoundingCl.top;
  var _menuEl$offsetParent$ = menuEl.offsetParent.getBoundingClientRect(),
    containerTop = _menuEl$offsetParent$.top;
  var viewHeight = isFixedPosition ? window.innerHeight : normalizedHeight(scrollParent);
  var scrollTop = getScrollTop(scrollParent);
  var marginBottom = parseInt(getComputedStyle(menuEl).marginBottom, 10);
  var marginTop = parseInt(getComputedStyle(menuEl).marginTop, 10);
  var viewSpaceAbove = containerTop - marginTop;
  var viewSpaceBelow = viewHeight - menuTop;
  var scrollSpaceAbove = viewSpaceAbove + scrollTop;
  var scrollSpaceBelow = scrollHeight - scrollTop - menuTop;
  var scrollDown = menuBottom - viewHeight + scrollTop + marginBottom;
  var scrollUp = scrollTop + menuTop - marginTop;
  var scrollDuration = 160;
  switch (preferredPlacement) {
    case 'auto':
    case 'bottom':
      // 1: the menu will fit, do nothing
      if (viewSpaceBelow >= menuHeight) {
        return {
          placement: 'bottom',
          maxHeight: preferredMaxHeight
        };
      }

      // 2: the menu will fit, if scrolled
      if (scrollSpaceBelow >= menuHeight && !isFixedPosition) {
        if (shouldScroll) {
          animatedScrollTo(scrollParent, scrollDown, scrollDuration);
        }
        return {
          placement: 'bottom',
          maxHeight: preferredMaxHeight
        };
      }

      // 3: the menu will fit, if constrained
      if (!isFixedPosition && scrollSpaceBelow >= minHeight || isFixedPosition && viewSpaceBelow >= minHeight) {
        if (shouldScroll) {
          animatedScrollTo(scrollParent, scrollDown, scrollDuration);
        }

        // we want to provide as much of the menu as possible to the user,
        // so give them whatever is available below rather than the minHeight.
        var constrainedHeight = isFixedPosition ? viewSpaceBelow - marginBottom : scrollSpaceBelow - marginBottom;
        return {
          placement: 'bottom',
          maxHeight: constrainedHeight
        };
      }

      // 4. Forked beviour when there isn't enough space below

      // AUTO: flip the menu, render above
      if (preferredPlacement === 'auto' || isFixedPosition) {
        // may need to be constrained after flipping
        var _constrainedHeight = preferredMaxHeight;
        var spaceAbove = isFixedPosition ? viewSpaceAbove : scrollSpaceAbove;
        if (spaceAbove >= minHeight) {
          _constrainedHeight = Math.min(spaceAbove - marginBottom - controlHeight, preferredMaxHeight);
        }
        return {
          placement: 'top',
          maxHeight: _constrainedHeight
        };
      }

      // BOTTOM: allow browser to increase scrollable area and immediately set scroll
      if (preferredPlacement === 'bottom') {
        if (shouldScroll) {
          scrollTo(scrollParent, scrollDown);
        }
        return {
          placement: 'bottom',
          maxHeight: preferredMaxHeight
        };
      }
      break;
    case 'top':
      // 1: the menu will fit, do nothing
      if (viewSpaceAbove >= menuHeight) {
        return {
          placement: 'top',
          maxHeight: preferredMaxHeight
        };
      }

      // 2: the menu will fit, if scrolled
      if (scrollSpaceAbove >= menuHeight && !isFixedPosition) {
        if (shouldScroll) {
          animatedScrollTo(scrollParent, scrollUp, scrollDuration);
        }
        return {
          placement: 'top',
          maxHeight: preferredMaxHeight
        };
      }

      // 3: the menu will fit, if constrained
      if (!isFixedPosition && scrollSpaceAbove >= minHeight || isFixedPosition && viewSpaceAbove >= minHeight) {
        var _constrainedHeight2 = preferredMaxHeight;

        // we want to provide as much of the menu as possible to the user,
        // so give them whatever is available below rather than the minHeight.
        if (!isFixedPosition && scrollSpaceAbove >= minHeight || isFixedPosition && viewSpaceAbove >= minHeight) {
          _constrainedHeight2 = isFixedPosition ? viewSpaceAbove - marginTop : scrollSpaceAbove - marginTop;
        }
        if (shouldScroll) {
          animatedScrollTo(scrollParent, scrollUp, scrollDuration);
        }
        return {
          placement: 'top',
          maxHeight: _constrainedHeight2
        };
      }

      // 4. not enough space, the browser WILL NOT increase scrollable area when
      // absolutely positioned element rendered above the viewport (only below).
      // Flip the menu, render below
      return {
        placement: 'bottom',
        maxHeight: preferredMaxHeight
      };
    default:
      throw new Error("Invalid placement provided \"".concat(preferredPlacement, "\"."));
  }
  return defaultState;
}

// Menu Component
// ------------------------------

function alignToControl(placement) {
  var placementToCSSProp = {
    bottom: 'top',
    top: 'bottom'
  };
  return placement ? placementToCSSProp[placement] : 'bottom';
}
var coercePlacement = function coercePlacement(p) {
  return p === 'auto' ? 'bottom' : p;
};
var menuCSS = function menuCSS(_ref2, unstyled) {
  var _objectSpread2;
  var placement = _ref2.placement,
    _ref2$theme = _ref2.theme,
    borderRadius = _ref2$theme.borderRadius,
    spacing = _ref2$theme.spacing,
    colors = _ref2$theme.colors;
  return objectSpread2_objectSpread2((_objectSpread2 = {
    label: 'menu'
  }, _defineProperty(_objectSpread2, alignToControl(placement), '100%'), _defineProperty(_objectSpread2, "position", 'absolute'), _defineProperty(_objectSpread2, "width", '100%'), _defineProperty(_objectSpread2, "zIndex", 1), _objectSpread2), unstyled ? {} : {
    backgroundColor: colors.neutral0,
    borderRadius: borderRadius,
    boxShadow: '0 0 0 1px hsla(0, 0%, 0%, 0.1), 0 4px 11px hsla(0, 0%, 0%, 0.1)',
    marginBottom: spacing.menuGutter,
    marginTop: spacing.menuGutter
  });
};
var PortalPlacementContext = /*#__PURE__*/(0,react.createContext)(null);

// NOTE: internal only
var MenuPlacer = function MenuPlacer(props) {
  var children = props.children,
    minMenuHeight = props.minMenuHeight,
    maxMenuHeight = props.maxMenuHeight,
    menuPlacement = props.menuPlacement,
    menuPosition = props.menuPosition,
    menuShouldScrollIntoView = props.menuShouldScrollIntoView,
    theme = props.theme;
  var _ref3 = (0,react.useContext)(PortalPlacementContext) || {},
    setPortalPlacement = _ref3.setPortalPlacement;
  var ref = (0,react.useRef)(null);
  var _useState = (0,react.useState)(maxMenuHeight),
    _useState2 = _slicedToArray(_useState, 2),
    maxHeight = _useState2[0],
    setMaxHeight = _useState2[1];
  var _useState3 = (0,react.useState)(null),
    _useState4 = _slicedToArray(_useState3, 2),
    placement = _useState4[0],
    setPlacement = _useState4[1];
  var controlHeight = theme.spacing.controlHeight;
  index(function () {
    var menuEl = ref.current;
    if (!menuEl) return;

    // DO NOT scroll if position is fixed
    var isFixedPosition = menuPosition === 'fixed';
    var shouldScroll = menuShouldScrollIntoView && !isFixedPosition;
    var state = getMenuPlacement({
      maxHeight: maxMenuHeight,
      menuEl: menuEl,
      minHeight: minMenuHeight,
      placement: menuPlacement,
      shouldScroll: shouldScroll,
      isFixedPosition: isFixedPosition,
      controlHeight: controlHeight
    });
    setMaxHeight(state.maxHeight);
    setPlacement(state.placement);
    setPortalPlacement === null || setPortalPlacement === void 0 ? void 0 : setPortalPlacement(state.placement);
  }, [maxMenuHeight, menuPlacement, menuPosition, menuShouldScrollIntoView, minMenuHeight, setPortalPlacement, controlHeight]);
  return children({
    ref: ref,
    placerProps: objectSpread2_objectSpread2(objectSpread2_objectSpread2({}, props), {}, {
      placement: placement || coercePlacement(menuPlacement),
      maxHeight: maxHeight
    })
  });
};
var Menu = function Menu(props) {
  var children = props.children,
    innerRef = props.innerRef,
    innerProps = props.innerProps;
  return jsx("div", extends_extends({}, getStyleProps(props, 'menu', {
    menu: true
  }), {
    ref: innerRef
  }, innerProps), children);
};
var Menu$1 = Menu;

// ==============================
// Menu List
// ==============================

var menuListCSS = function menuListCSS(_ref4, unstyled) {
  var maxHeight = _ref4.maxHeight,
    baseUnit = _ref4.theme.spacing.baseUnit;
  return objectSpread2_objectSpread2({
    maxHeight: maxHeight,
    overflowY: 'auto',
    position: 'relative',
    // required for offset[Height, Top] > keyboard scroll
    WebkitOverflowScrolling: 'touch'
  }, unstyled ? {} : {
    paddingBottom: baseUnit,
    paddingTop: baseUnit
  });
};
var MenuList = function MenuList(props) {
  var children = props.children,
    innerProps = props.innerProps,
    innerRef = props.innerRef,
    isMulti = props.isMulti;
  return jsx("div", extends_extends({}, getStyleProps(props, 'menuList', {
    'menu-list': true,
    'menu-list--is-multi': isMulti
  }), {
    ref: innerRef
  }, innerProps), children);
};

// ==============================
// Menu Notices
// ==============================

var noticeCSS = function noticeCSS(_ref5, unstyled) {
  var _ref5$theme = _ref5.theme,
    baseUnit = _ref5$theme.spacing.baseUnit,
    colors = _ref5$theme.colors;
  return objectSpread2_objectSpread2({
    textAlign: 'center'
  }, unstyled ? {} : {
    color: colors.neutral40,
    padding: "".concat(baseUnit * 2, "px ").concat(baseUnit * 3, "px")
  });
};
var noOptionsMessageCSS = noticeCSS;
var loadingMessageCSS = noticeCSS;
var NoOptionsMessage = function NoOptionsMessage(_ref6) {
  var _ref6$children = _ref6.children,
    children = _ref6$children === void 0 ? 'No options' : _ref6$children,
    innerProps = _ref6.innerProps,
    restProps = _objectWithoutProperties(_ref6, _excluded$3);
  return jsx("div", extends_extends({}, getStyleProps(objectSpread2_objectSpread2(objectSpread2_objectSpread2({}, restProps), {}, {
    children: children,
    innerProps: innerProps
  }), 'noOptionsMessage', {
    'menu-notice': true,
    'menu-notice--no-options': true
  }), innerProps), children);
};
var LoadingMessage = function LoadingMessage(_ref7) {
  var _ref7$children = _ref7.children,
    children = _ref7$children === void 0 ? 'Loading...' : _ref7$children,
    innerProps = _ref7.innerProps,
    restProps = _objectWithoutProperties(_ref7, _excluded2$1);
  return jsx("div", extends_extends({}, getStyleProps(objectSpread2_objectSpread2(objectSpread2_objectSpread2({}, restProps), {}, {
    children: children,
    innerProps: innerProps
  }), 'loadingMessage', {
    'menu-notice': true,
    'menu-notice--loading': true
  }), innerProps), children);
};

// ==============================
// Menu Portal
// ==============================

var menuPortalCSS = function menuPortalCSS(_ref8) {
  var rect = _ref8.rect,
    offset = _ref8.offset,
    position = _ref8.position;
  return {
    left: rect.left,
    position: position,
    top: offset,
    width: rect.width,
    zIndex: 1
  };
};
var MenuPortal = function MenuPortal(props) {
  var appendTo = props.appendTo,
    children = props.children,
    controlElement = props.controlElement,
    innerProps = props.innerProps,
    menuPlacement = props.menuPlacement,
    menuPosition = props.menuPosition;
  var menuPortalRef = (0,react.useRef)(null);
  var cleanupRef = (0,react.useRef)(null);
  var _useState5 = (0,react.useState)(coercePlacement(menuPlacement)),
    _useState6 = _slicedToArray(_useState5, 2),
    placement = _useState6[0],
    setPortalPlacement = _useState6[1];
  var portalPlacementContext = (0,react.useMemo)(function () {
    return {
      setPortalPlacement: setPortalPlacement
    };
  }, []);
  var _useState7 = (0,react.useState)(null),
    _useState8 = _slicedToArray(_useState7, 2),
    computedPosition = _useState8[0],
    setComputedPosition = _useState8[1];
  var updateComputedPosition = (0,react.useCallback)(function () {
    if (!controlElement) return;
    var rect = getBoundingClientObj(controlElement);
    var scrollDistance = menuPosition === 'fixed' ? 0 : window.pageYOffset;
    var offset = rect[placement] + scrollDistance;
    if (offset !== (computedPosition === null || computedPosition === void 0 ? void 0 : computedPosition.offset) || rect.left !== (computedPosition === null || computedPosition === void 0 ? void 0 : computedPosition.rect.left) || rect.width !== (computedPosition === null || computedPosition === void 0 ? void 0 : computedPosition.rect.width)) {
      setComputedPosition({
        offset: offset,
        rect: rect
      });
    }
  }, [controlElement, menuPosition, placement, computedPosition === null || computedPosition === void 0 ? void 0 : computedPosition.offset, computedPosition === null || computedPosition === void 0 ? void 0 : computedPosition.rect.left, computedPosition === null || computedPosition === void 0 ? void 0 : computedPosition.rect.width]);
  index(function () {
    updateComputedPosition();
  }, [updateComputedPosition]);
  var runAutoUpdate = (0,react.useCallback)(function () {
    if (typeof cleanupRef.current === 'function') {
      cleanupRef.current();
      cleanupRef.current = null;
    }
    if (controlElement && menuPortalRef.current) {
      cleanupRef.current = autoUpdate(controlElement, menuPortalRef.current, updateComputedPosition, {
        elementResize: 'ResizeObserver' in window
      });
    }
  }, [controlElement, updateComputedPosition]);
  index(function () {
    runAutoUpdate();
  }, [runAutoUpdate]);
  var setMenuPortalElement = (0,react.useCallback)(function (menuPortalElement) {
    menuPortalRef.current = menuPortalElement;
    runAutoUpdate();
  }, [runAutoUpdate]);

  // bail early if required elements aren't present
  if (!appendTo && menuPosition !== 'fixed' || !computedPosition) return null;

  // same wrapper element whether fixed or portalled
  var menuWrapper = jsx("div", extends_extends({
    ref: setMenuPortalElement
  }, getStyleProps(objectSpread2_objectSpread2(objectSpread2_objectSpread2({}, props), {}, {
    offset: computedPosition.offset,
    position: menuPosition,
    rect: computedPosition.rect
  }), 'menuPortal', {
    'menu-portal': true
  }), innerProps), children);
  return jsx(PortalPlacementContext.Provider, {
    value: portalPlacementContext
  }, appendTo ? /*#__PURE__*/(0,react_dom.createPortal)(menuWrapper, appendTo) : menuWrapper);
};

// ==============================
// Root Container
// ==============================

var containerCSS = function containerCSS(_ref) {
  var isDisabled = _ref.isDisabled,
    isRtl = _ref.isRtl;
  return {
    label: 'container',
    direction: isRtl ? 'rtl' : undefined,
    pointerEvents: isDisabled ? 'none' : undefined,
    // cancel mouse events when disabled
    position: 'relative'
  };
};
var SelectContainer = function SelectContainer(props) {
  var children = props.children,
    innerProps = props.innerProps,
    isDisabled = props.isDisabled,
    isRtl = props.isRtl;
  return jsx("div", extends_extends({}, getStyleProps(props, 'container', {
    '--is-disabled': isDisabled,
    '--is-rtl': isRtl
  }), innerProps), children);
};

// ==============================
// Value Container
// ==============================

var valueContainerCSS = function valueContainerCSS(_ref2, unstyled) {
  var spacing = _ref2.theme.spacing,
    isMulti = _ref2.isMulti,
    hasValue = _ref2.hasValue,
    controlShouldRenderValue = _ref2.selectProps.controlShouldRenderValue;
  return objectSpread2_objectSpread2({
    alignItems: 'center',
    display: isMulti && hasValue && controlShouldRenderValue ? 'flex' : 'grid',
    flex: 1,
    flexWrap: 'wrap',
    WebkitOverflowScrolling: 'touch',
    position: 'relative',
    overflow: 'hidden'
  }, unstyled ? {} : {
    padding: "".concat(spacing.baseUnit / 2, "px ").concat(spacing.baseUnit * 2, "px")
  });
};
var ValueContainer = function ValueContainer(props) {
  var children = props.children,
    innerProps = props.innerProps,
    isMulti = props.isMulti,
    hasValue = props.hasValue;
  return jsx("div", extends_extends({}, getStyleProps(props, 'valueContainer', {
    'value-container': true,
    'value-container--is-multi': isMulti,
    'value-container--has-value': hasValue
  }), innerProps), children);
};

// ==============================
// Indicator Container
// ==============================

var indicatorsContainerCSS = function indicatorsContainerCSS() {
  return {
    alignItems: 'center',
    alignSelf: 'stretch',
    display: 'flex',
    flexShrink: 0
  };
};
var IndicatorsContainer = function IndicatorsContainer(props) {
  var children = props.children,
    innerProps = props.innerProps;
  return jsx("div", extends_extends({}, getStyleProps(props, 'indicatorsContainer', {
    indicators: true
  }), innerProps), children);
};

var _templateObject;
var _excluded$2 = ["size"],
  _excluded2 = ["innerProps", "isRtl", "size"];
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; }

// ==============================
// Dropdown & Clear Icons
// ==============================
var _ref2 =  true ? {
  name: "8mmkcg",
  styles: "display:inline-block;fill:currentColor;line-height:1;stroke:currentColor;stroke-width:0"
} : 0;
var Svg = function Svg(_ref) {
  var size = _ref.size,
    props = _objectWithoutProperties(_ref, _excluded$2);
  return jsx("svg", extends_extends({
    height: size,
    width: size,
    viewBox: "0 0 20 20",
    "aria-hidden": "true",
    focusable: "false",
    css: _ref2
  }, props));
};
var CrossIcon = function CrossIcon(props) {
  return jsx(Svg, extends_extends({
    size: 20
  }, props), jsx("path", {
    d: "M14.348 14.849c-0.469 0.469-1.229 0.469-1.697 0l-2.651-3.030-2.651 3.029c-0.469 0.469-1.229 0.469-1.697 0-0.469-0.469-0.469-1.229 0-1.697l2.758-3.15-2.759-3.152c-0.469-0.469-0.469-1.228 0-1.697s1.228-0.469 1.697 0l2.652 3.031 2.651-3.031c0.469-0.469 1.228-0.469 1.697 0s0.469 1.229 0 1.697l-2.758 3.152 2.758 3.15c0.469 0.469 0.469 1.229 0 1.698z"
  }));
};
var DownChevron = function DownChevron(props) {
  return jsx(Svg, extends_extends({
    size: 20
  }, props), jsx("path", {
    d: "M4.516 7.548c0.436-0.446 1.043-0.481 1.576 0l3.908 3.747 3.908-3.747c0.533-0.481 1.141-0.446 1.574 0 0.436 0.445 0.408 1.197 0 1.615-0.406 0.418-4.695 4.502-4.695 4.502-0.217 0.223-0.502 0.335-0.787 0.335s-0.57-0.112-0.789-0.335c0 0-4.287-4.084-4.695-4.502s-0.436-1.17 0-1.615z"
  }));
};

// ==============================
// Dropdown & Clear Buttons
// ==============================

var baseCSS = function baseCSS(_ref3, unstyled) {
  var isFocused = _ref3.isFocused,
    _ref3$theme = _ref3.theme,
    baseUnit = _ref3$theme.spacing.baseUnit,
    colors = _ref3$theme.colors;
  return objectSpread2_objectSpread2({
    label: 'indicatorContainer',
    display: 'flex',
    transition: 'color 150ms'
  }, unstyled ? {} : {
    color: isFocused ? colors.neutral60 : colors.neutral20,
    padding: baseUnit * 2,
    ':hover': {
      color: isFocused ? colors.neutral80 : colors.neutral40
    }
  });
};
var dropdownIndicatorCSS = baseCSS;
var DropdownIndicator = function DropdownIndicator(props) {
  var children = props.children,
    innerProps = props.innerProps;
  return jsx("div", extends_extends({}, getStyleProps(props, 'dropdownIndicator', {
    indicator: true,
    'dropdown-indicator': true
  }), innerProps), children || jsx(DownChevron, null));
};
var clearIndicatorCSS = baseCSS;
var ClearIndicator = function ClearIndicator(props) {
  var children = props.children,
    innerProps = props.innerProps;
  return jsx("div", extends_extends({}, getStyleProps(props, 'clearIndicator', {
    indicator: true,
    'clear-indicator': true
  }), innerProps), children || jsx(CrossIcon, null));
};

// ==============================
// Separator
// ==============================

var indicatorSeparatorCSS = function indicatorSeparatorCSS(_ref4, unstyled) {
  var isDisabled = _ref4.isDisabled,
    _ref4$theme = _ref4.theme,
    baseUnit = _ref4$theme.spacing.baseUnit,
    colors = _ref4$theme.colors;
  return objectSpread2_objectSpread2({
    label: 'indicatorSeparator',
    alignSelf: 'stretch',
    width: 1
  }, unstyled ? {} : {
    backgroundColor: isDisabled ? colors.neutral10 : colors.neutral20,
    marginBottom: baseUnit * 2,
    marginTop: baseUnit * 2
  });
};
var IndicatorSeparator = function IndicatorSeparator(props) {
  var innerProps = props.innerProps;
  return jsx("span", extends_extends({}, innerProps, getStyleProps(props, 'indicatorSeparator', {
    'indicator-separator': true
  })));
};

// ==============================
// Loading
// ==============================

var loadingDotAnimations = keyframes(_templateObject || (_templateObject = _taggedTemplateLiteral(["\n  0%, 80%, 100% { opacity: 0; }\n  40% { opacity: 1; }\n"])));
var loadingIndicatorCSS = function loadingIndicatorCSS(_ref5, unstyled) {
  var isFocused = _ref5.isFocused,
    size = _ref5.size,
    _ref5$theme = _ref5.theme,
    colors = _ref5$theme.colors,
    baseUnit = _ref5$theme.spacing.baseUnit;
  return objectSpread2_objectSpread2({
    label: 'loadingIndicator',
    display: 'flex',
    transition: 'color 150ms',
    alignSelf: 'center',
    fontSize: size,
    lineHeight: 1,
    marginRight: size,
    textAlign: 'center',
    verticalAlign: 'middle'
  }, unstyled ? {} : {
    color: isFocused ? colors.neutral60 : colors.neutral20,
    padding: baseUnit * 2
  });
};
var LoadingDot = function LoadingDot(_ref6) {
  var delay = _ref6.delay,
    offset = _ref6.offset;
  return jsx("span", {
    css: /*#__PURE__*/css({
      animation: "".concat(loadingDotAnimations, " 1s ease-in-out ").concat(delay, "ms infinite;"),
      backgroundColor: 'currentColor',
      borderRadius: '1em',
      display: 'inline-block',
      marginLeft: offset ? '1em' : undefined,
      height: '1em',
      verticalAlign: 'top',
      width: '1em'
    },  true ? "" : 0,  true ? "" : 0)
  });
};
var LoadingIndicator = function LoadingIndicator(_ref7) {
  var innerProps = _ref7.innerProps,
    isRtl = _ref7.isRtl,
    _ref7$size = _ref7.size,
    size = _ref7$size === void 0 ? 4 : _ref7$size,
    restProps = _objectWithoutProperties(_ref7, _excluded2);
  return jsx("div", extends_extends({}, getStyleProps(objectSpread2_objectSpread2(objectSpread2_objectSpread2({}, restProps), {}, {
    innerProps: innerProps,
    isRtl: isRtl,
    size: size
  }), 'loadingIndicator', {
    indicator: true,
    'loading-indicator': true
  }), innerProps), jsx(LoadingDot, {
    delay: 0,
    offset: isRtl
  }), jsx(LoadingDot, {
    delay: 160,
    offset: true
  }), jsx(LoadingDot, {
    delay: 320,
    offset: !isRtl
  }));
};

var css$1 = function css(_ref, unstyled) {
  var isDisabled = _ref.isDisabled,
    isFocused = _ref.isFocused,
    _ref$theme = _ref.theme,
    colors = _ref$theme.colors,
    borderRadius = _ref$theme.borderRadius,
    spacing = _ref$theme.spacing;
  return objectSpread2_objectSpread2({
    label: 'control',
    alignItems: 'center',
    cursor: 'default',
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    minHeight: spacing.controlHeight,
    outline: '0 !important',
    position: 'relative',
    transition: 'all 100ms'
  }, unstyled ? {} : {
    backgroundColor: isDisabled ? colors.neutral5 : colors.neutral0,
    borderColor: isDisabled ? colors.neutral10 : isFocused ? colors.primary : colors.neutral20,
    borderRadius: borderRadius,
    borderStyle: 'solid',
    borderWidth: 1,
    boxShadow: isFocused ? "0 0 0 1px ".concat(colors.primary) : undefined,
    '&:hover': {
      borderColor: isFocused ? colors.primary : colors.neutral30
    }
  });
};
var Control = function Control(props) {
  var children = props.children,
    isDisabled = props.isDisabled,
    isFocused = props.isFocused,
    innerRef = props.innerRef,
    innerProps = props.innerProps,
    menuIsOpen = props.menuIsOpen;
  return jsx("div", extends_extends({
    ref: innerRef
  }, getStyleProps(props, 'control', {
    control: true,
    'control--is-disabled': isDisabled,
    'control--is-focused': isFocused,
    'control--menu-is-open': menuIsOpen
  }), innerProps, {
    "aria-disabled": isDisabled || undefined
  }), children);
};
var Control$1 = Control;

var _excluded$1 = ["data"];
var groupCSS = function groupCSS(_ref, unstyled) {
  var spacing = _ref.theme.spacing;
  return unstyled ? {} : {
    paddingBottom: spacing.baseUnit * 2,
    paddingTop: spacing.baseUnit * 2
  };
};
var Group = function Group(props) {
  var children = props.children,
    cx = props.cx,
    getStyles = props.getStyles,
    getClassNames = props.getClassNames,
    Heading = props.Heading,
    headingProps = props.headingProps,
    innerProps = props.innerProps,
    label = props.label,
    theme = props.theme,
    selectProps = props.selectProps;
  return jsx("div", extends_extends({}, getStyleProps(props, 'group', {
    group: true
  }), innerProps), jsx(Heading, extends_extends({}, headingProps, {
    selectProps: selectProps,
    theme: theme,
    getStyles: getStyles,
    getClassNames: getClassNames,
    cx: cx
  }), label), jsx("div", null, children));
};
var groupHeadingCSS = function groupHeadingCSS(_ref2, unstyled) {
  var _ref2$theme = _ref2.theme,
    colors = _ref2$theme.colors,
    spacing = _ref2$theme.spacing;
  return objectSpread2_objectSpread2({
    label: 'group',
    cursor: 'default',
    display: 'block'
  }, unstyled ? {} : {
    color: colors.neutral40,
    fontSize: '75%',
    fontWeight: 500,
    marginBottom: '0.25em',
    paddingLeft: spacing.baseUnit * 3,
    paddingRight: spacing.baseUnit * 3,
    textTransform: 'uppercase'
  });
};
var GroupHeading = function GroupHeading(props) {
  var _cleanCommonProps = cleanCommonProps(props);
    _cleanCommonProps.data;
    var innerProps = _objectWithoutProperties(_cleanCommonProps, _excluded$1);
  return jsx("div", extends_extends({}, getStyleProps(props, 'groupHeading', {
    'group-heading': true
  }), innerProps));
};
var Group$1 = Group;

var index_641ee5b8_esm_excluded = ["innerRef", "isDisabled", "isHidden", "inputClassName"];
var inputCSS = function inputCSS(_ref, unstyled) {
  var isDisabled = _ref.isDisabled,
    value = _ref.value,
    _ref$theme = _ref.theme,
    spacing = _ref$theme.spacing,
    colors = _ref$theme.colors;
  return objectSpread2_objectSpread2(objectSpread2_objectSpread2({
    visibility: isDisabled ? 'hidden' : 'visible',
    // force css to recompute when value change due to @emotion bug.
    // We can remove it whenever the bug is fixed.
    transform: value ? 'translateZ(0)' : ''
  }, containerStyle), unstyled ? {} : {
    margin: spacing.baseUnit / 2,
    paddingBottom: spacing.baseUnit / 2,
    paddingTop: spacing.baseUnit / 2,
    color: colors.neutral80
  });
};
var spacingStyle = {
  gridArea: '1 / 2',
  font: 'inherit',
  minWidth: '2px',
  border: 0,
  margin: 0,
  outline: 0,
  padding: 0
};
var containerStyle = {
  flex: '1 1 auto',
  display: 'inline-grid',
  gridArea: '1 / 1 / 2 / 3',
  gridTemplateColumns: '0 min-content',
  '&:after': objectSpread2_objectSpread2({
    content: 'attr(data-value) " "',
    visibility: 'hidden',
    whiteSpace: 'pre'
  }, spacingStyle)
};
var inputStyle = function inputStyle(isHidden) {
  return objectSpread2_objectSpread2({
    label: 'input',
    color: 'inherit',
    background: 0,
    opacity: isHidden ? 0 : 1,
    width: '100%'
  }, spacingStyle);
};
var Input = function Input(props) {
  var cx = props.cx,
    value = props.value;
  var _cleanCommonProps = cleanCommonProps(props),
    innerRef = _cleanCommonProps.innerRef,
    isDisabled = _cleanCommonProps.isDisabled,
    isHidden = _cleanCommonProps.isHidden,
    inputClassName = _cleanCommonProps.inputClassName,
    innerProps = _objectWithoutProperties(_cleanCommonProps, index_641ee5b8_esm_excluded);
  return jsx("div", extends_extends({}, getStyleProps(props, 'input', {
    'input-container': true
  }), {
    "data-value": value || ''
  }), jsx("input", extends_extends({
    className: cx({
      input: true
    }, inputClassName),
    ref: innerRef,
    style: inputStyle(isHidden),
    disabled: isDisabled
  }, innerProps)));
};
var Input$1 = Input;

var multiValueCSS = function multiValueCSS(_ref, unstyled) {
  var _ref$theme = _ref.theme,
    spacing = _ref$theme.spacing,
    borderRadius = _ref$theme.borderRadius,
    colors = _ref$theme.colors;
  return objectSpread2_objectSpread2({
    label: 'multiValue',
    display: 'flex',
    minWidth: 0
  }, unstyled ? {} : {
    backgroundColor: colors.neutral10,
    borderRadius: borderRadius / 2,
    margin: spacing.baseUnit / 2
  });
};
var multiValueLabelCSS = function multiValueLabelCSS(_ref2, unstyled) {
  var _ref2$theme = _ref2.theme,
    borderRadius = _ref2$theme.borderRadius,
    colors = _ref2$theme.colors,
    cropWithEllipsis = _ref2.cropWithEllipsis;
  return objectSpread2_objectSpread2({
    overflow: 'hidden',
    textOverflow: cropWithEllipsis || cropWithEllipsis === undefined ? 'ellipsis' : undefined,
    whiteSpace: 'nowrap'
  }, unstyled ? {} : {
    borderRadius: borderRadius / 2,
    color: colors.neutral80,
    fontSize: '85%',
    padding: 3,
    paddingLeft: 6
  });
};
var multiValueRemoveCSS = function multiValueRemoveCSS(_ref3, unstyled) {
  var _ref3$theme = _ref3.theme,
    spacing = _ref3$theme.spacing,
    borderRadius = _ref3$theme.borderRadius,
    colors = _ref3$theme.colors,
    isFocused = _ref3.isFocused;
  return objectSpread2_objectSpread2({
    alignItems: 'center',
    display: 'flex'
  }, unstyled ? {} : {
    borderRadius: borderRadius / 2,
    backgroundColor: isFocused ? colors.dangerLight : undefined,
    paddingLeft: spacing.baseUnit,
    paddingRight: spacing.baseUnit,
    ':hover': {
      backgroundColor: colors.dangerLight,
      color: colors.danger
    }
  });
};
var MultiValueGeneric = function MultiValueGeneric(_ref4) {
  var children = _ref4.children,
    innerProps = _ref4.innerProps;
  return jsx("div", innerProps, children);
};
var MultiValueContainer = MultiValueGeneric;
var MultiValueLabel = MultiValueGeneric;
function MultiValueRemove(_ref5) {
  var children = _ref5.children,
    innerProps = _ref5.innerProps;
  return jsx("div", extends_extends({
    role: "button"
  }, innerProps), children || jsx(CrossIcon, {
    size: 14
  }));
}
var MultiValue = function MultiValue(props) {
  var children = props.children,
    components = props.components,
    data = props.data,
    innerProps = props.innerProps,
    isDisabled = props.isDisabled,
    removeProps = props.removeProps,
    selectProps = props.selectProps;
  var Container = components.Container,
    Label = components.Label,
    Remove = components.Remove;
  return jsx(Container, {
    data: data,
    innerProps: objectSpread2_objectSpread2(objectSpread2_objectSpread2({}, getStyleProps(props, 'multiValue', {
      'multi-value': true,
      'multi-value--is-disabled': isDisabled
    })), innerProps),
    selectProps: selectProps
  }, jsx(Label, {
    data: data,
    innerProps: objectSpread2_objectSpread2({}, getStyleProps(props, 'multiValueLabel', {
      'multi-value__label': true
    })),
    selectProps: selectProps
  }, children), jsx(Remove, {
    data: data,
    innerProps: objectSpread2_objectSpread2(objectSpread2_objectSpread2({}, getStyleProps(props, 'multiValueRemove', {
      'multi-value__remove': true
    })), {}, {
      'aria-label': "Remove ".concat(children || 'option')
    }, removeProps),
    selectProps: selectProps
  }));
};
var MultiValue$1 = MultiValue;

var optionCSS = function optionCSS(_ref, unstyled) {
  var isDisabled = _ref.isDisabled,
    isFocused = _ref.isFocused,
    isSelected = _ref.isSelected,
    _ref$theme = _ref.theme,
    spacing = _ref$theme.spacing,
    colors = _ref$theme.colors;
  return objectSpread2_objectSpread2({
    label: 'option',
    cursor: 'default',
    display: 'block',
    fontSize: 'inherit',
    width: '100%',
    userSelect: 'none',
    WebkitTapHighlightColor: 'rgba(0, 0, 0, 0)'
  }, unstyled ? {} : {
    backgroundColor: isSelected ? colors.primary : isFocused ? colors.primary25 : 'transparent',
    color: isDisabled ? colors.neutral20 : isSelected ? colors.neutral0 : 'inherit',
    padding: "".concat(spacing.baseUnit * 2, "px ").concat(spacing.baseUnit * 3, "px"),
    // provide some affordance on touch devices
    ':active': {
      backgroundColor: !isDisabled ? isSelected ? colors.primary : colors.primary50 : undefined
    }
  });
};
var Option = function Option(props) {
  var children = props.children,
    isDisabled = props.isDisabled,
    isFocused = props.isFocused,
    isSelected = props.isSelected,
    innerRef = props.innerRef,
    innerProps = props.innerProps;
  return jsx("div", extends_extends({}, getStyleProps(props, 'option', {
    option: true,
    'option--is-disabled': isDisabled,
    'option--is-focused': isFocused,
    'option--is-selected': isSelected
  }), {
    ref: innerRef,
    "aria-disabled": isDisabled
  }, innerProps), children);
};
var Option$1 = Option;

var placeholderCSS = function placeholderCSS(_ref, unstyled) {
  var _ref$theme = _ref.theme,
    spacing = _ref$theme.spacing,
    colors = _ref$theme.colors;
  return objectSpread2_objectSpread2({
    label: 'placeholder',
    gridArea: '1 / 1 / 2 / 3'
  }, unstyled ? {} : {
    color: colors.neutral50,
    marginLeft: spacing.baseUnit / 2,
    marginRight: spacing.baseUnit / 2
  });
};
var Placeholder = function Placeholder(props) {
  var children = props.children,
    innerProps = props.innerProps;
  return jsx("div", extends_extends({}, getStyleProps(props, 'placeholder', {
    placeholder: true
  }), innerProps), children);
};
var Placeholder$1 = Placeholder;

var index_641ee5b8_esm_css = function css(_ref, unstyled) {
  var isDisabled = _ref.isDisabled,
    _ref$theme = _ref.theme,
    spacing = _ref$theme.spacing,
    colors = _ref$theme.colors;
  return objectSpread2_objectSpread2({
    label: 'singleValue',
    gridArea: '1 / 1 / 2 / 3',
    maxWidth: '100%',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap'
  }, unstyled ? {} : {
    color: isDisabled ? colors.neutral40 : colors.neutral80,
    marginLeft: spacing.baseUnit / 2,
    marginRight: spacing.baseUnit / 2
  });
};
var SingleValue = function SingleValue(props) {
  var children = props.children,
    isDisabled = props.isDisabled,
    innerProps = props.innerProps;
  return jsx("div", extends_extends({}, getStyleProps(props, 'singleValue', {
    'single-value': true,
    'single-value--is-disabled': isDisabled
  }), innerProps), children);
};
var SingleValue$1 = SingleValue;

var components = {
  ClearIndicator: ClearIndicator,
  Control: Control$1,
  DropdownIndicator: DropdownIndicator,
  DownChevron: DownChevron,
  CrossIcon: CrossIcon,
  Group: Group$1,
  GroupHeading: GroupHeading,
  IndicatorsContainer: IndicatorsContainer,
  IndicatorSeparator: IndicatorSeparator,
  Input: Input$1,
  LoadingIndicator: LoadingIndicator,
  Menu: Menu$1,
  MenuList: MenuList,
  MenuPortal: MenuPortal,
  LoadingMessage: LoadingMessage,
  NoOptionsMessage: NoOptionsMessage,
  MultiValue: MultiValue$1,
  MultiValueContainer: MultiValueContainer,
  MultiValueLabel: MultiValueLabel,
  MultiValueRemove: MultiValueRemove,
  Option: Option$1,
  Placeholder: Placeholder$1,
  SelectContainer: SelectContainer,
  SingleValue: SingleValue$1,
  ValueContainer: ValueContainer
};
var defaultComponents = function defaultComponents(props) {
  return objectSpread2_objectSpread2(objectSpread2_objectSpread2({}, components), props.components);
};



;// CONCATENATED MODULE: ./node_modules/memoize-one/dist/memoize-one.esm.js
var safeIsNaN = Number.isNaN ||
    function ponyfill(value) {
        return typeof value === 'number' && value !== value;
    };
function isEqual(first, second) {
    if (first === second) {
        return true;
    }
    if (safeIsNaN(first) && safeIsNaN(second)) {
        return true;
    }
    return false;
}
function areInputsEqual(newInputs, lastInputs) {
    if (newInputs.length !== lastInputs.length) {
        return false;
    }
    for (var i = 0; i < newInputs.length; i++) {
        if (!isEqual(newInputs[i], lastInputs[i])) {
            return false;
        }
    }
    return true;
}

function memoizeOne(resultFn, isEqual) {
    if (isEqual === void 0) { isEqual = areInputsEqual; }
    var cache = null;
    function memoized() {
        var newArgs = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            newArgs[_i] = arguments[_i];
        }
        if (cache && cache.lastThis === this && isEqual(newArgs, cache.lastArgs)) {
            return cache.lastResult;
        }
        var lastResult = resultFn.apply(this, newArgs);
        cache = {
            lastResult: lastResult,
            lastArgs: newArgs,
            lastThis: this,
        };
        return lastResult;
    }
    memoized.clear = function clear() {
        cache = null;
    };
    return memoized;
}



;// CONCATENATED MODULE: ./node_modules/react-select/dist/Select-ef7c0426.esm.js














function _EMOTION_STRINGIFIED_CSS_ERROR__$2() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; }

// Assistive text to describe visual elements. Hidden for sighted users.
var _ref =  true ? {
  name: "7pg0cj-a11yText",
  styles: "label:a11yText;z-index:9999;border:0;clip:rect(1px, 1px, 1px, 1px);height:1px;width:1px;position:absolute;overflow:hidden;padding:0;white-space:nowrap"
} : 0;
var A11yText = function A11yText(props) {
  return jsx("span", extends_extends({
    css: _ref
  }, props));
};
var A11yText$1 = A11yText;

var defaultAriaLiveMessages = {
  guidance: function guidance(props) {
    var isSearchable = props.isSearchable,
      isMulti = props.isMulti,
      tabSelectsValue = props.tabSelectsValue,
      context = props.context,
      isInitialFocus = props.isInitialFocus;
    switch (context) {
      case 'menu':
        return "Use Up and Down to choose options, press Enter to select the currently focused option, press Escape to exit the menu".concat(tabSelectsValue ? ', press Tab to select the option and exit the menu' : '', ".");
      case 'input':
        return isInitialFocus ? "".concat(props['aria-label'] || 'Select', " is focused ").concat(isSearchable ? ',type to refine list' : '', ", press Down to open the menu, ").concat(isMulti ? ' press left to focus selected values' : '') : '';
      case 'value':
        return 'Use left and right to toggle between focused values, press Backspace to remove the currently focused value';
      default:
        return '';
    }
  },
  onChange: function onChange(props) {
    var action = props.action,
      _props$label = props.label,
      label = _props$label === void 0 ? '' : _props$label,
      labels = props.labels,
      isDisabled = props.isDisabled;
    switch (action) {
      case 'deselect-option':
      case 'pop-value':
      case 'remove-value':
        return "option ".concat(label, ", deselected.");
      case 'clear':
        return 'All selected options have been cleared.';
      case 'initial-input-focus':
        return "option".concat(labels.length > 1 ? 's' : '', " ").concat(labels.join(','), ", selected.");
      case 'select-option':
        return isDisabled ? "option ".concat(label, " is disabled. Select another option.") : "option ".concat(label, ", selected.");
      default:
        return '';
    }
  },
  onFocus: function onFocus(props) {
    var context = props.context,
      focused = props.focused,
      options = props.options,
      _props$label2 = props.label,
      label = _props$label2 === void 0 ? '' : _props$label2,
      selectValue = props.selectValue,
      isDisabled = props.isDisabled,
      isSelected = props.isSelected,
      isAppleDevice = props.isAppleDevice;
    var getArrayIndex = function getArrayIndex(arr, item) {
      return arr && arr.length ? "".concat(arr.indexOf(item) + 1, " of ").concat(arr.length) : '';
    };
    if (context === 'value' && selectValue) {
      return "value ".concat(label, " focused, ").concat(getArrayIndex(selectValue, focused), ".");
    }
    if (context === 'menu' && isAppleDevice) {
      var disabled = isDisabled ? ' disabled' : '';
      var status = "".concat(isSelected ? ' selected' : '').concat(disabled);
      return "".concat(label).concat(status, ", ").concat(getArrayIndex(options, focused), ".");
    }
    return '';
  },
  onFilter: function onFilter(props) {
    var inputValue = props.inputValue,
      resultsMessage = props.resultsMessage;
    return "".concat(resultsMessage).concat(inputValue ? ' for search term ' + inputValue : '', ".");
  }
};

var LiveRegion = function LiveRegion(props) {
  var ariaSelection = props.ariaSelection,
    focusedOption = props.focusedOption,
    focusedValue = props.focusedValue,
    focusableOptions = props.focusableOptions,
    isFocused = props.isFocused,
    selectValue = props.selectValue,
    selectProps = props.selectProps,
    id = props.id,
    isAppleDevice = props.isAppleDevice;
  var ariaLiveMessages = selectProps.ariaLiveMessages,
    getOptionLabel = selectProps.getOptionLabel,
    inputValue = selectProps.inputValue,
    isMulti = selectProps.isMulti,
    isOptionDisabled = selectProps.isOptionDisabled,
    isSearchable = selectProps.isSearchable,
    menuIsOpen = selectProps.menuIsOpen,
    options = selectProps.options,
    screenReaderStatus = selectProps.screenReaderStatus,
    tabSelectsValue = selectProps.tabSelectsValue,
    isLoading = selectProps.isLoading;
  var ariaLabel = selectProps['aria-label'];
  var ariaLive = selectProps['aria-live'];

  // Update aria live message configuration when prop changes
  var messages = (0,react.useMemo)(function () {
    return objectSpread2_objectSpread2(objectSpread2_objectSpread2({}, defaultAriaLiveMessages), ariaLiveMessages || {});
  }, [ariaLiveMessages]);

  // Update aria live selected option when prop changes
  var ariaSelected = (0,react.useMemo)(function () {
    var message = '';
    if (ariaSelection && messages.onChange) {
      var option = ariaSelection.option,
        selectedOptions = ariaSelection.options,
        removedValue = ariaSelection.removedValue,
        removedValues = ariaSelection.removedValues,
        value = ariaSelection.value;
      // select-option when !isMulti does not return option so we assume selected option is value
      var asOption = function asOption(val) {
        return !Array.isArray(val) ? val : null;
      };

      // If there is just one item from the action then get its label
      var selected = removedValue || option || asOption(value);
      var label = selected ? getOptionLabel(selected) : '';

      // If there are multiple items from the action then return an array of labels
      var multiSelected = selectedOptions || removedValues || undefined;
      var labels = multiSelected ? multiSelected.map(getOptionLabel) : [];
      var onChangeProps = objectSpread2_objectSpread2({
        // multiSelected items are usually items that have already been selected
        // or set by the user as a default value so we assume they are not disabled
        isDisabled: selected && isOptionDisabled(selected, selectValue),
        label: label,
        labels: labels
      }, ariaSelection);
      message = messages.onChange(onChangeProps);
    }
    return message;
  }, [ariaSelection, messages, isOptionDisabled, selectValue, getOptionLabel]);
  var ariaFocused = (0,react.useMemo)(function () {
    var focusMsg = '';
    var focused = focusedOption || focusedValue;
    var isSelected = !!(focusedOption && selectValue && selectValue.includes(focusedOption));
    if (focused && messages.onFocus) {
      var onFocusProps = {
        focused: focused,
        label: getOptionLabel(focused),
        isDisabled: isOptionDisabled(focused, selectValue),
        isSelected: isSelected,
        options: focusableOptions,
        context: focused === focusedOption ? 'menu' : 'value',
        selectValue: selectValue,
        isAppleDevice: isAppleDevice
      };
      focusMsg = messages.onFocus(onFocusProps);
    }
    return focusMsg;
  }, [focusedOption, focusedValue, getOptionLabel, isOptionDisabled, messages, focusableOptions, selectValue, isAppleDevice]);
  var ariaResults = (0,react.useMemo)(function () {
    var resultsMsg = '';
    if (menuIsOpen && options.length && !isLoading && messages.onFilter) {
      var resultsMessage = screenReaderStatus({
        count: focusableOptions.length
      });
      resultsMsg = messages.onFilter({
        inputValue: inputValue,
        resultsMessage: resultsMessage
      });
    }
    return resultsMsg;
  }, [focusableOptions, inputValue, menuIsOpen, messages, options, screenReaderStatus, isLoading]);
  var isInitialFocus = (ariaSelection === null || ariaSelection === void 0 ? void 0 : ariaSelection.action) === 'initial-input-focus';
  var ariaGuidance = (0,react.useMemo)(function () {
    var guidanceMsg = '';
    if (messages.guidance) {
      var context = focusedValue ? 'value' : menuIsOpen ? 'menu' : 'input';
      guidanceMsg = messages.guidance({
        'aria-label': ariaLabel,
        context: context,
        isDisabled: focusedOption && isOptionDisabled(focusedOption, selectValue),
        isMulti: isMulti,
        isSearchable: isSearchable,
        tabSelectsValue: tabSelectsValue,
        isInitialFocus: isInitialFocus
      });
    }
    return guidanceMsg;
  }, [ariaLabel, focusedOption, focusedValue, isMulti, isOptionDisabled, isSearchable, menuIsOpen, messages, selectValue, tabSelectsValue, isInitialFocus]);
  var ScreenReaderText = jsx(react.Fragment, null, jsx("span", {
    id: "aria-selection"
  }, ariaSelected), jsx("span", {
    id: "aria-focused"
  }, ariaFocused), jsx("span", {
    id: "aria-results"
  }, ariaResults), jsx("span", {
    id: "aria-guidance"
  }, ariaGuidance));
  return jsx(react.Fragment, null, jsx(A11yText$1, {
    id: id
  }, isInitialFocus && ScreenReaderText), jsx(A11yText$1, {
    "aria-live": ariaLive,
    "aria-atomic": "false",
    "aria-relevant": "additions text",
    role: "log"
  }, isFocused && !isInitialFocus && ScreenReaderText));
};
var LiveRegion$1 = LiveRegion;

var diacritics = [{
  base: 'A',
  letters: "A\u24B6\uFF21\xC0\xC1\xC2\u1EA6\u1EA4\u1EAA\u1EA8\xC3\u0100\u0102\u1EB0\u1EAE\u1EB4\u1EB2\u0226\u01E0\xC4\u01DE\u1EA2\xC5\u01FA\u01CD\u0200\u0202\u1EA0\u1EAC\u1EB6\u1E00\u0104\u023A\u2C6F"
}, {
  base: 'AA',
  letters: "\uA732"
}, {
  base: 'AE',
  letters: "\xC6\u01FC\u01E2"
}, {
  base: 'AO',
  letters: "\uA734"
}, {
  base: 'AU',
  letters: "\uA736"
}, {
  base: 'AV',
  letters: "\uA738\uA73A"
}, {
  base: 'AY',
  letters: "\uA73C"
}, {
  base: 'B',
  letters: "B\u24B7\uFF22\u1E02\u1E04\u1E06\u0243\u0182\u0181"
}, {
  base: 'C',
  letters: "C\u24B8\uFF23\u0106\u0108\u010A\u010C\xC7\u1E08\u0187\u023B\uA73E"
}, {
  base: 'D',
  letters: "D\u24B9\uFF24\u1E0A\u010E\u1E0C\u1E10\u1E12\u1E0E\u0110\u018B\u018A\u0189\uA779"
}, {
  base: 'DZ',
  letters: "\u01F1\u01C4"
}, {
  base: 'Dz',
  letters: "\u01F2\u01C5"
}, {
  base: 'E',
  letters: "E\u24BA\uFF25\xC8\xC9\xCA\u1EC0\u1EBE\u1EC4\u1EC2\u1EBC\u0112\u1E14\u1E16\u0114\u0116\xCB\u1EBA\u011A\u0204\u0206\u1EB8\u1EC6\u0228\u1E1C\u0118\u1E18\u1E1A\u0190\u018E"
}, {
  base: 'F',
  letters: "F\u24BB\uFF26\u1E1E\u0191\uA77B"
}, {
  base: 'G',
  letters: "G\u24BC\uFF27\u01F4\u011C\u1E20\u011E\u0120\u01E6\u0122\u01E4\u0193\uA7A0\uA77D\uA77E"
}, {
  base: 'H',
  letters: "H\u24BD\uFF28\u0124\u1E22\u1E26\u021E\u1E24\u1E28\u1E2A\u0126\u2C67\u2C75\uA78D"
}, {
  base: 'I',
  letters: "I\u24BE\uFF29\xCC\xCD\xCE\u0128\u012A\u012C\u0130\xCF\u1E2E\u1EC8\u01CF\u0208\u020A\u1ECA\u012E\u1E2C\u0197"
}, {
  base: 'J',
  letters: "J\u24BF\uFF2A\u0134\u0248"
}, {
  base: 'K',
  letters: "K\u24C0\uFF2B\u1E30\u01E8\u1E32\u0136\u1E34\u0198\u2C69\uA740\uA742\uA744\uA7A2"
}, {
  base: 'L',
  letters: "L\u24C1\uFF2C\u013F\u0139\u013D\u1E36\u1E38\u013B\u1E3C\u1E3A\u0141\u023D\u2C62\u2C60\uA748\uA746\uA780"
}, {
  base: 'LJ',
  letters: "\u01C7"
}, {
  base: 'Lj',
  letters: "\u01C8"
}, {
  base: 'M',
  letters: "M\u24C2\uFF2D\u1E3E\u1E40\u1E42\u2C6E\u019C"
}, {
  base: 'N',
  letters: "N\u24C3\uFF2E\u01F8\u0143\xD1\u1E44\u0147\u1E46\u0145\u1E4A\u1E48\u0220\u019D\uA790\uA7A4"
}, {
  base: 'NJ',
  letters: "\u01CA"
}, {
  base: 'Nj',
  letters: "\u01CB"
}, {
  base: 'O',
  letters: "O\u24C4\uFF2F\xD2\xD3\xD4\u1ED2\u1ED0\u1ED6\u1ED4\xD5\u1E4C\u022C\u1E4E\u014C\u1E50\u1E52\u014E\u022E\u0230\xD6\u022A\u1ECE\u0150\u01D1\u020C\u020E\u01A0\u1EDC\u1EDA\u1EE0\u1EDE\u1EE2\u1ECC\u1ED8\u01EA\u01EC\xD8\u01FE\u0186\u019F\uA74A\uA74C"
}, {
  base: 'OI',
  letters: "\u01A2"
}, {
  base: 'OO',
  letters: "\uA74E"
}, {
  base: 'OU',
  letters: "\u0222"
}, {
  base: 'P',
  letters: "P\u24C5\uFF30\u1E54\u1E56\u01A4\u2C63\uA750\uA752\uA754"
}, {
  base: 'Q',
  letters: "Q\u24C6\uFF31\uA756\uA758\u024A"
}, {
  base: 'R',
  letters: "R\u24C7\uFF32\u0154\u1E58\u0158\u0210\u0212\u1E5A\u1E5C\u0156\u1E5E\u024C\u2C64\uA75A\uA7A6\uA782"
}, {
  base: 'S',
  letters: "S\u24C8\uFF33\u1E9E\u015A\u1E64\u015C\u1E60\u0160\u1E66\u1E62\u1E68\u0218\u015E\u2C7E\uA7A8\uA784"
}, {
  base: 'T',
  letters: "T\u24C9\uFF34\u1E6A\u0164\u1E6C\u021A\u0162\u1E70\u1E6E\u0166\u01AC\u01AE\u023E\uA786"
}, {
  base: 'TZ',
  letters: "\uA728"
}, {
  base: 'U',
  letters: "U\u24CA\uFF35\xD9\xDA\xDB\u0168\u1E78\u016A\u1E7A\u016C\xDC\u01DB\u01D7\u01D5\u01D9\u1EE6\u016E\u0170\u01D3\u0214\u0216\u01AF\u1EEA\u1EE8\u1EEE\u1EEC\u1EF0\u1EE4\u1E72\u0172\u1E76\u1E74\u0244"
}, {
  base: 'V',
  letters: "V\u24CB\uFF36\u1E7C\u1E7E\u01B2\uA75E\u0245"
}, {
  base: 'VY',
  letters: "\uA760"
}, {
  base: 'W',
  letters: "W\u24CC\uFF37\u1E80\u1E82\u0174\u1E86\u1E84\u1E88\u2C72"
}, {
  base: 'X',
  letters: "X\u24CD\uFF38\u1E8A\u1E8C"
}, {
  base: 'Y',
  letters: "Y\u24CE\uFF39\u1EF2\xDD\u0176\u1EF8\u0232\u1E8E\u0178\u1EF6\u1EF4\u01B3\u024E\u1EFE"
}, {
  base: 'Z',
  letters: "Z\u24CF\uFF3A\u0179\u1E90\u017B\u017D\u1E92\u1E94\u01B5\u0224\u2C7F\u2C6B\uA762"
}, {
  base: 'a',
  letters: "a\u24D0\uFF41\u1E9A\xE0\xE1\xE2\u1EA7\u1EA5\u1EAB\u1EA9\xE3\u0101\u0103\u1EB1\u1EAF\u1EB5\u1EB3\u0227\u01E1\xE4\u01DF\u1EA3\xE5\u01FB\u01CE\u0201\u0203\u1EA1\u1EAD\u1EB7\u1E01\u0105\u2C65\u0250"
}, {
  base: 'aa',
  letters: "\uA733"
}, {
  base: 'ae',
  letters: "\xE6\u01FD\u01E3"
}, {
  base: 'ao',
  letters: "\uA735"
}, {
  base: 'au',
  letters: "\uA737"
}, {
  base: 'av',
  letters: "\uA739\uA73B"
}, {
  base: 'ay',
  letters: "\uA73D"
}, {
  base: 'b',
  letters: "b\u24D1\uFF42\u1E03\u1E05\u1E07\u0180\u0183\u0253"
}, {
  base: 'c',
  letters: "c\u24D2\uFF43\u0107\u0109\u010B\u010D\xE7\u1E09\u0188\u023C\uA73F\u2184"
}, {
  base: 'd',
  letters: "d\u24D3\uFF44\u1E0B\u010F\u1E0D\u1E11\u1E13\u1E0F\u0111\u018C\u0256\u0257\uA77A"
}, {
  base: 'dz',
  letters: "\u01F3\u01C6"
}, {
  base: 'e',
  letters: "e\u24D4\uFF45\xE8\xE9\xEA\u1EC1\u1EBF\u1EC5\u1EC3\u1EBD\u0113\u1E15\u1E17\u0115\u0117\xEB\u1EBB\u011B\u0205\u0207\u1EB9\u1EC7\u0229\u1E1D\u0119\u1E19\u1E1B\u0247\u025B\u01DD"
}, {
  base: 'f',
  letters: "f\u24D5\uFF46\u1E1F\u0192\uA77C"
}, {
  base: 'g',
  letters: "g\u24D6\uFF47\u01F5\u011D\u1E21\u011F\u0121\u01E7\u0123\u01E5\u0260\uA7A1\u1D79\uA77F"
}, {
  base: 'h',
  letters: "h\u24D7\uFF48\u0125\u1E23\u1E27\u021F\u1E25\u1E29\u1E2B\u1E96\u0127\u2C68\u2C76\u0265"
}, {
  base: 'hv',
  letters: "\u0195"
}, {
  base: 'i',
  letters: "i\u24D8\uFF49\xEC\xED\xEE\u0129\u012B\u012D\xEF\u1E2F\u1EC9\u01D0\u0209\u020B\u1ECB\u012F\u1E2D\u0268\u0131"
}, {
  base: 'j',
  letters: "j\u24D9\uFF4A\u0135\u01F0\u0249"
}, {
  base: 'k',
  letters: "k\u24DA\uFF4B\u1E31\u01E9\u1E33\u0137\u1E35\u0199\u2C6A\uA741\uA743\uA745\uA7A3"
}, {
  base: 'l',
  letters: "l\u24DB\uFF4C\u0140\u013A\u013E\u1E37\u1E39\u013C\u1E3D\u1E3B\u017F\u0142\u019A\u026B\u2C61\uA749\uA781\uA747"
}, {
  base: 'lj',
  letters: "\u01C9"
}, {
  base: 'm',
  letters: "m\u24DC\uFF4D\u1E3F\u1E41\u1E43\u0271\u026F"
}, {
  base: 'n',
  letters: "n\u24DD\uFF4E\u01F9\u0144\xF1\u1E45\u0148\u1E47\u0146\u1E4B\u1E49\u019E\u0272\u0149\uA791\uA7A5"
}, {
  base: 'nj',
  letters: "\u01CC"
}, {
  base: 'o',
  letters: "o\u24DE\uFF4F\xF2\xF3\xF4\u1ED3\u1ED1\u1ED7\u1ED5\xF5\u1E4D\u022D\u1E4F\u014D\u1E51\u1E53\u014F\u022F\u0231\xF6\u022B\u1ECF\u0151\u01D2\u020D\u020F\u01A1\u1EDD\u1EDB\u1EE1\u1EDF\u1EE3\u1ECD\u1ED9\u01EB\u01ED\xF8\u01FF\u0254\uA74B\uA74D\u0275"
}, {
  base: 'oi',
  letters: "\u01A3"
}, {
  base: 'ou',
  letters: "\u0223"
}, {
  base: 'oo',
  letters: "\uA74F"
}, {
  base: 'p',
  letters: "p\u24DF\uFF50\u1E55\u1E57\u01A5\u1D7D\uA751\uA753\uA755"
}, {
  base: 'q',
  letters: "q\u24E0\uFF51\u024B\uA757\uA759"
}, {
  base: 'r',
  letters: "r\u24E1\uFF52\u0155\u1E59\u0159\u0211\u0213\u1E5B\u1E5D\u0157\u1E5F\u024D\u027D\uA75B\uA7A7\uA783"
}, {
  base: 's',
  letters: "s\u24E2\uFF53\xDF\u015B\u1E65\u015D\u1E61\u0161\u1E67\u1E63\u1E69\u0219\u015F\u023F\uA7A9\uA785\u1E9B"
}, {
  base: 't',
  letters: "t\u24E3\uFF54\u1E6B\u1E97\u0165\u1E6D\u021B\u0163\u1E71\u1E6F\u0167\u01AD\u0288\u2C66\uA787"
}, {
  base: 'tz',
  letters: "\uA729"
}, {
  base: 'u',
  letters: "u\u24E4\uFF55\xF9\xFA\xFB\u0169\u1E79\u016B\u1E7B\u016D\xFC\u01DC\u01D8\u01D6\u01DA\u1EE7\u016F\u0171\u01D4\u0215\u0217\u01B0\u1EEB\u1EE9\u1EEF\u1EED\u1EF1\u1EE5\u1E73\u0173\u1E77\u1E75\u0289"
}, {
  base: 'v',
  letters: "v\u24E5\uFF56\u1E7D\u1E7F\u028B\uA75F\u028C"
}, {
  base: 'vy',
  letters: "\uA761"
}, {
  base: 'w',
  letters: "w\u24E6\uFF57\u1E81\u1E83\u0175\u1E87\u1E85\u1E98\u1E89\u2C73"
}, {
  base: 'x',
  letters: "x\u24E7\uFF58\u1E8B\u1E8D"
}, {
  base: 'y',
  letters: "y\u24E8\uFF59\u1EF3\xFD\u0177\u1EF9\u0233\u1E8F\xFF\u1EF7\u1E99\u1EF5\u01B4\u024F\u1EFF"
}, {
  base: 'z',
  letters: "z\u24E9\uFF5A\u017A\u1E91\u017C\u017E\u1E93\u1E95\u01B6\u0225\u0240\u2C6C\uA763"
}];
var anyDiacritic = new RegExp('[' + diacritics.map(function (d) {
  return d.letters;
}).join('') + ']', 'g');
var diacriticToBase = {};
for (var i = 0; i < diacritics.length; i++) {
  var diacritic = diacritics[i];
  for (var j = 0; j < diacritic.letters.length; j++) {
    diacriticToBase[diacritic.letters[j]] = diacritic.base;
  }
}
var stripDiacritics = function stripDiacritics(str) {
  return str.replace(anyDiacritic, function (match) {
    return diacriticToBase[match];
  });
};

var memoizedStripDiacriticsForInput = memoizeOne(stripDiacritics);
var trimString = function trimString(str) {
  return str.replace(/^\s+|\s+$/g, '');
};
var defaultStringify = function defaultStringify(option) {
  return "".concat(option.label, " ").concat(option.value);
};
var createFilter = function createFilter(config) {
  return function (option, rawInput) {
    // eslint-disable-next-line no-underscore-dangle
    if (option.data.__isNew__) return true;
    var _ignoreCase$ignoreAcc = objectSpread2_objectSpread2({
        ignoreCase: true,
        ignoreAccents: true,
        stringify: defaultStringify,
        trim: true,
        matchFrom: 'any'
      }, config),
      ignoreCase = _ignoreCase$ignoreAcc.ignoreCase,
      ignoreAccents = _ignoreCase$ignoreAcc.ignoreAccents,
      stringify = _ignoreCase$ignoreAcc.stringify,
      trim = _ignoreCase$ignoreAcc.trim,
      matchFrom = _ignoreCase$ignoreAcc.matchFrom;
    var input = trim ? trimString(rawInput) : rawInput;
    var candidate = trim ? trimString(stringify(option)) : stringify(option);
    if (ignoreCase) {
      input = input.toLowerCase();
      candidate = candidate.toLowerCase();
    }
    if (ignoreAccents) {
      input = memoizedStripDiacriticsForInput(input);
      candidate = stripDiacritics(candidate);
    }
    return matchFrom === 'start' ? candidate.substr(0, input.length) === input : candidate.indexOf(input) > -1;
  };
};

var Select_ef7c0426_esm_excluded = ["innerRef"];
function DummyInput(_ref) {
  var innerRef = _ref.innerRef,
    props = _objectWithoutProperties(_ref, Select_ef7c0426_esm_excluded);
  // Remove animation props not meant for HTML elements
  var filteredProps = removeProps(props, 'onExited', 'in', 'enter', 'exit', 'appear');
  return jsx("input", extends_extends({
    ref: innerRef
  }, filteredProps, {
    css: /*#__PURE__*/css({
      label: 'dummyInput',
      // get rid of any default styles
      background: 0,
      border: 0,
      // important! this hides the flashing cursor
      caretColor: 'transparent',
      fontSize: 'inherit',
      gridArea: '1 / 1 / 2 / 3',
      outline: 0,
      padding: 0,
      // important! without `width` browsers won't allow focus
      width: 1,
      // remove cursor on desktop
      color: 'transparent',
      // remove cursor on mobile whilst maintaining "scroll into view" behaviour
      left: -100,
      opacity: 0,
      position: 'relative',
      transform: 'scale(.01)'
    },  true ? "" : 0,  true ? "" : 0)
  }));
}

var cancelScroll = function cancelScroll(event) {
  if (event.cancelable) event.preventDefault();
  event.stopPropagation();
};
function useScrollCapture(_ref) {
  var isEnabled = _ref.isEnabled,
    onBottomArrive = _ref.onBottomArrive,
    onBottomLeave = _ref.onBottomLeave,
    onTopArrive = _ref.onTopArrive,
    onTopLeave = _ref.onTopLeave;
  var isBottom = (0,react.useRef)(false);
  var isTop = (0,react.useRef)(false);
  var touchStart = (0,react.useRef)(0);
  var scrollTarget = (0,react.useRef)(null);
  var handleEventDelta = (0,react.useCallback)(function (event, delta) {
    if (scrollTarget.current === null) return;
    var _scrollTarget$current = scrollTarget.current,
      scrollTop = _scrollTarget$current.scrollTop,
      scrollHeight = _scrollTarget$current.scrollHeight,
      clientHeight = _scrollTarget$current.clientHeight;
    var target = scrollTarget.current;
    var isDeltaPositive = delta > 0;
    var availableScroll = scrollHeight - clientHeight - scrollTop;
    var shouldCancelScroll = false;

    // reset bottom/top flags
    if (availableScroll > delta && isBottom.current) {
      if (onBottomLeave) onBottomLeave(event);
      isBottom.current = false;
    }
    if (isDeltaPositive && isTop.current) {
      if (onTopLeave) onTopLeave(event);
      isTop.current = false;
    }

    // bottom limit
    if (isDeltaPositive && delta > availableScroll) {
      if (onBottomArrive && !isBottom.current) {
        onBottomArrive(event);
      }
      target.scrollTop = scrollHeight;
      shouldCancelScroll = true;
      isBottom.current = true;

      // top limit
    } else if (!isDeltaPositive && -delta > scrollTop) {
      if (onTopArrive && !isTop.current) {
        onTopArrive(event);
      }
      target.scrollTop = 0;
      shouldCancelScroll = true;
      isTop.current = true;
    }

    // cancel scroll
    if (shouldCancelScroll) {
      cancelScroll(event);
    }
  }, [onBottomArrive, onBottomLeave, onTopArrive, onTopLeave]);
  var onWheel = (0,react.useCallback)(function (event) {
    handleEventDelta(event, event.deltaY);
  }, [handleEventDelta]);
  var onTouchStart = (0,react.useCallback)(function (event) {
    // set touch start so we can calculate touchmove delta
    touchStart.current = event.changedTouches[0].clientY;
  }, []);
  var onTouchMove = (0,react.useCallback)(function (event) {
    var deltaY = touchStart.current - event.changedTouches[0].clientY;
    handleEventDelta(event, deltaY);
  }, [handleEventDelta]);
  var startListening = (0,react.useCallback)(function (el) {
    // bail early if no element is available to attach to
    if (!el) return;
    var notPassive = supportsPassiveEvents ? {
      passive: false
    } : false;
    el.addEventListener('wheel', onWheel, notPassive);
    el.addEventListener('touchstart', onTouchStart, notPassive);
    el.addEventListener('touchmove', onTouchMove, notPassive);
  }, [onTouchMove, onTouchStart, onWheel]);
  var stopListening = (0,react.useCallback)(function (el) {
    // bail early if no element is available to detach from
    if (!el) return;
    el.removeEventListener('wheel', onWheel, false);
    el.removeEventListener('touchstart', onTouchStart, false);
    el.removeEventListener('touchmove', onTouchMove, false);
  }, [onTouchMove, onTouchStart, onWheel]);
  (0,react.useEffect)(function () {
    if (!isEnabled) return;
    var element = scrollTarget.current;
    startListening(element);
    return function () {
      stopListening(element);
    };
  }, [isEnabled, startListening, stopListening]);
  return function (element) {
    scrollTarget.current = element;
  };
}

var STYLE_KEYS = ['boxSizing', 'height', 'overflow', 'paddingRight', 'position'];
var LOCK_STYLES = {
  boxSizing: 'border-box',
  // account for possible declaration `width: 100%;` on body
  overflow: 'hidden',
  position: 'relative',
  height: '100%'
};
function preventTouchMove(e) {
  if (e.cancelable) e.preventDefault();
}
function allowTouchMove(e) {
  e.stopPropagation();
}
function preventInertiaScroll() {
  var top = this.scrollTop;
  var totalScroll = this.scrollHeight;
  var currentScroll = top + this.offsetHeight;
  if (top === 0) {
    this.scrollTop = 1;
  } else if (currentScroll === totalScroll) {
    this.scrollTop = top - 1;
  }
}

// `ontouchstart` check works on most browsers
// `maxTouchPoints` works on IE10/11 and Surface
function isTouchDevice() {
  return 'ontouchstart' in window || navigator.maxTouchPoints;
}
var canUseDOM = !!(typeof window !== 'undefined' && window.document && window.document.createElement);
var activeScrollLocks = 0;
var listenerOptions = {
  capture: false,
  passive: false
};
function useScrollLock(_ref) {
  var isEnabled = _ref.isEnabled,
    _ref$accountForScroll = _ref.accountForScrollbars,
    accountForScrollbars = _ref$accountForScroll === void 0 ? true : _ref$accountForScroll;
  var originalStyles = (0,react.useRef)({});
  var scrollTarget = (0,react.useRef)(null);
  var addScrollLock = (0,react.useCallback)(function (touchScrollTarget) {
    if (!canUseDOM) return;
    var target = document.body;
    var targetStyle = target && target.style;
    if (accountForScrollbars) {
      // store any styles already applied to the body
      STYLE_KEYS.forEach(function (key) {
        var val = targetStyle && targetStyle[key];
        originalStyles.current[key] = val;
      });
    }

    // apply the lock styles and padding if this is the first scroll lock
    if (accountForScrollbars && activeScrollLocks < 1) {
      var currentPadding = parseInt(originalStyles.current.paddingRight, 10) || 0;
      var clientWidth = document.body ? document.body.clientWidth : 0;
      var adjustedPadding = window.innerWidth - clientWidth + currentPadding || 0;
      Object.keys(LOCK_STYLES).forEach(function (key) {
        var val = LOCK_STYLES[key];
        if (targetStyle) {
          targetStyle[key] = val;
        }
      });
      if (targetStyle) {
        targetStyle.paddingRight = "".concat(adjustedPadding, "px");
      }
    }

    // account for touch devices
    if (target && isTouchDevice()) {
      // Mobile Safari ignores { overflow: hidden } declaration on the body.
      target.addEventListener('touchmove', preventTouchMove, listenerOptions);

      // Allow scroll on provided target
      if (touchScrollTarget) {
        touchScrollTarget.addEventListener('touchstart', preventInertiaScroll, listenerOptions);
        touchScrollTarget.addEventListener('touchmove', allowTouchMove, listenerOptions);
      }
    }

    // increment active scroll locks
    activeScrollLocks += 1;
  }, [accountForScrollbars]);
  var removeScrollLock = (0,react.useCallback)(function (touchScrollTarget) {
    if (!canUseDOM) return;
    var target = document.body;
    var targetStyle = target && target.style;

    // safely decrement active scroll locks
    activeScrollLocks = Math.max(activeScrollLocks - 1, 0);

    // reapply original body styles, if any
    if (accountForScrollbars && activeScrollLocks < 1) {
      STYLE_KEYS.forEach(function (key) {
        var val = originalStyles.current[key];
        if (targetStyle) {
          targetStyle[key] = val;
        }
      });
    }

    // remove touch listeners
    if (target && isTouchDevice()) {
      target.removeEventListener('touchmove', preventTouchMove, listenerOptions);
      if (touchScrollTarget) {
        touchScrollTarget.removeEventListener('touchstart', preventInertiaScroll, listenerOptions);
        touchScrollTarget.removeEventListener('touchmove', allowTouchMove, listenerOptions);
      }
    }
  }, [accountForScrollbars]);
  (0,react.useEffect)(function () {
    if (!isEnabled) return;
    var element = scrollTarget.current;
    addScrollLock(element);
    return function () {
      removeScrollLock(element);
    };
  }, [isEnabled, addScrollLock, removeScrollLock]);
  return function (element) {
    scrollTarget.current = element;
  };
}

function _EMOTION_STRINGIFIED_CSS_ERROR__$1() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; }
var blurSelectInput = function blurSelectInput(event) {
  var element = event.target;
  return element.ownerDocument.activeElement && element.ownerDocument.activeElement.blur();
};
var _ref2$1 =  true ? {
  name: "1kfdb0e",
  styles: "position:fixed;left:0;bottom:0;right:0;top:0"
} : 0;
function ScrollManager(_ref) {
  var children = _ref.children,
    lockEnabled = _ref.lockEnabled,
    _ref$captureEnabled = _ref.captureEnabled,
    captureEnabled = _ref$captureEnabled === void 0 ? true : _ref$captureEnabled,
    onBottomArrive = _ref.onBottomArrive,
    onBottomLeave = _ref.onBottomLeave,
    onTopArrive = _ref.onTopArrive,
    onTopLeave = _ref.onTopLeave;
  var setScrollCaptureTarget = useScrollCapture({
    isEnabled: captureEnabled,
    onBottomArrive: onBottomArrive,
    onBottomLeave: onBottomLeave,
    onTopArrive: onTopArrive,
    onTopLeave: onTopLeave
  });
  var setScrollLockTarget = useScrollLock({
    isEnabled: lockEnabled
  });
  var targetRef = function targetRef(element) {
    setScrollCaptureTarget(element);
    setScrollLockTarget(element);
  };
  return jsx(react.Fragment, null, lockEnabled && jsx("div", {
    onClick: blurSelectInput,
    css: _ref2$1
  }), children(targetRef));
}

function Select_ef7c0426_esm_EMOTION_STRINGIFIED_CSS_ERROR_() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; }
var Select_ef7c0426_esm_ref2 =  true ? {
  name: "1a0ro4n-requiredInput",
  styles: "label:requiredInput;opacity:0;pointer-events:none;position:absolute;bottom:0;left:0;right:0;width:100%"
} : 0;
var RequiredInput = function RequiredInput(_ref) {
  var name = _ref.name,
    onFocus = _ref.onFocus;
  return jsx("input", {
    required: true,
    name: name,
    tabIndex: -1,
    "aria-hidden": "true",
    onFocus: onFocus,
    css: Select_ef7c0426_esm_ref2
    // Prevent `Switching from uncontrolled to controlled` error
    ,
    value: "",
    onChange: function onChange() {}
  });
};
var RequiredInput$1 = RequiredInput;

/// <reference types="user-agent-data-types" />

function testPlatform(re) {
  var _window$navigator$use;
  return typeof window !== 'undefined' && window.navigator != null ? re.test(((_window$navigator$use = window.navigator['userAgentData']) === null || _window$navigator$use === void 0 ? void 0 : _window$navigator$use.platform) || window.navigator.platform) : false;
}
function isIPhone() {
  return testPlatform(/^iPhone/i);
}
function isMac() {
  return testPlatform(/^Mac/i);
}
function isIPad() {
  return testPlatform(/^iPad/i) ||
  // iPadOS 13 lies and says it's a Mac, but we can distinguish by detecting touch support.
  isMac() && navigator.maxTouchPoints > 1;
}
function isIOS() {
  return isIPhone() || isIPad();
}
function isAppleDevice() {
  return isMac() || isIOS();
}

var formatGroupLabel = function formatGroupLabel(group) {
  return group.label;
};
var Select_ef7c0426_esm_getOptionLabel$1 = function getOptionLabel(option) {
  return option.label;
};
var Select_ef7c0426_esm_getOptionValue$1 = function getOptionValue(option) {
  return option.value;
};
var isOptionDisabled = function isOptionDisabled(option) {
  return !!option.isDisabled;
};

var defaultStyles = {
  clearIndicator: clearIndicatorCSS,
  container: containerCSS,
  control: css$1,
  dropdownIndicator: dropdownIndicatorCSS,
  group: groupCSS,
  groupHeading: groupHeadingCSS,
  indicatorsContainer: indicatorsContainerCSS,
  indicatorSeparator: indicatorSeparatorCSS,
  input: inputCSS,
  loadingIndicator: loadingIndicatorCSS,
  loadingMessage: loadingMessageCSS,
  menu: menuCSS,
  menuList: menuListCSS,
  menuPortal: menuPortalCSS,
  multiValue: multiValueCSS,
  multiValueLabel: multiValueLabelCSS,
  multiValueRemove: multiValueRemoveCSS,
  noOptionsMessage: noOptionsMessageCSS,
  option: optionCSS,
  placeholder: placeholderCSS,
  singleValue: index_641ee5b8_esm_css,
  valueContainer: valueContainerCSS
};
// Merge Utility
// Allows consumers to extend a base Select with additional styles

function mergeStyles(source) {
  var target = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  // initialize with source styles
  var styles = _objectSpread({}, source);

  // massage in target styles
  Object.keys(target).forEach(function (keyAsString) {
    var key = keyAsString;
    if (source[key]) {
      styles[key] = function (rsCss, props) {
        return target[key](source[key](rsCss, props), props);
      };
    } else {
      styles[key] = target[key];
    }
  });
  return styles;
}

var colors = {
  primary: '#2684FF',
  primary75: '#4C9AFF',
  primary50: '#B2D4FF',
  primary25: '#DEEBFF',
  danger: '#DE350B',
  dangerLight: '#FFBDAD',
  neutral0: 'hsl(0, 0%, 100%)',
  neutral5: 'hsl(0, 0%, 95%)',
  neutral10: 'hsl(0, 0%, 90%)',
  neutral20: 'hsl(0, 0%, 80%)',
  neutral30: 'hsl(0, 0%, 70%)',
  neutral40: 'hsl(0, 0%, 60%)',
  neutral50: 'hsl(0, 0%, 50%)',
  neutral60: 'hsl(0, 0%, 40%)',
  neutral70: 'hsl(0, 0%, 30%)',
  neutral80: 'hsl(0, 0%, 20%)',
  neutral90: 'hsl(0, 0%, 10%)'
};
var borderRadius = 4;
// Used to calculate consistent margin/padding on elements
var baseUnit = 4;
// The minimum height of the control
var controlHeight = 38;
// The amount of space between the control and menu */
var menuGutter = baseUnit * 2;
var spacing = {
  baseUnit: baseUnit,
  controlHeight: controlHeight,
  menuGutter: menuGutter
};
var defaultTheme = {
  borderRadius: borderRadius,
  colors: colors,
  spacing: spacing
};

var defaultProps = {
  'aria-live': 'polite',
  backspaceRemovesValue: true,
  blurInputOnSelect: isTouchCapable(),
  captureMenuScroll: !isTouchCapable(),
  classNames: {},
  closeMenuOnSelect: true,
  closeMenuOnScroll: false,
  components: {},
  controlShouldRenderValue: true,
  escapeClearsValue: false,
  filterOption: createFilter(),
  formatGroupLabel: formatGroupLabel,
  getOptionLabel: Select_ef7c0426_esm_getOptionLabel$1,
  getOptionValue: Select_ef7c0426_esm_getOptionValue$1,
  isDisabled: false,
  isLoading: false,
  isMulti: false,
  isRtl: false,
  isSearchable: true,
  isOptionDisabled: isOptionDisabled,
  loadingMessage: function loadingMessage() {
    return 'Loading...';
  },
  maxMenuHeight: 300,
  minMenuHeight: 140,
  menuIsOpen: false,
  menuPlacement: 'bottom',
  menuPosition: 'absolute',
  menuShouldBlockScroll: false,
  menuShouldScrollIntoView: !isMobileDevice(),
  noOptionsMessage: function noOptionsMessage() {
    return 'No options';
  },
  openMenuOnFocus: false,
  openMenuOnClick: true,
  options: [],
  pageSize: 5,
  placeholder: 'Select...',
  screenReaderStatus: function screenReaderStatus(_ref) {
    var count = _ref.count;
    return "".concat(count, " result").concat(count !== 1 ? 's' : '', " available");
  },
  styles: {},
  tabIndex: 0,
  tabSelectsValue: true,
  unstyled: false
};
function toCategorizedOption(props, option, selectValue, index) {
  var isDisabled = _isOptionDisabled(props, option, selectValue);
  var isSelected = _isOptionSelected(props, option, selectValue);
  var label = getOptionLabel(props, option);
  var value = getOptionValue(props, option);
  return {
    type: 'option',
    data: option,
    isDisabled: isDisabled,
    isSelected: isSelected,
    label: label,
    value: value,
    index: index
  };
}
function buildCategorizedOptions(props, selectValue) {
  return props.options.map(function (groupOrOption, groupOrOptionIndex) {
    if ('options' in groupOrOption) {
      var categorizedOptions = groupOrOption.options.map(function (option, optionIndex) {
        return toCategorizedOption(props, option, selectValue, optionIndex);
      }).filter(function (categorizedOption) {
        return isFocusable(props, categorizedOption);
      });
      return categorizedOptions.length > 0 ? {
        type: 'group',
        data: groupOrOption,
        options: categorizedOptions,
        index: groupOrOptionIndex
      } : undefined;
    }
    var categorizedOption = toCategorizedOption(props, groupOrOption, selectValue, groupOrOptionIndex);
    return isFocusable(props, categorizedOption) ? categorizedOption : undefined;
  }).filter(notNullish);
}
function buildFocusableOptionsFromCategorizedOptions(categorizedOptions) {
  return categorizedOptions.reduce(function (optionsAccumulator, categorizedOption) {
    if (categorizedOption.type === 'group') {
      optionsAccumulator.push.apply(optionsAccumulator, _toConsumableArray(categorizedOption.options.map(function (option) {
        return option.data;
      })));
    } else {
      optionsAccumulator.push(categorizedOption.data);
    }
    return optionsAccumulator;
  }, []);
}
function buildFocusableOptionsWithIds(categorizedOptions, optionId) {
  return categorizedOptions.reduce(function (optionsAccumulator, categorizedOption) {
    if (categorizedOption.type === 'group') {
      optionsAccumulator.push.apply(optionsAccumulator, _toConsumableArray(categorizedOption.options.map(function (option) {
        return {
          data: option.data,
          id: "".concat(optionId, "-").concat(categorizedOption.index, "-").concat(option.index)
        };
      })));
    } else {
      optionsAccumulator.push({
        data: categorizedOption.data,
        id: "".concat(optionId, "-").concat(categorizedOption.index)
      });
    }
    return optionsAccumulator;
  }, []);
}
function buildFocusableOptions(props, selectValue) {
  return buildFocusableOptionsFromCategorizedOptions(buildCategorizedOptions(props, selectValue));
}
function isFocusable(props, categorizedOption) {
  var _props$inputValue = props.inputValue,
    inputValue = _props$inputValue === void 0 ? '' : _props$inputValue;
  var data = categorizedOption.data,
    isSelected = categorizedOption.isSelected,
    label = categorizedOption.label,
    value = categorizedOption.value;
  return (!shouldHideSelectedOptions(props) || !isSelected) && _filterOption(props, {
    label: label,
    value: value,
    data: data
  }, inputValue);
}
function getNextFocusedValue(state, nextSelectValue) {
  var focusedValue = state.focusedValue,
    lastSelectValue = state.selectValue;
  var lastFocusedIndex = lastSelectValue.indexOf(focusedValue);
  if (lastFocusedIndex > -1) {
    var nextFocusedIndex = nextSelectValue.indexOf(focusedValue);
    if (nextFocusedIndex > -1) {
      // the focused value is still in the selectValue, return it
      return focusedValue;
    } else if (lastFocusedIndex < nextSelectValue.length) {
      // the focusedValue is not present in the next selectValue array by
      // reference, so return the new value at the same index
      return nextSelectValue[lastFocusedIndex];
    }
  }
  return null;
}
function getNextFocusedOption(state, options) {
  var lastFocusedOption = state.focusedOption;
  return lastFocusedOption && options.indexOf(lastFocusedOption) > -1 ? lastFocusedOption : options[0];
}
var getFocusedOptionId = function getFocusedOptionId(focusableOptionsWithIds, focusedOption) {
  var _focusableOptionsWith;
  var focusedOptionId = (_focusableOptionsWith = focusableOptionsWithIds.find(function (option) {
    return option.data === focusedOption;
  })) === null || _focusableOptionsWith === void 0 ? void 0 : _focusableOptionsWith.id;
  return focusedOptionId || null;
};
var getOptionLabel = function getOptionLabel(props, data) {
  return props.getOptionLabel(data);
};
var getOptionValue = function getOptionValue(props, data) {
  return props.getOptionValue(data);
};
function _isOptionDisabled(props, option, selectValue) {
  return typeof props.isOptionDisabled === 'function' ? props.isOptionDisabled(option, selectValue) : false;
}
function _isOptionSelected(props, option, selectValue) {
  if (selectValue.indexOf(option) > -1) return true;
  if (typeof props.isOptionSelected === 'function') {
    return props.isOptionSelected(option, selectValue);
  }
  var candidate = getOptionValue(props, option);
  return selectValue.some(function (i) {
    return getOptionValue(props, i) === candidate;
  });
}
function _filterOption(props, option, inputValue) {
  return props.filterOption ? props.filterOption(option, inputValue) : true;
}
var shouldHideSelectedOptions = function shouldHideSelectedOptions(props) {
  var hideSelectedOptions = props.hideSelectedOptions,
    isMulti = props.isMulti;
  if (hideSelectedOptions === undefined) return isMulti;
  return hideSelectedOptions;
};
var instanceId = 1;
var Select = /*#__PURE__*/function (_Component) {
  _inherits(Select, _Component);
  var _super = _createSuper(Select);
  // Misc. Instance Properties
  // ------------------------------

  // TODO

  // Refs
  // ------------------------------

  // Lifecycle
  // ------------------------------

  function Select(_props) {
    var _this;
    _classCallCheck(this, Select);
    _this = _super.call(this, _props);
    _this.state = {
      ariaSelection: null,
      focusedOption: null,
      focusedOptionId: null,
      focusableOptionsWithIds: [],
      focusedValue: null,
      inputIsHidden: false,
      isFocused: false,
      selectValue: [],
      clearFocusValueOnUpdate: false,
      prevWasFocused: false,
      inputIsHiddenAfterUpdate: undefined,
      prevProps: undefined,
      instancePrefix: '',
      isAppleDevice: false
    };
    _this.blockOptionHover = false;
    _this.isComposing = false;
    _this.commonProps = void 0;
    _this.initialTouchX = 0;
    _this.initialTouchY = 0;
    _this.openAfterFocus = false;
    _this.scrollToFocusedOptionOnUpdate = false;
    _this.userIsDragging = void 0;
    _this.controlRef = null;
    _this.getControlRef = function (ref) {
      _this.controlRef = ref;
    };
    _this.focusedOptionRef = null;
    _this.getFocusedOptionRef = function (ref) {
      _this.focusedOptionRef = ref;
    };
    _this.menuListRef = null;
    _this.getMenuListRef = function (ref) {
      _this.menuListRef = ref;
    };
    _this.inputRef = null;
    _this.getInputRef = function (ref) {
      _this.inputRef = ref;
    };
    _this.focus = _this.focusInput;
    _this.blur = _this.blurInput;
    _this.onChange = function (newValue, actionMeta) {
      var _this$props = _this.props,
        onChange = _this$props.onChange,
        name = _this$props.name;
      actionMeta.name = name;
      _this.ariaOnChange(newValue, actionMeta);
      onChange(newValue, actionMeta);
    };
    _this.setValue = function (newValue, action, option) {
      var _this$props2 = _this.props,
        closeMenuOnSelect = _this$props2.closeMenuOnSelect,
        isMulti = _this$props2.isMulti,
        inputValue = _this$props2.inputValue;
      _this.onInputChange('', {
        action: 'set-value',
        prevInputValue: inputValue
      });
      if (closeMenuOnSelect) {
        _this.setState({
          inputIsHiddenAfterUpdate: !isMulti
        });
        _this.onMenuClose();
      }
      // when the select value should change, we should reset focusedValue
      _this.setState({
        clearFocusValueOnUpdate: true
      });
      _this.onChange(newValue, {
        action: action,
        option: option
      });
    };
    _this.selectOption = function (newValue) {
      var _this$props3 = _this.props,
        blurInputOnSelect = _this$props3.blurInputOnSelect,
        isMulti = _this$props3.isMulti,
        name = _this$props3.name;
      var selectValue = _this.state.selectValue;
      var deselected = isMulti && _this.isOptionSelected(newValue, selectValue);
      var isDisabled = _this.isOptionDisabled(newValue, selectValue);
      if (deselected) {
        var candidate = _this.getOptionValue(newValue);
        _this.setValue(multiValueAsValue(selectValue.filter(function (i) {
          return _this.getOptionValue(i) !== candidate;
        })), 'deselect-option', newValue);
      } else if (!isDisabled) {
        // Select option if option is not disabled
        if (isMulti) {
          _this.setValue(multiValueAsValue([].concat(_toConsumableArray(selectValue), [newValue])), 'select-option', newValue);
        } else {
          _this.setValue(singleValueAsValue(newValue), 'select-option');
        }
      } else {
        _this.ariaOnChange(singleValueAsValue(newValue), {
          action: 'select-option',
          option: newValue,
          name: name
        });
        return;
      }
      if (blurInputOnSelect) {
        _this.blurInput();
      }
    };
    _this.removeValue = function (removedValue) {
      var isMulti = _this.props.isMulti;
      var selectValue = _this.state.selectValue;
      var candidate = _this.getOptionValue(removedValue);
      var newValueArray = selectValue.filter(function (i) {
        return _this.getOptionValue(i) !== candidate;
      });
      var newValue = valueTernary(isMulti, newValueArray, newValueArray[0] || null);
      _this.onChange(newValue, {
        action: 'remove-value',
        removedValue: removedValue
      });
      _this.focusInput();
    };
    _this.clearValue = function () {
      var selectValue = _this.state.selectValue;
      _this.onChange(valueTernary(_this.props.isMulti, [], null), {
        action: 'clear',
        removedValues: selectValue
      });
    };
    _this.popValue = function () {
      var isMulti = _this.props.isMulti;
      var selectValue = _this.state.selectValue;
      var lastSelectedValue = selectValue[selectValue.length - 1];
      var newValueArray = selectValue.slice(0, selectValue.length - 1);
      var newValue = valueTernary(isMulti, newValueArray, newValueArray[0] || null);
      if (lastSelectedValue) {
        _this.onChange(newValue, {
          action: 'pop-value',
          removedValue: lastSelectedValue
        });
      }
    };
    _this.getFocusedOptionId = function (focusedOption) {
      return getFocusedOptionId(_this.state.focusableOptionsWithIds, focusedOption);
    };
    _this.getFocusableOptionsWithIds = function () {
      return buildFocusableOptionsWithIds(buildCategorizedOptions(_this.props, _this.state.selectValue), _this.getElementId('option'));
    };
    _this.getValue = function () {
      return _this.state.selectValue;
    };
    _this.cx = function () {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      return classNames.apply(void 0, [_this.props.classNamePrefix].concat(args));
    };
    _this.getOptionLabel = function (data) {
      return getOptionLabel(_this.props, data);
    };
    _this.getOptionValue = function (data) {
      return getOptionValue(_this.props, data);
    };
    _this.getStyles = function (key, props) {
      var unstyled = _this.props.unstyled;
      var base = defaultStyles[key](props, unstyled);
      base.boxSizing = 'border-box';
      var custom = _this.props.styles[key];
      return custom ? custom(base, props) : base;
    };
    _this.getClassNames = function (key, props) {
      var _this$props$className, _this$props$className2;
      return (_this$props$className = (_this$props$className2 = _this.props.classNames)[key]) === null || _this$props$className === void 0 ? void 0 : _this$props$className.call(_this$props$className2, props);
    };
    _this.getElementId = function (element) {
      return "".concat(_this.state.instancePrefix, "-").concat(element);
    };
    _this.getComponents = function () {
      return defaultComponents(_this.props);
    };
    _this.buildCategorizedOptions = function () {
      return buildCategorizedOptions(_this.props, _this.state.selectValue);
    };
    _this.getCategorizedOptions = function () {
      return _this.props.menuIsOpen ? _this.buildCategorizedOptions() : [];
    };
    _this.buildFocusableOptions = function () {
      return buildFocusableOptionsFromCategorizedOptions(_this.buildCategorizedOptions());
    };
    _this.getFocusableOptions = function () {
      return _this.props.menuIsOpen ? _this.buildFocusableOptions() : [];
    };
    _this.ariaOnChange = function (value, actionMeta) {
      _this.setState({
        ariaSelection: objectSpread2_objectSpread2({
          value: value
        }, actionMeta)
      });
    };
    _this.onMenuMouseDown = function (event) {
      if (event.button !== 0) {
        return;
      }
      event.stopPropagation();
      event.preventDefault();
      _this.focusInput();
    };
    _this.onMenuMouseMove = function (event) {
      _this.blockOptionHover = false;
    };
    _this.onControlMouseDown = function (event) {
      // Event captured by dropdown indicator
      if (event.defaultPrevented) {
        return;
      }
      var openMenuOnClick = _this.props.openMenuOnClick;
      if (!_this.state.isFocused) {
        if (openMenuOnClick) {
          _this.openAfterFocus = true;
        }
        _this.focusInput();
      } else if (!_this.props.menuIsOpen) {
        if (openMenuOnClick) {
          _this.openMenu('first');
        }
      } else {
        if (event.target.tagName !== 'INPUT' && event.target.tagName !== 'TEXTAREA') {
          _this.onMenuClose();
        }
      }
      if (event.target.tagName !== 'INPUT' && event.target.tagName !== 'TEXTAREA') {
        event.preventDefault();
      }
    };
    _this.onDropdownIndicatorMouseDown = function (event) {
      // ignore mouse events that weren't triggered by the primary button
      if (event && event.type === 'mousedown' && event.button !== 0) {
        return;
      }
      if (_this.props.isDisabled) return;
      var _this$props4 = _this.props,
        isMulti = _this$props4.isMulti,
        menuIsOpen = _this$props4.menuIsOpen;
      _this.focusInput();
      if (menuIsOpen) {
        _this.setState({
          inputIsHiddenAfterUpdate: !isMulti
        });
        _this.onMenuClose();
      } else {
        _this.openMenu('first');
      }
      event.preventDefault();
    };
    _this.onClearIndicatorMouseDown = function (event) {
      // ignore mouse events that weren't triggered by the primary button
      if (event && event.type === 'mousedown' && event.button !== 0) {
        return;
      }
      _this.clearValue();
      event.preventDefault();
      _this.openAfterFocus = false;
      if (event.type === 'touchend') {
        _this.focusInput();
      } else {
        setTimeout(function () {
          return _this.focusInput();
        });
      }
    };
    _this.onScroll = function (event) {
      if (typeof _this.props.closeMenuOnScroll === 'boolean') {
        if (event.target instanceof HTMLElement && isDocumentElement(event.target)) {
          _this.props.onMenuClose();
        }
      } else if (typeof _this.props.closeMenuOnScroll === 'function') {
        if (_this.props.closeMenuOnScroll(event)) {
          _this.props.onMenuClose();
        }
      }
    };
    _this.onCompositionStart = function () {
      _this.isComposing = true;
    };
    _this.onCompositionEnd = function () {
      _this.isComposing = false;
    };
    _this.onTouchStart = function (_ref2) {
      var touches = _ref2.touches;
      var touch = touches && touches.item(0);
      if (!touch) {
        return;
      }
      _this.initialTouchX = touch.clientX;
      _this.initialTouchY = touch.clientY;
      _this.userIsDragging = false;
    };
    _this.onTouchMove = function (_ref3) {
      var touches = _ref3.touches;
      var touch = touches && touches.item(0);
      if (!touch) {
        return;
      }
      var deltaX = Math.abs(touch.clientX - _this.initialTouchX);
      var deltaY = Math.abs(touch.clientY - _this.initialTouchY);
      var moveThreshold = 5;
      _this.userIsDragging = deltaX > moveThreshold || deltaY > moveThreshold;
    };
    _this.onTouchEnd = function (event) {
      if (_this.userIsDragging) return;

      // close the menu if the user taps outside
      // we're checking on event.target here instead of event.currentTarget, because we want to assert information
      // on events on child elements, not the document (which we've attached this handler to).
      if (_this.controlRef && !_this.controlRef.contains(event.target) && _this.menuListRef && !_this.menuListRef.contains(event.target)) {
        _this.blurInput();
      }

      // reset move vars
      _this.initialTouchX = 0;
      _this.initialTouchY = 0;
    };
    _this.onControlTouchEnd = function (event) {
      if (_this.userIsDragging) return;
      _this.onControlMouseDown(event);
    };
    _this.onClearIndicatorTouchEnd = function (event) {
      if (_this.userIsDragging) return;
      _this.onClearIndicatorMouseDown(event);
    };
    _this.onDropdownIndicatorTouchEnd = function (event) {
      if (_this.userIsDragging) return;
      _this.onDropdownIndicatorMouseDown(event);
    };
    _this.handleInputChange = function (event) {
      var prevInputValue = _this.props.inputValue;
      var inputValue = event.currentTarget.value;
      _this.setState({
        inputIsHiddenAfterUpdate: false
      });
      _this.onInputChange(inputValue, {
        action: 'input-change',
        prevInputValue: prevInputValue
      });
      if (!_this.props.menuIsOpen) {
        _this.onMenuOpen();
      }
    };
    _this.onInputFocus = function (event) {
      if (_this.props.onFocus) {
        _this.props.onFocus(event);
      }
      _this.setState({
        inputIsHiddenAfterUpdate: false,
        isFocused: true
      });
      if (_this.openAfterFocus || _this.props.openMenuOnFocus) {
        _this.openMenu('first');
      }
      _this.openAfterFocus = false;
    };
    _this.onInputBlur = function (event) {
      var prevInputValue = _this.props.inputValue;
      if (_this.menuListRef && _this.menuListRef.contains(document.activeElement)) {
        _this.inputRef.focus();
        return;
      }
      if (_this.props.onBlur) {
        _this.props.onBlur(event);
      }
      _this.onInputChange('', {
        action: 'input-blur',
        prevInputValue: prevInputValue
      });
      _this.onMenuClose();
      _this.setState({
        focusedValue: null,
        isFocused: false
      });
    };
    _this.onOptionHover = function (focusedOption) {
      if (_this.blockOptionHover || _this.state.focusedOption === focusedOption) {
        return;
      }
      var options = _this.getFocusableOptions();
      var focusedOptionIndex = options.indexOf(focusedOption);
      _this.setState({
        focusedOption: focusedOption,
        focusedOptionId: focusedOptionIndex > -1 ? _this.getFocusedOptionId(focusedOption) : null
      });
    };
    _this.shouldHideSelectedOptions = function () {
      return shouldHideSelectedOptions(_this.props);
    };
    _this.onValueInputFocus = function (e) {
      e.preventDefault();
      e.stopPropagation();
      _this.focus();
    };
    _this.onKeyDown = function (event) {
      var _this$props5 = _this.props,
        isMulti = _this$props5.isMulti,
        backspaceRemovesValue = _this$props5.backspaceRemovesValue,
        escapeClearsValue = _this$props5.escapeClearsValue,
        inputValue = _this$props5.inputValue,
        isClearable = _this$props5.isClearable,
        isDisabled = _this$props5.isDisabled,
        menuIsOpen = _this$props5.menuIsOpen,
        onKeyDown = _this$props5.onKeyDown,
        tabSelectsValue = _this$props5.tabSelectsValue,
        openMenuOnFocus = _this$props5.openMenuOnFocus;
      var _this$state = _this.state,
        focusedOption = _this$state.focusedOption,
        focusedValue = _this$state.focusedValue,
        selectValue = _this$state.selectValue;
      if (isDisabled) return;
      if (typeof onKeyDown === 'function') {
        onKeyDown(event);
        if (event.defaultPrevented) {
          return;
        }
      }

      // Block option hover events when the user has just pressed a key
      _this.blockOptionHover = true;
      switch (event.key) {
        case 'ArrowLeft':
          if (!isMulti || inputValue) return;
          _this.focusValue('previous');
          break;
        case 'ArrowRight':
          if (!isMulti || inputValue) return;
          _this.focusValue('next');
          break;
        case 'Delete':
        case 'Backspace':
          if (inputValue) return;
          if (focusedValue) {
            _this.removeValue(focusedValue);
          } else {
            if (!backspaceRemovesValue) return;
            if (isMulti) {
              _this.popValue();
            } else if (isClearable) {
              _this.clearValue();
            }
          }
          break;
        case 'Tab':
          if (_this.isComposing) return;
          if (event.shiftKey || !menuIsOpen || !tabSelectsValue || !focusedOption ||
          // don't capture the event if the menu opens on focus and the focused
          // option is already selected; it breaks the flow of navigation
          openMenuOnFocus && _this.isOptionSelected(focusedOption, selectValue)) {
            return;
          }
          _this.selectOption(focusedOption);
          break;
        case 'Enter':
          if (event.keyCode === 229) {
            // ignore the keydown event from an Input Method Editor(IME)
            // ref. https://www.w3.org/TR/uievents/#determine-keydown-keyup-keyCode
            break;
          }
          if (menuIsOpen) {
            if (!focusedOption) return;
            if (_this.isComposing) return;
            _this.selectOption(focusedOption);
            break;
          }
          return;
        case 'Escape':
          if (menuIsOpen) {
            _this.setState({
              inputIsHiddenAfterUpdate: false
            });
            _this.onInputChange('', {
              action: 'menu-close',
              prevInputValue: inputValue
            });
            _this.onMenuClose();
          } else if (isClearable && escapeClearsValue) {
            _this.clearValue();
          }
          break;
        case ' ':
          // space
          if (inputValue) {
            return;
          }
          if (!menuIsOpen) {
            _this.openMenu('first');
            break;
          }
          if (!focusedOption) return;
          _this.selectOption(focusedOption);
          break;
        case 'ArrowUp':
          if (menuIsOpen) {
            _this.focusOption('up');
          } else {
            _this.openMenu('last');
          }
          break;
        case 'ArrowDown':
          if (menuIsOpen) {
            _this.focusOption('down');
          } else {
            _this.openMenu('first');
          }
          break;
        case 'PageUp':
          if (!menuIsOpen) return;
          _this.focusOption('pageup');
          break;
        case 'PageDown':
          if (!menuIsOpen) return;
          _this.focusOption('pagedown');
          break;
        case 'Home':
          if (!menuIsOpen) return;
          _this.focusOption('first');
          break;
        case 'End':
          if (!menuIsOpen) return;
          _this.focusOption('last');
          break;
        default:
          return;
      }
      event.preventDefault();
    };
    _this.state.instancePrefix = 'react-select-' + (_this.props.instanceId || ++instanceId);
    _this.state.selectValue = cleanValue(_props.value);
    // Set focusedOption if menuIsOpen is set on init (e.g. defaultMenuIsOpen)
    if (_props.menuIsOpen && _this.state.selectValue.length) {
      var focusableOptionsWithIds = _this.getFocusableOptionsWithIds();
      var focusableOptions = _this.buildFocusableOptions();
      var optionIndex = focusableOptions.indexOf(_this.state.selectValue[0]);
      _this.state.focusableOptionsWithIds = focusableOptionsWithIds;
      _this.state.focusedOption = focusableOptions[optionIndex];
      _this.state.focusedOptionId = getFocusedOptionId(focusableOptionsWithIds, focusableOptions[optionIndex]);
    }
    return _this;
  }
  _createClass(Select, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.startListeningComposition();
      this.startListeningToTouch();
      if (this.props.closeMenuOnScroll && document && document.addEventListener) {
        // Listen to all scroll events, and filter them out inside of 'onScroll'
        document.addEventListener('scroll', this.onScroll, true);
      }
      if (this.props.autoFocus) {
        this.focusInput();
      }

      // Scroll focusedOption into view if menuIsOpen is set on mount (e.g. defaultMenuIsOpen)
      if (this.props.menuIsOpen && this.state.focusedOption && this.menuListRef && this.focusedOptionRef) {
        scrollIntoView(this.menuListRef, this.focusedOptionRef);
      }
      if (isAppleDevice()) {
        // eslint-disable-next-line react/no-did-mount-set-state
        this.setState({
          isAppleDevice: true
        });
      }
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      var _this$props6 = this.props,
        isDisabled = _this$props6.isDisabled,
        menuIsOpen = _this$props6.menuIsOpen;
      var isFocused = this.state.isFocused;
      if (
      // ensure focus is restored correctly when the control becomes enabled
      isFocused && !isDisabled && prevProps.isDisabled ||
      // ensure focus is on the Input when the menu opens
      isFocused && menuIsOpen && !prevProps.menuIsOpen) {
        this.focusInput();
      }
      if (isFocused && isDisabled && !prevProps.isDisabled) {
        // ensure select state gets blurred in case Select is programmatically disabled while focused
        // eslint-disable-next-line react/no-did-update-set-state
        this.setState({
          isFocused: false
        }, this.onMenuClose);
      } else if (!isFocused && !isDisabled && prevProps.isDisabled && this.inputRef === document.activeElement) {
        // ensure select state gets focused in case Select is programatically re-enabled while focused (Firefox)
        // eslint-disable-next-line react/no-did-update-set-state
        this.setState({
          isFocused: true
        });
      }

      // scroll the focused option into view if necessary
      if (this.menuListRef && this.focusedOptionRef && this.scrollToFocusedOptionOnUpdate) {
        scrollIntoView(this.menuListRef, this.focusedOptionRef);
        this.scrollToFocusedOptionOnUpdate = false;
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.stopListeningComposition();
      this.stopListeningToTouch();
      document.removeEventListener('scroll', this.onScroll, true);
    }

    // ==============================
    // Consumer Handlers
    // ==============================
  }, {
    key: "onMenuOpen",
    value: function onMenuOpen() {
      this.props.onMenuOpen();
    }
  }, {
    key: "onMenuClose",
    value: function onMenuClose() {
      this.onInputChange('', {
        action: 'menu-close',
        prevInputValue: this.props.inputValue
      });
      this.props.onMenuClose();
    }
  }, {
    key: "onInputChange",
    value: function onInputChange(newValue, actionMeta) {
      this.props.onInputChange(newValue, actionMeta);
    }

    // ==============================
    // Methods
    // ==============================
  }, {
    key: "focusInput",
    value: function focusInput() {
      if (!this.inputRef) return;
      this.inputRef.focus();
    }
  }, {
    key: "blurInput",
    value: function blurInput() {
      if (!this.inputRef) return;
      this.inputRef.blur();
    }

    // aliased for consumers
  }, {
    key: "openMenu",
    value: function openMenu(focusOption) {
      var _this2 = this;
      var _this$state2 = this.state,
        selectValue = _this$state2.selectValue,
        isFocused = _this$state2.isFocused;
      var focusableOptions = this.buildFocusableOptions();
      var openAtIndex = focusOption === 'first' ? 0 : focusableOptions.length - 1;
      if (!this.props.isMulti) {
        var selectedIndex = focusableOptions.indexOf(selectValue[0]);
        if (selectedIndex > -1) {
          openAtIndex = selectedIndex;
        }
      }

      // only scroll if the menu isn't already open
      this.scrollToFocusedOptionOnUpdate = !(isFocused && this.menuListRef);
      this.setState({
        inputIsHiddenAfterUpdate: false,
        focusedValue: null,
        focusedOption: focusableOptions[openAtIndex],
        focusedOptionId: this.getFocusedOptionId(focusableOptions[openAtIndex])
      }, function () {
        return _this2.onMenuOpen();
      });
    }
  }, {
    key: "focusValue",
    value: function focusValue(direction) {
      var _this$state3 = this.state,
        selectValue = _this$state3.selectValue,
        focusedValue = _this$state3.focusedValue;

      // Only multiselects support value focusing
      if (!this.props.isMulti) return;
      this.setState({
        focusedOption: null
      });
      var focusedIndex = selectValue.indexOf(focusedValue);
      if (!focusedValue) {
        focusedIndex = -1;
      }
      var lastIndex = selectValue.length - 1;
      var nextFocus = -1;
      if (!selectValue.length) return;
      switch (direction) {
        case 'previous':
          if (focusedIndex === 0) {
            // don't cycle from the start to the end
            nextFocus = 0;
          } else if (focusedIndex === -1) {
            // if nothing is focused, focus the last value first
            nextFocus = lastIndex;
          } else {
            nextFocus = focusedIndex - 1;
          }
          break;
        case 'next':
          if (focusedIndex > -1 && focusedIndex < lastIndex) {
            nextFocus = focusedIndex + 1;
          }
          break;
      }
      this.setState({
        inputIsHidden: nextFocus !== -1,
        focusedValue: selectValue[nextFocus]
      });
    }
  }, {
    key: "focusOption",
    value: function focusOption() {
      var direction = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'first';
      var pageSize = this.props.pageSize;
      var focusedOption = this.state.focusedOption;
      var options = this.getFocusableOptions();
      if (!options.length) return;
      var nextFocus = 0; // handles 'first'
      var focusedIndex = options.indexOf(focusedOption);
      if (!focusedOption) {
        focusedIndex = -1;
      }
      if (direction === 'up') {
        nextFocus = focusedIndex > 0 ? focusedIndex - 1 : options.length - 1;
      } else if (direction === 'down') {
        nextFocus = (focusedIndex + 1) % options.length;
      } else if (direction === 'pageup') {
        nextFocus = focusedIndex - pageSize;
        if (nextFocus < 0) nextFocus = 0;
      } else if (direction === 'pagedown') {
        nextFocus = focusedIndex + pageSize;
        if (nextFocus > options.length - 1) nextFocus = options.length - 1;
      } else if (direction === 'last') {
        nextFocus = options.length - 1;
      }
      this.scrollToFocusedOptionOnUpdate = true;
      this.setState({
        focusedOption: options[nextFocus],
        focusedValue: null,
        focusedOptionId: this.getFocusedOptionId(options[nextFocus])
      });
    }
  }, {
    key: "getTheme",
    value:
    // ==============================
    // Getters
    // ==============================

    function getTheme() {
      // Use the default theme if there are no customisations.
      if (!this.props.theme) {
        return defaultTheme;
      }
      // If the theme prop is a function, assume the function
      // knows how to merge the passed-in default theme with
      // its own modifications.
      if (typeof this.props.theme === 'function') {
        return this.props.theme(defaultTheme);
      }
      // Otherwise, if a plain theme object was passed in,
      // overlay it with the default theme.
      return objectSpread2_objectSpread2(objectSpread2_objectSpread2({}, defaultTheme), this.props.theme);
    }
  }, {
    key: "getCommonProps",
    value: function getCommonProps() {
      var clearValue = this.clearValue,
        cx = this.cx,
        getStyles = this.getStyles,
        getClassNames = this.getClassNames,
        getValue = this.getValue,
        selectOption = this.selectOption,
        setValue = this.setValue,
        props = this.props;
      var isMulti = props.isMulti,
        isRtl = props.isRtl,
        options = props.options;
      var hasValue = this.hasValue();
      return {
        clearValue: clearValue,
        cx: cx,
        getStyles: getStyles,
        getClassNames: getClassNames,
        getValue: getValue,
        hasValue: hasValue,
        isMulti: isMulti,
        isRtl: isRtl,
        options: options,
        selectOption: selectOption,
        selectProps: props,
        setValue: setValue,
        theme: this.getTheme()
      };
    }
  }, {
    key: "hasValue",
    value: function hasValue() {
      var selectValue = this.state.selectValue;
      return selectValue.length > 0;
    }
  }, {
    key: "hasOptions",
    value: function hasOptions() {
      return !!this.getFocusableOptions().length;
    }
  }, {
    key: "isClearable",
    value: function isClearable() {
      var _this$props7 = this.props,
        isClearable = _this$props7.isClearable,
        isMulti = _this$props7.isMulti;

      // single select, by default, IS NOT clearable
      // multi select, by default, IS clearable
      if (isClearable === undefined) return isMulti;
      return isClearable;
    }
  }, {
    key: "isOptionDisabled",
    value: function isOptionDisabled(option, selectValue) {
      return _isOptionDisabled(this.props, option, selectValue);
    }
  }, {
    key: "isOptionSelected",
    value: function isOptionSelected(option, selectValue) {
      return _isOptionSelected(this.props, option, selectValue);
    }
  }, {
    key: "filterOption",
    value: function filterOption(option, inputValue) {
      return _filterOption(this.props, option, inputValue);
    }
  }, {
    key: "formatOptionLabel",
    value: function formatOptionLabel(data, context) {
      if (typeof this.props.formatOptionLabel === 'function') {
        var _inputValue = this.props.inputValue;
        var _selectValue = this.state.selectValue;
        return this.props.formatOptionLabel(data, {
          context: context,
          inputValue: _inputValue,
          selectValue: _selectValue
        });
      } else {
        return this.getOptionLabel(data);
      }
    }
  }, {
    key: "formatGroupLabel",
    value: function formatGroupLabel(data) {
      return this.props.formatGroupLabel(data);
    }

    // ==============================
    // Mouse Handlers
    // ==============================
  }, {
    key: "startListeningComposition",
    value:
    // ==============================
    // Composition Handlers
    // ==============================

    function startListeningComposition() {
      if (document && document.addEventListener) {
        document.addEventListener('compositionstart', this.onCompositionStart, false);
        document.addEventListener('compositionend', this.onCompositionEnd, false);
      }
    }
  }, {
    key: "stopListeningComposition",
    value: function stopListeningComposition() {
      if (document && document.removeEventListener) {
        document.removeEventListener('compositionstart', this.onCompositionStart);
        document.removeEventListener('compositionend', this.onCompositionEnd);
      }
    }
  }, {
    key: "startListeningToTouch",
    value:
    // ==============================
    // Touch Handlers
    // ==============================

    function startListeningToTouch() {
      if (document && document.addEventListener) {
        document.addEventListener('touchstart', this.onTouchStart, false);
        document.addEventListener('touchmove', this.onTouchMove, false);
        document.addEventListener('touchend', this.onTouchEnd, false);
      }
    }
  }, {
    key: "stopListeningToTouch",
    value: function stopListeningToTouch() {
      if (document && document.removeEventListener) {
        document.removeEventListener('touchstart', this.onTouchStart);
        document.removeEventListener('touchmove', this.onTouchMove);
        document.removeEventListener('touchend', this.onTouchEnd);
      }
    }
  }, {
    key: "renderInput",
    value:
    // ==============================
    // Renderers
    // ==============================
    function renderInput() {
      var _this$props8 = this.props,
        isDisabled = _this$props8.isDisabled,
        isSearchable = _this$props8.isSearchable,
        inputId = _this$props8.inputId,
        inputValue = _this$props8.inputValue,
        tabIndex = _this$props8.tabIndex,
        form = _this$props8.form,
        menuIsOpen = _this$props8.menuIsOpen,
        required = _this$props8.required;
      var _this$getComponents = this.getComponents(),
        Input = _this$getComponents.Input;
      var _this$state4 = this.state,
        inputIsHidden = _this$state4.inputIsHidden,
        ariaSelection = _this$state4.ariaSelection;
      var commonProps = this.commonProps;
      var id = inputId || this.getElementId('input');

      // aria attributes makes the JSX "noisy", separated for clarity
      var ariaAttributes = objectSpread2_objectSpread2(objectSpread2_objectSpread2(objectSpread2_objectSpread2({
        'aria-autocomplete': 'list',
        'aria-expanded': menuIsOpen,
        'aria-haspopup': true,
        'aria-errormessage': this.props['aria-errormessage'],
        'aria-invalid': this.props['aria-invalid'],
        'aria-label': this.props['aria-label'],
        'aria-labelledby': this.props['aria-labelledby'],
        'aria-required': required,
        role: 'combobox',
        'aria-activedescendant': this.state.isAppleDevice ? undefined : this.state.focusedOptionId || ''
      }, menuIsOpen && {
        'aria-controls': this.getElementId('listbox')
      }), !isSearchable && {
        'aria-readonly': true
      }), this.hasValue() ? (ariaSelection === null || ariaSelection === void 0 ? void 0 : ariaSelection.action) === 'initial-input-focus' && {
        'aria-describedby': this.getElementId('live-region')
      } : {
        'aria-describedby': this.getElementId('placeholder')
      });
      if (!isSearchable) {
        // use a dummy input to maintain focus/blur functionality
        return /*#__PURE__*/react.createElement(DummyInput, extends_extends({
          id: id,
          innerRef: this.getInputRef,
          onBlur: this.onInputBlur,
          onChange: noop,
          onFocus: this.onInputFocus,
          disabled: isDisabled,
          tabIndex: tabIndex,
          inputMode: "none",
          form: form,
          value: ""
        }, ariaAttributes));
      }
      return /*#__PURE__*/react.createElement(Input, extends_extends({}, commonProps, {
        autoCapitalize: "none",
        autoComplete: "off",
        autoCorrect: "off",
        id: id,
        innerRef: this.getInputRef,
        isDisabled: isDisabled,
        isHidden: inputIsHidden,
        onBlur: this.onInputBlur,
        onChange: this.handleInputChange,
        onFocus: this.onInputFocus,
        spellCheck: "false",
        tabIndex: tabIndex,
        form: form,
        type: "text",
        value: inputValue
      }, ariaAttributes));
    }
  }, {
    key: "renderPlaceholderOrValue",
    value: function renderPlaceholderOrValue() {
      var _this3 = this;
      var _this$getComponents2 = this.getComponents(),
        MultiValue = _this$getComponents2.MultiValue,
        MultiValueContainer = _this$getComponents2.MultiValueContainer,
        MultiValueLabel = _this$getComponents2.MultiValueLabel,
        MultiValueRemove = _this$getComponents2.MultiValueRemove,
        SingleValue = _this$getComponents2.SingleValue,
        Placeholder = _this$getComponents2.Placeholder;
      var commonProps = this.commonProps;
      var _this$props9 = this.props,
        controlShouldRenderValue = _this$props9.controlShouldRenderValue,
        isDisabled = _this$props9.isDisabled,
        isMulti = _this$props9.isMulti,
        inputValue = _this$props9.inputValue,
        placeholder = _this$props9.placeholder;
      var _this$state5 = this.state,
        selectValue = _this$state5.selectValue,
        focusedValue = _this$state5.focusedValue,
        isFocused = _this$state5.isFocused;
      if (!this.hasValue() || !controlShouldRenderValue) {
        return inputValue ? null : /*#__PURE__*/react.createElement(Placeholder, extends_extends({}, commonProps, {
          key: "placeholder",
          isDisabled: isDisabled,
          isFocused: isFocused,
          innerProps: {
            id: this.getElementId('placeholder')
          }
        }), placeholder);
      }
      if (isMulti) {
        return selectValue.map(function (opt, index) {
          var isOptionFocused = opt === focusedValue;
          var key = "".concat(_this3.getOptionLabel(opt), "-").concat(_this3.getOptionValue(opt));
          return /*#__PURE__*/react.createElement(MultiValue, extends_extends({}, commonProps, {
            components: {
              Container: MultiValueContainer,
              Label: MultiValueLabel,
              Remove: MultiValueRemove
            },
            isFocused: isOptionFocused,
            isDisabled: isDisabled,
            key: key,
            index: index,
            removeProps: {
              onClick: function onClick() {
                return _this3.removeValue(opt);
              },
              onTouchEnd: function onTouchEnd() {
                return _this3.removeValue(opt);
              },
              onMouseDown: function onMouseDown(e) {
                e.preventDefault();
              }
            },
            data: opt
          }), _this3.formatOptionLabel(opt, 'value'));
        });
      }
      if (inputValue) {
        return null;
      }
      var singleValue = selectValue[0];
      return /*#__PURE__*/react.createElement(SingleValue, extends_extends({}, commonProps, {
        data: singleValue,
        isDisabled: isDisabled
      }), this.formatOptionLabel(singleValue, 'value'));
    }
  }, {
    key: "renderClearIndicator",
    value: function renderClearIndicator() {
      var _this$getComponents3 = this.getComponents(),
        ClearIndicator = _this$getComponents3.ClearIndicator;
      var commonProps = this.commonProps;
      var _this$props10 = this.props,
        isDisabled = _this$props10.isDisabled,
        isLoading = _this$props10.isLoading;
      var isFocused = this.state.isFocused;
      if (!this.isClearable() || !ClearIndicator || isDisabled || !this.hasValue() || isLoading) {
        return null;
      }
      var innerProps = {
        onMouseDown: this.onClearIndicatorMouseDown,
        onTouchEnd: this.onClearIndicatorTouchEnd,
        'aria-hidden': 'true'
      };
      return /*#__PURE__*/react.createElement(ClearIndicator, extends_extends({}, commonProps, {
        innerProps: innerProps,
        isFocused: isFocused
      }));
    }
  }, {
    key: "renderLoadingIndicator",
    value: function renderLoadingIndicator() {
      var _this$getComponents4 = this.getComponents(),
        LoadingIndicator = _this$getComponents4.LoadingIndicator;
      var commonProps = this.commonProps;
      var _this$props11 = this.props,
        isDisabled = _this$props11.isDisabled,
        isLoading = _this$props11.isLoading;
      var isFocused = this.state.isFocused;
      if (!LoadingIndicator || !isLoading) return null;
      var innerProps = {
        'aria-hidden': 'true'
      };
      return /*#__PURE__*/react.createElement(LoadingIndicator, extends_extends({}, commonProps, {
        innerProps: innerProps,
        isDisabled: isDisabled,
        isFocused: isFocused
      }));
    }
  }, {
    key: "renderIndicatorSeparator",
    value: function renderIndicatorSeparator() {
      var _this$getComponents5 = this.getComponents(),
        DropdownIndicator = _this$getComponents5.DropdownIndicator,
        IndicatorSeparator = _this$getComponents5.IndicatorSeparator;

      // separator doesn't make sense without the dropdown indicator
      if (!DropdownIndicator || !IndicatorSeparator) return null;
      var commonProps = this.commonProps;
      var isDisabled = this.props.isDisabled;
      var isFocused = this.state.isFocused;
      return /*#__PURE__*/react.createElement(IndicatorSeparator, extends_extends({}, commonProps, {
        isDisabled: isDisabled,
        isFocused: isFocused
      }));
    }
  }, {
    key: "renderDropdownIndicator",
    value: function renderDropdownIndicator() {
      var _this$getComponents6 = this.getComponents(),
        DropdownIndicator = _this$getComponents6.DropdownIndicator;
      if (!DropdownIndicator) return null;
      var commonProps = this.commonProps;
      var isDisabled = this.props.isDisabled;
      var isFocused = this.state.isFocused;
      var innerProps = {
        onMouseDown: this.onDropdownIndicatorMouseDown,
        onTouchEnd: this.onDropdownIndicatorTouchEnd,
        'aria-hidden': 'true'
      };
      return /*#__PURE__*/react.createElement(DropdownIndicator, extends_extends({}, commonProps, {
        innerProps: innerProps,
        isDisabled: isDisabled,
        isFocused: isFocused
      }));
    }
  }, {
    key: "renderMenu",
    value: function renderMenu() {
      var _this4 = this;
      var _this$getComponents7 = this.getComponents(),
        Group = _this$getComponents7.Group,
        GroupHeading = _this$getComponents7.GroupHeading,
        Menu = _this$getComponents7.Menu,
        MenuList = _this$getComponents7.MenuList,
        MenuPortal = _this$getComponents7.MenuPortal,
        LoadingMessage = _this$getComponents7.LoadingMessage,
        NoOptionsMessage = _this$getComponents7.NoOptionsMessage,
        Option = _this$getComponents7.Option;
      var commonProps = this.commonProps;
      var focusedOption = this.state.focusedOption;
      var _this$props12 = this.props,
        captureMenuScroll = _this$props12.captureMenuScroll,
        inputValue = _this$props12.inputValue,
        isLoading = _this$props12.isLoading,
        loadingMessage = _this$props12.loadingMessage,
        minMenuHeight = _this$props12.minMenuHeight,
        maxMenuHeight = _this$props12.maxMenuHeight,
        menuIsOpen = _this$props12.menuIsOpen,
        menuPlacement = _this$props12.menuPlacement,
        menuPosition = _this$props12.menuPosition,
        menuPortalTarget = _this$props12.menuPortalTarget,
        menuShouldBlockScroll = _this$props12.menuShouldBlockScroll,
        menuShouldScrollIntoView = _this$props12.menuShouldScrollIntoView,
        noOptionsMessage = _this$props12.noOptionsMessage,
        onMenuScrollToTop = _this$props12.onMenuScrollToTop,
        onMenuScrollToBottom = _this$props12.onMenuScrollToBottom;
      if (!menuIsOpen) return null;

      // TODO: Internal Option Type here
      var render = function render(props, id) {
        var type = props.type,
          data = props.data,
          isDisabled = props.isDisabled,
          isSelected = props.isSelected,
          label = props.label,
          value = props.value;
        var isFocused = focusedOption === data;
        var onHover = isDisabled ? undefined : function () {
          return _this4.onOptionHover(data);
        };
        var onSelect = isDisabled ? undefined : function () {
          return _this4.selectOption(data);
        };
        var optionId = "".concat(_this4.getElementId('option'), "-").concat(id);
        var innerProps = {
          id: optionId,
          onClick: onSelect,
          onMouseMove: onHover,
          onMouseOver: onHover,
          tabIndex: -1,
          role: 'option',
          'aria-selected': _this4.state.isAppleDevice ? undefined : isSelected // is not supported on Apple devices
        };

        return /*#__PURE__*/react.createElement(Option, extends_extends({}, commonProps, {
          innerProps: innerProps,
          data: data,
          isDisabled: isDisabled,
          isSelected: isSelected,
          key: optionId,
          label: label,
          type: type,
          value: value,
          isFocused: isFocused,
          innerRef: isFocused ? _this4.getFocusedOptionRef : undefined
        }), _this4.formatOptionLabel(props.data, 'menu'));
      };
      var menuUI;
      if (this.hasOptions()) {
        menuUI = this.getCategorizedOptions().map(function (item) {
          if (item.type === 'group') {
            var _data = item.data,
              options = item.options,
              groupIndex = item.index;
            var groupId = "".concat(_this4.getElementId('group'), "-").concat(groupIndex);
            var headingId = "".concat(groupId, "-heading");
            return /*#__PURE__*/react.createElement(Group, extends_extends({}, commonProps, {
              key: groupId,
              data: _data,
              options: options,
              Heading: GroupHeading,
              headingProps: {
                id: headingId,
                data: item.data
              },
              label: _this4.formatGroupLabel(item.data)
            }), item.options.map(function (option) {
              return render(option, "".concat(groupIndex, "-").concat(option.index));
            }));
          } else if (item.type === 'option') {
            return render(item, "".concat(item.index));
          }
        });
      } else if (isLoading) {
        var message = loadingMessage({
          inputValue: inputValue
        });
        if (message === null) return null;
        menuUI = /*#__PURE__*/react.createElement(LoadingMessage, commonProps, message);
      } else {
        var _message = noOptionsMessage({
          inputValue: inputValue
        });
        if (_message === null) return null;
        menuUI = /*#__PURE__*/react.createElement(NoOptionsMessage, commonProps, _message);
      }
      var menuPlacementProps = {
        minMenuHeight: minMenuHeight,
        maxMenuHeight: maxMenuHeight,
        menuPlacement: menuPlacement,
        menuPosition: menuPosition,
        menuShouldScrollIntoView: menuShouldScrollIntoView
      };
      var menuElement = /*#__PURE__*/react.createElement(MenuPlacer, extends_extends({}, commonProps, menuPlacementProps), function (_ref4) {
        var ref = _ref4.ref,
          _ref4$placerProps = _ref4.placerProps,
          placement = _ref4$placerProps.placement,
          maxHeight = _ref4$placerProps.maxHeight;
        return /*#__PURE__*/react.createElement(Menu, extends_extends({}, commonProps, menuPlacementProps, {
          innerRef: ref,
          innerProps: {
            onMouseDown: _this4.onMenuMouseDown,
            onMouseMove: _this4.onMenuMouseMove
          },
          isLoading: isLoading,
          placement: placement
        }), /*#__PURE__*/react.createElement(ScrollManager, {
          captureEnabled: captureMenuScroll,
          onTopArrive: onMenuScrollToTop,
          onBottomArrive: onMenuScrollToBottom,
          lockEnabled: menuShouldBlockScroll
        }, function (scrollTargetRef) {
          return /*#__PURE__*/react.createElement(MenuList, extends_extends({}, commonProps, {
            innerRef: function innerRef(instance) {
              _this4.getMenuListRef(instance);
              scrollTargetRef(instance);
            },
            innerProps: {
              role: 'listbox',
              'aria-multiselectable': commonProps.isMulti,
              id: _this4.getElementId('listbox')
            },
            isLoading: isLoading,
            maxHeight: maxHeight,
            focusedOption: focusedOption
          }), menuUI);
        }));
      });

      // positioning behaviour is almost identical for portalled and fixed,
      // so we use the same component. the actual portalling logic is forked
      // within the component based on `menuPosition`
      return menuPortalTarget || menuPosition === 'fixed' ? /*#__PURE__*/react.createElement(MenuPortal, extends_extends({}, commonProps, {
        appendTo: menuPortalTarget,
        controlElement: this.controlRef,
        menuPlacement: menuPlacement,
        menuPosition: menuPosition
      }), menuElement) : menuElement;
    }
  }, {
    key: "renderFormField",
    value: function renderFormField() {
      var _this5 = this;
      var _this$props13 = this.props,
        delimiter = _this$props13.delimiter,
        isDisabled = _this$props13.isDisabled,
        isMulti = _this$props13.isMulti,
        name = _this$props13.name,
        required = _this$props13.required;
      var selectValue = this.state.selectValue;
      if (required && !this.hasValue() && !isDisabled) {
        return /*#__PURE__*/react.createElement(RequiredInput$1, {
          name: name,
          onFocus: this.onValueInputFocus
        });
      }
      if (!name || isDisabled) return;
      if (isMulti) {
        if (delimiter) {
          var value = selectValue.map(function (opt) {
            return _this5.getOptionValue(opt);
          }).join(delimiter);
          return /*#__PURE__*/react.createElement("input", {
            name: name,
            type: "hidden",
            value: value
          });
        } else {
          var input = selectValue.length > 0 ? selectValue.map(function (opt, i) {
            return /*#__PURE__*/react.createElement("input", {
              key: "i-".concat(i),
              name: name,
              type: "hidden",
              value: _this5.getOptionValue(opt)
            });
          }) : /*#__PURE__*/react.createElement("input", {
            name: name,
            type: "hidden",
            value: ""
          });
          return /*#__PURE__*/react.createElement("div", null, input);
        }
      } else {
        var _value = selectValue[0] ? this.getOptionValue(selectValue[0]) : '';
        return /*#__PURE__*/react.createElement("input", {
          name: name,
          type: "hidden",
          value: _value
        });
      }
    }
  }, {
    key: "renderLiveRegion",
    value: function renderLiveRegion() {
      var commonProps = this.commonProps;
      var _this$state6 = this.state,
        ariaSelection = _this$state6.ariaSelection,
        focusedOption = _this$state6.focusedOption,
        focusedValue = _this$state6.focusedValue,
        isFocused = _this$state6.isFocused,
        selectValue = _this$state6.selectValue;
      var focusableOptions = this.getFocusableOptions();
      return /*#__PURE__*/react.createElement(LiveRegion$1, extends_extends({}, commonProps, {
        id: this.getElementId('live-region'),
        ariaSelection: ariaSelection,
        focusedOption: focusedOption,
        focusedValue: focusedValue,
        isFocused: isFocused,
        selectValue: selectValue,
        focusableOptions: focusableOptions,
        isAppleDevice: this.state.isAppleDevice
      }));
    }
  }, {
    key: "render",
    value: function render() {
      var _this$getComponents8 = this.getComponents(),
        Control = _this$getComponents8.Control,
        IndicatorsContainer = _this$getComponents8.IndicatorsContainer,
        SelectContainer = _this$getComponents8.SelectContainer,
        ValueContainer = _this$getComponents8.ValueContainer;
      var _this$props14 = this.props,
        className = _this$props14.className,
        id = _this$props14.id,
        isDisabled = _this$props14.isDisabled,
        menuIsOpen = _this$props14.menuIsOpen;
      var isFocused = this.state.isFocused;
      var commonProps = this.commonProps = this.getCommonProps();
      return /*#__PURE__*/react.createElement(SelectContainer, extends_extends({}, commonProps, {
        className: className,
        innerProps: {
          id: id,
          onKeyDown: this.onKeyDown
        },
        isDisabled: isDisabled,
        isFocused: isFocused
      }), this.renderLiveRegion(), /*#__PURE__*/react.createElement(Control, extends_extends({}, commonProps, {
        innerRef: this.getControlRef,
        innerProps: {
          onMouseDown: this.onControlMouseDown,
          onTouchEnd: this.onControlTouchEnd
        },
        isDisabled: isDisabled,
        isFocused: isFocused,
        menuIsOpen: menuIsOpen
      }), /*#__PURE__*/react.createElement(ValueContainer, extends_extends({}, commonProps, {
        isDisabled: isDisabled
      }), this.renderPlaceholderOrValue(), this.renderInput()), /*#__PURE__*/react.createElement(IndicatorsContainer, extends_extends({}, commonProps, {
        isDisabled: isDisabled
      }), this.renderClearIndicator(), this.renderLoadingIndicator(), this.renderIndicatorSeparator(), this.renderDropdownIndicator())), this.renderMenu(), this.renderFormField());
    }
  }], [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      var prevProps = state.prevProps,
        clearFocusValueOnUpdate = state.clearFocusValueOnUpdate,
        inputIsHiddenAfterUpdate = state.inputIsHiddenAfterUpdate,
        ariaSelection = state.ariaSelection,
        isFocused = state.isFocused,
        prevWasFocused = state.prevWasFocused,
        instancePrefix = state.instancePrefix;
      var options = props.options,
        value = props.value,
        menuIsOpen = props.menuIsOpen,
        inputValue = props.inputValue,
        isMulti = props.isMulti;
      var selectValue = cleanValue(value);
      var newMenuOptionsState = {};
      if (prevProps && (value !== prevProps.value || options !== prevProps.options || menuIsOpen !== prevProps.menuIsOpen || inputValue !== prevProps.inputValue)) {
        var focusableOptions = menuIsOpen ? buildFocusableOptions(props, selectValue) : [];
        var focusableOptionsWithIds = menuIsOpen ? buildFocusableOptionsWithIds(buildCategorizedOptions(props, selectValue), "".concat(instancePrefix, "-option")) : [];
        var focusedValue = clearFocusValueOnUpdate ? getNextFocusedValue(state, selectValue) : null;
        var focusedOption = getNextFocusedOption(state, focusableOptions);
        var focusedOptionId = getFocusedOptionId(focusableOptionsWithIds, focusedOption);
        newMenuOptionsState = {
          selectValue: selectValue,
          focusedOption: focusedOption,
          focusedOptionId: focusedOptionId,
          focusableOptionsWithIds: focusableOptionsWithIds,
          focusedValue: focusedValue,
          clearFocusValueOnUpdate: false
        };
      }
      // some updates should toggle the state of the input visibility
      var newInputIsHiddenState = inputIsHiddenAfterUpdate != null && props !== prevProps ? {
        inputIsHidden: inputIsHiddenAfterUpdate,
        inputIsHiddenAfterUpdate: undefined
      } : {};
      var newAriaSelection = ariaSelection;
      var hasKeptFocus = isFocused && prevWasFocused;
      if (isFocused && !hasKeptFocus) {
        // If `value` or `defaultValue` props are not empty then announce them
        // when the Select is initially focused
        newAriaSelection = {
          value: valueTernary(isMulti, selectValue, selectValue[0] || null),
          options: selectValue,
          action: 'initial-input-focus'
        };
        hasKeptFocus = !prevWasFocused;
      }

      // If the 'initial-input-focus' action has been set already
      // then reset the ariaSelection to null
      if ((ariaSelection === null || ariaSelection === void 0 ? void 0 : ariaSelection.action) === 'initial-input-focus') {
        newAriaSelection = null;
      }
      return objectSpread2_objectSpread2(objectSpread2_objectSpread2(objectSpread2_objectSpread2({}, newMenuOptionsState), newInputIsHiddenState), {}, {
        prevProps: props,
        ariaSelection: newAriaSelection,
        prevWasFocused: hasKeptFocus
      });
    }
  }]);
  return Select;
}(react.Component);
Select.defaultProps = defaultProps;



;// CONCATENATED MODULE: ./node_modules/react-select/dist/react-select.esm.js


























var StateManagedSelect = /*#__PURE__*/(0,react.forwardRef)(function (props, ref) {
  var baseSelectProps = useStateManager(props);
  return /*#__PURE__*/react.createElement(Select, extends_extends({
    ref: ref
  }, baseSelectProps));
});
var StateManagedSelect$1 = StateManagedSelect;

var NonceProvider = (function (_ref) {
  var nonce = _ref.nonce,
    children = _ref.children,
    cacheKey = _ref.cacheKey;
  var emotionCache = useMemo(function () {
    return createCache({
      key: cacheKey,
      nonce: nonce
    });
  }, [cacheKey, nonce]);
  return /*#__PURE__*/React.createElement(CacheProvider, {
    value: emotionCache
  }, children);
});



;// CONCATENATED MODULE: ./node_modules/react-select/dist/useCreatable-09aaeb9a.esm.js







var useCreatable_09aaeb9a_esm_excluded = ["allowCreateWhileLoading", "createOptionPosition", "formatCreateLabel", "isValidNewOption", "getNewOptionData", "onCreateOption", "options", "onChange"];
var compareOption = function compareOption() {
  var inputValue = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
  var option = arguments.length > 1 ? arguments[1] : undefined;
  var accessors = arguments.length > 2 ? arguments[2] : undefined;
  var candidate = String(inputValue).toLowerCase();
  var optionValue = String(accessors.getOptionValue(option)).toLowerCase();
  var optionLabel = String(accessors.getOptionLabel(option)).toLowerCase();
  return optionValue === candidate || optionLabel === candidate;
};
var builtins = {
  formatCreateLabel: function formatCreateLabel(inputValue) {
    return "Create \"".concat(inputValue, "\"");
  },
  isValidNewOption: function isValidNewOption(inputValue, selectValue, selectOptions, accessors) {
    return !(!inputValue || selectValue.some(function (option) {
      return compareOption(inputValue, option, accessors);
    }) || selectOptions.some(function (option) {
      return compareOption(inputValue, option, accessors);
    }));
  },
  getNewOptionData: function getNewOptionData(inputValue, optionLabel) {
    return {
      label: optionLabel,
      value: inputValue,
      __isNew__: true
    };
  }
};
function useCreatable(_ref) {
  var _ref$allowCreateWhile = _ref.allowCreateWhileLoading,
    allowCreateWhileLoading = _ref$allowCreateWhile === void 0 ? false : _ref$allowCreateWhile,
    _ref$createOptionPosi = _ref.createOptionPosition,
    createOptionPosition = _ref$createOptionPosi === void 0 ? 'last' : _ref$createOptionPosi,
    _ref$formatCreateLabe = _ref.formatCreateLabel,
    formatCreateLabel = _ref$formatCreateLabe === void 0 ? builtins.formatCreateLabel : _ref$formatCreateLabe,
    _ref$isValidNewOption = _ref.isValidNewOption,
    isValidNewOption = _ref$isValidNewOption === void 0 ? builtins.isValidNewOption : _ref$isValidNewOption,
    _ref$getNewOptionData = _ref.getNewOptionData,
    getNewOptionData = _ref$getNewOptionData === void 0 ? builtins.getNewOptionData : _ref$getNewOptionData,
    onCreateOption = _ref.onCreateOption,
    _ref$options = _ref.options,
    propsOptions = _ref$options === void 0 ? [] : _ref$options,
    propsOnChange = _ref.onChange,
    restSelectProps = _objectWithoutProperties(_ref, useCreatable_09aaeb9a_esm_excluded);
  var _restSelectProps$getO = restSelectProps.getOptionValue,
    getOptionValue$1 = _restSelectProps$getO === void 0 ? Select_ef7c0426_esm_getOptionValue$1 : _restSelectProps$getO,
    _restSelectProps$getO2 = restSelectProps.getOptionLabel,
    getOptionLabel$1 = _restSelectProps$getO2 === void 0 ? Select_ef7c0426_esm_getOptionLabel$1 : _restSelectProps$getO2,
    inputValue = restSelectProps.inputValue,
    isLoading = restSelectProps.isLoading,
    isMulti = restSelectProps.isMulti,
    value = restSelectProps.value,
    name = restSelectProps.name;
  var newOption = (0,react.useMemo)(function () {
    return isValidNewOption(inputValue, cleanValue(value), propsOptions, {
      getOptionValue: getOptionValue$1,
      getOptionLabel: getOptionLabel$1
    }) ? getNewOptionData(inputValue, formatCreateLabel(inputValue)) : undefined;
  }, [formatCreateLabel, getNewOptionData, getOptionLabel$1, getOptionValue$1, inputValue, isValidNewOption, propsOptions, value]);
  var options = (0,react.useMemo)(function () {
    return (allowCreateWhileLoading || !isLoading) && newOption ? createOptionPosition === 'first' ? [newOption].concat(_toConsumableArray(propsOptions)) : [].concat(_toConsumableArray(propsOptions), [newOption]) : propsOptions;
  }, [allowCreateWhileLoading, createOptionPosition, isLoading, newOption, propsOptions]);
  var onChange = (0,react.useCallback)(function (newValue, actionMeta) {
    if (actionMeta.action !== 'select-option') {
      return propsOnChange(newValue, actionMeta);
    }
    var valueArray = Array.isArray(newValue) ? newValue : [newValue];
    if (valueArray[valueArray.length - 1] === newOption) {
      if (onCreateOption) onCreateOption(inputValue);else {
        var newOptionData = getNewOptionData(inputValue, inputValue);
        var newActionMeta = {
          action: 'create-option',
          name: name,
          option: newOptionData
        };
        propsOnChange(valueTernary(isMulti, [].concat(_toConsumableArray(cleanValue(value)), [newOptionData]), newOptionData), newActionMeta);
      }
      return;
    }
    propsOnChange(newValue, actionMeta);
  }, [getNewOptionData, inputValue, isMulti, name, newOption, onCreateOption, propsOnChange, value]);
  return objectSpread2_objectSpread2(objectSpread2_objectSpread2({}, restSelectProps), {}, {
    options: options,
    onChange: onChange
  });
}



;// CONCATENATED MODULE: ./node_modules/react-select/creatable/dist/react-select-creatable.esm.js

























var CreatableSelect = /*#__PURE__*/(0,react.forwardRef)(function (props, ref) {
  var creatableProps = useStateManager(props);
  var selectProps = useCreatable(creatableProps);
  return /*#__PURE__*/react.createElement(Select, extends_extends({
    ref: ref
  }, selectProps));
});
var CreatableSelect$1 = CreatableSelect;



;// CONCATENATED MODULE: ./src/scheduled-messages/ScheduledMessagesManager.tsx
/**
 * 定时消息管理主页面
 */












// react-select 选项类型

// react-select 自定义样式
const selectStyles = {
  control: (base, state) => ({
    ...base,
    minHeight: '38px',
    borderColor: state.isFocused ? '#007bff' : '#ddd',
    boxShadow: state.isFocused ? '0 0 0 2px rgba(0, 123, 255, 0.25)' : 'none',
    '&:hover': {
      borderColor: '#007bff'
    }
  }),
  option: (base, state) => ({
    ...base,
    backgroundColor: state.isSelected ? '#007bff' : state.isFocused ? '#e7f3ff' : 'white',
    color: state.isSelected ? 'white' : '#333',
    cursor: 'pointer',
    '&:active': {
      backgroundColor: '#0056b3'
    }
  }),
  multiValue: base => ({
    ...base,
    backgroundColor: '#e7f3ff',
    borderRadius: '4px'
  }),
  multiValueLabel: base => ({
    ...base,
    color: '#007bff',
    fontWeight: 500
  }),
  multiValueRemove: base => ({
    ...base,
    color: '#007bff',
    '&:hover': {
      backgroundColor: '#007bff',
      color: 'white'
    }
  }),
  placeholder: base => ({
    ...base,
    color: '#999'
  }),
  menu: base => ({
    ...base,
    zIndex: 9999
  })
};

// 单选样式
const singleSelectStyles = {
  control: (base, state) => ({
    ...base,
    minHeight: '38px',
    borderColor: state.isFocused ? '#007bff' : '#ddd',
    boxShadow: state.isFocused ? '0 0 0 2px rgba(0, 123, 255, 0.25)' : 'none',
    '&:hover': {
      borderColor: '#007bff'
    }
  }),
  option: (base, state) => ({
    ...base,
    backgroundColor: state.isSelected ? '#007bff' : state.isFocused ? '#e7f3ff' : 'white',
    color: state.isSelected ? 'white' : '#333',
    cursor: 'pointer',
    '&:active': {
      backgroundColor: '#0056b3'
    }
  }),
  singleValue: base => ({
    ...base,
    color: '#333'
  }),
  placeholder: base => ({
    ...base,
    color: '#999'
  }),
  menu: base => ({
    ...base,
    zIndex: 9999
  })
};
const ScheduledMessagesManager = () => {
  const [isInitialized, setIsInitialized] = (0,react.useState)(false);
  const [isLoading, setIsLoading] = (0,react.useState)(true);
  const [config, setConfig] = (0,react.useState)(null);
  const [messages, setMessages] = (0,react.useState)([]);
  const [statistics, setStatistics] = (0,react.useState)({
    total: 0,
    active: 0,
    paused: 0,
    completed: 0,
    done: 0,
    executedToday: 0
  });
  const [service, setService] = (0,react.useState)(null);
  const [showAddDialog, setShowAddDialog] = (0,react.useState)(false);
  const [isSubmitting, setIsSubmitting] = (0,react.useState)(false);
  const [showBotConfigDialog, setShowBotConfigDialog] = (0,react.useState)(false);
  const [botConfigured, setBotConfigured] = (0,react.useState)(false);
  const [showBotConfigWarning, setShowBotConfigWarning] = (0,react.useState)(false);
  const [filterSelfOnly, setFilterSelfOnly] = (0,react.useState)(false);
  const [selectedCategories, setSelectedCategories] = (0,react.useState)([]);
  const [currentUsername, setCurrentUsername] = (0,react.useState)('');
  const [hoveredMessage, setHoveredMessage] = (0,react.useState)(null);
  const [tooltipPosition, setTooltipPosition] = (0,react.useState)({
    x: 0,
    y: 0
  });
  const [isReminderMode, setIsReminderMode] = (0,react.useState)(false);
  const [isUpdating, setIsUpdating] = (0,react.useState)(false);
  const [updateAvailable, setUpdateAvailable] = (0,react.useState)(false);
  const [appScriptVersion, setAppScriptVersion] = (0,react.useState)('');
  const [editingMessage, setEditingMessage] = (0,react.useState)(null);
  (0,react.useEffect)(() => {
    initializeApp();
    getCurrentUserName();
  }, []);

  // 从所有消息中提取 category 选项
  const availableCategories = (0,react.useMemo)(() => {
    const categorySet = new Set();
    messages.forEach(msg => {
      if (msg.Category) {
        msg.Category.split(',').forEach(cat => {
          const trimmed = cat.trim();
          if (trimmed) categorySet.add(trimmed);
        });
      }
    });
    return Array.from(categorySet).sort().map(cat => ({
      value: cat,
      label: cat
    }));
  }, [messages]);
  const initializeApp = async () => {
    try {
      // 检查是否已初始化
      const result = await chrome.storage.local.get(['scheduledMessagesConfig']);
      const savedConfig = result.scheduledMessagesConfig;
      if (savedConfig && savedConfig.sheetId) {
        setConfig(savedConfig);
        setIsInitialized(true);

        // 检查 Bot 是否已配置（从 scheduledMessagesConfig.botExecutor 读取）
        if (savedConfig.botExecutor && savedConfig.botExecutor.ruleId) {
          setBotConfigured(true);
        }

        // 获取 token 并加载数据
        const token = await getAuthToken();
        if (token) {
          const messageService = new ScheduledMessageService(token);
          setService(messageService);
          await loadMessages(messageService);

          // 加载消息后，验证 Bot 配置是否仍然有效
          await checkBotConfigValidity(savedConfig, messageService);
        }
      } else {
        setIsInitialized(false);
      }
    } catch (error) {
      console.error('初始化应用失败:', error);
    } finally {
      setIsLoading(false);
    }
  };
  const loadMessages = async messageService => {
    try {
      const msgs = await messageService.getAllMessages();

      // 同步 JiraAutomation 状态
      const updatedMsgs = await syncJiraAutomationStatus(msgs, messageService);
      setMessages(updatedMsgs);
      const stats = await messageService.getStatistics();
      setStatistics(stats);
    } catch (error) {
      console.error('加载消息失败:', error);
    }
  };

  /**
   * 同步 JiraAutomation 状态
   * 检查 Jira Rule 的实际状态，如果与 Sheet 记录不一致则更新
   */
  const syncJiraAutomationStatus = async (msgs, messageService) => {
    const updatedMsgs = [...msgs];
    let hasUpdates = false;
    for (let i = 0; i < updatedMsgs.length; i++) {
      const msg = updatedMsgs[i];

      // 只处理 JiraAutomation 类型的消息
      if (msg.Push_Method !== 'JiraAutomation' || !msg.Automation_Link) {
        continue;
      }
      try {
        const linkInfo = parseAutomationLink(msg.Automation_Link);
        if (!linkInfo) continue;
        const {
          jiraUrl,
          projectKey,
          ruleId
        } = linkInfo;
        const projectId = await getProjectIdFromKey(jiraUrl, projectKey);
        if (!projectId) continue;

        // 获取 Jira Rule 详情
        const detailResult = await chrome.runtime.sendMessage({
          type: 'GET_JIRA_RULE_DETAILS',
          data: {
            jiraUrl,
            projectId,
            ruleId
          }
        });
        if (detailResult?.success && detailResult.ruleData) {
          const jiraState = detailResult.ruleData.state; // 'ENABLED' 或 'DISABLED'
          const expectedStatus = jiraState === 'ENABLED' ? 'Active' : 'Paused';

          // 如果状态不一致，更新 Sheet
          if (msg.Status !== expectedStatus) {
            console.log(`[同步] Jira Rule ${ruleId} 状态不一致: Sheet=${msg.Status}, Jira=${jiraState}, 更新为 ${expectedStatus}`);

            // 更新本地状态
            updatedMsgs[i] = {
              ...msg,
              Status: expectedStatus
            };

            // 更新 Sheet
            await messageService.updateMessage(msg.ID, {
              Status: expectedStatus
            });
            hasUpdates = true;
          }
        }
      } catch (error) {
        console.warn(`同步 Jira Rule 状态失败 (${msg.Topic}):`, error);
      }
    }
    return hasUpdates ? updatedMsgs : msgs;
  };
  const checkBotConfigValidity = async (savedConfig, messageService) => {
    try {
      // 获取所有消息
      const msgs = await messageService.getAllMessages();

      // 检查是否有待推送的 Bot 消息（Active 状态 + Push_Method 为 Bot）
      const hasPendingBotMessages = msgs.some(msg => msg.Status === 'Active' && msg.Push_Method === 'Bot');

      // 如果没有待推送的 Bot 消息，不需要显示警告
      if (!hasPendingBotMessages) {
        setShowBotConfigWarning(false);
        return;
      }

      // 如果没有配置 Bot，跳过检查
      if (!savedConfig.botExecutor || !savedConfig.botExecutor.ruleId) {
        console.warn('没有配置 Bot 推送规则，但有待推送的 Bot 消息');
        setShowBotConfigWarning(true);
        setBotConfigured(false);
        return;
      }

      // 检查 Jira 规则是否还存在
      const {
        JiraAutomationService
      } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 5704));
      const jiraService = new JiraAutomationService();
      const ruleExists = await jiraService.checkRuleExists({
        jiraUrl: savedConfig.botExecutor.jiraUrl,
        projectKey: savedConfig.botExecutor.projectKey
      }, savedConfig.botExecutor.ruleId);

      // 如果规则不存在且有待推送的 Bot 消息，显示警告
      if (!ruleExists) {
        console.warn('Bot 推送规则不存在，但有待推送的 Bot 消息');
        setShowBotConfigWarning(true);
        setBotConfigured(false);
      } else {
        setShowBotConfigWarning(false);
      }
    } catch (error) {
      console.error('检查 Bot 配置有效性失败:', error);
      // 检查失败不影响正常使用，不显示警告
    }
  };
  const handleInitializationComplete = result => {
    if (result.success) {
      // 刷新页面重新加载
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    }
  };
  const handleSync = async () => {
    if (!service || !config) return;
    setIsLoading(true);
    try {
      await loadMessages(service);

      // 检查并补充 logsSheetId（如果缺失）
      if (config.logsSheetId === undefined || config.logsSheetId === null) {
        console.log('⏳ 同步时发现 logsSheetId 缺失，尝试获取...');
        try {
          const token = await getAuthToken();
          if (token) {
            const logsSheetId = await fetchLogsSheetId(token, config.sheetId);
            if (logsSheetId !== null) {
              // 保存到配置
              const updatedConfig = {
                ...config,
                logsSheetId
              };
              await chrome.storage.local.set({
                scheduledMessagesConfig: updatedConfig
              });
              setConfig(updatedConfig);
              console.log('✅ 已补充 logsSheetId:', logsSheetId);
            }
          }
        } catch (error) {
          console.error('补充 logsSheetId 失败:', error);
        }
      }
    } finally {
      setIsLoading(false);
    }
  };

  // 检查 App Script 更新
  const checkForUpdates = async () => {
    try {
      if (!config || !config.webAppUrl) {
        return;
      }
      const token = await getAuthToken();
      if (!token) {
        return;
      }
      const updater = new AppScriptUpdater(token, config);
      const result = await updater.checkForUpdates();
      if (result.needsUpdate) {
        setUpdateAvailable(true);
        setAppScriptVersion(result.currentVersion);
        console.log(`发现新版本: ${result.latestVersion}`);
      } else {
        setUpdateAvailable(false);
        setAppScriptVersion(result.currentVersion);
      }
    } catch (error) {
      console.error('检查更新失败:', error);
    }
  };

  // 执行升级版本（包含 Sheet Schema、App Script、Jira Rule 三项更新）
  const handleUpgradeVersion = async () => {
    if (!config) return;
    if (!confirm('确定要升级到最新版本吗？\n\n将依次执行以下升级：\n1. Sheet 表结构升级\n2. App Script 代码升级\n3. Jira Automation 规则升级\n\n整个过程可能需要几分钟时间。')) {
      return;
    }
    setIsUpdating(true);
    const updateResults = [];
    try {
      const token = await getAuthToken();
      if (!token) {
        throw new Error('无法获取 Google 授权');
      }

      // 1. 升级 Sheet Schema
      console.log('🔄 开始升级 Sheet Schema...');
      try {
        const schemaUpdater = new SheetSchemaUpdater(token, config);
        const schemaResult = await schemaUpdater.checkAndUpdate();
        if (schemaResult.updated) {
          updateResults.push(`✅ Sheet 表结构已升级\n   新增列: ${schemaResult.addedColumns.join(', ')}`);
        } else {
          updateResults.push('✓ Sheet 表结构已是最新');
        }
      } catch (error) {
        console.error('Sheet Schema 升级失败:', error);
        updateResults.push(`⚠️ Sheet 表结构升级失败: ${error.message}`);
      }

      // 2. 升级 App Script（延迟 3 秒，等待 Schema 更新完成）
      await new Promise(resolve => setTimeout(resolve, 3000));
      console.log('🔄 开始升级 App Script...');
      try {
        const appScriptUpdater = new AppScriptUpdater(token, config);
        const appScriptResult = await appScriptUpdater.updateAppScript();
        if (appScriptResult.success) {
          updateResults.push(`✅ App Script 已升级到 ${appScriptResult.newVersion}`);
          setUpdateAvailable(false);
          setAppScriptVersion(appScriptResult.newVersion || '');
        } else {
          throw new Error(appScriptResult.error || '更新失败');
        }
      } catch (error) {
        console.error('App Script 升级失败:', error);
        updateResults.push(`⚠️ App Script 升级失败: ${error.message}`);
      }

      // 3. 升级 Jira Automation Rule（延迟 5 秒，避免与上面的更新冲突）
      await new Promise(resolve => setTimeout(resolve, 5000));
      console.log('🔄 开始升级 Jira Automation Rule...');
      try {
        const jiraUpdater = new JiraRuleUpdater(config);
        const checkResult = await jiraUpdater.checkForUpdates();
        if (checkResult.needsUpdate) {
          const jiraResult = await jiraUpdater.updateJiraRule();
          if (jiraResult.success) {
            updateResults.push(`✅ Jira Automation 规则已升级到 ${jiraResult.newVersion}`);
          } else {
            throw new Error(jiraResult.error || '更新失败');
          }
        } else {
          updateResults.push('✓ Jira Automation 规则已是最新');
        }
      } catch (error) {
        console.error('Jira Rule 升级失败:', error);
        updateResults.push(`⚠️ Jira Automation 规则升级失败: ${error.message}`);
      }

      // 显示升级结果
      alert(`🎉 版本升级完成！\n\n${updateResults.join('\n\n')}\n\n页面将重新加载以应用更新...`);

      // 重新加载配置
      await initializeApp();
    } catch (error) {
      console.error('版本升级失败:', error);
      alert(`❌ 升级失败: ${error.message}\n\n请稍后重试或联系管理员。`);
    } finally {
      setIsUpdating(false);
    }
  };

  // 组件加载时检查更新
  (0,react.useEffect)(() => {
    if (isInitialized && config) {
      checkForUpdates();
    }
  }, [isInitialized, config]);
  const handleOpenSheet = async () => {
    if (config && config.sheetUrl) {
      // 如果有 logsSheetId，直接打开 Logs 表
      if (config.logsSheetId !== undefined && config.logsSheetId !== null) {
        const url = `${config.sheetUrl.replace('/edit', '')}#gid=${config.logsSheetId}`;
        window.open(url, '_blank');
      } else {
        // 没有 logsSheetId，尝试获取并保存
        console.log('⏳ logsSheetId 未记录，尝试获取...');
        try {
          const token = await getAuthToken();
          if (token && service) {
            const logsSheetId = await fetchLogsSheetId(token, config.sheetId);
            if (logsSheetId !== null) {
              // 保存到配置
              const updatedConfig = {
                ...config,
                logsSheetId
              };
              await chrome.storage.local.set({
                scheduledMessagesConfig: updatedConfig
              });
              setConfig(updatedConfig);

              // 打开 Logs 表
              const url = `${config.sheetUrl.replace('/edit', '')}#gid=${logsSheetId}`;
              window.open(url, '_blank');
              console.log('✅ 已获取并保存 logsSheetId:', logsSheetId);
            } else {
              // 找不到 Logs 表，打开默认页
              window.open(config.sheetUrl, '_blank');
            }
          } else {
            window.open(config.sheetUrl, '_blank');
          }
        } catch (error) {
          console.error('获取 logsSheetId 失败:', error);
          // 出错时打开默认页
          window.open(config.sheetUrl, '_blank');
        }
      }
    }
  };

  // 获取 Logs Sheet ID
  const fetchLogsSheetId = async (token, sheetId) => {
    try {
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}?fields=sheets.properties`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (!response.ok) {
        throw new Error(`获取 Sheet 信息失败: ${response.status}`);
      }
      const data = await response.json();
      const logsSheet = data.sheets.find(s => s.properties.title === 'Logs');
      if (!logsSheet) {
        console.warn('未找到 Logs 工作表');
        return null;
      }
      return logsSheet.properties.sheetId;
    } catch (error) {
      console.error('fetchLogsSheetId 失败:', error);
      return null;
    }
  };
  const handleAddMessage = () => {
    setIsReminderMode(false);
    setEditingMessage(null);
    setShowAddDialog(true);
  };
  const handleAddReminder = () => {
    setIsReminderMode(true);
    setEditingMessage(null);
    setShowAddDialog(true);
  };

  // 托管确认弹窗状态
  const [showTakeoverDialog, setShowTakeoverDialog] = (0,react.useState)(false);
  const [takeoverMessage, setTakeoverMessage] = (0,react.useState)(null);
  const [takeoverLoading, setTakeoverLoading] = (0,react.useState)(false);
  const [takeoverError, setTakeoverError] = (0,react.useState)('');
  const handleEditMessage = async message => {
    // 检查是否是需要托管确认的 JiraAutomation 消息
    // 条件：Push_Method 是 JiraAutomation，有 Schedule_Date，但没有 AI_Endpoint
    const needsTakeoverConfirmation = message.Push_Method === 'JiraAutomation' && message.Schedule_Date && !message.AI_Endpoint && message.Automation_Link;
    if (needsTakeoverConfirmation) {
      // 显示托管确认弹窗
      setTakeoverMessage(message);
      setTakeoverError('');
      setShowTakeoverDialog(true);
      return;
    }

    // 正常编辑流程
    setIsReminderMode(false);
    setEditingMessage(message);
    setShowAddDialog(true);
  };

  // 处理托管确认
  const handleTakeoverConfirm = async () => {
    if (!takeoverMessage || !service) return;
    setTakeoverLoading(true);
    setTakeoverError('');
    try {
      const linkInfo = parseAutomationLink(takeoverMessage.Automation_Link);
      if (!linkInfo) {
        throw new Error('无法解析 Automation_Link');
      }
      const {
        jiraUrl,
        projectKey,
        ruleId
      } = linkInfo;
      const projectId = await getProjectIdFromKey(jiraUrl, projectKey);
      if (!projectId) {
        throw new Error('无法获取项目 ID');
      }

      // 获取规则详情，检查 executionMode
      console.log('🔍 检查规则 executionMode...');
      const detailResult = await chrome.runtime.sendMessage({
        type: 'GET_JIRA_RULE_DETAILS',
        data: {
          jiraUrl,
          projectId,
          ruleId
        }
      });
      if (!detailResult?.success || !detailResult.ruleData) {
        throw new Error('无法获取规则详情');
      }
      const ruleData = detailResult.ruleData;
      const trigger = ruleData.trigger;
      const executionMode = trigger?.value?.executionMode;

      // 检查执行频率是否小于 1 天
      if (trigger && trigger.type === 'jira.jql.scheduled') {
        const schedule = trigger.value?.schedule;
        if (schedule) {
          let intervalTooShort = false;
          let intervalDescription = '';

          // 检查 method=FIXED
          if (schedule.method === 'FIXED') {
            const rateInterval = schedule.rateInterval || 0;

            // rateInterval 单位是分钟，86400 分钟 = 1 天
            if (rateInterval < 86400) {
              intervalTooShort = true;
              const hours = Math.floor(rateInterval / 60);
              const minutes = rateInterval % 60;
              intervalDescription = hours > 0 ? `每 ${hours} 小时 ${minutes > 0 ? minutes + ' 分钟' : ''}` : `每 ${minutes} 分钟`;
            }
          }
          // 检查 method=CRON
          else if (schedule.method === 'CRON') {
            const cronExpression = schedule.cronExpression || '';

            // 解析 CRON 表达式判断频率
            // CRON 格式: 秒 分 时 日 月 周
            // 例如: "0 0 */12 * * ?" = 每 12 小时执行一次
            const parts = cronExpression.split(' ');
            if (parts.length >= 6) {
              const dayOfMonth = parts[3];
              const hours = parts[2];

              // 检查是否是小时级别的执行（时字段包含 */N）
              if (hours.includes('*/')) {
                const hourMatch = hours.match(/^\*\/(\d+)$/);
                if (hourMatch) {
                  const hourInterval = parseInt(hourMatch[1], 10);
                  if (hourInterval < 24) {
                    intervalTooShort = true;
                    intervalDescription = `每 ${hourInterval} 小时`;
                  }
                }
              } else if (hours.includes(',')) {
                // 多个小时执行（例如 "0,6,12,18"）
                const hourList = hours.split(',');
                if (hourList.length > 1) {
                  intervalTooShort = true;
                  intervalDescription = '每天多次执行';
                }
              }

              // 检查是否是每 N 天执行（日字段包含 */N，且 N < 1）
              if (dayOfMonth.includes('*/')) {
                const dayMatch = dayOfMonth.match(/^\*\/(\d+)$/);
                if (dayMatch) {
                  const dayInterval = parseInt(dayMatch[1], 10);
                  if (dayInterval < 1) {
                    intervalTooShort = true;
                    intervalDescription = '小于 1 天';
                  }
                }
              }
            }
          }

          // 如果间隔小于 1 天，显示错误并返回
          if (intervalTooShort) {
            setTakeoverError(`⚠️ 该规则的执行间隔小于 1 天（${intervalDescription}），无法在 Personal AI 中托管。\n\n` + 'Personal AI 的调度系统基于 Google Sheets 和 Apps Script，仅支持每天最多执行一次。\n\n' + '如果需要更高频率的执行，请保持规则在 Jira Automation 中运行。');
            setTakeoverLoading(false);
            return;
          }
        }
      }

      // 检查是否是 nosearch 模式
      if (executionMode !== 'nosearch') {
        setTakeoverError('⚠️ 该规则的触发器使用了 JQL 查询模式（' + (executionMode || 'unknown') + '）。\n\n' + '要使用 Personal AI 托管，请先在 Jira 中修改该规则的 Scheduled trigger 为：\n' + '"Simply run the conditions and actions without providing issues" 模式，\n' + '并使用 JQL branch 替代原有的 Jira 查询功能。\n\n' + '修改完成后，请重新尝试托管。');
        setTakeoverLoading(false);
        return;
      }

      // 执行 webhook 转换
      console.log('🔄 转换规则为 incoming webhook...');
      const webhookResult = await chrome.runtime.sendMessage({
        type: 'CONVERT_JIRA_RULE_TO_WEBHOOK',
        data: {
          ruleId,
          projectId,
          jiraUrl
        }
      });
      if (!webhookResult?.success || !webhookResult.webhookUrl) {
        throw new Error(webhookResult?.error || '转换 webhook 失败');
      }

      // 更新 Sheet 中的 AI_Endpoint
      console.log('📝 更新消息的 AI_Endpoint...');
      const aiEndpoint = `POST ${webhookResult.webhookUrl}`;
      await service.updateMessage(takeoverMessage.ID, {
        AI_Endpoint: aiEndpoint
      });

      // 刷新消息列表
      await loadMessages(service);

      // 关闭弹窗并进入编辑模式
      setShowTakeoverDialog(false);
      setTakeoverMessage(null);

      // 找到更新后的消息并进入编辑模式
      const updatedMessages = await service.getAllMessages();
      const updatedMessage = updatedMessages.find(m => m.ID === takeoverMessage.ID);
      if (updatedMessage) {
        setIsReminderMode(false);
        setEditingMessage(updatedMessage);
        setShowAddDialog(true);
        alert('✅ 已成功将规则托管给 Personal AI！\n现在可以编辑调度配置了。');
      }
    } catch (error) {
      console.error('托管失败:', error);
      setTakeoverError(`托管失败: ${error.message}`);
    } finally {
      setTakeoverLoading(false);
    }
  };

  // 取消托管确认
  const handleTakeoverCancel = () => {
    setShowTakeoverDialog(false);
    setTakeoverMessage(null);
    setTakeoverError('');
  };
  const handleDeleteMessage = async (id, topic) => {
    if (!service) return;

    // 查找消息，检查是否是托管中的 JiraAutomation 消息
    const message = messages.find(m => m.ID === id);
    const isManagedJiraAutomation = message && message.Push_Method === 'JiraAutomation' && message.Schedule_Date && message.AI_Endpoint && message.Automation_Link;
    if (isManagedJiraAutomation) {
      // 托管消息需要特殊处理
      const confirmMessage = `⚠️ 删除托管消息\n\n` + `消息: "${topic}"\n\n` + `此消息正在由 Personal AI 托管，删除后将：\n` + `1. 将 Jira Rule 的 trigger 恢复为 Scheduled 模式\n` + `2. 从 Personal AI 中移除此消息\n\n` + `确定要撤销托管并删除吗？`;
      if (!confirm(confirmMessage)) {
        return;
      }
      setIsLoading(true);
      try {
        // 先恢复 Jira Rule 的 trigger
        const linkInfo = parseAutomationLink(message.Automation_Link);
        if (linkInfo) {
          const {
            jiraUrl,
            projectKey,
            ruleId
          } = linkInfo;
          const projectId = await getProjectIdFromKey(jiraUrl, projectKey);
          if (projectId) {
            console.log('🔄 恢复 Jira Rule 的 scheduled trigger...');

            // 构建调度配置
            const scheduleConfig = {
              scheduleTime: message.Schedule_Time || '09:00',
              repeatEvery: Number(message.Repeat_Every) || 1,
              // 确保转换为数字
              repeatUnit: message.Repeat_Unit || 'Day',
              // TODO: 如果需要支持周几执行，可以从消息中读取
              scheduleDaysOfWeek: undefined
            };
            const convertResult = await chrome.runtime.sendMessage({
              type: 'CONVERT_WEBHOOK_TO_SCHEDULED',
              data: {
                ruleId,
                projectId,
                jiraUrl,
                scheduleConfig
              }
            });
            if (!convertResult?.success) {
              const errorMsg = convertResult?.error || '未知错误';
              // 恢复失败，不删除消息
              alert(`❌ 恢复 Jira Rule 失败: ${errorMsg}\n\n` + `为了数据安全，不会删除 Personal AI 中的消息记录。\n` + `请先手动检查并修复 Jira Rule，然后再尝试删除。`);
              setIsLoading(false);
              return;
            }
          }
        }

        // 只有在恢复成功后才删除消息
        await service.deleteMessage(id);
        await loadMessages(service);
        alert('✅ 消息已删除，Jira Rule 已恢复为 Scheduled 模式。\n\n' + '请前往 Jira Automation 页面确认规则是否正常运作。');
      } catch (error) {
        console.error('删除托管消息失败:', error);
        alert(`删除失败: ${error.message}`);
      } finally {
        setIsLoading(false);
      }
    } else {
      // 普通消息的删除流程
      if (!confirm(`确定要删除消息 "${topic}" 吗？此操作无法撤销。`)) {
        return;
      }
      setIsLoading(true);
      try {
        await service.deleteMessage(id);
        await loadMessages(service);
        alert('消息已删除');
      } catch (error) {
        console.error('删除消息失败:', error);
        alert(`删除失败: ${error.message}`);
      } finally {
        setIsLoading(false);
      }
    }
  };

  // 从 Automation_Link 解析 Jira 信息
  const parseAutomationLink = link => {
    try {
      // 格式: https://jira.ringcentral.com/secure/AutomationProjectAdminAction!default.jspa?projectKey=MTR#/rule/1646
      const url = new URL(link);
      const jiraUrl = url.origin;
      const projectKey = url.searchParams.get('projectKey') || '';
      const ruleIdMatch = link.match(/#\/rule\/(\d+)/);
      const ruleId = ruleIdMatch ? ruleIdMatch[1] : '';
      if (jiraUrl && projectKey && ruleId) {
        return {
          jiraUrl,
          projectKey,
          ruleId
        };
      }
      return null;
    } catch (error) {
      console.error('解析 Automation_Link 失败:', error);
      return null;
    }
  };

  // 获取项目 ID（从项目 key）
  const getProjectIdFromKey = async (jiraUrl, projectKey) => {
    try {
      const response = await fetch(`${jiraUrl}/rest/api/2/project/${projectKey}`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Cache-Control': 'no-cache'
        },
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        return data.id;
      }
      return null;
    } catch (error) {
      console.error('获取项目 ID 失败:', error);
      return null;
    }
  };
  const handleToggleStatus = async message => {
    if (!service) return;
    setIsLoading(true);
    try {
      // 如果有 Automation_Link，同时更新 Jira Rule 状态
      if (message.Automation_Link) {
        const linkInfo = parseAutomationLink(message.Automation_Link);
        if (linkInfo) {
          const {
            jiraUrl,
            projectKey,
            ruleId
          } = linkInfo;
          const projectId = await getProjectIdFromKey(jiraUrl, projectKey);
          if (projectId) {
            // 获取规则详情
            const detailResult = await chrome.runtime.sendMessage({
              type: 'GET_JIRA_RULE_DETAILS',
              data: {
                jiraUrl,
                projectId,
                ruleId
              }
            });
            if (detailResult?.success && detailResult.ruleData) {
              // 更新 Jira Rule 状态
              const newState = message.Status === 'Active' ? 'DISABLED' : 'ENABLED';
              const updateResult = await chrome.runtime.sendMessage({
                type: 'UPDATE_JIRA_RULE_STATE',
                data: {
                  jiraUrl,
                  projectId,
                  ruleId,
                  newState,
                  ruleData: detailResult.ruleData
                }
              });
              if (!updateResult?.success) {
                console.warn('更新 Jira Rule 状态失败:', updateResult?.error);
                // 不阻止本地状态更新，只是给个警告
              }
            }
          }
        }
      }
      await service.toggleMessageStatus(message.ID);
      await loadMessages(service);
    } catch (error) {
      console.error('切换状态失败:', error);
      alert(`切换状态失败: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };
  const handleSubmitNewMessage = async formData => {
    if (!service) return;
    setIsSubmitting(true);
    try {
      if (editingMessage) {
        // 编辑模式：更新消息
        await service.updateMessage(editingMessage.ID, formData);
        await loadMessages(service);
        setShowAddDialog(false);
        setEditingMessage(null);
        alert('消息更新成功！');
      } else {
        // 新建模式：创建消息
        await service.createMessage(formData);
        await loadMessages(service);
        setShowAddDialog(false);
        alert('消息创建成功！');
      }
    } catch (error) {
      console.error(editingMessage ? '更新消息失败:' : '创建消息失败:', error);
      alert(`${editingMessage ? '更新' : '创建'}失败: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleCleanupCompleted = async () => {
    if (!service) return;
    if (!confirm(`确定要删除所有已完成的消息吗？\n共 ${statistics.done} 条消息将被永久删除。`)) {
      return;
    }
    try {
      const deletedCount = await service.deleteCompletedMessages();
      await loadMessages(service);
      alert(`成功清理 ${deletedCount} 条已完成的消息！`);
    } catch (error) {
      console.error('清理已完成消息失败:', error);
      alert(`清理失败: ${error.message}`);
    }
  };
  const getAuthToken = () => {
    return new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({
        interactive: true
      }, token => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(token || '');
        }
      });
    });
  };
  const getCurrentUserName = async () => {
    try {
      const token = await getAuthToken();
      const response = await fetch('https://www.googleapis.com/oauth2/v1/userinfo?alt=json', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (response.ok) {
        const userInfo = await response.json();
        // userInfo.email 格式如：esone.qiu@ringcentral.com
        const email = userInfo.email || '';
        const username = email.split('@')[0]; // 提取 esone.qiu
        setCurrentUsername(username);
      }
    } catch (error) {
      console.error('获取用户信息失败:', error);
    }
  };

  // 格式化下次执行时间
  const formatNextExec = message => {
    // 检查是否为 Timeline 触发
    if (!message.Schedule_Date && message.Timeline_Milestone) {
      const milestone = message.Timeline_Milestone;
      const offset = message.Timeline_Offset ?? 0;
      let offsetText = '';
      if (offset === 0) {
        offsetText = '当天';
      } else if (offset === 1) {
        offsetText = '后一天';
      } else if (offset === -1) {
        offsetText = '前一天';
      } else if (offset > 1) {
        offsetText = `后${offset}天`;
      } else if (offset < -1) {
        offsetText = `前${Math.abs(offset)}天`;
      }
      return `下次 ${milestone} ${offsetText}`;
    }

    // 时间触发：返回原有的 Next_Exec 值
    return message.Next_Exec || '-';
  };

  // 频率格式化函数
  const formatFrequency = message => {
    // 检查是否为只有 Automation_Link 而没有 Schedule_Date 的 Jira Automation 规则
    if (message.Automation_Link && !message.Schedule_Date) {
      return 'JIRA触发器';
    }

    // 检查是否为 Timeline 触发
    if (!message.Schedule_Date && message.Timeline_Milestone) {
      const milestone = message.Timeline_Milestone;
      const offset = message.Timeline_Offset ?? 0;
      let offsetText = '';
      if (offset === 0) {
        offsetText = '当天';
      } else if (offset === 1) {
        offsetText = '后一天';
      } else if (offset === -1) {
        offsetText = '前一天';
      } else if (offset > 1) {
        offsetText = `后${offset}天`;
      } else if (offset < -1) {
        offsetText = `前${Math.abs(offset)}天`;
      }
      const timeText = message.Schedule_Time ? ` ${message.Schedule_Time}` : ' 早上';
      return `${milestone} ${offsetText}${timeText}`;
    }

    // 判断是否有重复规则
    if (!message.Repeat_Every || !message.Repeat_Unit) {
      // 一次性任务
      return '推送一次';
    }
    const every = message.Repeat_Every;
    const unit = message.Repeat_Unit;
    const scheduleDate = message.Schedule_Date;
    const scheduleTime = message.Schedule_Time;

    // 根据单位构建频率描述
    let freq = '';
    if (unit === 'Day') {
      if (every === 1) {
        freq = '每天';
      } else {
        freq = `每 ${every} 天`;
      }
    } else if (unit === 'Week') {
      if (every === 1) {
        // 解析 Schedule_Date 获取星期几
        const date = new Date(scheduleDate);
        const weekdays = ['日', '一', '二', '三', '四', '五', '六'];
        const weekday = weekdays[date.getDay()];
        freq = `每周${weekday}`;
      } else {
        freq = `每 ${every} 周`;
      }
    } else if (unit === 'Month') {
      // 从 Schedule_Date 提取日期
      const day = new Date(scheduleDate).getDate();
      if (every === 1) {
        freq = `每月 ${day} 号`;
      } else {
        freq = `每 ${every} 月的 ${day} 号`;
      }
    } else if (unit === 'Year') {
      if (every === 1) {
        const date = new Date(scheduleDate);
        const month = date.getMonth() + 1;
        const day = date.getDate();
        freq = `每年 ${month}/${day}`;
      } else {
        freq = `每 ${every} 年`;
      }
    }

    // 添加时间
    if (scheduleTime) {
      freq += ` ${scheduleTime}`;
    } else {
      freq += ' 早上';
    }
    return freq;
  };

  // 判断消息是否只发给自己
  const isSelfOnlyMessage = message => {
    if (!message.Glip_User_Name || !currentUsername) {
      return false;
    }

    // Glip_User_Name 格式：esone.qiu 或 esone.qiu+john.doe
    const usernames = message.Glip_User_Name.split('+');

    // 只有一个人且是自己
    return usernames.length === 1 && usernames[0] === currentUsername;
  };

  // 根据 Push_Method 显示类型
  const getMessageTypeDisplay = message => {
    // 特殊逻辑：sync.service 显示为系统消息
    if (message.Glip_User_Name === 'sync.service') {
      return '系统消息';
    }
    switch (message.Push_Method) {
      case 'AI':
        return 'AI Report';
      case 'AsMe':
        return '假装我发的';
      case 'Bot':
        return 'Bot 定时';
      case 'JiraAutomation':
        return 'JIRA自动化';
      default:
        return message.Push_Method;
    }
  };

  // 格式化"发给"列的显示
  const formatRecipient = message => {
    // 优先显示用户名
    if (message.Glip_User_Name && message.Glip_User_Name.trim()) {
      const usernames = message.Glip_User_Name.split('+');
      const formattedNames = usernames.map(name => {
        // esone.qiu -> Esone
        const parts = name.split('.');
        if (parts.length > 0) {
          return parts[0].charAt(0).toUpperCase() + parts[0].slice(1);
        }
        return name;
      });
      return formattedNames.join(', ');
    }

    // 否则显示群组 ID
    if (message.Glip_Team_ID && message.Glip_Team_ID.trim()) {
      return message.Glip_Team_ID;
    }
    return '-';
  };
  if (isLoading) {
    return /*#__PURE__*/react.createElement("div", {
      style: ScheduledMessagesManager_styles.loadingContainer
    }, /*#__PURE__*/react.createElement("div", {
      style: ScheduledMessagesManager_styles.spinner
    }), /*#__PURE__*/react.createElement("p", null, "\u52A0\u8F7D\u4E2D..."));
  }
  if (!isInitialized) {
    return /*#__PURE__*/react.createElement(OneClickSetup, {
      onComplete: handleInitializationComplete
    });
  }
  return /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.container
  }, /*#__PURE__*/react.createElement("header", {
    style: ScheduledMessagesManager_styles.header
  }, /*#__PURE__*/react.createElement("h1", {
    style: ScheduledMessagesManager_styles.title
  }, "\u23F0 \u5B9A\u65F6\u6D88\u606F\u7BA1\u7406"), /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.headerActions
  }, /*#__PURE__*/react.createElement("button", {
    style: ScheduledMessagesManager_styles.reminderButton,
    onClick: handleAddReminder,
    title: "\u5FEB\u901F\u521B\u5EFA\u4E2A\u4EBA\u63D0\u9192"
  }, "\u23F0 \u63D0\u9192\u6211"), /*#__PURE__*/react.createElement("button", {
    style: ScheduledMessagesManager_styles.addButton,
    onClick: handleAddMessage,
    title: "\u65B0\u589E\u6D88\u606F"
  }, "\u2795 \u65B0\u589E"), /*#__PURE__*/react.createElement("button", {
    style: ScheduledMessagesManager_styles.syncButton,
    onClick: handleSync,
    title: "\u540C\u6B65\u6570\u636E"
  }, "\uD83D\uDD04 \u540C\u6B65"), updateAvailable && /*#__PURE__*/react.createElement("button", {
    style: ScheduledMessagesManager_styles.updateButton,
    onClick: handleUpgradeVersion,
    disabled: isUpdating,
    title: `当前版本: ${appScriptVersion}，点击升级到最新版本（包含 Sheet、Script、Jira Rule）`
  }, isUpdating ? '⏳ 升级中...' : '🚀 升级版本'), /*#__PURE__*/react.createElement("button", {
    style: ScheduledMessagesManager_styles.configButton,
    onClick: handleOpenSheet,
    title: "\u67E5\u770B\u63A8\u9001\u8BB0\u5F55"
  }, "\uD83D\uDCCA \u63A8\u9001\u8BB0\u5F55"))), showBotConfigWarning && /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.warningBanner
  }, /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.warningContent
  }, /*#__PURE__*/react.createElement("span", {
    style: ScheduledMessagesManager_styles.warningIcon
  }, "\u26A0\uFE0F"), /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.warningText
  }, /*#__PURE__*/react.createElement("strong", null, "Bot \u63A8\u9001\u914D\u7F6E\u5931\u6548"), /*#__PURE__*/react.createElement("p", {
    style: ScheduledMessagesManager_styles.warningDescription
  }, "\u68C0\u6D4B\u5230\u60A8\u6709\u5F85\u63A8\u9001\u7684 Bot \u6D88\u606F\uFF0C\u4F46 Jira Automation \u89C4\u5219\u5DF2\u4E0D\u5B58\u5728\uFF0C\u9700\u8981\u91CD\u65B0\u914D\u7F6E\u3002"))), /*#__PURE__*/react.createElement("button", {
    style: ScheduledMessagesManager_styles.warningButton,
    onClick: () => setShowBotConfigDialog(true)
  }, "\uD83D\uDD27 \u91CD\u65B0\u914D\u7F6E")), /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.statusBar
  }, /*#__PURE__*/react.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '15px',
      flex: 1
    }
  }, /*#__PURE__*/react.createElement("span", {
    style: ScheduledMessagesManager_styles.statusItem
  }, "\uD83D\uDCCA \u72B6\u6001\uFF1A", /*#__PURE__*/react.createElement("strong", null, "\u5DF2\u521D\u59CB\u5316")), /*#__PURE__*/react.createElement("span", {
    style: ScheduledMessagesManager_styles.statusItem
  }, "\u603B\u8BA1: ", /*#__PURE__*/react.createElement("strong", null, statistics.total)), /*#__PURE__*/react.createElement("span", {
    style: ScheduledMessagesManager_styles.statusItem
  }, "\u6D3B\u8DC3: ", /*#__PURE__*/react.createElement("strong", {
    style: {
      color: '#28a745'
    }
  }, statistics.active)), /*#__PURE__*/react.createElement("span", {
    style: ScheduledMessagesManager_styles.statusItem
  }, "\u6682\u505C: ", /*#__PURE__*/react.createElement("strong", {
    style: {
      color: '#ffc107'
    }
  }, statistics.paused)), /*#__PURE__*/react.createElement("span", {
    style: ScheduledMessagesManager_styles.statusItem
  }, "\u5DF2\u5B8C\u6210: ", /*#__PURE__*/react.createElement("strong", {
    style: {
      color: '#6c757d'
    }
  }, statistics.done)), /*#__PURE__*/react.createElement("span", {
    style: ScheduledMessagesManager_styles.statusItem
  }, "\u4ECA\u65E5\u5DF2\u6267\u884C: ", /*#__PURE__*/react.createElement("strong", {
    style: {
      color: '#007bff'
    }
  }, statistics.executedToday))), /*#__PURE__*/react.createElement("div", {
    style: {
      display: 'flex',
      gap: '10px',
      alignItems: 'center'
    }
  }, statistics.done > 0 && /*#__PURE__*/react.createElement("button", {
    onClick: handleCleanupCompleted,
    style: {
      padding: '6px 12px',
      backgroundColor: '#dc3545',
      color: 'white',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '13px',
      fontWeight: 500
    },
    title: `清理 ${statistics.done} 条已完成的消息`
  }, "\uD83D\uDDD1\uFE0F \u6E05\u7406\u5DF2\u5B8C\u6210 (", statistics.done, ")"), /*#__PURE__*/react.createElement("div", {
    style: {
      minWidth: '200px'
    }
  }, /*#__PURE__*/react.createElement(StateManagedSelect$1, {
    isMulti: true,
    options: availableCategories,
    value: selectedCategories,
    onChange: newValue => setSelectedCategories([...newValue]),
    placeholder: "\uD83C\uDFF7\uFE0F \u7B5B\u9009\u7C7B\u522B...",
    styles: selectStyles,
    noOptionsMessage: () => '暂无类别',
    isClearable: true
  })), /*#__PURE__*/react.createElement("label", {
    style: {
      display: 'flex',
      alignItems: 'center',
      cursor: 'pointer',
      fontSize: '13px',
      fontWeight: 500,
      color: '#666',
      userSelect: 'none'
    }
  }, /*#__PURE__*/react.createElement("input", {
    type: "checkbox",
    checked: filterSelfOnly,
    onChange: e => setFilterSelfOnly(e.target.checked),
    style: {
      marginRight: '6px',
      cursor: 'pointer'
    }
  }), "\u8FC7\u6EE4\u6389\u4EC5\u53D1\u6211\u7684"))), /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.content
  }, messages.length === 0 ? /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.emptyState
  }, /*#__PURE__*/react.createElement("p", {
    style: ScheduledMessagesManager_styles.emptyText
  }, "\u6682\u65E0\u5B9A\u65F6\u6D88\u606F"), /*#__PURE__*/react.createElement("p", {
    style: ScheduledMessagesManager_styles.emptyHint
  }, "\u8BF7\u5728 ", /*#__PURE__*/react.createElement("a", {
    href: "#",
    onClick: handleOpenSheet
  }, "Google Sheet"), " \u4E2D\u6DFB\u52A0\u6D88\u606F")) : /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.messageList
  }, /*#__PURE__*/react.createElement("table", {
    style: ScheduledMessagesManager_styles.table
  }, /*#__PURE__*/react.createElement("thead", null, /*#__PURE__*/react.createElement("tr", null, /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u7C7B\u578B"), /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u4E3B\u9898"), /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u7C7B\u522B"), /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u53D1\u7ED9"), /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u9891\u7387"), /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u4E0B\u6B21\u6267\u884C"), /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u5DF2\u53D1"), /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u72B6\u6001"), /*#__PURE__*/react.createElement("th", {
    style: ScheduledMessagesManager_styles.th
  }, "\u64CD\u4F5C"))), /*#__PURE__*/react.createElement("tbody", null, messages.filter(message => {
    // 应用过滤条件
    if (filterSelfOnly && isSelfOnlyMessage(message)) {
      return false;
    }
    // Category 筛选（并集逻辑）
    if (selectedCategories.length > 0) {
      const messageCategories = message.Category ? message.Category.split(',').map(c => c.trim()) : [];
      const hasMatchingCategory = selectedCategories.some(selected => messageCategories.includes(selected.value));
      if (!hasMatchingCategory) {
        return false;
      }
    }
    return true;
  }).map(message => {
    const displayTitle = message.Topic || (message.Content.length > 30 ? message.Content.substring(0, 30) + '...' : message.Content);
    return /*#__PURE__*/react.createElement("tr", {
      key: message.ID,
      style: ScheduledMessagesManager_styles.tr,
      onMouseMove: e => {
        setHoveredMessage(message);
        setTooltipPosition({
          x: e.clientX,
          y: e.clientY
        });
      },
      onMouseLeave: () => {
        setHoveredMessage(null);
      }
    }, /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, /*#__PURE__*/react.createElement("span", {
      style: getTypeStyle(message.Push_Method)
    }, getMessageTypeDisplay(message))), /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, /*#__PURE__*/react.createElement("span", {
      style: ScheduledMessagesManager_styles.topicText
    }, displayTitle)), /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, message.Category ? /*#__PURE__*/react.createElement("div", {
      style: {
        display: 'flex',
        flexWrap: 'wrap',
        gap: '4px'
      }
    }, message.Category.split(',').map((cat, idx) => /*#__PURE__*/react.createElement("span", {
      key: idx,
      style: ScheduledMessagesManager_styles.categoryTag
    }, cat.trim()))) : '-'), /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, formatRecipient(message)), /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, formatFrequency(message)), /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, formatNextExec(message)), /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, message.Exec_Count || 0, " \u6B21"), /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, /*#__PURE__*/react.createElement("span", {
      style: {
        ...getStatusStyle(message.Status),
        cursor: 'pointer'
      },
      onClick: () => handleToggleStatus(message),
      title: `点击切换为${message.Status === 'Active' ? '禁用' : '启用'}`
    }, message.Status)), /*#__PURE__*/react.createElement("td", {
      style: ScheduledMessagesManager_styles.td
    }, /*#__PURE__*/react.createElement("div", {
      style: {
        display: 'flex',
        gap: '6px'
      }
    }, message.Automation_Link && /*#__PURE__*/react.createElement("button", {
      style: ScheduledMessagesManager_styles.jiraLinkButton,
      onClick: () => window.open(message.Automation_Link, '_blank'),
      title: "\u6253\u5F00 Jira Automation Rule"
    }, "\uD83D\uDD17"), !(message.Automation_Link && !message.Schedule_Date) && /*#__PURE__*/react.createElement("button", {
      style: ScheduledMessagesManager_styles.editButton,
      onClick: () => handleEditMessage(message),
      title: "\u7F16\u8F91\u6D88\u606F"
    }, "\u270F\uFE0F"), /*#__PURE__*/react.createElement("button", {
      style: ScheduledMessagesManager_styles.deleteButton,
      onClick: () => handleDeleteMessage(message.ID, displayTitle),
      title: "\u5220\u9664\u6D88\u606F"
    }, "\uD83D\uDDD1\uFE0F"))));
  }))))), /*#__PURE__*/react.createElement("footer", {
    style: ScheduledMessagesManager_styles.footer
  }, /*#__PURE__*/react.createElement("p", {
    style: ScheduledMessagesManager_styles.footerText
  }, "\u63D0\u793A\uFF1A\u7F16\u8F91\u6D88\u606F\u8BF7\u5728 ", /*#__PURE__*/react.createElement("a", {
    href: "#",
    onClick: handleOpenSheet
  }, "Google Sheet"), " \u4E2D\u64CD\u4F5C")), showAddDialog && /*#__PURE__*/react.createElement(AddMessageDialog, {
    onSubmit: handleSubmitNewMessage,
    onCancel: () => {
      setShowAddDialog(false);
      setEditingMessage(null);
    },
    isSubmitting: isSubmitting,
    botConfigured: botConfigured,
    onConfigureBot: () => setShowBotConfigDialog(true),
    isReminderMode: isReminderMode,
    currentUsername: currentUsername,
    availableCategories: availableCategories,
    editingMessage: editingMessage
  }), showBotConfigDialog && config && /*#__PURE__*/react.createElement(BotConfigDialog, {
    config: config,
    onClose: () => setShowBotConfigDialog(false),
    onSuccess: () => {
      setBotConfigured(true);
      setShowBotConfigWarning(false);
      setShowBotConfigDialog(false);
      alert('Bot 推送配置成功！');
    }
  }), showTakeoverDialog && takeoverMessage && /*#__PURE__*/react.createElement("div", {
    style: {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: 1000
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: {
      backgroundColor: 'white',
      borderRadius: '12px',
      padding: '24px',
      maxWidth: '500px',
      width: '90%',
      boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)'
    }
  }, /*#__PURE__*/react.createElement("h3", {
    style: {
      margin: '0 0 16px',
      fontSize: '18px',
      color: '#172B4D'
    }
  }, "\uD83E\uDD16 \u4F7F\u7528 Personal AI \u6258\u7BA1\u6B64\u89C4\u5219\uFF1F"), /*#__PURE__*/react.createElement("div", {
    style: {
      marginBottom: '16px',
      padding: '12px',
      backgroundColor: '#F4F5F7',
      borderRadius: '8px'
    }
  }, /*#__PURE__*/react.createElement("p", {
    style: {
      margin: '0 0 8px',
      fontSize: '14px'
    }
  }, /*#__PURE__*/react.createElement("strong", null, "\u89C4\u5219\uFF1A"), " ", takeoverMessage.Topic), /*#__PURE__*/react.createElement("p", {
    style: {
      margin: '0',
      fontSize: '13px',
      color: '#666'
    }
  }, "\u5F53\u524D\u8C03\u5EA6\uFF1A", takeoverMessage.Schedule_Time, " | \u6BCF ", takeoverMessage.Repeat_Every, " ", takeoverMessage.Repeat_Unit === 'Day' ? '天' : takeoverMessage.Repeat_Unit === 'Week' ? '周' : '月')), /*#__PURE__*/react.createElement("div", {
    style: {
      marginBottom: '16px',
      padding: '12px',
      backgroundColor: '#FFFAE6',
      borderRadius: '8px',
      borderLeft: '3px solid #FFAB00'
    }
  }, /*#__PURE__*/react.createElement("p", {
    style: {
      margin: '0',
      fontSize: '13px',
      color: '#172B4D'
    }
  }, "\u26A0\uFE0F ", /*#__PURE__*/react.createElement("strong", null, "\u6CE8\u610F\uFF1A"), "\u786E\u8BA4\u540E\uFF0C\u89C4\u5219\u7684 Scheduled Trigger \u5C06\u88AB\u8F6C\u6362\u4E3A Incoming Webhook \u6A21\u5F0F\uFF0C \u7531 Personal AI \u63A5\u7BA1\u8C03\u5EA6\u65F6\u95F4\u7BA1\u7406\u3002\u539F\u6709\u7684\u5B9A\u65F6\u89E6\u53D1\u5C06\u88AB\u66FF\u6362\u3002")), takeoverError && /*#__PURE__*/react.createElement("div", {
    style: {
      marginBottom: '16px',
      padding: '12px',
      backgroundColor: '#FFEBE6',
      borderRadius: '8px',
      borderLeft: '3px solid #FF5630'
    }
  }, /*#__PURE__*/react.createElement("p", {
    style: {
      margin: '0',
      fontSize: '13px',
      color: '#BF2600',
      whiteSpace: 'pre-wrap'
    }
  }, takeoverError)), /*#__PURE__*/react.createElement("div", {
    style: {
      display: 'flex',
      gap: '12px',
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/react.createElement("button", {
    onClick: handleTakeoverCancel,
    disabled: takeoverLoading,
    style: {
      padding: '10px 20px',
      border: '1px solid #DFE1E6',
      borderRadius: '6px',
      backgroundColor: 'white',
      cursor: takeoverLoading ? 'not-allowed' : 'pointer',
      fontSize: '14px',
      fontWeight: 500
    }
  }, "\u53D6\u6D88"), /*#__PURE__*/react.createElement("button", {
    onClick: handleTakeoverConfirm,
    disabled: takeoverLoading,
    style: {
      padding: '10px 20px',
      border: 'none',
      borderRadius: '6px',
      backgroundColor: takeoverLoading ? '#ccc' : '#0052cc',
      color: 'white',
      cursor: takeoverLoading ? 'not-allowed' : 'pointer',
      fontSize: '14px',
      fontWeight: 500
    }
  }, takeoverLoading ? '⏳ 处理中...' : '✅ 确认托管')))), hoveredMessage && /*#__PURE__*/react.createElement("div", {
    style: {
      ...ScheduledMessagesManager_styles.tooltip,
      left: `${tooltipPosition.x + 15}px`,
      top: `${tooltipPosition.y + 15}px`
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.tooltipHeader
  }, "\u6D88\u606F\u5185\u5BB9"), /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.tooltipContent
  }, hoveredMessage.Content)));
};

// 变量选择器组件
const VariableSelector = _ref => {
  let {
    onInsert,
    excludeVariables = []
  } = _ref;
  // 项目变量列表（用于检测是否插入了项目变量）- 预留扩展用
  const _projectVariables = ['{currentRelease}', '{currentPhase}', '{currentPhaseStartDate}', '{currentPhaseStartedWorkdays}', '{nextPhase}', '{nextPhaseStartDate}', '{nextPhaseCountdownWorkdays}'];
  const variables = [{
    key: '{Topic}',
    label: '消息主题'
  }, {
    key: '{Content}',
    label: '消息内容'
  }, {
    key: '{TeamID}',
    label: '群组 ID'
  }, {
    key: '{currentRelease}',
    label: '当前 Release',
    isProjectVar: true
  }, {
    key: '{currentPhase}',
    label: '当前 Phase',
    isProjectVar: true
  }, {
    key: '{currentPhaseStartDate}',
    label: '当前 Phase 日期',
    isProjectVar: true
  }, {
    key: '{currentPhaseStartedWorkdays}',
    label: '已过天数',
    isProjectVar: true
  }, {
    key: '{nextPhase}',
    label: '下个 Phase',
    isProjectVar: true
  }, {
    key: '{nextPhaseStartDate}',
    label: '下个 Phase 日期',
    isProjectVar: true
  }, {
    key: '{nextPhaseCountdownWorkdays}',
    label: '距离天数',
    isProjectVar: true
  }].filter(v => !excludeVariables.includes(v.key));
  if (variables.length === 0) return null;
  return /*#__PURE__*/react.createElement("div", {
    style: {
      marginTop: '8px',
      padding: '8px 10px',
      backgroundColor: '#f8f9fa',
      borderRadius: '4px',
      border: '1px solid #e0e0e0',
      fontSize: '12px',
      color: '#666'
    }
  }, /*#__PURE__*/react.createElement("span", {
    style: {
      marginRight: '8px'
    }
  }, "\uD83D\uDCA1 \u63D2\u5165\u53D8\u91CF\uFF1A"), variables.map((variable, index) => /*#__PURE__*/react.createElement(react.Fragment, {
    key: variable.key
  }, index > 0 && /*#__PURE__*/react.createElement("span", {
    style: {
      margin: '0 4px',
      color: '#ccc'
    }
  }, "|"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => onInsert(variable.key),
    style: {
      padding: '2px 8px',
      backgroundColor: '#e0e0e0',
      color: '#555',
      border: 'none',
      borderRadius: '12px',
      cursor: 'pointer',
      fontSize: '12px',
      fontWeight: '500',
      transition: 'background-color 0.2s'
    },
    onMouseEnter: e => {
      e.currentTarget.style.backgroundColor = '#d0d0d0';
    },
    onMouseLeave: e => {
      e.currentTarget.style.backgroundColor = '#e0e0e0';
    },
    title: `插入 ${variable.key}`
  }, variable.label))));
};

// 用户名格式化工具函数
const formatUserName = {
  /**
   * 验证用户名格式（必须包含 first name 和 last name）
   */
  validate: input => {
    const trimmed = input.trim();
    if (!trimmed) return false;

    // 支持两种格式：
    // 1. "Esone Qiu" - 空格分隔
    // 2. "esone.qiu" - 点号分隔
    const parts = trimmed.includes('.') ? trimmed.split('.') : trimmed.split(/\s+/);

    // 必须至少有两个部分（first name 和 last name）
    return parts.length >= 2 && parts.every(p => p.length > 0);
  },
  /**
   * 转换为显示格式："Esone Qiu"
   */
  toDisplayFormat: input => {
    const trimmed = input.trim().toLowerCase();

    // 分割：支持空格或点号
    const parts = trimmed.includes('.') ? trimmed.split('.') : trimmed.split(/\s+/);

    // 首字母大写
    return parts.map(part => part.charAt(0).toUpperCase() + part.slice(1)).join(' ');
  },
  /**
   * 转换为存储格式："esone.qiu"
   */
  toStorageFormat: input => {
    const trimmed = input.trim().toLowerCase();

    // 分割：支持空格或点号
    const parts = trimmed.includes('.') ? trimmed.split('.') : trimmed.split(/\s+/);

    // 用点号连接
    return parts.join('.');
  },
  /**
   * 将多个用户名转换为存储格式（用+连接，用于 Glip_User_Name）
   */
  joinForStorage: displayNames => {
    return displayNames.map(name => formatUserName.toStorageFormat(name)).join('+');
  },
  /**
   * 将多个用户名转换为 mentionList 格式（用,连接，用于 AI Report）
   */
  joinForMentionList: displayNames => {
    return displayNames.map(name => formatUserName.toStorageFormat(name)).join(',');
  }
};

// Tags 输入框组件
const TagsInput = _ref2 => {
  let {
    tags,
    onChange,
    placeholder,
    maxTags,
    disabled
  } = _ref2;
  const [inputValue, setInputValue] = (0,react.useState)('');
  const [error, setError] = (0,react.useState)('');
  const handleKeyDown = e => {
    if (e.key === 'Enter' && inputValue.trim()) {
      e.preventDefault();

      // 验证格式
      if (!formatUserName.validate(inputValue)) {
        setError('请输入完整的姓名（如：Esone Qiu 或 esone.qiu）');
        return;
      }
      if (maxTags && tags.length >= maxTags) {
        setError(`最多只能添加 ${maxTags} 个`);
        return;
      }

      // 转换为显示格式
      const displayName = formatUserName.toDisplayFormat(inputValue);

      // 检查是否已存在（避免重复）
      if (tags.includes(displayName)) {
        setError('该用户已添加');
        return;
      }
      onChange([...tags, displayName]);
      setInputValue('');
      setError('');
    } else if (e.key === 'Backspace' && !inputValue && tags.length > 0) {
      onChange(tags.slice(0, -1));
      setError('');
    }
  };
  const handleInputChange = e => {
    setInputValue(e.target.value);
    if (error) setError(''); // 清除错误提示
  };
  const removeTag = indexToRemove => {
    onChange(tags.filter((_, index) => index !== indexToRemove));
    setError('');
  };
  return /*#__PURE__*/react.createElement("div", null, /*#__PURE__*/react.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '8px',
      padding: '8px',
      border: `1px solid ${error ? '#dc3545' : '#ddd'}`,
      borderRadius: '4px',
      minHeight: '42px',
      backgroundColor: disabled ? '#f5f5f5' : '#fff'
    }
  }, tags.map((tag, index) => /*#__PURE__*/react.createElement("span", {
    key: index,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      padding: '4px 8px',
      backgroundColor: '#007bff',
      color: '#fff',
      borderRadius: '4px',
      fontSize: '14px'
    }
  }, tag, /*#__PURE__*/react.createElement("button", {
    onClick: () => removeTag(index),
    disabled: disabled,
    style: {
      marginLeft: '6px',
      background: 'none',
      border: 'none',
      color: '#fff',
      cursor: 'pointer',
      fontSize: '16px',
      padding: '0'
    }
  }, "\xD7"))), /*#__PURE__*/react.createElement("input", {
    type: "text",
    value: inputValue,
    onChange: handleInputChange,
    onKeyDown: handleKeyDown,
    placeholder: tags.length === 0 ? placeholder : '',
    disabled: disabled,
    style: {
      flex: 1,
      border: 'none',
      outline: 'none',
      minWidth: '120px',
      fontSize: '14px',
      backgroundColor: 'transparent'
    }
  })), error && /*#__PURE__*/react.createElement("div", {
    style: {
      color: '#dc3545',
      fontSize: '12px',
      marginTop: '4px'
    }
  }, error));
};

// AI Header 选项
const AVAILABLE_AI_HEADERS = [{
  value: 'Authorization',
  label: 'Authorization (认证)',
  placeholder: 'Bearer token 或 Basic xxx'
}, {
  value: 'Content-Type',
  label: 'Content-Type (内容类型)',
  placeholder: 'application/json'
}, {
  value: 'Accept',
  label: 'Accept (接受类型)',
  placeholder: 'application/json'
}, {
  value: 'X-API-Key',
  label: 'X-API-Key (API密钥)',
  placeholder: 'sk-xxxxxxx'
}, {
  value: 'User-Agent',
  label: 'User-Agent (用户代理)',
  placeholder: 'MyApp/1.0'
}, {
  value: 'X-Request-ID',
  label: 'X-Request-ID (请求ID)',
  placeholder: 'req-12345'
}, {
  value: 'X-Custom-Header',
  label: 'X-Custom-Header (自定义)',
  placeholder: '自定义值'
}];

// AI Header 类型

// 新增/编辑消息对话框组件
const AddMessageDialog = _ref3 => {
  let {
    onSubmit,
    onCancel,
    isSubmitting,
    botConfigured,
    onConfigureBot,
    isReminderMode = false,
    currentUsername = '',
    availableCategories,
    editingMessage = null
  } = _ref3;
  const isEditMode = !!editingMessage;
  // 格式化时间为 HH:MM 格式（确保两位数）
  const formatTimeToHHMM = time => {
    if (!time) return '';
    // 如果已经是 HH:MM 格式，直接返回
    if (/^\d{2}:\d{2}$/.test(time)) return time;
    // 如果是 H:MM 或 H:M 格式，补零
    const parts = time.split(':');
    if (parts.length === 2) {
      const hours = parts[0].padStart(2, '0');
      const minutes = parts[1].padStart(2, '0');
      return `${hours}:${minutes}`;
    }
    return time;
  };

  // 初始化表单数据（编辑模式时使用现有数据）
  const getInitialFormData = () => {
    if (editingMessage) {
      return {
        Topic: editingMessage.Topic || '',
        Content: editingMessage.Content || '',
        Schedule_Date: editingMessage.Schedule_Date || '',
        Schedule_Time: formatTimeToHHMM(editingMessage.Schedule_Time),
        Push_Method: editingMessage.Push_Method || 'AsMe',
        Target_Type: editingMessage.Glip_Team_ID ? 'group' : 'private',
        Glip_User_Name: editingMessage.Glip_User_Name || '',
        Glip_Team_ID: editingMessage.Glip_Team_ID || '',
        Repeat_Every: editingMessage.Repeat_Every,
        Repeat_Unit: editingMessage.Repeat_Unit,
        Repeat_Count: editingMessage.Repeat_Count,
        End_Date: editingMessage.End_Date,
        AI_Endpoint: editingMessage.AI_Endpoint,
        AI_Headers: editingMessage.AI_Headers,
        AI_Body: editingMessage.AI_Body,
        Timeline_Project: editingMessage.Timeline_Project,
        Timeline_Milestone: editingMessage.Timeline_Milestone,
        Timeline_Offset: editingMessage.Timeline_Offset,
        Category: editingMessage.Category
      };
    }
    return {
      Topic: '',
      Content: '',
      Schedule_Date: new Date().toISOString().split('T')[0],
      Schedule_Time: '',
      Push_Method: 'AsMe',
      Target_Type: 'private',
      Glip_User_Name: '',
      Glip_Team_ID: ''
    };
  };

  // 初始化用户标签（编辑模式时解析现有用户名）
  const getInitialUserTags = () => {
    if (editingMessage && editingMessage.Glip_User_Name) {
      // esone.qiu+john.doe -> ['Esone Qiu', 'John Doe']
      return editingMessage.Glip_User_Name.split('+').map(name => formatUserName.toDisplayFormat(name));
    }
    return [];
  };

  // 初始化分类标签
  const getInitialCategoryTags = () => {
    if (editingMessage && editingMessage.Category) {
      return editingMessage.Category.split(',').map(cat => ({
        value: cat.trim(),
        label: cat.trim()
      }));
    }
    return [];
  };
  const [formData, setFormData] = (0,react.useState)(getInitialFormData);
  const [userTags, setUserTags] = (0,react.useState)(getInitialUserTags);
  const [isRepeating, setIsRepeating] = (0,react.useState)(editingMessage ? !!(editingMessage.Repeat_Every && editingMessage.Repeat_Unit) : false);
  const [aiReportTemplate, setAiReportTemplate] = (0,react.useState)(() => {
    // 编辑模式时，根据 AI_Endpoint 判断模板类型
    if (editingMessage && editingMessage.Push_Method === 'AI' && editingMessage.AI_Endpoint) {
      if (editingMessage.AI_Endpoint.includes('dify.int.rclabenv.com')) {
        return 'ai-report';
      } else if (editingMessage.AI_Endpoint.includes('pep_daily_report')) {
        return 'pep-report';
      }
      return 'custom';
    }
    return 'ai-report';
  });
  const [aiHeaders, setAiHeaders] = (0,react.useState)([]);
  const [isTimelineTrigger, setIsTimelineTrigger] = (0,react.useState)(editingMessage ? !!(editingMessage.Timeline_Milestone && !editingMessage.Schedule_Date) : false);

  // 解析编辑模式下 AI Report Body 的辅助函数
  const parseAiReportBody = () => {
    if (!editingMessage || editingMessage.Push_Method !== 'AI' || !editingMessage.AI_Body) {
      return {
        jql: '',
        outputs: {
          noduedate: false,
          overdue: true,
          toTest: false,
          tickets: true
        },
        ticketIncludes: ['summary', 'status', 'assignee', 'reporter'],
        customOutputs: [],
        teamId: '',
        mentionList: [],
        extraText: ''
      };
    }
    try {
      const body = JSON.parse(editingMessage.AI_Body);
      const inputs = body.inputs || {};

      // 解析 outputs
      const outputsStr = inputs.outputs || '';
      const outputsArr = outputsStr.split(',').map(s => s.trim());

      // 解析 ticketIncludes
      const ticketIncludesStr = inputs.ticketIncludes || 'summary, status, assignee, reporter';
      const ticketIncludesArr = ticketIncludesStr.split(',').map(s => s.trim());

      // 解析 customOutputs（格式：name1:prompt1 | prompt2）
      const customOutputsStr = inputs.customOutputs || '';
      const customOutputsArr = customOutputsStr ? customOutputsStr.split(' | ').map(item => {
        const colonIndex = item.indexOf(':');
        if (colonIndex > 0) {
          return {
            name: item.substring(0, colonIndex),
            prompt: item.substring(colonIndex + 1)
          };
        }
        return {
          name: '',
          prompt: item
        };
      }) : [];

      // 解析 mentionList
      const mentionListStr = inputs.mentionList || '';
      const mentionListArr = mentionListStr ? mentionListStr.split(',').map(s => formatUserName.toDisplayFormat(s.trim())) : [];
      return {
        jql: editingMessage.Content || inputs.jql || '',
        outputs: {
          noduedate: outputsArr.includes('noduedate'),
          overdue: outputsArr.includes('overdue'),
          toTest: outputsArr.includes('toTest'),
          tickets: outputsArr.includes('tickets')
        },
        ticketIncludes: ticketIncludesArr,
        customOutputs: customOutputsArr,
        teamId: editingMessage.Glip_Team_ID || inputs.teamId || '',
        mentionList: mentionListArr,
        extraText: inputs.extraText || ''
      };
    } catch (e) {
      console.error('解析 AI Report Body 失败:', e);
      return {
        jql: editingMessage.Content || '',
        outputs: {
          noduedate: false,
          overdue: true,
          toTest: false,
          tickets: true
        },
        ticketIncludes: ['summary', 'status', 'assignee', 'reporter'],
        customOutputs: [],
        teamId: editingMessage.Glip_Team_ID || '',
        mentionList: [],
        extraText: ''
      };
    }
  };
  const initialAiReportData = parseAiReportBody();

  // AI Report 可视化字段
  const [aiReportJql, setAiReportJql] = (0,react.useState)(initialAiReportData.jql);
  const [aiReportOutputs, setAiReportOutputs] = (0,react.useState)(initialAiReportData.outputs);
  const [ticketIncludes, setTicketIncludes] = (0,react.useState)(initialAiReportData.ticketIncludes);
  const [customOutputs, setCustomOutputs] = (0,react.useState)(initialAiReportData.customOutputs);
  const [showCustomOutputDialog, setShowCustomOutputDialog] = (0,react.useState)(false);
  const [editingCustomOutputIndex, setEditingCustomOutputIndex] = (0,react.useState)(null);
  const [customOutputName, setCustomOutputName] = (0,react.useState)('');
  const [customOutputPrompt, setCustomOutputPrompt] = (0,react.useState)('');
  const [aiReportTeamId, setAiReportTeamId] = (0,react.useState)(initialAiReportData.teamId);
  const [aiReportMentionList, setAiReportMentionList] = (0,react.useState)(initialAiReportData.mentionList);
  const [aiReportExtraText, setAiReportExtraText] = (0,react.useState)(initialAiReportData.extraText);
  const [pepReportTeamId, setPepReportTeamId] = (0,react.useState)(() => {
    // 编辑模式时，如果是 pep-report 类型，初始化 TeamID
    if (editingMessage && editingMessage.Push_Method === 'AI' && editingMessage.AI_Endpoint?.includes('pep_daily_report')) {
      return editingMessage.Glip_Team_ID || '';
    }
    return '';
  });
  const [categoryTags, setCategoryTags] = (0,react.useState)(getInitialCategoryTags);

  // Body 输入框的 ref，用于插入变量
  const bodyTextareaRef = (0,react.useRef)(null);
  const contentTextareaRef = (0,react.useRef)(null);
  const jqlTextareaRef = (0,react.useRef)(null);

  // 提醒模式：展开高级选项的状态
  const [showAdvancedOptions, setShowAdvancedOptions] = (0,react.useState)(false);

  // 提醒模式初始化（仅新建模式时生效）
  react.useEffect(() => {
    if (isReminderMode && !isEditMode) {
      // 自动填充提醒模式的数据
      handleChange('Topic', '个人提醒事项');
      handleChange('Push_Method', 'Bot');
      handleChange('Target_Type', 'private');

      // 填充当前用户名
      if (currentUsername) {
        const displayName = formatUserName.toDisplayFormat(currentUsername);
        setUserTags([displayName]);
      }
    }
  }, [isReminderMode, isEditMode]);

  // 三个模板的数据缓存（内存中，关闭页面后失效）
  const templateCacheRef = react.useRef({
    'ai-report': {
      AI_Endpoint: '',
      AI_Headers: '',
      AI_Body: ''
    },
    'pep-report': {
      AI_Endpoint: '',
      AI_Headers: '',
      AI_Body: ''
    },
    'custom': {
      AI_Endpoint: '',
      AI_Headers: '',
      AI_Body: ''
    }
  });

  // AI Report 预设值
  const aiReportPresets = {
    'ai-report': {
      AI_Endpoint: 'POST https://dify.int.rclabenv.com/v1/chat-messages',
      AI_Headers: 'Authorization: Bearer app-hTAaR1jaLnYDITixXRP5qi4Y\nContent-Type: application/json',
      AI_Body: JSON.stringify({
        response_mode: 'blocking',
        user: 'default-user',
        query: '{Topic}',
        inputs: {
          title: '{Topic}',
          outputs: 'noduedate, overdue, toTest, tickets',
          jql: '{Content}',
          extraText: '',
          teamId: '{TeamID}',
          mentionList: '',
          ticketIncludes: 'summary, status, assignee, reporter'
        }
      }, null, 2)
    },
    'pep-report': {
      AI_Endpoint: 'POST https://gitlab-reviewer.int.rclabenv.com/pep_daily_report',
      AI_Headers: 'Content-Type: application/json',
      AI_Body: JSON.stringify({
        jql: '',
        jira_query_id: 111,
        sheet_id: '',
        sheet_name: '',
        team_id: '{TeamID}',
        mention_list: [],
        overallFilterId: '',
        bugFilterid: '',
        ignore_due_soon: true,
        force_running: true,
        missing_due_check_scope: 'all',
        language: '',
        milestones: [{
          abbreviation: 'MR',
          full_name: 'Code Merge',
          goal: '提测所有功能及安排在本Release的Production Bug'
        }, {
          abbreviation: 'FF',
          full_name: 'Feature Freeze',
          goal: '1）完成所有功能测试；2）完成安排在本Release的所有Production和Release Bug (接近FF 2天内的P2 bug可以Regression阶段修复）'
        }, {
          abbreviation: 'CF',
          full_name: 'Code Freeze',
          goal: '完成所有本Release的功能开发、测试和Bug修复。完成Sign off。提供Dogfooding Build'
        }]
      }, null, 2)
    }
  };

  // 处理模板切换
  const handleTemplateChange = newTemplate => {
    // 保存当前模板的数据到缓存
    if (aiReportTemplate === 'ai-report') {
      // ai-report 使用可视化字段，不需要保存 Body
      templateCacheRef.current[aiReportTemplate] = {
        AI_Endpoint: formData.AI_Endpoint || '',
        AI_Headers: formData.AI_Headers || '',
        AI_Body: '' // ai-report 的 Body 会动态生成
      };
    } else {
      templateCacheRef.current[aiReportTemplate] = {
        AI_Endpoint: formData.AI_Endpoint || '',
        AI_Headers: formData.AI_Headers || '',
        AI_Body: formData.AI_Body || ''
      };
    }

    // 切换到新模板
    setAiReportTemplate(newTemplate);

    // 如果新模板有预设值且缓存为空，使用预设值
    if (newTemplate === 'ai-report' && !templateCacheRef.current['ai-report'].AI_Endpoint) {
      const headersStr = aiReportPresets['ai-report'].AI_Headers;
      handleChange('AI_Endpoint', aiReportPresets['ai-report'].AI_Endpoint);
      handleChange('AI_Headers', headersStr);
      // ai-report 的 Body 会通过可视化字段自动生成，不需要手动设置
      setAiHeaders(parseHeadersString(headersStr));
    } else if (newTemplate === 'pep-report' && !templateCacheRef.current['pep-report'].AI_Endpoint) {
      const headersStr = aiReportPresets['pep-report'].AI_Headers;
      handleChange('AI_Endpoint', aiReportPresets['pep-report'].AI_Endpoint);
      handleChange('AI_Headers', headersStr);
      handleChange('AI_Body', aiReportPresets['pep-report'].AI_Body);
      setAiHeaders(parseHeadersString(headersStr));
    } else {
      // 从缓存恢复数据
      const cached = templateCacheRef.current[newTemplate];
      handleChange('AI_Endpoint', cached.AI_Endpoint);
      handleChange('AI_Headers', cached.AI_Headers);
      if (newTemplate !== 'ai-report') {
        handleChange('AI_Body', cached.AI_Body);
      }
      if (newTemplate === 'custom') {
        setAiHeaders(parseHeadersString(cached.AI_Headers));
      }
    }
  };

  // 构建 AI Report Body JSON
  const buildAiReportBody = () => {
    const outputs = Object.entries(aiReportOutputs).filter(_ref4 => {
      let [, enabled] = _ref4;
      return enabled;
    }).map(_ref5 => {
      let [key] = _ref5;
      return key;
    }).join(', ');
    const inputs = {
      title: '{Topic}',
      outputs: outputs,
      jql: '{Content}',
      extraText: aiReportExtraText,
      teamId: '{TeamID}',
      mentionList: formatUserName.joinForMentionList(aiReportMentionList)
    };

    // 如果选择了列出JQL查询结果，添加 ticketIncludes（逗号分隔字符串）
    if (aiReportOutputs.tickets) {
      inputs.ticketIncludes = ticketIncludes.join(', ');
    }

    // 如果有自定义版块，添加 customOutputs（格式：name1:prompt1 | prompt2）
    if (customOutputs.length > 0) {
      inputs.customOutputs = customOutputs.map(output => output.name ? `${output.name}:${output.prompt}` : output.prompt).join(' | ');
    }
    return JSON.stringify({
      response_mode: 'blocking',
      user: 'default-user',
      query: '{Topic}',
      inputs: inputs
    }, null, 2);
  };

  // 解析 headers 字符串为数组
  const parseHeadersString = headersStr => {
    if (!headersStr) return [];
    const lines = headersStr.split('\n');
    const headers = [];
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      const colonIndex = trimmed.indexOf(':');
      if (colonIndex === -1) continue;
      const name = trimmed.substring(0, colonIndex).trim();
      const value = trimmed.substring(colonIndex + 1).trim();
      if (name && value) {
        headers.push({
          name,
          value
        });
      }
    }
    return headers;
  };

  // 将 headers 数组转换为字符串
  const formatHeadersToString = headers => {
    return headers.filter(h => h.name && h.value).map(h => `${h.name}: ${h.value}`).join('\n');
  };

  // 当 Push_Method 切换到 AI 时，初始化模板（仅新建模式时）
  react.useEffect(() => {
    if (formData.Push_Method === 'AI' && !formData.AI_Endpoint && !isEditMode) {
      setAiReportTemplate('ai-report');
      const headersStr = aiReportPresets['ai-report'].AI_Headers;
      handleChange('AI_Endpoint', aiReportPresets['ai-report'].AI_Endpoint);
      handleChange('AI_Headers', headersStr);
      // ai-report 模板不需要初始化 AI_Body，会通过可视化字段动态生成
      setAiHeaders(parseHeadersString(headersStr));
    }
  }, [formData.Push_Method, isEditMode]);

  // 编辑模式下，初始化 AI Headers
  react.useEffect(() => {
    if (isEditMode && editingMessage?.AI_Headers) {
      setAiHeaders(parseHeadersString(editingMessage.AI_Headers));
    }
  }, [isEditMode, editingMessage]);

  // 当 ai-report 的可视化字段变化时，自动更新 Content 和 AI_Body
  react.useEffect(() => {
    if (formData.Push_Method === 'AI' && aiReportTemplate === 'ai-report') {
      // 同步 JQL 到 Content
      handleChange('Content', aiReportJql);
      // 动态构建 AI_Body
      handleChange('AI_Body', buildAiReportBody());
    }
  }, [aiReportJql, aiReportOutputs, aiReportTeamId, aiReportMentionList, aiReportExtraText, ticketIncludes, customOutputs]);

  // Header 管理函数
  const addAIHeader = () => {
    setAiHeaders([...aiHeaders, {
      name: '',
      value: ''
    }]);
  };
  const updateAIHeaderName = (index, name) => {
    const newHeaders = [...aiHeaders];
    newHeaders[index].name = name;
    setAiHeaders(newHeaders);
    handleChange('AI_Headers', formatHeadersToString(newHeaders));
  };
  const updateAIHeaderValue = (index, value) => {
    const newHeaders = [...aiHeaders];
    newHeaders[index].value = value;
    setAiHeaders(newHeaders);
    handleChange('AI_Headers', formatHeadersToString(newHeaders));
  };
  const removeAIHeader = index => {
    const newHeaders = aiHeaders.filter((_, i) => i !== index);
    setAiHeaders(newHeaders);
    handleChange('AI_Headers', formatHeadersToString(newHeaders));
  };

  // 检查是否是项目变量
  const isProjectVariable = variable => {
    const projectVariables = ['{currentRelease}', '{currentPhase}', '{currentPhaseStartDate}', '{currentPhaseStartedWorkdays}', '{nextPhase}', '{nextPhaseStartDate}', '{nextPhaseCountdownWorkdays}'];
    return projectVariables.includes(variable);
  };

  // 检查内容中是否包含项目变量
  const hasProjectVariables = () => {
    const content = formData.Content || '';
    const aiBody = formData.AI_Body || '';
    const topic = formData.Topic || '';
    const combinedText = content + aiBody + topic;
    const projectVariables = ['{currentRelease}', '{currentPhase}', '{currentPhaseStartDate}', '{currentPhaseStartedWorkdays}', '{nextPhase}', '{nextPhaseStartDate}', '{nextPhaseCountdownWorkdays}'];
    return projectVariables.some(v => combinedText.includes(v));
  };

  // 插入变量到 Body 输入框
  const insertVariableToBody = variable => {
    const textarea = bodyTextareaRef.current;
    if (!textarea) return;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = formData.AI_Body || '';
    const newText = text.substring(0, start) + variable + text.substring(end);
    handleChange('AI_Body', newText);

    // 如果插入的是项目变量，自动设置默认项目（如果还没设置）
    if (isProjectVariable(variable) && !formData.Timeline_Project) {
      handleChange('Timeline_Project', 'mThor');
    }

    // 设置光标位置到插入变量之后
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + variable.length, start + variable.length);
    }, 0);
  };

  // 插入变量到消息内容输入框
  const insertVariableToContent = variable => {
    const textarea = contentTextareaRef.current;
    if (!textarea) return;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = formData.Content || '';
    const newText = text.substring(0, start) + variable + text.substring(end);
    handleChange('Content', newText);

    // 如果插入的是项目变量，自动设置默认项目（如果还没设置）
    if (isProjectVariable(variable) && !formData.Timeline_Project) {
      handleChange('Timeline_Project', 'mThor');
    }

    // 设置光标位置到插入变量之后
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + variable.length, start + variable.length);
    }, 0);
  };

  // 插入变量到 JQL 输入框
  const insertVariableToJql = variable => {
    const textarea = jqlTextareaRef.current;
    if (!textarea) return;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = aiReportJql || '';
    const newText = text.substring(0, start) + variable + text.substring(end);
    setAiReportJql(newText);

    // 如果插入的是项目变量，自动设置默认项目（如果还没设置）
    if (isProjectVariable(variable) && !formData.Timeline_Project) {
      handleChange('Timeline_Project', 'mThor');
    }

    // 设置光标位置到插入变量之后
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + variable.length, start + variable.length);
    }, 0);
  };
  const handleSubmit = e => {
    e.preventDefault();

    // 提醒模式：检查 Bot 是否已配置
    if (isReminderMode && !botConfigured) {
      alert('请先配置 Bot 推送功能才能创建个人提醒');
      return;
    }

    // 验证必填字段
    if (!formData.Topic) {
      alert('请填写消息主题');
      return;
    }

    // 验证触发方式
    if (isTimelineTrigger) {
      // Timeline 触发验证：必须先配置 Bot
      if (!botConfigured) {
        alert('Timeline 触发功能需要先配置 Bot 推送（需要通过 Jira Automation 规则访问 Release 信息）');
        return;
      }
      if (!formData.Timeline_Project || !formData.Timeline_Milestone || formData.Timeline_Offset === undefined) {
        alert('请完整填写 Timeline 触发配置');
        return;
      }
    } else {
      // 时间触发验证
      if (!formData.Schedule_Date) {
        alert('请填写执行日期');
        return;
      }
    }

    // 验证推送目标
    if (formData.Push_Method === 'AI') {
      // AI 消息验证
      if (aiReportTemplate === 'ai-report') {
        // ai-report 模板验证 JQL
        if (!aiReportJql.trim()) {
          alert('请填写 JQL 查询');
          return;
        }
      } else {
        // 其他模板验证 Content 和 Body
        if (!formData.Content) {
          alert('请填写消息内容');
          return;
        }
        if (!formData.AI_Endpoint || !formData.AI_Body) {
          alert('请填写 AI Endpoint 和 Body');
          return;
        }
      }
    } else {
      // Bot/AsMe 消息验证
      if (!formData.Content) {
        alert('请填写消息内容');
        return;
      }

      // 非提醒模式才需要验证推送目标（提醒模式已自动配置）
      if (!isReminderMode && formData.Push_Method !== 'JiraAutomation') {
        if (formData.Target_Type === 'private' && userTags.length === 0) {
          alert('请至少添加一个接收人');
          return;
        }
        if (formData.Target_Type === 'group' && !formData.Glip_Team_ID) {
          alert('请填写群组 ID');
          return;
        }
      }
    }

    // 验证周期性消息
    if (isRepeating) {
      if (!formData.Repeat_Every || !formData.Repeat_Unit) {
        alert('请完整填写重复设置');
        return;
      }
    }

    // 合并 userTags 到 Glip_User_Name（转换为存储格式：esone.qiu+john.doe）
    // 注意：不传递 Target_Type，由 AppScript 动态判断

    // 处理 AI Report 的 Glip_Team_ID
    let glipTeamId = formData.Glip_Team_ID;
    if (formData.Push_Method === 'AI') {
      if (aiReportTemplate === 'ai-report') {
        // ai-report 模板：使用可视化输入框的值
        glipTeamId = aiReportTeamId;
      } else if (aiReportTemplate === 'pep-report') {
        // pep-report 模板：使用专用的输入框值
        glipTeamId = pepReportTeamId;
      }
      // custom 模板：不处理，用户自己负责
    }
    const finalFormData = {
      ...formData,
      Glip_User_Name: formData.Push_Method === 'AI' ? undefined : formatUserName.joinForStorage(userTags),
      Glip_Team_ID: glipTeamId,
      Repeat_Every: isRepeating ? formData.Repeat_Every : undefined,
      Repeat_Unit: isRepeating ? formData.Repeat_Unit : undefined,
      Repeat_Count: isRepeating ? formData.Repeat_Count : undefined,
      End_Date: isRepeating ? formData.End_Date : undefined,
      Category: categoryTags.length > 0 ? categoryTags.map(t => t.value).join(',') : undefined
    };
    onSubmit(finalFormData);
  };
  const handleChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };
  const handleUserTagsChange = tags => {
    setUserTags(tags);
  };
  return /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.overlay
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.dialog
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.header
  }, /*#__PURE__*/react.createElement("h2", {
    style: dialogStyles.title
  }, isEditMode ? '✏️ 编辑定时消息' : isReminderMode ? '⏰ 新增个人提醒' : '➕ 新增定时消息'), /*#__PURE__*/react.createElement("button", {
    style: dialogStyles.closeButton,
    onClick: onCancel
  }, "\u2715")), /*#__PURE__*/react.createElement("form", {
    onSubmit: handleSubmit,
    style: dialogStyles.form
  }, isReminderMode && /*#__PURE__*/react.createElement("div", {
    style: {
      padding: '12px 16px',
      backgroundColor: '#e7f3ff',
      borderRadius: '8px',
      marginBottom: '16px',
      border: '1px solid #b3d7ff'
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: {
      fontSize: '14px',
      color: '#0066cc',
      lineHeight: '1.6'
    }
  }, /*#__PURE__*/react.createElement("strong", null, "\uD83D\uDCA1 \u4E2A\u4EBA\u63D0\u9192\u6A21\u5F0F"), /*#__PURE__*/react.createElement("p", {
    style: {
      margin: '4px 0 0 0',
      fontSize: '13px'
    }
  }, "\u6B64\u6A21\u5F0F\u4F1A\u901A\u8FC7 Bot \u5411\u60A8\u53D1\u9001\u79C1\u4FE1\u63D0\u9192\uFF0C\u65E0\u9700\u914D\u7F6E\u63A8\u9001\u65B9\u5F0F\u548C\u63A5\u6536\u4EBA\u3002"))), !(formData.Push_Method === 'AI' && aiReportTemplate === 'ai-report' && !isReminderMode) && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u6D88\u606F\u5185\u5BB9 *"), /*#__PURE__*/react.createElement("textarea", {
    ref: contentTextareaRef,
    style: dialogStyles.textarea,
    value: formData.Content,
    onChange: e => handleChange('Content', e.target.value),
    placeholder: isReminderMode ? "输入提醒内容" : "输入消息内容",
    rows: 4
  }), !isReminderMode && formData.Push_Method !== 'AsMe' && /*#__PURE__*/react.createElement(VariableSelector, {
    onInsert: insertVariableToContent,
    excludeVariables: ['{Topic}', '{Content}', '{TeamID}']
  })), isReminderMode && /*#__PURE__*/react.createElement("div", {
    style: {
      overflow: 'hidden',
      transition: 'max-height 0.3s ease-in-out, opacity 0.3s ease-in-out',
      maxHeight: showAdvancedOptions ? '2000px' : '0px',
      opacity: showAdvancedOptions ? 1 : 0
    }
  }, !(formData.Push_Method === 'AI' && aiReportTemplate === 'ai-report') && formData.Push_Method !== 'AsMe' && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement(VariableSelector, {
    onInsert: insertVariableToContent,
    excludeVariables: ['{Topic}', '{Content}', '{TeamID}']
  })), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u6D88\u606F\u4E3B\u9898\uFF08\u53EF\u9009\uFF09"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "text",
    value: formData.Topic,
    onChange: e => handleChange('Topic', e.target.value),
    placeholder: "\u8F93\u5165\u6D88\u606F\u4E3B\u9898"
  })), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u89E6\u53D1\u65B9\u5F0F *"), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.buttonGroup
  }, /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: getButtonStyle(!isTimelineTrigger),
    onClick: () => {
      setIsTimelineTrigger(false);
      handleChange('Schedule_Date', new Date().toISOString().split('T')[0]);
      handleChange('Timeline_Project', undefined);
      handleChange('Timeline_Milestone', undefined);
      handleChange('Timeline_Offset', undefined);
    }
  }, "\u23F0 \u65F6\u95F4\u89E6\u53D1"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: getButtonStyle(isTimelineTrigger),
    onClick: () => {
      setIsTimelineTrigger(true);
      handleChange('Schedule_Date', '');
      handleChange('Timeline_Project', 'mThor');
      handleChange('Timeline_Milestone', 'FF');
      handleChange('Timeline_Offset', 0);
    }
  }, "\uD83D\uDCC5 Timeline \u89E6\u53D1"))), !isTimelineTrigger && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: {
      ...dialogStyles.label,
      display: 'flex',
      alignItems: 'center',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/react.createElement("input", {
    type: "checkbox",
    checked: isRepeating,
    onChange: e => {
      setIsRepeating(e.target.checked);
      if (e.target.checked) {
        handleChange('Repeat_Every', 1);
        handleChange('Repeat_Unit', 'Week');
      }
    },
    style: {
      marginRight: '8px'
    }
  }), "\u662F\u5426\u91CD\u590D\u63A8\u9001"))), !isReminderMode && /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u6D88\u606F\u4E3B\u9898 *"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "text",
    value: formData.Topic,
    onChange: e => handleChange('Topic', e.target.value),
    placeholder: "\u8F93\u5165\u6D88\u606F\u4E3B\u9898"
  })), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u89E6\u53D1\u65B9\u5F0F *"), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.buttonGroup
  }, /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: getButtonStyle(!isTimelineTrigger),
    onClick: () => {
      setIsTimelineTrigger(false);
      handleChange('Schedule_Date', new Date().toISOString().split('T')[0]);
      handleChange('Timeline_Project', undefined);
      handleChange('Timeline_Milestone', undefined);
      handleChange('Timeline_Offset', undefined);
    }
  }, "\u23F0 \u65F6\u95F4\u89E6\u53D1"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: getButtonStyle(isTimelineTrigger),
    onClick: () => {
      setIsTimelineTrigger(true);
      handleChange('Schedule_Date', '');
      handleChange('Timeline_Project', 'mThor');
      handleChange('Timeline_Milestone', 'FF');
      handleChange('Timeline_Offset', 0);
    }
  }, "\uD83D\uDCC5 Timeline \u89E6\u53D1")))), !isTimelineTrigger && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formRow
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u6267\u884C\u65E5\u671F *"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "date",
    value: formData.Schedule_Date || '',
    onChange: e => handleChange('Schedule_Date', e.target.value)
  })), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u6267\u884C\u65F6\u95F4"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "time",
    value: formData.Schedule_Time || '',
    onChange: e => handleChange('Schedule_Time', e.target.value),
    placeholder: "09:00"
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u7559\u7A7A\u5219\u6BCF\u65E5\u65E9\u4E0A 9 \u70B9\u5DE6\u53F3\u63A8\u9001"))), isTimelineTrigger && /*#__PURE__*/react.createElement("div", {
    style: {
      ...dialogStyles.section,
      backgroundColor: '#f0f7ff',
      padding: '16px',
      borderRadius: '8px',
      marginBottom: '16px'
    }
  }, !botConfigured && /*#__PURE__*/react.createElement("div", {
    style: {
      padding: '12px',
      backgroundColor: '#fff3cd',
      borderRadius: '6px',
      border: '1px solid #ffc107',
      marginBottom: '16px'
    }
  }, /*#__PURE__*/react.createElement("p", {
    style: {
      margin: '0 0 10px 0',
      color: '#856404',
      fontSize: '14px'
    }
  }, "\u26A0\uFE0F Timeline \u89E6\u53D1\u529F\u80FD\u9700\u8981\u914D\u7F6E Bot \u63A8\u9001\u624D\u80FD\u4F7F\u7528\uFF08\u9700\u8981\u901A\u8FC7 Jira Automation \u89C4\u5219\u8BBF\u95EE Release \u4FE1\u606F\uFF09"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => {
      onConfigureBot();
    },
    style: {
      padding: '8px 16px',
      backgroundColor: '#ffc107',
      color: '#000',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: 'bold'
    }
  }, "\uD83D\uDD27 \u914D\u7F6E Bot \u540E\u542F\u7528")), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formRow
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u9879\u76EE *"), /*#__PURE__*/react.createElement(StateManagedSelect$1, {
    options: [{
      value: 'mThor',
      label: '🚀 mThor'
    }, {
      value: 'Jupiter desktop',
      label: '🖥️ Jupiter Desktop'
    }, {
      value: 'Jupiter web',
      label: '🌐 Jupiter Web'
    }],
    value: {
      value: formData.Timeline_Project || 'mThor',
      label: formData.Timeline_Project === 'Jupiter desktop' ? '🖥️ Jupiter Desktop' : formData.Timeline_Project === 'Jupiter web' ? '🌐 Jupiter Web' : '🚀 mThor'
    },
    onChange: option => option && handleChange('Timeline_Project', option.value),
    styles: singleSelectStyles,
    isDisabled: !botConfigured,
    isSearchable: false
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u65B0\u589E\u8BF7\u8054\u7CFB\u9879\u76EE\u7EC4\u6240\u5728 SDET \u5B8C\u5584 ", /*#__PURE__*/react.createElement("a", {
    href: "https://heimdall-xmn02.int.rclabenv.com/api/swagger/#/bot/bot_get_release_info_retrieve",
    target: "_blank",
    rel: "noopener noreferrer",
    style: {
      color: '#007bff',
      textDecoration: 'underline'
    }
  }, "API"))), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "Milestone *"), /*#__PURE__*/react.createElement(StateManagedSelect$1, {
    options: [{
      value: 'DoR',
      label: '📋 DoR'
    }, {
      value: 'Embedded',
      label: '🔧 Embedded'
    }, {
      value: 'FF',
      label: '🎯 FF'
    }, {
      value: 'Regression',
      label: '🔄 Regression'
    }, {
      value: 'CF',
      label: '❄️ CF'
    }, {
      value: 'Release',
      label: '🚀 Release'
    }],
    value: {
      value: formData.Timeline_Milestone || 'FF',
      label: formData.Timeline_Milestone === 'DoR' ? '📋 DoR' : formData.Timeline_Milestone === 'Embedded' ? '🔧 Embedded' : formData.Timeline_Milestone === 'Regression' ? '🔄 Regression' : formData.Timeline_Milestone === 'CF' ? '❄️ CF' : formData.Timeline_Milestone === 'Release' ? '🚀 Release' : '🎯 FF'
    },
    onChange: option => option && handleChange('Timeline_Milestone', option.value),
    styles: singleSelectStyles,
    isDisabled: !botConfigured,
    isSearchable: false
  }))), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formRow
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u504F\u79FB\u5929\u6570 *"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "number",
    min: "-30",
    max: "30",
    value: formData.Timeline_Offset ?? 0,
    onChange: e => handleChange('Timeline_Offset', parseInt(e.target.value)),
    disabled: !botConfigured
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u8D1F\u6570=\u4E4B\u524D\uFF0C0=\u5F53\u5929\uFF0C\u6B63\u6570=\u4E4B\u540E\u3002\u4F8B\u5982\uFF1A-1 \u8868\u793A Milestone \u524D\u4E00\u5929\uFF0C1 \u8868\u793A\u540E\u4E00\u5929")), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u6267\u884C\u65F6\u95F4"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "time",
    value: formData.Schedule_Time || '',
    onChange: e => handleChange('Schedule_Time', e.target.value),
    placeholder: "09:00",
    disabled: !botConfigured
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u7559\u7A7A\u5219\u6BCF\u65E5\u65E9\u4E0A 9 \u70B9\u5DE6\u53F3\u63A8\u9001")))), !isTimelineTrigger && hasProjectVariables() && formData.Push_Method !== 'AsMe' && /*#__PURE__*/react.createElement("div", {
    style: {
      ...dialogStyles.section,
      backgroundColor: '#fff8e1',
      padding: '12px',
      borderRadius: '8px',
      marginBottom: '16px'
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: {
      marginBottom: '8px',
      color: '#856404',
      fontSize: '13px',
      fontWeight: '500'
    }
  }, "\uD83D\uDCA1 \u68C0\u6D4B\u5230\u9879\u76EE\u53D8\u91CF\uFF0C\u8BF7\u9009\u62E9\u9879\u76EE"), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u9879\u76EE *"), /*#__PURE__*/react.createElement(StateManagedSelect$1, {
    options: [{
      value: 'mThor',
      label: '🚀 mThor'
    }, {
      value: 'Jupiter desktop',
      label: '🖥️ Jupiter Desktop'
    }, {
      value: 'Jupiter web',
      label: '🌐 Jupiter Web'
    }],
    value: {
      value: formData.Timeline_Project || 'mThor',
      label: formData.Timeline_Project === 'Jupiter desktop' ? '🖥️ Jupiter Desktop' : formData.Timeline_Project === 'Jupiter web' ? '🌐 Jupiter Web' : '🚀 mThor'
    },
    onChange: option => option && handleChange('Timeline_Project', option.value),
    styles: singleSelectStyles,
    isSearchable: false
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u9009\u62E9\u9879\u76EE\u4EE5\u66FF\u6362\u6D88\u606F\u4E2D\u7684\u53D8\u91CF\uFF08\u5982 ", '{currentRelease}', "\u3001", '{nextPhase}', " \u7B49\uFF09"))), !isReminderMode && !isTimelineTrigger && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: {
      ...dialogStyles.label,
      display: 'flex',
      alignItems: 'center',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/react.createElement("input", {
    type: "checkbox",
    checked: isRepeating,
    onChange: e => {
      setIsRepeating(e.target.checked);
      if (e.target.checked) {
        handleChange('Repeat_Every', 1);
        handleChange('Repeat_Unit', 'Week');
      }
    },
    style: {
      marginRight: '8px'
    }
  }), "\u662F\u5426\u91CD\u590D\u63A8\u9001")), !isTimelineTrigger && isRepeating && /*#__PURE__*/react.createElement("div", {
    style: {
      ...dialogStyles.section,
      backgroundColor: '#f8f9fa',
      padding: '16px',
      borderRadius: '8px'
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formRow
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u6BCF\u9694 *"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "number",
    min: "1",
    value: formData.Repeat_Every || 1,
    onChange: e => handleChange('Repeat_Every', parseInt(e.target.value))
  })), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u91CD\u590D\u5355\u4F4D *"), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.buttonGroup
  }, ['Day', 'Week', 'Month', 'Year'].map(unit => /*#__PURE__*/react.createElement("button", {
    key: unit,
    type: "button",
    style: getButtonStyle(formData.Repeat_Unit === unit),
    onClick: () => handleChange('Repeat_Unit', unit)
  }, unit === 'Day' ? '天' : unit === 'Week' ? '周' : unit === 'Month' ? '月' : '年'))))), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formRow
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u7ED3\u675F\u65E5\u671F\uFF08\u53EF\u9009\uFF09"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "date",
    value: formData.End_Date || '',
    onChange: e => handleChange('End_Date', e.target.value)
  })), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u91CD\u590D\u6B21\u6570\uFF08\u53EF\u9009\uFF09"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "number",
    min: "1",
    value: formData.Repeat_Count || '',
    onChange: e => handleChange('Repeat_Count', e.target.value ? parseInt(e.target.value) : undefined),
    placeholder: "\u7559\u7A7A\u8868\u793A\u65E0\u9650"
  })))), isReminderMode && /*#__PURE__*/react.createElement("div", {
    style: {
      marginBottom: '16px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => setShowAdvancedOptions(!showAdvancedOptions),
    style: {
      padding: '10px 20px',
      backgroundColor: 'transparent',
      color: '#007bff',
      border: '1px dashed #007bff',
      borderRadius: '6px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '500',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '8px',
      margin: '0 auto',
      transition: 'all 0.2s ease-in-out',
      width: '100%'
    },
    onMouseEnter: e => {
      e.currentTarget.style.backgroundColor = '#f0f7ff';
      e.currentTarget.style.borderColor = '#0056b3';
      e.currentTarget.style.color = '#0056b3';
    },
    onMouseLeave: e => {
      e.currentTarget.style.backgroundColor = 'transparent';
      e.currentTarget.style.borderColor = '#007bff';
      e.currentTarget.style.color = '#007bff';
    }
  }, /*#__PURE__*/react.createElement("span", {
    style: {
      display: 'inline-block',
      transition: 'transform 0.3s ease-in-out',
      transform: showAdvancedOptions ? 'rotate(180deg)' : 'rotate(0deg)'
    }
  }, "\u25BC"), showAdvancedOptions ? '收起高级选项' : '展开更多选项')), isReminderMode && !botConfigured && /*#__PURE__*/react.createElement("div", {
    style: {
      padding: '16px',
      backgroundColor: '#fff3cd',
      borderRadius: '8px',
      border: '1px solid #ffc107',
      marginBottom: '16px'
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: {
      fontWeight: 'bold',
      marginBottom: '8px',
      color: '#856404',
      fontSize: '15px'
    }
  }, "\u26A0\uFE0F Bot \u63A8\u9001\u529F\u80FD\u672A\u914D\u7F6E"), /*#__PURE__*/react.createElement("p", {
    style: {
      margin: '0 0 12px 0',
      color: '#856404',
      fontSize: '14px',
      lineHeight: '1.6'
    }
  }, "\u4E2A\u4EBA\u63D0\u9192\u529F\u80FD\u9700\u8981\u901A\u8FC7 Bot \u53D1\u9001\u6D88\u606F\u3002\u8BF7\u5148\u914D\u7F6E Bot \u63A8\u9001\u529F\u80FD\u624D\u80FD\u4F7F\u7528\u3002"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => {
      onConfigureBot();
    },
    style: {
      padding: '10px 20px',
      backgroundColor: '#ffc107',
      color: '#000',
      border: 'none',
      borderRadius: '6px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: 'bold'
    }
  }, "\uD83D\uDD27 \u7ACB\u5373\u914D\u7F6E Bot")), !isReminderMode && /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u63A8\u9001\u65B9\u5F0F *"), formData.Push_Method === 'JiraAutomation' ? /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.buttonGroup
  }, /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: {
      ...getButtonStyle(true),
      cursor: 'default'
    },
    disabled: true
  }, "\uD83D\uDD27 JIRA \u81EA\u52A8\u5316")) : /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.buttonGroup
  }, /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: getButtonStyle(formData.Push_Method === 'AsMe'),
    onClick: () => handleChange('Push_Method', 'AsMe')
  }, "\uD83D\uDC64 AsMe\uFF08\u4EE5\u6211\u7684\u8EAB\u4EFD\uFF09"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: getButtonStyle(formData.Push_Method === 'Bot'),
    onClick: () => handleChange('Push_Method', 'Bot')
  }, "\uD83E\uDD16 Bot\uFF08\u673A\u5668\u4EBA\uFF09"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: getButtonStyle(formData.Push_Method === 'AI'),
    onClick: () => handleChange('Push_Method', 'AI')
  }, "\uD83E\uDD16 AI Report")), formData.Push_Method === 'Bot' && !botConfigured && /*#__PURE__*/react.createElement("div", {
    style: {
      marginTop: '12px',
      padding: '12px',
      backgroundColor: '#fff3cd',
      borderRadius: '6px',
      border: '1px solid #ffc107'
    }
  }, /*#__PURE__*/react.createElement("p", {
    style: {
      margin: '0 0 10px 0',
      color: '#856404',
      fontSize: '14px'
    }
  }, "\u26A0\uFE0F \u60A8\u8FD8\u672A\u914D\u7F6E Bot \u63A8\u9001\u529F\u80FD\uFF0C\u9700\u8981\u5148\u914D\u7F6E\u624D\u80FD\u4F7F\u7528\u3002"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => {
      onConfigureBot();
    },
    style: {
      padding: '8px 16px',
      backgroundColor: '#ffc107',
      color: '#000',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: 'bold'
    }
  }, "\uD83D\uDD27 \u914D\u7F6E Bot \u540E\u542F\u7528")), formData.Push_Method === 'AI' && !botConfigured && /*#__PURE__*/react.createElement("div", {
    style: {
      marginTop: '12px',
      padding: '12px',
      backgroundColor: '#fff3cd',
      borderRadius: '6px',
      border: '1px solid #ffc107'
    }
  }, /*#__PURE__*/react.createElement("p", {
    style: {
      margin: '0 0 10px 0',
      color: '#856404',
      fontSize: '14px'
    }
  }, "\u26A0\uFE0F AI Report \u529F\u80FD\u9700\u8981\u914D\u7F6E Bot \u63A8\u9001\u529F\u80FD\u624D\u80FD\u4F7F\u7528\u3002"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => {
      onConfigureBot();
    },
    style: {
      padding: '8px 16px',
      backgroundColor: '#ffc107',
      color: '#000',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: 'bold'
    }
  }, "\uD83D\uDD27 \u914D\u7F6E Bot \u540E\u542F\u7528"))), formData.Push_Method === 'AI' && /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u62A5\u544A\u6A21\u677F *"), /*#__PURE__*/react.createElement(StateManagedSelect$1, {
    options: [{
      value: 'ai-report',
      label: '🤖 AI Report'
    }, {
      value: 'pep-report',
      label: '📊 PEP Report'
    }, {
      value: 'custom',
      label: '⚙️ 自定义'
    }],
    value: {
      value: aiReportTemplate,
      label: aiReportTemplate === 'ai-report' ? '🤖 AI Report' : aiReportTemplate === 'pep-report' ? '📊 PEP Report' : '⚙️ 自定义'
    },
    onChange: option => option && handleTemplateChange(option.value),
    styles: singleSelectStyles,
    isSearchable: false
  })), aiReportTemplate === 'custom' && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "API Endpoint *"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "text",
    value: formData.AI_Endpoint || '',
    onChange: e => handleChange('AI_Endpoint', e.target.value),
    placeholder: "POST https://example.com/api \u6216 GET https://example.com/api \u6216 https://example.com/api"
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u683C\u5F0F\uFF1APOST/GET URL \u6216\u4EC5 URL\uFF08\u9ED8\u8BA4\u4E3A GET\uFF09")), aiReportTemplate === 'custom' && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "Headers"), /*#__PURE__*/react.createElement("div", {
    style: {
      border: '1px solid #ddd',
      borderRadius: '4px',
      padding: '12px',
      backgroundColor: '#f9f9f9'
    }
  }, aiHeaders.map((header, index) => /*#__PURE__*/react.createElement("div", {
    key: index,
    style: {
      display: 'flex',
      gap: '8px',
      marginBottom: '12px',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: {
      flex: '0 0 200px'
    }
  }, /*#__PURE__*/react.createElement(StateManagedSelect$1, {
    options: AVAILABLE_AI_HEADERS.map(h => ({
      value: h.value,
      label: h.label
    })),
    value: header.name ? {
      value: header.name,
      label: AVAILABLE_AI_HEADERS.find(h => h.value === header.name)?.label || header.name
    } : null,
    onChange: option => updateAIHeaderName(index, option?.value || ''),
    placeholder: "\u9009\u62E9 Header",
    styles: singleSelectStyles,
    isClearable: true
  })), /*#__PURE__*/react.createElement("input", {
    type: "text",
    value: header.value,
    onChange: e => updateAIHeaderValue(index, e.target.value),
    placeholder: header.name ? AVAILABLE_AI_HEADERS.find(h => h.value === header.name)?.placeholder || 'Header 值' : 'Header 值',
    style: {
      ...dialogStyles.input,
      flex: 1,
      marginBottom: 0
    }
  }), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => removeAIHeader(index),
    style: {
      padding: '8px 12px',
      backgroundColor: '#dc3545',
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '14px',
      whiteSpace: 'nowrap'
    },
    title: "\u5220\u9664\u6B64 Header"
  }, "\uD83D\uDDD1\uFE0F"))), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: addAIHeader,
    style: {
      padding: '8px 16px',
      backgroundColor: '#28a745',
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '14px',
      width: '100%',
      marginTop: aiHeaders.length > 0 ? '4px' : '0'
    }
  }, "\u2795 \u6DFB\u52A0 Header")), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\uD83D\uDCA1 \u63D0\u793A\uFF1A\u53EA\u652F\u6301\u9884\u5B9A\u4E49\u7684 7 \u4E2A header \u540D\u79F0\uFF0C\u9009\u62E9\u540E\u586B\u5199\u5BF9\u5E94\u7684\u503C\u5373\u53EF")), aiReportTemplate === 'ai-report' ?
  /*#__PURE__*/
  /* AI Report 可视化配置 */
  react.createElement("div", {
    style: {
      ...dialogStyles.section,
      backgroundColor: '#f8f9fa',
      padding: '16px',
      borderRadius: '8px'
    }
  }, /*#__PURE__*/react.createElement("h3", {
    style: {
      margin: '0 0 16px 0',
      fontSize: '16px',
      fontWeight: 'bold',
      color: '#333'
    }
  }, "\uD83D\uDCCA AI Report \u914D\u7F6E"), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "JQL \u67E5\u8BE2 *"), /*#__PURE__*/react.createElement("textarea", {
    ref: jqlTextareaRef,
    style: dialogStyles.textarea,
    value: aiReportJql,
    onChange: e => setAiReportJql(e.target.value),
    placeholder: "\u4F8B\u5982\uFF1Aproject = MTR AND status = \"In Progress\"",
    rows: 3
  }), /*#__PURE__*/react.createElement("div", {
    style: {
      marginTop: '8px',
      padding: '8px 10px',
      backgroundColor: '#f8f9fa',
      borderRadius: '4px',
      border: '1px solid #e0e0e0',
      fontSize: '12px',
      color: '#666'
    }
  }, /*#__PURE__*/react.createElement("span", {
    style: {
      marginRight: '8px'
    }
  }, "\uD83D\uDCA1 \u63D2\u5165\u53D8\u91CF\uFF1A"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => insertVariableToJql('{currentRelease}'),
    style: {
      padding: '2px 8px',
      backgroundColor: '#e0e0e0',
      color: '#555',
      border: 'none',
      borderRadius: '12px',
      cursor: 'pointer',
      fontSize: '12px',
      fontWeight: '500',
      transition: 'background-color 0.2s'
    },
    onMouseEnter: e => {
      e.currentTarget.style.backgroundColor = '#d0d0d0';
    },
    onMouseLeave: e => {
      e.currentTarget.style.backgroundColor = '#e0e0e0';
    },
    title: "\u63D2\u5165 {currentRelease}"
  }, "\u5F53\u524D Release"))), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u7248\u5757\u81EA\u5B9A\u4E49"), /*#__PURE__*/react.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '8px'
    }
  }, /*#__PURE__*/react.createElement("label", {
    style: {
      display: 'flex',
      alignItems: 'center',
      cursor: 'pointer',
      fontSize: '14px'
    }
  }, /*#__PURE__*/react.createElement("input", {
    type: "checkbox",
    checked: aiReportOutputs.tickets,
    onChange: e => setAiReportOutputs({
      ...aiReportOutputs,
      tickets: e.target.checked
    }),
    style: {
      marginRight: '8px'
    }
  }), "\u5217\u51FAJQL\u67E5\u8BE2\u7ED3\u679C"), aiReportOutputs.tickets && /*#__PURE__*/react.createElement("div", {
    style: {
      marginLeft: '24px',
      padding: '12px',
      backgroundColor: '#f8f9fa',
      borderRadius: '6px',
      border: '1px solid #e0e0e0'
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: {
      fontSize: '13px',
      color: '#666',
      marginBottom: '8px'
    }
  }, "\u9009\u62E9\u8981\u5C55\u793A\u7684 ticket \u5B57\u6BB5\uFF1A"), /*#__PURE__*/react.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '8px'
    }
  }, [{
    key: 'summary',
    label: 'Summary'
  }, {
    key: 'status',
    label: 'Status'
  }, {
    key: 'assignee',
    label: 'Assignee'
  }, {
    key: 'reporter',
    label: 'Reporter'
  }, {
    key: 'priority',
    label: 'Priority'
  }, {
    key: 'duedate',
    label: 'Due Date'
  }, {
    key: 'created',
    label: 'Created'
  }, {
    key: 'updated',
    label: 'Updated'
  }, {
    key: 'labels',
    label: 'Labels'
  }, {
    key: 'components',
    label: 'Components'
  }, {
    key: 'fixVersions',
    label: 'Fix Versions'
  }, {
    key: 'sprint',
    label: 'Sprint'
  }, {
    key: 'team',
    label: 'Team'
  }].map(field => /*#__PURE__*/react.createElement("label", {
    key: field.key,
    style: {
      display: 'flex',
      alignItems: 'center',
      cursor: 'pointer',
      fontSize: '13px',
      padding: '4px 8px',
      backgroundColor: ticketIncludes.includes(field.key) ? '#e3f2fd' : '#fff',
      border: `1px solid ${ticketIncludes.includes(field.key) ? '#1976d2' : '#ddd'}`,
      borderRadius: '4px'
    }
  }, /*#__PURE__*/react.createElement("input", {
    type: "checkbox",
    checked: ticketIncludes.includes(field.key),
    onChange: e => {
      if (e.target.checked) {
        setTicketIncludes([...ticketIncludes, field.key]);
      } else {
        setTicketIncludes(ticketIncludes.filter(f => f !== field.key));
      }
    },
    style: {
      marginRight: '4px'
    }
  }), field.label)))), /*#__PURE__*/react.createElement("label", {
    style: {
      display: 'flex',
      alignItems: 'center',
      cursor: 'pointer',
      fontSize: '14px'
    }
  }, /*#__PURE__*/react.createElement("input", {
    type: "checkbox",
    checked: aiReportOutputs.noduedate,
    onChange: e => setAiReportOutputs({
      ...aiReportOutputs,
      noduedate: e.target.checked
    }),
    style: {
      marginRight: '8px'
    }
  }), "\u5C55\u793A\u6CA1\u586B Duedate \u7684 tickets"), /*#__PURE__*/react.createElement("label", {
    style: {
      display: 'flex',
      alignItems: 'center',
      cursor: 'pointer',
      fontSize: '14px'
    }
  }, /*#__PURE__*/react.createElement("input", {
    type: "checkbox",
    checked: aiReportOutputs.overdue,
    onChange: e => setAiReportOutputs({
      ...aiReportOutputs,
      overdue: e.target.checked
    }),
    style: {
      marginRight: '8px'
    }
  }), "\u5C55\u793A Duedate \u8D85\u65F6\u7684 tickets"), /*#__PURE__*/react.createElement("label", {
    style: {
      display: 'flex',
      alignItems: 'center',
      cursor: 'pointer',
      fontSize: '14px'
    }
  }, /*#__PURE__*/react.createElement("input", {
    type: "checkbox",
    checked: aiReportOutputs.toTest,
    onChange: e => setAiReportOutputs({
      ...aiReportOutputs,
      toTest: e.target.checked
    }),
    style: {
      marginRight: '8px'
    }
  }), "\u5C55\u793A\u5F85 QA \u9A8C\u8BC1\u7684 tickets"), customOutputs.map((output, index) => /*#__PURE__*/react.createElement("div", {
    key: index,
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '8px 12px',
      backgroundColor: '#e8f5e9',
      borderRadius: '6px',
      border: '1px solid #a5d6a7'
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: {
      flex: 1,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: {
      fontWeight: 'bold',
      color: '#2e7d32',
      fontSize: '14px'
    }
  }, output.name ? `📋 ${output.name}` : '📋 自定义版块'), /*#__PURE__*/react.createElement("div", {
    style: {
      color: '#666',
      fontSize: '12px',
      marginTop: '4px',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, output.prompt)), /*#__PURE__*/react.createElement("div", {
    style: {
      display: 'flex',
      gap: '8px'
    }
  }, /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => {
      setEditingCustomOutputIndex(index);
      setCustomOutputName(output.name);
      setCustomOutputPrompt(output.prompt);
      setShowCustomOutputDialog(true);
    },
    style: {
      padding: '4px 10px',
      backgroundColor: '#fff',
      color: '#1976d2',
      border: '1px solid #1976d2',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '12px'
    }
  }, "\u7F16\u8F91"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => {
      setCustomOutputs(customOutputs.filter((_, i) => i !== index));
    },
    style: {
      padding: '4px 10px',
      backgroundColor: '#fff',
      color: '#dc3545',
      border: '1px solid #dc3545',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '12px'
    }
  }, "\u5220\u9664")))), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => {
      setEditingCustomOutputIndex(null);
      setCustomOutputName('');
      setCustomOutputPrompt('');
      setShowCustomOutputDialog(true);
    },
    style: {
      padding: '8px 16px',
      backgroundColor: '#fff',
      color: '#28a745',
      border: '1px dashed #28a745',
      borderRadius: '6px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '500',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '6px',
      marginTop: '4px'
    }
  }, "\u2795 \u6DFB\u52A0\u81EA\u5B9A\u4E49\u7248\u5757"))), showCustomOutputDialog && /*#__PURE__*/react.createElement("div", {
    style: {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: 2000
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: {
      backgroundColor: '#fff',
      borderRadius: '12px',
      padding: '20px',
      maxWidth: '500px',
      width: '90%',
      boxShadow: '0 10px 40px rgba(0, 0, 0, 0.3)'
    }
  }, /*#__PURE__*/react.createElement("h3", {
    style: {
      margin: '0 0 16px 0',
      fontSize: '18px',
      color: '#333'
    }
  }, editingCustomOutputIndex !== null ? '📝 编辑自定义版块' : '➕ 添加自定义版块'), /*#__PURE__*/react.createElement("div", {
    style: {
      marginBottom: '16px'
    }
  }, /*#__PURE__*/react.createElement("label", {
    style: {
      display: 'block',
      marginBottom: '6px',
      fontSize: '14px',
      fontWeight: 'bold',
      color: '#333'
    }
  }, "\u7248\u5757\u540D\u79F0\uFF08\u53EF\u9009\uFF09"), /*#__PURE__*/react.createElement("input", {
    type: "text",
    value: customOutputName,
    onChange: e => setCustomOutputName(e.target.value),
    placeholder: "\u4F8B\u5982\uFF1A\u98CE\u9669\u5206\u6790\uFF08\u53EF\u7559\u7A7A\uFF09",
    style: {
      width: '100%',
      padding: '8px 12px',
      border: '1px solid #ddd',
      borderRadius: '4px',
      fontSize: '14px',
      boxSizing: 'border-box'
    }
  }), /*#__PURE__*/react.createElement("small", {
    style: {
      display: 'block',
      marginTop: '4px',
      fontSize: '12px',
      color: '#999'
    }
  }, "\u7559\u7A7A\u65F6\u4E0D\u4F1A\u663E\u793A\u6807\u9898\uFF0C\u76F4\u63A5\u8F93\u51FA\u5206\u6790\u7ED3\u679C")), /*#__PURE__*/react.createElement("div", {
    style: {
      marginBottom: '16px'
    }
  }, /*#__PURE__*/react.createElement("label", {
    style: {
      display: 'block',
      marginBottom: '6px',
      fontSize: '14px',
      fontWeight: 'bold',
      color: '#333'
    }
  }, "Prompt *"), /*#__PURE__*/react.createElement("textarea", {
    value: customOutputPrompt,
    onChange: e => setCustomOutputPrompt(e.target.value),
    placeholder: "\u4F8B\u5982\uFF1A\u5206\u6790\u8FD9\u4E9B tickets \u4E2D\u53EF\u80FD\u5B58\u5728\u7684\u98CE\u9669\u70B9\uFF0C\u5E76\u7ED9\u51FA\u5EFA\u8BAE",
    rows: 4,
    style: {
      width: '100%',
      padding: '8px 12px',
      border: '1px solid #ddd',
      borderRadius: '4px',
      fontSize: '14px',
      resize: 'vertical',
      boxSizing: 'border-box'
    }
  }), /*#__PURE__*/react.createElement("small", {
    style: {
      display: 'block',
      marginTop: '4px',
      fontSize: '12px',
      color: '#999'
    }
  }, "\u63CF\u8FF0 AI \u5E94\u8BE5\u5982\u4F55\u5904\u7406\u8FD9\u4E2A\u7248\u5757\u7684\u5185\u5BB9")), /*#__PURE__*/react.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: '10px'
    }
  }, /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => {
      setShowCustomOutputDialog(false);
      setEditingCustomOutputIndex(null);
      setCustomOutputName('');
      setCustomOutputPrompt('');
    },
    style: {
      padding: '10px 20px',
      backgroundColor: '#6c757d',
      color: '#fff',
      border: 'none',
      borderRadius: '6px',
      cursor: 'pointer',
      fontSize: '14px'
    }
  }, "\u53D6\u6D88"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => {
      if (!customOutputPrompt.trim()) {
        alert('请填写 Prompt');
        return;
      }
      const newOutput = {
        name: customOutputName.trim(),
        prompt: customOutputPrompt.trim()
      };
      if (editingCustomOutputIndex !== null) {
        // 编辑模式
        const newOutputs = [...customOutputs];
        newOutputs[editingCustomOutputIndex] = newOutput;
        setCustomOutputs(newOutputs);
      } else {
        // 添加模式
        setCustomOutputs([...customOutputs, newOutput]);
      }
      setShowCustomOutputDialog(false);
      setEditingCustomOutputIndex(null);
      setCustomOutputName('');
      setCustomOutputPrompt('');
    },
    style: {
      padding: '10px 20px',
      backgroundColor: '#28a745',
      color: '#fff',
      border: 'none',
      borderRadius: '6px',
      cursor: 'pointer',
      fontSize: '14px'
    }
  }, editingCustomOutputIndex !== null ? '保存修改' : '添加版块')))), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "Team ID"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "text",
    value: aiReportTeamId,
    onChange: e => setAiReportTeamId(e.target.value),
    placeholder: "\u4F8B\u5982\uFF1A148192141318"
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u53EF\u9009\uFF0C\u586B\u5165\u540E\u4F1A\u5C06\u62A5\u544A\u53D1\u9001\u5230\u6307\u5B9A\u7FA4\u7EC4")), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "@ \u6210\u5458"), /*#__PURE__*/react.createElement(TagsInput, {
    tags: aiReportMentionList,
    onChange: setAiReportMentionList,
    placeholder: "\u8F93\u5165\u4EBA\u540D\u540E\u6309 Enter \u6DFB\u52A0\uFF0C\u4F8B\u5982\uFF1AEsone Qiu \u6216 esone.qiu"
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u652F\u6301\u683C\u5F0F\uFF1A", /*#__PURE__*/react.createElement("strong", null, "Esone Qiu"), " \u6216 ", /*#__PURE__*/react.createElement("strong", null, "esone.qiu"), "\uFF0C\u6309 Enter \u6DFB\u52A0")), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u5C3E\u90E8\u6DFB\u52A0\u6587\u672C"), /*#__PURE__*/react.createElement("textarea", {
    style: dialogStyles.textarea,
    value: aiReportExtraText,
    onChange: e => setAiReportExtraText(e.target.value),
    placeholder: "\u53EF\u9009\uFF0C\u5728\u62A5\u544A\u672B\u5C3E\u6DFB\u52A0\u81EA\u5B9A\u4E49\u6587\u672C",
    rows: 2
  }))) :
  /*#__PURE__*/
  /* PEP Report 和自定义模板：显示 JSON 输入框 */
  react.createElement(react.Fragment, null, aiReportTemplate === 'pep-report' && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u7FA4\u7EC4 ID"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "text",
    value: pepReportTeamId,
    onChange: e => setPepReportTeamId(e.target.value),
    placeholder: "\u4F8B\u5982\uFF1A148192141318"
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u53EF\u9009\uFF0C\u586B\u5165\u540E\u4F1A\u5C06\u62A5\u544A\u53D1\u9001\u5230\u6307\u5B9A\u7FA4\u7EC4")), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "Body *"), /*#__PURE__*/react.createElement("textarea", {
    ref: bodyTextareaRef,
    style: dialogStyles.textarea,
    value: formData.AI_Body || '',
    onChange: e => handleChange('AI_Body', e.target.value),
    placeholder: "{\"key\": \"value\"}",
    rows: 8
  }), /*#__PURE__*/react.createElement(VariableSelector, {
    onInsert: insertVariableToBody
  })))), formData.Push_Method !== 'AI' && formData.Push_Method !== 'JiraAutomation' && /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u63A8\u9001\u76EE\u6807 *"), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.buttonGroup
  }, /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: getButtonStyle(formData.Target_Type === 'private'),
    onClick: () => handleChange('Target_Type', 'private')
  }, "\uD83D\uDCAC \u79C1\u53D1\u6D88\u606F"), /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: getButtonStyle(formData.Target_Type === 'group'),
    onClick: () => handleChange('Target_Type', 'group')
  }, "\uD83D\uDC65 \u7FA4\u7EC4\u6D88\u606F"))), formData.Target_Type === 'private' && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u63A5\u6536\u4EBA *", formData.Push_Method === 'Bot' && /*#__PURE__*/react.createElement("span", {
    style: {
      color: '#dc3545',
      marginLeft: '8px'
    }
  }, "\uFF08Bot \u6A21\u5F0F\u53EA\u80FD\u586B\u4E00\u4E2A\u4EBA\u540D\uFF09")), /*#__PURE__*/react.createElement(TagsInput, {
    tags: userTags,
    onChange: handleUserTagsChange,
    placeholder: "\u8F93\u5165\u4EBA\u540D\u540E\u6309 Enter \u6DFB\u52A0\uFF0C\u4F8B\u5982\uFF1AEsone Qiu \u6216 esone.qiu",
    maxTags: formData.Push_Method === 'Bot' ? 1 : undefined
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u652F\u6301\u683C\u5F0F\uFF1A", /*#__PURE__*/react.createElement("strong", null, "Esone Qiu"), " \u6216 ", /*#__PURE__*/react.createElement("strong", null, "esone.qiu"), "\uFF0C\u6309 Enter \u6DFB\u52A0")), formData.Target_Type === 'group' && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u7FA4\u7EC4 ID *"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "text",
    value: formData.Glip_Team_ID || '',
    onChange: e => handleChange('Glip_Team_ID', e.target.value),
    placeholder: "\u4F8B\u5982\uFF1A148192141318"
  })))), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "\u7C7B\u522B\uFF08\u53EF\u9009\uFF09"), /*#__PURE__*/react.createElement(CreatableSelect$1, {
    isMulti: true,
    options: availableCategories,
    value: categoryTags,
    onChange: newValue => setCategoryTags([...newValue]),
    placeholder: "\u9009\u62E9\u6216\u8F93\u5165\u7C7B\u522B\uFF0C\u6309 Enter \u6DFB\u52A0...",
    styles: selectStyles,
    noOptionsMessage: () => '输入新类别并按 Enter 添加',
    formatCreateLabel: inputValue => `创建 "${inputValue}"`,
    isClearable: true
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u53EF\u9009\u62E9\u5DF2\u6709\u7C7B\u522B\uFF0C\u6216\u8F93\u5165\u65B0\u7C7B\u522B\u6309 Enter \u521B\u5EFA")), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.actions
  }, /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: dialogStyles.cancelButton,
    onClick: onCancel,
    disabled: isSubmitting
  }, "\u53D6\u6D88"), /*#__PURE__*/react.createElement("button", {
    type: "submit",
    style: dialogStyles.submitButton,
    disabled: isSubmitting
  }, isSubmitting ? isEditMode ? '保存中...' : '创建中...' : isEditMode ? '✅ 保存修改' : '✅ 创建消息')))));
};

// 按钮选择器样式辅助函数
const getButtonStyle = isSelected => ({
  flex: 1,
  padding: '10px 16px',
  backgroundColor: isSelected ? '#007bff' : '#fff',
  color: isSelected ? '#fff' : '#333',
  border: `2px solid ${isSelected ? '#007bff' : '#ddd'}`,
  borderRadius: '6px',
  cursor: 'pointer',
  fontSize: '14px',
  fontWeight: isSelected ? 'bold' : 'normal',
  transition: 'all 0.2s'
});
const getTypeStyle = pushMethod => {
  const baseStyle = {
    padding: '4px 8px',
    borderRadius: '4px',
    fontSize: '12px',
    fontWeight: 'bold'
  };
  switch (pushMethod) {
    case 'AI':
      return {
        ...baseStyle,
        backgroundColor: '#e3f2fd',
        color: '#1976d2'
      };
    // 蓝色 - AI Report
    case 'AsMe':
      return {
        ...baseStyle,
        backgroundColor: '#f3e5f5',
        color: '#7b1fa2'
      };
    // 紫色 - 假装我发的
    case 'Bot':
      return {
        ...baseStyle,
        backgroundColor: '#fff3e0',
        color: '#f57c00'
      };
    // 橙色 - Bot 定时
    case 'JiraAutomation':
      return {
        ...baseStyle,
        backgroundColor: '#e8f5e9',
        color: '#388e3c'
      };
    // 绿色 - JIRA自动化
    default:
      return {
        ...baseStyle,
        backgroundColor: '#f5f5f5',
        color: '#666'
      };
  }
};
const getStatusStyle = status => {
  const baseStyle = {
    padding: '4px 8px',
    borderRadius: '4px',
    fontSize: '12px',
    fontWeight: 'bold'
  };
  switch (status) {
    case 'Active':
      return {
        ...baseStyle,
        backgroundColor: '#d4edda',
        color: '#155724'
      };
    case 'Paused':
      return {
        ...baseStyle,
        backgroundColor: '#fff3cd',
        color: '#856404'
      };
    case 'Completed':
      return {
        ...baseStyle,
        backgroundColor: '#d1ecf1',
        color: '#0c5460'
      };
    default:
      return {
        ...baseStyle,
        backgroundColor: '#f5f5f5',
        color: '#666'
      };
  }
};
const ScheduledMessagesManager_styles = {
  container: {
    minHeight: '100vh',
    backgroundColor: '#f8f9fa'
  },
  loadingContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '100vh'
  },
  spinner: {
    width: '50px',
    height: '50px',
    border: '4px solid #f3f3f3',
    borderTop: '4px solid #007bff',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite'
  },
  topicText: {
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    maxWidth: '300px',
    display: 'inline-block'
  },
  categoryTag: {
    display: 'inline-block',
    padding: '2px 8px',
    backgroundColor: '#e7f3ff',
    color: '#007bff',
    borderRadius: '12px',
    fontSize: '12px',
    fontWeight: 500
  },
  header: {
    backgroundColor: '#fff',
    padding: '20px',
    borderBottom: '1px solid #e0e0e0',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  title: {
    margin: 0,
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#333'
  },
  headerActions: {
    display: 'flex',
    gap: '10px'
  },
  reminderButton: {
    padding: '8px 16px',
    backgroundColor: '#ffc107',
    color: '#000',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold'
  },
  addButton: {
    padding: '8px 16px',
    backgroundColor: '#28a745',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px'
  },
  syncButton: {
    padding: '8px 16px',
    backgroundColor: '#007bff',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px'
  },
  updateButton: {
    padding: '8px 16px',
    backgroundColor: '#ff5722',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold',
    animation: 'pulse 2s infinite'
  },
  configButton: {
    padding: '8px 16px',
    backgroundColor: '#6c757d',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px'
  },
  editButton: {
    padding: '4px 8px',
    backgroundColor: 'transparent',
    color: '#007bff',
    border: '1px solid #007bff',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
    transition: 'all 0.2s'
  },
  jiraLinkButton: {
    padding: '4px 8px',
    backgroundColor: 'transparent',
    color: '#0052cc',
    border: '1px solid #0052cc',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
    transition: 'all 0.2s'
  },
  deleteButton: {
    padding: '4px 8px',
    backgroundColor: 'transparent',
    color: '#dc3545',
    border: '1px solid #dc3545',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
    transition: 'all 0.2s'
  },
  warningBanner: {
    backgroundColor: '#fff3cd',
    borderLeft: '4px solid #ffc107',
    padding: '16px 20px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottom: '1px solid #ffc107',
    animation: 'slideDown 0.3s ease-out'
  },
  warningContent: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: '12px',
    flex: 1
  },
  warningIcon: {
    fontSize: '24px',
    lineHeight: 1
  },
  warningText: {
    flex: 1
  },
  warningDescription: {
    margin: '4px 0 0 0',
    fontSize: '13px',
    color: '#856404'
  },
  warningButton: {
    padding: '8px 16px',
    backgroundColor: '#ffc107',
    color: '#000',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold',
    whiteSpace: 'nowrap',
    marginLeft: '16px'
  },
  statusBar: {
    backgroundColor: '#fff',
    padding: '15px 20px',
    borderBottom: '1px solid #e0e0e0',
    display: 'flex',
    gap: '20px'
  },
  statusItem: {
    fontSize: '14px',
    color: '#666'
  },
  content: {
    padding: '20px'
  },
  emptyState: {
    textAlign: 'center',
    padding: '60px 20px',
    backgroundColor: '#fff',
    borderRadius: '8px'
  },
  emptyText: {
    fontSize: '18px',
    color: '#666',
    marginBottom: '10px'
  },
  emptyHint: {
    fontSize: '14px',
    color: '#999'
  },
  messageList: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    overflow: 'hidden'
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse'
  },
  th: {
    padding: '12px',
    textAlign: 'left',
    backgroundColor: '#f8f9fa',
    borderBottom: '2px solid #e0e0e0',
    fontWeight: 'bold',
    fontSize: '14px',
    color: '#333'
  },
  tr: {
    borderBottom: '1px solid #e0e0e0'
  },
  td: {
    padding: '12px',
    fontSize: '14px',
    color: '#666'
  },
  footer: {
    padding: '20px',
    textAlign: 'center'
  },
  footerText: {
    fontSize: '12px',
    color: '#999'
  },
  tooltip: {
    position: 'fixed',
    backgroundColor: '#333',
    color: '#fff',
    padding: '8px 12px',
    borderRadius: '6px',
    fontSize: '13px',
    maxWidth: '400px',
    zIndex: 10000,
    pointerEvents: 'none',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)'
  },
  tooltipHeader: {
    fontWeight: 'bold',
    marginBottom: '4px',
    fontSize: '12px',
    color: '#ffc107'
  },
  tooltipContent: {
    whiteSpace: 'pre-wrap',
    wordBreak: 'break-word'
  }
};

// 对话框样式
const dialogStyles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000
  },
  dialog: {
    backgroundColor: '#fff',
    borderRadius: '12px',
    padding: '0',
    maxWidth: '600px',
    width: '90%',
    maxHeight: '90vh',
    overflow: 'auto',
    boxShadow: '0 10px 40px rgba(0, 0, 0, 0.3)'
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '20px',
    borderBottom: '1px solid #e0e0e0'
  },
  title: {
    margin: 0,
    fontSize: '20px',
    fontWeight: 'bold',
    color: '#333'
  },
  closeButton: {
    background: 'transparent',
    border: 'none',
    fontSize: '24px',
    cursor: 'pointer',
    color: '#666',
    padding: '0',
    width: '30px',
    height: '30px'
  },
  form: {
    padding: '20px'
  },
  formGroup: {
    marginBottom: '16px',
    flex: '1'
  },
  formRow: {
    display: 'flex',
    gap: '16px'
  },
  section: {
    marginBottom: '16px'
  },
  buttonGroup: {
    display: 'flex',
    gap: '8px',
    flexWrap: 'wrap'
  },
  label: {
    display: 'block',
    marginBottom: '6px',
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333'
  },
  input: {
    width: '100%',
    padding: '8px 12px',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '14px',
    boxSizing: 'border-box'
  },
  textarea: {
    width: '100%',
    padding: '8px 12px',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '14px',
    resize: 'vertical',
    boxSizing: 'border-box'
  },
  select: {
    width: '100%',
    padding: '8px 12px',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '14px',
    boxSizing: 'border-box'
  },
  hint: {
    display: 'block',
    marginTop: '4px',
    fontSize: '12px',
    color: '#999'
  },
  actions: {
    display: 'flex',
    justifyContent: 'flex-end',
    gap: '10px',
    marginTop: '24px',
    paddingTop: '20px',
    borderTop: '1px solid #e0e0e0'
  },
  cancelButton: {
    padding: '10px 20px',
    backgroundColor: '#6c757d',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px'
  },
  submitButton: {
    padding: '10px 20px',
    backgroundColor: '#28a745',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px'
  }
};

// 添加 CSS 动画
const ScheduledMessagesManager_styleSheet = document.createElement('style');
ScheduledMessagesManager_styleSheet.textContent = `
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
  @keyframes slideDown {
    from {
      opacity: 0;
      transform: translateY(-10px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  button:hover {
    opacity: 0.9;
  }
  button:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;
document.head.appendChild(ScheduledMessagesManager_styleSheet);

// Bot 配置对话框组件
const BotConfigDialog = _ref6 => {
  let {
    config,
    onClose,
    onSuccess
  } = _ref6;
  const [isSubmitting, setIsSubmitting] = (0,react.useState)(false);
  const [error, setError] = (0,react.useState)('');
  const [step, setStep] = (0,react.useState)('input');
  const [jiraUrl, setJiraUrl] = (0,react.useState)('https://jira.ringcentral.com');
  const [projectKey, setProjectKey] = (0,react.useState)('');
  const [isJiraNotLoggedIn, setIsJiraNotLoggedIn] = (0,react.useState)(false);

  // 使用 ref 跟踪组件是否已挂载
  const isMountedRef = (0,react.useRef)(true);
  (0,react.useEffect)(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  // 获取授权 token
  const getAuthToken = () => {
    return new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({
        interactive: false
      }, token => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(token || '');
        }
      });
    });
  };
  const handleSubmit = async e => {
    e.preventDefault();
    if (!projectKey.trim()) {
      setError('请输入 Jira Project Key');
      return;
    }
    setIsSubmitting(true);
    setError('');
    setIsJiraNotLoggedIn(false);
    try {
      // 导入服务类
      const {
        JiraAutomationService
      } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 5704));
      const jiraService = new JiraAutomationService();

      // 步骤 1: 测试连接
      setStep('testing');
      const testResult = await jiraService.testAccess({
        jiraUrl,
        projectKey: projectKey.toUpperCase()
      });
      if (!testResult.success) {
        throw new Error(testResult.message);
      }

      // 步骤 2: 创建规则
      setStep('creating');
      const ruleResult = await jiraService.createBotExecutorRule({
        jiraUrl,
        projectKey: projectKey.toUpperCase()
      }, config.webAppUrl);

      // 保存配置到 scheduledMessagesConfig.botExecutor
      const updatedConfig = {
        ...config,
        botExecutor: {
          ...ruleResult,
          jiraUrl
        }
      };

      // 使用 ConfigSyncService 同步配置到 Sheet 和 Chrome Storage
      const token = await getAuthToken();
      const {
        ConfigSyncService
      } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 8998));
      const syncService = new ConfigSyncService(token);
      await syncService.syncConfig(updatedConfig);
      onSuccess();
    } catch (err) {
      console.error('配置 Bot 失败:', err);
      if (isMountedRef.current) {
        const errorMessage = err.message || '配置失败，请重试';
        // 检测未登录状态（通常是 401 错误或包含登录相关关键词）
        const isNotLoggedIn = errorMessage.includes('401') || errorMessage.includes('未登录') || errorMessage.includes('登录') || errorMessage.includes('Unauthorized') || errorMessage.includes('authentication') || errorMessage.includes('login');
        setIsJiraNotLoggedIn(isNotLoggedIn);
        setError(isNotLoggedIn ? 'JIRA 未登录，请先登录后再试' : errorMessage);
        setStep('input');
      }
    } finally {
      if (isMountedRef.current) {
        setIsSubmitting(false);
      }
    }
  };
  return /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.overlay
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.dialog
  }, /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.header
  }, /*#__PURE__*/react.createElement("h2", {
    style: dialogStyles.title
  }, "\uD83E\uDD16 \u914D\u7F6E Bot \u63A8\u9001"), /*#__PURE__*/react.createElement("button", {
    style: dialogStyles.closeButton,
    onClick: onClose,
    disabled: isSubmitting
  }, "\u2715")), /*#__PURE__*/react.createElement("form", {
    onSubmit: handleSubmit,
    style: dialogStyles.form
  }, step === 'input' && /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("div", {
    style: {
      backgroundColor: '#e7f3ff',
      padding: '15px',
      borderRadius: '8px',
      marginBottom: '20px',
      border: '1px solid #b3d7ff'
    }
  }, /*#__PURE__*/react.createElement("p", {
    style: {
      margin: '0 0 8px 0',
      fontSize: '14px',
      fontWeight: 'bold',
      color: '#333'
    }
  }, "\uD83D\uDCCB \u914D\u7F6E\u8BF4\u660E"), /*#__PURE__*/react.createElement("ul", {
    style: {
      margin: 0,
      paddingLeft: '20px',
      fontSize: '13px',
      color: '#666',
      lineHeight: '1.6'
    }
  }, /*#__PURE__*/react.createElement("li", null, "\u9700\u8981\u60A8\u5728 Jira \u4E0A\u6709\u7BA1\u7406\u6743\u9650\u7684\u9879\u76EE"), /*#__PURE__*/react.createElement("li", null, "\u7CFB\u7EDF\u5C06\u5728\u8BE5\u9879\u76EE\u4E0B\u521B\u5EFA\u4E00\u4E2A Automation \u89C4\u5219"), /*#__PURE__*/react.createElement("li", null, "\u8BE5\u89C4\u5219\u6BCF\u5206\u949F\u6267\u884C\u4E00\u6B21\uFF0C\u68C0\u67E5\u5E76\u53D1\u9001 Bot \u6D88\u606F"), /*#__PURE__*/react.createElement("li", null, "\u2705 Bot \u914D\u7F6E\uFF08API \u5730\u5740\u3001Token\u3001ID\uFF09\u5C06\u81EA\u52A8\u4ECE\u6269\u5C55\u8BBE\u7F6E\u4E2D\u8BFB\u53D6\uFF0C\u65E0\u9700\u624B\u52A8\u586B\u5199"))), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "Jira URL *"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "text",
    value: jiraUrl,
    onChange: e => setJiraUrl(e.target.value),
    placeholder: "https://jira.ringcentral.com"
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u8BF7\u786E\u4FDD\u60A8\u5DF2\u5728\u6D4F\u89C8\u5668\u4E2D\u767B\u5F55\u6B64 Jira \u5B9E\u4F8B")), /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.formGroup
  }, /*#__PURE__*/react.createElement("label", {
    style: dialogStyles.label
  }, "Project Key *"), /*#__PURE__*/react.createElement("input", {
    style: dialogStyles.input,
    type: "text",
    value: projectKey,
    onChange: e => setProjectKey(e.target.value.toUpperCase()),
    placeholder: "MTR",
    maxLength: 10
  }), /*#__PURE__*/react.createElement("small", {
    style: dialogStyles.hint
  }, "\u8BF7\u8F93\u5165\u60A8\u6709\u7BA1\u7406\u6743\u9650\u7684\u9879\u76EE Key\uFF0C\u5982\uFF1AMTR")), error && /*#__PURE__*/react.createElement("div", {
    style: {
      padding: '12px',
      backgroundColor: isJiraNotLoggedIn ? '#fff3cd' : '#f8d7da',
      color: isJiraNotLoggedIn ? '#856404' : '#721c24',
      borderRadius: '6px',
      fontSize: '14px',
      marginTop: '16px',
      border: `1px solid ${isJiraNotLoggedIn ? '#ffc107' : '#f5c6cb'}`
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: {
      fontWeight: 'bold',
      marginBottom: '6px'
    }
  }, isJiraNotLoggedIn ? '⚠️ JIRA 未登录' : '❌ 配置失败'), /*#__PURE__*/react.createElement("div", {
    style: {
      whiteSpace: 'pre-wrap',
      marginBottom: isJiraNotLoggedIn ? '12px' : '0'
    }
  }, error), isJiraNotLoggedIn && /*#__PURE__*/react.createElement("button", {
    type: "button",
    onClick: () => window.open(jiraUrl, '_blank'),
    style: {
      padding: '8px 16px',
      backgroundColor: '#ffc107',
      color: '#000',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: 'bold'
    }
  }, "\uD83D\uDD17 \u6253\u5F00 JIRA \u767B\u5F55"))), step === 'testing' && /*#__PURE__*/react.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '40px 20px'
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.spinner
  }), /*#__PURE__*/react.createElement("p", {
    style: {
      fontSize: '16px',
      color: '#333',
      marginTop: '20px'
    }
  }, "\u6B63\u5728\u6D4B\u8BD5 Jira \u8FDE\u63A5...")), step === 'creating' && /*#__PURE__*/react.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '40px 20px'
    }
  }, /*#__PURE__*/react.createElement("div", {
    style: ScheduledMessagesManager_styles.spinner
  }), /*#__PURE__*/react.createElement("p", {
    style: {
      fontSize: '16px',
      color: '#333',
      marginTop: '20px'
    }
  }, "\u6B63\u5728\u521B\u5EFA Jira Automation \u89C4\u5219..."), /*#__PURE__*/react.createElement("p", {
    style: {
      fontSize: '13px',
      color: '#999',
      marginTop: '10px'
    }
  }, "\u8FD9\u53EF\u80FD\u9700\u8981\u51E0\u79D2\u949F\uFF0C\u8BF7\u7A0D\u5019...")), step === 'input' && /*#__PURE__*/react.createElement("div", {
    style: dialogStyles.actions
  }, /*#__PURE__*/react.createElement("button", {
    type: "button",
    style: dialogStyles.cancelButton,
    onClick: onClose,
    disabled: isSubmitting
  }, "\u53D6\u6D88"), /*#__PURE__*/react.createElement("button", {
    type: "submit",
    style: dialogStyles.submitButton,
    disabled: isSubmitting
  }, isSubmitting ? '配置中...' : '✅ 开始配置')))));
};

// 渲染应用
react_dom.render(/*#__PURE__*/react.createElement(react.StrictMode, null, /*#__PURE__*/react.createElement(ScheduledMessagesManager, null)), document.getElementById('root'));
/******/ })()
;
//# sourceMappingURL=scheduled-messages.js.map