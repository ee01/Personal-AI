/******/ (() => { // webpackBootstrap
/******/ 	"use strict";

;// CONCATENATED MODULE: ./src/storage.ts
function getIndexedDBData(databaseName, storeName) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(databaseName);
    request.onsuccess = event => {
      const db = event.target.result;
      const transaction = db.transaction([storeName], 'readonly');
      const objectStore = transaction.objectStore(storeName);
      const dataRequest = objectStore.getAll();
      dataRequest.onsuccess = event => {
        resolve(event.target.result);
      };
      dataRequest.onerror = event => {
        reject(event.target.error);
      };
    };
    request.onerror = event => {
      reject(event.target.error);
    };
  });
}
const getLocalStorageItem = (key, defaultValue) => {
  return JSON.parse(localStorage.getItem(key) || JSON.stringify(defaultValue));
};
const setLocalStorageItem = (key, defaultValue) => {
  localStorage.setItem(key, JSON.stringify(defaultValue));
};
function getCurrentUserInfo() {
  const {
    extension: extensionId
  } = getLocalStorageItem('ownExtension', {});
  const username = getLocalStorageItem('displayName', 'radar-poc');
  return {
    extensionId,
    username
  };
}
function getFolders() {
  return getIndexedDBData('Glip', 'profile').then(_ref => {
    let [data] = _ref;
    const favorite_group_ids = data?.favorite_group_ids || [];
    const conversation_sets = data?.conversation_sets || [];
    // @ts-ignore
    const folders = [{
      title: ' ',
      ids: []
    }, {
      title: 'favorite',
      ids: favorite_group_ids
    }, ...conversation_sets.filter(item => item.type === 'folder')];
    return folders;
  }).catch(error => {
    console.log(error);
  });
}
function getGroupsMap() {
  return getIndexedDBData('Glip', 'group').then(groups => {
    const groupsMap = groups.reduce((acc, group) => {
      acc[group.id] = {
        name: group.set_abbreviation,
        is_team: group.is_team
      };
      return acc;
    }, {});
    return groupsMap;
  });
}
;// CONCATENATED MODULE: ./src/scheduled-messages/scheduleUtils.ts
/**
 * Schedule 解析工具函数
 * 共享的纯解析逻辑，可被多个 content scripts 和 services 使用
 * 不依赖 Chrome APIs，保证在任何上下文中都能正常工作
 */

/**
 * Schedule 配置接口
 */

/**
 * Cron 解析结果
 */

/**
 * 解析星期配置
 * 支持格式：1-5, 1,3,5, MON-FRI, MON,WED,FRI
 * @returns Jira 格式的数字数组：1=周日, 2=周一, ..., 7=周六
 */
function parseDaysOfWeek(dayOfWeek) {
  const dayMap = {
    'SUN': 1,
    'MON': 2,
    'TUE': 3,
    'WED': 4,
    'THU': 5,
    'FRI': 6,
    'SAT': 7,
    '1': 1,
    '2': 2,
    '3': 3,
    '4': 4,
    '5': 5,
    '6': 6,
    '7': 7
  };
  const result = [];
  const segments = dayOfWeek.split(',');
  for (const segment of segments) {
    const trimmed = segment.trim().toUpperCase();
    if (trimmed.includes('-')) {
      const [start, end] = trimmed.split('-');
      const startNum = dayMap[start.trim()] || parseInt(start.trim(), 10);
      const endNum = dayMap[end.trim()] || parseInt(end.trim(), 10);
      if (!isNaN(startNum) && !isNaN(endNum)) {
        for (let i = startNum; i <= endNum; i++) {
          if (!result.includes(i)) result.push(i);
        }
      }
    } else {
      const num = dayMap[trimmed] || parseInt(trimmed, 10);
      if (!isNaN(num) && !result.includes(num)) {
        result.push(num);
      }
    }
  }
  return result.sort((a, b) => a - b);
}

/**
 * 计算下一个调度日期
 */
function getNextScheduleDate(hours, minutes, repeatUnit, daysOfWeek) {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hours, minutes);
  if (repeatUnit === 'Week' && daysOfWeek && daysOfWeek.length > 0) {
    // Jira 的周日是 1，JavaScript Date.getDay() 的周日是 0
    const currentJiraDay = now.getDay() + 1;
    for (let offset = 0; offset < 7; offset++) {
      const checkDay = (currentJiraDay - 1 + offset) % 7 + 1;
      if (daysOfWeek.includes(checkDay)) {
        const targetDate = new Date(now);
        targetDate.setDate(now.getDate() + offset);

        // 如果是今天但时间已过，继续找下一天
        if (offset === 0 && now > today) {
          continue;
        }
        return targetDate.toISOString().split('T')[0];
      }
    }
  }

  // 默认：如果今天时间已过，用明天
  if (now > today) {
    today.setDate(today.getDate() + 1);
  }
  return today.toISOString().split('T')[0];
}

/**
 * 解析 Cron 表达式获取调度配置
 * Jira CRON 格式: 秒 分 时 日 月 周
 * 注意：Jira 使用 UTC 时间，会自动转换为本地时间 (UTC+8)
 */
function parseCronExpression(cron) {
  if (!cron) return null;
  const parts = cron.split(' ');
  if (parts.length < 6) return null;
  const [_seconds, minutes, hours, dayOfMonth, _month, dayOfWeek] = parts;

  // 解析时间（Jira CRON 使用 UTC 时间，需要转换为本地时间 UTC+8）
  const timeMinutes = parseInt(minutes, 10) || 0;
  const utcHours = parseInt(hours, 10) || 0;
  const localHours = (utcHours + 8) % 24; // UTC -> 本地时间 (UTC+8)
  const time = `${String(localHours).padStart(2, '0')}:${String(timeMinutes).padStart(2, '0')}`;
  let repeatEvery = 1;
  let repeatUnit = 'Day';
  let daysOfWeek;

  // 检查是否是每周特定几天
  if (dayOfWeek !== '*' && dayOfWeek !== '?') {
    daysOfWeek = parseDaysOfWeek(dayOfWeek);
    if (daysOfWeek && daysOfWeek.length > 0) {
      repeatUnit = 'Week';
    }
  }

  // 检查是否是每 N 天
  if (dayOfMonth !== '*' && dayOfMonth !== '?') {
    const dayMatch = dayOfMonth.match(/^\*\/(\d+)$/);
    if (dayMatch) {
      repeatEvery = parseInt(dayMatch[1], 10);
      repeatUnit = 'Day';
    } else if (/^\d+$/.test(dayOfMonth)) {
      repeatUnit = 'Month';
    }
  }
  return {
    time,
    repeatEvery,
    repeatUnit,
    daysOfWeek
  };
}

/**
 * 解析 FIXED 模式配置
 * @param schedule - trigger.value.schedule 对象
 * @returns 解析后的重复配置
 */
function parseFixedRateConfig(schedule) {
  // rateInterval 单位是分钟
  // 60 = 1小时, 86400 = 1天, 604800 = 1周, 2592000 = 1个月
  let repeatUnit = 'Day';
  let repeatEvery = schedule?.rate || 1;
  const rateInterval = schedule?.rateInterval || 86400;
  if (rateInterval < 86400) {
    // 小于1天的间隔（Hour、Minute），统一为"每天"
    repeatUnit = 'Day';
    repeatEvery = 1;
  } else if (rateInterval === 604800) {
    repeatUnit = 'Week';
  } else if (rateInterval === 2592000) {
    repeatUnit = 'Month';
  }
  return {
    repeatEvery,
    repeatUnit
  };
}

/**
 * 分析 Jira Automation Rule 的 trigger，返回用于 Scheduled Messages 的配置
 * 
 * 支持三种情况：
 * 1. scheduled + nosearch - 完整导入调度信息，可以托管
 * 2. scheduled + jql - 仅展示调度信息，不可托管
 * 3. 其他类型 - 仅作为引用
 * 
 * @param trigger - Jira Rule 的 trigger 对象
 * @param scheduleDate - 可选的日期（用于 FIXED 模式，从 audit log 获取）
 * @returns ScheduleConfig 对象
 */
function analyzeTriggerForScheduledMessages(trigger, scheduleDate) {
  const isScheduledTrigger = trigger?.type === 'jira.jql.scheduled';
  const executionMode = trigger?.value?.executionMode;
  const schedule = trigger?.value?.schedule;

  // 情况一：scheduled + nosearch - 完整导入，可以托管
  if (isScheduledTrigger && executionMode === 'nosearch') {
    if (schedule?.method === 'CRON') {
      const cronConfig = parseCronExpression(schedule.cronExpression);
      if (cronConfig) {
        const [hours, minutes] = cronConfig.time.split(':').map(Number);
        return {
          scheduleDate: getNextScheduleDate(hours, minutes, cronConfig.repeatUnit, cronConfig.daysOfWeek),
          scheduleTime: cronConfig.time,
          repeatEvery: cronConfig.repeatEvery,
          repeatUnit: cronConfig.repeatUnit,
          daysOfWeek: cronConfig.daysOfWeek,
          executionMode: 'nosearch',
          needsWebhookConversion: true,
          triggerType: trigger.type
        };
      }
    } else if (schedule?.method === 'FIXED') {
      const {
        repeatEvery,
        repeatUnit
      } = parseFixedRateConfig(schedule);
      return {
        scheduleDate,
        // FIXED 模式需要外部传入日期
        repeatEvery,
        repeatUnit,
        executionMode: 'nosearch',
        needsWebhookConversion: true,
        triggerType: trigger.type
      };
    }
  }

  // 情况二：scheduled + jql - 仅展示，不可托管
  if (isScheduledTrigger && executionMode === 'jql') {
    if (schedule?.method === 'CRON') {
      const cronConfig = parseCronExpression(schedule.cronExpression);
      if (cronConfig) {
        const [hours, minutes] = cronConfig.time.split(':').map(Number);
        return {
          scheduleDate: getNextScheduleDate(hours, minutes, cronConfig.repeatUnit, cronConfig.daysOfWeek),
          scheduleTime: cronConfig.time,
          repeatEvery: cronConfig.repeatEvery,
          repeatUnit: cronConfig.repeatUnit,
          daysOfWeek: cronConfig.daysOfWeek,
          executionMode: 'jql',
          needsWebhookConversion: false,
          triggerType: trigger.type
        };
      }
    } else if (schedule?.method === 'FIXED') {
      const {
        repeatEvery,
        repeatUnit
      } = parseFixedRateConfig(schedule);
      return {
        scheduleDate,
        // FIXED 模式需要外部传入日期
        repeatEvery,
        repeatUnit,
        executionMode: 'jql',
        needsWebhookConversion: false,
        triggerType: trigger.type
      };
    }
  }

  // 情况三：其他类型（包括 incoming webhook）- 仅作为引用
  return {
    repeatEvery: 1,
    repeatUnit: 'Day',
    executionMode: 'other',
    needsWebhookConversion: false,
    triggerType: trigger?.type
  };
}

/**
 * 将 Jira 格式的星期 (1-7) 转换为 JS 格式 (0-6)
 * Jira: 1=周日, 2=周一, ..., 7=周六
 * JS: 0=周日, 1=周一, ..., 6=周六
 */
function jiraDaysToJsDays(jiraDays) {
  return jiraDays.map(d => (d - 1) % 7).sort((a, b) => a - b);
}

/**
 * 格式化星期显示（用于 UI 展示）
 * @param daysOfWeek Jira 格式的星期数组 (1=周日, 2=周一...7=周六)
 */
function formatDaysOfWeekDisplay(daysOfWeek) {
  if (!daysOfWeek || daysOfWeek.length === 0) return '';
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  // 转换 Jira 格式 (1-7) 到 JS 格式 (0-6)
  const jsDays = jiraDaysToJsDays(daysOfWeek);

  // 检查是否是工作日 (1,2,3,4,5 in JS = Mon-Fri)
  if (jsDays.length === 5 && jsDays[0] === 1 && jsDays[1] === 2 && jsDays[2] === 3 && jsDays[3] === 4 && jsDays[4] === 5) {
    return '工作日 (Mon-Fri)';
  }

  // 检查是否是周末 (0,6 in JS = Sun, Sat)
  if (jsDays.length === 2 && jsDays[0] === 0 && jsDays[1] === 6) {
    return '周末 (Sat, Sun)';
  }

  // 其他情况，显示具体星期
  return jsDays.map(d => dayNames[d]).join(', ');
}

/**
 * 根据 ScheduleConfig 构建 Scheduled Messages 的 messageData 中的调度字段
 * @param scheduleConfig - 解析后的调度配置
 * @returns 需要添加到 messageData 的调度字段对象
 */
function buildScheduleMessageFields(scheduleConfig) {
  const fields = {};
  if (scheduleConfig.scheduleDate) {
    fields.Schedule_Date = scheduleConfig.scheduleDate;
  }
  if (scheduleConfig.scheduleTime) {
    fields.Schedule_Time = scheduleConfig.scheduleTime;
  }
  fields.Repeat_Every = scheduleConfig.repeatEvery;
  fields.Repeat_Unit = scheduleConfig.repeatUnit;

  // 如果有多星期配置，转换 Jira 格式 (1-7) 到 JS 格式 (0-6) 并保存
  if (scheduleConfig.daysOfWeek && scheduleConfig.daysOfWeek.length > 0) {
    const jsDays = jiraDaysToJsDays(scheduleConfig.daysOfWeek);
    fields.Repeat_Days = jsDays.join(',');
  }
  return fields;
}
;// CONCATENATED MODULE: ./src/utils.ts
// 环境配置类型定义

function formatDate(dateString) {
  const date = new Date(dateString);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}
function uniqBy(array, key) {
  const seen = new Set();
  return array.filter(item => {
    const keyValue = item[key];
    if (seen.has(keyValue)) {
      return false;
    }
    seen.add(keyValue);
    return true;
  });
}
function showToast(message, type, onClose) {
  // 获取或创建容器元素
  const container = document.getElementById('radar-poc-result');
  if (!container) return;

  // 移除现有的 Toast 元素
  const existingToast = container.querySelector('.radar-poc-toast');
  if (existingToast) {
    container.removeChild(existingToast);
  }

  // 创建新的 Toast 元素
  const toast = document.createElement('div');
  toast.className = `radar-poc-toast radar-poc-toast-${type}`;
  const toastInner = document.createElement('div');
  toastInner.className = 'radar-poc-toast-inner';
  toastInner.textContent = message;
  toast.appendChild(toastInner);
  container.appendChild(toast);

  // 设置定时器在 3 秒后关闭 Toast
  const timer = setTimeout(() => {
    if (container.contains(toast)) {
      container.removeChild(toast);
    }
    if (onClose) {
      onClose();
    }
  }, 3000);

  // 返回一个函数以便手动关闭 Toast
  return () => {
    clearTimeout(timer);
    if (container.contains(toast)) {
      container.removeChild(toast);
    }
    if (onClose) {
      onClose();
    }
  };
}
function transformGroupLinks(inputString) {
  const groupLinkPattern = /\[group:(.+):(\d+)\]/g;
  const transformedString = inputString.replace(groupLinkPattern, (match, groupName, groupId) => {
    return `[${groupName}](/messages/${groupId})`;
  });
  return transformedString;
}
function transformPostLinks(inputString) {
  const postLinkPattern = /\[post:(\d+)\]/g;
  let index = 1;
  const transformedString = inputString.replace(postLinkPattern, (match, postId) => {
    return `[[${index++}]](/l${window.location.pathname}/${postId})`;
  });
  return transformedString;
}

// 默认环境配置
const defaultEnvConfig = {
  MESSAGE_ANALYSIS_INTERVAL: Number({"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.MESSAGE_ANALYSIS_INTERVAL) || Number({"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.SCHEDULED_INTERVAL) || 120,
  MESSAGE_CONTEXT_WINDOW: Number({"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.MESSAGE_CONTEXT_WINDOW) || 5,
  SCHEDULED_INTERVAL: Number({"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.SCHEDULED_INTERVAL) || 120,
  // 保留用于向后兼容
  ANALYSIS_TYPE: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.ANALYSIS_TYPE || "filter",
  LLM_TYPE: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.LLM_TYPE || "dify",
  ANALYZE_BY_GROUP: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.ANALYZE_BY_GROUP === "true",
  OLLAMA_BASE_URL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OLLAMA_BASE_URL || "http://localhost:11434",
  OLLAMA_MODEL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OLLAMA_MODEL || "deepseek-r1",
  OLLAMA_REVIEW_MODEL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OLLAMA_REVIEW_MODEL || "llama3.1",
  OLLAMA_QUERY_MODEL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OLLAMA_QUERY_MODEL || "llama3.1",
  DIFY_API_KEY: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.DIFY_API_KEY || "",
  DIFY_REVIEW_API_KEY: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.DIFY_REVIEW_API_KEY || "",
  DIFY_API_BASE_URL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.DIFY_API_BASE_URL || "",
  OPENAI_API_KEY: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OPENAI_API_KEY || "",
  OPENAI_MODEL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OPENAI_MODEL || "",
  OPENAI_REVIEW_MODEL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OPENAI_REVIEW_MODEL || "",
  OPENAI_API_BASE_URL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.OPENAI_API_BASE_URL || "",
  GROQ_API_KEY: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.GROQ_API_KEY || "",
  GROQ_MODEL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.GROQ_MODEL || "",
  GROQ_REVIEW_MODEL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.GROQ_REVIEW_MODEL || "",
  BOT_API_BASE_URL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.BOT_API_BASE_URL || "https://botman.int.rclabenv.com/v2",
  BOT_TOKEN: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.BOT_TOKEN || "",
  BOT_ID: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.BOT_ID || "4700372020@37439510.bot.glip.net",
  BOT_TYPE: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.BOT_TYPE || "user",
  TEAM_ID: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.TEAM_ID || "",
  ENABLE_BOT: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.ENABLE_BOT === "true",
  LLM_REVIEW_BEFORE_SEND: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.LLM_REVIEW_BEFORE_SEND === "true",
  ENABLE_CHROMA: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.ENABLE_CHROMA === "true",
  CHROMA_API_URL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.CHROMA_API_URL || "http://localhost:8000",
  // 保留用于兼容
  CHROMA_HOST: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.CHROMA_HOST || "localhost",
  CHROMA_PORT: Number({"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.CHROMA_PORT) || 8000,
  CHROMA_SSL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.CHROMA_SSL === "true",
  CHROMA_COLLECTION_NAME: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.CHROMA_COLLECTION_NAME || "",
  JIRA_BASE_URL: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.JIRA_BASE_URL || "https://jira.ringcentral.com",
  JIRA_USERNAME: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.JIRA_USERNAME || "",
  JIRA_API_TOKEN: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.JIRA_API_TOKEN || "",
  // 消息交互功能开关（默认全部启用）
  ENABLE_AUTO_REPLY: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.ENABLE_AUTO_REPLY !== "false",
  ENABLE_SNOOZE: {"MESSAGE_ANALYSIS_INTERVAL":"60","MESSAGE_CONTEXT_WINDOW":"30","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_HOST":"10.32.56.212","CHROMA_PORT":"8000","CHROMA_SSL":"false","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com","ICON_NAME":"icon"}.ENABLE_SNOOZE !== "false"
};

// 获取环境配置，如果可能的话从 storage 获取，否则从 process.env 获取
async function utils_getEnvConfig() {
  try {
    const {
      envConfig
    } = await chrome.storage.local.get(['envConfig']);
    if (envConfig) {
      // 将存储的配置与默认配置合并，确保新增的配置项也会被包含
      return {
        ...defaultEnvConfig,
        ...envConfig
      };
    }
  } catch (error) {
    console.error('获取配置失败:', error);
  }

  // 如果获取失败或没有保存的配置，返回默认值
  return defaultEnvConfig;
}
function getDefaultEnvConfig() {
  return defaultEnvConfig;
}
async function getUserInfo() {
  const {
    userinfo
  } = await chrome.storage.local.get(['userinfo']);
  return userinfo;
}

/**
 * 解析 ChromaDB 连接参数，支持新旧配置格式的兼容
 */
function parseChromaConfig(config) {
  // 如果有新的 host 配置，直接使用
  if (config.CHROMA_HOST && config.CHROMA_HOST !== 'localhost') {
    return {
      host: config.CHROMA_HOST,
      port: config.CHROMA_PORT,
      ssl: config.CHROMA_SSL
    };
  }

  // 如果没有配置新的 host，尝试从旧的 CHROMA_API_URL 解析
  if (config.CHROMA_API_URL) {
    try {
      const url = new URL(config.CHROMA_API_URL);
      return {
        host: url.hostname,
        port: url.port ? parseInt(url.port) : url.protocol === 'https:' ? 443 : 8000,
        ssl: url.protocol === 'https:'
      };
    } catch (error) {
      console.warn('解析 CHROMA_API_URL 失败:', error);
      // 回退到默认值
      return {
        host: 'localhost',
        port: config.CHROMA_PORT || 8000,
        ssl: false
      };
    }
  }

  // 都没有配置，使用默认值
  return {
    host: config.CHROMA_HOST || 'localhost',
    port: config.CHROMA_PORT || 8000,
    ssl: config.CHROMA_SSL || false
  };
}
;// CONCATENATED MODULE: ./src/jira.ts


// JIRA 基础配置
const JIRA_BASE_URL = 'https://jira.ringcentral.com';

// =====================================================
// JIRA 认证工具函数（统一管理 Token 和 Cookie 认证）
// =====================================================

// 缓存 Jira token
let cachedJiraToken = null;

/**
 * 获取 JIRA Token（优先使用配置的 token）
 * @returns token 字符串，如果未配置则返回 null
 */
async function getJiraToken() {
  if (cachedJiraToken !== null) {
    return cachedJiraToken || null;
  }
  try {
    const envConfig = await utils_getEnvConfig();
    cachedJiraToken = envConfig.JIRA_API_TOKEN || '';
    return cachedJiraToken || null;
  } catch (error) {
    console.log('未配置 Jira Token，将使用 cookie 模式访问');
    cachedJiraToken = '';
    return null;
  }
}

/**
 * 清除 token 缓存（当用户更新配置时调用）
 */
function clearJiraTokenCache() {
  cachedJiraToken = null;
}

/**
 * 创建 JIRA 请求头，自动支持 token 和 cookie fallback
 * @param additionalHeaders 额外的请求头
 * @param overrideToken 可选的覆盖 token（用于调用方明确指定 token 的情况）
 * @returns 请求头对象
 */
async function createJiraHeaders() {
  let additionalHeaders = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  let overrideToken = arguments.length > 1 ? arguments[1] : undefined;
  const token = overrideToken ?? (await getJiraToken());
  const headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache',
    ...additionalHeaders
  };

  // 如果有 token，添加 Authorization 头
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

/**
 * 创建 JIRA 请求配置，自动支持 token 和 cookie fallback
 * @param method HTTP 方法
 * @param additionalHeaders 额外的请求头
 * @param body 请求体（会被 JSON.stringify）
 * @param overrideToken 可选的覆盖 token
 * @returns fetch 请求的 init 配置对象
 */
async function createJiraFetchInit() {
  let method = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'GET';
  let additionalHeaders = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  let body = arguments.length > 2 ? arguments[2] : undefined;
  let overrideToken = arguments.length > 3 ? arguments[3] : undefined;
  const headers = await createJiraHeaders(additionalHeaders, overrideToken);
  const init = {
    method,
    headers,
    credentials: 'include' // 始终包含 cookie 作为 fallback
  };
  if (body && method !== 'GET') {
    init.body = JSON.stringify(body);
  }
  return init;
}

/**
 * 统一的 JIRA API 请求方法
 * 自动处理 token 和 cookie 双重认证
 * 
 * @param url 完整的 API URL 或相对路径
 * @param options 请求配置
 * @returns fetch Response
 */
async function jiraFetch(url) {
  let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  const init = await createJiraFetchInit(options.method || 'GET', options.headers || {}, options.body, options.token);
  return fetch(url, init);
}

/**
 * 获取 JIRA Base URL
 * 优先从环境配置读取，否则使用默认值
 */
async function getJiraBaseUrl() {
  try {
    const envConfig = await getEnvConfig();
    return envConfig.JIRA_BASE_URL || JIRA_BASE_URL;
  } catch {
    return JIRA_BASE_URL;
  }
}

// =====================================================
// 通用 JIRA API 工具函数
// =====================================================

/**
 * 获取当前 JIRA 用户信息
 */
async function getCurrentUser() {
  try {
    const baseUrl = await getJiraBaseUrl();
    const response = await jiraFetch(`${baseUrl}/rest/api/2/myself`);
    if (!response.ok) {
      return {
        success: false,
        error: `获取用户信息失败 (${response.status})`
      };
    }
    const userInfo = await response.json();
    const ownerId = userInfo.key || userInfo.name || userInfo.accountId;
    if (!ownerId) {
      return {
        success: false,
        error: '无法从用户信息中获取用户标识'
      };
    }
    return {
      success: true,
      ownerId,
      accountId: userInfo.accountId,
      name: userInfo.name
    };
  } catch (error) {
    return {
      success: false,
      error: error.message || '获取用户信息失败'
    };
  }
}

/**
 * 通过项目 Key 获取项目信息（ID、名称等）
 */
async function getProjectByKey(projectKey) {
  try {
    const baseUrl = await getJiraBaseUrl();
    const response = await jiraFetch(`${baseUrl}/rest/api/2/project/${projectKey}`);
    if (!response.ok) {
      if (response.status === 404) {
        return {
          success: false,
          error: `项目 ${projectKey} 不存在`
        };
      }
      return {
        success: false,
        error: `获取项目信息失败 (${response.status})`
      };
    }
    const projectInfo = await response.json();
    return {
      success: true,
      projectId: projectInfo.id,
      projectName: projectInfo.name,
      project: projectInfo
    };
  } catch (error) {
    return {
      success: false,
      error: error.message || '获取项目信息失败'
    };
  }
}

/**
 * 获取单个 JIRA Ticket 的详细信息
 * @param ticketKey Ticket 的 key，如 INIT-23647
 * @returns Ticket 详细信息
 */
async function getTicketDetail(ticketKey) {
  try {
    const baseUrl = await getJiraBaseUrl();
    const fields = ['summary', 'status', 'issuetype', 'priority', 'assignee', 'reporter', 'created', 'updated', 'duedate', 'resolution', 'labels', 'components', 'fixVersions', 'customfield_11450', 'customfield_11451', 'customfield_10106', 'description'].join(',');
    const response = await jiraFetch(`${baseUrl}/rest/api/2/issue/${ticketKey}?fields=${fields}`);
    if (!response.ok) {
      if (response.status === 404) {
        return {
          success: false,
          error: `Ticket ${ticketKey} 不存在`
        };
      }
      if (response.status === 401 || response.status === 403) {
        return {
          success: false,
          error: '未授权访问，请先登录 JIRA'
        };
      }
      return {
        success: false,
        error: `获取 Ticket 信息失败 (${response.status})`
      };
    }
    const issue = await response.json();
    const fields_data = issue.fields;

    // 处理 Sprint 字段 (customfield_10106)
    let sprintName;
    if (fields_data.customfield_10106 && Array.isArray(fields_data.customfield_10106)) {
      const activeSprint = fields_data.customfield_10106.find(s => s.state === 'active');
      const latestSprint = activeSprint || fields_data.customfield_10106[fields_data.customfield_10106.length - 1];
      if (latestSprint) {
        sprintName = typeof latestSprint === 'string' ? latestSprint.match(/name=([^,]+)/)?.[1] : latestSprint.name;
      }
    }
    return {
      success: true,
      data: {
        key: issue.key,
        summary: fields_data.summary || '',
        status: fields_data.status?.name || '',
        statusCategory: fields_data.status?.statusCategory?.key || '',
        issuetype: fields_data.issuetype?.name || '',
        priority: fields_data.priority?.name || '',
        assignee: fields_data.assignee?.displayName || '未分配',
        assigneeAvatar: fields_data.assignee?.avatarUrls?.['24x24'],
        reporter: fields_data.reporter?.displayName || '',
        reporterAvatar: fields_data.reporter?.avatarUrls?.['24x24'],
        created: fields_data.created || '',
        updated: fields_data.updated || '',
        duedate: fields_data.duedate,
        resolution: fields_data.resolution?.name,
        labels: fields_data.labels || [],
        components: (fields_data.components || []).map(c => c.name),
        fixVersions: (fields_data.fixVersions || []).map(v => v.name),
        epicLink: fields_data.customfield_11450,
        epicName: fields_data.customfield_11451,
        storyPoints: fields_data.customfield_10106,
        sprint: sprintName,
        description: fields_data.description?.substring(0, 500),
        url: `${baseUrl}/browse/${issue.key}`
      }
    };
  } catch (error) {
    console.error('Error fetching ticket detail:', error);
    return {
      success: false,
      error: error.message || '获取 Ticket 信息失败'
    };
  }
}

// =====================================================
// JIRA Issues 抓取功能
// =====================================================

// 从 Jira 页面抓取数据
async function fetchJiraTickets(jql) {
  return new Promise((resolve, reject) => {
    const requestId = Math.random().toString(36).substring(7);

    // 监听来自 background script 的消息
    const messageListener = message => {
      // 只处理匹配的消息类型和请求ID
      if (message.type === 'JIRA_TICKETS_RESULT' && message.requestId === requestId) {
        chrome.runtime.onMessage.removeListener(messageListener);
        if (message.error) {
          reject(new Error(message.error));
        } else {
          resolve(message.tickets);
        }
        return true; // 只对匹配的消息返回 true
      }
      // 不处理的消息类型，返回 false 或不返回，让其他监听器处理
      return false;
    };
    chrome.runtime.onMessage.addListener(messageListener);

    // 发送消息给 background script 来创建新标签页
    chrome.runtime.sendMessage({
      type: 'FETCH_JIRA_TICKETS',
      jql,
      requestId
    });
  });
}

// 然后在 FETCH_JIRA_TICKETS 函数中使用 sourceTabId
async function FETCH_JIRA_TICKETS(jql, requestId, sourceTabId) {
  const envConfig = await getEnvConfig();
  const url = `${envConfig.JIRA_BASE_URL}/issues/?jql=${encodeURIComponent(jql)}&wildcardFlag=true`;

  // 创建新标签页
  chrome.tabs.create({
    url,
    active: false
  }, tab => {
    if (!tab.id) {
      chrome.tabs.sendMessage(sourceTabId, {
        type: 'JIRA_TICKETS_RESULT',
        requestId,
        error: '无法创建标签页'
      });
      return;
    }

    // 等待页面加载完成
    const checkPageLoad = () => {
      chrome.tabs.get(tab.id, updatedTab => {
        if (updatedTab.status === 'complete') {
          if (updatedTab.url.includes('login') || updatedTab.url.includes('okta')) {
            chrome.tabs.sendMessage(sourceTabId, {
              type: 'JIRA_TICKETS_RESULT',
              requestId,
              error: 'jira 需要登录，请登录后重新尝试'
            });
            setTimeout(() => chrome.tabs.update(tab.id, {
              active: true
            }), 3000);
            return;
          }
          // 注入内容脚本
          chrome.scripting.executeScript({
            target: {
              tabId: tab.id
            },
            func: async () => {
              const allTickets = [];

              // 判断是否是Jira Cloud版本，通过检查特定的DOM元素判断
              const isJiraCloud = !!document.querySelector('table[data-vc="issue-table"]') || !!document.querySelector('table[aria-label="Work"]');

              // 抓取当前页面的tickets
              function extractTicketsFromCurrentPage() {
                const tickets = [];
                if (isJiraCloud) {
                  // Jira Cloud 版本的选择器
                  const rows = document.querySelectorAll('tr[data-testid="native-issue-table.ui.issue-row"]');
                  if (rows && rows.length > 0) {
                    rows.forEach(row => {
                      // 获取key - a[data-testid="native-issue-table.common.ui.issue-cells.issue-key.issue-key-cell"]
                      const keyElement = row.querySelector('a[data-testid="native-issue-table.common.ui.issue-cells.issue-key.issue-key-cell"]');

                      // 获取summary - a[data-testid="native-issue-table.common.ui.issue-cells.issue-summary.issue-summary-cell"]
                      const summaryElement = row.querySelector('a[data-testid="native-issue-table.common.ui.issue-cells.issue-summary.issue-summary-cell"]');

                      // 获取status - 状态位于有特定class的span中
                      const statusContainer = row.querySelector('div[data-testid^="issue.fields.status.common.ui.status-lozenge"]');
                      const statusElement = statusContainer ? statusContainer.querySelector('div._4cvr1h6o') : null;

                      // 经办人、报告人和优先级通常位于相应的单元格中
                      const cells = row.querySelectorAll('td');
                      let assignee = '',
                        reporter = '',
                        priority = '',
                        created = '',
                        updated = '',
                        duedate = '';

                      // 通过位置判断各个字段
                      if (cells.length >= 11) {
                        // 假设第5个单元格是assignee
                        const assigneeText = cells[4].textContent?.trim();
                        assignee = assigneeText.match(/^(.+?)\1+$/)[1] || assigneeText;
                        assignee = assignee !== 'Unassigned' ? assignee || '' : '';

                        // 假设第6个单元格是reporter
                        reporter = cells[5].textContent?.trim() || '';
                        reporter = reporter.match(/^(.+?)\1+$/)[1] || reporter;

                        // 假设第7个单元格是priority
                        priority = cells[6].textContent?.trim() || '';

                        // 假设第9个单元格是created
                        created = cells[8].textContent?.trim() || '';

                        // 假设第10个单元格是updated
                        updated = cells[9].textContent?.trim() || '';

                        // 假设第11个单元格是duedate
                        const dueDateText = cells[10].textContent?.trim();
                        duedate = dueDateText !== 'None' ? dueDateText || '' : '';
                      }
                      const ticket = {
                        key: keyElement ? keyElement.textContent?.trim() || '' : '',
                        summary: summaryElement ? summaryElement.textContent?.trim() || '' : '',
                        status: statusElement ? statusElement.textContent?.trim() || '' : '',
                        assignee,
                        reporter,
                        priority,
                        created,
                        updated,
                        duedate,
                        description: '' // Cloud视图中通常不显示描述
                      };
                      tickets.push(ticket);
                    });
                  }
                } else {
                  // 原有的 Jira On-Premise 版本的选择器
                  const rows = document.querySelectorAll('tr.issuerow');
                  rows.forEach(row => {
                    const ticket = {};
                    const cells = row.querySelectorAll('td');
                    cells.forEach(cell => {
                      if (cell.classList && cell.classList.length > 0) {
                        let propertyName = cell.classList[0]; // Get the first class name
                        const img = cell.querySelector('img[alt]');
                        const value = cell.textContent?.trim() || (img ? img.getAttribute('alt') || '' : '');

                        // If the class name is 'issuekey', the property in our object should be 'key'
                        if (propertyName === 'issuekey') propertyName = 'key';
                        if (propertyName) {
                          // Ensure propertyName is not empty
                          ticket[propertyName] = value;
                        }
                      }
                    });

                    // Ensure essential non-optional fields from JiraTicket are present, even if empty
                    ticket.key = ticket.key || '';
                    ticket.summary = ticket.summary || '';
                    ticket.status = ticket.status || '';
                    tickets.push(ticket);
                  });
                }
                return tickets;
              }

              // 查找下一页按钮
              function getNextPageButton() {
                // Jira Cloud 的下一页按钮选择器
                const cloudNextButton = document.querySelector('button[aria-label="Next"]');
                if (cloudNextButton && !cloudNextButton.hasAttribute('disabled')) {
                  return cloudNextButton;
                }

                // Jira On-Premise 的下一页按钮选择器
                const onPremiseNextButton = document.querySelector('a.nav-next');
                if (onPremiseNextButton && !onPremiseNextButton.classList.contains('nav-disabled')) {
                  return onPremiseNextButton;
                }
                return null;
              }

              // 等待页面加载完成，并确保页面真正切换了
              function waitForPageLoad(previousFirstKey) {
                return new Promise(resolve => {
                  const checkLoading = () => {
                    // 检查 Jira Cloud 加载指示器
                    const cloudLoader = document.querySelector('[data-testid="native-issue-table.ui.issue-table-container"] [role="progressbar"]');

                    // 检查 Jira On-Premise 加载指示器
                    const onPremiseLoader = document.querySelector('.loading, .aui-restfultable-loading');
                    if (!cloudLoader && !onPremiseLoader) {
                      // 额外检查：确保页面真正切换了（第一条数据的key不同）
                      const checkPageChanged = () => {
                        let currentFirstKey = '';
                        if (isJiraCloud) {
                          const firstRow = document.querySelector('tr[data-testid="native-issue-table.ui.issue-row"]');
                          const keyElement = firstRow?.querySelector('a[data-testid="native-issue-table.common.ui.issue-cells.issue-key.issue-key-cell"]');
                          currentFirstKey = keyElement?.textContent?.trim() || '';
                        } else {
                          const firstRow = document.querySelector('tr.issuerow');
                          const keyCell = firstRow?.querySelector('td.issuekey');
                          currentFirstKey = keyCell?.textContent?.trim() || '';
                        }
                        if (currentFirstKey && currentFirstKey !== previousFirstKey) {
                          // 页面已经切换，额外等待一点时间确保DOM更新完成
                          setTimeout(resolve, 300);
                        } else if (!previousFirstKey) {
                          // 第一次加载，没有previousFirstKey，直接继续
                          setTimeout(resolve, 300);
                        } else {
                          // 页面还没切换，继续等待
                          setTimeout(checkPageChanged, 200);
                        }
                      };
                      checkPageChanged();
                    } else {
                      setTimeout(checkLoading, 200);
                    }
                  };
                  checkLoading();
                });
              }

              // 主循环：抓取所有页面
              let currentPage = 1;
              const maxPages = 100; // 设置最大页数限制，防止无限循环
              const ticketKeySet = new Set(); // 用于去重

              while (currentPage <= maxPages) {
                console.log(`正在抓取第 ${currentPage} 页...`);

                // 获取当前页第一条数据的key，用于后续验证页面是否切换
                let currentFirstKey = '';
                if (isJiraCloud) {
                  const firstRow = document.querySelector('tr[data-testid="native-issue-table.ui.issue-row"]');
                  const keyElement = firstRow?.querySelector('a[data-testid="native-issue-table.common.ui.issue-cells.issue-key.issue-key-cell"]');
                  currentFirstKey = keyElement?.textContent?.trim() || '';
                } else {
                  const firstRow = document.querySelector('tr.issuerow');
                  const keyCell = firstRow?.querySelector('td.issuekey');
                  currentFirstKey = keyCell?.textContent?.trim() || '';
                }

                // 抓取当前页
                const currentPageTickets = extractTicketsFromCurrentPage();

                // 去重并添加
                let addedCount = 0;
                currentPageTickets.forEach(ticket => {
                  if (ticket.key && !ticketKeySet.has(ticket.key)) {
                    ticketKeySet.add(ticket.key);
                    allTickets.push(ticket);
                    addedCount++;
                  }
                });
                console.log(`第 ${currentPage} 页抓取到 ${currentPageTickets.length} 条数据，去重后新增 ${addedCount} 条，累计 ${allTickets.length} 条`);

                // 查找下一页按钮
                const nextButton = getNextPageButton();
                if (!nextButton) {
                  console.log('没有下一页，抓取完成');
                  break;
                }

                // 点击下一页
                nextButton.click();
                currentPage++;

                // 等待新页面加载完成，并确保页面真正切换了
                await waitForPageLoad(currentFirstKey);
              }
              if (currentPage > maxPages) {
                console.warn(`已达到最大页数限制 (${maxPages})，停止抓取`);
              }
              console.log(`所有页面抓取完成，共 ${currentPage - 1} 页，总计 ${allTickets.length} 条唯一数据`);
              return allTickets;
            }
          }, results => {
            // 处理结果
            if (results && results[0] && results[0].result) {
              // 对summary字段进行额外处理，确保干净的文本
              results[0].result = results[0].result.map(ticket => ({
                ...ticket,
                summary: ticket.summary.split('\n').map(s => s.trim()).filter(Boolean).pop() || ticket.summary
              }));
              chrome.tabs.sendMessage(sourceTabId, {
                type: 'JIRA_TICKETS_RESULT',
                requestId,
                tickets: results[0].result
              });
            } else {
              // 如果没有结果
              chrome.tabs.sendMessage(sourceTabId, {
                type: 'JIRA_TICKETS_RESULT',
                requestId,
                tickets: []
              });
            }

            // 关闭 Jira 标签页
            chrome.tabs.remove(tab.id);
          });
        } else {
          setTimeout(checkPageLoad, 100);
        }
      });
    };
    checkPageLoad();
  });
}
;// CONCATENATED MODULE: ./src/contentScriptJiraAutomation.ts
/**
 * Jira Automation 导入功能 Content Script
 * 在Jira automation管理页面添加导入功能
 */





// 类型定义

// 检测是否在Jira automation管理页面
function isJiraAutomationPage() {
  // 检查主页面URL
  if (window.location.pathname.includes('/secure/AutomationProjectAdminAction')) {
    return true;
  }

  // 检查iframe内的URL
  if (window.location.pathname.includes('/secure/AutomationProjectAdminAction!iframe.jspa')) {
    return true;
  }
  return false;
}

// 从localStorage获取当前ownerId
async function getCurrentOwnerId() {
  // 首先尝试从localStorage获取
  const ownerId = getLocalStorageItem('ownerId', '');
  if (ownerId && ownerId !== 'radar-poc') {
    console.log('Found ownerId from localStorage:', ownerId);
    return ownerId;
  }

  // 如果localStorage中没有，尝试从页面获取（仅在主页面）
  if (window === window.top) {
    const userProfileElement = document.querySelector('#header-details-user-fullname');
    if (userProfileElement) {
      // 从img标签的src属性中获取ownerId
      const imgElement = userProfileElement.querySelector('img');
      if (imgElement) {
        const src = imgElement.getAttribute('src');
        if (src) {
          const ownerIdMatch = src.match(/ownerId=([^&]+)/);
          if (ownerIdMatch && ownerIdMatch[1]) {
            const ownerId = ownerIdMatch[1];
            console.log('Found ownerId from profile image src:', ownerId);
            // 保存到localStorage
            setLocalStorageItem('ownerId', ownerId);
            return ownerId;
          }
        }
      }
    }

    // 如果页面元素中也获取不到，尝试通过API获取（使用统一的认证方法）
    try {
      console.log('Trying to get ownerId from JIRA API...');
      const headers = await createJiraHeaders();
      const response = await fetch(window.location.origin + '/rest/api/2/myself', {
        method: 'GET',
        headers,
        credentials: 'include'
      });
      if (response.ok) {
        const userInfo = await response.json();
        if (userInfo.key) {
          const ownerId = userInfo.key;
          console.log('Found ownerId from JIRA API:', ownerId);
          // 保存到localStorage
          setLocalStorageItem('ownerId', ownerId);
          return ownerId;
        }
      } else {
        console.warn('Failed to fetch user info from JIRA API:', response.status, response.statusText);
      }
    } catch (error) {
      console.warn('Error fetching user info from JIRA API:', error);
    }
  }
  console.warn('Could not find ownerId');
  return '';
}

// 全局变量存储当前项目ID

// 从页面动态获取项目ID
function getProjectId() {
  // 如果是iframe，尝试从父页面获取全局变量
  if (window !== window.top) {
    try {
      const parentProjectId = window.top?.__PERSONAL_AI_PROJECT_ID__;
      if (parentProjectId) {
        console.log('Found project ID from parent window global variable:', parentProjectId);
        return parentProjectId;
      }
    } catch (error) {
      console.log('Cannot access parent window, trying local detection...');
    }
  }

  // 动态从页面获取项目ID
  let projectId = '';

  // 方案1：从页面全局变量获取
  if (typeof window.WRM !== 'undefined' && window.WRM._unparsedData && window.WRM._unparsedData["project-id"]) {
    projectId = window.WRM._unparsedData["project-id"];
    console.log('Found project ID from WRM._unparsedData:', projectId);
  }

  // 方案2：从项目编辑链接中获取projectId
  if (!projectId) {
    const editProjectLink = document.querySelector('#edit_project');
    if (editProjectLink) {
      const href = editProjectLink.getAttribute('href');
      if (href) {
        const pidMatch = href.match(/pid=(\d+)/);
        if (pidMatch && pidMatch[1]) {
          projectId = pidMatch[1];
          console.log('Found project ID from edit project link:', projectId);
        }
      }
    }
  }

  // 方案3：尝试其他可能包含projectId的链接
  if (!projectId) {
    const projectLinks = document.querySelectorAll('a[href*="pid="]');
    for (const link of Array.from(projectLinks)) {
      const href = link.getAttribute('href');
      if (href) {
        const pidMatch = href.match(/pid=(\d+)/);
        if (pidMatch && pidMatch[1]) {
          projectId = pidMatch[1];
          console.log('Found project ID from project link:', projectId);
          break;
        }
      }
    }
  }

  // 方案4：从URL获取projectKey
  if (!projectId) {
    const urlParams = new URLSearchParams(window.location.search);
    const projectKey = urlParams.get('projectKey') || '';
    if (projectKey) {
      projectId = projectKey;
      console.log('Using projectKey from URL as fallback:', projectId);
    }
  }

  // 如果在主页面且找到了项目ID，存储到全局变量供iframe使用
  if (projectId && window === window.top) {
    window.__PERSONAL_AI_PROJECT_ID__ = projectId;
    console.log('Stored project ID in global variable:', projectId);
  }

  // 如果都找不到，返回空字符串
  if (!projectId) {
    console.warn('Could not find project ID');
  }
  return projectId;
}

// 获取项目Key (用于URL构建)
function getProjectKey() {
  // 首先尝试从URL参数获取projectKey
  const urlParams = new URLSearchParams(window.location.search);
  const projectKey = urlParams.get('projectKey');
  if (projectKey) {
    console.log('Found projectKey from URL params:', projectKey);
    return projectKey;
  }

  // 如果URL中没有projectKey，尝试从其他地方获取
  // 这里可以根据需要添加更多的获取逻辑
  console.warn('Could not find projectKey, using default');
  return 'MTR'; // 默认值
}

// 等待元素出现（预留功能）
function _waitForElement(selector) {
  let timeout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 10000;
  return new Promise((resolve, reject) => {
    const element = document.querySelector(selector);
    if (element) {
      return resolve(element);
    }
    const observer = new MutationObserver(() => {
      const element = document.querySelector(selector);
      if (element) {
        observer.disconnect();
        resolve(element);
      }
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
    setTimeout(() => {
      observer.disconnect();
      reject(new Error(`Timeout waiting for element: ${selector}`));
    }, timeout);
  });
}

// 等待iframe加载完成
function waitForIframe() {
  return new Promise((resolve, reject) => {
    const iframe = document.querySelector('iframe.automation-page-container');
    if (!iframe) {
      reject(new Error('Iframe not found'));
      return;
    }
    const checkIframeContent = () => {
      try {
        const iframeDoc = iframe.contentDocument;
        if (iframeDoc && iframeDoc.readyState === 'complete') {
          resolve(iframeDoc);
        } else {
          setTimeout(checkIframeContent, 100);
        }
      } catch (error) {
        setTimeout(checkIframeContent, 100);
      }
    };
    iframe.addEventListener('load', () => {
      // 检查是否有待跳转的URL
      try {
        if (window.top) {
          const pendingUrl = window.top.__PERSONAL_AI_PENDING_NAVIGATION__;
          if (pendingUrl) {
            console.log('Found pending navigation URL on iframe load:', pendingUrl);

            // 清除存储的URL
            window.top.__PERSONAL_AI_PENDING_NAVIGATION__ = null;
            console.log('Executing navigation from iframe load event to:', pendingUrl);
            window.top.location.href = pendingUrl;
            return; // 有待跳转URL时，不需要继续执行其他逻辑
          }
        }
      } catch (error) {
        console.error('Error checking pending navigation on iframe load:', error);
      }
      checkIframeContent();
    });

    // 如果iframe已经加载，直接检查
    checkIframeContent();
  });
}

// 转换导出的JSON格式为API所需格式
async function convertExportedRuleToImportFormat(exportedRule, projectId) {
  const now = Date.now();
  const ownerId = await getCurrentOwnerId();

  // 为components生成新的ID
  const convertedComponents = exportedRule.components.map((component, index) => ({
    ...component,
    id: `__NEW__COMPONENT__${now + index}`
  }));

  // 为trigger设置新的ID
  const convertedTrigger = {
    ...exportedRule.trigger,
    id: '__NEW__TRIGGER'
  };

  // 确保项目ID正确
  const projects = exportedRule.projects.map(project => ({
    ...project,
    projectId: projectId // 使用当前项目ID
  }));
  return {
    name: '(Imported by Personal AI) ' + exportedRule.name,
    isNewRule: true,
    state: exportedRule.state,
    canOtherRuleTrigger: exportedRule.canOtherRuleTrigger,
    notifyOnError: exportedRule.notifyOnError,
    authorAccountId: ownerId,
    created: now,
    updated: now,
    components: convertedComponents,
    trigger: convertedTrigger,
    labels: exportedRule.labels || [],
    description: exportedRule.description,
    projects: projects
  };
}

// 创建automation rule的API调用（使用统一的认证方法）
async function createAutomationRule(ruleData, projectId) {
  try {
    const headers = await createJiraHeaders();
    const response = await fetch(`/rest/cb-automation/latest/project/${projectId}/rule`, {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify(ruleData)
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`API call failed: ${response.status} ${response.statusText}\n${errorText}`);
    }
    return await response.json();
  } catch (error) {
    console.error('Error creating automation rule:', error);
    throw error;
  }
}

// 显示成功消息
function showSuccessMessage(message) {
  const successDiv = document.createElement('div');
  successDiv.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #4CAF50;
    color: white;
    padding: 16px;
    border-radius: 4px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    z-index: 10000;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    max-width: 400px;
  `;
  successDiv.textContent = message;
  document.body.appendChild(successDiv);
  setTimeout(() => {
    document.body.removeChild(successDiv);
  }, 5000);
}

// 显示错误消息
function showErrorMessage(message) {
  const errorDiv = document.createElement('div');
  errorDiv.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #f44336;
    color: white;
    padding: 16px;
    border-radius: 4px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    z-index: 10000;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    max-width: 400px;
    word-wrap: break-word;
  `;
  errorDiv.textContent = message;
  document.body.appendChild(errorDiv);
  setTimeout(() => {
    if (document.body.contains(errorDiv)) {
      document.body.removeChild(errorDiv);
    }
  }, 10000);
}

// 处理文件导入
function handleFileImport(file, projectId) {
  const reader = new FileReader();
  reader.onload = async e => {
    try {
      const content = e.target?.result;
      const exportedData = JSON.parse(content);
      if (!exportedData.rules || !Array.isArray(exportedData.rules)) {
        throw new Error('Invalid JSON format: Missing rules array');
      }
      if (exportedData.rules.length === 0) {
        throw new Error('No rules found in the imported file');
      }

      // 只导入第一个rule（如果有多个的话）
      const ruleToImport = exportedData.rules[0];
      const convertedRule = await convertExportedRuleToImportFormat(ruleToImport, projectId);
      console.log('Importing rule:', convertedRule);

      // 调用API创建rule
      const result = await createAutomationRule(convertedRule, projectId);
      console.log('Rule created successfully:', result);
      showSuccessMessage(`Automation rule "${ruleToImport.name}" imported successfully!`);

      // 跳转到导入后的automation脚本页面
      if (result && result.id) {
        const projectKey = getProjectKey();
        const ruleUrl = `https://jira.ringcentral.com/secure/AutomationProjectAdminAction!default.jspa?projectKey=${projectKey}#/rule/${result.id}`;
        console.log('Navigating to rule page:', ruleUrl);
        setTimeout(() => {
          console.log('Storing navigation URL and refreshing iframe:', ruleUrl);

          // 将跳转URL存储到父窗口的属性中
          if (window.top) {
            try {
              window.top.__PERSONAL_AI_PENDING_NAVIGATION__ = ruleUrl;
              console.log('Stored navigation URL in parent window:', ruleUrl);
            } catch (error) {
              console.error('Failed to store navigation URL in parent window:', error);
            }
          }

          // 刷新当前iframe页面
          window.location.reload();
        }, 2000);
      } else {
        console.warn('Rule ID not found in response, falling back to page refresh');
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      }
    } catch (error) {
      console.error('Error importing rule:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      showErrorMessage(`Import failed: ${errorMessage}`);
    }
  };
  reader.onerror = () => {
    showErrorMessage('Error reading file');
  };
  reader.readAsText(file);
}

// 创建Import按钮
function createImportButton(iframeDoc, projectId) {
  if (iframeDoc.getElementById('import-rule-button')) {
    console.log('Import rule button already exists');
    return;
  }
  console.log('Looking for Create rule button...');

  // 首先尝试通过文本内容查找按钮
  const buttons = iframeDoc.querySelectorAll('button');
  let foundButton = null;
  buttons.forEach(button => {
    const text = button.textContent?.trim();
    console.log('Button text:', text);
    if (text && text.toLowerCase().includes('create rule')) {
      foundButton = button;
      console.log('Found Create rule button by text:', text);
    }
  });

  // if (!foundButton) {
  //   console.warn('Create rule button not found by text, trying CSS selectors...');

  //   // 尝试CSS选择器作为备选方案
  //   const createButton = iframeDoc.querySelector('button[data-testid="create-rule-button"], .create-rule-button, [class*="create"], [class*="Create"]');

  //   if (createButton) {
  //     foundButton = createButton;
  //     console.log('Found Create rule button by CSS selector');
  //   }
  // }

  // if (!foundButton) {
  //   console.warn('Could not find Create rule button, will append to first available container');
  //   const container = iframeDoc.querySelector('div[class*="header"], .page-header, .toolbar, .actions') 
  //                    || iframeDoc.body.firstElementChild;
  //   if (container) {
  //     appendImportButton(container as HTMLElement, projectId, iframeDoc);
  //   }
  //   return;
  // }

  if (!foundButton) {
    console.warn('Could not find Create import rule button!');
    return;
  }
  appendImportButtonNearElement(foundButton, projectId, iframeDoc);
}
function appendImportButtonNearElement(referenceElement, projectId, iframeDoc) {
  const importButton = createImportButtonElement(projectId, iframeDoc);

  // 尝试在Create button旁边插入
  if (referenceElement.parentNode) {
    referenceElement.parentNode.insertBefore(importButton, referenceElement.nextSibling);
  }
}
function _appendImportButton(container, projectId, iframeDoc) {
  const importButton = createImportButtonElement(projectId, iframeDoc);
  container.appendChild(importButton);
}
function createImportButtonElement(projectId, iframeDoc) {
  // 创建隐藏的文件输入元素
  const fileInput = iframeDoc.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = '.json';
  fileInput.style.display = 'none';

  // 创建Import按钮
  const importButton = iframeDoc.createElement('button');
  importButton.textContent = 'Import rule';
  importButton.id = 'import-rule-button';
  importButton.style.cssText = `
    margin-left: 8px;
    padding: 8px 16px;
    background-color: #0052cc;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  `;

  // 悬停效果
  importButton.addEventListener('mouseenter', () => {
    importButton.style.backgroundColor = '#0065ff';
  });
  importButton.addEventListener('mouseleave', () => {
    importButton.style.backgroundColor = '#0052cc';
  });

  // 点击事件
  importButton.addEventListener('click', () => {
    fileInput.click();
  });

  // 文件选择事件
  fileInput.addEventListener('change', e => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileImport(file, projectId);
    }
  });

  // 创建容器
  const container = iframeDoc.createElement('div');
  container.style.display = 'inline-block';
  container.appendChild(fileInput);
  container.appendChild(importButton);
  return container;
}

// 主函数
async function main() {
  if (!isJiraAutomationPage()) {
    return;
  }
  try {
    console.log('Jira Automation Import: Initializing...');
    console.log('Current URL:', window.location.href);
    console.log('Is in iframe:', window !== window.top);

    // 如果在iframe内，直接在当前文档中执行
    if (window !== window.top) {
      console.log('Running inside iframe, executing directly...');
      const projectId = getProjectId();
      if (!projectId) {
        console.warn('Project ID not found');
        return;
      }
      console.log('Project ID:', projectId);

      // 等待页面内容加载
      setTimeout(async () => {
        createImportButton(document, projectId);
        console.log('Import button created in iframe');

        // 同时初始化 Schedule 按钮（异步）
        await initScheduleButtons(document, projectId);
        console.log('Schedule buttons initialization completed in iframe');
      }, 2000);
    } else {
      // 如果在主页面，等待iframe加载
      console.log('Running in main page, waiting for iframe...');
      const ownerId = await getCurrentOwnerId();
      console.log('OwnerId:', ownerId);
      const projectId = getProjectId();
      if (!projectId) {
        console.warn('Project ID not found');
        return;
      }
      console.log('Project ID:', projectId);

      // 等待iframe加载完成
      const iframeDoc = await waitForIframe();
      console.log('Iframe loaded successfully');

      // 等待页面内容加载
      setTimeout(async () => {
        createImportButton(iframeDoc, projectId);
        console.log('Import button created in main page');

        // 同时初始化 Schedule 按钮（异步）
        await initScheduleButtons(iframeDoc, projectId);
        console.log('Schedule buttons initialization completed in main page');
      }, 2000);
    }
  } catch (error) {
    console.error('Error initializing Jira Automation Import:', error);
  }
}

// 页面加载时执行
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', main);
} else {
  main();
}

// 处理SPA导航
let currentUrl = location.href;
const observer = new MutationObserver(() => {
  if (currentUrl !== location.href) {
    currentUrl = location.href;
    if (isJiraAutomationPage()) {
      setTimeout(main, 1000);
    }
  }
});
observer.observe(document, {
  subtree: true,
  childList: true
});

// =====================================================
// Add to Scheduled Messages 功能
// =====================================================

// 存储已添加按钮的规则 ID，避免重复添加
const addedScheduleButtons = new Set();

// 存储已被 Personal AI 管理的规则 ID（预加载）
const managedRuleIds = new Set();

// 规则信息缓存

/**
 * 获取项目的所有规则（直接调用 Jira API）
 */
async function getAllProjectRules(projectId) {
  try {
    // 使用统一的认证方法
    const headers = await createJiraHeaders();
    const response = await fetch(`/rest/cb-automation/latest/project/${projectId}/rule`, {
      method: 'GET',
      headers,
      credentials: 'include'
    });
    if (!response.ok) {
      console.error('获取规则列表失败:', response.status);
      return [];
    }
    return await response.json();
  } catch (error) {
    console.error('获取规则列表失败:', error);
    return [];
  }
}

/**
 * 预加载已被 Personal AI 管理的规则 ID
 * 通过 Jira API 获取所有规则，然后批量检查哪些已在 Scheduled Messages 中
 */
async function preloadManagedRules(projectId, projectKey) {
  console.log('[Personal AI] 预加载已被管理的规则...');

  // 1. 获取项目的所有规则
  const rules = await getAllProjectRules(projectId);
  console.log(`[Personal AI] 获取到 ${rules.length} 个规则`);
  if (rules.length === 0) {
    return;
  }

  // 2. 为每个规则构建 Automation_Link URL
  const automationLinks = rules.map(rule => {
    const ruleId = String(rule.id);
    return `${window.location.origin}/secure/AutomationProjectAdminAction!default.jspa?projectKey=${projectKey}#/rule/${ruleId}`;
  });

  // 3. 批量检查哪些规则已被管理
  const existsMap = await batchCheckAutomationLinksExist(automationLinks);

  // 4. 存储已被管理的规则 ID
  managedRuleIds.clear();
  rules.forEach((rule, index) => {
    const ruleUrl = automationLinks[index];
    if (existsMap.get(ruleUrl)) {
      managedRuleIds.add(String(rule.id));
    }
  });
  console.log(`[Personal AI] 已被管理的规则 ID: [${Array.from(managedRuleIds).join(', ')}]`);
}

/**
 * 获取规则详情（通过 background script）
 */
async function getRuleDetails(ruleId, projectId) {
  try {
    const rules = await getAllProjectRules(projectId);
    const rule = rules.find(r => String(r.id) === String(ruleId));
    if (rule) {
      return {
        id: String(rule.id),
        name: rule.name,
        trigger: rule.trigger,
        state: rule.state
      };
    }
    return null;
  } catch (error) {
    console.error('获取规则详情失败:', error);
    return null;
  }
}

/**
 * 获取规则的 Audit Log
 */
async function getRuleAuditLog(ruleId, projectId) {
  try {
    // 使用正确的 API 路径：/rest/cb-automation/latest/audit/{projectId}?limit=50&ruleId={ruleId}&offset=0
    // 使用统一的认证方法
    const headers = await createJiraHeaders();
    const response = await fetch(`/rest/cb-automation/latest/audit/${projectId}?limit=50&ruleId=${ruleId}&offset=0`, {
      method: 'GET',
      headers,
      credentials: 'include'
    });
    if (!response.ok) {
      console.warn('获取 Audit Log 失败:', response.status, response.statusText);
      return [];
    }
    const data = await response.json();
    return data.items || data || [];
  } catch (error) {
    console.error('获取 Audit Log 失败:', error);
    return [];
  }
}

// 以下函数已移至 scheduleUtils.ts：
// - parseCronExpression
// - parseDaysOfWeek
// - getNextScheduleDate

/**
 * 创建 "Add to Scheduled Messages" 按钮
 * @param isManaged - 是否已被 Personal AI 管理（true = 红色常亮，false = 灰色悬停显示）
 */
function createScheduleButton(ruleId, projectId, doc) {
  let isManaged = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;
  const button = doc.createElement('button');
  button.className = 'personal-ai-schedule-btn';
  button.setAttribute('data-rule-id', ruleId);

  // 使用同一个 icon，通过 CSS filter 实现灰色效果
  const iconUrl = chrome.runtime.getURL('icons/icon32.png');

  // 根据管理状态设置不同的样式和提示
  if (isManaged) {
    // 已管理：红色常亮
    button.title = 'Already managed by Personal AI';
    button.style.cssText = `
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 20px;
      height: 20px;
      margin-left: 8px;
      border: none;
      border-radius: 4px;
      background-color: transparent;
      background-image: url('${iconUrl}');
      background-size: 16px 16px;
      background-position: center;
      background-repeat: no-repeat;
      cursor: pointer;
      opacity: 1;
      filter: none;
      transition: opacity 0.2s ease, transform 0.2s ease;
      vertical-align: middle;
    `;

    // 红色常亮 icon 悬停时放大
    button.addEventListener('mouseenter', () => {
      button.style.transform = 'scale(1.2)';
    });
    button.addEventListener('mouseleave', () => {
      button.style.transform = 'scale(1)';
    });

    // 点击红色常亮 icon 时提示已存在
    button.addEventListener('click', e => {
      e.preventDefault();
      e.stopPropagation();
      showErrorMessage('此规则已在 Scheduled Messages 中管理');
    });
  } else {
    // 未管理：灰色悬停显示
    button.title = 'Add to Scheduled Messages';
    button.style.cssText = `
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 20px;
      height: 20px;
      margin-left: 8px;
      border: none;
      border-radius: 4px;
      background-color: transparent;
      background-image: url('${iconUrl}');
      background-size: 16px 16px;
      background-position: center;
      background-repeat: no-repeat;
      cursor: pointer;
      opacity: 0;
      filter: grayscale(100%) brightness(1.2);
      transition: opacity 0.2s ease, filter 0.2s ease, transform 0.2s ease;
      vertical-align: middle;
    `;

    // 灰色 icon 悬停时显示并变为红色+放大
    button.addEventListener('mouseenter', () => {
      button.style.opacity = '1';
      button.style.filter = 'none';
      button.style.transform = 'scale(1.2)';
    });
    button.addEventListener('mouseleave', () => {
      button.style.opacity = '0';
      button.style.filter = 'grayscale(100%) brightness(1.2)';
      button.style.transform = 'scale(1)';
    });

    // 点击灰色 icon 时执行添加操作
    button.addEventListener('click', async e => {
      e.preventDefault();
      e.stopPropagation();
      await handleAddToScheduledMessages(ruleId, projectId, doc);
    });
  }
  return button;
}

/**
 * 更新按钮状态为已管理状态（红色常亮）
 */
function updateButtonToManagedState(button, _doc) {
  button.title = 'Already managed by Personal AI';
  button.style.opacity = '1';
  button.style.transform = 'scale(1)';
  button.style.filter = 'none';
  button.style.transition = 'opacity 0.2s ease, transform 0.2s ease';

  // 移除所有旧的事件监听器（通过克隆节点）
  const newButton = button.cloneNode(true);
  button.parentNode?.replaceChild(newButton, button);

  // 添加新的事件监听器
  newButton.addEventListener('mouseenter', () => {
    newButton.style.transform = 'scale(1.2)';
  });
  newButton.addEventListener('mouseleave', () => {
    newButton.style.transform = 'scale(1)';
  });
  newButton.addEventListener('click', e => {
    e.preventDefault();
    e.stopPropagation();
    showErrorMessage('此规则已在 Scheduled Messages 中管理');
  });
}

/**
 * 格式化星期显示（用于弹窗展示）
 * @param daysOfWeek Jira格式的星期数组 (1=周日, 2=周一...7=周六)
 */
// formatDaysOfWeekDisplay 已移至 scheduleUtils.ts

/**
 * 显示导入对话框（带 AI 总结）
 */
function showImportDialog(ruleInfo, scheduleConfig, projectId, doc) {
  return new Promise(resolve => {
    // 创建遮罩
    const overlay = doc.createElement('div');
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(0, 0, 0, 0.5);
      z-index: 10000;
      display: flex;
      align-items: center;
      justify-content: center;
    `;

    // 创建对话框
    const dialog = doc.createElement('div');
    dialog.style.cssText = `
      background: white;
      border-radius: 8px;
      padding: 24px;
      max-width: 600px;
      width: 90%;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    `;
    const projectKey = getProjectKey();
    // ruleUrl 用于可能的未来功能扩展
    const _ruleUrl = `${window.location.origin}/jira/software/c/projects/${projectKey}/automation#/rule/${ruleInfo.id}`;

    // 根据配置显示不同内容
    let scheduleInfo = '';
    let showDateInput = false;
    let warningMessage = '';
    if (scheduleConfig) {
      // 格式化重复周期显示
      const formatRepeatCycle = () => {
        const daysDisplay = formatDaysOfWeekDisplay(scheduleConfig.daysOfWeek);
        if (daysDisplay) {
          return `${daysDisplay} ${scheduleConfig.scheduleTime || ''}`;
        }
        const unitText = scheduleConfig.repeatUnit === 'Day' ? '天' : scheduleConfig.repeatUnit === 'Week' ? '周' : '月';
        return `每 ${scheduleConfig.repeatEvery} ${unitText} ${scheduleConfig.scheduleTime || ''}`;
      };

      // 情况一: scheduled + nosearch - 完整导入，需要转换为 webhook
      if (scheduleConfig.needsWebhookConversion && scheduleConfig.scheduleDate) {
        scheduleInfo = `
          <p><strong>执行时间:</strong> ${scheduleConfig.scheduleTime || '未指定'}</p>
          <p><strong>重复周期:</strong> ${formatRepeatCycle()}</p>
        `;
        if (!scheduleConfig.scheduleDate) {
          showDateInput = true;
        }
        warningMessage = '✅ 此规则可以在[定时消息管理]中管理 schedule';
      }
      // 情况二: scheduled + nosearch (FIXED模式) - 需要手动指定日期
      else if (scheduleConfig.needsWebhookConversion && !scheduleConfig.scheduleDate) {
        scheduleInfo = `
          <p><strong>触发模式:</strong> FIXED 模式（需要手动指定开始日期）</p>
          <p><strong>重复周期:</strong> ${formatRepeatCycle()}</p>
        `;
        showDateInput = true;
        warningMessage = '✅ 此规则可以在[定时消息管理]中管理 schedule';
      }
      // 情况三: scheduled + jql - 仅展示，不可编辑
      else if (scheduleConfig.executionMode === 'jql' && scheduleConfig.scheduleDate) {
        scheduleInfo = `
          <p><strong>执行时间:</strong> ${scheduleConfig.scheduleTime || '未指定'}</p>
          <p><strong>重复周期:</strong> ${formatRepeatCycle()}</p>
          <p><strong>执行模式:</strong> JQL 查询模式（仅作为引用记录）</p>
        `;
        warningMessage = 'ℹ️ 该规则将以 JQL 模式执行，添加到 Scheduled Messages 后仅可查看和跳转';
      }
      // 其他情况: 仅添加引用
      else {
        scheduleInfo = `
          <p><strong>规则类型:</strong> ${scheduleConfig.executionMode || '其他'} 模式</p>
          <p>此规则将仅作为引用添加，不会导入调度配置</p>
        `;
        warningMessage = 'ℹ️ 仅添加规则链接作为引用，不会修改原规则';
      }
    }
    dialog.innerHTML = `
      <h3 style="margin: 0 0 16px; font-size: 18px; color: #172B4D;">Add to Scheduled Messages</h3>
      <div style="margin-bottom: 16px; padding: 12px; background: #F4F5F7; border-radius: 4px;">
        <p style="margin: 0 0 8px;"><strong>规则名称:</strong> ${ruleInfo.name}</p>
        ${scheduleInfo}
      </div>
      <div id="ai-summary-container" style="margin-bottom: 16px; padding: 12px; background: #E3F2FD; border-radius: 4px; border-left: 3px solid #2196F3;">
        <p style="margin: 0 0 4px; font-weight: 500; color: #1976D2;">🤖 AI 规则总结:</p>
        <p id="ai-summary-text" style="margin: 0; font-size: 13px; color: #424242; font-style: italic;">
          正在分析规则内容...
        </p>
      </div>
      ${showDateInput ? `
        <div style="margin-bottom: 16px;">
          <label style="display: block; margin-bottom: 4px; font-weight: 500;">开始日期:</label>
          <input type="date" id="schedule-date-input" 
            value="${scheduleConfig.scheduleDate || new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0]}"
            style="width: 100%; padding: 8px; border: 1px solid #DFE1E6; border-radius: 4px; box-sizing: border-box;">
        </div>
      ` : ''}
      <div style="margin-bottom: 16px; padding: 12px; background: #FFFAE6; border-radius: 4px; border-left: 3px solid #FFAB00;">
        <p style="margin: 0; font-size: 13px; color: #172B4D;">
          ${warningMessage}
        </p>
      </div>
      <div style="display: flex; gap: 8px; justify-content: flex-end;">
        <button id="cancel-btn" style="padding: 8px 16px; border: 1px solid #DFE1E6; border-radius: 4px; background: white; cursor: pointer;">取消</button>
        <button id="confirm-btn" style="padding: 8px 16px; border: none; border-radius: 4px; background: #0052cc; color: white; cursor: pointer;">确认添加</button>
      </div>
    `;
    overlay.appendChild(dialog);
    doc.body.appendChild(overlay);

    // 异步获取 AI 总结
    let ruleSummary = `关联的 Jira Automation 规则: ${ruleInfo.name}`;
    const summaryElement = dialog.querySelector('#ai-summary-text');
    (async () => {
      try {
        ruleSummary = await summarizeRuleWithLLM(ruleInfo);
        if (summaryElement) {
          summaryElement.textContent = ruleSummary;
          summaryElement.style.fontStyle = 'normal';
        }
      } catch (error) {
        console.error('AI 总结失败:', error);
        if (summaryElement) {
          summaryElement.textContent = `关联的 Jira Automation 规则: ${ruleInfo.name}`;
          summaryElement.style.fontStyle = 'normal';
        }
      }
    })();

    // 事件处理
    const cancelBtn = dialog.querySelector('#cancel-btn');
    const confirmBtn = dialog.querySelector('#confirm-btn');
    const dateInput = dialog.querySelector('#schedule-date-input');
    cancelBtn.addEventListener('click', () => {
      doc.body.removeChild(overlay);
      resolve({
        confirmed: false,
        scheduleDate: undefined,
        ruleSummary
      });
    });
    confirmBtn.addEventListener('click', () => {
      const scheduleDate = dateInput ? dateInput.value : scheduleConfig?.scheduleDate;
      doc.body.removeChild(overlay);
      resolve({
        confirmed: true,
        scheduleDate,
        ruleSummary
      });
    });
    overlay.addEventListener('click', e => {
      if (e.target === overlay) {
        doc.body.removeChild(overlay);
        resolve({
          confirmed: false,
          scheduleDate: undefined,
          ruleSummary
        });
      }
    });
  });
}

/**
 * 检查 Automation_Link 是否已存在于 Scheduled Messages 中
 */
async function checkAutomationLinkExists(automationLink) {
  try {
    const result = await chrome.runtime.sendMessage({
      type: 'CHECK_AUTOMATION_LINK_EXISTS',
      data: {
        automationLink
      }
    });
    return result?.exists || false;
  } catch (error) {
    console.error('检查 Automation_Link 是否存在失败:', error);
    return false;
  }
}

/**
 * 批量检查多个 Automation_Link 是否已存在于 Scheduled Messages 中
 */
async function batchCheckAutomationLinksExist(automationLinks) {
  try {
    const result = await chrome.runtime.sendMessage({
      type: 'BATCH_CHECK_AUTOMATION_LINKS_EXIST',
      data: {
        automationLinks
      }
    });

    // 将结果转换为 Map
    const resultMap = new Map();
    if (result?.results) {
      Object.entries(result.results).forEach(_ref => {
        let [link, exists] = _ref;
        resultMap.set(link, exists);
      });
    }
    return resultMap;
  } catch (error) {
    console.error('批量检查 Automation_Link 失败:', error);
    return new Map();
  }
}

/**
 * 使用 LLM 总结 Jira Rule 的功能
 * 通过 background script 调用 LLM（content script 无法直接导入模块）
 */
async function summarizeRuleWithLLM(ruleInfo) {
  try {
    // 构建规则描述
    const triggerType = ruleInfo.trigger?.type || '未知';
    const triggerValue = JSON.stringify(ruleInfo.trigger?.value || {}, null, 2);
    const prompt = `请用一句简洁的中文描述以下 Jira Automation 规则的功能：

规则名称：${ruleInfo.name}
触发器类型：${triggerType}
触发器配置：${triggerValue}

要求：用 20-50 字描述这个规则的主要功能，不要包含技术细节。`;

    // 通过 background script 调用 LLM
    const result = await chrome.runtime.sendMessage({
      type: 'CALL_LLM_SUMMARIZE',
      data: {
        prompt
      }
    });
    if (result?.success && result.summary) {
      return result.summary.trim();
    }

    // 如果 LLM 调用失败，返回默认描述
    return `关联的 Jira Automation 规则: ${ruleInfo.name}`;
  } catch (error) {
    console.error('LLM 总结规则失败:', error);
    return `关联的 Jira Automation 规则: ${ruleInfo.name}`;
  }
}

/**
 * 处理添加到 Scheduled Messages
 */
async function handleAddToScheduledMessages(ruleId, projectId, doc) {
  try {
    showLoadingMessage('正在读取规则信息...', doc);

    // 获取规则详情
    const ruleInfo = await getRuleDetails(ruleId, projectId);
    if (!ruleInfo) {
      showErrorMessage('无法获取规则信息');
      return;
    }

    // 构建 Automation_Link
    const projectKey = getProjectKey();
    const ruleUrl = `${window.location.origin}/secure/AutomationProjectAdminAction!default.jspa?projectKey=${projectKey}#/rule/${ruleId}`;

    // 检查是否已存在
    showLoadingMessage('正在检查是否已添加...', doc);
    const alreadyExists = await checkAutomationLinkExists(ruleUrl);
    if (alreadyExists) {
      hideLoadingMessage(doc);
      showErrorMessage('已经添加过了，你可以在定时消息管理界面查看！');
      return;
    }
    hideLoadingMessage(doc);

    // 分析 trigger 类型
    const trigger = ruleInfo.trigger;
    const isScheduledTrigger = trigger?.type === 'jira.jql.scheduled';
    const executionMode = trigger?.value?.executionMode;
    const schedule = trigger?.value?.schedule;
    let scheduleConfig = null;
    if (isScheduledTrigger && executionMode === 'nosearch') {
      // 情况一：scheduled + nosearch - 完整导入，需要转换为 webhook
      if (schedule?.method === 'CRON') {
        // Cron 模式 - 可以完整解析
        const cronConfig = parseCronExpression(schedule.cronExpression);
        if (cronConfig) {
          const [hours, minutes] = cronConfig.time.split(':').map(Number);
          scheduleConfig = {
            scheduleDate: getNextScheduleDate(hours, minutes, cronConfig.repeatUnit, cronConfig.daysOfWeek),
            scheduleTime: cronConfig.time,
            repeatEvery: cronConfig.repeatEvery,
            repeatUnit: cronConfig.repeatUnit,
            daysOfWeek: cronConfig.daysOfWeek,
            // 传递解析的星期配置
            executionMode: 'nosearch',
            needsWebhookConversion: true
          };
        }
      } else if (schedule?.method === 'FIXED') {
        // FIXED 模式 - 需要从 audit log 获取日期或让用户输入
        showLoadingMessage('正在获取执行历史...', doc);
        const auditLogs = await getRuleAuditLog(ruleId, projectId);
        hideLoadingMessage(doc);
        const successLog = auditLogs.find(log => log.category === 'SUCCESS');
        let scheduleDate;
        if (successLog && successLog.created) {
          const date = new Date(successLog.created);
          scheduleDate = date.toISOString().split('T')[0];
        }

        // 使用共享的 FIXED 配置解析函数
        const fixedConfig = parseFixedRateConfig(schedule);
        scheduleConfig = {
          scheduleDate,
          repeatEvery: fixedConfig.repeatEvery,
          repeatUnit: fixedConfig.repeatUnit,
          executionMode: 'nosearch',
          needsWebhookConversion: true
        };
      }
    } else if (isScheduledTrigger && executionMode === 'jql') {
      // 情况二：scheduled + jql - 仅展示，读取日期和周期到 sheet
      if (schedule?.method === 'CRON') {
        const cronConfig = parseCronExpression(schedule.cronExpression);
        if (cronConfig) {
          const [hours, minutes] = cronConfig.time.split(':').map(Number);
          scheduleConfig = {
            scheduleDate: getNextScheduleDate(hours, minutes, cronConfig.repeatUnit, cronConfig.daysOfWeek),
            scheduleTime: cronConfig.time,
            repeatEvery: cronConfig.repeatEvery,
            repeatUnit: cronConfig.repeatUnit,
            daysOfWeek: cronConfig.daysOfWeek,
            // 传递解析的星期配置
            executionMode: 'jql',
            needsWebhookConversion: false
          };
        }
      } else if (schedule?.method === 'FIXED') {
        // FIXED 模式
        showLoadingMessage('正在获取执行历史...', doc);
        const auditLogs = await getRuleAuditLog(ruleId, projectId);
        hideLoadingMessage(doc);
        const successLog = auditLogs.find(log => log.state === 'COMPLETED' || log.state === 'SUCCESS');
        let scheduleDate;
        if (successLog && successLog.created) {
          const date = new Date(successLog.created);
          scheduleDate = date.toISOString().split('T')[0];
        }

        // 使用共享的 FIXED 配置解析函数
        const fixedConfig = parseFixedRateConfig(schedule);
        scheduleConfig = {
          scheduleDate,
          repeatEvery: fixedConfig.repeatEvery,
          repeatUnit: fixedConfig.repeatUnit,
          executionMode: 'jql',
          needsWebhookConversion: false
        };
      }
    } else {
      // 情况三：其他类型 - 仅添加引用
      scheduleConfig = {
        executionMode: executionMode || 'other',
        needsWebhookConversion: false
      };
    }

    // 显示确认对话框（已包含 AI 总结）
    const dialogResult = await showImportDialog(ruleInfo, scheduleConfig, projectId, doc);
    if (!dialogResult.confirmed) {
      return;
    }

    // 使用弹窗中已生成的 AI 总结
    const ruleSummary = dialogResult.ruleSummary;
    showLoadingMessage('正在添加到 Scheduled Messages...', doc);

    // 准备消息数据 - 注意 ruleUrl 已在前面定义
    const messageData = {
      Topic: `${ruleInfo.name}`,
      Content: ruleSummary,
      Push_Method: 'JiraAutomation',
      Target_Type: 'api',
      // 根据 Jira Rule 的状态设置 Status：ENABLED -> Active, DISABLED -> Paused
      Status: ruleInfo.state === 'ENABLED' ? 'Active' : 'Paused',
      Automation_Link: ruleUrl,
      // 添加 Category，使用项目 key
      Category: projectKey
    };
    scheduleConfig.scheduleDate = dialogResult.scheduleDate || scheduleConfig.scheduleDate;
    if (scheduleConfig?.needsWebhookConversion && scheduleConfig.scheduleDate) {
      // 情况一：scheduled + nosearch - 完整导入调度信息，但不立即转换为 webhook
      // webhook 转换延迟到用户在 ScheduledMessagesManager 中确认托管时再执行
      messageData.Schedule_Date = scheduleConfig.scheduleDate;
      messageData.Schedule_Time = scheduleConfig.scheduleTime;
      messageData.Repeat_Every = scheduleConfig.repeatEvery;
      messageData.Repeat_Unit = scheduleConfig.repeatUnit;
      // 如果有多星期配置，转换 Jira 格式 (1-7) 到 JS 格式 (0-6) 并保存
      if (scheduleConfig.daysOfWeek && scheduleConfig.daysOfWeek.length > 0) {
        const jsDays = jiraDaysToJsDays(scheduleConfig.daysOfWeek);
        messageData.Repeat_Days = jsDays.join(',');
        console.log('[Personal AI] 保存多星期配置:', {
          jiraDays: scheduleConfig.daysOfWeek,
          jsDays,
          Repeat_Days: messageData.Repeat_Days
        });
      }
      // 不设置 AI_Endpoint，留待用户在管理界面确认后再转换
      // 用户可以在 ScheduledMessagesManager 中点击编辑按钮来激活 Personal AI 托管
    } else if (scheduleConfig?.executionMode === 'jql') {
      // 情况二：scheduled + jql - 读取日期和周期到 sheet，作为展示使用
      messageData.Schedule_Date = scheduleConfig.scheduleDate;
      messageData.Schedule_Time = scheduleConfig.scheduleTime;
      messageData.Repeat_Every = scheduleConfig.repeatEvery;
      messageData.Repeat_Unit = scheduleConfig.repeatUnit;
      // 如果有多星期配置，转换并保存
      if (scheduleConfig.daysOfWeek && scheduleConfig.daysOfWeek.length > 0) {
        const jsDays = jiraDaysToJsDays(scheduleConfig.daysOfWeek);
        messageData.Repeat_Days = jsDays.join(',');
      }
      // 不设置 AI_Endpoint，表示仅作为引用
      messageData.Content = `Linked to Jira Automation Rule (JQL Mode, View Only): ${ruleInfo.name}`;
    }
    // 情况三：其他类型 - 仅添加引用，不设置调度信息

    // 发送到 background script 添加消息
    console.log('[Personal AI] 发送 ADD_SCHEDULED_MESSAGE 消息:', messageData);
    let result;
    try {
      result = await chrome.runtime.sendMessage({
        type: 'ADD_SCHEDULED_MESSAGE',
        data: messageData
      });
      console.log('[Personal AI] ADD_SCHEDULED_MESSAGE 响应:', result);
    } catch (sendError) {
      console.error('[Personal AI] 发送消息失败:', sendError);
      hideLoadingMessage(doc);
      showErrorMessage(`发送消息失败: ${sendError instanceof Error ? sendError.message : '未知错误'}`);
      return;
    }
    hideLoadingMessage(doc);
    if (result && result.success) {
      showSuccessMessage(`已添加到 Scheduled Messages: ${ruleInfo.name}`);

      // 将规则 ID 加入已管理列表
      managedRuleIds.add(ruleId);
      console.log(`[Personal AI] 规则 ${ruleId} 已加入 managedRuleIds`);

      // 立即更新当前按钮为已管理状态（红色常亮）
      const currentButton = doc.querySelector(`.personal-ai-schedule-btn[data-rule-id="${ruleId}"]`);
      if (currentButton) {
        console.log('[Personal AI] 更新按钮为已管理状态（红色常亮）');
        updateButtonToManagedState(currentButton, doc);
      }
    } else {
      const errorMsg = result?.error || (result === undefined ? '未收到响应（可能 background script 未正确处理）' : '未知错误');
      console.error('[Personal AI] 添加失败:', errorMsg, result);
      showErrorMessage(`添加失败: ${errorMsg}`);
    }
  } catch (error) {
    hideLoadingMessage(doc);
    console.error('添加到 Scheduled Messages 失败:', error);
    showErrorMessage(`添加失败: ${error instanceof Error ? error.message : '未知错误'}`);
  }
}

/**
 * 显示加载消息
 */
function showLoadingMessage(message, doc) {
  hideLoadingMessage(doc);
  const loadingDiv = doc.createElement('div');
  loadingDiv.id = 'personal-ai-loading';
  loadingDiv.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #0052cc;
    color: white;
    padding: 12px 16px;
    border-radius: 4px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    z-index: 10001;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    display: flex;
    align-items: center;
    gap: 8px;
  `;
  loadingDiv.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 16 16" style="animation: spin 1s linear infinite;">
      <circle cx="8" cy="8" r="6" fill="none" stroke="white" stroke-width="2" stroke-dasharray="32" stroke-dashoffset="8"/>
    </svg>
    <span>${message}</span>
  `;

  // 添加旋转动画
  const style = doc.createElement('style');
  style.textContent = `@keyframes spin { to { transform: rotate(360deg); } }`;
  doc.head.appendChild(style);
  doc.body.appendChild(loadingDiv);
}

/**
 * 隐藏加载消息
 */
function hideLoadingMessage(doc) {
  const loadingDiv = doc.getElementById('personal-ai-loading');
  if (loadingDiv) {
    loadingDiv.remove();
  }
}

/**
 * 为规则列表添加悬停按钮
 * 
 * DOM 结构参考:
 * <tr class="css-1wodie7">
 *   <td class="css-1edgzzu">
 *     <div>
 *       <div draggable="true">
 *         <div class="sc-hzNEM cMGECf">
 *           <div class="sc-LKuAh dxEdMv">...</div>
 *           <span role="presentation">
 *             <span style="display: inline-flex; ...">
 *               <a href="...#/rule/1685">[Esone] AI notify...</a>
 *               <span style="margin-left: 5px;"></span>  <!-- 插入点 -->
 *             </span>
 *           </span>
 *         </div>
 *       </div>
 *     </div>
 *   </td>
 *   ...
 * </tr>
 */
function addScheduleButtonsToRules(doc, projectId) {
  // 查找所有规则链接
  const allLinks = doc.querySelectorAll('a[href*="#/rule/"]');
  allLinks.forEach(link => {
    const href = link.getAttribute('href');
    const match = href?.match(/#\/rule\/(\d+)/);
    if (!match) return;
    const ruleId = match[1];

    // 检查该链接是否已经有按钮了（通过查找父元素中是否已有按钮）
    const linkParent = link.parentElement;
    if (linkParent) {
      const existingButton = linkParent.querySelector('.personal-ai-schedule-btn');
      if (existingButton) {
        // 检查按钮的 data-rule-id 是否与当前链接的规则 ID 匹配
        // 如果不匹配，说明 Jira SPA 翻页时复用了 DOM 元素，需要移除旧按钮重新创建
        const buttonRuleId = existingButton.getAttribute('data-rule-id');
        if (buttonRuleId === ruleId) {
          // ID 匹配，保持现有按钮
          return;
        } else {
          // ID 不匹配，移除旧按钮（包括其容器 div）
          const buttonContainer = existingButton.parentElement;
          if (buttonContainer && buttonContainer.style.display === 'inline-block') {
            buttonContainer.remove();
          } else {
            existingButton.remove();
          }
        }
      }
    }

    // 找到规则行 <tr>
    const ruleRow = link.closest('tr');
    if (!ruleRow) {
      return;
    }

    // 根据预加载的 managedRuleIds 判断是否已被管理
    const isManaged = managedRuleIds.has(ruleId);

    // 创建按钮（根据管理状态决定样式）
    const button = createScheduleButton(ruleId, projectId, doc, isManaged);

    // 在链接后面的 span 中插入按钮
    if (linkParent) {
      const spacerSpan = linkParent.querySelector('span[style*="margin-left"]');
      if (spacerSpan) {
        spacerSpan.appendChild(button);
      } else {
        link.insertAdjacentElement('afterend', button);
      }
    }

    // 添加悬停效果 - 监听整个表格行（仅对灰色未管理按钮）
    if (!isManaged) {
      ruleRow.addEventListener('mouseenter', () => {
        if (button.style.opacity === '0') {
          button.style.opacity = '1';
        }
      });
      ruleRow.addEventListener('mouseleave', () => {
        if (button.title === 'Add to Scheduled Messages') {
          button.style.opacity = '0';
        }
      });
    }
    addedScheduleButtons.add(ruleId);
  });
}

/**
 * 检查是否已初始化 Scheduled Messages 配置
 */
async function checkScheduledMessagesInitialized() {
  try {
    const result = await chrome.storage.local.get(['scheduledMessagesConfig']);
    const config = result.scheduledMessagesConfig;
    if (config && config.sheetId) {
      console.log('[Personal AI] Scheduled Messages 已初始化，sheetId:', config.sheetId);
      return true;
    }
    console.log('[Personal AI] Scheduled Messages 未初始化，跳过注入添加按钮');
    return false;
  } catch (error) {
    console.error('[Personal AI] 检查 Scheduled Messages 配置失败:', error);
    return false;
  }
}

/**
 * 初始化 Schedule 按钮功能
 */
async function initScheduleButtons(doc, projectId) {
  // 先检查是否已初始化 Scheduled Messages
  const isInitialized = await checkScheduledMessagesInitialized();
  if (!isInitialized) {
    console.log('[Personal AI] 跳过 Schedule 按钮注入（未初始化 Scheduled Messages）');
    return;
  }

  // 预加载已被管理的规则 ID（通过 Jira API 获取所有规则，批量检查）
  const projectKey = getProjectKey();
  await preloadManagedRules(projectId, projectKey);

  // 初始添加按钮
  addScheduleButtonsToRules(doc, projectId);

  // 监听 DOM 变化，为新加载的规则添加按钮
  const scheduleObserver = new MutationObserver(() => {
    addScheduleButtonsToRules(doc, projectId);
  });
  scheduleObserver.observe(doc.body, {
    childList: true,
    subtree: true
  });
}

// Schedule 按钮初始化已集成到 main() 函数中
// 与 Import button 共享同一个初始化时机，无需额外的独立入口
/******/ })()
;
//# sourceMappingURL=contentScriptJiraAutomation.js.map