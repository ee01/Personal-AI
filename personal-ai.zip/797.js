"use strict";
(self["webpackChunkpersonal_ai"] = self["webpackChunkpersonal_ai"] || []).push([[797],{

/***/ 797:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VERSION: () => (/* binding */ VERSION)
/* harmony export */ });
const VERSION = '4.91.0'; // x-release-please-version
//# sourceMappingURL=version.mjs.map

/***/ })

}]);
//# sourceMappingURL=797.js.map