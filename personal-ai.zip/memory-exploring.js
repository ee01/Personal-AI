/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 6802:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1354);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6314);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `
.skills-grid[data-v-744c8b2e] {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 1rem;
}
.skill-card[data-v-744c8b2e] {
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(148, 163, 184, 0.1);
  border-radius: 0.75rem;
  padding: 1rem;
  transition: all 0.3s ease;
}
.skill-card[data-v-744c8b2e]:hover {
  border-color: rgba(59, 130, 246, 0.3);
  transform: translateY(-2px);
}
.skill-header[data-v-744c8b2e] {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.75rem;
}
.skill-name[data-v-744c8b2e] {
  font-weight: 600;
  font-size: 1.1rem;
  color: #e2e8f0;
}
.skill-level[data-v-744c8b2e] {
  background: rgba(34, 197, 94, 0.2);
  color: #22c55e;
  padding: 0.25rem 0.75rem;
  border-radius: 1rem;
  font-size: 0.75rem;
  font-weight: 500;
}
.skill-progress[data-v-744c8b2e] {
  width: 100%;
  height: 0.5rem;
  background: rgba(148, 163, 184, 0.2);
  border-radius: 0.25rem;
  overflow: hidden;
  margin-bottom: 0.75rem;
}
.skill-progress-bar[data-v-744c8b2e] {
  height: 100%;
  background: linear-gradient(90deg, #60a5fa, #a78bfa);
  transition: width 0.5s ease;
}
.skill-projects[data-v-744c8b2e] {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  align-items: center;
}
.projects-label[data-v-744c8b2e] {
  font-size: 0.75rem;
  color: #94a3b8;
  margin-right: 0.25rem;
}
.skill-project-tag[data-v-744c8b2e] {
  background: rgba(59, 130, 246, 0.2);
  color: #60a5fa;
  padding: 0.125rem 0.375rem;
  border-radius: 0.25rem;
  font-size: 0.625rem;
  font-weight: 500;
}
.person-header[data-v-744c8b2e] {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(148, 163, 184, 0.1);
  border-radius: 1rem;
  padding: 2rem;
  backdrop-filter: blur(10px);
}
.person-avatar[data-v-744c8b2e] {
  width: 4rem;
  height: 4rem;
  border-radius: 1rem;
  background: linear-gradient(135deg, #34d399, #22c55e);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2rem;
  flex-shrink: 0;
}
`, "",{"version":3,"sources":["webpack://./src/modals/components/PersonDetailPage.vue"],"names":[],"mappings":";AA8TA;EACE,aAAa;EACb,4DAA4D;EAC5D,SAAS;AACX;AAEA;EACE,iCAAiC;EACjC,0CAA0C;EAC1C,sBAAsB;EACtB,aAAa;EACb,yBAAyB;AAC3B;AAEA;EACE,qCAAqC;EACrC,2BAA2B;AAC7B;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,sBAAsB;AACxB;AAEA;EACE,gBAAgB;EAChB,iBAAiB;EACjB,cAAc;AAChB;AAEA;EACE,kCAAkC;EAClC,cAAc;EACd,wBAAwB;EACxB,mBAAmB;EACnB,kBAAkB;EAClB,gBAAgB;AAClB;AAEA;EACE,WAAW;EACX,cAAc;EACd,oCAAoC;EACpC,sBAAsB;EACtB,gBAAgB;EAChB,sBAAsB;AACxB;AAEA;EACE,YAAY;EACZ,oDAAoD;EACpD,2BAA2B;AAC7B;AAEA;EACE,aAAa;EACb,eAAe;EACf,YAAY;EACZ,mBAAmB;AACrB;AAEA;EACE,kBAAkB;EAClB,cAAc;EACd,qBAAqB;AACvB;AAEA;EACE,mCAAmC;EACnC,cAAc;EACd,0BAA0B;EAC1B,sBAAsB;EACtB,mBAAmB;EACnB,gBAAgB;AAClB;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,WAAW;EACX,iCAAiC;EACjC,0CAA0C;EAC1C,mBAAmB;EACnB,aAAa;EACb,2BAA2B;AAC7B;AAEA;EACE,WAAW;EACX,YAAY;EACZ,mBAAmB;EACnB,qDAAqD;EACrD,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,eAAe;EACf,cAAc;AAChB","sourcesContent":["<template>\n  <div class=\"person-detail\">\n    <div class=\"detail-header\">\n      <button class=\"back-btn\" @click=\"goBack\">\n        <span>←</span>\n        <span>返回人物列表</span>\n      </button>\n      <div v-if=\"personData\" class=\"person-header\">\n        <div class=\"person-avatar\">👤</div>\n        <div class=\"person-info\">\n          <h2>{{ personData.title }}</h2>\n          <div class=\"person-meta\">\n            <span class=\"meta-item\">🏢 {{ personData.overview?.team || '技术团队' }}</span>\n            <span class=\"meta-item\">🤝 {{ personData.overview?.collaborations || 0 }} 个协作项目</span>\n            <span class=\"meta-item\">💬 {{ personData.overview?.messages || 0 }} 条消息</span>\n            <span class=\"meta-item\">📚 {{ personData.overview?.resources || 0 }} 个资源</span>\n            <span class=\"meta-item\">⏰ 最后联系：1小时前</span>\n          </div>\n        </div>\n        <div class=\"person-actions\">\n          <button class=\"action-btn\">💬 发送消息</button>\n          <button class=\"action-btn\">🤝 查看协作</button>\n        </div>\n      </div>\n    </div>\n\n    <div v-if=\"isLoading\" class=\"loading-container\">\n      <div class=\"loading-spinner\"></div>\n      <span>加载人物详情...</span>\n    </div>\n\n    <div v-else-if=\"personData\" class=\"person-detail-content\">\n      <div class=\"tab-navigation\">\n        <button \n          v-for=\"tab in tabs\" \n          :key=\"tab.key\"\n          :class=\"['tab-btn', { active: activeTab === tab.key }]\"\n          @click=\"activeTab = tab.key\"\n        >\n          {{ tab.label }}\n        </button>\n      </div>\n\n      <!-- 协作项目标签页 -->\n      <div v-if=\"activeTab === 'projects'\" class=\"tab-content active\">\n        <div class=\"section-header\">\n          <h3>🚀 协作项目</h3>\n          <button class=\"add-btn\">+ 添加协作</button>\n        </div>\n        <div class=\"items-grid\">\n          <div v-for=\"project in personData.collaborationProjects\" :key=\"project.id\" class=\"item-card\">\n            <div class=\"item-header\">\n              <div class=\"item-title\">\n                <span>🚀</span>\n                <span>{{ project.name }}</span>\n              </div>\n              <div class=\"item-actions\">\n                <button class=\"item-action\" title=\"移除协作\">❌</button>\n              </div>\n            </div>\n            <div class=\"item-content\">\n              <div style=\"margin-bottom: 0.5rem;\">\n                <span class=\"card-badge\">{{ project.status }}</span>\n                <span class=\"card-badge\" style=\"background: rgba(147, 51, 234, 0.2); color: #a78bfa;\">{{ project.role }}</span>\n              </div>\n              <p>{{ project.description }}</p>\n            </div>\n          </div>\n        </div>\n      </div>\n\n      <!-- 专业技能标签页 -->\n      <div v-if=\"activeTab === 'skills'\" class=\"tab-content active\">\n        <div class=\"section-header\">\n          <h3>🎯 专业技能</h3>\n          <button class=\"add-btn\">+ 添加技能</button>\n        </div>\n        <div class=\"skills-grid\">\n          <div v-for=\"skill in personData.skills\" :key=\"skill.id\" class=\"skill-card\">\n            <div class=\"skill-header\">\n              <div class=\"skill-name\">{{ skill.name }}</div>\n              <div class=\"skill-level\">{{ skill.level }}</div>\n            </div>\n            <div class=\"skill-progress\">\n              <div class=\"skill-progress-bar\" :style=\"{ width: skill.proficiency + '%' }\"></div>\n            </div>\n            <div v-if=\"skill.projects\" class=\"skill-projects\">\n              <span class=\"projects-label\">相关项目：</span>\n              <span v-for=\"(project, index) in skill.projects\" :key=\"index\" class=\"skill-project-tag\">\n                {{ project }}\n              </span>\n            </div>\n          </div>\n        </div>\n      </div>\n\n      <!-- 聊天记录标签页 -->\n      <div v-if=\"activeTab === 'conversations'\" class=\"tab-content active\">\n        <div class=\"section-header\">\n          <h3>💬 聊天记录</h3>\n          <div class=\"search-controls\">\n            <input type=\"text\" class=\"search-input\" placeholder=\"搜索聊天记录...\" v-model=\"convSearchQuery\" />\n            <select class=\"filter-select\" v-model=\"convFilter\">\n              <option value=\"all\">全部群组</option>\n              <option value=\"team\">团队群</option>\n              <option value=\"project\">项目群</option>\n              <option value=\"tech\">技术讨论</option>\n            </select>\n          </div>\n        </div>\n        <div class=\"conversations-list\">\n          <div \n            v-for=\"conv in filteredConversations\" \n            :key=\"conv.id\" \n            class=\"conversation-item\"\n            :class=\"{ expanded: expandedConversations.has(conv.id) }\"\n          >\n            <div class=\"conversation-header\">\n              <div class=\"conversation-meta\">\n                <div class=\"sender-avatar\">{{ conv.sender.charAt(0) }}</div>\n                <div class=\"sender-info\">\n                  <div class=\"sender-name\">{{ conv.sender }}</div>\n                  <div class=\"group-name\">{{ conv.group }}</div>\n                </div>\n              </div>\n              <div class=\"conversation-time\">{{ conv.time }}</div>\n            </div>\n            <div class=\"conversation-summary\" v-html=\"highlightText(conv.summary, convSearchQuery)\"></div>\n            <div \n              class=\"context-indicator\"\n              :class=\"{ expanded: expandedConversations.has(conv.id) }\"\n              @click=\"toggleConversationExpand(conv.id)\"\n            >\n              <span class=\"indicator-text\">\n                {{ expandedConversations.has(conv.id) ? '🔼 收起上下文' : `🔍 查看上下文 (${conv.context?.length || 0} 条相关消息)` }}\n              </span>\n            </div>\n            <div \n              v-if=\"conv.context\" \n              class=\"context-content\"\n              :class=\"{ expanded: expandedConversations.has(conv.id) }\"\n            >\n              <div class=\"context-divider\"></div>\n              <div \n                v-for=\"(contextMsg, index) in conv.context\" \n                :key=\"index\" \n                class=\"context-item\"\n                :class=\"{ 'main-message': contextMsg.isMainMessage }\"\n              >\n                <div class=\"context-header\">\n                  <div class=\"context-sender\">{{ contextMsg.sender }}</div>\n                  <div class=\"context-time\">{{ contextMsg.time }}</div>\n                </div>\n                <div \n                  class=\"context-content-text\"\n                  v-html=\"contextMsg.isMainMessage ? highlightText(contextMsg.content, convSearchQuery) : contextMsg.content\"\n                ></div>\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n\n      <!-- 相关资源标签页 -->\n      <div v-if=\"activeTab === 'resources'\" class=\"tab-content active\">\n        <div class=\"section-header\">\n          <h3>📚 相关资源</h3>\n          <button class=\"add-btn\">+ 添加资源</button>\n        </div>\n        <div class=\"items-grid\">\n          <div v-for=\"resource in personData.recentDataDetails.resources\" :key=\"resource.id\" class=\"item-card\">\n            <div class=\"item-header\">\n              <div class=\"item-title\">\n                <span>📚</span>\n                <span>{{ resource.name }}</span>\n              </div>\n              <div class=\"item-actions\">\n                <button class=\"item-action\" title=\"删除资源\">❌</button>\n              </div>\n            </div>\n            <div class=\"item-content\">\n              <div style=\"margin-bottom: 0.5rem;\">\n                <span class=\"card-badge\">{{ resource.type }}</span>\n              </div>\n              <p><a :href=\"resource.url\" style=\"color: #60a5fa;\">查看资源</a></p>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</template>\n\n<script setup lang=\"ts\">\nimport { ref, computed, watch } from 'vue';\nimport { useRoute, useRouter } from 'vue-router';\nimport { useMemoryStore } from '../memory-store';\n\nconst route = useRoute();\nconst router = useRouter();\nconst store = useMemoryStore();\n\nconst personId = computed(() => route.params.id as string);\nconst personData = computed(() => store.personDetailData);\nconst isLoading = computed(() => store.isLoading);\nconst activeTab = ref('projects');\n\nconst convSearchQuery = ref('');\nconst convFilter = ref('all');\nconst expandedConversations = ref(new Set());\n\nconst tabs = [\n  { key: 'projects', label: '🚀 协作项目' },\n  { key: 'skills', label: '🎯 专业技能' },\n  { key: 'conversations', label: '💬 聊天记录' },\n  { key: 'resources', label: '📚 相关资源' }\n];\n\nconst filteredConversations = computed(() => {\n  let filtered = personData.value?.conversations || [];\n  \n  if (convSearchQuery.value.trim()) {\n    const query = convSearchQuery.value.toLowerCase();\n    filtered = filtered.filter(conv => \n      conv.summary.toLowerCase().includes(query) ||\n      conv.sender.toLowerCase().includes(query) ||\n      conv.group.toLowerCase().includes(query)\n    );\n  }\n  \n  if (convFilter.value !== 'all') {\n    filtered = filtered.filter(conv => {\n      switch (convFilter.value) {\n        case 'team':\n          return conv.group.includes('团队') || conv.group.includes('Team');\n        case 'project':\n          return conv.group.includes('项目') || conv.group.includes('Project');\n        case 'tech':\n          return conv.group.includes('技术') || conv.group.includes('Tech') || conv.group.includes('开发');\n        default:\n          return true;\n      }\n    });\n  }\n  \n  return filtered;\n});\n\nconst goBack = () => {\n  router.push('/entity/Person');\n};\n\nconst toggleConversationExpand = (conversationId: string) => {\n  const newExpanded = new Set(expandedConversations.value);\n  if (newExpanded.has(conversationId)) {\n    newExpanded.delete(conversationId);\n  } else {\n    newExpanded.clear();\n    newExpanded.add(conversationId);\n  }\n  expandedConversations.value = newExpanded;\n};\n\nconst highlightText = (text: string, searchQuery: string) => {\n  if (!searchQuery.trim()) return text;\n  \n  const regex = new RegExp(`(${searchQuery.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&')})`, 'gi');\n  return text.replace(regex, '<mark style=\"background: rgba(251, 191, 36, 0.3); color: #fbbf24; padding: 0.125rem 0.25rem; border-radius: 0.25rem; font-weight: 600;\">$1</mark>');\n};\n\n// 模拟加载人物详情数据\nconst loadPersonDetail = (personId: string) => {\n  store.personDetailData = {\n    id: personId,\n    title: '张三',\n    overview: { team: '技术团队', collaborations: 3, messages: 25, resources: 8 },\n    collaborationProjects: [\n      { id: 'project-1', name: 'Personal-AI', status: '开发中', role: '前端负责人', description: 'Chrome扩展智能助手开发' },\n      { id: 'project-2', name: 'Web Platform', status: '维护中', role: '核心开发', description: '前端平台维护和优化' }\n    ],\n    skills: [\n      { id: 'skill-1', name: 'React', level: '专家', proficiency: 95, projects: ['Personal-AI', 'Web Platform'] },\n      { id: 'skill-2', name: 'TypeScript', level: '高级', proficiency: 88, projects: ['Personal-AI'] },\n      { id: 'skill-3', name: '性能优化', level: '中级', proficiency: 75, projects: ['Web Platform'] }\n    ],\n    conversations: [{\n      id: 'conv-1',\n      sender: '张三',\n      group: '技术讨论组',\n      time: '1小时前',\n      summary: '代码审查反馈：建议优化组件性能',\n      context: [\n        { sender: '李四', content: '这个组件的渲染次数有点多', time: '2小时前' },\n        { sender: '张三', content: '我建议使用useMemo来优化', time: '1小时前', isMainMessage: true }\n      ]\n    }],\n    relatedResources: [\n      { id: 'resource-1', name: 'React 性能优化指南', type: '技术文档', url: '#' },\n      { id: 'resource-2', name: 'TypeScript 最佳实践', type: '教程', url: '#' }\n    ]\n  };\n};\n\nwatch(personId, (newId) => {\n  if (newId) {\n    loadPersonDetail(newId);\n  }\n}, { immediate: true });\n\nwatch(() => route.query, (newQuery) => {\n  if (newQuery.messageId) {\n    activeTab.value = 'conversations';\n    console.log('定位到消息:', newQuery.messageId);\n  }\n});\n</script>\n\n<style scoped>\n.skills-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));\n  gap: 1rem;\n}\n\n.skill-card {\n  background: rgba(15, 23, 42, 0.6);\n  border: 1px solid rgba(148, 163, 184, 0.1);\n  border-radius: 0.75rem;\n  padding: 1rem;\n  transition: all 0.3s ease;\n}\n\n.skill-card:hover {\n  border-color: rgba(59, 130, 246, 0.3);\n  transform: translateY(-2px);\n}\n\n.skill-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 0.75rem;\n}\n\n.skill-name {\n  font-weight: 600;\n  font-size: 1.1rem;\n  color: #e2e8f0;\n}\n\n.skill-level {\n  background: rgba(34, 197, 94, 0.2);\n  color: #22c55e;\n  padding: 0.25rem 0.75rem;\n  border-radius: 1rem;\n  font-size: 0.75rem;\n  font-weight: 500;\n}\n\n.skill-progress {\n  width: 100%;\n  height: 0.5rem;\n  background: rgba(148, 163, 184, 0.2);\n  border-radius: 0.25rem;\n  overflow: hidden;\n  margin-bottom: 0.75rem;\n}\n\n.skill-progress-bar {\n  height: 100%;\n  background: linear-gradient(90deg, #60a5fa, #a78bfa);\n  transition: width 0.5s ease;\n}\n\n.skill-projects {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 0.25rem;\n  align-items: center;\n}\n\n.projects-label {\n  font-size: 0.75rem;\n  color: #94a3b8;\n  margin-right: 0.25rem;\n}\n\n.skill-project-tag {\n  background: rgba(59, 130, 246, 0.2);\n  color: #60a5fa;\n  padding: 0.125rem 0.375rem;\n  border-radius: 0.25rem;\n  font-size: 0.625rem;\n  font-weight: 500;\n}\n\n.person-header {\n  display: flex;\n  align-items: center;\n  gap: 1.5rem;\n  background: rgba(15, 23, 42, 0.6);\n  border: 1px solid rgba(148, 163, 184, 0.1);\n  border-radius: 1rem;\n  padding: 2rem;\n  backdrop-filter: blur(10px);\n}\n\n.person-avatar {\n  width: 4rem;\n  height: 4rem;\n  border-radius: 1rem;\n  background: linear-gradient(135deg, #34d399, #22c55e);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 2rem;\n  flex-shrink: 0;\n}\n</style>\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 6165:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1354);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6314);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `
.search-results-section[data-v-26a7e817] {
  max-width: 1200px;
  margin: 0 auto;
  animation: fadeInUp-26a7e817 0.6s ease-out;
}
.search-header[data-v-26a7e817] {
  text-align: center;
  margin-bottom: 2rem;
  padding: 2rem;
  background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(147, 51, 234, 0.1));
  border: 1px solid rgba(59, 130, 246, 0.2);
  border-radius: 1rem;
  backdrop-filter: blur(10px);
}
.search-header h2[data-v-26a7e817] {
  font-size: 1.75rem;
  font-weight: 600;
  margin-bottom: 0.75rem;
  color: #ffffff;
}
.search-header p[data-v-26a7e817] {
  color: #cbd5e1;
  font-size: 1rem;
}
.results-summary[data-v-26a7e817] {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  flex-wrap: wrap;
  gap: 1rem;
}
.results-count[data-v-26a7e817] {
  color: #94a3b8;
  font-size: 0.875rem;
}
.results-filters[data-v-26a7e817] {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
}
.type-filter[data-v-26a7e817] {
  padding: 0.5rem 1rem;
  background: rgba(59, 130, 246, 0.1);
  border: 1px solid rgba(59, 130, 246, 0.3);
  border-radius: 0.5rem;
  color: #60a5fa;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 0.875rem;
  white-space: nowrap;
}
.type-filter[data-v-26a7e817]:hover {
  background: rgba(59, 130, 246, 0.2);
}
.type-filter.active[data-v-26a7e817] {
  background: rgba(59, 130, 246, 0.3);
  border-color: rgba(59, 130, 246, 0.5);
  color: #93c5fd;
}
.search-results-grid[data-v-26a7e817] {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
  gap: 1rem;
}
.search-result-card[data-v-26a7e817] {
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(148, 163, 184, 0.1);
  border-radius: 0.75rem;
  padding: 1.5rem;
  transition: all 0.3s ease;
  cursor: pointer;
  backdrop-filter: blur(10px);
}
.search-result-card[data-v-26a7e817]:hover {
  border-color: rgba(59, 130, 246, 0.3);
  transform: translateY(-2px);
  box-shadow: 0 8px 32px rgba(59, 130, 246, 0.1);
}
.result-header[data-v-26a7e817] {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
}
.result-type-indicator[data-v-26a7e817] {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.25rem 0.75rem;
  background: rgba(59, 130, 246, 0.2);
  border-radius: 1rem;
}
.type-icon[data-v-26a7e817] {
  font-size: 1rem;
}
.type-name[data-v-26a7e817] {
  font-size: 0.75rem;
  font-weight: 500;
  color: #60a5fa;
}
.relevance-score[data-v-26a7e817] {
  font-size: 0.75rem;
  color: #22c55e;
  background: rgba(34, 197, 94, 0.2);
  padding: 0.25rem 0.5rem;
  border-radius: 0.375rem;
}
.result-content[data-v-26a7e817] {
  margin-bottom: 1rem;
}
.result-title[data-v-26a7e817] {
  font-size: 1.25rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: #e2e8f0;
}
.result-description[data-v-26a7e817] {
  color: #cbd5e1;
  font-size: 0.875rem;
  line-height: 1.5;
  margin-bottom: 0.75rem;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.result-tags[data-v-26a7e817] {
  display: flex;
  gap: 0.375rem;
  flex-wrap: wrap;
}
.result-tag[data-v-26a7e817] {
  padding: 0.25rem 0.5rem;
  background: rgba(147, 51, 234, 0.2);
  color: #a78bfa;
  border-radius: 0.375rem;
  font-size: 0.75rem;
  font-weight: 500;
}
.result-tag.more-tags[data-v-26a7e817] {
  background: rgba(148, 163, 184, 0.2);
  color: #94a3b8;
}
.result-actions[data-v-26a7e817] {
  display: flex;
  justify-content: flex-end;
}
.action-btn[data-v-26a7e817] {
  padding: 0.5rem 1rem;
  background: rgba(59, 130, 246, 0.1);
  border: 1px solid rgba(59, 130, 246, 0.3);
  border-radius: 0.5rem;
  color: #60a5fa;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 0.875rem;
  font-weight: 500;
}
.action-btn.primary[data-v-26a7e817] {
  background: rgba(59, 130, 246, 0.2);
  border-color: rgba(59, 130, 246, 0.4);
}
.action-btn[data-v-26a7e817]:hover {
  background: rgba(59, 130, 246, 0.3);
  border-color: rgba(59, 130, 246, 0.5);
}
.empty-search-state[data-v-26a7e817] {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 4rem 2rem;
  color: #94a3b8;
  text-align: center;
}
.empty-search-state span[data-v-26a7e817] {
  font-size: 4rem;
  margin-bottom: 1rem;
  opacity: 0.5;
}
.empty-search-state p[data-v-26a7e817] {
  margin-bottom: 0.5rem;
}
.search-tips[data-v-26a7e817] {
  font-size: 0.875rem;
  color: #64748b;
}
@keyframes fadeInUp-26a7e817 {
from {
    opacity: 0;
    transform: translateY(20px);
}
to {
    opacity: 1;
    transform: translateY(0);
}
}
@media (max-width: 768px) {
.search-results-grid[data-v-26a7e817] {
    grid-template-columns: 1fr;
}
.results-summary[data-v-26a7e817] {
    flex-direction: column;
    align-items: flex-start;
}
.results-filters[data-v-26a7e817] {
    width: 100%;
    justify-content: flex-start;
}
}
`, "",{"version":3,"sources":["webpack://./src/modals/components/SearchResultPage.vue"],"names":[],"mappings":";AAyJA;EACE,iBAAiB;EACjB,cAAc;EACd,0CAAiC;AACnC;AAEA;EACE,kBAAkB;EAClB,mBAAmB;EACnB,aAAa;EACb,qFAAqF;EACrF,yCAAyC;EACzC,mBAAmB;EACnB,2BAA2B;AAC7B;AAEA;EACE,kBAAkB;EAClB,gBAAgB;EAChB,sBAAsB;EACtB,cAAc;AAChB;AAEA;EACE,cAAc;EACd,eAAe;AACjB;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,qBAAqB;EACrB,eAAe;EACf,SAAS;AACX;AAEA;EACE,cAAc;EACd,mBAAmB;AACrB;AAEA;EACE,aAAa;EACb,WAAW;EACX,eAAe;AACjB;AAEA;EACE,oBAAoB;EACpB,mCAAmC;EACnC,yCAAyC;EACzC,qBAAqB;EACrB,cAAc;EACd,eAAe;EACf,yBAAyB;EACzB,mBAAmB;EACnB,mBAAmB;AACrB;AAEA;EACE,mCAAmC;AACrC;AAEA;EACE,mCAAmC;EACnC,qCAAqC;EACrC,cAAc;AAChB;AAEA;EACE,aAAa;EACb,4DAA4D;EAC5D,SAAS;AACX;AAEA;EACE,iCAAiC;EACjC,0CAA0C;EAC1C,sBAAsB;EACtB,eAAe;EACf,yBAAyB;EACzB,eAAe;EACf,2BAA2B;AAC7B;AAEA;EACE,qCAAqC;EACrC,2BAA2B;EAC3B,8CAA8C;AAChD;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,mBAAmB;AACrB;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,WAAW;EACX,wBAAwB;EACxB,mCAAmC;EACnC,mBAAmB;AACrB;AAEA;EACE,eAAe;AACjB;AAEA;EACE,kBAAkB;EAClB,gBAAgB;EAChB,cAAc;AAChB;AAEA;EACE,kBAAkB;EAClB,cAAc;EACd,kCAAkC;EAClC,uBAAuB;EACvB,uBAAuB;AACzB;AAEA;EACE,mBAAmB;AACrB;AAEA;EACE,kBAAkB;EAClB,gBAAgB;EAChB,qBAAqB;EACrB,cAAc;AAChB;AAEA;EACE,cAAc;EACd,mBAAmB;EACnB,gBAAgB;EAChB,sBAAsB;EACtB,oBAAoB;EACpB,qBAAqB;EACrB,4BAA4B;EAC5B,gBAAgB;AAClB;AAEA;EACE,aAAa;EACb,aAAa;EACb,eAAe;AACjB;AAEA;EACE,uBAAuB;EACvB,mCAAmC;EACnC,cAAc;EACd,uBAAuB;EACvB,kBAAkB;EAClB,gBAAgB;AAClB;AAEA;EACE,oCAAoC;EACpC,cAAc;AAChB;AAEA;EACE,aAAa;EACb,yBAAyB;AAC3B;AAEA;EACE,oBAAoB;EACpB,mCAAmC;EACnC,yCAAyC;EACzC,qBAAqB;EACrB,cAAc;EACd,eAAe;EACf,yBAAyB;EACzB,mBAAmB;EACnB,gBAAgB;AAClB;AAEA;EACE,mCAAmC;EACnC,qCAAqC;AACvC;AAEA;EACE,mCAAmC;EACnC,qCAAqC;AACvC;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,mBAAmB;EACnB,uBAAuB;EACvB,kBAAkB;EAClB,cAAc;EACd,kBAAkB;AACpB;AAEA;EACE,eAAe;EACf,mBAAmB;EACnB,YAAY;AACd;AAEA;EACE,qBAAqB;AACvB;AAEA;EACE,mBAAmB;EACnB,cAAc;AAChB;AAEA;AACE;IACE,UAAU;IACV,2BAA2B;AAC7B;AACA;IACE,UAAU;IACV,wBAAwB;AAC1B;AACF;AAEA;AACE;IACE,0BAA0B;AAC5B;AAEA;IACE,sBAAsB;IACtB,uBAAuB;AACzB;AAEA;IACE,WAAW;IACX,2BAA2B;AAC7B;AACF","sourcesContent":["<template>\n  <div class=\"search-results-section\">\n    <div class=\"search-header\">\n      <h2>🔍 搜索结果</h2>\n      <p v-if=\"searchQuery\">关键词: \"{{ searchQuery }}\"</p>\n    </div>\n    \n    <div v-if=\"isLoading\" class=\"loading-container\">\n      <div class=\"loading-spinner\"></div>\n      <span>正在搜索...</span>\n    </div>\n    \n    <div v-else-if=\"entities.length > 0\" class=\"search-results\">\n      <div class=\"results-summary\">\n        <span class=\"results-count\">找到 {{ entities.length }} 个相关结果</span>\n        <div class=\"results-filters\">\n          <button \n            v-for=\"type in availableTypes\" \n            :key=\"type.key\"\n            :class=\"['type-filter', { active: selectedTypeFilter === type.key }]\"\n            @click=\"selectedTypeFilter = type.key\"\n          >\n            {{ type.icon }} {{ type.name }} ({{ type.count }})\n          </button>\n        </div>\n      </div>\n      \n      <div class=\"search-results-grid\">\n        <div \n          v-for=\"entity in filteredResults\" \n          :key=\"entity.id\" \n          class=\"search-result-card\"\n          @click=\"handleResultClick(entity)\"\n        >\n          <div class=\"result-header\">\n            <div class=\"result-type-indicator\">\n              <span class=\"type-icon\">{{ getEntityIcon(entity.type) }}</span>\n              <span class=\"type-name\">{{ getEntityTypeName(entity.type) }}</span>\n            </div>\n            <div v-if=\"entity.relevanceScore\" class=\"relevance-score\">\n              {{ Math.round(entity.relevanceScore * 100) }}% 匹配\n            </div>\n          </div>\n          \n          <div class=\"result-content\">\n            <h3 class=\"result-title\">{{ entity.name }}</h3>\n            <p v-if=\"entity.description\" class=\"result-description\">\n              {{ entity.description }}\n            </p>\n            <div v-if=\"entity.tags && entity.tags.length > 0\" class=\"result-tags\">\n              <span \n                v-for=\"tag in entity.tags.slice(0, 3)\" \n                :key=\"tag\" \n                class=\"result-tag\"\n              >\n                {{ tag }}\n              </span>\n              <span v-if=\"entity.tags.length > 3\" class=\"result-tag more-tags\">\n                +{{ entity.tags.length - 3 }}\n              </span>\n            </div>\n          </div>\n          \n          <div class=\"result-actions\">\n            <button class=\"action-btn primary\">\n              查看详情 →\n            </button>\n          </div>\n        </div>\n      </div>\n    </div>\n    \n    <div v-else class=\"empty-search-state\">\n      <span>🔍</span>\n      <p>没有找到相关结果</p>\n      <p class=\"search-tips\">\n        尝试使用不同的关键词或更具体的描述\n      </p>\n    </div>\n  </div>\n</template>\n\n<script setup lang=\"ts\">\nimport { computed, ref } from 'vue';\nimport { useRoute, useRouter } from 'vue-router';\nimport { useMemoryStore, ENTITY_TYPE_CONFIG } from '../memory-store';\n\nconst route = useRoute();\nconst router = useRouter();\nconst store = useMemoryStore();\n\nconst searchQuery = computed(() => route.query.q as string || '');\nconst entities = computed(() => store.entities);\nconst isLoading = computed(() => store.isLoading);\nconst selectedTypeFilter = ref('all');\n\n// 获取可用的实体类型及其数量\nconst availableTypes = computed(() => {\n  const typeMap = new Map();\n  typeMap.set('all', { key: 'all', name: '全部', icon: '📁', count: entities.value.length });\n  \n  entities.value.forEach(entity => {\n    const config = ENTITY_TYPE_CONFIG[entity.type];\n    if (config) {\n      const existing = typeMap.get(entity.type) || { \n        key: entity.type, \n        name: config.name, \n        icon: config.icon, \n        count: 0 \n      };\n      existing.count++;\n      typeMap.set(entity.type, existing);\n    }\n  });\n  \n  return Array.from(typeMap.values()).filter(type => type.count > 0);\n});\n\n// 根据类型过滤的结果\nconst filteredResults = computed(() => {\n  if (selectedTypeFilter.value === 'all') {\n    return entities.value;\n  }\n  return entities.value.filter(entity => entity.type === selectedTypeFilter.value);\n});\n\nconst getEntityIcon = (type: string) => {\n  return ENTITY_TYPE_CONFIG[type]?.icon || '📂';\n};\n\nconst getEntityTypeName = (type: string) => {\n  return ENTITY_TYPE_CONFIG[type]?.name || type;\n};\n\nconst handleResultClick = (entity: any) => {\n  switch (entity.type) {\n    case 'Topic':\n      router.push(`/topic/${entity.id}`);\n      break;\n    case 'Person':\n      router.push(`/person/${entity.id}`);\n      break;\n    case 'Project':\n      router.push(`/project/${entity.id}`);\n      break;\n    default:\n      router.push(`/entity/${entity.type}`);\n      break;\n  }\n};\n</script>\n\n<style scoped>\n.search-results-section {\n  max-width: 1200px;\n  margin: 0 auto;\n  animation: fadeInUp 0.6s ease-out;\n}\n\n.search-header {\n  text-align: center;\n  margin-bottom: 2rem;\n  padding: 2rem;\n  background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(147, 51, 234, 0.1));\n  border: 1px solid rgba(59, 130, 246, 0.2);\n  border-radius: 1rem;\n  backdrop-filter: blur(10px);\n}\n\n.search-header h2 {\n  font-size: 1.75rem;\n  font-weight: 600;\n  margin-bottom: 0.75rem;\n  color: #ffffff;\n}\n\n.search-header p {\n  color: #cbd5e1;\n  font-size: 1rem;\n}\n\n.results-summary {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 1.5rem;\n  flex-wrap: wrap;\n  gap: 1rem;\n}\n\n.results-count {\n  color: #94a3b8;\n  font-size: 0.875rem;\n}\n\n.results-filters {\n  display: flex;\n  gap: 0.5rem;\n  flex-wrap: wrap;\n}\n\n.type-filter {\n  padding: 0.5rem 1rem;\n  background: rgba(59, 130, 246, 0.1);\n  border: 1px solid rgba(59, 130, 246, 0.3);\n  border-radius: 0.5rem;\n  color: #60a5fa;\n  cursor: pointer;\n  transition: all 0.3s ease;\n  font-size: 0.875rem;\n  white-space: nowrap;\n}\n\n.type-filter:hover {\n  background: rgba(59, 130, 246, 0.2);\n}\n\n.type-filter.active {\n  background: rgba(59, 130, 246, 0.3);\n  border-color: rgba(59, 130, 246, 0.5);\n  color: #93c5fd;\n}\n\n.search-results-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));\n  gap: 1rem;\n}\n\n.search-result-card {\n  background: rgba(15, 23, 42, 0.6);\n  border: 1px solid rgba(148, 163, 184, 0.1);\n  border-radius: 0.75rem;\n  padding: 1.5rem;\n  transition: all 0.3s ease;\n  cursor: pointer;\n  backdrop-filter: blur(10px);\n}\n\n.search-result-card:hover {\n  border-color: rgba(59, 130, 246, 0.3);\n  transform: translateY(-2px);\n  box-shadow: 0 8px 32px rgba(59, 130, 246, 0.1);\n}\n\n.result-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 1rem;\n}\n\n.result-type-indicator {\n  display: flex;\n  align-items: center;\n  gap: 0.5rem;\n  padding: 0.25rem 0.75rem;\n  background: rgba(59, 130, 246, 0.2);\n  border-radius: 1rem;\n}\n\n.type-icon {\n  font-size: 1rem;\n}\n\n.type-name {\n  font-size: 0.75rem;\n  font-weight: 500;\n  color: #60a5fa;\n}\n\n.relevance-score {\n  font-size: 0.75rem;\n  color: #22c55e;\n  background: rgba(34, 197, 94, 0.2);\n  padding: 0.25rem 0.5rem;\n  border-radius: 0.375rem;\n}\n\n.result-content {\n  margin-bottom: 1rem;\n}\n\n.result-title {\n  font-size: 1.25rem;\n  font-weight: 600;\n  margin-bottom: 0.5rem;\n  color: #e2e8f0;\n}\n\n.result-description {\n  color: #cbd5e1;\n  font-size: 0.875rem;\n  line-height: 1.5;\n  margin-bottom: 0.75rem;\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n}\n\n.result-tags {\n  display: flex;\n  gap: 0.375rem;\n  flex-wrap: wrap;\n}\n\n.result-tag {\n  padding: 0.25rem 0.5rem;\n  background: rgba(147, 51, 234, 0.2);\n  color: #a78bfa;\n  border-radius: 0.375rem;\n  font-size: 0.75rem;\n  font-weight: 500;\n}\n\n.result-tag.more-tags {\n  background: rgba(148, 163, 184, 0.2);\n  color: #94a3b8;\n}\n\n.result-actions {\n  display: flex;\n  justify-content: flex-end;\n}\n\n.action-btn {\n  padding: 0.5rem 1rem;\n  background: rgba(59, 130, 246, 0.1);\n  border: 1px solid rgba(59, 130, 246, 0.3);\n  border-radius: 0.5rem;\n  color: #60a5fa;\n  cursor: pointer;\n  transition: all 0.3s ease;\n  font-size: 0.875rem;\n  font-weight: 500;\n}\n\n.action-btn.primary {\n  background: rgba(59, 130, 246, 0.2);\n  border-color: rgba(59, 130, 246, 0.4);\n}\n\n.action-btn:hover {\n  background: rgba(59, 130, 246, 0.3);\n  border-color: rgba(59, 130, 246, 0.5);\n}\n\n.empty-search-state {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  padding: 4rem 2rem;\n  color: #94a3b8;\n  text-align: center;\n}\n\n.empty-search-state span {\n  font-size: 4rem;\n  margin-bottom: 1rem;\n  opacity: 0.5;\n}\n\n.empty-search-state p {\n  margin-bottom: 0.5rem;\n}\n\n.search-tips {\n  font-size: 0.875rem;\n  color: #64748b;\n}\n\n@keyframes fadeInUp {\n  from {\n    opacity: 0;\n    transform: translateY(20px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n\n@media (max-width: 768px) {\n  .search-results-grid {\n    grid-template-columns: 1fr;\n  }\n  \n  .results-summary {\n    flex-direction: column;\n    align-items: flex-start;\n  }\n  \n  .results-filters {\n    width: 100%;\n    justify-content: flex-start;\n  }\n}\n</style>\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 3438:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1354);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6314);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `
/* 全局样式 */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body {
  font-size: 1rem;
  font-family: 'SF Pro Display', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: linear-gradient(135deg, #0c0c0c 0%, #1a1a2e 50%, #16213e 100%);
  color: #ffffff;
  overflow-x: hidden;
  min-height: 100vh;
}
.memory-container {
  display: flex;
  min-height: 100vh;
  font-family: 'SF Pro Display', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: linear-gradient(135deg, #0c0c0c 0%, #1a1a2e 50%, #16213e 100%);
  color: #ffffff;
  overflow-x: hidden;
}
.main-content {
  flex: 1;
  padding: 2rem;
  overflow-y: auto;
  height: 100vh;
  max-height: 100vh;
}

/* 侧边栏样式 */
.sidebar {
  width: 280px;
  background: rgba(15, 23, 42, 0.8);
  backdrop-filter: blur(20px);
  border-right: 1px solid rgba(148, 163, 184, 0.1);
  padding: 2rem 0;
  transition: all 0.3s ease;
}
.sidebar-header {
  padding: 0 2rem 2rem;
  border-bottom: 1px solid rgba(148, 163, 184, 0.1);
}
.logo {
  font-size: 1.5rem;
  font-weight: 700;
  background: linear-gradient(135deg, #60a5fa, #a78bfa);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
.entity-types {
  padding: 1.5rem 0;
}
.entity-type {
  display: flex;
  align-items: center;
  padding: 0.75rem 2rem;
  margin: 0.25rem 0;
  cursor: pointer;
  transition: all 0.3s ease;
  border-left: 3px solid transparent;
  text-decoration: none;
  color: inherit;
}
.entity-type:hover {
  background: rgba(59, 130, 246, 0.1);
  border-left-color: #60a5fa;
}
.entity-type.router-link-active {
  background: rgba(59, 130, 246, 0.2);
  border-left-color: #60a5fa;
}
.entity-icon {
  width: 1.5rem;
  height: 1.5rem;
  margin-right: 0.75rem;
  font-size: 1.2rem;
  display: flex;
  align-items: center;
  justify-content: center;
}
.entity-name {
  font-weight: 500;
  flex: 1;
}
.entity-count {
  background: rgba(59, 130, 246, 0.2);
  color: #60a5fa;
  padding: 0.25rem 0.5rem;
  border-radius: 0.75rem;
  font-size: 0.75rem;
  font-weight: 600;
}
.sidebar-divider {
  margin: 1rem 0;
  border: none;
  border-top: 1px solid rgba(148, 163, 184, 0.1);
}

/* 搜索头部样式 */
.search-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 2rem;
}
.search-box {
  flex: 1;
  position: relative;
}
.search-input {
  width: 100%;
  padding: 0.75rem 1rem 0.75rem 3rem;
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(148, 163, 184, 0.2);
  border-radius: 0.75rem;
  color: #ffffff;
  font-size: 1rem;
  transition: all 0.3s ease;
}
.search-input:focus {
  outline: none;
  border-color: #60a5fa;
  box-shadow: 0 0 0 3px rgba(96, 165, 250, 0.1);
}
.search-input::placeholder {
  color: #64748b;
}
.search-icon {
  position: absolute;
  left: 1rem;
  top: 50%;
  transform: translateY(-50%);
  color: #64748b;
}
.filter-btn {
  padding: 0.75rem 1.5rem;
  background: rgba(59, 130, 246, 0.1);
  border: 1px solid rgba(59, 130, 246, 0.3);
  border-radius: 0.75rem;
  color: #60a5fa;
  cursor: pointer;
  transition: all 0.3s ease;
  white-space: nowrap;
  border: none;
}
.filter-btn:hover {
  background: rgba(59, 130, 246, 0.2);
}

/* 页面过渡动画 */
.fade-enter-active, .fade-leave-active {
  transition: opacity 0.3s ease;
}
.fade-enter-from, .fade-leave-to {
  opacity: 0;
}

/* 概览样式 */
.overview-section {
  animation: fadeInUp 0.6s ease-out;
}
.greeting-card {
  background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(147, 51, 234, 0.1));
  border: 1px solid rgba(59, 130, 246, 0.2);
  border-radius: 1rem;
  padding: 2rem;
  margin-bottom: 2rem;
  backdrop-filter: blur(10px);
}
.greeting-title {
  font-size: 1.5rem;
  font-weight: 600;
  margin-bottom: 1rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
.greeting-content {
  color: #cbd5e1;
  line-height: 1.6;
}
.quick-summary {
  list-style: none;
  margin: 1rem 0;
}
.quick-summary li {
  padding: 0.5rem 0;
  border-left: 3px solid #60a5fa;
  padding-left: 1rem;
  margin: 0.5rem 0;
}

/* 内容网格 */
.content-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
}
.content-card {
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(148, 163, 184, 0.1);
  border-radius: 1rem;
  padding: 1.5rem;
  transition: all 0.3s ease;
  backdrop-filter: blur(10px);
  cursor: pointer;
}
.content-card:hover {
  transform: translateY(-2px);
  border-color: rgba(59, 130, 246, 0.3);
  box-shadow: 0 8px 32px rgba(59, 130, 246, 0.1);
}

/* 实体网格布局 */
.entities-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 1rem;
}
.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1rem;
}
.card-title {
  font-size: 1.1rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
.card-badge {
  background: rgba(59, 130, 246, 0.2);
  color: #60a5fa;
  padding: 0.25rem 0.75rem;
  border-radius: 1rem;
  font-size: 0.75rem;
  font-weight: 500;
}
.card-content {
  color: #cbd5e1;
  line-height: 1.5;
  margin-bottom: 1rem;
}
.info-list {
  list-style: none;
}
.info-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 0;
  border-bottom: 1px solid rgba(148, 163, 184, 0.1);
  transition: all 0.3s ease;
}
.info-item:hover {
  background: rgba(59, 130, 246, 0.05);
  border-radius: 0.5rem;
  padding-left: 0.5rem;
}
.info-item:last-child {
  border-bottom: none;
}
.info-time {
  color: #64748b;
  font-size: 0.875rem;
  margin-left: auto;
}
.view-more-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  color: #60a5fa;
  font-size: 0.875rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}
.view-more-btn:hover {
  color: #93c5fd;
}

/* 加载动画 */
.loading-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 3rem;
  color: #94a3b8;
}
.loading-spinner {
  width: 2rem;
  height: 2rem;
  border: 2px solid rgba(96, 165, 250, 0.3);
  border-top: 2px solid #60a5fa;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin-bottom: 1rem;
}

/* 时间轴样式 */
.timeline-view {
  animation: fadeInUp 0.6s ease-out;
}
.timeline-container {
  position: relative;
}
.timeline-item {
  display: flex;
  gap: 1rem;
  margin-bottom: 1.5rem;
  position: relative;
}
.timeline-item:not(:last-child)::before {
  content: '';
  position: absolute;
  left: 1.25rem;
  top: 3rem;
  width: 2px;
  height: calc(100% + 1rem);
  background: linear-gradient(to bottom, #60a5fa, rgba(96, 165, 250, 0.3));
}
.timeline-dot {
  width: 2.5rem;
  height: 2.5rem;
  border-radius: 50%;
  background: linear-gradient(135deg, #60a5fa, #a78bfa);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1rem;
  color: white;
  flex-shrink: 0;
  z-index: 1;
}
.timeline-content {
  flex: 1;
}
.timeline-time {
  color: #64748b;
  font-size: 0.875rem;
  margin-bottom: 0.5rem;
}
.event-source {
  color: #94a3b8;
  font-size: 0.75rem;
  margin-top: 0.5rem;
}

/* 实体详情样式 */
.entity-detail {
  animation: fadeInUp 0.6s ease-out;
}
.entity-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 2rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid rgba(148, 163, 184, 0.1);
}
.entity-avatar {
  width: 3rem;
  height: 3rem;
  border-radius: 50%;
  background: linear-gradient(135deg, #60a5fa, #a78bfa);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
}
.entity-info h2 {
  font-size: 1.75rem;
  font-weight: 600;
  margin-bottom: 0.25rem;
}
.entity-meta {
  color: #64748b;
  font-size: 1rem;
}

/* 实体网格样式 */
.entities-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 1rem;
}

/* Topic卡片特殊样式 */
.topic-card {
  min-height: auto;
}

/* Person卡片特殊样式 */
.person-card {
  min-height: auto;
}
.person-card-header {
  margin-bottom: 1rem;
}
.person-card-badge {
  background: rgba(34, 197, 94, 0.2);
  color: #22c55e;
  padding: 0.25rem 0.75rem;
  border-radius: 1rem;
  font-size: 0.75rem;
  font-weight: 500;
}
.person-preview-section {
  margin: 1rem 0;
  padding: 0.75rem 0;
  border-top: 1px solid rgba(148, 163, 184, 0.1);
}
.person-preview-section:first-of-type {
  border-top: none;
  margin-top: 0;
  padding-top: 0;
}
.expertise-tags {
  display: flex;
  gap: 0.375rem;
  flex-wrap: wrap;
}
.expertise-tag {
  padding: 0.25rem 0.5rem;
  background: rgba(147, 51, 234, 0.2);
  color: #a78bfa;
  border-radius: 0.375rem;
  font-size: 0.75rem;
  font-weight: 500;
}
.collaboration-item:hover .preview-content {
  color: #60a5fa;
}
.message-item:hover .preview-content {
  color: #60a5fa;
}
.team-indicator {
  background: rgba(59, 130, 246, 0.2);
  color: #60a5fa;
  padding: 0.125rem 0.375rem;
  border-radius: 0.25rem;
  font-size: 0.625rem;
  font-weight: 500;
}
.topic-card-header {
  margin-bottom: 1rem;
}
.topic-card-badge {
  background: rgba(59, 130, 246, 0.2);
  color: #60a5fa;
  padding: 0.25rem 0.75rem;
  border-radius: 1rem;
  font-size: 0.75rem;
  font-weight: 500;
}
.topic-preview-section {
  margin: 1rem 0;
  padding: 0.75rem 0;
  border-top: 1px solid rgba(148, 163, 184, 0.1);
}
.topic-preview-section:first-of-type {
  border-top: none;
  margin-top: 0;
  padding-top: 0;
}
.preview-section-title {
  color: #60a5fa;
  font-size: 0.875rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
  display: flex;
  align-items: center;
  gap: 0.25rem;
}
.preview-list {
  list-style: none;
  margin: 0;
  padding: 0;
}
.preview-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.375rem 0;
  cursor: pointer;
  transition: all 0.3s ease;
  border-radius: 0.25rem;
  margin: 0.25rem 0;
}
.preview-item:hover {
  background: rgba(59, 130, 246, 0.05);
  padding-left: 0.5rem;
}
.preview-content {
  flex: 1;
  font-size: 0.875rem;
  color: #cbd5e1;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.preview-time {
  font-size: 0.75rem;
  color: #64748b;
  white-space: nowrap;
}
.project-status {
  background: rgba(34, 197, 94, 0.2);
  color: #22c55e;
  padding: 0.125rem 0.375rem;
  border-radius: 0.25rem;
  font-size: 0.625rem;
  font-weight: 500;
  white-space: nowrap;
}
.discussion-item:hover .preview-content {
  color: #60a5fa;
}
.resource-item:hover .preview-content {
  color: #60a5fa;
}
.project-item:hover .preview-content {
  color: #60a5fa;
}

/* 项目卡片特殊样式 */
.project-card {
  position: relative;
}
.project-actions {
  display: flex;
  gap: 0.5rem;
  margin: 0.75rem 0;
  flex-wrap: wrap;
}
.project-action-btn {
  padding: 0.375rem 0.75rem;
  background: rgba(59, 130, 246, 0.1);
  border: 1px solid rgba(59, 130, 246, 0.3);
  border-radius: 0.5rem;
  color: #60a5fa;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 0.75rem;
  font-weight: 500;
  white-space: nowrap;
}
.project-action-btn:hover {
  background: rgba(59, 130, 246, 0.2);
  border-color: rgba(59, 130, 246, 0.5);
}
.project-action-btn.highlight.active {
  background: rgba(251, 191, 36, 0.2);
  border-color: rgba(251, 191, 36, 0.5);
  color: #f59e0b;
}
.project-action-btn.highlight.active:hover {
  background: rgba(251, 191, 36, 0.3);
}
.project-action-btn.dashboard {
  background: rgba(34, 197, 94, 0.1);
  border-color: rgba(34, 197, 94, 0.3);
  color: #22c55e;
}
.project-action-btn.dashboard:hover {
  background: rgba(34, 197, 94, 0.2);
  border-color: rgba(34, 197, 94, 0.5);
}
.entity-card {
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(148, 163, 184, 0.1);
  border-radius: 0.75rem;
  padding: 1rem;
  transition: all 0.3s ease;
  cursor: pointer;
}
.entity-card:hover {
  border-color: rgba(59, 130, 246, 0.3);
  transform: translateY(-2px);
}
.entity-card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 0.5rem;
}
.entity-card-title {
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 1.1rem;
}
.importance-indicator {
  width: 60px;
  height: 4px;
  background: rgba(148, 163, 184, 0.2);
  border-radius: 2px;
  overflow: hidden;
}
.importance-bar {
  height: 100%;
  background: linear-gradient(90deg, #60a5fa, #a78bfa);
  transition: width 0.3s ease;
}
.entity-description {
  color: #cbd5e1;
  font-size: 0.875rem;
  line-height: 1.5;
  margin-bottom: 0.75rem;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.entity-stats {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 0.5rem;
  margin-bottom: 0.75rem;
}
.stat-item {
  display: flex;
  align-items: center;
  gap: 0.25rem;
  font-size: 0.75rem;
  color: #94a3b8;
}
.entity-tags {
  display: flex;
  gap: 0.25rem;
  flex-wrap: wrap;
  margin-bottom: 0.75rem;
}
.entity-tag {
  padding: 0.125rem 0.375rem;
  background: rgba(59, 130, 246, 0.2);
  color: #60a5fa;
  border-radius: 0.25rem;
  font-size: 0.625rem;
}
.entity-tag.more-tags {
  background: rgba(148, 163, 184, 0.2);
  color: #94a3b8;
}
.entity-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.75rem;
  color: #64748b;
}
.last-accessed {
  color: #64748b;
}
.status-indicator {
  padding: 0.125rem 0.375rem;
  border-radius: 0.25rem;
  font-size: 0.625rem;
  font-weight: 500;
}
.status-indicator.active {
  background: rgba(34, 197, 94, 0.2);
  color: #22c55e;
}
.status-indicator.inactive {
  background: rgba(148, 163, 184, 0.2);
  color: #94a3b8;
}

/* 主题详情样式 */
.topic-detail {
  animation: fadeInUp 0.6s ease-out;
}
.detail-header {
  margin-bottom: 2rem;
}
.back-btn {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  background: rgba(59, 130, 246, 0.1);
  border: 1px solid rgba(59, 130, 246, 0.3);
  border-radius: 0.5rem;
  padding: 0.75rem 1.5rem;
  color: #60a5fa;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-bottom: 1.5rem;
}
.back-btn:hover {
  background: rgba(59, 130, 246, 0.2);
}
.topic-header {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(148, 163, 184, 0.1);
  border-radius: 1rem;
  padding: 2rem;
  backdrop-filter: blur(10px);
}
.topic-avatar {
  width: 4rem;
  height: 4rem;
  border-radius: 1rem;
  background: linear-gradient(135deg, #60a5fa, #a78bfa);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2rem;
  flex-shrink: 0;
}
.topic-info {
  flex: 1;
}
.topic-info h2 {
  font-size: 1.75rem;
  font-weight: 600;
  margin-bottom: 0.75rem;
}
.topic-meta {
  display: flex;
  gap: 1.5rem;
  flex-wrap: wrap;
}
.meta-item {
  color: #94a3b8;
  font-size: 0.875rem;
}
.topic-actions {
  display: flex;
  gap: 0.75rem;
}
.action-btn {
  padding: 0.75rem 1.5rem;
  background: rgba(59, 130, 246, 0.1);
  border: 1px solid rgba(59, 130, 246, 0.3);
  border-radius: 0.5rem;
  color: #60a5fa;
  cursor: pointer;
  transition: all 0.3s ease;
  white-space: nowrap;
}
.action-btn:hover {
  background: rgba(59, 130, 246, 0.2);
}

/* 选项卡样式 */
.tab-navigation {
  display: flex;
  gap: 0.5rem;
  margin-bottom: 2rem;
  border-bottom: 1px solid rgba(148, 163, 184, 0.1);
  padding-bottom: 1rem;
  overflow-x: auto;
}
.tab-btn {
  padding: 0.75rem 1.5rem;
  background: transparent;
  border: none;
  border-radius: 0.5rem;
  color: #94a3b8;
  cursor: pointer;
  transition: all 0.3s ease;
  white-space: nowrap;
  font-size: 0.875rem;
}
.tab-btn.active {
  background: rgba(59, 130, 246, 0.2);
  color: #60a5fa;
}
.tab-btn:hover:not(.active) {
  background: rgba(59, 130, 246, 0.1);
  color: #93c5fd;
}
.tab-content {
  display: block;
  animation: fadeInUp 0.4s ease-out;
}

/* 列表项样式 */
.section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1.5rem;
}
.section-header h3 {
  font-size: 1.25rem;
  font-weight: 600;
}
.add-btn {
  padding: 0.75rem 1.5rem;
  background: rgba(34, 197, 94, 0.1);
  border: 1px solid rgba(34, 197, 94, 0.3);
  border-radius: 0.5rem;
  color: #22c55e;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 1rem;
}
.add-btn:hover {
  background: rgba(34, 197, 94, 0.2);
}
.items-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 1rem;
}
.item-card {
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(148, 163, 184, 0.1);
  border-radius: 0.75rem;
  padding: 1rem;
  transition: all 0.3s ease;
  cursor: pointer;
}
.item-card:hover {
  border-color: rgba(59, 130, 246, 0.3);
  transform: translateY(-2px);
}
.item-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 0.5rem;
}
.item-title {
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 1.1rem;
}
.item-actions {
  display: flex;
  gap: 0.25rem;
}
.item-action {
  padding: 0.25rem;
  background: transparent;
  border: none;
  border-radius: 0.25rem;
  color: #94a3b8;
  cursor: pointer;
  transition: all 0.3s ease;
}
.item-action:hover {
  background: rgba(239, 68, 68, 0.1);
  color: #ef4444;
}
.item-content {
  color: #cbd5e1;
  font-size: 0.875rem;
  line-height: 1.5;
}

/* 搜索控件 */
.search-controls {
  display: flex;
  gap: 1rem;
  align-items: center;
}

/* 搜索过滤控件 */
.search-filter-controls {
  display: flex;
  gap: 1rem;
  align-items: center;
  margin-bottom: 1.5rem;
  padding: 1rem;
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(148, 163, 184, 0.1);
  border-radius: 0.75rem;
  backdrop-filter: blur(10px);
}
.filter-controls {
  display: flex;
  gap: 0.75rem;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1.5rem;
  flex-wrap: wrap;
}
.filter-select-wrapper {
  display: flex;
  align-items: center;
}
.results-count {
  color: #94a3b8;
  font-size: 0.875rem;
  margin-left: auto;
}
.filter-select {
  padding: 0.5rem;
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(148, 163, 184, 0.2);
  border-radius: 0.5rem;
  color: #ffffff;
  min-width: 120px;
  font-size: 0.875rem;
}

/* 聊天记录样式 */
.conversations-list {
  margin-bottom: 2rem;
}
.conversation-item {
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(148, 163, 184, 0.1);
  border-radius: 0.75rem;
  padding: 1rem;
  margin-bottom: 1rem;
  position: relative;
  cursor: pointer;
  transition: all 0.3s ease;
}
.conversation-item:hover {
  border-color: rgba(59, 130, 246, 0.3);
}
.conversation-item.expanded {
  cursor: default;
}
.conversation-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 0.75rem;
}
.conversation-meta {
  display: flex;
  align-items: center;
  gap: 1rem;
}
.sender-avatar {
  width: 2.5rem;
  height: 2.5rem;
  border-radius: 50%;
  background: linear-gradient(135deg, #60a5fa, #a78bfa);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1rem;
}
.sender-info {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}
.sender-name {
  font-weight: 600;
  font-size: 0.875rem;
}
.group-name {
  font-size: 0.75rem;
  color: #94a3b8;
}
.conversation-time {
  font-size: 0.875rem;
  color: #64748b;
}
.conversation-summary {
  color: #cbd5e1;
  line-height: 1.5;
  margin-bottom: 0.5rem;
}
.context-indicator {
  margin-top: 0.75rem;
  padding: 0.5rem 0.75rem;
  background: rgba(59, 130, 246, 0.1);
  border: 1px solid rgba(59, 130, 246, 0.3);
  border-radius: 0.5rem;
  cursor: pointer;
  transition: all 0.3s ease;
  user-select: none;
}
.context-indicator:hover {
  background: rgba(59, 130, 246, 0.2);
  border-color: rgba(59, 130, 246, 0.5);
}
.context-indicator.expanded {
  background: rgba(59, 130, 246, 0.2);
  border-color: rgba(59, 130, 246, 0.4);
}
.indicator-text {
  font-size: 0.875rem;
  color: #60a5fa;
  font-weight: 500;
}
.context-content {
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.3s ease;
}
.context-content.expanded {
  max-height: 500px;
  overflow-y: auto;
}
.context-divider {
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(148, 163, 184, 0.3), transparent);
  margin: 1rem 0;
}
.context-item {
  background: rgba(30, 41, 59, 0.4);
  border: 1px solid rgba(148, 163, 184, 0.1);
  border-radius: 0.5rem;
  padding: 0.75rem;
  margin-bottom: 0.5rem;
  transition: all 0.3s ease;
}
.context-item:last-child {
  margin-bottom: 0;
}
.context-item.main-message {
  border-color: rgba(34, 197, 94, 0.3);
  background: rgba(34, 197, 94, 0.1);
}
.context-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
}
.context-sender {
  font-weight: 600;
  font-size: 0.75rem;
  color: #e2e8f0;
}
.context-time {
  font-size: 0.75rem;
  color: #94a3b8;
}
.context-content-text {
  color: #cbd5e1;
  line-height: 1.4;
  font-size: 0.8rem;
}

/* 网页记录样式 */
.webpages-list {
  margin-bottom: 2rem;
}
.webpage-item {
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(148, 163, 184, 0.1);
  border-radius: 0.75rem;
  padding: 1rem;
  margin-bottom: 1rem;
  transition: all 0.3s ease;
}
.webpage-item:hover {
  border-color: rgba(59, 130, 246, 0.3);
  transform: translateY(-1px);
}
.webpage-header {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  margin-bottom: 0.75rem;
}
.webpage-icon {
  width: 2.5rem;
  height: 2.5rem;
  border-radius: 0.5rem;
  background: linear-gradient(135deg, #60a5fa, #a78bfa);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.25rem;
  flex-shrink: 0;
}
.webpage-info {
  flex: 1;
  min-width: 0;
}
.webpage-title {
  font-weight: 600;
  margin-bottom: 0.25rem;
  font-size: 1.1rem;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.webpage-url {
  font-size: 0.75rem;
  color: #60a5fa;
  margin-bottom: 0.5rem;
  word-break: break-all;
}
.webpage-meta {
  display: flex;
  gap: 1rem;
  font-size: 0.875rem;
  color: #94a3b8;
}
.webpage-content {
  color: #cbd5e1;
  font-size: 0.875rem;
  line-height: 1.5;
  margin-bottom: 0.75rem;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.webpage-tags {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
}
.webpage-tag {
  padding: 0.25rem 0.5rem;
  background: rgba(59, 130, 246, 0.2);
  color: #60a5fa;
  border-radius: 0.25rem;
  font-size: 0.875rem;
}

/* 空状态 */
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 3rem;
  color: #94a3b8;
  text-align: center;
}
.empty-state span {
  font-size: 3rem;
  margin-bottom: 1rem;
}

/* 动画 */
@keyframes fadeInUp {
from {
    opacity: 0;
    transform: translateY(20px);
}
to {
    opacity: 1;
    transform: translateY(0);
}
}
@keyframes spin {
to {
    transform: rotate(360deg);
}
}

/* 用户画像样式 */
.user-profile-section {
  max-width: 1200px;
  margin: 0 auto;
  animation: fadeInUp 0.6s ease-out;
}
.profile-header {
  text-align: center;
  margin-bottom: 2rem;
  padding: 2rem;
  background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(147, 51, 234, 0.1));
  border: 1px solid rgba(59, 130, 246, 0.2);
  border-radius: 1rem;
  backdrop-filter: blur(10px);
}
.profile-header h2 {
  font-size: 1.75rem;
  font-weight: 600;
  margin-bottom: 0.75rem;
  color: #ffffff;
}
.profile-header p {
  color: #cbd5e1;
  font-size: 1rem;
  line-height: 1.6;
}
.profile-content {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}
.profile-card {
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(148, 163, 184, 0.1);
  border-radius: 1rem;
  padding: 1.5rem;
  backdrop-filter: blur(10px);
  transition: all 0.3s ease;
}
.profile-card:hover {
  border-color: rgba(59, 130, 246, 0.3);
  box-shadow: 0 8px 32px rgba(59, 130, 246, 0.1);
}
.profile-card h3 {
  font-size: 1.25rem;
  font-weight: 600;
  margin-bottom: 1rem;
  color: #60a5fa;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
.interest-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
}
.interest-category h4 {
  font-size: 1rem;
  font-weight: 600;
  margin-bottom: 0.75rem;
  color: #e2e8f0;
}
.interest-list {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}
.interest-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 0.75rem;
  background: rgba(59, 130, 246, 0.1);
  border-radius: 0.5rem;
  transition: all 0.3s ease;
}
.interest-item:hover {
  background: rgba(59, 130, 246, 0.2);
  transform: translateX(4px);
}
.interest-icon {
  font-size: 1rem;
}
.insights-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1rem;
}
.insight-item {
  padding: 1rem;
  background: rgba(30, 41, 59, 0.4);
  border: 1px solid rgba(148, 163, 184, 0.1);
  border-radius: 0.75rem;
}
.insight-item h4 {
  font-size: 0.875rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: #60a5fa;
}
.insight-item p {
  color: #cbd5e1;
  font-size: 0.875rem;
  line-height: 1.5;
}
.tag-list {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}
.focus-tag {
  padding: 0.25rem 0.75rem;
  background: rgba(34, 197, 94, 0.2);
  color: #22c55e;
  border-radius: 1rem;
  font-size: 0.75rem;
  font-weight: 500;
}
.suggestions-list {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}
.suggestion-item {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem;
  background: rgba(30, 41, 59, 0.4);
  border: 1px solid rgba(148, 163, 184, 0.1);
  border-radius: 0.5rem;
  transition: all 0.3s ease;
}
.suggestion-item:hover {
  background: rgba(59, 130, 246, 0.1);
  border-color: rgba(59, 130, 246, 0.3);
}
.suggestion-icon {
  font-size: 1rem;
  color: #60a5fa;
}
.predictions-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
.prediction-item {
  padding: 1rem;
  background: rgba(30, 41, 59, 0.4);
  border: 1px solid rgba(148, 163, 184, 0.1);
  border-radius: 0.75rem;
}
.prediction-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
}
.prediction-type {
  background: rgba(147, 51, 234, 0.2);
  color: #a78bfa;
  padding: 0.25rem 0.75rem;
  border-radius: 1rem;
  font-size: 0.75rem;
  font-weight: 500;
}
.prediction-confidence {
  font-size: 0.75rem;
  color: #94a3b8;
}
.prediction-name {
  font-weight: 600;
  margin-bottom: 0.25rem;
  color: #e2e8f0;
}
.prediction-reason {
  font-size: 0.875rem;
  color: #94a3b8;
  line-height: 1.4;
}
.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 1rem;
}
.stat-card {
  text-align: center;
  padding: 1rem;
  background: rgba(59, 130, 246, 0.1);
  border-radius: 0.75rem;
  transition: all 0.3s ease;
}
.stat-card:hover {
  background: rgba(59, 130, 246, 0.2);
  transform: translateY(-2px);
}
.stat-value {
  font-size: 1.5rem;
  font-weight: 700;
  color: #60a5fa;
  margin-bottom: 0.25rem;
}
.stat-label {
  font-size: 0.75rem;
  color: #94a3b8;
}
.empty-hint {
  font-size: 0.875rem;
  color: #94a3b8;
  margin-top: 0.5rem;
}

/* 滚动条样式 */
::-webkit-scrollbar {
  width: 8px;
}
::-webkit-scrollbar-track {
  background: rgba(15, 23, 42, 0.3);
}
::-webkit-scrollbar-thumb {
  background: rgba(59, 130, 246, 0.3);
  border-radius: 4px;
}
::-webkit-scrollbar-thumb:hover {
  background: rgba(59, 130, 246, 0.5);
}

/* 响应式设计 */
@media (max-width: 768px) {
.memory-container {
    flex-direction: column;
}
.sidebar {
    width: 100%;
    height: auto;
    position: static;
}
.main-content {
    padding: 1rem;
}
.content-grid,
  .entities-grid {
    grid-template-columns: 1fr;
}
.search-header {
    flex-direction: column;
    gap: 0.5rem;
}
.search-box {
    width: 100%;
}
.topic-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 1rem;
}
.topic-actions {
    width: 100%;
    justify-content: stretch;
}
.action-btn {
    flex: 1;
}
.tab-navigation {
    overflow-x: auto;
}
}
`, "",{"version":3,"sources":["webpack://./src/modals/memory-exploring.vue"],"names":[],"mappings":";AAqHA,SAAS;AACT;EACE,SAAS;EACT,UAAU;EACV,sBAAsB;AACxB;AAEA;EACE,eAAe;EACf,gGAAgG;EAChG,0EAA0E;EAC1E,cAAc;EACd,kBAAkB;EAClB,iBAAiB;AACnB;AAEA;EACE,aAAa;EACb,iBAAiB;EACjB,gGAAgG;EAChG,0EAA0E;EAC1E,cAAc;EACd,kBAAkB;AACpB;AAEA;EACE,OAAO;EACP,aAAa;EACb,gBAAgB;EAChB,aAAa;EACb,iBAAiB;AACnB;;AAEA,UAAU;AACV;EACE,YAAY;EACZ,iCAAiC;EACjC,2BAA2B;EAC3B,gDAAgD;EAChD,eAAe;EACf,yBAAyB;AAC3B;AAEA;EACE,oBAAoB;EACpB,iDAAiD;AACnD;AAEA;EACE,iBAAiB;EACjB,gBAAgB;EAChB,qDAAqD;EACrD,6BAA6B;EAC7B,oCAAoC;EACpC,qBAAqB;AACvB;AAEA;EACE,iBAAiB;AACnB;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,qBAAqB;EACrB,iBAAiB;EACjB,eAAe;EACf,yBAAyB;EACzB,kCAAkC;EAClC,qBAAqB;EACrB,cAAc;AAChB;AAEA;EACE,mCAAmC;EACnC,0BAA0B;AAC5B;AAEA;EACE,mCAAmC;EACnC,0BAA0B;AAC5B;AAEA;EACE,aAAa;EACb,cAAc;EACd,qBAAqB;EACrB,iBAAiB;EACjB,aAAa;EACb,mBAAmB;EACnB,uBAAuB;AACzB;AAEA;EACE,gBAAgB;EAChB,OAAO;AACT;AAEA;EACE,mCAAmC;EACnC,cAAc;EACd,uBAAuB;EACvB,sBAAsB;EACtB,kBAAkB;EAClB,gBAAgB;AAClB;AAEA;EACE,cAAc;EACd,YAAY;EACZ,8CAA8C;AAChD;;AAEA,WAAW;AACX;EACE,aAAa;EACb,mBAAmB;EACnB,SAAS;EACT,mBAAmB;AACrB;AAEA;EACE,OAAO;EACP,kBAAkB;AACpB;AAEA;EACE,WAAW;EACX,kCAAkC;EAClC,iCAAiC;EACjC,0CAA0C;EAC1C,sBAAsB;EACtB,cAAc;EACd,eAAe;EACf,yBAAyB;AAC3B;AAEA;EACE,aAAa;EACb,qBAAqB;EACrB,6CAA6C;AAC/C;AAEA;EACE,cAAc;AAChB;AAEA;EACE,kBAAkB;EAClB,UAAU;EACV,QAAQ;EACR,2BAA2B;EAC3B,cAAc;AAChB;AAEA;EACE,uBAAuB;EACvB,mCAAmC;EACnC,yCAAyC;EACzC,sBAAsB;EACtB,cAAc;EACd,eAAe;EACf,yBAAyB;EACzB,mBAAmB;EACnB,YAAY;AACd;AAEA;EACE,mCAAmC;AACrC;;AAEA,WAAW;AACX;EACE,6BAA6B;AAC/B;AAEA;EACE,UAAU;AACZ;;AAEA,SAAS;AACT;EACE,iCAAiC;AACnC;AAEA;EACE,qFAAqF;EACrF,yCAAyC;EACzC,mBAAmB;EACnB,aAAa;EACb,mBAAmB;EACnB,2BAA2B;AAC7B;AAEA;EACE,iBAAiB;EACjB,gBAAgB;EAChB,mBAAmB;EACnB,aAAa;EACb,mBAAmB;EACnB,WAAW;AACb;AAEA;EACE,cAAc;EACd,gBAAgB;AAClB;AAEA;EACE,gBAAgB;EAChB,cAAc;AAChB;AAEA;EACE,iBAAiB;EACjB,8BAA8B;EAC9B,kBAAkB;EAClB,gBAAgB;AAClB;;AAEA,SAAS;AACT;EACE,aAAa;EACb,2DAA2D;EAC3D,WAAW;EACX,mBAAmB;AACrB;AAEA;EACE,iCAAiC;EACjC,0CAA0C;EAC1C,mBAAmB;EACnB,eAAe;EACf,yBAAyB;EACzB,2BAA2B;EAC3B,eAAe;AACjB;AAEA;EACE,2BAA2B;EAC3B,qCAAqC;EACrC,8CAA8C;AAChD;;AAEA,WAAW;AACX;EACE,aAAa;EACb,4DAA4D;EAC5D,SAAS;AACX;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,mBAAmB;AACrB;AAEA;EACE,iBAAiB;EACjB,gBAAgB;EAChB,aAAa;EACb,mBAAmB;EACnB,WAAW;AACb;AAEA;EACE,mCAAmC;EACnC,cAAc;EACd,wBAAwB;EACxB,mBAAmB;EACnB,kBAAkB;EAClB,gBAAgB;AAClB;AAEA;EACE,cAAc;EACd,gBAAgB;EAChB,mBAAmB;AACrB;AAEA;EACE,gBAAgB;AAClB;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,WAAW;EACX,iBAAiB;EACjB,iDAAiD;EACjD,yBAAyB;AAC3B;AAEA;EACE,oCAAoC;EACpC,qBAAqB;EACrB,oBAAoB;AACtB;AAEA;EACE,mBAAmB;AACrB;AAEA;EACE,cAAc;EACd,mBAAmB;EACnB,iBAAiB;AACnB;AAEA;EACE,oBAAoB;EACpB,mBAAmB;EACnB,WAAW;EACX,cAAc;EACd,mBAAmB;EACnB,gBAAgB;EAChB,eAAe;EACf,yBAAyB;AAC3B;AAEA;EACE,cAAc;AAChB;;AAEA,SAAS;AACT;EACE,aAAa;EACb,sBAAsB;EACtB,mBAAmB;EACnB,uBAAuB;EACvB,aAAa;EACb,cAAc;AAChB;AAEA;EACE,WAAW;EACX,YAAY;EACZ,yCAAyC;EACzC,6BAA6B;EAC7B,kBAAkB;EAClB,kCAAkC;EAClC,mBAAmB;AACrB;;AAEA,UAAU;AACV;EACE,iCAAiC;AACnC;AAEA;EACE,kBAAkB;AACpB;AAEA;EACE,aAAa;EACb,SAAS;EACT,qBAAqB;EACrB,kBAAkB;AACpB;AAEA;EACE,WAAW;EACX,kBAAkB;EAClB,aAAa;EACb,SAAS;EACT,UAAU;EACV,yBAAyB;EACzB,wEAAwE;AAC1E;AAEA;EACE,aAAa;EACb,cAAc;EACd,kBAAkB;EAClB,qDAAqD;EACrD,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,eAAe;EACf,YAAY;EACZ,cAAc;EACd,UAAU;AACZ;AAEA;EACE,OAAO;AACT;AAEA;EACE,cAAc;EACd,mBAAmB;EACnB,qBAAqB;AACvB;AAEA;EACE,cAAc;EACd,kBAAkB;EAClB,kBAAkB;AACpB;;AAEA,WAAW;AACX;EACE,iCAAiC;AACnC;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,SAAS;EACT,mBAAmB;EACnB,oBAAoB;EACpB,iDAAiD;AACnD;AAEA;EACE,WAAW;EACX,YAAY;EACZ,kBAAkB;EAClB,qDAAqD;EACrD,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,iBAAiB;AACnB;AAEA;EACE,kBAAkB;EAClB,gBAAgB;EAChB,sBAAsB;AACxB;AAEA;EACE,cAAc;EACd,eAAe;AACjB;;AAEA,WAAW;AACX;EACE,aAAa;EACb,4DAA4D;EAC5D,SAAS;AACX;;AAEA,gBAAgB;AAChB;EACE,gBAAgB;AAClB;;AAEA,iBAAiB;AACjB;EACE,gBAAgB;AAClB;AAEA;EACE,mBAAmB;AACrB;AAEA;EACE,kCAAkC;EAClC,cAAc;EACd,wBAAwB;EACxB,mBAAmB;EACnB,kBAAkB;EAClB,gBAAgB;AAClB;AAEA;EACE,cAAc;EACd,kBAAkB;EAClB,8CAA8C;AAChD;AAEA;EACE,gBAAgB;EAChB,aAAa;EACb,cAAc;AAChB;AAEA;EACE,aAAa;EACb,aAAa;EACb,eAAe;AACjB;AAEA;EACE,uBAAuB;EACvB,mCAAmC;EACnC,cAAc;EACd,uBAAuB;EACvB,kBAAkB;EAClB,gBAAgB;AAClB;AAEA;EACE,cAAc;AAChB;AAEA;EACE,cAAc;AAChB;AAEA;EACE,mCAAmC;EACnC,cAAc;EACd,0BAA0B;EAC1B,sBAAsB;EACtB,mBAAmB;EACnB,gBAAgB;AAClB;AAEA;EACE,mBAAmB;AACrB;AAEA;EACE,mCAAmC;EACnC,cAAc;EACd,wBAAwB;EACxB,mBAAmB;EACnB,kBAAkB;EAClB,gBAAgB;AAClB;AAEA;EACE,cAAc;EACd,kBAAkB;EAClB,8CAA8C;AAChD;AAEA;EACE,gBAAgB;EAChB,aAAa;EACb,cAAc;AAChB;AAEA;EACE,cAAc;EACd,mBAAmB;EACnB,gBAAgB;EAChB,qBAAqB;EACrB,aAAa;EACb,mBAAmB;EACnB,YAAY;AACd;AAEA;EACE,gBAAgB;EAChB,SAAS;EACT,UAAU;AACZ;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,WAAW;EACX,mBAAmB;EACnB,eAAe;EACf,yBAAyB;EACzB,sBAAsB;EACtB,iBAAiB;AACnB;AAEA;EACE,oCAAoC;EACpC,oBAAoB;AACtB;AAEA;EACE,OAAO;EACP,mBAAmB;EACnB,cAAc;EACd,oBAAoB;EACpB,qBAAqB;EACrB,4BAA4B;EAC5B,gBAAgB;AAClB;AAEA;EACE,kBAAkB;EAClB,cAAc;EACd,mBAAmB;AACrB;AAEA;EACE,kCAAkC;EAClC,cAAc;EACd,0BAA0B;EAC1B,sBAAsB;EACtB,mBAAmB;EACnB,gBAAgB;EAChB,mBAAmB;AACrB;AAEA;EACE,cAAc;AAChB;AAEA;EACE,cAAc;AAChB;AAEA;EACE,cAAc;AAChB;;AAEA,aAAa;AACb;EACE,kBAAkB;AACpB;AAEA;EACE,aAAa;EACb,WAAW;EACX,iBAAiB;EACjB,eAAe;AACjB;AAEA;EACE,yBAAyB;EACzB,mCAAmC;EACnC,yCAAyC;EACzC,qBAAqB;EACrB,cAAc;EACd,eAAe;EACf,yBAAyB;EACzB,kBAAkB;EAClB,gBAAgB;EAChB,mBAAmB;AACrB;AAEA;EACE,mCAAmC;EACnC,qCAAqC;AACvC;AAEA;EACE,mCAAmC;EACnC,qCAAqC;EACrC,cAAc;AAChB;AAEA;EACE,mCAAmC;AACrC;AAEA;EACE,kCAAkC;EAClC,oCAAoC;EACpC,cAAc;AAChB;AAEA;EACE,kCAAkC;EAClC,oCAAoC;AACtC;AAEA;EACE,iCAAiC;EACjC,0CAA0C;EAC1C,sBAAsB;EACtB,aAAa;EACb,yBAAyB;EACzB,eAAe;AACjB;AAEA;EACE,qCAAqC;EACrC,2BAA2B;AAC7B;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,qBAAqB;AACvB;AAEA;EACE,gBAAgB;EAChB,aAAa;EACb,mBAAmB;EACnB,WAAW;EACX,iBAAiB;AACnB;AAEA;EACE,WAAW;EACX,WAAW;EACX,oCAAoC;EACpC,kBAAkB;EAClB,gBAAgB;AAClB;AAEA;EACE,YAAY;EACZ,oDAAoD;EACpD,2BAA2B;AAC7B;AAEA;EACE,cAAc;EACd,mBAAmB;EACnB,gBAAgB;EAChB,sBAAsB;EACtB,oBAAoB;EACpB,qBAAqB;EACrB,4BAA4B;EAC5B,gBAAgB;AAClB;AAEA;EACE,aAAa;EACb,qCAAqC;EACrC,WAAW;EACX,sBAAsB;AACxB;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,YAAY;EACZ,kBAAkB;EAClB,cAAc;AAChB;AAEA;EACE,aAAa;EACb,YAAY;EACZ,eAAe;EACf,sBAAsB;AACxB;AAEA;EACE,0BAA0B;EAC1B,mCAAmC;EACnC,cAAc;EACd,sBAAsB;EACtB,mBAAmB;AACrB;AAEA;EACE,oCAAoC;EACpC,cAAc;AAChB;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,kBAAkB;EAClB,cAAc;AAChB;AAEA;EACE,cAAc;AAChB;AAEA;EACE,0BAA0B;EAC1B,sBAAsB;EACtB,mBAAmB;EACnB,gBAAgB;AAClB;AAEA;EACE,kCAAkC;EAClC,cAAc;AAChB;AAEA;EACE,oCAAoC;EACpC,cAAc;AAChB;;AAEA,WAAW;AACX;EACE,iCAAiC;AACnC;AAEA;EACE,mBAAmB;AACrB;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,WAAW;EACX,mCAAmC;EACnC,yCAAyC;EACzC,qBAAqB;EACrB,uBAAuB;EACvB,cAAc;EACd,eAAe;EACf,yBAAyB;EACzB,qBAAqB;AACvB;AAEA;EACE,mCAAmC;AACrC;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,WAAW;EACX,iCAAiC;EACjC,0CAA0C;EAC1C,mBAAmB;EACnB,aAAa;EACb,2BAA2B;AAC7B;AAEA;EACE,WAAW;EACX,YAAY;EACZ,mBAAmB;EACnB,qDAAqD;EACrD,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,eAAe;EACf,cAAc;AAChB;AAEA;EACE,OAAO;AACT;AAEA;EACE,kBAAkB;EAClB,gBAAgB;EAChB,sBAAsB;AACxB;AAEA;EACE,aAAa;EACb,WAAW;EACX,eAAe;AACjB;AAEA;EACE,cAAc;EACd,mBAAmB;AACrB;AAEA;EACE,aAAa;EACb,YAAY;AACd;AAEA;EACE,uBAAuB;EACvB,mCAAmC;EACnC,yCAAyC;EACzC,qBAAqB;EACrB,cAAc;EACd,eAAe;EACf,yBAAyB;EACzB,mBAAmB;AACrB;AAEA;EACE,mCAAmC;AACrC;;AAEA,UAAU;AACV;EACE,aAAa;EACb,WAAW;EACX,mBAAmB;EACnB,iDAAiD;EACjD,oBAAoB;EACpB,gBAAgB;AAClB;AAEA;EACE,uBAAuB;EACvB,uBAAuB;EACvB,YAAY;EACZ,qBAAqB;EACrB,cAAc;EACd,eAAe;EACf,yBAAyB;EACzB,mBAAmB;EACnB,mBAAmB;AACrB;AAEA;EACE,mCAAmC;EACnC,cAAc;AAChB;AAEA;EACE,mCAAmC;EACnC,cAAc;AAChB;AAEA;EACE,cAAc;EACd,iCAAiC;AACnC;;AAEA,UAAU;AACV;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,qBAAqB;AACvB;AAEA;EACE,kBAAkB;EAClB,gBAAgB;AAClB;AAEA;EACE,uBAAuB;EACvB,kCAAkC;EAClC,wCAAwC;EACxC,qBAAqB;EACrB,cAAc;EACd,eAAe;EACf,yBAAyB;EACzB,eAAe;AACjB;AAEA;EACE,kCAAkC;AACpC;AAEA;EACE,aAAa;EACb,4DAA4D;EAC5D,SAAS;AACX;AAEA;EACE,iCAAiC;EACjC,0CAA0C;EAC1C,sBAAsB;EACtB,aAAa;EACb,yBAAyB;EACzB,eAAe;AACjB;AAEA;EACE,qCAAqC;EACrC,2BAA2B;AAC7B;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,qBAAqB;AACvB;AAEA;EACE,gBAAgB;EAChB,aAAa;EACb,mBAAmB;EACnB,WAAW;EACX,iBAAiB;AACnB;AAEA;EACE,aAAa;EACb,YAAY;AACd;AAEA;EACE,gBAAgB;EAChB,uBAAuB;EACvB,YAAY;EACZ,sBAAsB;EACtB,cAAc;EACd,eAAe;EACf,yBAAyB;AAC3B;AAEA;EACE,kCAAkC;EAClC,cAAc;AAChB;AAEA;EACE,cAAc;EACd,mBAAmB;EACnB,gBAAgB;AAClB;;AAEA,SAAS;AACT;EACE,aAAa;EACb,SAAS;EACT,mBAAmB;AACrB;;AAEA,WAAW;AACX;EACE,aAAa;EACb,SAAS;EACT,mBAAmB;EACnB,qBAAqB;EACrB,aAAa;EACb,iCAAiC;EACjC,0CAA0C;EAC1C,sBAAsB;EACtB,2BAA2B;AAC7B;AAEA;EACE,aAAa;EACb,YAAY;EACZ,mBAAmB;EACnB,8BAA8B;EAC9B,qBAAqB;EACrB,eAAe;AACjB;AAEA;EACE,aAAa;EACb,mBAAmB;AACrB;AAEA;EACE,cAAc;EACd,mBAAmB;EACnB,iBAAiB;AACnB;AAEA;EACE,eAAe;EACf,iCAAiC;EACjC,0CAA0C;EAC1C,qBAAqB;EACrB,cAAc;EACd,gBAAgB;EAChB,mBAAmB;AACrB;;AAEA,WAAW;AACX;EACE,mBAAmB;AACrB;AAEA;EACE,iCAAiC;EACjC,0CAA0C;EAC1C,sBAAsB;EACtB,aAAa;EACb,mBAAmB;EACnB,kBAAkB;EAClB,eAAe;EACf,yBAAyB;AAC3B;AAEA;EACE,qCAAqC;AACvC;AAEA;EACE,eAAe;AACjB;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,sBAAsB;AACxB;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,SAAS;AACX;AAEA;EACE,aAAa;EACb,cAAc;EACd,kBAAkB;EAClB,qDAAqD;EACrD,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,eAAe;AACjB;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;AACd;AAEA;EACE,gBAAgB;EAChB,mBAAmB;AACrB;AAEA;EACE,kBAAkB;EAClB,cAAc;AAChB;AAEA;EACE,mBAAmB;EACnB,cAAc;AAChB;AAEA;EACE,cAAc;EACd,gBAAgB;EAChB,qBAAqB;AACvB;AAEA;EACE,mBAAmB;EACnB,uBAAuB;EACvB,mCAAmC;EACnC,yCAAyC;EACzC,qBAAqB;EACrB,eAAe;EACf,yBAAyB;EACzB,iBAAiB;AACnB;AAEA;EACE,mCAAmC;EACnC,qCAAqC;AACvC;AAEA;EACE,mCAAmC;EACnC,qCAAqC;AACvC;AAEA;EACE,mBAAmB;EACnB,cAAc;EACd,gBAAgB;AAClB;AAEA;EACE,aAAa;EACb,gBAAgB;EAChB,gCAAgC;AAClC;AAEA;EACE,iBAAiB;EACjB,gBAAgB;AAClB;AAEA;EACE,WAAW;EACX,sFAAsF;EACtF,cAAc;AAChB;AAEA;EACE,iCAAiC;EACjC,0CAA0C;EAC1C,qBAAqB;EACrB,gBAAgB;EAChB,qBAAqB;EACrB,yBAAyB;AAC3B;AAEA;EACE,gBAAgB;AAClB;AAEA;EACE,oCAAoC;EACpC,kCAAkC;AACpC;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,qBAAqB;AACvB;AAEA;EACE,gBAAgB;EAChB,kBAAkB;EAClB,cAAc;AAChB;AAEA;EACE,kBAAkB;EAClB,cAAc;AAChB;AAEA;EACE,cAAc;EACd,gBAAgB;EAChB,iBAAiB;AACnB;;AAEA,WAAW;AACX;EACE,mBAAmB;AACrB;AAEA;EACE,iCAAiC;EACjC,0CAA0C;EAC1C,sBAAsB;EACtB,aAAa;EACb,mBAAmB;EACnB,yBAAyB;AAC3B;AAEA;EACE,qCAAqC;EACrC,2BAA2B;AAC7B;AAEA;EACE,aAAa;EACb,uBAAuB;EACvB,SAAS;EACT,sBAAsB;AACxB;AAEA;EACE,aAAa;EACb,cAAc;EACd,qBAAqB;EACrB,qDAAqD;EACrD,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,kBAAkB;EAClB,cAAc;AAChB;AAEA;EACE,OAAO;EACP,YAAY;AACd;AAEA;EACE,gBAAgB;EAChB,sBAAsB;EACtB,iBAAiB;EACjB,oBAAoB;EACpB,qBAAqB;EACrB,4BAA4B;EAC5B,gBAAgB;AAClB;AAEA;EACE,kBAAkB;EAClB,cAAc;EACd,qBAAqB;EACrB,qBAAqB;AACvB;AAEA;EACE,aAAa;EACb,SAAS;EACT,mBAAmB;EACnB,cAAc;AAChB;AAEA;EACE,cAAc;EACd,mBAAmB;EACnB,gBAAgB;EAChB,sBAAsB;EACtB,oBAAoB;EACpB,qBAAqB;EACrB,4BAA4B;EAC5B,gBAAgB;AAClB;AAEA;EACE,aAAa;EACb,WAAW;EACX,eAAe;AACjB;AAEA;EACE,uBAAuB;EACvB,mCAAmC;EACnC,cAAc;EACd,sBAAsB;EACtB,mBAAmB;AACrB;;AAEA,QAAQ;AACR;EACE,aAAa;EACb,sBAAsB;EACtB,mBAAmB;EACnB,uBAAuB;EACvB,aAAa;EACb,cAAc;EACd,kBAAkB;AACpB;AAEA;EACE,eAAe;EACf,mBAAmB;AACrB;;AAEA,OAAO;AACP;AACE;IACE,UAAU;IACV,2BAA2B;AAC7B;AACA;IACE,UAAU;IACV,wBAAwB;AAC1B;AACF;AAEA;AACE;IACE,yBAAyB;AAC3B;AACF;;AAEA,WAAW;AACX;EACE,iBAAiB;EACjB,cAAc;EACd,iCAAiC;AACnC;AAEA;EACE,kBAAkB;EAClB,mBAAmB;EACnB,aAAa;EACb,qFAAqF;EACrF,yCAAyC;EACzC,mBAAmB;EACnB,2BAA2B;AAC7B;AAEA;EACE,kBAAkB;EAClB,gBAAgB;EAChB,sBAAsB;EACtB,cAAc;AAChB;AAEA;EACE,cAAc;EACd,eAAe;EACf,gBAAgB;AAClB;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,WAAW;AACb;AAEA;EACE,iCAAiC;EACjC,0CAA0C;EAC1C,mBAAmB;EACnB,eAAe;EACf,2BAA2B;EAC3B,yBAAyB;AAC3B;AAEA;EACE,qCAAqC;EACrC,8CAA8C;AAChD;AAEA;EACE,kBAAkB;EAClB,gBAAgB;EAChB,mBAAmB;EACnB,cAAc;EACd,aAAa;EACb,mBAAmB;EACnB,WAAW;AACb;AAEA;EACE,aAAa;EACb,2DAA2D;EAC3D,WAAW;AACb;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,sBAAsB;EACtB,cAAc;AAChB;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,WAAW;AACb;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,WAAW;EACX,uBAAuB;EACvB,mCAAmC;EACnC,qBAAqB;EACrB,yBAAyB;AAC3B;AAEA;EACE,mCAAmC;EACnC,0BAA0B;AAC5B;AAEA;EACE,eAAe;AACjB;AAEA;EACE,aAAa;EACb,2DAA2D;EAC3D,SAAS;AACX;AAEA;EACE,aAAa;EACb,iCAAiC;EACjC,0CAA0C;EAC1C,sBAAsB;AACxB;AAEA;EACE,mBAAmB;EACnB,gBAAgB;EAChB,qBAAqB;EACrB,cAAc;AAChB;AAEA;EACE,cAAc;EACd,mBAAmB;EACnB,gBAAgB;AAClB;AAEA;EACE,aAAa;EACb,eAAe;EACf,WAAW;AACb;AAEA;EACE,wBAAwB;EACxB,kCAAkC;EAClC,cAAc;EACd,mBAAmB;EACnB,kBAAkB;EAClB,gBAAgB;AAClB;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;AACd;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,YAAY;EACZ,gBAAgB;EAChB,iCAAiC;EACjC,0CAA0C;EAC1C,qBAAqB;EACrB,yBAAyB;AAC3B;AAEA;EACE,mCAAmC;EACnC,qCAAqC;AACvC;AAEA;EACE,eAAe;EACf,cAAc;AAChB;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,SAAS;AACX;AAEA;EACE,aAAa;EACb,iCAAiC;EACjC,0CAA0C;EAC1C,sBAAsB;AACxB;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,qBAAqB;AACvB;AAEA;EACE,mCAAmC;EACnC,cAAc;EACd,wBAAwB;EACxB,mBAAmB;EACnB,kBAAkB;EAClB,gBAAgB;AAClB;AAEA;EACE,kBAAkB;EAClB,cAAc;AAChB;AAEA;EACE,gBAAgB;EAChB,sBAAsB;EACtB,cAAc;AAChB;AAEA;EACE,mBAAmB;EACnB,cAAc;EACd,gBAAgB;AAClB;AAEA;EACE,aAAa;EACb,2DAA2D;EAC3D,SAAS;AACX;AAEA;EACE,kBAAkB;EAClB,aAAa;EACb,mCAAmC;EACnC,sBAAsB;EACtB,yBAAyB;AAC3B;AAEA;EACE,mCAAmC;EACnC,2BAA2B;AAC7B;AAEA;EACE,iBAAiB;EACjB,gBAAgB;EAChB,cAAc;EACd,sBAAsB;AACxB;AAEA;EACE,kBAAkB;EAClB,cAAc;AAChB;AAEA;EACE,mBAAmB;EACnB,cAAc;EACd,kBAAkB;AACpB;;AAEA,UAAU;AACV;EACE,UAAU;AACZ;AAEA;EACE,iCAAiC;AACnC;AAEA;EACE,mCAAmC;EACnC,kBAAkB;AACpB;AAEA;EACE,mCAAmC;AACrC;;AAEA,UAAU;AACV;AACE;IACE,sBAAsB;AACxB;AAEA;IACE,WAAW;IACX,YAAY;IACZ,gBAAgB;AAClB;AAEA;IACE,aAAa;AACf;AAEA;;IAEE,0BAA0B;AAC5B;AAEA;IACE,sBAAsB;IACtB,WAAW;AACb;AAEA;IACE,WAAW;AACb;AAEA;IACE,sBAAsB;IACtB,uBAAuB;IACvB,SAAS;AACX;AAEA;IACE,WAAW;IACX,wBAAwB;AAC1B;AAEA;IACE,OAAO;AACT;AAEA;IACE,gBAAgB;AAClB;AACF","sourcesContent":["<template>\n  <div id=\"memory-app\">\n    <div class=\"memory-container\">\n      <!-- 侧边栏 -->\n      <div class=\"sidebar\">\n        <div class=\"sidebar-header\">\n          <div class=\"logo\">🧠 记忆查询系统</div>\n        </div>\n        \n        <div class=\"entity-types\">\n          <router-link to=\"/\" class=\"entity-type\" active-class=\"router-link-active\">\n            <div class=\"entity-icon\">🏠</div>\n            <div class=\"entity-name\">首页概览</div>\n          </router-link>\n          \n          <router-link to=\"/timeline\" class=\"entity-type\" active-class=\"router-link-active\">\n            <div class=\"entity-icon\">⏰</div>\n            <div class=\"entity-name\">时间轴</div>\n          </router-link>\n          \n          <router-link to=\"/user-profile\" class=\"entity-type\" active-class=\"router-link-active\">\n            <div class=\"entity-icon\">👤</div>\n            <div class=\"entity-name\">用户画像</div>\n          </router-link>\n          \n          <hr class=\"sidebar-divider\" />\n          \n          <router-link \n            v-for=\"entityType in entityTypes\" \n            :key=\"entityType.type\"\n            :to=\"`/entity/${entityType.type}`\"\n            class=\"entity-type\" \n            active-class=\"router-link-active\"\n          >\n            <div class=\"entity-icon\">{{ entityType.icon }}</div>\n            <div class=\"entity-name\">{{ entityType.name }}</div>\n            <div class=\"entity-count\">{{ entityType.count }}</div>\n          </router-link>\n        </div>\n      </div>\n\n      <!-- 主内容区 -->\n      <div class=\"main-content\">\n        <!-- 搜索头部 -->\n        <div class=\"search-header\">\n          <div class=\"search-box\">\n            <div class=\"search-icon\">🔍</div>\n            <input \n              type=\"text\" \n              class=\"search-input\" \n              placeholder=\"搜索任何内容、实体或关键词...\"\n              v-model=\"searchQuery\"\n              @input=\"handleSearchInput\"\n              @keypress.enter=\"handleSearch\"\n            />\n          </div>\n          <button class=\"filter-btn\" @click=\"handleSearch\">📊 搜索</button>\n          <button class=\"filter-btn\" @click=\"clearSearch\">🔄 重置</button>\n        </div>\n\n        <!-- 路由内容 -->\n        <router-view v-slot=\"{ Component }\">\n          <transition name=\"fade\" mode=\"out-in\">\n            <component :is=\"Component\" />\n          </transition>\n        </router-view>\n      </div>\n    </div>\n  </div>\n</template>\n\n<script setup lang=\"ts\">\nimport { ref, computed, onMounted } from 'vue';\nimport { useRouter } from 'vue-router';\nimport { useMemoryStore } from './memory-store';\n\n// 应用初始化逻辑\nconst store = useMemoryStore();\nconst router = useRouter();\nconst entityTypes = computed(() => store.entityTypes);\nconst searchQuery = ref('');\n\nconst handleSearchInput = () => {\n  if (searchQuery.value.length > 2) {\n    performSearch();\n  }\n};\n\nconst handleSearch = () => {\n  if (searchQuery.value.trim()) {\n    performSearch();\n  }\n};\n\nconst performSearch = () => {\n  if (searchQuery.value.trim().length >= 2) {\n    // 使用云端向量检索进行搜索\n    store.vectorSearchEntities(searchQuery.value);\n    router.push({ \n      path: '/search', \n      query: { q: searchQuery.value } \n    });\n  }\n};\n\nconst clearSearch = () => {\n  searchQuery.value = '';\n  store.searchQuery = '';\n  router.push('/');\n};\n\nonMounted(() => {\n  store.initialize();\n});\n</script>\n\n<style>\n/* 全局样式 */\n* {\n  margin: 0;\n  padding: 0;\n  box-sizing: border-box;\n}\n\nbody {\n  font-size: 1rem;\n  font-family: 'SF Pro Display', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;\n  background: linear-gradient(135deg, #0c0c0c 0%, #1a1a2e 50%, #16213e 100%);\n  color: #ffffff;\n  overflow-x: hidden;\n  min-height: 100vh;\n}\n\n.memory-container {\n  display: flex;\n  min-height: 100vh;\n  font-family: 'SF Pro Display', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;\n  background: linear-gradient(135deg, #0c0c0c 0%, #1a1a2e 50%, #16213e 100%);\n  color: #ffffff;\n  overflow-x: hidden;\n}\n\n.main-content {\n  flex: 1;\n  padding: 2rem;\n  overflow-y: auto;\n  height: 100vh;\n  max-height: 100vh;\n}\n\n/* 侧边栏样式 */\n.sidebar {\n  width: 280px;\n  background: rgba(15, 23, 42, 0.8);\n  backdrop-filter: blur(20px);\n  border-right: 1px solid rgba(148, 163, 184, 0.1);\n  padding: 2rem 0;\n  transition: all 0.3s ease;\n}\n\n.sidebar-header {\n  padding: 0 2rem 2rem;\n  border-bottom: 1px solid rgba(148, 163, 184, 0.1);\n}\n\n.logo {\n  font-size: 1.5rem;\n  font-weight: 700;\n  background: linear-gradient(135deg, #60a5fa, #a78bfa);\n  -webkit-background-clip: text;\n  -webkit-text-fill-color: transparent;\n  background-clip: text;\n}\n\n.entity-types {\n  padding: 1.5rem 0;\n}\n\n.entity-type {\n  display: flex;\n  align-items: center;\n  padding: 0.75rem 2rem;\n  margin: 0.25rem 0;\n  cursor: pointer;\n  transition: all 0.3s ease;\n  border-left: 3px solid transparent;\n  text-decoration: none;\n  color: inherit;\n}\n\n.entity-type:hover {\n  background: rgba(59, 130, 246, 0.1);\n  border-left-color: #60a5fa;\n}\n\n.entity-type.router-link-active {\n  background: rgba(59, 130, 246, 0.2);\n  border-left-color: #60a5fa;\n}\n\n.entity-icon {\n  width: 1.5rem;\n  height: 1.5rem;\n  margin-right: 0.75rem;\n  font-size: 1.2rem;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.entity-name {\n  font-weight: 500;\n  flex: 1;\n}\n\n.entity-count {\n  background: rgba(59, 130, 246, 0.2);\n  color: #60a5fa;\n  padding: 0.25rem 0.5rem;\n  border-radius: 0.75rem;\n  font-size: 0.75rem;\n  font-weight: 600;\n}\n\n.sidebar-divider {\n  margin: 1rem 0;\n  border: none;\n  border-top: 1px solid rgba(148, 163, 184, 0.1);\n}\n\n/* 搜索头部样式 */\n.search-header {\n  display: flex;\n  align-items: center;\n  gap: 1rem;\n  margin-bottom: 2rem;\n}\n\n.search-box {\n  flex: 1;\n  position: relative;\n}\n\n.search-input {\n  width: 100%;\n  padding: 0.75rem 1rem 0.75rem 3rem;\n  background: rgba(15, 23, 42, 0.6);\n  border: 1px solid rgba(148, 163, 184, 0.2);\n  border-radius: 0.75rem;\n  color: #ffffff;\n  font-size: 1rem;\n  transition: all 0.3s ease;\n}\n\n.search-input:focus {\n  outline: none;\n  border-color: #60a5fa;\n  box-shadow: 0 0 0 3px rgba(96, 165, 250, 0.1);\n}\n\n.search-input::placeholder {\n  color: #64748b;\n}\n\n.search-icon {\n  position: absolute;\n  left: 1rem;\n  top: 50%;\n  transform: translateY(-50%);\n  color: #64748b;\n}\n\n.filter-btn {\n  padding: 0.75rem 1.5rem;\n  background: rgba(59, 130, 246, 0.1);\n  border: 1px solid rgba(59, 130, 246, 0.3);\n  border-radius: 0.75rem;\n  color: #60a5fa;\n  cursor: pointer;\n  transition: all 0.3s ease;\n  white-space: nowrap;\n  border: none;\n}\n\n.filter-btn:hover {\n  background: rgba(59, 130, 246, 0.2);\n}\n\n/* 页面过渡动画 */\n.fade-enter-active, .fade-leave-active {\n  transition: opacity 0.3s ease;\n}\n\n.fade-enter-from, .fade-leave-to {\n  opacity: 0;\n}\n\n/* 概览样式 */\n.overview-section {\n  animation: fadeInUp 0.6s ease-out;\n}\n\n.greeting-card {\n  background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(147, 51, 234, 0.1));\n  border: 1px solid rgba(59, 130, 246, 0.2);\n  border-radius: 1rem;\n  padding: 2rem;\n  margin-bottom: 2rem;\n  backdrop-filter: blur(10px);\n}\n\n.greeting-title {\n  font-size: 1.5rem;\n  font-weight: 600;\n  margin-bottom: 1rem;\n  display: flex;\n  align-items: center;\n  gap: 0.5rem;\n}\n\n.greeting-content {\n  color: #cbd5e1;\n  line-height: 1.6;\n}\n\n.quick-summary {\n  list-style: none;\n  margin: 1rem 0;\n}\n\n.quick-summary li {\n  padding: 0.5rem 0;\n  border-left: 3px solid #60a5fa;\n  padding-left: 1rem;\n  margin: 0.5rem 0;\n}\n\n/* 内容网格 */\n.content-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));\n  gap: 1.5rem;\n  margin-bottom: 2rem;\n}\n\n.content-card {\n  background: rgba(15, 23, 42, 0.6);\n  border: 1px solid rgba(148, 163, 184, 0.1);\n  border-radius: 1rem;\n  padding: 1.5rem;\n  transition: all 0.3s ease;\n  backdrop-filter: blur(10px);\n  cursor: pointer;\n}\n\n.content-card:hover {\n  transform: translateY(-2px);\n  border-color: rgba(59, 130, 246, 0.3);\n  box-shadow: 0 8px 32px rgba(59, 130, 246, 0.1);\n}\n\n/* 实体网格布局 */\n.entities-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));\n  gap: 1rem;\n}\n\n.card-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 1rem;\n}\n\n.card-title {\n  font-size: 1.1rem;\n  font-weight: 600;\n  display: flex;\n  align-items: center;\n  gap: 0.5rem;\n}\n\n.card-badge {\n  background: rgba(59, 130, 246, 0.2);\n  color: #60a5fa;\n  padding: 0.25rem 0.75rem;\n  border-radius: 1rem;\n  font-size: 0.75rem;\n  font-weight: 500;\n}\n\n.card-content {\n  color: #cbd5e1;\n  line-height: 1.5;\n  margin-bottom: 1rem;\n}\n\n.info-list {\n  list-style: none;\n}\n\n.info-item {\n  display: flex;\n  align-items: center;\n  gap: 0.5rem;\n  padding: 0.5rem 0;\n  border-bottom: 1px solid rgba(148, 163, 184, 0.1);\n  transition: all 0.3s ease;\n}\n\n.info-item:hover {\n  background: rgba(59, 130, 246, 0.05);\n  border-radius: 0.5rem;\n  padding-left: 0.5rem;\n}\n\n.info-item:last-child {\n  border-bottom: none;\n}\n\n.info-time {\n  color: #64748b;\n  font-size: 0.875rem;\n  margin-left: auto;\n}\n\n.view-more-btn {\n  display: inline-flex;\n  align-items: center;\n  gap: 0.5rem;\n  color: #60a5fa;\n  font-size: 0.875rem;\n  font-weight: 500;\n  cursor: pointer;\n  transition: all 0.3s ease;\n}\n\n.view-more-btn:hover {\n  color: #93c5fd;\n}\n\n/* 加载动画 */\n.loading-container {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  padding: 3rem;\n  color: #94a3b8;\n}\n\n.loading-spinner {\n  width: 2rem;\n  height: 2rem;\n  border: 2px solid rgba(96, 165, 250, 0.3);\n  border-top: 2px solid #60a5fa;\n  border-radius: 50%;\n  animation: spin 1s linear infinite;\n  margin-bottom: 1rem;\n}\n\n/* 时间轴样式 */\n.timeline-view {\n  animation: fadeInUp 0.6s ease-out;\n}\n\n.timeline-container {\n  position: relative;\n}\n\n.timeline-item {\n  display: flex;\n  gap: 1rem;\n  margin-bottom: 1.5rem;\n  position: relative;\n}\n\n.timeline-item:not(:last-child)::before {\n  content: '';\n  position: absolute;\n  left: 1.25rem;\n  top: 3rem;\n  width: 2px;\n  height: calc(100% + 1rem);\n  background: linear-gradient(to bottom, #60a5fa, rgba(96, 165, 250, 0.3));\n}\n\n.timeline-dot {\n  width: 2.5rem;\n  height: 2.5rem;\n  border-radius: 50%;\n  background: linear-gradient(135deg, #60a5fa, #a78bfa);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 1rem;\n  color: white;\n  flex-shrink: 0;\n  z-index: 1;\n}\n\n.timeline-content {\n  flex: 1;\n}\n\n.timeline-time {\n  color: #64748b;\n  font-size: 0.875rem;\n  margin-bottom: 0.5rem;\n}\n\n.event-source {\n  color: #94a3b8;\n  font-size: 0.75rem;\n  margin-top: 0.5rem;\n}\n\n/* 实体详情样式 */\n.entity-detail {\n  animation: fadeInUp 0.6s ease-out;\n}\n\n.entity-header {\n  display: flex;\n  align-items: center;\n  gap: 1rem;\n  margin-bottom: 2rem;\n  padding-bottom: 1rem;\n  border-bottom: 1px solid rgba(148, 163, 184, 0.1);\n}\n\n.entity-avatar {\n  width: 3rem;\n  height: 3rem;\n  border-radius: 50%;\n  background: linear-gradient(135deg, #60a5fa, #a78bfa);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 1.5rem;\n}\n\n.entity-info h2 {\n  font-size: 1.75rem;\n  font-weight: 600;\n  margin-bottom: 0.25rem;\n}\n\n.entity-meta {\n  color: #64748b;\n  font-size: 1rem;\n}\n\n/* 实体网格样式 */\n.entities-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));\n  gap: 1rem;\n}\n\n/* Topic卡片特殊样式 */\n.topic-card {\n  min-height: auto;\n}\n\n/* Person卡片特殊样式 */\n.person-card {\n  min-height: auto;\n}\n\n.person-card-header {\n  margin-bottom: 1rem;\n}\n\n.person-card-badge {\n  background: rgba(34, 197, 94, 0.2);\n  color: #22c55e;\n  padding: 0.25rem 0.75rem;\n  border-radius: 1rem;\n  font-size: 0.75rem;\n  font-weight: 500;\n}\n\n.person-preview-section {\n  margin: 1rem 0;\n  padding: 0.75rem 0;\n  border-top: 1px solid rgba(148, 163, 184, 0.1);\n}\n\n.person-preview-section:first-of-type {\n  border-top: none;\n  margin-top: 0;\n  padding-top: 0;\n}\n\n.expertise-tags {\n  display: flex;\n  gap: 0.375rem;\n  flex-wrap: wrap;\n}\n\n.expertise-tag {\n  padding: 0.25rem 0.5rem;\n  background: rgba(147, 51, 234, 0.2);\n  color: #a78bfa;\n  border-radius: 0.375rem;\n  font-size: 0.75rem;\n  font-weight: 500;\n}\n\n.collaboration-item:hover .preview-content {\n  color: #60a5fa;\n}\n\n.message-item:hover .preview-content {\n  color: #60a5fa;\n}\n\n.team-indicator {\n  background: rgba(59, 130, 246, 0.2);\n  color: #60a5fa;\n  padding: 0.125rem 0.375rem;\n  border-radius: 0.25rem;\n  font-size: 0.625rem;\n  font-weight: 500;\n}\n\n.topic-card-header {\n  margin-bottom: 1rem;\n}\n\n.topic-card-badge {\n  background: rgba(59, 130, 246, 0.2);\n  color: #60a5fa;\n  padding: 0.25rem 0.75rem;\n  border-radius: 1rem;\n  font-size: 0.75rem;\n  font-weight: 500;\n}\n\n.topic-preview-section {\n  margin: 1rem 0;\n  padding: 0.75rem 0;\n  border-top: 1px solid rgba(148, 163, 184, 0.1);\n}\n\n.topic-preview-section:first-of-type {\n  border-top: none;\n  margin-top: 0;\n  padding-top: 0;\n}\n\n.preview-section-title {\n  color: #60a5fa;\n  font-size: 0.875rem;\n  font-weight: 600;\n  margin-bottom: 0.5rem;\n  display: flex;\n  align-items: center;\n  gap: 0.25rem;\n}\n\n.preview-list {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n\n.preview-item {\n  display: flex;\n  align-items: center;\n  gap: 0.5rem;\n  padding: 0.375rem 0;\n  cursor: pointer;\n  transition: all 0.3s ease;\n  border-radius: 0.25rem;\n  margin: 0.25rem 0;\n}\n\n.preview-item:hover {\n  background: rgba(59, 130, 246, 0.05);\n  padding-left: 0.5rem;\n}\n\n.preview-content {\n  flex: 1;\n  font-size: 0.875rem;\n  color: #cbd5e1;\n  display: -webkit-box;\n  -webkit-line-clamp: 1;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n}\n\n.preview-time {\n  font-size: 0.75rem;\n  color: #64748b;\n  white-space: nowrap;\n}\n\n.project-status {\n  background: rgba(34, 197, 94, 0.2);\n  color: #22c55e;\n  padding: 0.125rem 0.375rem;\n  border-radius: 0.25rem;\n  font-size: 0.625rem;\n  font-weight: 500;\n  white-space: nowrap;\n}\n\n.discussion-item:hover .preview-content {\n  color: #60a5fa;\n}\n\n.resource-item:hover .preview-content {\n  color: #60a5fa;\n}\n\n.project-item:hover .preview-content {\n  color: #60a5fa;\n}\n\n/* 项目卡片特殊样式 */\n.project-card {\n  position: relative;\n}\n\n.project-actions {\n  display: flex;\n  gap: 0.5rem;\n  margin: 0.75rem 0;\n  flex-wrap: wrap;\n}\n\n.project-action-btn {\n  padding: 0.375rem 0.75rem;\n  background: rgba(59, 130, 246, 0.1);\n  border: 1px solid rgba(59, 130, 246, 0.3);\n  border-radius: 0.5rem;\n  color: #60a5fa;\n  cursor: pointer;\n  transition: all 0.3s ease;\n  font-size: 0.75rem;\n  font-weight: 500;\n  white-space: nowrap;\n}\n\n.project-action-btn:hover {\n  background: rgba(59, 130, 246, 0.2);\n  border-color: rgba(59, 130, 246, 0.5);\n}\n\n.project-action-btn.highlight.active {\n  background: rgba(251, 191, 36, 0.2);\n  border-color: rgba(251, 191, 36, 0.5);\n  color: #f59e0b;\n}\n\n.project-action-btn.highlight.active:hover {\n  background: rgba(251, 191, 36, 0.3);\n}\n\n.project-action-btn.dashboard {\n  background: rgba(34, 197, 94, 0.1);\n  border-color: rgba(34, 197, 94, 0.3);\n  color: #22c55e;\n}\n\n.project-action-btn.dashboard:hover {\n  background: rgba(34, 197, 94, 0.2);\n  border-color: rgba(34, 197, 94, 0.5);\n}\n\n.entity-card {\n  background: rgba(15, 23, 42, 0.6);\n  border: 1px solid rgba(148, 163, 184, 0.1);\n  border-radius: 0.75rem;\n  padding: 1rem;\n  transition: all 0.3s ease;\n  cursor: pointer;\n}\n\n.entity-card:hover {\n  border-color: rgba(59, 130, 246, 0.3);\n  transform: translateY(-2px);\n}\n\n.entity-card-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 0.5rem;\n}\n\n.entity-card-title {\n  font-weight: 600;\n  display: flex;\n  align-items: center;\n  gap: 0.5rem;\n  font-size: 1.1rem;\n}\n\n.importance-indicator {\n  width: 60px;\n  height: 4px;\n  background: rgba(148, 163, 184, 0.2);\n  border-radius: 2px;\n  overflow: hidden;\n}\n\n.importance-bar {\n  height: 100%;\n  background: linear-gradient(90deg, #60a5fa, #a78bfa);\n  transition: width 0.3s ease;\n}\n\n.entity-description {\n  color: #cbd5e1;\n  font-size: 0.875rem;\n  line-height: 1.5;\n  margin-bottom: 0.75rem;\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n}\n\n.entity-stats {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 0.5rem;\n  margin-bottom: 0.75rem;\n}\n\n.stat-item {\n  display: flex;\n  align-items: center;\n  gap: 0.25rem;\n  font-size: 0.75rem;\n  color: #94a3b8;\n}\n\n.entity-tags {\n  display: flex;\n  gap: 0.25rem;\n  flex-wrap: wrap;\n  margin-bottom: 0.75rem;\n}\n\n.entity-tag {\n  padding: 0.125rem 0.375rem;\n  background: rgba(59, 130, 246, 0.2);\n  color: #60a5fa;\n  border-radius: 0.25rem;\n  font-size: 0.625rem;\n}\n\n.entity-tag.more-tags {\n  background: rgba(148, 163, 184, 0.2);\n  color: #94a3b8;\n}\n\n.entity-footer {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  font-size: 0.75rem;\n  color: #64748b;\n}\n\n.last-accessed {\n  color: #64748b;\n}\n\n.status-indicator {\n  padding: 0.125rem 0.375rem;\n  border-radius: 0.25rem;\n  font-size: 0.625rem;\n  font-weight: 500;\n}\n\n.status-indicator.active {\n  background: rgba(34, 197, 94, 0.2);\n  color: #22c55e;\n}\n\n.status-indicator.inactive {\n  background: rgba(148, 163, 184, 0.2);\n  color: #94a3b8;\n}\n\n/* 主题详情样式 */\n.topic-detail {\n  animation: fadeInUp 0.6s ease-out;\n}\n\n.detail-header {\n  margin-bottom: 2rem;\n}\n\n.back-btn {\n  display: flex;\n  align-items: center;\n  gap: 0.5rem;\n  background: rgba(59, 130, 246, 0.1);\n  border: 1px solid rgba(59, 130, 246, 0.3);\n  border-radius: 0.5rem;\n  padding: 0.75rem 1.5rem;\n  color: #60a5fa;\n  cursor: pointer;\n  transition: all 0.3s ease;\n  margin-bottom: 1.5rem;\n}\n\n.back-btn:hover {\n  background: rgba(59, 130, 246, 0.2);\n}\n\n.topic-header {\n  display: flex;\n  align-items: center;\n  gap: 1.5rem;\n  background: rgba(15, 23, 42, 0.6);\n  border: 1px solid rgba(148, 163, 184, 0.1);\n  border-radius: 1rem;\n  padding: 2rem;\n  backdrop-filter: blur(10px);\n}\n\n.topic-avatar {\n  width: 4rem;\n  height: 4rem;\n  border-radius: 1rem;\n  background: linear-gradient(135deg, #60a5fa, #a78bfa);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 2rem;\n  flex-shrink: 0;\n}\n\n.topic-info {\n  flex: 1;\n}\n\n.topic-info h2 {\n  font-size: 1.75rem;\n  font-weight: 600;\n  margin-bottom: 0.75rem;\n}\n\n.topic-meta {\n  display: flex;\n  gap: 1.5rem;\n  flex-wrap: wrap;\n}\n\n.meta-item {\n  color: #94a3b8;\n  font-size: 0.875rem;\n}\n\n.topic-actions {\n  display: flex;\n  gap: 0.75rem;\n}\n\n.action-btn {\n  padding: 0.75rem 1.5rem;\n  background: rgba(59, 130, 246, 0.1);\n  border: 1px solid rgba(59, 130, 246, 0.3);\n  border-radius: 0.5rem;\n  color: #60a5fa;\n  cursor: pointer;\n  transition: all 0.3s ease;\n  white-space: nowrap;\n}\n\n.action-btn:hover {\n  background: rgba(59, 130, 246, 0.2);\n}\n\n/* 选项卡样式 */\n.tab-navigation {\n  display: flex;\n  gap: 0.5rem;\n  margin-bottom: 2rem;\n  border-bottom: 1px solid rgba(148, 163, 184, 0.1);\n  padding-bottom: 1rem;\n  overflow-x: auto;\n}\n\n.tab-btn {\n  padding: 0.75rem 1.5rem;\n  background: transparent;\n  border: none;\n  border-radius: 0.5rem;\n  color: #94a3b8;\n  cursor: pointer;\n  transition: all 0.3s ease;\n  white-space: nowrap;\n  font-size: 0.875rem;\n}\n\n.tab-btn.active {\n  background: rgba(59, 130, 246, 0.2);\n  color: #60a5fa;\n}\n\n.tab-btn:hover:not(.active) {\n  background: rgba(59, 130, 246, 0.1);\n  color: #93c5fd;\n}\n\n.tab-content {\n  display: block;\n  animation: fadeInUp 0.4s ease-out;\n}\n\n/* 列表项样式 */\n.section-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 1.5rem;\n}\n\n.section-header h3 {\n  font-size: 1.25rem;\n  font-weight: 600;\n}\n\n.add-btn {\n  padding: 0.75rem 1.5rem;\n  background: rgba(34, 197, 94, 0.1);\n  border: 1px solid rgba(34, 197, 94, 0.3);\n  border-radius: 0.5rem;\n  color: #22c55e;\n  cursor: pointer;\n  transition: all 0.3s ease;\n  font-size: 1rem;\n}\n\n.add-btn:hover {\n  background: rgba(34, 197, 94, 0.2);\n}\n\n.items-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));\n  gap: 1rem;\n}\n\n.item-card {\n  background: rgba(15, 23, 42, 0.6);\n  border: 1px solid rgba(148, 163, 184, 0.1);\n  border-radius: 0.75rem;\n  padding: 1rem;\n  transition: all 0.3s ease;\n  cursor: pointer;\n}\n\n.item-card:hover {\n  border-color: rgba(59, 130, 246, 0.3);\n  transform: translateY(-2px);\n}\n\n.item-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 0.5rem;\n}\n\n.item-title {\n  font-weight: 600;\n  display: flex;\n  align-items: center;\n  gap: 0.5rem;\n  font-size: 1.1rem;\n}\n\n.item-actions {\n  display: flex;\n  gap: 0.25rem;\n}\n\n.item-action {\n  padding: 0.25rem;\n  background: transparent;\n  border: none;\n  border-radius: 0.25rem;\n  color: #94a3b8;\n  cursor: pointer;\n  transition: all 0.3s ease;\n}\n\n.item-action:hover {\n  background: rgba(239, 68, 68, 0.1);\n  color: #ef4444;\n}\n\n.item-content {\n  color: #cbd5e1;\n  font-size: 0.875rem;\n  line-height: 1.5;\n}\n\n/* 搜索控件 */\n.search-controls {\n  display: flex;\n  gap: 1rem;\n  align-items: center;\n}\n\n/* 搜索过滤控件 */\n.search-filter-controls {\n  display: flex;\n  gap: 1rem;\n  align-items: center;\n  margin-bottom: 1.5rem;\n  padding: 1rem;\n  background: rgba(15, 23, 42, 0.6);\n  border: 1px solid rgba(148, 163, 184, 0.1);\n  border-radius: 0.75rem;\n  backdrop-filter: blur(10px);\n}\n\n.filter-controls {\n  display: flex;\n  gap: 0.75rem;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 1.5rem;\n  flex-wrap: wrap;\n}\n\n.filter-select-wrapper {\n  display: flex;\n  align-items: center;\n}\n\n.results-count {\n  color: #94a3b8;\n  font-size: 0.875rem;\n  margin-left: auto;\n}\n\n.filter-select {\n  padding: 0.5rem;\n  background: rgba(15, 23, 42, 0.6);\n  border: 1px solid rgba(148, 163, 184, 0.2);\n  border-radius: 0.5rem;\n  color: #ffffff;\n  min-width: 120px;\n  font-size: 0.875rem;\n}\n\n/* 聊天记录样式 */\n.conversations-list {\n  margin-bottom: 2rem;\n}\n\n.conversation-item {\n  background: rgba(15, 23, 42, 0.6);\n  border: 1px solid rgba(148, 163, 184, 0.1);\n  border-radius: 0.75rem;\n  padding: 1rem;\n  margin-bottom: 1rem;\n  position: relative;\n  cursor: pointer;\n  transition: all 0.3s ease;\n}\n\n.conversation-item:hover {\n  border-color: rgba(59, 130, 246, 0.3);\n}\n\n.conversation-item.expanded {\n  cursor: default;\n}\n\n.conversation-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 0.75rem;\n}\n\n.conversation-meta {\n  display: flex;\n  align-items: center;\n  gap: 1rem;\n}\n\n.sender-avatar {\n  width: 2.5rem;\n  height: 2.5rem;\n  border-radius: 50%;\n  background: linear-gradient(135deg, #60a5fa, #a78bfa);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 1rem;\n}\n\n.sender-info {\n  display: flex;\n  flex-direction: column;\n  gap: 0.25rem;\n}\n\n.sender-name {\n  font-weight: 600;\n  font-size: 0.875rem;\n}\n\n.group-name {\n  font-size: 0.75rem;\n  color: #94a3b8;\n}\n\n.conversation-time {\n  font-size: 0.875rem;\n  color: #64748b;\n}\n\n.conversation-summary {\n  color: #cbd5e1;\n  line-height: 1.5;\n  margin-bottom: 0.5rem;\n}\n\n.context-indicator {\n  margin-top: 0.75rem;\n  padding: 0.5rem 0.75rem;\n  background: rgba(59, 130, 246, 0.1);\n  border: 1px solid rgba(59, 130, 246, 0.3);\n  border-radius: 0.5rem;\n  cursor: pointer;\n  transition: all 0.3s ease;\n  user-select: none;\n}\n\n.context-indicator:hover {\n  background: rgba(59, 130, 246, 0.2);\n  border-color: rgba(59, 130, 246, 0.5);\n}\n\n.context-indicator.expanded {\n  background: rgba(59, 130, 246, 0.2);\n  border-color: rgba(59, 130, 246, 0.4);\n}\n\n.indicator-text {\n  font-size: 0.875rem;\n  color: #60a5fa;\n  font-weight: 500;\n}\n\n.context-content {\n  max-height: 0;\n  overflow: hidden;\n  transition: max-height 0.3s ease;\n}\n\n.context-content.expanded {\n  max-height: 500px;\n  overflow-y: auto;\n}\n\n.context-divider {\n  height: 1px;\n  background: linear-gradient(90deg, transparent, rgba(148, 163, 184, 0.3), transparent);\n  margin: 1rem 0;\n}\n\n.context-item {\n  background: rgba(30, 41, 59, 0.4);\n  border: 1px solid rgba(148, 163, 184, 0.1);\n  border-radius: 0.5rem;\n  padding: 0.75rem;\n  margin-bottom: 0.5rem;\n  transition: all 0.3s ease;\n}\n\n.context-item:last-child {\n  margin-bottom: 0;\n}\n\n.context-item.main-message {\n  border-color: rgba(34, 197, 94, 0.3);\n  background: rgba(34, 197, 94, 0.1);\n}\n\n.context-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 0.5rem;\n}\n\n.context-sender {\n  font-weight: 600;\n  font-size: 0.75rem;\n  color: #e2e8f0;\n}\n\n.context-time {\n  font-size: 0.75rem;\n  color: #94a3b8;\n}\n\n.context-content-text {\n  color: #cbd5e1;\n  line-height: 1.4;\n  font-size: 0.8rem;\n}\n\n/* 网页记录样式 */\n.webpages-list {\n  margin-bottom: 2rem;\n}\n\n.webpage-item {\n  background: rgba(15, 23, 42, 0.6);\n  border: 1px solid rgba(148, 163, 184, 0.1);\n  border-radius: 0.75rem;\n  padding: 1rem;\n  margin-bottom: 1rem;\n  transition: all 0.3s ease;\n}\n\n.webpage-item:hover {\n  border-color: rgba(59, 130, 246, 0.3);\n  transform: translateY(-1px);\n}\n\n.webpage-header {\n  display: flex;\n  align-items: flex-start;\n  gap: 1rem;\n  margin-bottom: 0.75rem;\n}\n\n.webpage-icon {\n  width: 2.5rem;\n  height: 2.5rem;\n  border-radius: 0.5rem;\n  background: linear-gradient(135deg, #60a5fa, #a78bfa);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 1.25rem;\n  flex-shrink: 0;\n}\n\n.webpage-info {\n  flex: 1;\n  min-width: 0;\n}\n\n.webpage-title {\n  font-weight: 600;\n  margin-bottom: 0.25rem;\n  font-size: 1.1rem;\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n}\n\n.webpage-url {\n  font-size: 0.75rem;\n  color: #60a5fa;\n  margin-bottom: 0.5rem;\n  word-break: break-all;\n}\n\n.webpage-meta {\n  display: flex;\n  gap: 1rem;\n  font-size: 0.875rem;\n  color: #94a3b8;\n}\n\n.webpage-content {\n  color: #cbd5e1;\n  font-size: 0.875rem;\n  line-height: 1.5;\n  margin-bottom: 0.75rem;\n  display: -webkit-box;\n  -webkit-line-clamp: 3;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n}\n\n.webpage-tags {\n  display: flex;\n  gap: 0.5rem;\n  flex-wrap: wrap;\n}\n\n.webpage-tag {\n  padding: 0.25rem 0.5rem;\n  background: rgba(59, 130, 246, 0.2);\n  color: #60a5fa;\n  border-radius: 0.25rem;\n  font-size: 0.875rem;\n}\n\n/* 空状态 */\n.empty-state {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  padding: 3rem;\n  color: #94a3b8;\n  text-align: center;\n}\n\n.empty-state span {\n  font-size: 3rem;\n  margin-bottom: 1rem;\n}\n\n/* 动画 */\n@keyframes fadeInUp {\n  from {\n    opacity: 0;\n    transform: translateY(20px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n\n@keyframes spin {\n  to {\n    transform: rotate(360deg);\n  }\n}\n\n/* 用户画像样式 */\n.user-profile-section {\n  max-width: 1200px;\n  margin: 0 auto;\n  animation: fadeInUp 0.6s ease-out;\n}\n\n.profile-header {\n  text-align: center;\n  margin-bottom: 2rem;\n  padding: 2rem;\n  background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(147, 51, 234, 0.1));\n  border: 1px solid rgba(59, 130, 246, 0.2);\n  border-radius: 1rem;\n  backdrop-filter: blur(10px);\n}\n\n.profile-header h2 {\n  font-size: 1.75rem;\n  font-weight: 600;\n  margin-bottom: 0.75rem;\n  color: #ffffff;\n}\n\n.profile-header p {\n  color: #cbd5e1;\n  font-size: 1rem;\n  line-height: 1.6;\n}\n\n.profile-content {\n  display: flex;\n  flex-direction: column;\n  gap: 1.5rem;\n}\n\n.profile-card {\n  background: rgba(15, 23, 42, 0.6);\n  border: 1px solid rgba(148, 163, 184, 0.1);\n  border-radius: 1rem;\n  padding: 1.5rem;\n  backdrop-filter: blur(10px);\n  transition: all 0.3s ease;\n}\n\n.profile-card:hover {\n  border-color: rgba(59, 130, 246, 0.3);\n  box-shadow: 0 8px 32px rgba(59, 130, 246, 0.1);\n}\n\n.profile-card h3 {\n  font-size: 1.25rem;\n  font-weight: 600;\n  margin-bottom: 1rem;\n  color: #60a5fa;\n  display: flex;\n  align-items: center;\n  gap: 0.5rem;\n}\n\n.interest-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));\n  gap: 1.5rem;\n}\n\n.interest-category h4 {\n  font-size: 1rem;\n  font-weight: 600;\n  margin-bottom: 0.75rem;\n  color: #e2e8f0;\n}\n\n.interest-list {\n  display: flex;\n  flex-direction: column;\n  gap: 0.5rem;\n}\n\n.interest-item {\n  display: flex;\n  align-items: center;\n  gap: 0.5rem;\n  padding: 0.5rem 0.75rem;\n  background: rgba(59, 130, 246, 0.1);\n  border-radius: 0.5rem;\n  transition: all 0.3s ease;\n}\n\n.interest-item:hover {\n  background: rgba(59, 130, 246, 0.2);\n  transform: translateX(4px);\n}\n\n.interest-icon {\n  font-size: 1rem;\n}\n\n.insights-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));\n  gap: 1rem;\n}\n\n.insight-item {\n  padding: 1rem;\n  background: rgba(30, 41, 59, 0.4);\n  border: 1px solid rgba(148, 163, 184, 0.1);\n  border-radius: 0.75rem;\n}\n\n.insight-item h4 {\n  font-size: 0.875rem;\n  font-weight: 600;\n  margin-bottom: 0.5rem;\n  color: #60a5fa;\n}\n\n.insight-item p {\n  color: #cbd5e1;\n  font-size: 0.875rem;\n  line-height: 1.5;\n}\n\n.tag-list {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 0.5rem;\n}\n\n.focus-tag {\n  padding: 0.25rem 0.75rem;\n  background: rgba(34, 197, 94, 0.2);\n  color: #22c55e;\n  border-radius: 1rem;\n  font-size: 0.75rem;\n  font-weight: 500;\n}\n\n.suggestions-list {\n  display: flex;\n  flex-direction: column;\n  gap: 0.75rem;\n}\n\n.suggestion-item {\n  display: flex;\n  align-items: center;\n  gap: 0.75rem;\n  padding: 0.75rem;\n  background: rgba(30, 41, 59, 0.4);\n  border: 1px solid rgba(148, 163, 184, 0.1);\n  border-radius: 0.5rem;\n  transition: all 0.3s ease;\n}\n\n.suggestion-item:hover {\n  background: rgba(59, 130, 246, 0.1);\n  border-color: rgba(59, 130, 246, 0.3);\n}\n\n.suggestion-icon {\n  font-size: 1rem;\n  color: #60a5fa;\n}\n\n.predictions-list {\n  display: flex;\n  flex-direction: column;\n  gap: 1rem;\n}\n\n.prediction-item {\n  padding: 1rem;\n  background: rgba(30, 41, 59, 0.4);\n  border: 1px solid rgba(148, 163, 184, 0.1);\n  border-radius: 0.75rem;\n}\n\n.prediction-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 0.5rem;\n}\n\n.prediction-type {\n  background: rgba(147, 51, 234, 0.2);\n  color: #a78bfa;\n  padding: 0.25rem 0.75rem;\n  border-radius: 1rem;\n  font-size: 0.75rem;\n  font-weight: 500;\n}\n\n.prediction-confidence {\n  font-size: 0.75rem;\n  color: #94a3b8;\n}\n\n.prediction-name {\n  font-weight: 600;\n  margin-bottom: 0.25rem;\n  color: #e2e8f0;\n}\n\n.prediction-reason {\n  font-size: 0.875rem;\n  color: #94a3b8;\n  line-height: 1.4;\n}\n\n.stats-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));\n  gap: 1rem;\n}\n\n.stat-card {\n  text-align: center;\n  padding: 1rem;\n  background: rgba(59, 130, 246, 0.1);\n  border-radius: 0.75rem;\n  transition: all 0.3s ease;\n}\n\n.stat-card:hover {\n  background: rgba(59, 130, 246, 0.2);\n  transform: translateY(-2px);\n}\n\n.stat-value {\n  font-size: 1.5rem;\n  font-weight: 700;\n  color: #60a5fa;\n  margin-bottom: 0.25rem;\n}\n\n.stat-label {\n  font-size: 0.75rem;\n  color: #94a3b8;\n}\n\n.empty-hint {\n  font-size: 0.875rem;\n  color: #94a3b8;\n  margin-top: 0.5rem;\n}\n\n/* 滚动条样式 */\n::-webkit-scrollbar {\n  width: 8px;\n}\n\n::-webkit-scrollbar-track {\n  background: rgba(15, 23, 42, 0.3);\n}\n\n::-webkit-scrollbar-thumb {\n  background: rgba(59, 130, 246, 0.3);\n  border-radius: 4px;\n}\n\n::-webkit-scrollbar-thumb:hover {\n  background: rgba(59, 130, 246, 0.5);\n}\n\n/* 响应式设计 */\n@media (max-width: 768px) {\n  .memory-container {\n    flex-direction: column;\n  }\n\n  .sidebar {\n    width: 100%;\n    height: auto;\n    position: static;\n  }\n\n  .main-content {\n    padding: 1rem;\n  }\n\n  .content-grid,\n  .entities-grid {\n    grid-template-columns: 1fr;\n  }\n\n  .search-header {\n    flex-direction: column;\n    gap: 0.5rem;\n  }\n\n  .search-box {\n    width: 100%;\n  }\n\n  .topic-header {\n    flex-direction: column;\n    align-items: flex-start;\n    gap: 1rem;\n  }\n\n  .topic-actions {\n    width: 100%;\n    justify-content: stretch;\n  }\n\n  .action-btn {\n    flex: 1;\n  }\n\n  .tab-navigation {\n    overflow-x: auto;\n  }\n}\n</style>"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 6314:
/***/ ((module) => {

"use strict";


/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
module.exports = function (cssWithMappingToString) {
  var list = [];

  // return the list of modules as css string
  list.toString = function toString() {
    return this.map(function (item) {
      var content = "";
      var needLayer = typeof item[5] !== "undefined";
      if (item[4]) {
        content += "@supports (".concat(item[4], ") {");
      }
      if (item[2]) {
        content += "@media ".concat(item[2], " {");
      }
      if (needLayer) {
        content += "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {");
      }
      content += cssWithMappingToString(item);
      if (needLayer) {
        content += "}";
      }
      if (item[2]) {
        content += "}";
      }
      if (item[4]) {
        content += "}";
      }
      return content;
    }).join("");
  };

  // import a list of modules into the list
  list.i = function i(modules, media, dedupe, supports, layer) {
    if (typeof modules === "string") {
      modules = [[null, modules, undefined]];
    }
    var alreadyImportedModules = {};
    if (dedupe) {
      for (var k = 0; k < this.length; k++) {
        var id = this[k][0];
        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }
    for (var _k = 0; _k < modules.length; _k++) {
      var item = [].concat(modules[_k]);
      if (dedupe && alreadyImportedModules[item[0]]) {
        continue;
      }
      if (typeof layer !== "undefined") {
        if (typeof item[5] === "undefined") {
          item[5] = layer;
        } else {
          item[1] = "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {").concat(item[1], "}");
          item[5] = layer;
        }
      }
      if (media) {
        if (!item[2]) {
          item[2] = media;
        } else {
          item[1] = "@media ".concat(item[2], " {").concat(item[1], "}");
          item[2] = media;
        }
      }
      if (supports) {
        if (!item[4]) {
          item[4] = "".concat(supports);
        } else {
          item[1] = "@supports (".concat(item[4], ") {").concat(item[1], "}");
          item[4] = supports;
        }
      }
      list.push(item);
    }
  };
  return list;
};

/***/ }),

/***/ 1354:
/***/ ((module) => {

"use strict";


module.exports = function (item) {
  var content = item[1];
  var cssMapping = item[3];
  if (!cssMapping) {
    return content;
  }
  if (typeof btoa === "function") {
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(cssMapping))));
    var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
    var sourceMapping = "/*# ".concat(data, " */");
    return [content].concat([sourceMapping]).join("\n");
  }
  return [content].join("\n");
};

/***/ }),

/***/ 6262:
/***/ ((__unused_webpack_module, exports) => {

"use strict";
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
// runtime helper for setting properties on components
// in a tree-shakable way
exports.A = (sfc, props) => {
    const target = sfc.__vccOpts || sfc;
    for (const [key, val] of props) {
        target[key] = val;
    }
    return target;
};


/***/ }),

/***/ 3299:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(6802);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.id, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = (__webpack_require__(534)/* ["default"] */ .A)
var update = add("7385b6d4", content, false, {});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ 4816:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(6165);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.id, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = (__webpack_require__(534)/* ["default"] */ .A)
var update = add("8c511644", content, false, {});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ 2325:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(3438);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.id, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = (__webpack_require__(534)/* ["default"] */ .A)
var update = add("3f7e6576", content, false, {});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ 534:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  A: () => (/* binding */ addStylesClient)
});

;// CONCATENATED MODULE: ./node_modules/vue-style-loader/lib/listToStyles.js
/**
 * Translates the list format produced by css-loader into something
 * easier to manipulate.
 */
function listToStyles (parentId, list) {
  var styles = []
  var newStyles = {}
  for (var i = 0; i < list.length; i++) {
    var item = list[i]
    var id = item[0]
    var css = item[1]
    var media = item[2]
    var sourceMap = item[3]
    var part = {
      id: parentId + ':' + i,
      css: css,
      media: media,
      sourceMap: sourceMap
    }
    if (!newStyles[id]) {
      styles.push(newStyles[id] = { id: id, parts: [part] })
    } else {
      newStyles[id].parts.push(part)
    }
  }
  return styles
}

;// CONCATENATED MODULE: ./node_modules/vue-style-loader/lib/addStylesClient.js
/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
  Modified by Evan You @yyx990803
*/



var hasDocument = typeof document !== 'undefined'

if (typeof DEBUG !== 'undefined' && DEBUG) {
  if (!hasDocument) {
    throw new Error(
    'vue-style-loader cannot be used in a non-browser environment. ' +
    "Use { target: 'node' } in your Webpack config to indicate a server-rendering environment."
  ) }
}

/*
type StyleObject = {
  id: number;
  parts: Array<StyleObjectPart>
}

type StyleObjectPart = {
  css: string;
  media: string;
  sourceMap: ?string
}
*/

var stylesInDom = {/*
  [id: number]: {
    id: number,
    refs: number,
    parts: Array<(obj?: StyleObjectPart) => void>
  }
*/}

var head = hasDocument && (document.head || document.getElementsByTagName('head')[0])
var singletonElement = null
var singletonCounter = 0
var isProduction = false
var noop = function () {}
var options = null
var ssrIdKey = 'data-vue-ssr-id'

// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
// tags it will allow on a page
var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase())

function addStylesClient (parentId, list, _isProduction, _options) {
  isProduction = _isProduction

  options = _options || {}

  var styles = listToStyles(parentId, list)
  addStylesToDom(styles)

  return function update (newList) {
    var mayRemove = []
    for (var i = 0; i < styles.length; i++) {
      var item = styles[i]
      var domStyle = stylesInDom[item.id]
      domStyle.refs--
      mayRemove.push(domStyle)
    }
    if (newList) {
      styles = listToStyles(parentId, newList)
      addStylesToDom(styles)
    } else {
      styles = []
    }
    for (var i = 0; i < mayRemove.length; i++) {
      var domStyle = mayRemove[i]
      if (domStyle.refs === 0) {
        for (var j = 0; j < domStyle.parts.length; j++) {
          domStyle.parts[j]()
        }
        delete stylesInDom[domStyle.id]
      }
    }
  }
}

function addStylesToDom (styles /* Array<StyleObject> */) {
  for (var i = 0; i < styles.length; i++) {
    var item = styles[i]
    var domStyle = stylesInDom[item.id]
    if (domStyle) {
      domStyle.refs++
      for (var j = 0; j < domStyle.parts.length; j++) {
        domStyle.parts[j](item.parts[j])
      }
      for (; j < item.parts.length; j++) {
        domStyle.parts.push(addStyle(item.parts[j]))
      }
      if (domStyle.parts.length > item.parts.length) {
        domStyle.parts.length = item.parts.length
      }
    } else {
      var parts = []
      for (var j = 0; j < item.parts.length; j++) {
        parts.push(addStyle(item.parts[j]))
      }
      stylesInDom[item.id] = { id: item.id, refs: 1, parts: parts }
    }
  }
}

function createStyleElement () {
  var styleElement = document.createElement('style')
  styleElement.type = 'text/css'
  head.appendChild(styleElement)
  return styleElement
}

function addStyle (obj /* StyleObjectPart */) {
  var update, remove
  var styleElement = document.querySelector('style[' + ssrIdKey + '~="' + obj.id + '"]')

  if (styleElement) {
    if (isProduction) {
      // has SSR styles and in production mode.
      // simply do nothing.
      return noop
    } else {
      // has SSR styles but in dev mode.
      // for some reason Chrome can't handle source map in server-rendered
      // style tags - source maps in <style> only works if the style tag is
      // created and inserted dynamically. So we remove the server rendered
      // styles and inject new ones.
      styleElement.parentNode.removeChild(styleElement)
    }
  }

  if (isOldIE) {
    // use singleton mode for IE9.
    var styleIndex = singletonCounter++
    styleElement = singletonElement || (singletonElement = createStyleElement())
    update = applyToSingletonTag.bind(null, styleElement, styleIndex, false)
    remove = applyToSingletonTag.bind(null, styleElement, styleIndex, true)
  } else {
    // use multi-style-tag mode in all other cases
    styleElement = createStyleElement()
    update = applyToTag.bind(null, styleElement)
    remove = function () {
      styleElement.parentNode.removeChild(styleElement)
    }
  }

  update(obj)

  return function updateStyle (newObj /* StyleObjectPart */) {
    if (newObj) {
      if (newObj.css === obj.css &&
          newObj.media === obj.media &&
          newObj.sourceMap === obj.sourceMap) {
        return
      }
      update(obj = newObj)
    } else {
      remove()
    }
  }
}

var replaceText = (function () {
  var textStore = []

  return function (index, replacement) {
    textStore[index] = replacement
    return textStore.filter(Boolean).join('\n')
  }
})()

function applyToSingletonTag (styleElement, index, remove, obj) {
  var css = remove ? '' : obj.css

  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = replaceText(index, css)
  } else {
    var cssNode = document.createTextNode(css)
    var childNodes = styleElement.childNodes
    if (childNodes[index]) styleElement.removeChild(childNodes[index])
    if (childNodes.length) {
      styleElement.insertBefore(cssNode, childNodes[index])
    } else {
      styleElement.appendChild(cssNode)
    }
  }
}

function applyToTag (styleElement, obj) {
  var css = obj.css
  var media = obj.media
  var sourceMap = obj.sourceMap

  if (media) {
    styleElement.setAttribute('media', media)
  }
  if (options.ssrId) {
    styleElement.setAttribute(ssrIdKey, obj.id)
  }

  if (sourceMap) {
    // https://developer.chrome.com/devtools/docs/javascript-debugging
    // this makes source maps inside style tags work properly in Chrome
    css += '\n/*# sourceURL=' + sourceMap.sources[0] + ' */'
    // http://stackoverflow.com/a/26603875
    css += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + ' */'
  }

  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild)
    }
    styleElement.appendChild(document.createTextNode(css))
  }
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";

// UNUSED EXPORTS: default

;// CONCATENATED MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
/**
* @vue/shared v3.5.20
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function shared_esm_bundler_makeMap(str) {
  const map = /* @__PURE__ */ Object.create(null);
  for (const key of str.split(",")) map[key] = 1;
  return (val) => val in map;
}

const shared_esm_bundler_EMPTY_OBJ =  false ? 0 : {};
const EMPTY_ARR =  false ? 0 : [];
const shared_esm_bundler_NOOP = () => {
};
const NO = () => false;
const shared_esm_bundler_isOn = (key) => key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && // uppercase letter
(key.charCodeAt(2) > 122 || key.charCodeAt(2) < 97);
const isModelListener = (key) => key.startsWith("onUpdate:");
const shared_esm_bundler_extend = Object.assign;
const remove = (arr, el) => {
  const i = arr.indexOf(el);
  if (i > -1) {
    arr.splice(i, 1);
  }
};
const shared_esm_bundler_hasOwnProperty = Object.prototype.hasOwnProperty;
const hasOwn = (val, key) => shared_esm_bundler_hasOwnProperty.call(val, key);
const shared_esm_bundler_isArray = Array.isArray;
const isMap = (val) => toTypeString(val) === "[object Map]";
const shared_esm_bundler_isSet = (val) => toTypeString(val) === "[object Set]";
const isDate = (val) => toTypeString(val) === "[object Date]";
const isRegExp = (val) => toTypeString(val) === "[object RegExp]";
const shared_esm_bundler_isFunction = (val) => typeof val === "function";
const shared_esm_bundler_isString = (val) => typeof val === "string";
const shared_esm_bundler_isSymbol = (val) => typeof val === "symbol";
const shared_esm_bundler_isObject = (val) => val !== null && typeof val === "object";
const shared_esm_bundler_isPromise = (val) => {
  return (shared_esm_bundler_isObject(val) || shared_esm_bundler_isFunction(val)) && shared_esm_bundler_isFunction(val.then) && shared_esm_bundler_isFunction(val.catch);
};
const objectToString = Object.prototype.toString;
const toTypeString = (value) => objectToString.call(value);
const shared_esm_bundler_toRawType = (value) => {
  return toTypeString(value).slice(8, -1);
};
const shared_esm_bundler_isPlainObject = (val) => toTypeString(val) === "[object Object]";
const isIntegerKey = (key) => shared_esm_bundler_isString(key) && key !== "NaN" && key[0] !== "-" && "" + parseInt(key, 10) === key;
const shared_esm_bundler_isReservedProp = /* @__PURE__ */ shared_esm_bundler_makeMap(
  // the leading comma is intentional so empty string "" is also included
  ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
);
const shared_esm_bundler_isBuiltInDirective = /* @__PURE__ */ (/* unused pure expression or super */ null && (shared_esm_bundler_makeMap(
  "bind,cloak,else-if,else,for,html,if,model,on,once,pre,show,slot,text,memo"
)));
const cacheStringFunction = (fn) => {
  const cache = /* @__PURE__ */ Object.create(null);
  return ((str) => {
    const hit = cache[str];
    return hit || (cache[str] = fn(str));
  });
};
const camelizeRE = /-(\w)/g;
const shared_esm_bundler_camelize = cacheStringFunction(
  (str) => {
    return str.replace(camelizeRE, (_, c) => c ? c.toUpperCase() : "");
  }
);
const hyphenateRE = /\B([A-Z])/g;
const shared_esm_bundler_hyphenate = cacheStringFunction(
  (str) => str.replace(hyphenateRE, "-$1").toLowerCase()
);
const shared_esm_bundler_capitalize = cacheStringFunction((str) => {
  return str.charAt(0).toUpperCase() + str.slice(1);
});
const shared_esm_bundler_toHandlerKey = cacheStringFunction(
  (str) => {
    const s = str ? `on${shared_esm_bundler_capitalize(str)}` : ``;
    return s;
  }
);
const shared_esm_bundler_hasChanged = (value, oldValue) => !Object.is(value, oldValue);
const invokeArrayFns = (fns, ...arg) => {
  for (let i = 0; i < fns.length; i++) {
    fns[i](...arg);
  }
};
const def = (obj, key, value, writable = false) => {
  Object.defineProperty(obj, key, {
    configurable: true,
    enumerable: false,
    writable,
    value
  });
};
const looseToNumber = (val) => {
  const n = parseFloat(val);
  return isNaN(n) ? val : n;
};
const toNumber = (val) => {
  const n = shared_esm_bundler_isString(val) ? Number(val) : NaN;
  return isNaN(n) ? val : n;
};
let _globalThis;
const getGlobalThis = () => {
  return _globalThis || (_globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof __webpack_require__.g !== "undefined" ? __webpack_require__.g : {});
};
const identRE = /^[_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*$/;
function genPropsAccessExp(name) {
  return identRE.test(name) ? `__props.${name}` : `__props[${JSON.stringify(name)}]`;
}
function genCacheKey(source, options) {
  return source + JSON.stringify(
    options,
    (_, val) => typeof val === "function" ? val.toString() : val
  );
}

const PatchFlags = {
  "TEXT": 1,
  "1": "TEXT",
  "CLASS": 2,
  "2": "CLASS",
  "STYLE": 4,
  "4": "STYLE",
  "PROPS": 8,
  "8": "PROPS",
  "FULL_PROPS": 16,
  "16": "FULL_PROPS",
  "NEED_HYDRATION": 32,
  "32": "NEED_HYDRATION",
  "STABLE_FRAGMENT": 64,
  "64": "STABLE_FRAGMENT",
  "KEYED_FRAGMENT": 128,
  "128": "KEYED_FRAGMENT",
  "UNKEYED_FRAGMENT": 256,
  "256": "UNKEYED_FRAGMENT",
  "NEED_PATCH": 512,
  "512": "NEED_PATCH",
  "DYNAMIC_SLOTS": 1024,
  "1024": "DYNAMIC_SLOTS",
  "DEV_ROOT_FRAGMENT": 2048,
  "2048": "DEV_ROOT_FRAGMENT",
  "CACHED": -1,
  "-1": "CACHED",
  "BAIL": -2,
  "-2": "BAIL"
};
const PatchFlagNames = {
  [1]: `TEXT`,
  [2]: `CLASS`,
  [4]: `STYLE`,
  [8]: `PROPS`,
  [16]: `FULL_PROPS`,
  [32]: `NEED_HYDRATION`,
  [64]: `STABLE_FRAGMENT`,
  [128]: `KEYED_FRAGMENT`,
  [256]: `UNKEYED_FRAGMENT`,
  [512]: `NEED_PATCH`,
  [1024]: `DYNAMIC_SLOTS`,
  [2048]: `DEV_ROOT_FRAGMENT`,
  [-1]: `CACHED`,
  [-2]: `BAIL`
};

const ShapeFlags = {
  "ELEMENT": 1,
  "1": "ELEMENT",
  "FUNCTIONAL_COMPONENT": 2,
  "2": "FUNCTIONAL_COMPONENT",
  "STATEFUL_COMPONENT": 4,
  "4": "STATEFUL_COMPONENT",
  "TEXT_CHILDREN": 8,
  "8": "TEXT_CHILDREN",
  "ARRAY_CHILDREN": 16,
  "16": "ARRAY_CHILDREN",
  "SLOTS_CHILDREN": 32,
  "32": "SLOTS_CHILDREN",
  "TELEPORT": 64,
  "64": "TELEPORT",
  "SUSPENSE": 128,
  "128": "SUSPENSE",
  "COMPONENT_SHOULD_KEEP_ALIVE": 256,
  "256": "COMPONENT_SHOULD_KEEP_ALIVE",
  "COMPONENT_KEPT_ALIVE": 512,
  "512": "COMPONENT_KEPT_ALIVE",
  "COMPONENT": 6,
  "6": "COMPONENT"
};

const SlotFlags = {
  "STABLE": 1,
  "1": "STABLE",
  "DYNAMIC": 2,
  "2": "DYNAMIC",
  "FORWARDED": 3,
  "3": "FORWARDED"
};
const slotFlagsText = {
  [1]: "STABLE",
  [2]: "DYNAMIC",
  [3]: "FORWARDED"
};

const GLOBALS_ALLOWED = "Infinity,undefined,NaN,isFinite,isNaN,parseFloat,parseInt,decodeURI,decodeURIComponent,encodeURI,encodeURIComponent,Math,Number,Date,Array,Object,Boolean,String,RegExp,Map,Set,JSON,Intl,BigInt,console,Error,Symbol";
const isGloballyAllowed = /* @__PURE__ */ shared_esm_bundler_makeMap(GLOBALS_ALLOWED);
const isGloballyWhitelisted = (/* unused pure expression or super */ null && (isGloballyAllowed));

const range = 2;
function generateCodeFrame(source, start = 0, end = source.length) {
  start = Math.max(0, Math.min(start, source.length));
  end = Math.max(0, Math.min(end, source.length));
  if (start > end) return "";
  let lines = source.split(/(\r?\n)/);
  const newlineSequences = lines.filter((_, idx) => idx % 2 === 1);
  lines = lines.filter((_, idx) => idx % 2 === 0);
  let count = 0;
  const res = [];
  for (let i = 0; i < lines.length; i++) {
    count += lines[i].length + (newlineSequences[i] && newlineSequences[i].length || 0);
    if (count >= start) {
      for (let j = i - range; j <= i + range || end > count; j++) {
        if (j < 0 || j >= lines.length) continue;
        const line = j + 1;
        res.push(
          `${line}${" ".repeat(Math.max(3 - String(line).length, 0))}|  ${lines[j]}`
        );
        const lineLength = lines[j].length;
        const newLineSeqLength = newlineSequences[j] && newlineSequences[j].length || 0;
        if (j === i) {
          const pad = start - (count - (lineLength + newLineSeqLength));
          const length = Math.max(
            1,
            end > count ? lineLength - pad : end - start
          );
          res.push(`   |  ` + " ".repeat(pad) + "^".repeat(length));
        } else if (j > i) {
          if (end > count) {
            const length = Math.max(Math.min(end - count, lineLength), 1);
            res.push(`   |  ` + "^".repeat(length));
          }
          count += lineLength + newLineSeqLength;
        }
      }
      break;
    }
  }
  return res.join("\n");
}

function shared_esm_bundler_normalizeStyle(value) {
  if (shared_esm_bundler_isArray(value)) {
    const res = {};
    for (let i = 0; i < value.length; i++) {
      const item = value[i];
      const normalized = shared_esm_bundler_isString(item) ? parseStringStyle(item) : shared_esm_bundler_normalizeStyle(item);
      if (normalized) {
        for (const key in normalized) {
          res[key] = normalized[key];
        }
      }
    }
    return res;
  } else if (shared_esm_bundler_isString(value) || shared_esm_bundler_isObject(value)) {
    return value;
  }
}
const listDelimiterRE = /;(?![^(]*\))/g;
const propertyDelimiterRE = /:([^]+)/;
const styleCommentRE = /\/\*[^]*?\*\//g;
function parseStringStyle(cssText) {
  const ret = {};
  cssText.replace(styleCommentRE, "").split(listDelimiterRE).forEach((item) => {
    if (item) {
      const tmp = item.split(propertyDelimiterRE);
      tmp.length > 1 && (ret[tmp[0].trim()] = tmp[1].trim());
    }
  });
  return ret;
}
function shared_esm_bundler_stringifyStyle(styles) {
  if (!styles) return "";
  if (shared_esm_bundler_isString(styles)) return styles;
  let ret = "";
  for (const key in styles) {
    const value = styles[key];
    if (shared_esm_bundler_isString(value) || typeof value === "number") {
      const normalizedKey = key.startsWith(`--`) ? key : shared_esm_bundler_hyphenate(key);
      ret += `${normalizedKey}:${value};`;
    }
  }
  return ret;
}
function shared_esm_bundler_normalizeClass(value) {
  let res = "";
  if (shared_esm_bundler_isString(value)) {
    res = value;
  } else if (shared_esm_bundler_isArray(value)) {
    for (let i = 0; i < value.length; i++) {
      const normalized = shared_esm_bundler_normalizeClass(value[i]);
      if (normalized) {
        res += normalized + " ";
      }
    }
  } else if (shared_esm_bundler_isObject(value)) {
    for (const name in value) {
      if (value[name]) {
        res += name + " ";
      }
    }
  }
  return res.trim();
}
function normalizeProps(props) {
  if (!props) return null;
  let { class: klass, style } = props;
  if (klass && !shared_esm_bundler_isString(klass)) {
    props.class = shared_esm_bundler_normalizeClass(klass);
  }
  if (style) {
    props.style = shared_esm_bundler_normalizeStyle(style);
  }
  return props;
}

const HTML_TAGS = "html,body,base,head,link,meta,style,title,address,article,aside,footer,header,hgroup,h1,h2,h3,h4,h5,h6,nav,section,div,dd,dl,dt,figcaption,figure,picture,hr,img,li,main,ol,p,pre,ul,a,b,abbr,bdi,bdo,br,cite,code,data,dfn,em,i,kbd,mark,q,rp,rt,ruby,s,samp,small,span,strong,sub,sup,time,u,var,wbr,area,audio,map,track,video,embed,object,param,source,canvas,script,noscript,del,ins,caption,col,colgroup,table,thead,tbody,td,th,tr,button,datalist,fieldset,form,input,label,legend,meter,optgroup,option,output,progress,select,textarea,details,dialog,menu,summary,template,blockquote,iframe,tfoot";
const SVG_TAGS = "svg,animate,animateMotion,animateTransform,circle,clipPath,color-profile,defs,desc,discard,ellipse,feBlend,feColorMatrix,feComponentTransfer,feComposite,feConvolveMatrix,feDiffuseLighting,feDisplacementMap,feDistantLight,feDropShadow,feFlood,feFuncA,feFuncB,feFuncG,feFuncR,feGaussianBlur,feImage,feMerge,feMergeNode,feMorphology,feOffset,fePointLight,feSpecularLighting,feSpotLight,feTile,feTurbulence,filter,foreignObject,g,hatch,hatchpath,image,line,linearGradient,marker,mask,mesh,meshgradient,meshpatch,meshrow,metadata,mpath,path,pattern,polygon,polyline,radialGradient,rect,set,solidcolor,stop,switch,symbol,text,textPath,title,tspan,unknown,use,view";
const MATH_TAGS = "annotation,annotation-xml,maction,maligngroup,malignmark,math,menclose,merror,mfenced,mfrac,mfraction,mglyph,mi,mlabeledtr,mlongdiv,mmultiscripts,mn,mo,mover,mpadded,mphantom,mprescripts,mroot,mrow,ms,mscarries,mscarry,msgroup,msline,mspace,msqrt,msrow,mstack,mstyle,msub,msubsup,msup,mtable,mtd,mtext,mtr,munder,munderover,none,semantics";
const VOID_TAGS = "area,base,br,col,embed,hr,img,input,link,meta,param,source,track,wbr";
const shared_esm_bundler_isHTMLTag = /* @__PURE__ */ (/* unused pure expression or super */ null && (shared_esm_bundler_makeMap(HTML_TAGS)));
const shared_esm_bundler_isSVGTag = /* @__PURE__ */ (/* unused pure expression or super */ null && (shared_esm_bundler_makeMap(SVG_TAGS)));
const shared_esm_bundler_isMathMLTag = /* @__PURE__ */ (/* unused pure expression or super */ null && (shared_esm_bundler_makeMap(MATH_TAGS)));
const isVoidTag = /* @__PURE__ */ (/* unused pure expression or super */ null && (shared_esm_bundler_makeMap(VOID_TAGS)));

const specialBooleanAttrs = `itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly`;
const isSpecialBooleanAttr = /* @__PURE__ */ shared_esm_bundler_makeMap(specialBooleanAttrs);
const shared_esm_bundler_isBooleanAttr = /* @__PURE__ */ shared_esm_bundler_makeMap(
  specialBooleanAttrs + `,async,autofocus,autoplay,controls,default,defer,disabled,hidden,inert,loop,open,required,reversed,scoped,seamless,checked,muted,multiple,selected`
);
function shared_esm_bundler_includeBooleanAttr(value) {
  return !!value || value === "";
}
const unsafeAttrCharRE = /[>/="'\u0009\u000a\u000c\u0020]/;
const attrValidationCache = {};
function isSSRSafeAttrName(name) {
  if (attrValidationCache.hasOwnProperty(name)) {
    return attrValidationCache[name];
  }
  const isUnsafe = unsafeAttrCharRE.test(name);
  if (isUnsafe) {
    console.error(`unsafe attribute name: ${name}`);
  }
  return attrValidationCache[name] = !isUnsafe;
}
const propsToAttrMap = {
  acceptCharset: "accept-charset",
  className: "class",
  htmlFor: "for",
  httpEquiv: "http-equiv"
};
const shared_esm_bundler_isKnownHtmlAttr = /* @__PURE__ */ (/* unused pure expression or super */ null && (shared_esm_bundler_makeMap(
  `accept,accept-charset,accesskey,action,align,allow,alt,async,autocapitalize,autocomplete,autofocus,autoplay,background,bgcolor,border,buffered,capture,challenge,charset,checked,cite,class,code,codebase,color,cols,colspan,content,contenteditable,contextmenu,controls,coords,crossorigin,csp,data,datetime,decoding,default,defer,dir,dirname,disabled,download,draggable,dropzone,enctype,enterkeyhint,for,form,formaction,formenctype,formmethod,formnovalidate,formtarget,headers,height,hidden,high,href,hreflang,http-equiv,icon,id,importance,inert,integrity,ismap,itemprop,keytype,kind,label,lang,language,loading,list,loop,low,manifest,max,maxlength,minlength,media,min,multiple,muted,name,novalidate,open,optimum,pattern,ping,placeholder,poster,preload,radiogroup,readonly,referrerpolicy,rel,required,reversed,rows,rowspan,sandbox,scope,scoped,selected,shape,size,sizes,slot,span,spellcheck,src,srcdoc,srclang,srcset,start,step,style,summary,tabindex,target,title,translate,type,usemap,value,width,wrap`
)));
const shared_esm_bundler_isKnownSvgAttr = /* @__PURE__ */ (/* unused pure expression or super */ null && (shared_esm_bundler_makeMap(
  `xmlns,accent-height,accumulate,additive,alignment-baseline,alphabetic,amplitude,arabic-form,ascent,attributeName,attributeType,azimuth,baseFrequency,baseline-shift,baseProfile,bbox,begin,bias,by,calcMode,cap-height,class,clip,clipPathUnits,clip-path,clip-rule,color,color-interpolation,color-interpolation-filters,color-profile,color-rendering,contentScriptType,contentStyleType,crossorigin,cursor,cx,cy,d,decelerate,descent,diffuseConstant,direction,display,divisor,dominant-baseline,dur,dx,dy,edgeMode,elevation,enable-background,end,exponent,fill,fill-opacity,fill-rule,filter,filterRes,filterUnits,flood-color,flood-opacity,font-family,font-size,font-size-adjust,font-stretch,font-style,font-variant,font-weight,format,from,fr,fx,fy,g1,g2,glyph-name,glyph-orientation-horizontal,glyph-orientation-vertical,glyphRef,gradientTransform,gradientUnits,hanging,height,href,hreflang,horiz-adv-x,horiz-origin-x,id,ideographic,image-rendering,in,in2,intercept,k,k1,k2,k3,k4,kernelMatrix,kernelUnitLength,kerning,keyPoints,keySplines,keyTimes,lang,lengthAdjust,letter-spacing,lighting-color,limitingConeAngle,local,marker-end,marker-mid,marker-start,markerHeight,markerUnits,markerWidth,mask,maskContentUnits,maskUnits,mathematical,max,media,method,min,mode,name,numOctaves,offset,opacity,operator,order,orient,orientation,origin,overflow,overline-position,overline-thickness,panose-1,paint-order,path,pathLength,patternContentUnits,patternTransform,patternUnits,ping,pointer-events,points,pointsAtX,pointsAtY,pointsAtZ,preserveAlpha,preserveAspectRatio,primitiveUnits,r,radius,referrerPolicy,refX,refY,rel,rendering-intent,repeatCount,repeatDur,requiredExtensions,requiredFeatures,restart,result,rotate,rx,ry,scale,seed,shape-rendering,slope,spacing,specularConstant,specularExponent,speed,spreadMethod,startOffset,stdDeviation,stemh,stemv,stitchTiles,stop-color,stop-opacity,strikethrough-position,strikethrough-thickness,string,stroke,stroke-dasharray,stroke-dashoffset,stroke-linecap,stroke-linejoin,stroke-miterlimit,stroke-opacity,stroke-width,style,surfaceScale,systemLanguage,tabindex,tableValues,target,targetX,targetY,text-anchor,text-decoration,text-rendering,textLength,to,transform,transform-origin,type,u1,u2,underline-position,underline-thickness,unicode,unicode-bidi,unicode-range,units-per-em,v-alphabetic,v-hanging,v-ideographic,v-mathematical,values,vector-effect,version,vert-adv-y,vert-origin-x,vert-origin-y,viewBox,viewTarget,visibility,width,widths,word-spacing,writing-mode,x,x-height,x1,x2,xChannelSelector,xlink:actuate,xlink:arcrole,xlink:href,xlink:role,xlink:show,xlink:title,xlink:type,xmlns:xlink,xml:base,xml:lang,xml:space,y,y1,y2,yChannelSelector,z,zoomAndPan`
)));
const isKnownMathMLAttr = /* @__PURE__ */ (/* unused pure expression or super */ null && (shared_esm_bundler_makeMap(
  `accent,accentunder,actiontype,align,alignmentscope,altimg,altimg-height,altimg-valign,altimg-width,alttext,bevelled,close,columnsalign,columnlines,columnspan,denomalign,depth,dir,display,displaystyle,encoding,equalcolumns,equalrows,fence,fontstyle,fontweight,form,frame,framespacing,groupalign,height,href,id,indentalign,indentalignfirst,indentalignlast,indentshift,indentshiftfirst,indentshiftlast,indextype,justify,largetop,largeop,lquote,lspace,mathbackground,mathcolor,mathsize,mathvariant,maxsize,minlabelspacing,mode,other,overflow,position,rowalign,rowlines,rowspan,rquote,rspace,scriptlevel,scriptminsize,scriptsizemultiplier,selection,separator,separators,shift,side,src,stackalign,stretchy,subscriptshift,superscriptshift,symmetric,voffset,width,widths,xlink:href,xlink:show,xlink:type,xmlns`
)));
function shared_esm_bundler_isRenderableAttrValue(value) {
  if (value == null) {
    return false;
  }
  const type = typeof value;
  return type === "string" || type === "number" || type === "boolean";
}

const escapeRE = /["'&<>]/;
function escapeHtml(string) {
  const str = "" + string;
  const match = escapeRE.exec(str);
  if (!match) {
    return str;
  }
  let html = "";
  let escaped;
  let index;
  let lastIndex = 0;
  for (index = match.index; index < str.length; index++) {
    switch (str.charCodeAt(index)) {
      case 34:
        escaped = "&quot;";
        break;
      case 38:
        escaped = "&amp;";
        break;
      case 39:
        escaped = "&#39;";
        break;
      case 60:
        escaped = "&lt;";
        break;
      case 62:
        escaped = "&gt;";
        break;
      default:
        continue;
    }
    if (lastIndex !== index) {
      html += str.slice(lastIndex, index);
    }
    lastIndex = index + 1;
    html += escaped;
  }
  return lastIndex !== index ? html + str.slice(lastIndex, index) : html;
}
const commentStripRE = /^-?>|<!--|-->|--!>|<!-$/g;
function escapeHtmlComment(src) {
  return src.replace(commentStripRE, "");
}
const cssVarNameEscapeSymbolsRE = /[ !"#$%&'()*+,./:;<=>?@[\\\]^`{|}~]/g;
function shared_esm_bundler_getEscapedCssVarName(key, doubleEscape) {
  return key.replace(
    cssVarNameEscapeSymbolsRE,
    (s) => doubleEscape ? s === '"' ? '\\\\\\"' : `\\\\${s}` : `\\${s}`
  );
}

function looseCompareArrays(a, b) {
  if (a.length !== b.length) return false;
  let equal = true;
  for (let i = 0; equal && i < a.length; i++) {
    equal = shared_esm_bundler_looseEqual(a[i], b[i]);
  }
  return equal;
}
function shared_esm_bundler_looseEqual(a, b) {
  if (a === b) return true;
  let aValidType = isDate(a);
  let bValidType = isDate(b);
  if (aValidType || bValidType) {
    return aValidType && bValidType ? a.getTime() === b.getTime() : false;
  }
  aValidType = shared_esm_bundler_isSymbol(a);
  bValidType = shared_esm_bundler_isSymbol(b);
  if (aValidType || bValidType) {
    return a === b;
  }
  aValidType = shared_esm_bundler_isArray(a);
  bValidType = shared_esm_bundler_isArray(b);
  if (aValidType || bValidType) {
    return aValidType && bValidType ? looseCompareArrays(a, b) : false;
  }
  aValidType = shared_esm_bundler_isObject(a);
  bValidType = shared_esm_bundler_isObject(b);
  if (aValidType || bValidType) {
    if (!aValidType || !bValidType) {
      return false;
    }
    const aKeysCount = Object.keys(a).length;
    const bKeysCount = Object.keys(b).length;
    if (aKeysCount !== bKeysCount) {
      return false;
    }
    for (const key in a) {
      const aHasKey = a.hasOwnProperty(key);
      const bHasKey = b.hasOwnProperty(key);
      if (aHasKey && !bHasKey || !aHasKey && bHasKey || !shared_esm_bundler_looseEqual(a[key], b[key])) {
        return false;
      }
    }
  }
  return String(a) === String(b);
}
function shared_esm_bundler_looseIndexOf(arr, val) {
  return arr.findIndex((item) => shared_esm_bundler_looseEqual(item, val));
}

const shared_esm_bundler_isRef = (val) => {
  return !!(val && val["__v_isRef"] === true);
};
const toDisplayString = (val) => {
  return shared_esm_bundler_isString(val) ? val : val == null ? "" : shared_esm_bundler_isArray(val) || shared_esm_bundler_isObject(val) && (val.toString === objectToString || !shared_esm_bundler_isFunction(val.toString)) ? shared_esm_bundler_isRef(val) ? toDisplayString(val.value) : JSON.stringify(val, replacer, 2) : String(val);
};
const replacer = (_key, val) => {
  if (shared_esm_bundler_isRef(val)) {
    return replacer(_key, val.value);
  } else if (isMap(val)) {
    return {
      [`Map(${val.size})`]: [...val.entries()].reduce(
        (entries, [key, val2], i) => {
          entries[stringifySymbol(key, i) + " =>"] = val2;
          return entries;
        },
        {}
      )
    };
  } else if (shared_esm_bundler_isSet(val)) {
    return {
      [`Set(${val.size})`]: [...val.values()].map((v) => stringifySymbol(v))
    };
  } else if (shared_esm_bundler_isSymbol(val)) {
    return stringifySymbol(val);
  } else if (shared_esm_bundler_isObject(val) && !shared_esm_bundler_isArray(val) && !shared_esm_bundler_isPlainObject(val)) {
    return String(val);
  }
  return val;
};
const stringifySymbol = (v, i = "") => {
  var _a;
  return (
    // Symbol.description in es2019+ so we need to cast here to pass
    // the lib: es2016 check
    shared_esm_bundler_isSymbol(v) ? `Symbol(${(_a = v.description) != null ? _a : i})` : v
  );
};

function shared_esm_bundler_normalizeCssVarValue(value) {
  if (value == null) {
    return "initial";
  }
  if (typeof value === "string") {
    return value === "" ? " " : value;
  }
  if (typeof value !== "number" || !Number.isFinite(value)) {
    if (false) {}
  }
  return String(value);
}



;// CONCATENATED MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
/**
* @vue/reactivity v3.5.20
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/


function reactivity_esm_bundler_warn(msg, ...args) {
  console.warn(`[Vue warn] ${msg}`, ...args);
}

let activeEffectScope;
class EffectScope {
  constructor(detached = false) {
    this.detached = detached;
    /**
     * @internal
     */
    this._active = true;
    /**
     * @internal track `on` calls, allow `on` call multiple times
     */
    this._on = 0;
    /**
     * @internal
     */
    this.effects = [];
    /**
     * @internal
     */
    this.cleanups = [];
    this._isPaused = false;
    this.parent = activeEffectScope;
    if (!detached && activeEffectScope) {
      this.index = (activeEffectScope.scopes || (activeEffectScope.scopes = [])).push(
        this
      ) - 1;
    }
  }
  get active() {
    return this._active;
  }
  pause() {
    if (this._active) {
      this._isPaused = true;
      let i, l;
      if (this.scopes) {
        for (i = 0, l = this.scopes.length; i < l; i++) {
          this.scopes[i].pause();
        }
      }
      for (i = 0, l = this.effects.length; i < l; i++) {
        this.effects[i].pause();
      }
    }
  }
  /**
   * Resumes the effect scope, including all child scopes and effects.
   */
  resume() {
    if (this._active) {
      if (this._isPaused) {
        this._isPaused = false;
        let i, l;
        if (this.scopes) {
          for (i = 0, l = this.scopes.length; i < l; i++) {
            this.scopes[i].resume();
          }
        }
        for (i = 0, l = this.effects.length; i < l; i++) {
          this.effects[i].resume();
        }
      }
    }
  }
  run(fn) {
    if (this._active) {
      const currentEffectScope = activeEffectScope;
      try {
        activeEffectScope = this;
        return fn();
      } finally {
        activeEffectScope = currentEffectScope;
      }
    } else if (false) {}
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  on() {
    if (++this._on === 1) {
      this.prevScope = activeEffectScope;
      activeEffectScope = this;
    }
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  off() {
    if (this._on > 0 && --this._on === 0) {
      activeEffectScope = this.prevScope;
      this.prevScope = void 0;
    }
  }
  stop(fromParent) {
    if (this._active) {
      this._active = false;
      let i, l;
      for (i = 0, l = this.effects.length; i < l; i++) {
        this.effects[i].stop();
      }
      this.effects.length = 0;
      for (i = 0, l = this.cleanups.length; i < l; i++) {
        this.cleanups[i]();
      }
      this.cleanups.length = 0;
      if (this.scopes) {
        for (i = 0, l = this.scopes.length; i < l; i++) {
          this.scopes[i].stop(true);
        }
        this.scopes.length = 0;
      }
      if (!this.detached && this.parent && !fromParent) {
        const last = this.parent.scopes.pop();
        if (last && last !== this) {
          this.parent.scopes[this.index] = last;
          last.index = this.index;
        }
      }
      this.parent = void 0;
    }
  }
}
function effectScope(detached) {
  return new EffectScope(detached);
}
function getCurrentScope() {
  return activeEffectScope;
}
function onScopeDispose(fn, failSilently = false) {
  if (activeEffectScope) {
    activeEffectScope.cleanups.push(fn);
  } else if (false) {}
}

let activeSub;
const EffectFlags = {
  "ACTIVE": 1,
  "1": "ACTIVE",
  "RUNNING": 2,
  "2": "RUNNING",
  "TRACKING": 4,
  "4": "TRACKING",
  "NOTIFIED": 8,
  "8": "NOTIFIED",
  "DIRTY": 16,
  "16": "DIRTY",
  "ALLOW_RECURSE": 32,
  "32": "ALLOW_RECURSE",
  "PAUSED": 64,
  "64": "PAUSED",
  "EVALUATED": 128,
  "128": "EVALUATED"
};
const pausedQueueEffects = /* @__PURE__ */ new WeakSet();
class ReactiveEffect {
  constructor(fn) {
    this.fn = fn;
    /**
     * @internal
     */
    this.deps = void 0;
    /**
     * @internal
     */
    this.depsTail = void 0;
    /**
     * @internal
     */
    this.flags = 1 | 4;
    /**
     * @internal
     */
    this.next = void 0;
    /**
     * @internal
     */
    this.cleanup = void 0;
    this.scheduler = void 0;
    if (activeEffectScope && activeEffectScope.active) {
      activeEffectScope.effects.push(this);
    }
  }
  pause() {
    this.flags |= 64;
  }
  resume() {
    if (this.flags & 64) {
      this.flags &= -65;
      if (pausedQueueEffects.has(this)) {
        pausedQueueEffects.delete(this);
        this.trigger();
      }
    }
  }
  /**
   * @internal
   */
  notify() {
    if (this.flags & 2 && !(this.flags & 32)) {
      return;
    }
    if (!(this.flags & 8)) {
      batch(this);
    }
  }
  run() {
    if (!(this.flags & 1)) {
      return this.fn();
    }
    this.flags |= 2;
    cleanupEffect(this);
    prepareDeps(this);
    const prevEffect = activeSub;
    const prevShouldTrack = shouldTrack;
    activeSub = this;
    shouldTrack = true;
    try {
      return this.fn();
    } finally {
      if (false) {}
      cleanupDeps(this);
      activeSub = prevEffect;
      shouldTrack = prevShouldTrack;
      this.flags &= -3;
    }
  }
  stop() {
    if (this.flags & 1) {
      for (let link = this.deps; link; link = link.nextDep) {
        removeSub(link);
      }
      this.deps = this.depsTail = void 0;
      cleanupEffect(this);
      this.onStop && this.onStop();
      this.flags &= -2;
    }
  }
  trigger() {
    if (this.flags & 64) {
      pausedQueueEffects.add(this);
    } else if (this.scheduler) {
      this.scheduler();
    } else {
      this.runIfDirty();
    }
  }
  /**
   * @internal
   */
  runIfDirty() {
    if (isDirty(this)) {
      this.run();
    }
  }
  get dirty() {
    return isDirty(this);
  }
}
let batchDepth = 0;
let batchedSub;
let batchedComputed;
function batch(sub, isComputed = false) {
  sub.flags |= 8;
  if (isComputed) {
    sub.next = batchedComputed;
    batchedComputed = sub;
    return;
  }
  sub.next = batchedSub;
  batchedSub = sub;
}
function startBatch() {
  batchDepth++;
}
function endBatch() {
  if (--batchDepth > 0) {
    return;
  }
  if (batchedComputed) {
    let e = batchedComputed;
    batchedComputed = void 0;
    while (e) {
      const next = e.next;
      e.next = void 0;
      e.flags &= -9;
      e = next;
    }
  }
  let error;
  while (batchedSub) {
    let e = batchedSub;
    batchedSub = void 0;
    while (e) {
      const next = e.next;
      e.next = void 0;
      e.flags &= -9;
      if (e.flags & 1) {
        try {
          ;
          e.trigger();
        } catch (err) {
          if (!error) error = err;
        }
      }
      e = next;
    }
  }
  if (error) throw error;
}
function prepareDeps(sub) {
  for (let link = sub.deps; link; link = link.nextDep) {
    link.version = -1;
    link.prevActiveLink = link.dep.activeLink;
    link.dep.activeLink = link;
  }
}
function cleanupDeps(sub) {
  let head;
  let tail = sub.depsTail;
  let link = tail;
  while (link) {
    const prev = link.prevDep;
    if (link.version === -1) {
      if (link === tail) tail = prev;
      removeSub(link);
      removeDep(link);
    } else {
      head = link;
    }
    link.dep.activeLink = link.prevActiveLink;
    link.prevActiveLink = void 0;
    link = prev;
  }
  sub.deps = head;
  sub.depsTail = tail;
}
function isDirty(sub) {
  for (let link = sub.deps; link; link = link.nextDep) {
    if (link.dep.version !== link.version || link.dep.computed && (refreshComputed(link.dep.computed) || link.dep.version !== link.version)) {
      return true;
    }
  }
  if (sub._dirty) {
    return true;
  }
  return false;
}
function refreshComputed(computed) {
  if (computed.flags & 4 && !(computed.flags & 16)) {
    return;
  }
  computed.flags &= -17;
  if (computed.globalVersion === globalVersion) {
    return;
  }
  computed.globalVersion = globalVersion;
  if (!computed.isSSR && computed.flags & 128 && (!computed.deps && !computed._dirty || !isDirty(computed))) {
    return;
  }
  computed.flags |= 2;
  const dep = computed.dep;
  const prevSub = activeSub;
  const prevShouldTrack = shouldTrack;
  activeSub = computed;
  shouldTrack = true;
  try {
    prepareDeps(computed);
    const value = computed.fn(computed._value);
    if (dep.version === 0 || shared_esm_bundler_hasChanged(value, computed._value)) {
      computed.flags |= 128;
      computed._value = value;
      dep.version++;
    }
  } catch (err) {
    dep.version++;
    throw err;
  } finally {
    activeSub = prevSub;
    shouldTrack = prevShouldTrack;
    cleanupDeps(computed);
    computed.flags &= -3;
  }
}
function removeSub(link, soft = false) {
  const { dep, prevSub, nextSub } = link;
  if (prevSub) {
    prevSub.nextSub = nextSub;
    link.prevSub = void 0;
  }
  if (nextSub) {
    nextSub.prevSub = prevSub;
    link.nextSub = void 0;
  }
  if (false) {}
  if (dep.subs === link) {
    dep.subs = prevSub;
    if (!prevSub && dep.computed) {
      dep.computed.flags &= -5;
      for (let l = dep.computed.deps; l; l = l.nextDep) {
        removeSub(l, true);
      }
    }
  }
  if (!soft && !--dep.sc && dep.map) {
    dep.map.delete(dep.key);
  }
}
function removeDep(link) {
  const { prevDep, nextDep } = link;
  if (prevDep) {
    prevDep.nextDep = nextDep;
    link.prevDep = void 0;
  }
  if (nextDep) {
    nextDep.prevDep = prevDep;
    link.nextDep = void 0;
  }
}
function effect(fn, options) {
  if (fn.effect instanceof ReactiveEffect) {
    fn = fn.effect.fn;
  }
  const e = new ReactiveEffect(fn);
  if (options) {
    extend(e, options);
  }
  try {
    e.run();
  } catch (err) {
    e.stop();
    throw err;
  }
  const runner = e.run.bind(e);
  runner.effect = e;
  return runner;
}
function stop(runner) {
  runner.effect.stop();
}
let shouldTrack = true;
const trackStack = [];
function reactivity_esm_bundler_pauseTracking() {
  trackStack.push(shouldTrack);
  shouldTrack = false;
}
function enableTracking() {
  trackStack.push(shouldTrack);
  shouldTrack = true;
}
function reactivity_esm_bundler_resetTracking() {
  const last = trackStack.pop();
  shouldTrack = last === void 0 ? true : last;
}
function onEffectCleanup(fn, failSilently = false) {
  if (activeSub instanceof ReactiveEffect) {
    activeSub.cleanup = fn;
  } else if (false) {}
}
function cleanupEffect(e) {
  const { cleanup } = e;
  e.cleanup = void 0;
  if (cleanup) {
    const prevSub = activeSub;
    activeSub = void 0;
    try {
      cleanup();
    } finally {
      activeSub = prevSub;
    }
  }
}

let globalVersion = 0;
class Link {
  constructor(sub, dep) {
    this.sub = sub;
    this.dep = dep;
    this.version = dep.version;
    this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
  }
}
class Dep {
  // TODO isolatedDeclarations "__v_skip"
  constructor(computed) {
    this.computed = computed;
    this.version = 0;
    /**
     * Link between this dep and the current active effect
     */
    this.activeLink = void 0;
    /**
     * Doubly linked list representing the subscribing effects (tail)
     */
    this.subs = void 0;
    /**
     * For object property deps cleanup
     */
    this.map = void 0;
    this.key = void 0;
    /**
     * Subscriber counter
     */
    this.sc = 0;
    /**
     * @internal
     */
    this.__v_skip = true;
    if (false) {}
  }
  track(debugInfo) {
    if (!activeSub || !shouldTrack || activeSub === this.computed) {
      return;
    }
    let link = this.activeLink;
    if (link === void 0 || link.sub !== activeSub) {
      link = this.activeLink = new Link(activeSub, this);
      if (!activeSub.deps) {
        activeSub.deps = activeSub.depsTail = link;
      } else {
        link.prevDep = activeSub.depsTail;
        activeSub.depsTail.nextDep = link;
        activeSub.depsTail = link;
      }
      addSub(link);
    } else if (link.version === -1) {
      link.version = this.version;
      if (link.nextDep) {
        const next = link.nextDep;
        next.prevDep = link.prevDep;
        if (link.prevDep) {
          link.prevDep.nextDep = next;
        }
        link.prevDep = activeSub.depsTail;
        link.nextDep = void 0;
        activeSub.depsTail.nextDep = link;
        activeSub.depsTail = link;
        if (activeSub.deps === link) {
          activeSub.deps = next;
        }
      }
    }
    if (false) {}
    return link;
  }
  trigger(debugInfo) {
    this.version++;
    globalVersion++;
    this.notify(debugInfo);
  }
  notify(debugInfo) {
    startBatch();
    try {
      if (false) {}
      for (let link = this.subs; link; link = link.prevSub) {
        if (link.sub.notify()) {
          ;
          link.sub.dep.notify();
        }
      }
    } finally {
      endBatch();
    }
  }
}
function addSub(link) {
  link.dep.sc++;
  if (link.sub.flags & 4) {
    const computed = link.dep.computed;
    if (computed && !link.dep.subs) {
      computed.flags |= 4 | 16;
      for (let l = computed.deps; l; l = l.nextDep) {
        addSub(l);
      }
    }
    const currentTail = link.dep.subs;
    if (currentTail !== link) {
      link.prevSub = currentTail;
      if (currentTail) currentTail.nextSub = link;
    }
    if (false) {}
    link.dep.subs = link;
  }
}
const targetMap = /* @__PURE__ */ new WeakMap();
const ITERATE_KEY = Symbol(
   false ? 0 : ""
);
const MAP_KEY_ITERATE_KEY = Symbol(
   false ? 0 : ""
);
const ARRAY_ITERATE_KEY = Symbol(
   false ? 0 : ""
);
function reactivity_esm_bundler_track(target, type, key) {
  if (shouldTrack && activeSub) {
    let depsMap = targetMap.get(target);
    if (!depsMap) {
      targetMap.set(target, depsMap = /* @__PURE__ */ new Map());
    }
    let dep = depsMap.get(key);
    if (!dep) {
      depsMap.set(key, dep = new Dep());
      dep.map = depsMap;
      dep.key = key;
    }
    if (false) {} else {
      dep.track();
    }
  }
}
function trigger(target, type, key, newValue, oldValue, oldTarget) {
  const depsMap = targetMap.get(target);
  if (!depsMap) {
    globalVersion++;
    return;
  }
  const run = (dep) => {
    if (dep) {
      if (false) {} else {
        dep.trigger();
      }
    }
  };
  startBatch();
  if (type === "clear") {
    depsMap.forEach(run);
  } else {
    const targetIsArray = shared_esm_bundler_isArray(target);
    const isArrayIndex = targetIsArray && isIntegerKey(key);
    if (targetIsArray && key === "length") {
      const newLength = Number(newValue);
      depsMap.forEach((dep, key2) => {
        if (key2 === "length" || key2 === ARRAY_ITERATE_KEY || !shared_esm_bundler_isSymbol(key2) && key2 >= newLength) {
          run(dep);
        }
      });
    } else {
      if (key !== void 0 || depsMap.has(void 0)) {
        run(depsMap.get(key));
      }
      if (isArrayIndex) {
        run(depsMap.get(ARRAY_ITERATE_KEY));
      }
      switch (type) {
        case "add":
          if (!targetIsArray) {
            run(depsMap.get(ITERATE_KEY));
            if (isMap(target)) {
              run(depsMap.get(MAP_KEY_ITERATE_KEY));
            }
          } else if (isArrayIndex) {
            run(depsMap.get("length"));
          }
          break;
        case "delete":
          if (!targetIsArray) {
            run(depsMap.get(ITERATE_KEY));
            if (isMap(target)) {
              run(depsMap.get(MAP_KEY_ITERATE_KEY));
            }
          }
          break;
        case "set":
          if (isMap(target)) {
            run(depsMap.get(ITERATE_KEY));
          }
          break;
      }
    }
  }
  endBatch();
}
function getDepFromReactive(object, key) {
  const depMap = targetMap.get(object);
  return depMap && depMap.get(key);
}

function reactiveReadArray(array) {
  const raw = reactivity_esm_bundler_toRaw(array);
  if (raw === array) return raw;
  reactivity_esm_bundler_track(raw, "iterate", ARRAY_ITERATE_KEY);
  return reactivity_esm_bundler_isShallow(array) ? raw : raw.map(toReactive);
}
function shallowReadArray(arr) {
  reactivity_esm_bundler_track(arr = reactivity_esm_bundler_toRaw(arr), "iterate", ARRAY_ITERATE_KEY);
  return arr;
}
const arrayInstrumentations = {
  __proto__: null,
  [Symbol.iterator]() {
    return iterator(this, Symbol.iterator, toReactive);
  },
  concat(...args) {
    return reactiveReadArray(this).concat(
      ...args.map((x) => shared_esm_bundler_isArray(x) ? reactiveReadArray(x) : x)
    );
  },
  entries() {
    return iterator(this, "entries", (value) => {
      value[1] = toReactive(value[1]);
      return value;
    });
  },
  every(fn, thisArg) {
    return apply(this, "every", fn, thisArg, void 0, arguments);
  },
  filter(fn, thisArg) {
    return apply(this, "filter", fn, thisArg, (v) => v.map(toReactive), arguments);
  },
  find(fn, thisArg) {
    return apply(this, "find", fn, thisArg, toReactive, arguments);
  },
  findIndex(fn, thisArg) {
    return apply(this, "findIndex", fn, thisArg, void 0, arguments);
  },
  findLast(fn, thisArg) {
    return apply(this, "findLast", fn, thisArg, toReactive, arguments);
  },
  findLastIndex(fn, thisArg) {
    return apply(this, "findLastIndex", fn, thisArg, void 0, arguments);
  },
  // flat, flatMap could benefit from ARRAY_ITERATE but are not straight-forward to implement
  forEach(fn, thisArg) {
    return apply(this, "forEach", fn, thisArg, void 0, arguments);
  },
  includes(...args) {
    return searchProxy(this, "includes", args);
  },
  indexOf(...args) {
    return searchProxy(this, "indexOf", args);
  },
  join(separator) {
    return reactiveReadArray(this).join(separator);
  },
  // keys() iterator only reads `length`, no optimization required
  lastIndexOf(...args) {
    return searchProxy(this, "lastIndexOf", args);
  },
  map(fn, thisArg) {
    return apply(this, "map", fn, thisArg, void 0, arguments);
  },
  pop() {
    return noTracking(this, "pop");
  },
  push(...args) {
    return noTracking(this, "push", args);
  },
  reduce(fn, ...args) {
    return reduce(this, "reduce", fn, args);
  },
  reduceRight(fn, ...args) {
    return reduce(this, "reduceRight", fn, args);
  },
  shift() {
    return noTracking(this, "shift");
  },
  // slice could use ARRAY_ITERATE but also seems to beg for range tracking
  some(fn, thisArg) {
    return apply(this, "some", fn, thisArg, void 0, arguments);
  },
  splice(...args) {
    return noTracking(this, "splice", args);
  },
  toReversed() {
    return reactiveReadArray(this).toReversed();
  },
  toSorted(comparer) {
    return reactiveReadArray(this).toSorted(comparer);
  },
  toSpliced(...args) {
    return reactiveReadArray(this).toSpliced(...args);
  },
  unshift(...args) {
    return noTracking(this, "unshift", args);
  },
  values() {
    return iterator(this, "values", toReactive);
  }
};
function iterator(self, method, wrapValue) {
  const arr = shallowReadArray(self);
  const iter = arr[method]();
  if (arr !== self && !reactivity_esm_bundler_isShallow(self)) {
    iter._next = iter.next;
    iter.next = () => {
      const result = iter._next();
      if (result.value) {
        result.value = wrapValue(result.value);
      }
      return result;
    };
  }
  return iter;
}
const arrayProto = Array.prototype;
function apply(self, method, fn, thisArg, wrappedRetFn, args) {
  const arr = shallowReadArray(self);
  const needsWrap = arr !== self && !reactivity_esm_bundler_isShallow(self);
  const methodFn = arr[method];
  if (methodFn !== arrayProto[method]) {
    const result2 = methodFn.apply(self, args);
    return needsWrap ? toReactive(result2) : result2;
  }
  let wrappedFn = fn;
  if (arr !== self) {
    if (needsWrap) {
      wrappedFn = function(item, index) {
        return fn.call(this, toReactive(item), index, self);
      };
    } else if (fn.length > 2) {
      wrappedFn = function(item, index) {
        return fn.call(this, item, index, self);
      };
    }
  }
  const result = methodFn.call(arr, wrappedFn, thisArg);
  return needsWrap && wrappedRetFn ? wrappedRetFn(result) : result;
}
function reduce(self, method, fn, args) {
  const arr = shallowReadArray(self);
  let wrappedFn = fn;
  if (arr !== self) {
    if (!reactivity_esm_bundler_isShallow(self)) {
      wrappedFn = function(acc, item, index) {
        return fn.call(this, acc, toReactive(item), index, self);
      };
    } else if (fn.length > 3) {
      wrappedFn = function(acc, item, index) {
        return fn.call(this, acc, item, index, self);
      };
    }
  }
  return arr[method](wrappedFn, ...args);
}
function searchProxy(self, method, args) {
  const arr = reactivity_esm_bundler_toRaw(self);
  reactivity_esm_bundler_track(arr, "iterate", ARRAY_ITERATE_KEY);
  const res = arr[method](...args);
  if ((res === -1 || res === false) && isProxy(args[0])) {
    args[0] = reactivity_esm_bundler_toRaw(args[0]);
    return arr[method](...args);
  }
  return res;
}
function noTracking(self, method, args = []) {
  reactivity_esm_bundler_pauseTracking();
  startBatch();
  const res = reactivity_esm_bundler_toRaw(self)[method].apply(self, args);
  endBatch();
  reactivity_esm_bundler_resetTracking();
  return res;
}

const isNonTrackableKeys = /* @__PURE__ */ shared_esm_bundler_makeMap(`__proto__,__v_isRef,__isVue`);
const builtInSymbols = new Set(
  /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((key) => key !== "arguments" && key !== "caller").map((key) => Symbol[key]).filter(shared_esm_bundler_isSymbol)
);
function reactivity_esm_bundler_hasOwnProperty(key) {
  if (!shared_esm_bundler_isSymbol(key)) key = String(key);
  const obj = reactivity_esm_bundler_toRaw(this);
  reactivity_esm_bundler_track(obj, "has", key);
  return obj.hasOwnProperty(key);
}
class BaseReactiveHandler {
  constructor(_isReadonly = false, _isShallow = false) {
    this._isReadonly = _isReadonly;
    this._isShallow = _isShallow;
  }
  get(target, key, receiver) {
    if (key === "__v_skip") return target["__v_skip"];
    const isReadonly2 = this._isReadonly, isShallow2 = this._isShallow;
    if (key === "__v_isReactive") {
      return !isReadonly2;
    } else if (key === "__v_isReadonly") {
      return isReadonly2;
    } else if (key === "__v_isShallow") {
      return isShallow2;
    } else if (key === "__v_raw") {
      if (receiver === (isReadonly2 ? isShallow2 ? shallowReadonlyMap : readonlyMap : isShallow2 ? shallowReactiveMap : reactiveMap).get(target) || // receiver is not the reactive proxy, but has the same prototype
      // this means the receiver is a user proxy of the reactive proxy
      Object.getPrototypeOf(target) === Object.getPrototypeOf(receiver)) {
        return target;
      }
      return;
    }
    const targetIsArray = shared_esm_bundler_isArray(target);
    if (!isReadonly2) {
      let fn;
      if (targetIsArray && (fn = arrayInstrumentations[key])) {
        return fn;
      }
      if (key === "hasOwnProperty") {
        return reactivity_esm_bundler_hasOwnProperty;
      }
    }
    const res = Reflect.get(
      target,
      key,
      // if this is a proxy wrapping a ref, return methods using the raw ref
      // as receiver so that we don't have to call `toRaw` on the ref in all
      // its class methods
      reactivity_esm_bundler_isRef(target) ? target : receiver
    );
    if (shared_esm_bundler_isSymbol(key) ? builtInSymbols.has(key) : isNonTrackableKeys(key)) {
      return res;
    }
    if (!isReadonly2) {
      reactivity_esm_bundler_track(target, "get", key);
    }
    if (isShallow2) {
      return res;
    }
    if (reactivity_esm_bundler_isRef(res)) {
      return targetIsArray && isIntegerKey(key) ? res : res.value;
    }
    if (shared_esm_bundler_isObject(res)) {
      return isReadonly2 ? readonly(res) : reactive(res);
    }
    return res;
  }
}
class MutableReactiveHandler extends BaseReactiveHandler {
  constructor(isShallow2 = false) {
    super(false, isShallow2);
  }
  set(target, key, value, receiver) {
    let oldValue = target[key];
    if (!this._isShallow) {
      const isOldValueReadonly = reactivity_esm_bundler_isReadonly(oldValue);
      if (!reactivity_esm_bundler_isShallow(value) && !reactivity_esm_bundler_isReadonly(value)) {
        oldValue = reactivity_esm_bundler_toRaw(oldValue);
        value = reactivity_esm_bundler_toRaw(value);
      }
      if (!shared_esm_bundler_isArray(target) && reactivity_esm_bundler_isRef(oldValue) && !reactivity_esm_bundler_isRef(value)) {
        if (isOldValueReadonly) {
          if (false) {}
          return true;
        } else {
          oldValue.value = value;
          return true;
        }
      }
    }
    const hadKey = shared_esm_bundler_isArray(target) && isIntegerKey(key) ? Number(key) < target.length : hasOwn(target, key);
    const result = Reflect.set(
      target,
      key,
      value,
      reactivity_esm_bundler_isRef(target) ? target : receiver
    );
    if (target === reactivity_esm_bundler_toRaw(receiver)) {
      if (!hadKey) {
        trigger(target, "add", key, value);
      } else if (shared_esm_bundler_hasChanged(value, oldValue)) {
        trigger(target, "set", key, value, oldValue);
      }
    }
    return result;
  }
  deleteProperty(target, key) {
    const hadKey = hasOwn(target, key);
    const oldValue = target[key];
    const result = Reflect.deleteProperty(target, key);
    if (result && hadKey) {
      trigger(target, "delete", key, void 0, oldValue);
    }
    return result;
  }
  has(target, key) {
    const result = Reflect.has(target, key);
    if (!shared_esm_bundler_isSymbol(key) || !builtInSymbols.has(key)) {
      reactivity_esm_bundler_track(target, "has", key);
    }
    return result;
  }
  ownKeys(target) {
    reactivity_esm_bundler_track(
      target,
      "iterate",
      shared_esm_bundler_isArray(target) ? "length" : ITERATE_KEY
    );
    return Reflect.ownKeys(target);
  }
}
class ReadonlyReactiveHandler extends BaseReactiveHandler {
  constructor(isShallow2 = false) {
    super(true, isShallow2);
  }
  set(target, key) {
    if (false) {}
    return true;
  }
  deleteProperty(target, key) {
    if (false) {}
    return true;
  }
}
const mutableHandlers = /* @__PURE__ */ new MutableReactiveHandler();
const readonlyHandlers = /* @__PURE__ */ new ReadonlyReactiveHandler();
const shallowReactiveHandlers = /* @__PURE__ */ new MutableReactiveHandler(true);
const shallowReadonlyHandlers = /* @__PURE__ */ new ReadonlyReactiveHandler(true);

const toShallow = (value) => value;
const getProto = (v) => Reflect.getPrototypeOf(v);
function createIterableMethod(method, isReadonly2, isShallow2) {
  return function(...args) {
    const target = this["__v_raw"];
    const rawTarget = reactivity_esm_bundler_toRaw(target);
    const targetIsMap = isMap(rawTarget);
    const isPair = method === "entries" || method === Symbol.iterator && targetIsMap;
    const isKeyOnly = method === "keys" && targetIsMap;
    const innerIterator = target[method](...args);
    const wrap = isShallow2 ? toShallow : isReadonly2 ? toReadonly : toReactive;
    !isReadonly2 && reactivity_esm_bundler_track(
      rawTarget,
      "iterate",
      isKeyOnly ? MAP_KEY_ITERATE_KEY : ITERATE_KEY
    );
    return {
      // iterator protocol
      next() {
        const { value, done } = innerIterator.next();
        return done ? { value, done } : {
          value: isPair ? [wrap(value[0]), wrap(value[1])] : wrap(value),
          done
        };
      },
      // iterable protocol
      [Symbol.iterator]() {
        return this;
      }
    };
  };
}
function createReadonlyMethod(type) {
  return function(...args) {
    if (false) {}
    return type === "delete" ? false : type === "clear" ? void 0 : this;
  };
}
function createInstrumentations(readonly, shallow) {
  const instrumentations = {
    get(key) {
      const target = this["__v_raw"];
      const rawTarget = reactivity_esm_bundler_toRaw(target);
      const rawKey = reactivity_esm_bundler_toRaw(key);
      if (!readonly) {
        if (shared_esm_bundler_hasChanged(key, rawKey)) {
          reactivity_esm_bundler_track(rawTarget, "get", key);
        }
        reactivity_esm_bundler_track(rawTarget, "get", rawKey);
      }
      const { has } = getProto(rawTarget);
      const wrap = shallow ? toShallow : readonly ? toReadonly : toReactive;
      if (has.call(rawTarget, key)) {
        return wrap(target.get(key));
      } else if (has.call(rawTarget, rawKey)) {
        return wrap(target.get(rawKey));
      } else if (target !== rawTarget) {
        target.get(key);
      }
    },
    get size() {
      const target = this["__v_raw"];
      !readonly && reactivity_esm_bundler_track(reactivity_esm_bundler_toRaw(target), "iterate", ITERATE_KEY);
      return target.size;
    },
    has(key) {
      const target = this["__v_raw"];
      const rawTarget = reactivity_esm_bundler_toRaw(target);
      const rawKey = reactivity_esm_bundler_toRaw(key);
      if (!readonly) {
        if (shared_esm_bundler_hasChanged(key, rawKey)) {
          reactivity_esm_bundler_track(rawTarget, "has", key);
        }
        reactivity_esm_bundler_track(rawTarget, "has", rawKey);
      }
      return key === rawKey ? target.has(key) : target.has(key) || target.has(rawKey);
    },
    forEach(callback, thisArg) {
      const observed = this;
      const target = observed["__v_raw"];
      const rawTarget = reactivity_esm_bundler_toRaw(target);
      const wrap = shallow ? toShallow : readonly ? toReadonly : toReactive;
      !readonly && reactivity_esm_bundler_track(rawTarget, "iterate", ITERATE_KEY);
      return target.forEach((value, key) => {
        return callback.call(thisArg, wrap(value), wrap(key), observed);
      });
    }
  };
  shared_esm_bundler_extend(
    instrumentations,
    readonly ? {
      add: createReadonlyMethod("add"),
      set: createReadonlyMethod("set"),
      delete: createReadonlyMethod("delete"),
      clear: createReadonlyMethod("clear")
    } : {
      add(value) {
        if (!shallow && !reactivity_esm_bundler_isShallow(value) && !reactivity_esm_bundler_isReadonly(value)) {
          value = reactivity_esm_bundler_toRaw(value);
        }
        const target = reactivity_esm_bundler_toRaw(this);
        const proto = getProto(target);
        const hadKey = proto.has.call(target, value);
        if (!hadKey) {
          target.add(value);
          trigger(target, "add", value, value);
        }
        return this;
      },
      set(key, value) {
        if (!shallow && !reactivity_esm_bundler_isShallow(value) && !reactivity_esm_bundler_isReadonly(value)) {
          value = reactivity_esm_bundler_toRaw(value);
        }
        const target = reactivity_esm_bundler_toRaw(this);
        const { has, get } = getProto(target);
        let hadKey = has.call(target, key);
        if (!hadKey) {
          key = reactivity_esm_bundler_toRaw(key);
          hadKey = has.call(target, key);
        } else if (false) {}
        const oldValue = get.call(target, key);
        target.set(key, value);
        if (!hadKey) {
          trigger(target, "add", key, value);
        } else if (shared_esm_bundler_hasChanged(value, oldValue)) {
          trigger(target, "set", key, value, oldValue);
        }
        return this;
      },
      delete(key) {
        const target = reactivity_esm_bundler_toRaw(this);
        const { has, get } = getProto(target);
        let hadKey = has.call(target, key);
        if (!hadKey) {
          key = reactivity_esm_bundler_toRaw(key);
          hadKey = has.call(target, key);
        } else if (false) {}
        const oldValue = get ? get.call(target, key) : void 0;
        const result = target.delete(key);
        if (hadKey) {
          trigger(target, "delete", key, void 0, oldValue);
        }
        return result;
      },
      clear() {
        const target = reactivity_esm_bundler_toRaw(this);
        const hadItems = target.size !== 0;
        const oldTarget =  false ? 0 : void 0;
        const result = target.clear();
        if (hadItems) {
          trigger(
            target,
            "clear",
            void 0,
            void 0,
            oldTarget
          );
        }
        return result;
      }
    }
  );
  const iteratorMethods = [
    "keys",
    "values",
    "entries",
    Symbol.iterator
  ];
  iteratorMethods.forEach((method) => {
    instrumentations[method] = createIterableMethod(method, readonly, shallow);
  });
  return instrumentations;
}
function createInstrumentationGetter(isReadonly2, shallow) {
  const instrumentations = createInstrumentations(isReadonly2, shallow);
  return (target, key, receiver) => {
    if (key === "__v_isReactive") {
      return !isReadonly2;
    } else if (key === "__v_isReadonly") {
      return isReadonly2;
    } else if (key === "__v_raw") {
      return target;
    }
    return Reflect.get(
      hasOwn(instrumentations, key) && key in target ? instrumentations : target,
      key,
      receiver
    );
  };
}
const mutableCollectionHandlers = {
  get: /* @__PURE__ */ createInstrumentationGetter(false, false)
};
const shallowCollectionHandlers = {
  get: /* @__PURE__ */ createInstrumentationGetter(false, true)
};
const readonlyCollectionHandlers = {
  get: /* @__PURE__ */ createInstrumentationGetter(true, false)
};
const shallowReadonlyCollectionHandlers = {
  get: /* @__PURE__ */ createInstrumentationGetter(true, true)
};
function checkIdentityKeys(target, has, key) {
  const rawKey = reactivity_esm_bundler_toRaw(key);
  if (rawKey !== key && has.call(target, rawKey)) {
    const type = toRawType(target);
    reactivity_esm_bundler_warn(
      `Reactive ${type} contains both the raw and reactive versions of the same object${type === `Map` ? ` as keys` : ``}, which can lead to inconsistencies. Avoid differentiating between the raw and reactive versions of an object and only use the reactive version if possible.`
    );
  }
}

const reactiveMap = /* @__PURE__ */ new WeakMap();
const shallowReactiveMap = /* @__PURE__ */ new WeakMap();
const readonlyMap = /* @__PURE__ */ new WeakMap();
const shallowReadonlyMap = /* @__PURE__ */ new WeakMap();
function targetTypeMap(rawType) {
  switch (rawType) {
    case "Object":
    case "Array":
      return 1 /* COMMON */;
    case "Map":
    case "Set":
    case "WeakMap":
    case "WeakSet":
      return 2 /* COLLECTION */;
    default:
      return 0 /* INVALID */;
  }
}
function getTargetType(value) {
  return value["__v_skip"] || !Object.isExtensible(value) ? 0 /* INVALID */ : targetTypeMap(shared_esm_bundler_toRawType(value));
}
function reactive(target) {
  if (reactivity_esm_bundler_isReadonly(target)) {
    return target;
  }
  return createReactiveObject(
    target,
    false,
    mutableHandlers,
    mutableCollectionHandlers,
    reactiveMap
  );
}
function shallowReactive(target) {
  return createReactiveObject(
    target,
    false,
    shallowReactiveHandlers,
    shallowCollectionHandlers,
    shallowReactiveMap
  );
}
function readonly(target) {
  return createReactiveObject(
    target,
    true,
    readonlyHandlers,
    readonlyCollectionHandlers,
    readonlyMap
  );
}
function shallowReadonly(target) {
  return createReactiveObject(
    target,
    true,
    shallowReadonlyHandlers,
    shallowReadonlyCollectionHandlers,
    shallowReadonlyMap
  );
}
function createReactiveObject(target, isReadonly2, baseHandlers, collectionHandlers, proxyMap) {
  if (!shared_esm_bundler_isObject(target)) {
    if (false) {}
    return target;
  }
  if (target["__v_raw"] && !(isReadonly2 && target["__v_isReactive"])) {
    return target;
  }
  const targetType = getTargetType(target);
  if (targetType === 0 /* INVALID */) {
    return target;
  }
  const existingProxy = proxyMap.get(target);
  if (existingProxy) {
    return existingProxy;
  }
  const proxy = new Proxy(
    target,
    targetType === 2 /* COLLECTION */ ? collectionHandlers : baseHandlers
  );
  proxyMap.set(target, proxy);
  return proxy;
}
function reactivity_esm_bundler_isReactive(value) {
  if (reactivity_esm_bundler_isReadonly(value)) {
    return reactivity_esm_bundler_isReactive(value["__v_raw"]);
  }
  return !!(value && value["__v_isReactive"]);
}
function reactivity_esm_bundler_isReadonly(value) {
  return !!(value && value["__v_isReadonly"]);
}
function reactivity_esm_bundler_isShallow(value) {
  return !!(value && value["__v_isShallow"]);
}
function isProxy(value) {
  return value ? !!value["__v_raw"] : false;
}
function reactivity_esm_bundler_toRaw(observed) {
  const raw = observed && observed["__v_raw"];
  return raw ? reactivity_esm_bundler_toRaw(raw) : observed;
}
function reactivity_esm_bundler_markRaw(value) {
  if (!hasOwn(value, "__v_skip") && Object.isExtensible(value)) {
    def(value, "__v_skip", true);
  }
  return value;
}
const toReactive = (value) => shared_esm_bundler_isObject(value) ? reactive(value) : value;
const toReadonly = (value) => shared_esm_bundler_isObject(value) ? readonly(value) : value;

function reactivity_esm_bundler_isRef(r) {
  return r ? r["__v_isRef"] === true : false;
}
function reactivity_esm_bundler_ref(value) {
  return createRef(value, false);
}
function reactivity_esm_bundler_shallowRef(value) {
  return createRef(value, true);
}
function createRef(rawValue, shallow) {
  if (reactivity_esm_bundler_isRef(rawValue)) {
    return rawValue;
  }
  return new RefImpl(rawValue, shallow);
}
class RefImpl {
  constructor(value, isShallow2) {
    this.dep = new Dep();
    this["__v_isRef"] = true;
    this["__v_isShallow"] = false;
    this._rawValue = isShallow2 ? value : reactivity_esm_bundler_toRaw(value);
    this._value = isShallow2 ? value : toReactive(value);
    this["__v_isShallow"] = isShallow2;
  }
  get value() {
    if (false) {} else {
      this.dep.track();
    }
    return this._value;
  }
  set value(newValue) {
    const oldValue = this._rawValue;
    const useDirectValue = this["__v_isShallow"] || reactivity_esm_bundler_isShallow(newValue) || reactivity_esm_bundler_isReadonly(newValue);
    newValue = useDirectValue ? newValue : reactivity_esm_bundler_toRaw(newValue);
    if (shared_esm_bundler_hasChanged(newValue, oldValue)) {
      this._rawValue = newValue;
      this._value = useDirectValue ? newValue : toReactive(newValue);
      if (false) {} else {
        this.dep.trigger();
      }
    }
  }
}
function triggerRef(ref2) {
  if (ref2.dep) {
    if (false) {} else {
      ref2.dep.trigger();
    }
  }
}
function reactivity_esm_bundler_unref(ref2) {
  return reactivity_esm_bundler_isRef(ref2) ? ref2.value : ref2;
}
function toValue(source) {
  return isFunction(source) ? source() : reactivity_esm_bundler_unref(source);
}
const shallowUnwrapHandlers = {
  get: (target, key, receiver) => key === "__v_raw" ? target : reactivity_esm_bundler_unref(Reflect.get(target, key, receiver)),
  set: (target, key, value, receiver) => {
    const oldValue = target[key];
    if (reactivity_esm_bundler_isRef(oldValue) && !reactivity_esm_bundler_isRef(value)) {
      oldValue.value = value;
      return true;
    } else {
      return Reflect.set(target, key, value, receiver);
    }
  }
};
function proxyRefs(objectWithRefs) {
  return reactivity_esm_bundler_isReactive(objectWithRefs) ? objectWithRefs : new Proxy(objectWithRefs, shallowUnwrapHandlers);
}
class CustomRefImpl {
  constructor(factory) {
    this["__v_isRef"] = true;
    this._value = void 0;
    const dep = this.dep = new Dep();
    const { get, set } = factory(dep.track.bind(dep), dep.trigger.bind(dep));
    this._get = get;
    this._set = set;
  }
  get value() {
    return this._value = this._get();
  }
  set value(newVal) {
    this._set(newVal);
  }
}
function reactivity_esm_bundler_customRef(factory) {
  return new CustomRefImpl(factory);
}
function toRefs(object) {
  if (false) {}
  const ret = shared_esm_bundler_isArray(object) ? new Array(object.length) : {};
  for (const key in object) {
    ret[key] = propertyToRef(object, key);
  }
  return ret;
}
class ObjectRefImpl {
  constructor(_object, _key, _defaultValue) {
    this._object = _object;
    this._key = _key;
    this._defaultValue = _defaultValue;
    this["__v_isRef"] = true;
    this._value = void 0;
  }
  get value() {
    const val = this._object[this._key];
    return this._value = val === void 0 ? this._defaultValue : val;
  }
  set value(newVal) {
    this._object[this._key] = newVal;
  }
  get dep() {
    return getDepFromReactive(reactivity_esm_bundler_toRaw(this._object), this._key);
  }
}
class GetterRefImpl {
  constructor(_getter) {
    this._getter = _getter;
    this["__v_isRef"] = true;
    this["__v_isReadonly"] = true;
    this._value = void 0;
  }
  get value() {
    return this._value = this._getter();
  }
}
function reactivity_esm_bundler_toRef(source, key, defaultValue) {
  if (reactivity_esm_bundler_isRef(source)) {
    return source;
  } else if (isFunction(source)) {
    return new GetterRefImpl(source);
  } else if (isObject(source) && arguments.length > 1) {
    return propertyToRef(source, key, defaultValue);
  } else {
    return reactivity_esm_bundler_ref(source);
  }
}
function propertyToRef(source, key, defaultValue) {
  const val = source[key];
  return reactivity_esm_bundler_isRef(val) ? val : new ObjectRefImpl(source, key, defaultValue);
}

class ComputedRefImpl {
  constructor(fn, setter, isSSR) {
    this.fn = fn;
    this.setter = setter;
    /**
     * @internal
     */
    this._value = void 0;
    /**
     * @internal
     */
    this.dep = new Dep(this);
    /**
     * @internal
     */
    this.__v_isRef = true;
    // TODO isolatedDeclarations "__v_isReadonly"
    // A computed is also a subscriber that tracks other deps
    /**
     * @internal
     */
    this.deps = void 0;
    /**
     * @internal
     */
    this.depsTail = void 0;
    /**
     * @internal
     */
    this.flags = 16;
    /**
     * @internal
     */
    this.globalVersion = globalVersion - 1;
    /**
     * @internal
     */
    this.next = void 0;
    // for backwards compat
    this.effect = this;
    this["__v_isReadonly"] = !setter;
    this.isSSR = isSSR;
  }
  /**
   * @internal
   */
  notify() {
    this.flags |= 16;
    if (!(this.flags & 8) && // avoid infinite self recursion
    activeSub !== this) {
      batch(this, true);
      return true;
    } else if (false) {}
  }
  get value() {
    const link =  false ? 0 : this.dep.track();
    refreshComputed(this);
    if (link) {
      link.version = this.dep.version;
    }
    return this._value;
  }
  set value(newValue) {
    if (this.setter) {
      this.setter(newValue);
    } else if (false) {}
  }
}
function reactivity_esm_bundler_computed(getterOrOptions, debugOptions, isSSR = false) {
  let getter;
  let setter;
  if (shared_esm_bundler_isFunction(getterOrOptions)) {
    getter = getterOrOptions;
  } else {
    getter = getterOrOptions.get;
    setter = getterOrOptions.set;
  }
  const cRef = new ComputedRefImpl(getter, setter, isSSR);
  if (false) {}
  return cRef;
}

const TrackOpTypes = {
  "GET": "get",
  "HAS": "has",
  "ITERATE": "iterate"
};
const TriggerOpTypes = {
  "SET": "set",
  "ADD": "add",
  "DELETE": "delete",
  "CLEAR": "clear"
};
const ReactiveFlags = {
  "SKIP": "__v_skip",
  "IS_REACTIVE": "__v_isReactive",
  "IS_READONLY": "__v_isReadonly",
  "IS_SHALLOW": "__v_isShallow",
  "RAW": "__v_raw",
  "IS_REF": "__v_isRef"
};

const WatchErrorCodes = {
  "WATCH_GETTER": 2,
  "2": "WATCH_GETTER",
  "WATCH_CALLBACK": 3,
  "3": "WATCH_CALLBACK",
  "WATCH_CLEANUP": 4,
  "4": "WATCH_CLEANUP"
};
const INITIAL_WATCHER_VALUE = {};
const cleanupMap = /* @__PURE__ */ new WeakMap();
let activeWatcher = void 0;
function getCurrentWatcher() {
  return activeWatcher;
}
function onWatcherCleanup(cleanupFn, failSilently = false, owner = activeWatcher) {
  if (owner) {
    let cleanups = cleanupMap.get(owner);
    if (!cleanups) cleanupMap.set(owner, cleanups = []);
    cleanups.push(cleanupFn);
  } else if (false) {}
}
function reactivity_esm_bundler_watch(source, cb, options = shared_esm_bundler_EMPTY_OBJ) {
  const { immediate, deep, once, scheduler, augmentJob, call } = options;
  const warnInvalidSource = (s) => {
    (options.onWarn || reactivity_esm_bundler_warn)(
      `Invalid watch source: `,
      s,
      `A watch source can only be a getter/effect function, a ref, a reactive object, or an array of these types.`
    );
  };
  const reactiveGetter = (source2) => {
    if (deep) return source2;
    if (reactivity_esm_bundler_isShallow(source2) || deep === false || deep === 0)
      return traverse(source2, 1);
    return traverse(source2);
  };
  let effect;
  let getter;
  let cleanup;
  let boundCleanup;
  let forceTrigger = false;
  let isMultiSource = false;
  if (reactivity_esm_bundler_isRef(source)) {
    getter = () => source.value;
    forceTrigger = reactivity_esm_bundler_isShallow(source);
  } else if (reactivity_esm_bundler_isReactive(source)) {
    getter = () => reactiveGetter(source);
    forceTrigger = true;
  } else if (shared_esm_bundler_isArray(source)) {
    isMultiSource = true;
    forceTrigger = source.some((s) => reactivity_esm_bundler_isReactive(s) || reactivity_esm_bundler_isShallow(s));
    getter = () => source.map((s) => {
      if (reactivity_esm_bundler_isRef(s)) {
        return s.value;
      } else if (reactivity_esm_bundler_isReactive(s)) {
        return reactiveGetter(s);
      } else if (shared_esm_bundler_isFunction(s)) {
        return call ? call(s, 2) : s();
      } else {
         false && 0;
      }
    });
  } else if (shared_esm_bundler_isFunction(source)) {
    if (cb) {
      getter = call ? () => call(source, 2) : source;
    } else {
      getter = () => {
        if (cleanup) {
          reactivity_esm_bundler_pauseTracking();
          try {
            cleanup();
          } finally {
            reactivity_esm_bundler_resetTracking();
          }
        }
        const currentEffect = activeWatcher;
        activeWatcher = effect;
        try {
          return call ? call(source, 3, [boundCleanup]) : source(boundCleanup);
        } finally {
          activeWatcher = currentEffect;
        }
      };
    }
  } else {
    getter = shared_esm_bundler_NOOP;
     false && 0;
  }
  if (cb && deep) {
    const baseGetter = getter;
    const depth = deep === true ? Infinity : deep;
    getter = () => traverse(baseGetter(), depth);
  }
  const scope = getCurrentScope();
  const watchHandle = () => {
    effect.stop();
    if (scope && scope.active) {
      remove(scope.effects, effect);
    }
  };
  if (once && cb) {
    const _cb = cb;
    cb = (...args) => {
      _cb(...args);
      watchHandle();
    };
  }
  let oldValue = isMultiSource ? new Array(source.length).fill(INITIAL_WATCHER_VALUE) : INITIAL_WATCHER_VALUE;
  const job = (immediateFirstRun) => {
    if (!(effect.flags & 1) || !effect.dirty && !immediateFirstRun) {
      return;
    }
    if (cb) {
      const newValue = effect.run();
      if (deep || forceTrigger || (isMultiSource ? newValue.some((v, i) => shared_esm_bundler_hasChanged(v, oldValue[i])) : shared_esm_bundler_hasChanged(newValue, oldValue))) {
        if (cleanup) {
          cleanup();
        }
        const currentWatcher = activeWatcher;
        activeWatcher = effect;
        try {
          const args = [
            newValue,
            // pass undefined as the old value when it's changed for the first time
            oldValue === INITIAL_WATCHER_VALUE ? void 0 : isMultiSource && oldValue[0] === INITIAL_WATCHER_VALUE ? [] : oldValue,
            boundCleanup
          ];
          oldValue = newValue;
          call ? call(cb, 3, args) : (
            // @ts-expect-error
            cb(...args)
          );
        } finally {
          activeWatcher = currentWatcher;
        }
      }
    } else {
      effect.run();
    }
  };
  if (augmentJob) {
    augmentJob(job);
  }
  effect = new ReactiveEffect(getter);
  effect.scheduler = scheduler ? () => scheduler(job, false) : job;
  boundCleanup = (fn) => onWatcherCleanup(fn, false, effect);
  cleanup = effect.onStop = () => {
    const cleanups = cleanupMap.get(effect);
    if (cleanups) {
      if (call) {
        call(cleanups, 4);
      } else {
        for (const cleanup2 of cleanups) cleanup2();
      }
      cleanupMap.delete(effect);
    }
  };
  if (false) {}
  if (cb) {
    if (immediate) {
      job(true);
    } else {
      oldValue = effect.run();
    }
  } else if (scheduler) {
    scheduler(job.bind(null, true), true);
  } else {
    effect.run();
  }
  watchHandle.pause = effect.pause.bind(effect);
  watchHandle.resume = effect.resume.bind(effect);
  watchHandle.stop = watchHandle;
  return watchHandle;
}
function traverse(value, depth = Infinity, seen) {
  if (depth <= 0 || !shared_esm_bundler_isObject(value) || value["__v_skip"]) {
    return value;
  }
  seen = seen || /* @__PURE__ */ new Set();
  if (seen.has(value)) {
    return value;
  }
  seen.add(value);
  depth--;
  if (reactivity_esm_bundler_isRef(value)) {
    traverse(value.value, depth, seen);
  } else if (shared_esm_bundler_isArray(value)) {
    for (let i = 0; i < value.length; i++) {
      traverse(value[i], depth, seen);
    }
  } else if (shared_esm_bundler_isSet(value) || isMap(value)) {
    value.forEach((v) => {
      traverse(v, depth, seen);
    });
  } else if (shared_esm_bundler_isPlainObject(value)) {
    for (const key in value) {
      traverse(value[key], depth, seen);
    }
    for (const key of Object.getOwnPropertySymbols(value)) {
      if (Object.prototype.propertyIsEnumerable.call(value, key)) {
        traverse(value[key], depth, seen);
      }
    }
  }
  return value;
}



;// CONCATENATED MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
/**
* @vue/runtime-core v3.5.20
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/





const stack = [];
function pushWarningContext(vnode) {
  stack.push(vnode);
}
function popWarningContext() {
  stack.pop();
}
let isWarning = false;
function warn$1(msg, ...args) {
  if (isWarning) return;
  isWarning = true;
  pauseTracking();
  const instance = stack.length ? stack[stack.length - 1].component : null;
  const appWarnHandler = instance && instance.appContext.config.warnHandler;
  const trace = getComponentTrace();
  if (appWarnHandler) {
    callWithErrorHandling(
      appWarnHandler,
      instance,
      11,
      [
        // eslint-disable-next-line no-restricted-syntax
        msg + args.map((a) => {
          var _a, _b;
          return (_b = (_a = a.toString) == null ? void 0 : _a.call(a)) != null ? _b : JSON.stringify(a);
        }).join(""),
        instance && instance.proxy,
        trace.map(
          ({ vnode }) => `at <${formatComponentName(instance, vnode.type)}>`
        ).join("\n"),
        trace
      ]
    );
  } else {
    const warnArgs = [`[Vue warn]: ${msg}`, ...args];
    if (trace.length && // avoid spamming console during tests
    true) {
      warnArgs.push(`
`, ...formatTrace(trace));
    }
    console.warn(...warnArgs);
  }
  resetTracking();
  isWarning = false;
}
function getComponentTrace() {
  let currentVNode = stack[stack.length - 1];
  if (!currentVNode) {
    return [];
  }
  const normalizedStack = [];
  while (currentVNode) {
    const last = normalizedStack[0];
    if (last && last.vnode === currentVNode) {
      last.recurseCount++;
    } else {
      normalizedStack.push({
        vnode: currentVNode,
        recurseCount: 0
      });
    }
    const parentInstance = currentVNode.component && currentVNode.component.parent;
    currentVNode = parentInstance && parentInstance.vnode;
  }
  return normalizedStack;
}
function formatTrace(trace) {
  const logs = [];
  trace.forEach((entry, i) => {
    logs.push(...i === 0 ? [] : [`
`], ...formatTraceEntry(entry));
  });
  return logs;
}
function formatTraceEntry({ vnode, recurseCount }) {
  const postfix = recurseCount > 0 ? `... (${recurseCount} recursive calls)` : ``;
  const isRoot = vnode.component ? vnode.component.parent == null : false;
  const open = ` at <${formatComponentName(
    vnode.component,
    vnode.type,
    isRoot
  )}`;
  const close = `>` + postfix;
  return vnode.props ? [open, ...formatProps(vnode.props), close] : [open + close];
}
function formatProps(props) {
  const res = [];
  const keys = Object.keys(props);
  keys.slice(0, 3).forEach((key) => {
    res.push(...formatProp(key, props[key]));
  });
  if (keys.length > 3) {
    res.push(` ...`);
  }
  return res;
}
function formatProp(key, value, raw) {
  if (isString(value)) {
    value = JSON.stringify(value);
    return raw ? value : [`${key}=${value}`];
  } else if (typeof value === "number" || typeof value === "boolean" || value == null) {
    return raw ? value : [`${key}=${value}`];
  } else if (isRef(value)) {
    value = formatProp(key, toRaw(value.value), true);
    return raw ? value : [`${key}=Ref<`, value, `>`];
  } else if (isFunction(value)) {
    return [`${key}=fn${value.name ? `<${value.name}>` : ``}`];
  } else {
    value = toRaw(value);
    return raw ? value : [`${key}=`, value];
  }
}
function assertNumber(val, type) {
  if (true) return;
  if (val === void 0) {
    return;
  } else if (typeof val !== "number") {
    warn$1(`${type} is not a valid number - got ${JSON.stringify(val)}.`);
  } else if (isNaN(val)) {
    warn$1(`${type} is NaN - the duration expression might be incorrect.`);
  }
}

const ErrorCodes = {
  "SETUP_FUNCTION": 0,
  "0": "SETUP_FUNCTION",
  "RENDER_FUNCTION": 1,
  "1": "RENDER_FUNCTION",
  "NATIVE_EVENT_HANDLER": 5,
  "5": "NATIVE_EVENT_HANDLER",
  "COMPONENT_EVENT_HANDLER": 6,
  "6": "COMPONENT_EVENT_HANDLER",
  "VNODE_HOOK": 7,
  "7": "VNODE_HOOK",
  "DIRECTIVE_HOOK": 8,
  "8": "DIRECTIVE_HOOK",
  "TRANSITION_HOOK": 9,
  "9": "TRANSITION_HOOK",
  "APP_ERROR_HANDLER": 10,
  "10": "APP_ERROR_HANDLER",
  "APP_WARN_HANDLER": 11,
  "11": "APP_WARN_HANDLER",
  "FUNCTION_REF": 12,
  "12": "FUNCTION_REF",
  "ASYNC_COMPONENT_LOADER": 13,
  "13": "ASYNC_COMPONENT_LOADER",
  "SCHEDULER": 14,
  "14": "SCHEDULER",
  "COMPONENT_UPDATE": 15,
  "15": "COMPONENT_UPDATE",
  "APP_UNMOUNT_CLEANUP": 16,
  "16": "APP_UNMOUNT_CLEANUP"
};
const ErrorTypeStrings$1 = {
  ["sp"]: "serverPrefetch hook",
  ["bc"]: "beforeCreate hook",
  ["c"]: "created hook",
  ["bm"]: "beforeMount hook",
  ["m"]: "mounted hook",
  ["bu"]: "beforeUpdate hook",
  ["u"]: "updated",
  ["bum"]: "beforeUnmount hook",
  ["um"]: "unmounted hook",
  ["a"]: "activated hook",
  ["da"]: "deactivated hook",
  ["ec"]: "errorCaptured hook",
  ["rtc"]: "renderTracked hook",
  ["rtg"]: "renderTriggered hook",
  [0]: "setup function",
  [1]: "render function",
  [2]: "watcher getter",
  [3]: "watcher callback",
  [4]: "watcher cleanup function",
  [5]: "native event handler",
  [6]: "component event handler",
  [7]: "vnode hook",
  [8]: "directive hook",
  [9]: "transition hook",
  [10]: "app errorHandler",
  [11]: "app warnHandler",
  [12]: "ref function",
  [13]: "async component loader",
  [14]: "scheduler flush",
  [15]: "component update",
  [16]: "app unmount cleanup function"
};
function callWithErrorHandling(fn, instance, type, args) {
  try {
    return args ? fn(...args) : fn();
  } catch (err) {
    handleError(err, instance, type);
  }
}
function callWithAsyncErrorHandling(fn, instance, type, args) {
  if (shared_esm_bundler_isFunction(fn)) {
    const res = callWithErrorHandling(fn, instance, type, args);
    if (res && shared_esm_bundler_isPromise(res)) {
      res.catch((err) => {
        handleError(err, instance, type);
      });
    }
    return res;
  }
  if (shared_esm_bundler_isArray(fn)) {
    const values = [];
    for (let i = 0; i < fn.length; i++) {
      values.push(callWithAsyncErrorHandling(fn[i], instance, type, args));
    }
    return values;
  } else if (false) {}
}
function handleError(err, instance, type, throwInDev = true) {
  const contextVNode = instance ? instance.vnode : null;
  const { errorHandler, throwUnhandledErrorInProduction } = instance && instance.appContext.config || shared_esm_bundler_EMPTY_OBJ;
  if (instance) {
    let cur = instance.parent;
    const exposedInstance = instance.proxy;
    const errorInfo =  false ? 0 : `https://vuejs.org/error-reference/#runtime-${type}`;
    while (cur) {
      const errorCapturedHooks = cur.ec;
      if (errorCapturedHooks) {
        for (let i = 0; i < errorCapturedHooks.length; i++) {
          if (errorCapturedHooks[i](err, exposedInstance, errorInfo) === false) {
            return;
          }
        }
      }
      cur = cur.parent;
    }
    if (errorHandler) {
      reactivity_esm_bundler_pauseTracking();
      callWithErrorHandling(errorHandler, null, 10, [
        err,
        exposedInstance,
        errorInfo
      ]);
      reactivity_esm_bundler_resetTracking();
      return;
    }
  }
  logError(err, type, contextVNode, throwInDev, throwUnhandledErrorInProduction);
}
function logError(err, type, contextVNode, throwInDev = true, throwInProd = false) {
  if (false) {} else if (throwInProd) {
    throw err;
  } else {
    console.error(err);
  }
}

const queue = [];
let flushIndex = -1;
const pendingPostFlushCbs = [];
let activePostFlushCbs = null;
let postFlushIndex = 0;
const resolvedPromise = /* @__PURE__ */ Promise.resolve();
let currentFlushPromise = null;
const RECURSION_LIMIT = 100;
function nextTick(fn) {
  const p = currentFlushPromise || resolvedPromise;
  return fn ? p.then(this ? fn.bind(this) : fn) : p;
}
function findInsertionIndex(id) {
  let start = flushIndex + 1;
  let end = queue.length;
  while (start < end) {
    const middle = start + end >>> 1;
    const middleJob = queue[middle];
    const middleJobId = getId(middleJob);
    if (middleJobId < id || middleJobId === id && middleJob.flags & 2) {
      start = middle + 1;
    } else {
      end = middle;
    }
  }
  return start;
}
function queueJob(job) {
  if (!(job.flags & 1)) {
    const jobId = getId(job);
    const lastJob = queue[queue.length - 1];
    if (!lastJob || // fast path when the job id is larger than the tail
    !(job.flags & 2) && jobId >= getId(lastJob)) {
      queue.push(job);
    } else {
      queue.splice(findInsertionIndex(jobId), 0, job);
    }
    job.flags |= 1;
    queueFlush();
  }
}
function queueFlush() {
  if (!currentFlushPromise) {
    currentFlushPromise = resolvedPromise.then(flushJobs);
  }
}
function runtime_core_esm_bundler_queuePostFlushCb(cb) {
  if (!shared_esm_bundler_isArray(cb)) {
    if (activePostFlushCbs && cb.id === -1) {
      activePostFlushCbs.splice(postFlushIndex + 1, 0, cb);
    } else if (!(cb.flags & 1)) {
      pendingPostFlushCbs.push(cb);
      cb.flags |= 1;
    }
  } else {
    pendingPostFlushCbs.push(...cb);
  }
  queueFlush();
}
function flushPreFlushCbs(instance, seen, i = flushIndex + 1) {
  if (false) {}
  for (; i < queue.length; i++) {
    const cb = queue[i];
    if (cb && cb.flags & 2) {
      if (instance && cb.id !== instance.uid) {
        continue;
      }
      if (false) {}
      queue.splice(i, 1);
      i--;
      if (cb.flags & 4) {
        cb.flags &= -2;
      }
      cb();
      if (!(cb.flags & 4)) {
        cb.flags &= -2;
      }
    }
  }
}
function flushPostFlushCbs(seen) {
  if (pendingPostFlushCbs.length) {
    const deduped = [...new Set(pendingPostFlushCbs)].sort(
      (a, b) => getId(a) - getId(b)
    );
    pendingPostFlushCbs.length = 0;
    if (activePostFlushCbs) {
      activePostFlushCbs.push(...deduped);
      return;
    }
    activePostFlushCbs = deduped;
    if (false) {}
    for (postFlushIndex = 0; postFlushIndex < activePostFlushCbs.length; postFlushIndex++) {
      const cb = activePostFlushCbs[postFlushIndex];
      if (false) {}
      if (cb.flags & 4) {
        cb.flags &= -2;
      }
      if (!(cb.flags & 8)) cb();
      cb.flags &= -2;
    }
    activePostFlushCbs = null;
    postFlushIndex = 0;
  }
}
const getId = (job) => job.id == null ? job.flags & 2 ? -1 : Infinity : job.id;
function flushJobs(seen) {
  if (false) {}
  const check =  false ? 0 : shared_esm_bundler_NOOP;
  try {
    for (flushIndex = 0; flushIndex < queue.length; flushIndex++) {
      const job = queue[flushIndex];
      if (job && !(job.flags & 8)) {
        if (false) {}
        if (job.flags & 4) {
          job.flags &= ~1;
        }
        callWithErrorHandling(
          job,
          job.i,
          job.i ? 15 : 14
        );
        if (!(job.flags & 4)) {
          job.flags &= ~1;
        }
      }
    }
  } finally {
    for (; flushIndex < queue.length; flushIndex++) {
      const job = queue[flushIndex];
      if (job) {
        job.flags &= -2;
      }
    }
    flushIndex = -1;
    queue.length = 0;
    flushPostFlushCbs(seen);
    currentFlushPromise = null;
    if (queue.length || pendingPostFlushCbs.length) {
      flushJobs(seen);
    }
  }
}
function checkRecursiveUpdates(seen, fn) {
  const count = seen.get(fn) || 0;
  if (count > RECURSION_LIMIT) {
    const instance = fn.i;
    const componentName = instance && getComponentName(instance.type);
    handleError(
      `Maximum recursive updates exceeded${componentName ? ` in component <${componentName}>` : ``}. This means you have a reactive effect that is mutating its own dependencies and thus recursively triggering itself. Possible sources include component template, render function, updated hook or watcher source function.`,
      null,
      10
    );
    return true;
  }
  seen.set(fn, count + 1);
  return false;
}

let isHmrUpdating = false;
const hmrDirtyComponents = /* @__PURE__ */ new Map();
if (false) {}
const map = /* @__PURE__ */ new Map();
function registerHMR(instance) {
  const id = instance.type.__hmrId;
  let record = map.get(id);
  if (!record) {
    createRecord(id, instance.type);
    record = map.get(id);
  }
  record.instances.add(instance);
}
function unregisterHMR(instance) {
  map.get(instance.type.__hmrId).instances.delete(instance);
}
function createRecord(id, initialDef) {
  if (map.has(id)) {
    return false;
  }
  map.set(id, {
    initialDef: normalizeClassComponent(initialDef),
    instances: /* @__PURE__ */ new Set()
  });
  return true;
}
function normalizeClassComponent(component) {
  return isClassComponent(component) ? component.__vccOpts : component;
}
function rerender(id, newRender) {
  const record = map.get(id);
  if (!record) {
    return;
  }
  record.initialDef.render = newRender;
  [...record.instances].forEach((instance) => {
    if (newRender) {
      instance.render = newRender;
      normalizeClassComponent(instance.type).render = newRender;
    }
    instance.renderCache = [];
    isHmrUpdating = true;
    if (!(instance.job.flags & 8)) {
      instance.update();
    }
    isHmrUpdating = false;
  });
}
function reload(id, newComp) {
  const record = map.get(id);
  if (!record) return;
  newComp = normalizeClassComponent(newComp);
  updateComponentDef(record.initialDef, newComp);
  const instances = [...record.instances];
  for (let i = 0; i < instances.length; i++) {
    const instance = instances[i];
    const oldComp = normalizeClassComponent(instance.type);
    let dirtyInstances = hmrDirtyComponents.get(oldComp);
    if (!dirtyInstances) {
      if (oldComp !== record.initialDef) {
        updateComponentDef(oldComp, newComp);
      }
      hmrDirtyComponents.set(oldComp, dirtyInstances = /* @__PURE__ */ new Set());
    }
    dirtyInstances.add(instance);
    instance.appContext.propsCache.delete(instance.type);
    instance.appContext.emitsCache.delete(instance.type);
    instance.appContext.optionsCache.delete(instance.type);
    if (instance.ceReload) {
      dirtyInstances.add(instance);
      instance.ceReload(newComp.styles);
      dirtyInstances.delete(instance);
    } else if (instance.parent) {
      queueJob(() => {
        isHmrUpdating = true;
        instance.parent.update();
        isHmrUpdating = false;
        dirtyInstances.delete(instance);
      });
    } else if (instance.appContext.reload) {
      instance.appContext.reload();
    } else if (typeof window !== "undefined") {
      window.location.reload();
    } else {
      console.warn(
        "[HMR] Root or manually mounted instance modified. Full reload required."
      );
    }
    if (instance.root.ce && instance !== instance.root) {
      instance.root.ce._removeChildStyle(oldComp);
    }
  }
  runtime_core_esm_bundler_queuePostFlushCb(() => {
    hmrDirtyComponents.clear();
  });
}
function updateComponentDef(oldComp, newComp) {
  extend(oldComp, newComp);
  for (const key in oldComp) {
    if (key !== "__file" && !(key in newComp)) {
      delete oldComp[key];
    }
  }
}
function tryWrap(fn) {
  return (id, arg) => {
    try {
      return fn(id, arg);
    } catch (e) {
      console.error(e);
      console.warn(
        `[HMR] Something went wrong during Vue component hot-reload. Full reload required.`
      );
    }
  };
}

let devtools$1;
let buffer = (/* unused pure expression or super */ null && ([]));
let devtoolsNotInstalled = false;
function emit$1(event, ...args) {
  if (devtools$1) {
    devtools$1.emit(event, ...args);
  } else if (!devtoolsNotInstalled) {
    buffer.push({ event, args });
  }
}
function setDevtoolsHook$1(hook, target) {
  var _a, _b;
  devtools$1 = hook;
  if (devtools$1) {
    devtools$1.enabled = true;
    buffer.forEach(({ event, args }) => devtools$1.emit(event, ...args));
    buffer = [];
  } else if (
    // handle late devtools injection - only do this if we are in an actual
    // browser environment to avoid the timer handle stalling test runner exit
    // (#4815)
    typeof window !== "undefined" && // some envs mock window but not fully
    window.HTMLElement && // also exclude jsdom
    // eslint-disable-next-line no-restricted-syntax
    !((_b = (_a = window.navigator) == null ? void 0 : _a.userAgent) == null ? void 0 : _b.includes("jsdom"))
  ) {
    const replay = target.__VUE_DEVTOOLS_HOOK_REPLAY__ = target.__VUE_DEVTOOLS_HOOK_REPLAY__ || [];
    replay.push((newHook) => {
      setDevtoolsHook$1(newHook, target);
    });
    setTimeout(() => {
      if (!devtools$1) {
        target.__VUE_DEVTOOLS_HOOK_REPLAY__ = null;
        devtoolsNotInstalled = true;
        buffer = [];
      }
    }, 3e3);
  } else {
    devtoolsNotInstalled = true;
    buffer = [];
  }
}
function devtoolsInitApp(app, version) {
  emit$1("app:init" /* APP_INIT */, app, version, {
    Fragment: runtime_core_esm_bundler_Fragment,
    Text,
    Comment,
    Static: runtime_core_esm_bundler_Static
  });
}
function devtoolsUnmountApp(app) {
  emit$1("app:unmount" /* APP_UNMOUNT */, app);
}
const devtoolsComponentAdded = /* @__PURE__ */ (/* unused pure expression or super */ null && (createDevtoolsComponentHook("component:added" /* COMPONENT_ADDED */)));
const devtoolsComponentUpdated = /* @__PURE__ */ (/* unused pure expression or super */ null && (createDevtoolsComponentHook("component:updated" /* COMPONENT_UPDATED */)));
const _devtoolsComponentRemoved = /* @__PURE__ */ (/* unused pure expression or super */ null && (createDevtoolsComponentHook(
  "component:removed" /* COMPONENT_REMOVED */
)));
const devtoolsComponentRemoved = (component) => {
  if (devtools$1 && typeof devtools$1.cleanupBuffer === "function" && // remove the component if it wasn't buffered
  !devtools$1.cleanupBuffer(component)) {
    _devtoolsComponentRemoved(component);
  }
};
/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function createDevtoolsComponentHook(hook) {
  return (component) => {
    emit$1(
      hook,
      component.appContext.app,
      component.uid,
      component.parent ? component.parent.uid : void 0,
      component
    );
  };
}
const devtoolsPerfStart = /* @__PURE__ */ (/* unused pure expression or super */ null && (createDevtoolsPerformanceHook("perf:start" /* PERFORMANCE_START */)));
const devtoolsPerfEnd = /* @__PURE__ */ (/* unused pure expression or super */ null && (createDevtoolsPerformanceHook("perf:end" /* PERFORMANCE_END */)));
function createDevtoolsPerformanceHook(hook) {
  return (component, type, time) => {
    emit$1(hook, component.appContext.app, component.uid, component, type, time);
  };
}
function devtoolsComponentEmit(component, event, params) {
  emit$1(
    "component:emit" /* COMPONENT_EMIT */,
    component.appContext.app,
    component,
    event,
    params
  );
}

let currentRenderingInstance = null;
let currentScopeId = null;
function setCurrentRenderingInstance(instance) {
  const prev = currentRenderingInstance;
  currentRenderingInstance = instance;
  currentScopeId = instance && instance.type.__scopeId || null;
  return prev;
}
function pushScopeId(id) {
  currentScopeId = id;
}
function popScopeId() {
  currentScopeId = null;
}
const withScopeId = (_id) => withCtx;
function withCtx(fn, ctx = currentRenderingInstance, isNonScopedSlot) {
  if (!ctx) return fn;
  if (fn._n) {
    return fn;
  }
  const renderFnWithContext = (...args) => {
    if (renderFnWithContext._d) {
      setBlockTracking(-1);
    }
    const prevInstance = setCurrentRenderingInstance(ctx);
    let res;
    try {
      res = fn(...args);
    } finally {
      setCurrentRenderingInstance(prevInstance);
      if (renderFnWithContext._d) {
        setBlockTracking(1);
      }
    }
    if (false) {}
    return res;
  };
  renderFnWithContext._n = true;
  renderFnWithContext._c = true;
  renderFnWithContext._d = true;
  return renderFnWithContext;
}

function validateDirectiveName(name) {
  if (isBuiltInDirective(name)) {
    warn$1("Do not use built-in directive ids as custom directive id: " + name);
  }
}
function withDirectives(vnode, directives) {
  if (currentRenderingInstance === null) {
     false && 0;
    return vnode;
  }
  const instance = getComponentPublicInstance(currentRenderingInstance);
  const bindings = vnode.dirs || (vnode.dirs = []);
  for (let i = 0; i < directives.length; i++) {
    let [dir, value, arg, modifiers = shared_esm_bundler_EMPTY_OBJ] = directives[i];
    if (dir) {
      if (shared_esm_bundler_isFunction(dir)) {
        dir = {
          mounted: dir,
          updated: dir
        };
      }
      if (dir.deep) {
        traverse(value);
      }
      bindings.push({
        dir,
        instance,
        value,
        oldValue: void 0,
        arg,
        modifiers
      });
    }
  }
  return vnode;
}
function invokeDirectiveHook(vnode, prevVNode, instance, name) {
  const bindings = vnode.dirs;
  const oldBindings = prevVNode && prevVNode.dirs;
  for (let i = 0; i < bindings.length; i++) {
    const binding = bindings[i];
    if (oldBindings) {
      binding.oldValue = oldBindings[i].value;
    }
    let hook = binding.dir[name];
    if (hook) {
      reactivity_esm_bundler_pauseTracking();
      callWithAsyncErrorHandling(hook, instance, 8, [
        vnode.el,
        binding,
        vnode,
        prevVNode
      ]);
      reactivity_esm_bundler_resetTracking();
    }
  }
}

const TeleportEndKey = Symbol("_vte");
const isTeleport = (type) => type.__isTeleport;
const isTeleportDisabled = (props) => props && (props.disabled || props.disabled === "");
const isTeleportDeferred = (props) => props && (props.defer || props.defer === "");
const isTargetSVG = (target) => typeof SVGElement !== "undefined" && target instanceof SVGElement;
const isTargetMathML = (target) => typeof MathMLElement === "function" && target instanceof MathMLElement;
const resolveTarget = (props, select) => {
  const targetSelector = props && props.to;
  if (shared_esm_bundler_isString(targetSelector)) {
    if (!select) {
       false && 0;
      return null;
    } else {
      const target = select(targetSelector);
      if (false) {}
      return target;
    }
  } else {
    if (false) {}
    return targetSelector;
  }
};
const TeleportImpl = {
  name: "Teleport",
  __isTeleport: true,
  process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, internals) {
    const {
      mc: mountChildren,
      pc: patchChildren,
      pbc: patchBlockChildren,
      o: { insert, querySelector, createText, createComment }
    } = internals;
    const disabled = isTeleportDisabled(n2.props);
    let { shapeFlag, children, dynamicChildren } = n2;
    if (false) {}
    if (n1 == null) {
      const placeholder = n2.el =  false ? 0 : createText("");
      const mainAnchor = n2.anchor =  false ? 0 : createText("");
      insert(placeholder, container, anchor);
      insert(mainAnchor, container, anchor);
      const mount = (container2, anchor2) => {
        if (shapeFlag & 16) {
          if (parentComponent && parentComponent.isCE) {
            parentComponent.ce._teleportTarget = container2;
          }
          mountChildren(
            children,
            container2,
            anchor2,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        }
      };
      const mountToTarget = () => {
        const target = n2.target = resolveTarget(n2.props, querySelector);
        const targetAnchor = prepareAnchor(target, n2, createText, insert);
        if (target) {
          if (namespace !== "svg" && isTargetSVG(target)) {
            namespace = "svg";
          } else if (namespace !== "mathml" && isTargetMathML(target)) {
            namespace = "mathml";
          }
          if (!disabled) {
            mount(target, targetAnchor);
            updateCssVars(n2, false);
          }
        } else if (false) {}
      };
      if (disabled) {
        mount(container, mainAnchor);
        updateCssVars(n2, true);
      }
      if (isTeleportDeferred(n2.props)) {
        n2.el.__isMounted = false;
        queuePostRenderEffect(() => {
          mountToTarget();
          delete n2.el.__isMounted;
        }, parentSuspense);
      } else {
        mountToTarget();
      }
    } else {
      if (isTeleportDeferred(n2.props) && n1.el.__isMounted === false) {
        queuePostRenderEffect(() => {
          TeleportImpl.process(
            n1,
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized,
            internals
          );
        }, parentSuspense);
        return;
      }
      n2.el = n1.el;
      n2.targetStart = n1.targetStart;
      const mainAnchor = n2.anchor = n1.anchor;
      const target = n2.target = n1.target;
      const targetAnchor = n2.targetAnchor = n1.targetAnchor;
      const wasDisabled = isTeleportDisabled(n1.props);
      const currentContainer = wasDisabled ? container : target;
      const currentAnchor = wasDisabled ? mainAnchor : targetAnchor;
      if (namespace === "svg" || isTargetSVG(target)) {
        namespace = "svg";
      } else if (namespace === "mathml" || isTargetMathML(target)) {
        namespace = "mathml";
      }
      if (dynamicChildren) {
        patchBlockChildren(
          n1.dynamicChildren,
          dynamicChildren,
          currentContainer,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds
        );
        traverseStaticChildren(n1, n2, !!!("production" !== "production"));
      } else if (!optimized) {
        patchChildren(
          n1,
          n2,
          currentContainer,
          currentAnchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          false
        );
      }
      if (disabled) {
        if (!wasDisabled) {
          moveTeleport(
            n2,
            container,
            mainAnchor,
            internals,
            1
          );
        } else {
          if (n2.props && n1.props && n2.props.to !== n1.props.to) {
            n2.props.to = n1.props.to;
          }
        }
      } else {
        if ((n2.props && n2.props.to) !== (n1.props && n1.props.to)) {
          const nextTarget = n2.target = resolveTarget(
            n2.props,
            querySelector
          );
          if (nextTarget) {
            moveTeleport(
              n2,
              nextTarget,
              null,
              internals,
              0
            );
          } else if (false) {}
        } else if (wasDisabled) {
          moveTeleport(
            n2,
            target,
            targetAnchor,
            internals,
            1
          );
        }
      }
      updateCssVars(n2, disabled);
    }
  },
  remove(vnode, parentComponent, parentSuspense, { um: unmount, o: { remove: hostRemove } }, doRemove) {
    const {
      shapeFlag,
      children,
      anchor,
      targetStart,
      targetAnchor,
      target,
      props
    } = vnode;
    if (target) {
      hostRemove(targetStart);
      hostRemove(targetAnchor);
    }
    doRemove && hostRemove(anchor);
    if (shapeFlag & 16) {
      const shouldRemove = doRemove || !isTeleportDisabled(props);
      for (let i = 0; i < children.length; i++) {
        const child = children[i];
        unmount(
          child,
          parentComponent,
          parentSuspense,
          shouldRemove,
          !!child.dynamicChildren
        );
      }
    }
  },
  move: moveTeleport,
  hydrate: hydrateTeleport
};
function moveTeleport(vnode, container, parentAnchor, { o: { insert }, m: move }, moveType = 2) {
  if (moveType === 0) {
    insert(vnode.targetAnchor, container, parentAnchor);
  }
  const { el, anchor, shapeFlag, children, props } = vnode;
  const isReorder = moveType === 2;
  if (isReorder) {
    insert(el, container, parentAnchor);
  }
  if (!isReorder || isTeleportDisabled(props)) {
    if (shapeFlag & 16) {
      for (let i = 0; i < children.length; i++) {
        move(
          children[i],
          container,
          parentAnchor,
          2
        );
      }
    }
  }
  if (isReorder) {
    insert(anchor, container, parentAnchor);
  }
}
function hydrateTeleport(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized, {
  o: { nextSibling, parentNode, querySelector, insert, createText }
}, hydrateChildren) {
  const target = vnode.target = resolveTarget(
    vnode.props,
    querySelector
  );
  if (target) {
    const disabled = isTeleportDisabled(vnode.props);
    const targetNode = target._lpa || target.firstChild;
    if (vnode.shapeFlag & 16) {
      if (disabled) {
        vnode.anchor = hydrateChildren(
          nextSibling(node),
          vnode,
          parentNode(node),
          parentComponent,
          parentSuspense,
          slotScopeIds,
          optimized
        );
        vnode.targetStart = targetNode;
        vnode.targetAnchor = targetNode && nextSibling(targetNode);
      } else {
        vnode.anchor = nextSibling(node);
        let targetAnchor = targetNode;
        while (targetAnchor) {
          if (targetAnchor && targetAnchor.nodeType === 8) {
            if (targetAnchor.data === "teleport start anchor") {
              vnode.targetStart = targetAnchor;
            } else if (targetAnchor.data === "teleport anchor") {
              vnode.targetAnchor = targetAnchor;
              target._lpa = vnode.targetAnchor && nextSibling(vnode.targetAnchor);
              break;
            }
          }
          targetAnchor = nextSibling(targetAnchor);
        }
        if (!vnode.targetAnchor) {
          prepareAnchor(target, vnode, createText, insert);
        }
        hydrateChildren(
          targetNode && nextSibling(targetNode),
          vnode,
          target,
          parentComponent,
          parentSuspense,
          slotScopeIds,
          optimized
        );
      }
    }
    updateCssVars(vnode, disabled);
  }
  return vnode.anchor && nextSibling(vnode.anchor);
}
const Teleport = (/* unused pure expression or super */ null && (TeleportImpl));
function updateCssVars(vnode, isDisabled) {
  const ctx = vnode.ctx;
  if (ctx && ctx.ut) {
    let node, anchor;
    if (isDisabled) {
      node = vnode.el;
      anchor = vnode.anchor;
    } else {
      node = vnode.targetStart;
      anchor = vnode.targetAnchor;
    }
    while (node && node !== anchor) {
      if (node.nodeType === 1) node.setAttribute("data-v-owner", ctx.uid);
      node = node.nextSibling;
    }
    ctx.ut();
  }
}
function prepareAnchor(target, vnode, createText, insert) {
  const targetStart = vnode.targetStart = createText("");
  const targetAnchor = vnode.targetAnchor = createText("");
  targetStart[TeleportEndKey] = targetAnchor;
  if (target) {
    insert(targetStart, target);
    insert(targetAnchor, target);
  }
  return targetAnchor;
}

const leaveCbKey = Symbol("_leaveCb");
const enterCbKey = Symbol("_enterCb");
function useTransitionState() {
  const state = {
    isMounted: false,
    isLeaving: false,
    isUnmounting: false,
    leavingVNodes: /* @__PURE__ */ new Map()
  };
  runtime_core_esm_bundler_onMounted(() => {
    state.isMounted = true;
  });
  onBeforeUnmount(() => {
    state.isUnmounting = true;
  });
  return state;
}
const TransitionHookValidator = [Function, Array];
const BaseTransitionPropsValidators = {
  mode: String,
  appear: Boolean,
  persisted: Boolean,
  // enter
  onBeforeEnter: TransitionHookValidator,
  onEnter: TransitionHookValidator,
  onAfterEnter: TransitionHookValidator,
  onEnterCancelled: TransitionHookValidator,
  // leave
  onBeforeLeave: TransitionHookValidator,
  onLeave: TransitionHookValidator,
  onAfterLeave: TransitionHookValidator,
  onLeaveCancelled: TransitionHookValidator,
  // appear
  onBeforeAppear: TransitionHookValidator,
  onAppear: TransitionHookValidator,
  onAfterAppear: TransitionHookValidator,
  onAppearCancelled: TransitionHookValidator
};
const recursiveGetSubtree = (instance) => {
  const subTree = instance.subTree;
  return subTree.component ? recursiveGetSubtree(subTree.component) : subTree;
};
const BaseTransitionImpl = {
  name: `BaseTransition`,
  props: BaseTransitionPropsValidators,
  setup(props, { slots }) {
    const instance = runtime_core_esm_bundler_getCurrentInstance();
    const state = useTransitionState();
    return () => {
      const children = slots.default && getTransitionRawChildren(slots.default(), true);
      if (!children || !children.length) {
        return;
      }
      const child = findNonCommentChild(children);
      const rawProps = reactivity_esm_bundler_toRaw(props);
      const { mode } = rawProps;
      if (false) {}
      if (state.isLeaving) {
        return emptyPlaceholder(child);
      }
      const innerChild = getInnerChild$1(child);
      if (!innerChild) {
        return emptyPlaceholder(child);
      }
      let enterHooks = resolveTransitionHooks(
        innerChild,
        rawProps,
        state,
        instance,
        // #11061, ensure enterHooks is fresh after clone
        (hooks) => enterHooks = hooks
      );
      if (innerChild.type !== Comment) {
        setTransitionHooks(innerChild, enterHooks);
      }
      let oldInnerChild = instance.subTree && getInnerChild$1(instance.subTree);
      if (oldInnerChild && oldInnerChild.type !== Comment && !isSameVNodeType(innerChild, oldInnerChild) && recursiveGetSubtree(instance).type !== Comment) {
        let leavingHooks = resolveTransitionHooks(
          oldInnerChild,
          rawProps,
          state,
          instance
        );
        setTransitionHooks(oldInnerChild, leavingHooks);
        if (mode === "out-in" && innerChild.type !== Comment) {
          state.isLeaving = true;
          leavingHooks.afterLeave = () => {
            state.isLeaving = false;
            if (!(instance.job.flags & 8)) {
              instance.update();
            }
            delete leavingHooks.afterLeave;
            oldInnerChild = void 0;
          };
          return emptyPlaceholder(child);
        } else if (mode === "in-out" && innerChild.type !== Comment) {
          leavingHooks.delayLeave = (el, earlyRemove, delayedLeave) => {
            const leavingVNodesCache = getLeavingNodesForType(
              state,
              oldInnerChild
            );
            leavingVNodesCache[String(oldInnerChild.key)] = oldInnerChild;
            el[leaveCbKey] = () => {
              earlyRemove();
              el[leaveCbKey] = void 0;
              delete enterHooks.delayedLeave;
              oldInnerChild = void 0;
            };
            enterHooks.delayedLeave = () => {
              delayedLeave();
              delete enterHooks.delayedLeave;
              oldInnerChild = void 0;
            };
          };
        } else {
          oldInnerChild = void 0;
        }
      } else if (oldInnerChild) {
        oldInnerChild = void 0;
      }
      return child;
    };
  }
};
function findNonCommentChild(children) {
  let child = children[0];
  if (children.length > 1) {
    let hasFound = false;
    for (const c of children) {
      if (c.type !== Comment) {
        if (false) {}
        child = c;
        hasFound = true;
        if (true) break;
      }
    }
  }
  return child;
}
const BaseTransition = BaseTransitionImpl;
function getLeavingNodesForType(state, vnode) {
  const { leavingVNodes } = state;
  let leavingVNodesCache = leavingVNodes.get(vnode.type);
  if (!leavingVNodesCache) {
    leavingVNodesCache = /* @__PURE__ */ Object.create(null);
    leavingVNodes.set(vnode.type, leavingVNodesCache);
  }
  return leavingVNodesCache;
}
function resolveTransitionHooks(vnode, props, state, instance, postClone) {
  const {
    appear,
    mode,
    persisted = false,
    onBeforeEnter,
    onEnter,
    onAfterEnter,
    onEnterCancelled,
    onBeforeLeave,
    onLeave,
    onAfterLeave,
    onLeaveCancelled,
    onBeforeAppear,
    onAppear,
    onAfterAppear,
    onAppearCancelled
  } = props;
  const key = String(vnode.key);
  const leavingVNodesCache = getLeavingNodesForType(state, vnode);
  const callHook = (hook, args) => {
    hook && callWithAsyncErrorHandling(
      hook,
      instance,
      9,
      args
    );
  };
  const callAsyncHook = (hook, args) => {
    const done = args[1];
    callHook(hook, args);
    if (shared_esm_bundler_isArray(hook)) {
      if (hook.every((hook2) => hook2.length <= 1)) done();
    } else if (hook.length <= 1) {
      done();
    }
  };
  const hooks = {
    mode,
    persisted,
    beforeEnter(el) {
      let hook = onBeforeEnter;
      if (!state.isMounted) {
        if (appear) {
          hook = onBeforeAppear || onBeforeEnter;
        } else {
          return;
        }
      }
      if (el[leaveCbKey]) {
        el[leaveCbKey](
          true
          /* cancelled */
        );
      }
      const leavingVNode = leavingVNodesCache[key];
      if (leavingVNode && isSameVNodeType(vnode, leavingVNode) && leavingVNode.el[leaveCbKey]) {
        leavingVNode.el[leaveCbKey]();
      }
      callHook(hook, [el]);
    },
    enter(el) {
      let hook = onEnter;
      let afterHook = onAfterEnter;
      let cancelHook = onEnterCancelled;
      if (!state.isMounted) {
        if (appear) {
          hook = onAppear || onEnter;
          afterHook = onAfterAppear || onAfterEnter;
          cancelHook = onAppearCancelled || onEnterCancelled;
        } else {
          return;
        }
      }
      let called = false;
      const done = el[enterCbKey] = (cancelled) => {
        if (called) return;
        called = true;
        if (cancelled) {
          callHook(cancelHook, [el]);
        } else {
          callHook(afterHook, [el]);
        }
        if (hooks.delayedLeave) {
          hooks.delayedLeave();
        }
        el[enterCbKey] = void 0;
      };
      if (hook) {
        callAsyncHook(hook, [el, done]);
      } else {
        done();
      }
    },
    leave(el, remove) {
      const key2 = String(vnode.key);
      if (el[enterCbKey]) {
        el[enterCbKey](
          true
          /* cancelled */
        );
      }
      if (state.isUnmounting) {
        return remove();
      }
      callHook(onBeforeLeave, [el]);
      let called = false;
      const done = el[leaveCbKey] = (cancelled) => {
        if (called) return;
        called = true;
        remove();
        if (cancelled) {
          callHook(onLeaveCancelled, [el]);
        } else {
          callHook(onAfterLeave, [el]);
        }
        el[leaveCbKey] = void 0;
        if (leavingVNodesCache[key2] === vnode) {
          delete leavingVNodesCache[key2];
        }
      };
      leavingVNodesCache[key2] = vnode;
      if (onLeave) {
        callAsyncHook(onLeave, [el, done]);
      } else {
        done();
      }
    },
    clone(vnode2) {
      const hooks2 = resolveTransitionHooks(
        vnode2,
        props,
        state,
        instance,
        postClone
      );
      if (postClone) postClone(hooks2);
      return hooks2;
    }
  };
  return hooks;
}
function emptyPlaceholder(vnode) {
  if (isKeepAlive(vnode)) {
    vnode = cloneVNode(vnode);
    vnode.children = null;
    return vnode;
  }
}
function getInnerChild$1(vnode) {
  if (!isKeepAlive(vnode)) {
    if (isTeleport(vnode.type) && vnode.children) {
      return findNonCommentChild(vnode.children);
    }
    return vnode;
  }
  if (vnode.component) {
    return vnode.component.subTree;
  }
  const { shapeFlag, children } = vnode;
  if (children) {
    if (shapeFlag & 16) {
      return children[0];
    }
    if (shapeFlag & 32 && shared_esm_bundler_isFunction(children.default)) {
      return children.default();
    }
  }
}
function setTransitionHooks(vnode, hooks) {
  if (vnode.shapeFlag & 6 && vnode.component) {
    vnode.transition = hooks;
    setTransitionHooks(vnode.component.subTree, hooks);
  } else if (vnode.shapeFlag & 128) {
    vnode.ssContent.transition = hooks.clone(vnode.ssContent);
    vnode.ssFallback.transition = hooks.clone(vnode.ssFallback);
  } else {
    vnode.transition = hooks;
  }
}
function getTransitionRawChildren(children, keepComment = false, parentKey) {
  let ret = [];
  let keyedFragmentCount = 0;
  for (let i = 0; i < children.length; i++) {
    let child = children[i];
    const key = parentKey == null ? child.key : String(parentKey) + String(child.key != null ? child.key : i);
    if (child.type === runtime_core_esm_bundler_Fragment) {
      if (child.patchFlag & 128) keyedFragmentCount++;
      ret = ret.concat(
        getTransitionRawChildren(child.children, keepComment, key)
      );
    } else if (keepComment || child.type !== Comment) {
      ret.push(key != null ? cloneVNode(child, { key }) : child);
    }
  }
  if (keyedFragmentCount > 1) {
    for (let i = 0; i < ret.length; i++) {
      ret[i].patchFlag = -2;
    }
  }
  return ret;
}

/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function runtime_core_esm_bundler_defineComponent(options, extraOptions) {
  return shared_esm_bundler_isFunction(options) ? (
    // #8236: extend call and options.name access are considered side-effects
    // by Rollup, so we have to wrap it in a pure-annotated IIFE.
    /* @__PURE__ */ (() => shared_esm_bundler_extend({ name: options.name }, extraOptions, { setup: options }))()
  ) : options;
}

function useId() {
  const i = runtime_core_esm_bundler_getCurrentInstance();
  if (i) {
    return (i.appContext.config.idPrefix || "v") + "-" + i.ids[0] + i.ids[1]++;
  } else if (false) {}
  return "";
}
function markAsyncBoundary(instance) {
  instance.ids = [instance.ids[0] + instance.ids[2]++ + "-", 0, 0];
}

const knownTemplateRefs = /* @__PURE__ */ new WeakSet();
function useTemplateRef(key) {
  const i = runtime_core_esm_bundler_getCurrentInstance();
  const r = shallowRef(null);
  if (i) {
    const refs = i.refs === EMPTY_OBJ ? i.refs = {} : i.refs;
    let desc;
    if (false) {} else {
      Object.defineProperty(refs, key, {
        enumerable: true,
        get: () => r.value,
        set: (val) => r.value = val
      });
    }
  } else if (false) {}
  const ret =  false ? 0 : r;
  if (false) {}
  return ret;
}

function setRef(rawRef, oldRawRef, parentSuspense, vnode, isUnmount = false) {
  if (shared_esm_bundler_isArray(rawRef)) {
    rawRef.forEach(
      (r, i) => setRef(
        r,
        oldRawRef && (shared_esm_bundler_isArray(oldRawRef) ? oldRawRef[i] : oldRawRef),
        parentSuspense,
        vnode,
        isUnmount
      )
    );
    return;
  }
  if (isAsyncWrapper(vnode) && !isUnmount) {
    if (vnode.shapeFlag & 512 && vnode.type.__asyncResolved && vnode.component.subTree.component) {
      setRef(rawRef, oldRawRef, parentSuspense, vnode.component.subTree);
    }
    return;
  }
  const refValue = vnode.shapeFlag & 4 ? getComponentPublicInstance(vnode.component) : vnode.el;
  const value = isUnmount ? null : refValue;
  const { i: owner, r: ref } = rawRef;
  if (false) {}
  const oldRef = oldRawRef && oldRawRef.r;
  const refs = owner.refs === shared_esm_bundler_EMPTY_OBJ ? owner.refs = {} : owner.refs;
  const setupState = owner.setupState;
  const rawSetupState = reactivity_esm_bundler_toRaw(setupState);
  const canSetSetupRef = setupState === shared_esm_bundler_EMPTY_OBJ ? NO : (key) => {
    if (false) {}
    return hasOwn(rawSetupState, key);
  };
  const canSetRef = (ref2) => {
    return  true || 0;
  };
  if (oldRef != null && oldRef !== ref) {
    if (shared_esm_bundler_isString(oldRef)) {
      refs[oldRef] = null;
      if (canSetSetupRef(oldRef)) {
        setupState[oldRef] = null;
      }
    } else if (reactivity_esm_bundler_isRef(oldRef)) {
      if (canSetRef(oldRef)) {
        oldRef.value = null;
      }
      const oldRawRefAtom = oldRawRef;
      if (oldRawRefAtom.k) refs[oldRawRefAtom.k] = null;
    }
  }
  if (shared_esm_bundler_isFunction(ref)) {
    callWithErrorHandling(ref, owner, 12, [value, refs]);
  } else {
    const _isString = shared_esm_bundler_isString(ref);
    const _isRef = reactivity_esm_bundler_isRef(ref);
    if (_isString || _isRef) {
      const doSet = () => {
        if (rawRef.f) {
          const existing = _isString ? canSetSetupRef(ref) ? setupState[ref] : refs[ref] : canSetRef(ref) || !rawRef.k ? ref.value : refs[rawRef.k];
          if (isUnmount) {
            shared_esm_bundler_isArray(existing) && remove(existing, refValue);
          } else {
            if (!shared_esm_bundler_isArray(existing)) {
              if (_isString) {
                refs[ref] = [refValue];
                if (canSetSetupRef(ref)) {
                  setupState[ref] = refs[ref];
                }
              } else {
                const newVal = [refValue];
                if (canSetRef(ref)) {
                  ref.value = newVal;
                }
                if (rawRef.k) refs[rawRef.k] = newVal;
              }
            } else if (!existing.includes(refValue)) {
              existing.push(refValue);
            }
          }
        } else if (_isString) {
          refs[ref] = value;
          if (canSetSetupRef(ref)) {
            setupState[ref] = value;
          }
        } else if (_isRef) {
          if (canSetRef(ref)) {
            ref.value = value;
          }
          if (rawRef.k) refs[rawRef.k] = value;
        } else if (false) {}
      };
      if (value) {
        doSet.id = -1;
        queuePostRenderEffect(doSet, parentSuspense);
      } else {
        doSet();
      }
    } else if (false) {}
  }
}

let hasLoggedMismatchError = false;
const logMismatchError = () => {
  if (hasLoggedMismatchError) {
    return;
  }
  console.error("Hydration completed but contains mismatches.");
  hasLoggedMismatchError = true;
};
const isSVGContainer = (container) => container.namespaceURI.includes("svg") && container.tagName !== "foreignObject";
const isMathMLContainer = (container) => container.namespaceURI.includes("MathML");
const getContainerType = (container) => {
  if (container.nodeType !== 1) return void 0;
  if (isSVGContainer(container)) return "svg";
  if (isMathMLContainer(container)) return "mathml";
  return void 0;
};
const isComment = (node) => node.nodeType === 8;
function createHydrationFunctions(rendererInternals) {
  const {
    mt: mountComponent,
    p: patch,
    o: {
      patchProp,
      createText,
      nextSibling,
      parentNode,
      remove,
      insert,
      createComment
    }
  } = rendererInternals;
  const hydrate = (vnode, container) => {
    if (!container.hasChildNodes()) {
      ( false) && 0;
      patch(null, vnode, container);
      flushPostFlushCbs();
      container._vnode = vnode;
      return;
    }
    hydrateNode(container.firstChild, vnode, null, null, null);
    flushPostFlushCbs();
    container._vnode = vnode;
  };
  const hydrateNode = (node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized = false) => {
    optimized = optimized || !!vnode.dynamicChildren;
    const isFragmentStart = isComment(node) && node.data === "[";
    const onMismatch = () => handleMismatch(
      node,
      vnode,
      parentComponent,
      parentSuspense,
      slotScopeIds,
      isFragmentStart
    );
    const { type, ref, shapeFlag, patchFlag } = vnode;
    let domType = node.nodeType;
    vnode.el = node;
    if (false) {}
    if (patchFlag === -2) {
      optimized = false;
      vnode.dynamicChildren = null;
    }
    let nextNode = null;
    switch (type) {
      case Text:
        if (domType !== 3) {
          if (vnode.children === "") {
            insert(vnode.el = createText(""), parentNode(node), node);
            nextNode = node;
          } else {
            nextNode = onMismatch();
          }
        } else {
          if (node.data !== vnode.children) {
            ( false) && 0;
            logMismatchError();
            node.data = vnode.children;
          }
          nextNode = nextSibling(node);
        }
        break;
      case Comment:
        if (isTemplateNode(node)) {
          nextNode = nextSibling(node);
          replaceNode(
            vnode.el = node.content.firstChild,
            node,
            parentComponent
          );
        } else if (domType !== 8 || isFragmentStart) {
          nextNode = onMismatch();
        } else {
          nextNode = nextSibling(node);
        }
        break;
      case runtime_core_esm_bundler_Static:
        if (isFragmentStart) {
          node = nextSibling(node);
          domType = node.nodeType;
        }
        if (domType === 1 || domType === 3) {
          nextNode = node;
          const needToAdoptContent = !vnode.children.length;
          for (let i = 0; i < vnode.staticCount; i++) {
            if (needToAdoptContent)
              vnode.children += nextNode.nodeType === 1 ? nextNode.outerHTML : nextNode.data;
            if (i === vnode.staticCount - 1) {
              vnode.anchor = nextNode;
            }
            nextNode = nextSibling(nextNode);
          }
          return isFragmentStart ? nextSibling(nextNode) : nextNode;
        } else {
          onMismatch();
        }
        break;
      case runtime_core_esm_bundler_Fragment:
        if (!isFragmentStart) {
          nextNode = onMismatch();
        } else {
          nextNode = hydrateFragment(
            node,
            vnode,
            parentComponent,
            parentSuspense,
            slotScopeIds,
            optimized
          );
        }
        break;
      default:
        if (shapeFlag & 1) {
          if ((domType !== 1 || vnode.type.toLowerCase() !== node.tagName.toLowerCase()) && !isTemplateNode(node)) {
            nextNode = onMismatch();
          } else {
            nextNode = hydrateElement(
              node,
              vnode,
              parentComponent,
              parentSuspense,
              slotScopeIds,
              optimized
            );
          }
        } else if (shapeFlag & 6) {
          vnode.slotScopeIds = slotScopeIds;
          const container = parentNode(node);
          if (isFragmentStart) {
            nextNode = locateClosingAnchor(node);
          } else if (isComment(node) && node.data === "teleport start") {
            nextNode = locateClosingAnchor(node, node.data, "teleport end");
          } else {
            nextNode = nextSibling(node);
          }
          mountComponent(
            vnode,
            container,
            null,
            parentComponent,
            parentSuspense,
            getContainerType(container),
            optimized
          );
          if (isAsyncWrapper(vnode) && !vnode.type.__asyncResolved) {
            let subTree;
            if (isFragmentStart) {
              subTree = createVNode(runtime_core_esm_bundler_Fragment);
              subTree.anchor = nextNode ? nextNode.previousSibling : container.lastChild;
            } else {
              subTree = node.nodeType === 3 ? createTextVNode("") : createVNode("div");
            }
            subTree.el = node;
            vnode.component.subTree = subTree;
          }
        } else if (shapeFlag & 64) {
          if (domType !== 8) {
            nextNode = onMismatch();
          } else {
            nextNode = vnode.type.hydrate(
              node,
              vnode,
              parentComponent,
              parentSuspense,
              slotScopeIds,
              optimized,
              rendererInternals,
              hydrateChildren
            );
          }
        } else if (shapeFlag & 128) {
          nextNode = vnode.type.hydrate(
            node,
            vnode,
            parentComponent,
            parentSuspense,
            getContainerType(parentNode(node)),
            slotScopeIds,
            optimized,
            rendererInternals,
            hydrateNode
          );
        } else if (false) {}
    }
    if (ref != null) {
      setRef(ref, null, parentSuspense, vnode);
    }
    return nextNode;
  };
  const hydrateElement = (el, vnode, parentComponent, parentSuspense, slotScopeIds, optimized) => {
    optimized = optimized || !!vnode.dynamicChildren;
    const { type, props, patchFlag, shapeFlag, dirs, transition } = vnode;
    const forcePatch = type === "input" || type === "option";
    if ( false || forcePatch || patchFlag !== -1) {
      if (dirs) {
        invokeDirectiveHook(vnode, null, parentComponent, "created");
      }
      let needCallTransitionHooks = false;
      if (isTemplateNode(el)) {
        needCallTransitionHooks = needTransition(
          null,
          // no need check parentSuspense in hydration
          transition
        ) && parentComponent && parentComponent.vnode.props && parentComponent.vnode.props.appear;
        const content = el.content.firstChild;
        if (needCallTransitionHooks) {
          const cls = content.getAttribute("class");
          if (cls) content.$cls = cls;
          transition.beforeEnter(content);
        }
        replaceNode(content, el, parentComponent);
        vnode.el = el = content;
      }
      if (shapeFlag & 16 && // skip if element has innerHTML / textContent
      !(props && (props.innerHTML || props.textContent))) {
        let next = hydrateChildren(
          el.firstChild,
          vnode,
          el,
          parentComponent,
          parentSuspense,
          slotScopeIds,
          optimized
        );
        let hasWarned = false;
        while (next) {
          if (!isMismatchAllowed(el, 1 /* CHILDREN */)) {
            if (false) {}
            logMismatchError();
          }
          const cur = next;
          next = next.nextSibling;
          remove(cur);
        }
      } else if (shapeFlag & 8) {
        let clientText = vnode.children;
        if (clientText[0] === "\n" && (el.tagName === "PRE" || el.tagName === "TEXTAREA")) {
          clientText = clientText.slice(1);
        }
        if (el.textContent !== clientText) {
          if (!isMismatchAllowed(el, 0 /* TEXT */)) {
            ( false) && 0;
            logMismatchError();
          }
          el.textContent = vnode.children;
        }
      }
      if (props) {
        if ( false || forcePatch || !optimized || patchFlag & (16 | 32)) {
          const isCustomElement = el.tagName.includes("-");
          for (const key in props) {
            if (false) {}
            if (forcePatch && (key.endsWith("value") || key === "indeterminate") || isOn(key) && !isReservedProp(key) || // force hydrate v-bind with .prop modifiers
            key[0] === "." || isCustomElement) {
              patchProp(el, key, null, props[key], void 0, parentComponent);
            }
          }
        } else if (props.onClick) {
          patchProp(
            el,
            "onClick",
            null,
            props.onClick,
            void 0,
            parentComponent
          );
        } else if (patchFlag & 4 && isReactive(props.style)) {
          for (const key in props.style) props.style[key];
        }
      }
      let vnodeHooks;
      if (vnodeHooks = props && props.onVnodeBeforeMount) {
        invokeVNodeHook(vnodeHooks, parentComponent, vnode);
      }
      if (dirs) {
        invokeDirectiveHook(vnode, null, parentComponent, "beforeMount");
      }
      if ((vnodeHooks = props && props.onVnodeMounted) || dirs || needCallTransitionHooks) {
        queueEffectWithSuspense(() => {
          vnodeHooks && invokeVNodeHook(vnodeHooks, parentComponent, vnode);
          needCallTransitionHooks && transition.enter(el);
          dirs && invokeDirectiveHook(vnode, null, parentComponent, "mounted");
        }, parentSuspense);
      }
    }
    return el.nextSibling;
  };
  const hydrateChildren = (node, parentVNode, container, parentComponent, parentSuspense, slotScopeIds, optimized) => {
    optimized = optimized || !!parentVNode.dynamicChildren;
    const children = parentVNode.children;
    const l = children.length;
    let hasWarned = false;
    for (let i = 0; i < l; i++) {
      const vnode = optimized ? children[i] : children[i] = normalizeVNode(children[i]);
      const isText = vnode.type === Text;
      if (node) {
        if (isText && !optimized) {
          if (i + 1 < l && normalizeVNode(children[i + 1]).type === Text) {
            insert(
              createText(
                node.data.slice(vnode.children.length)
              ),
              container,
              nextSibling(node)
            );
            node.data = vnode.children;
          }
        }
        node = hydrateNode(
          node,
          vnode,
          parentComponent,
          parentSuspense,
          slotScopeIds,
          optimized
        );
      } else if (isText && !vnode.children) {
        insert(vnode.el = createText(""), container);
      } else {
        if (!isMismatchAllowed(container, 1 /* CHILDREN */)) {
          if (false) {}
          logMismatchError();
        }
        patch(
          null,
          vnode,
          container,
          null,
          parentComponent,
          parentSuspense,
          getContainerType(container),
          slotScopeIds
        );
      }
    }
    return node;
  };
  const hydrateFragment = (node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized) => {
    const { slotScopeIds: fragmentSlotScopeIds } = vnode;
    if (fragmentSlotScopeIds) {
      slotScopeIds = slotScopeIds ? slotScopeIds.concat(fragmentSlotScopeIds) : fragmentSlotScopeIds;
    }
    const container = parentNode(node);
    const next = hydrateChildren(
      nextSibling(node),
      vnode,
      container,
      parentComponent,
      parentSuspense,
      slotScopeIds,
      optimized
    );
    if (next && isComment(next) && next.data === "]") {
      return nextSibling(vnode.anchor = next);
    } else {
      logMismatchError();
      insert(vnode.anchor = createComment(`]`), container, next);
      return next;
    }
  };
  const handleMismatch = (node, vnode, parentComponent, parentSuspense, slotScopeIds, isFragment) => {
    if (!isMismatchAllowed(node.parentElement, 1 /* CHILDREN */)) {
      ( false) && 0;
      logMismatchError();
    }
    vnode.el = null;
    if (isFragment) {
      const end = locateClosingAnchor(node);
      while (true) {
        const next2 = nextSibling(node);
        if (next2 && next2 !== end) {
          remove(next2);
        } else {
          break;
        }
      }
    }
    const next = nextSibling(node);
    const container = parentNode(node);
    remove(node);
    patch(
      null,
      vnode,
      container,
      next,
      parentComponent,
      parentSuspense,
      getContainerType(container),
      slotScopeIds
    );
    if (parentComponent) {
      parentComponent.vnode.el = vnode.el;
      updateHOCHostEl(parentComponent, vnode.el);
    }
    return next;
  };
  const locateClosingAnchor = (node, open = "[", close = "]") => {
    let match = 0;
    while (node) {
      node = nextSibling(node);
      if (node && isComment(node)) {
        if (node.data === open) match++;
        if (node.data === close) {
          if (match === 0) {
            return nextSibling(node);
          } else {
            match--;
          }
        }
      }
    }
    return node;
  };
  const replaceNode = (newNode, oldNode, parentComponent) => {
    const parentNode2 = oldNode.parentNode;
    if (parentNode2) {
      parentNode2.replaceChild(newNode, oldNode);
    }
    let parent = parentComponent;
    while (parent) {
      if (parent.vnode.el === oldNode) {
        parent.vnode.el = parent.subTree.el = newNode;
      }
      parent = parent.parent;
    }
  };
  const isTemplateNode = (node) => {
    return node.nodeType === 1 && node.tagName === "TEMPLATE";
  };
  return [hydrate, hydrateNode];
}
function propHasMismatch(el, key, clientValue, vnode, instance) {
  let mismatchType;
  let mismatchKey;
  let actual;
  let expected;
  if (key === "class") {
    if (el.$cls) {
      actual = el.$cls;
      delete el.$cls;
    } else {
      actual = el.getAttribute("class");
    }
    expected = normalizeClass(clientValue);
    if (!isSetEqual(toClassSet(actual || ""), toClassSet(expected))) {
      mismatchType = 2 /* CLASS */;
      mismatchKey = `class`;
    }
  } else if (key === "style") {
    actual = el.getAttribute("style") || "";
    expected = isString(clientValue) ? clientValue : stringifyStyle(normalizeStyle(clientValue));
    const actualMap = toStyleMap(actual);
    const expectedMap = toStyleMap(expected);
    if (vnode.dirs) {
      for (const { dir, value } of vnode.dirs) {
        if (dir.name === "show" && !value) {
          expectedMap.set("display", "none");
        }
      }
    }
    if (instance) {
      resolveCssVars(instance, vnode, expectedMap);
    }
    if (!isMapEqual(actualMap, expectedMap)) {
      mismatchType = 3 /* STYLE */;
      mismatchKey = "style";
    }
  } else if (el instanceof SVGElement && isKnownSvgAttr(key) || el instanceof HTMLElement && (isBooleanAttr(key) || isKnownHtmlAttr(key))) {
    if (isBooleanAttr(key)) {
      actual = el.hasAttribute(key);
      expected = includeBooleanAttr(clientValue);
    } else if (clientValue == null) {
      actual = el.hasAttribute(key);
      expected = false;
    } else {
      if (el.hasAttribute(key)) {
        actual = el.getAttribute(key);
      } else if (key === "value" && el.tagName === "TEXTAREA") {
        actual = el.value;
      } else {
        actual = false;
      }
      expected = isRenderableAttrValue(clientValue) ? String(clientValue) : false;
    }
    if (actual !== expected) {
      mismatchType = 4 /* ATTRIBUTE */;
      mismatchKey = key;
    }
  }
  if (mismatchType != null && !isMismatchAllowed(el, mismatchType)) {
    const format = (v) => v === false ? `(not rendered)` : `${mismatchKey}="${v}"`;
    const preSegment = `Hydration ${MismatchTypeString[mismatchType]} mismatch on`;
    const postSegment = `
  - rendered on server: ${format(actual)}
  - expected on client: ${format(expected)}
  Note: this mismatch is check-only. The DOM will not be rectified in production due to performance overhead.
  You should fix the source of the mismatch.`;
    {
      warn$1(preSegment, el, postSegment);
    }
    return true;
  }
  return false;
}
function toClassSet(str) {
  return new Set(str.trim().split(/\s+/));
}
function isSetEqual(a, b) {
  if (a.size !== b.size) {
    return false;
  }
  for (const s of a) {
    if (!b.has(s)) {
      return false;
    }
  }
  return true;
}
function toStyleMap(str) {
  const styleMap = /* @__PURE__ */ new Map();
  for (const item of str.split(";")) {
    let [key, value] = item.split(":");
    key = key.trim();
    value = value && value.trim();
    if (key && value) {
      styleMap.set(key, value);
    }
  }
  return styleMap;
}
function isMapEqual(a, b) {
  if (a.size !== b.size) {
    return false;
  }
  for (const [key, value] of a) {
    if (value !== b.get(key)) {
      return false;
    }
  }
  return true;
}
function resolveCssVars(instance, vnode, expectedMap) {
  const root = instance.subTree;
  if (instance.getCssVars && (vnode === root || root && root.type === runtime_core_esm_bundler_Fragment && root.children.includes(vnode))) {
    const cssVars = instance.getCssVars();
    for (const key in cssVars) {
      const value = normalizeCssVarValue(cssVars[key]);
      expectedMap.set(`--${getEscapedCssVarName(key, false)}`, value);
    }
  }
  if (vnode === root && instance.parent) {
    resolveCssVars(instance.parent, instance.vnode, expectedMap);
  }
}
const allowMismatchAttr = "data-allow-mismatch";
const MismatchTypeString = {
  [0 /* TEXT */]: "text",
  [1 /* CHILDREN */]: "children",
  [2 /* CLASS */]: "class",
  [3 /* STYLE */]: "style",
  [4 /* ATTRIBUTE */]: "attribute"
};
function isMismatchAllowed(el, allowedType) {
  if (allowedType === 0 /* TEXT */ || allowedType === 1 /* CHILDREN */) {
    while (el && !el.hasAttribute(allowMismatchAttr)) {
      el = el.parentElement;
    }
  }
  const allowedAttr = el && el.getAttribute(allowMismatchAttr);
  if (allowedAttr == null) {
    return false;
  } else if (allowedAttr === "") {
    return true;
  } else {
    const list = allowedAttr.split(",");
    if (allowedType === 0 /* TEXT */ && list.includes("children")) {
      return true;
    }
    return list.includes(MismatchTypeString[allowedType]);
  }
}

const requestIdleCallback = getGlobalThis().requestIdleCallback || ((cb) => setTimeout(cb, 1));
const cancelIdleCallback = getGlobalThis().cancelIdleCallback || ((id) => clearTimeout(id));
const hydrateOnIdle = (timeout = 1e4) => (hydrate) => {
  const id = requestIdleCallback(hydrate, { timeout });
  return () => cancelIdleCallback(id);
};
function elementIsVisibleInViewport(el) {
  const { top, left, bottom, right } = el.getBoundingClientRect();
  const { innerHeight, innerWidth } = window;
  return (top > 0 && top < innerHeight || bottom > 0 && bottom < innerHeight) && (left > 0 && left < innerWidth || right > 0 && right < innerWidth);
}
const hydrateOnVisible = (opts) => (hydrate, forEach) => {
  const ob = new IntersectionObserver((entries) => {
    for (const e of entries) {
      if (!e.isIntersecting) continue;
      ob.disconnect();
      hydrate();
      break;
    }
  }, opts);
  forEach((el) => {
    if (!(el instanceof Element)) return;
    if (elementIsVisibleInViewport(el)) {
      hydrate();
      ob.disconnect();
      return false;
    }
    ob.observe(el);
  });
  return () => ob.disconnect();
};
const hydrateOnMediaQuery = (query) => (hydrate) => {
  if (query) {
    const mql = matchMedia(query);
    if (mql.matches) {
      hydrate();
    } else {
      mql.addEventListener("change", hydrate, { once: true });
      return () => mql.removeEventListener("change", hydrate);
    }
  }
};
const hydrateOnInteraction = (interactions = []) => (hydrate, forEach) => {
  if (isString(interactions)) interactions = [interactions];
  let hasHydrated = false;
  const doHydrate = (e) => {
    if (!hasHydrated) {
      hasHydrated = true;
      teardown();
      hydrate();
      e.target.dispatchEvent(new e.constructor(e.type, e));
    }
  };
  const teardown = () => {
    forEach((el) => {
      for (const i of interactions) {
        el.removeEventListener(i, doHydrate);
      }
    });
  };
  forEach((el) => {
    for (const i of interactions) {
      el.addEventListener(i, doHydrate, { once: true });
    }
  });
  return teardown;
};
function forEachElement(node, cb) {
  if (isComment(node) && node.data === "[") {
    let depth = 1;
    let next = node.nextSibling;
    while (next) {
      if (next.nodeType === 1) {
        const result = cb(next);
        if (result === false) {
          break;
        }
      } else if (isComment(next)) {
        if (next.data === "]") {
          if (--depth === 0) break;
        } else if (next.data === "[") {
          depth++;
        }
      }
      next = next.nextSibling;
    }
  } else {
    cb(node);
  }
}

const isAsyncWrapper = (i) => !!i.type.__asyncLoader;
/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function defineAsyncComponent(source) {
  if (isFunction(source)) {
    source = { loader: source };
  }
  const {
    loader,
    loadingComponent,
    errorComponent,
    delay = 200,
    hydrate: hydrateStrategy,
    timeout,
    // undefined = never times out
    suspensible = true,
    onError: userOnError
  } = source;
  let pendingRequest = null;
  let resolvedComp;
  let retries = 0;
  const retry = () => {
    retries++;
    pendingRequest = null;
    return load();
  };
  const load = () => {
    let thisRequest;
    return pendingRequest || (thisRequest = pendingRequest = loader().catch((err) => {
      err = err instanceof Error ? err : new Error(String(err));
      if (userOnError) {
        return new Promise((resolve, reject) => {
          const userRetry = () => resolve(retry());
          const userFail = () => reject(err);
          userOnError(err, userRetry, userFail, retries + 1);
        });
      } else {
        throw err;
      }
    }).then((comp) => {
      if (thisRequest !== pendingRequest && pendingRequest) {
        return pendingRequest;
      }
      if (false) {}
      if (comp && (comp.__esModule || comp[Symbol.toStringTag] === "Module")) {
        comp = comp.default;
      }
      if (false) {}
      resolvedComp = comp;
      return comp;
    }));
  };
  return runtime_core_esm_bundler_defineComponent({
    name: "AsyncComponentWrapper",
    __asyncLoader: load,
    __asyncHydrate(el, instance, hydrate) {
      let patched = false;
      (instance.bu || (instance.bu = [])).push(() => patched = true);
      const performHydrate = () => {
        if (patched) {
          if (false) {}
          return;
        }
        hydrate();
      };
      const doHydrate = hydrateStrategy ? () => {
        const teardown = hydrateStrategy(
          performHydrate,
          (cb) => forEachElement(el, cb)
        );
        if (teardown) {
          (instance.bum || (instance.bum = [])).push(teardown);
        }
      } : performHydrate;
      if (resolvedComp) {
        doHydrate();
      } else {
        load().then(() => !instance.isUnmounted && doHydrate());
      }
    },
    get __asyncResolved() {
      return resolvedComp;
    },
    setup() {
      const instance = currentInstance;
      markAsyncBoundary(instance);
      if (resolvedComp) {
        return () => createInnerComp(resolvedComp, instance);
      }
      const onError = (err) => {
        pendingRequest = null;
        handleError(
          err,
          instance,
          13,
          !errorComponent
        );
      };
      if (suspensible && instance.suspense || isInSSRComponentSetup) {
        return load().then((comp) => {
          return () => createInnerComp(comp, instance);
        }).catch((err) => {
          onError(err);
          return () => errorComponent ? createVNode(errorComponent, {
            error: err
          }) : null;
        });
      }
      const loaded = ref(false);
      const error = ref();
      const delayed = ref(!!delay);
      if (delay) {
        setTimeout(() => {
          delayed.value = false;
        }, delay);
      }
      if (timeout != null) {
        setTimeout(() => {
          if (!loaded.value && !error.value) {
            const err = new Error(
              `Async component timed out after ${timeout}ms.`
            );
            onError(err);
            error.value = err;
          }
        }, timeout);
      }
      load().then(() => {
        loaded.value = true;
        if (instance.parent && isKeepAlive(instance.parent.vnode)) {
          instance.parent.update();
        }
      }).catch((err) => {
        onError(err);
        error.value = err;
      });
      return () => {
        if (loaded.value && resolvedComp) {
          return createInnerComp(resolvedComp, instance);
        } else if (error.value && errorComponent) {
          return createVNode(errorComponent, {
            error: error.value
          });
        } else if (loadingComponent && !delayed.value) {
          return createVNode(loadingComponent);
        }
      };
    }
  });
}
function createInnerComp(comp, parent) {
  const { ref: ref2, props, children, ce } = parent.vnode;
  const vnode = createVNode(comp, props, children);
  vnode.ref = ref2;
  vnode.ce = ce;
  delete parent.vnode.ce;
  return vnode;
}

const isKeepAlive = (vnode) => vnode.type.__isKeepAlive;
const KeepAliveImpl = {
  name: `KeepAlive`,
  // Marker for special handling inside the renderer. We are not using a ===
  // check directly on KeepAlive in the renderer, because importing it directly
  // would prevent it from being tree-shaken.
  __isKeepAlive: true,
  props: {
    include: [String, RegExp, Array],
    exclude: [String, RegExp, Array],
    max: [String, Number]
  },
  setup(props, { slots }) {
    const instance = runtime_core_esm_bundler_getCurrentInstance();
    const sharedContext = instance.ctx;
    if (!sharedContext.renderer) {
      return () => {
        const children = slots.default && slots.default();
        return children && children.length === 1 ? children[0] : children;
      };
    }
    const cache = /* @__PURE__ */ new Map();
    const keys = /* @__PURE__ */ new Set();
    let current = null;
    if (false) {}
    const parentSuspense = instance.suspense;
    const {
      renderer: {
        p: patch,
        m: move,
        um: _unmount,
        o: { createElement }
      }
    } = sharedContext;
    const storageContainer = createElement("div");
    sharedContext.activate = (vnode, container, anchor, namespace, optimized) => {
      const instance2 = vnode.component;
      move(vnode, container, anchor, 0, parentSuspense);
      patch(
        instance2.vnode,
        vnode,
        container,
        anchor,
        instance2,
        parentSuspense,
        namespace,
        vnode.slotScopeIds,
        optimized
      );
      queuePostRenderEffect(() => {
        instance2.isDeactivated = false;
        if (instance2.a) {
          invokeArrayFns(instance2.a);
        }
        const vnodeHook = vnode.props && vnode.props.onVnodeMounted;
        if (vnodeHook) {
          invokeVNodeHook(vnodeHook, instance2.parent, vnode);
        }
      }, parentSuspense);
      if (false) {}
    };
    sharedContext.deactivate = (vnode) => {
      const instance2 = vnode.component;
      invalidateMount(instance2.m);
      invalidateMount(instance2.a);
      move(vnode, storageContainer, null, 1, parentSuspense);
      queuePostRenderEffect(() => {
        if (instance2.da) {
          invokeArrayFns(instance2.da);
        }
        const vnodeHook = vnode.props && vnode.props.onVnodeUnmounted;
        if (vnodeHook) {
          invokeVNodeHook(vnodeHook, instance2.parent, vnode);
        }
        instance2.isDeactivated = true;
      }, parentSuspense);
      if (false) {}
      if (false) {}
    };
    function unmount(vnode) {
      resetShapeFlag(vnode);
      _unmount(vnode, instance, parentSuspense, true);
    }
    function pruneCache(filter) {
      cache.forEach((vnode, key) => {
        const name = getComponentName(vnode.type);
        if (name && !filter(name)) {
          pruneCacheEntry(key);
        }
      });
    }
    function pruneCacheEntry(key) {
      const cached = cache.get(key);
      if (cached && (!current || !isSameVNodeType(cached, current))) {
        unmount(cached);
      } else if (current) {
        resetShapeFlag(current);
      }
      cache.delete(key);
      keys.delete(key);
    }
    runtime_core_esm_bundler_watch(
      () => [props.include, props.exclude],
      ([include, exclude]) => {
        include && pruneCache((name) => matches(include, name));
        exclude && pruneCache((name) => !matches(exclude, name));
      },
      // prune post-render after `current` has been updated
      { flush: "post", deep: true }
    );
    let pendingCacheKey = null;
    const cacheSubtree = () => {
      if (pendingCacheKey != null) {
        if (isSuspense(instance.subTree.type)) {
          queuePostRenderEffect(() => {
            cache.set(pendingCacheKey, getInnerChild(instance.subTree));
          }, instance.subTree.suspense);
        } else {
          cache.set(pendingCacheKey, getInnerChild(instance.subTree));
        }
      }
    };
    runtime_core_esm_bundler_onMounted(cacheSubtree);
    onUpdated(cacheSubtree);
    onBeforeUnmount(() => {
      cache.forEach((cached) => {
        const { subTree, suspense } = instance;
        const vnode = getInnerChild(subTree);
        if (cached.type === vnode.type && cached.key === vnode.key) {
          resetShapeFlag(vnode);
          const da = vnode.component.da;
          da && queuePostRenderEffect(da, suspense);
          return;
        }
        unmount(cached);
      });
    });
    return () => {
      pendingCacheKey = null;
      if (!slots.default) {
        return current = null;
      }
      const children = slots.default();
      const rawVNode = children[0];
      if (children.length > 1) {
        if (false) {}
        current = null;
        return children;
      } else if (!isVNode(rawVNode) || !(rawVNode.shapeFlag & 4) && !(rawVNode.shapeFlag & 128)) {
        current = null;
        return rawVNode;
      }
      let vnode = getInnerChild(rawVNode);
      if (vnode.type === Comment) {
        current = null;
        return vnode;
      }
      const comp = vnode.type;
      const name = getComponentName(
        isAsyncWrapper(vnode) ? vnode.type.__asyncResolved || {} : comp
      );
      const { include, exclude, max } = props;
      if (include && (!name || !matches(include, name)) || exclude && name && matches(exclude, name)) {
        vnode.shapeFlag &= -257;
        current = vnode;
        return rawVNode;
      }
      const key = vnode.key == null ? comp : vnode.key;
      const cachedVNode = cache.get(key);
      if (vnode.el) {
        vnode = cloneVNode(vnode);
        if (rawVNode.shapeFlag & 128) {
          rawVNode.ssContent = vnode;
        }
      }
      pendingCacheKey = key;
      if (cachedVNode) {
        vnode.el = cachedVNode.el;
        vnode.component = cachedVNode.component;
        if (vnode.transition) {
          setTransitionHooks(vnode, vnode.transition);
        }
        vnode.shapeFlag |= 512;
        keys.delete(key);
        keys.add(key);
      } else {
        keys.add(key);
        if (max && keys.size > parseInt(max, 10)) {
          pruneCacheEntry(keys.values().next().value);
        }
      }
      vnode.shapeFlag |= 256;
      current = vnode;
      return isSuspense(rawVNode.type) ? rawVNode : vnode;
    };
  }
};
const KeepAlive = (/* unused pure expression or super */ null && (KeepAliveImpl));
function matches(pattern, name) {
  if (shared_esm_bundler_isArray(pattern)) {
    return pattern.some((p) => matches(p, name));
  } else if (shared_esm_bundler_isString(pattern)) {
    return pattern.split(",").includes(name);
  } else if (isRegExp(pattern)) {
    pattern.lastIndex = 0;
    return pattern.test(name);
  }
  return false;
}
function runtime_core_esm_bundler_onActivated(hook, target) {
  registerKeepAliveHook(hook, "a", target);
}
function runtime_core_esm_bundler_onDeactivated(hook, target) {
  registerKeepAliveHook(hook, "da", target);
}
function registerKeepAliveHook(hook, type, target = currentInstance) {
  const wrappedHook = hook.__wdc || (hook.__wdc = () => {
    let current = target;
    while (current) {
      if (current.isDeactivated) {
        return;
      }
      current = current.parent;
    }
    return hook();
  });
  injectHook(type, wrappedHook, target);
  if (target) {
    let current = target.parent;
    while (current && current.parent) {
      if (isKeepAlive(current.parent.vnode)) {
        injectToKeepAliveRoot(wrappedHook, type, target, current);
      }
      current = current.parent;
    }
  }
}
function injectToKeepAliveRoot(hook, type, target, keepAliveRoot) {
  const injected = injectHook(
    type,
    hook,
    keepAliveRoot,
    true
    /* prepend */
  );
  runtime_core_esm_bundler_onUnmounted(() => {
    remove(keepAliveRoot[type], injected);
  }, target);
}
function resetShapeFlag(vnode) {
  vnode.shapeFlag &= -257;
  vnode.shapeFlag &= -513;
}
function getInnerChild(vnode) {
  return vnode.shapeFlag & 128 ? vnode.ssContent : vnode;
}

function injectHook(type, hook, target = currentInstance, prepend = false) {
  if (target) {
    const hooks = target[type] || (target[type] = []);
    const wrappedHook = hook.__weh || (hook.__weh = (...args) => {
      reactivity_esm_bundler_pauseTracking();
      const reset = setCurrentInstance(target);
      const res = callWithAsyncErrorHandling(hook, target, type, args);
      reset();
      reactivity_esm_bundler_resetTracking();
      return res;
    });
    if (prepend) {
      hooks.unshift(wrappedHook);
    } else {
      hooks.push(wrappedHook);
    }
    return wrappedHook;
  } else if (false) {}
}
const createHook = (lifecycle) => (hook, target = currentInstance) => {
  if (!isInSSRComponentSetup || lifecycle === "sp") {
    injectHook(lifecycle, (...args) => hook(...args), target);
  }
};
const onBeforeMount = createHook("bm");
const runtime_core_esm_bundler_onMounted = createHook("m");
const runtime_core_esm_bundler_onBeforeUpdate = createHook(
  "bu"
);
const onUpdated = createHook("u");
const onBeforeUnmount = createHook(
  "bum"
);
const runtime_core_esm_bundler_onUnmounted = createHook("um");
const onServerPrefetch = createHook(
  "sp"
);
const onRenderTriggered = createHook("rtg");
const onRenderTracked = createHook("rtc");
function onErrorCaptured(hook, target = currentInstance) {
  injectHook("ec", hook, target);
}

const COMPONENTS = "components";
const DIRECTIVES = "directives";
function resolveComponent(name, maybeSelfReference) {
  return resolveAsset(COMPONENTS, name, true, maybeSelfReference) || name;
}
const NULL_DYNAMIC_COMPONENT = Symbol.for("v-ndc");
function resolveDynamicComponent(component) {
  if (shared_esm_bundler_isString(component)) {
    return resolveAsset(COMPONENTS, component, false) || component;
  } else {
    return component || NULL_DYNAMIC_COMPONENT;
  }
}
function resolveDirective(name) {
  return resolveAsset(DIRECTIVES, name);
}
function resolveAsset(type, name, warnMissing = true, maybeSelfReference = false) {
  const instance = currentRenderingInstance || currentInstance;
  if (instance) {
    const Component = instance.type;
    if (type === COMPONENTS) {
      const selfName = getComponentName(
        Component,
        false
      );
      if (selfName && (selfName === name || selfName === shared_esm_bundler_camelize(name) || selfName === shared_esm_bundler_capitalize(shared_esm_bundler_camelize(name)))) {
        return Component;
      }
    }
    const res = (
      // local registration
      // check instance[type] first which is resolved for options API
      resolve(instance[type] || Component[type], name) || // global registration
      resolve(instance.appContext[type], name)
    );
    if (!res && maybeSelfReference) {
      return Component;
    }
    if (false) {}
    return res;
  } else if (false) {}
}
function resolve(registry, name) {
  return registry && (registry[name] || registry[shared_esm_bundler_camelize(name)] || registry[shared_esm_bundler_capitalize(shared_esm_bundler_camelize(name))]);
}

function renderList(source, renderItem, cache, index) {
  let ret;
  const cached = cache && cache[index];
  const sourceIsArray = shared_esm_bundler_isArray(source);
  if (sourceIsArray || shared_esm_bundler_isString(source)) {
    const sourceIsReactiveArray = sourceIsArray && reactivity_esm_bundler_isReactive(source);
    let needsWrap = false;
    let isReadonlySource = false;
    if (sourceIsReactiveArray) {
      needsWrap = !reactivity_esm_bundler_isShallow(source);
      isReadonlySource = reactivity_esm_bundler_isReadonly(source);
      source = shallowReadArray(source);
    }
    ret = new Array(source.length);
    for (let i = 0, l = source.length; i < l; i++) {
      ret[i] = renderItem(
        needsWrap ? isReadonlySource ? toReadonly(toReactive(source[i])) : toReactive(source[i]) : source[i],
        i,
        void 0,
        cached && cached[i]
      );
    }
  } else if (typeof source === "number") {
    if (false) {}
    ret = new Array(source);
    for (let i = 0; i < source; i++) {
      ret[i] = renderItem(i + 1, i, void 0, cached && cached[i]);
    }
  } else if (shared_esm_bundler_isObject(source)) {
    if (source[Symbol.iterator]) {
      ret = Array.from(
        source,
        (item, i) => renderItem(item, i, void 0, cached && cached[i])
      );
    } else {
      const keys = Object.keys(source);
      ret = new Array(keys.length);
      for (let i = 0, l = keys.length; i < l; i++) {
        const key = keys[i];
        ret[i] = renderItem(source[key], key, i, cached && cached[i]);
      }
    }
  } else {
    ret = [];
  }
  if (cache) {
    cache[index] = ret;
  }
  return ret;
}

function createSlots(slots, dynamicSlots) {
  for (let i = 0; i < dynamicSlots.length; i++) {
    const slot = dynamicSlots[i];
    if (isArray(slot)) {
      for (let j = 0; j < slot.length; j++) {
        slots[slot[j].name] = slot[j].fn;
      }
    } else if (slot) {
      slots[slot.name] = slot.key ? (...args) => {
        const res = slot.fn(...args);
        if (res) res.key = slot.key;
        return res;
      } : slot.fn;
    }
  }
  return slots;
}

function renderSlot(slots, name, props = {}, fallback, noSlotted) {
  if (currentRenderingInstance.ce || currentRenderingInstance.parent && isAsyncWrapper(currentRenderingInstance.parent) && currentRenderingInstance.parent.ce) {
    if (name !== "default") props.name = name;
    return openBlock(), createBlock(
      runtime_core_esm_bundler_Fragment,
      null,
      [createVNode("slot", props, fallback && fallback())],
      64
    );
  }
  let slot = slots[name];
  if (false) {}
  if (slot && slot._c) {
    slot._d = false;
  }
  openBlock();
  const validSlotContent = slot && ensureValidVNode(slot(props));
  const slotKey = props.key || // slot content array of a dynamic conditional slot may have a branch
  // key attached in the `createSlots` helper, respect that
  validSlotContent && validSlotContent.key;
  const rendered = createBlock(
    runtime_core_esm_bundler_Fragment,
    {
      key: (slotKey && !isSymbol(slotKey) ? slotKey : `_${name}`) + // #7256 force differentiate fallback content from actual content
      (!validSlotContent && fallback ? "_fb" : "")
    },
    validSlotContent || (fallback ? fallback() : []),
    validSlotContent && slots._ === 1 ? 64 : -2
  );
  if (!noSlotted && rendered.scopeId) {
    rendered.slotScopeIds = [rendered.scopeId + "-s"];
  }
  if (slot && slot._c) {
    slot._d = true;
  }
  return rendered;
}
function ensureValidVNode(vnodes) {
  return vnodes.some((child) => {
    if (!isVNode(child)) return true;
    if (child.type === Comment) return false;
    if (child.type === runtime_core_esm_bundler_Fragment && !ensureValidVNode(child.children))
      return false;
    return true;
  }) ? vnodes : null;
}

function toHandlers(obj, preserveCaseIfNecessary) {
  const ret = {};
  if (false) {}
  for (const key in obj) {
    ret[preserveCaseIfNecessary && /[A-Z]/.test(key) ? `on:${key}` : toHandlerKey(key)] = obj[key];
  }
  return ret;
}

const getPublicInstance = (i) => {
  if (!i) return null;
  if (isStatefulComponent(i)) return getComponentPublicInstance(i);
  return getPublicInstance(i.parent);
};
const publicPropertiesMap = (
  // Move PURE marker to new line to workaround compiler discarding it
  // due to type annotation
  /* @__PURE__ */ shared_esm_bundler_extend(/* @__PURE__ */ Object.create(null), {
    $: (i) => i,
    $el: (i) => i.vnode.el,
    $data: (i) => i.data,
    $props: (i) =>  false ? 0 : i.props,
    $attrs: (i) =>  false ? 0 : i.attrs,
    $slots: (i) =>  false ? 0 : i.slots,
    $refs: (i) =>  false ? 0 : i.refs,
    $parent: (i) => getPublicInstance(i.parent),
    $root: (i) => getPublicInstance(i.root),
    $host: (i) => i.ce,
    $emit: (i) => i.emit,
    $options: (i) =>  true ? resolveMergedOptions(i) : 0,
    $forceUpdate: (i) => i.f || (i.f = () => {
      queueJob(i.update);
    }),
    $nextTick: (i) => i.n || (i.n = nextTick.bind(i.proxy)),
    $watch: (i) =>  true ? instanceWatch.bind(i) : 0
  })
);
const isReservedPrefix = (key) => key === "_" || key === "$";
const hasSetupBinding = (state, key) => state !== shared_esm_bundler_EMPTY_OBJ && !state.__isScriptSetup && hasOwn(state, key);
const PublicInstanceProxyHandlers = {
  get({ _: instance }, key) {
    if (key === "__v_skip") {
      return true;
    }
    const { ctx, setupState, data, props, accessCache, type, appContext } = instance;
    if (false) {}
    let normalizedProps;
    if (key[0] !== "$") {
      const n = accessCache[key];
      if (n !== void 0) {
        switch (n) {
          case 1 /* SETUP */:
            return setupState[key];
          case 2 /* DATA */:
            return data[key];
          case 4 /* CONTEXT */:
            return ctx[key];
          case 3 /* PROPS */:
            return props[key];
        }
      } else if (hasSetupBinding(setupState, key)) {
        accessCache[key] = 1 /* SETUP */;
        return setupState[key];
      } else if (data !== shared_esm_bundler_EMPTY_OBJ && hasOwn(data, key)) {
        accessCache[key] = 2 /* DATA */;
        return data[key];
      } else if (
        // only cache other properties when instance has declared (thus stable)
        // props
        (normalizedProps = instance.propsOptions[0]) && hasOwn(normalizedProps, key)
      ) {
        accessCache[key] = 3 /* PROPS */;
        return props[key];
      } else if (ctx !== shared_esm_bundler_EMPTY_OBJ && hasOwn(ctx, key)) {
        accessCache[key] = 4 /* CONTEXT */;
        return ctx[key];
      } else if ( false || shouldCacheAccess) {
        accessCache[key] = 0 /* OTHER */;
      }
    }
    const publicGetter = publicPropertiesMap[key];
    let cssModule, globalProperties;
    if (publicGetter) {
      if (key === "$attrs") {
        reactivity_esm_bundler_track(instance.attrs, "get", "");
         false && 0;
      } else if (false) {}
      return publicGetter(instance);
    } else if (
      // css module (injected by vue-loader)
      (cssModule = type.__cssModules) && (cssModule = cssModule[key])
    ) {
      return cssModule;
    } else if (ctx !== shared_esm_bundler_EMPTY_OBJ && hasOwn(ctx, key)) {
      accessCache[key] = 4 /* CONTEXT */;
      return ctx[key];
    } else if (
      // global properties
      globalProperties = appContext.config.globalProperties, hasOwn(globalProperties, key)
    ) {
      {
        return globalProperties[key];
      }
    } else if (false) {}
  },
  set({ _: instance }, key, value) {
    const { data, setupState, ctx } = instance;
    if (hasSetupBinding(setupState, key)) {
      setupState[key] = value;
      return true;
    } else if (false) {} else if (data !== shared_esm_bundler_EMPTY_OBJ && hasOwn(data, key)) {
      data[key] = value;
      return true;
    } else if (hasOwn(instance.props, key)) {
       false && 0;
      return false;
    }
    if (key[0] === "$" && key.slice(1) in instance) {
       false && 0;
      return false;
    } else {
      if (false) {} else {
        ctx[key] = value;
      }
    }
    return true;
  },
  has({
    _: { data, setupState, accessCache, ctx, appContext, propsOptions, type }
  }, key) {
    let normalizedProps, cssModules;
    return !!(accessCache[key] || data !== shared_esm_bundler_EMPTY_OBJ && key[0] !== "$" && hasOwn(data, key) || hasSetupBinding(setupState, key) || (normalizedProps = propsOptions[0]) && hasOwn(normalizedProps, key) || hasOwn(ctx, key) || hasOwn(publicPropertiesMap, key) || hasOwn(appContext.config.globalProperties, key) || (cssModules = type.__cssModules) && cssModules[key]);
  },
  defineProperty(target, key, descriptor) {
    if (descriptor.get != null) {
      target._.accessCache[key] = 0;
    } else if (hasOwn(descriptor, "value")) {
      this.set(target, key, descriptor.value, null);
    }
    return Reflect.defineProperty(target, key, descriptor);
  }
};
if (false) {}
const RuntimeCompiledPublicInstanceProxyHandlers = /* @__PURE__ */ shared_esm_bundler_extend({}, PublicInstanceProxyHandlers, {
  get(target, key) {
    if (key === Symbol.unscopables) {
      return;
    }
    return PublicInstanceProxyHandlers.get(target, key, target);
  },
  has(_, key) {
    const has = key[0] !== "_" && !isGloballyAllowed(key);
    if (false) {}
    return has;
  }
});
function createDevRenderContext(instance) {
  const target = {};
  Object.defineProperty(target, `_`, {
    configurable: true,
    enumerable: false,
    get: () => instance
  });
  Object.keys(publicPropertiesMap).forEach((key) => {
    Object.defineProperty(target, key, {
      configurable: true,
      enumerable: false,
      get: () => publicPropertiesMap[key](instance),
      // intercepted by the proxy so no need for implementation,
      // but needed to prevent set errors
      set: NOOP
    });
  });
  return target;
}
function exposePropsOnRenderContext(instance) {
  const {
    ctx,
    propsOptions: [propsOptions]
  } = instance;
  if (propsOptions) {
    Object.keys(propsOptions).forEach((key) => {
      Object.defineProperty(ctx, key, {
        enumerable: true,
        configurable: true,
        get: () => instance.props[key],
        set: NOOP
      });
    });
  }
}
function exposeSetupStateOnRenderContext(instance) {
  const { ctx, setupState } = instance;
  Object.keys(toRaw(setupState)).forEach((key) => {
    if (!setupState.__isScriptSetup) {
      if (isReservedPrefix(key[0])) {
        warn$1(
          `setup() return property ${JSON.stringify(
            key
          )} should not start with "$" or "_" which are reserved prefixes for Vue internals.`
        );
        return;
      }
      Object.defineProperty(ctx, key, {
        enumerable: true,
        configurable: true,
        get: () => setupState[key],
        set: NOOP
      });
    }
  });
}

const warnRuntimeUsage = (method) => warn$1(
  `${method}() is a compiler-hint helper that is only usable inside <script setup> of a single file component. Its arguments should be compiled away and passing it at runtime has no effect.`
);
function defineProps() {
  if (false) {}
  return null;
}
function defineEmits() {
  if (false) {}
  return null;
}
function defineExpose(exposed) {
  if (false) {}
}
function defineOptions(options) {
  if (false) {}
}
function defineSlots() {
  if (false) {}
  return null;
}
function defineModel() {
  if (false) {}
}
function withDefaults(props, defaults) {
  if (false) {}
  return null;
}
function useSlots() {
  return getContext("useSlots").slots;
}
function useAttrs() {
  return getContext("useAttrs").attrs;
}
function getContext(calledFunctionName) {
  const i = runtime_core_esm_bundler_getCurrentInstance();
  if (false) {}
  return i.setupContext || (i.setupContext = createSetupContext(i));
}
function normalizePropsOrEmits(props) {
  return shared_esm_bundler_isArray(props) ? props.reduce(
    (normalized, p) => (normalized[p] = null, normalized),
    {}
  ) : props;
}
function mergeDefaults(raw, defaults) {
  const props = normalizePropsOrEmits(raw);
  for (const key in defaults) {
    if (key.startsWith("__skip")) continue;
    let opt = props[key];
    if (opt) {
      if (isArray(opt) || isFunction(opt)) {
        opt = props[key] = { type: opt, default: defaults[key] };
      } else {
        opt.default = defaults[key];
      }
    } else if (opt === null) {
      opt = props[key] = { default: defaults[key] };
    } else if (false) {}
    if (opt && defaults[`__skip_${key}`]) {
      opt.skipFactory = true;
    }
  }
  return props;
}
function mergeModels(a, b) {
  if (!a || !b) return a || b;
  if (isArray(a) && isArray(b)) return a.concat(b);
  return extend({}, normalizePropsOrEmits(a), normalizePropsOrEmits(b));
}
function createPropsRestProxy(props, excludedKeys) {
  const ret = {};
  for (const key in props) {
    if (!excludedKeys.includes(key)) {
      Object.defineProperty(ret, key, {
        enumerable: true,
        get: () => props[key]
      });
    }
  }
  return ret;
}
function withAsyncContext(getAwaitable) {
  const ctx = runtime_core_esm_bundler_getCurrentInstance();
  if (false) {}
  let awaitable = getAwaitable();
  unsetCurrentInstance();
  if (isPromise(awaitable)) {
    awaitable = awaitable.catch((e) => {
      setCurrentInstance(ctx);
      throw e;
    });
  }
  return [awaitable, () => setCurrentInstance(ctx)];
}

function createDuplicateChecker() {
  const cache = /* @__PURE__ */ Object.create(null);
  return (type, key) => {
    if (cache[key]) {
      warn$1(`${type} property "${key}" is already defined in ${cache[key]}.`);
    } else {
      cache[key] = type;
    }
  };
}
let shouldCacheAccess = true;
function applyOptions(instance) {
  const options = resolveMergedOptions(instance);
  const publicThis = instance.proxy;
  const ctx = instance.ctx;
  shouldCacheAccess = false;
  if (options.beforeCreate) {
    callHook(options.beforeCreate, instance, "bc");
  }
  const {
    // state
    data: dataOptions,
    computed: computedOptions,
    methods,
    watch: watchOptions,
    provide: provideOptions,
    inject: injectOptions,
    // lifecycle
    created,
    beforeMount,
    mounted,
    beforeUpdate,
    updated,
    activated,
    deactivated,
    beforeDestroy,
    beforeUnmount,
    destroyed,
    unmounted,
    render,
    renderTracked,
    renderTriggered,
    errorCaptured,
    serverPrefetch,
    // public API
    expose,
    inheritAttrs,
    // assets
    components,
    directives,
    filters
  } = options;
  const checkDuplicateProperties =  false ? 0 : null;
  if (false) {}
  if (injectOptions) {
    resolveInjections(injectOptions, ctx, checkDuplicateProperties);
  }
  if (methods) {
    for (const key in methods) {
      const methodHandler = methods[key];
      if (shared_esm_bundler_isFunction(methodHandler)) {
        if (false) {} else {
          ctx[key] = methodHandler.bind(publicThis);
        }
        if (false) {}
      } else if (false) {}
    }
  }
  if (dataOptions) {
    if (false) {}
    const data = dataOptions.call(publicThis, publicThis);
    if (false) {}
    if (!shared_esm_bundler_isObject(data)) {
       false && 0;
    } else {
      instance.data = reactive(data);
      if (false) {}
    }
  }
  shouldCacheAccess = true;
  if (computedOptions) {
    for (const key in computedOptions) {
      const opt = computedOptions[key];
      const get = shared_esm_bundler_isFunction(opt) ? opt.bind(publicThis, publicThis) : shared_esm_bundler_isFunction(opt.get) ? opt.get.bind(publicThis, publicThis) : shared_esm_bundler_NOOP;
      if (false) {}
      const set = !shared_esm_bundler_isFunction(opt) && shared_esm_bundler_isFunction(opt.set) ? opt.set.bind(publicThis) :  false ? 0 : shared_esm_bundler_NOOP;
      const c = runtime_core_esm_bundler_computed({
        get,
        set
      });
      Object.defineProperty(ctx, key, {
        enumerable: true,
        configurable: true,
        get: () => c.value,
        set: (v) => c.value = v
      });
      if (false) {}
    }
  }
  if (watchOptions) {
    for (const key in watchOptions) {
      createWatcher(watchOptions[key], ctx, publicThis, key);
    }
  }
  if (provideOptions) {
    const provides = shared_esm_bundler_isFunction(provideOptions) ? provideOptions.call(publicThis) : provideOptions;
    Reflect.ownKeys(provides).forEach((key) => {
      provide(key, provides[key]);
    });
  }
  if (created) {
    callHook(created, instance, "c");
  }
  function registerLifecycleHook(register, hook) {
    if (shared_esm_bundler_isArray(hook)) {
      hook.forEach((_hook) => register(_hook.bind(publicThis)));
    } else if (hook) {
      register(hook.bind(publicThis));
    }
  }
  registerLifecycleHook(onBeforeMount, beforeMount);
  registerLifecycleHook(runtime_core_esm_bundler_onMounted, mounted);
  registerLifecycleHook(runtime_core_esm_bundler_onBeforeUpdate, beforeUpdate);
  registerLifecycleHook(onUpdated, updated);
  registerLifecycleHook(runtime_core_esm_bundler_onActivated, activated);
  registerLifecycleHook(runtime_core_esm_bundler_onDeactivated, deactivated);
  registerLifecycleHook(onErrorCaptured, errorCaptured);
  registerLifecycleHook(onRenderTracked, renderTracked);
  registerLifecycleHook(onRenderTriggered, renderTriggered);
  registerLifecycleHook(onBeforeUnmount, beforeUnmount);
  registerLifecycleHook(runtime_core_esm_bundler_onUnmounted, unmounted);
  registerLifecycleHook(onServerPrefetch, serverPrefetch);
  if (shared_esm_bundler_isArray(expose)) {
    if (expose.length) {
      const exposed = instance.exposed || (instance.exposed = {});
      expose.forEach((key) => {
        Object.defineProperty(exposed, key, {
          get: () => publicThis[key],
          set: (val) => publicThis[key] = val,
          enumerable: true
        });
      });
    } else if (!instance.exposed) {
      instance.exposed = {};
    }
  }
  if (render && instance.render === shared_esm_bundler_NOOP) {
    instance.render = render;
  }
  if (inheritAttrs != null) {
    instance.inheritAttrs = inheritAttrs;
  }
  if (components) instance.components = components;
  if (directives) instance.directives = directives;
  if (serverPrefetch) {
    markAsyncBoundary(instance);
  }
}
function resolveInjections(injectOptions, ctx, checkDuplicateProperties = shared_esm_bundler_NOOP) {
  if (shared_esm_bundler_isArray(injectOptions)) {
    injectOptions = normalizeInject(injectOptions);
  }
  for (const key in injectOptions) {
    const opt = injectOptions[key];
    let injected;
    if (shared_esm_bundler_isObject(opt)) {
      if ("default" in opt) {
        injected = runtime_core_esm_bundler_inject(
          opt.from || key,
          opt.default,
          true
        );
      } else {
        injected = runtime_core_esm_bundler_inject(opt.from || key);
      }
    } else {
      injected = runtime_core_esm_bundler_inject(opt);
    }
    if (reactivity_esm_bundler_isRef(injected)) {
      Object.defineProperty(ctx, key, {
        enumerable: true,
        configurable: true,
        get: () => injected.value,
        set: (v) => injected.value = v
      });
    } else {
      ctx[key] = injected;
    }
    if (false) {}
  }
}
function callHook(hook, instance, type) {
  callWithAsyncErrorHandling(
    shared_esm_bundler_isArray(hook) ? hook.map((h) => h.bind(instance.proxy)) : hook.bind(instance.proxy),
    instance,
    type
  );
}
function createWatcher(raw, ctx, publicThis, key) {
  let getter = key.includes(".") ? createPathGetter(publicThis, key) : () => publicThis[key];
  if (shared_esm_bundler_isString(raw)) {
    const handler = ctx[raw];
    if (shared_esm_bundler_isFunction(handler)) {
      {
        runtime_core_esm_bundler_watch(getter, handler);
      }
    } else if (false) {}
  } else if (shared_esm_bundler_isFunction(raw)) {
    {
      runtime_core_esm_bundler_watch(getter, raw.bind(publicThis));
    }
  } else if (shared_esm_bundler_isObject(raw)) {
    if (shared_esm_bundler_isArray(raw)) {
      raw.forEach((r) => createWatcher(r, ctx, publicThis, key));
    } else {
      const handler = shared_esm_bundler_isFunction(raw.handler) ? raw.handler.bind(publicThis) : ctx[raw.handler];
      if (shared_esm_bundler_isFunction(handler)) {
        runtime_core_esm_bundler_watch(getter, handler, raw);
      } else if (false) {}
    }
  } else if (false) {}
}
function resolveMergedOptions(instance) {
  const base = instance.type;
  const { mixins, extends: extendsOptions } = base;
  const {
    mixins: globalMixins,
    optionsCache: cache,
    config: { optionMergeStrategies }
  } = instance.appContext;
  const cached = cache.get(base);
  let resolved;
  if (cached) {
    resolved = cached;
  } else if (!globalMixins.length && !mixins && !extendsOptions) {
    {
      resolved = base;
    }
  } else {
    resolved = {};
    if (globalMixins.length) {
      globalMixins.forEach(
        (m) => mergeOptions(resolved, m, optionMergeStrategies, true)
      );
    }
    mergeOptions(resolved, base, optionMergeStrategies);
  }
  if (shared_esm_bundler_isObject(base)) {
    cache.set(base, resolved);
  }
  return resolved;
}
function mergeOptions(to, from, strats, asMixin = false) {
  const { mixins, extends: extendsOptions } = from;
  if (extendsOptions) {
    mergeOptions(to, extendsOptions, strats, true);
  }
  if (mixins) {
    mixins.forEach(
      (m) => mergeOptions(to, m, strats, true)
    );
  }
  for (const key in from) {
    if (asMixin && key === "expose") {
       false && 0;
    } else {
      const strat = internalOptionMergeStrats[key] || strats && strats[key];
      to[key] = strat ? strat(to[key], from[key]) : from[key];
    }
  }
  return to;
}
const internalOptionMergeStrats = {
  data: mergeDataFn,
  props: mergeEmitsOrPropsOptions,
  emits: mergeEmitsOrPropsOptions,
  // objects
  methods: mergeObjectOptions,
  computed: mergeObjectOptions,
  // lifecycle
  beforeCreate: mergeAsArray,
  created: mergeAsArray,
  beforeMount: mergeAsArray,
  mounted: mergeAsArray,
  beforeUpdate: mergeAsArray,
  updated: mergeAsArray,
  beforeDestroy: mergeAsArray,
  beforeUnmount: mergeAsArray,
  destroyed: mergeAsArray,
  unmounted: mergeAsArray,
  activated: mergeAsArray,
  deactivated: mergeAsArray,
  errorCaptured: mergeAsArray,
  serverPrefetch: mergeAsArray,
  // assets
  components: mergeObjectOptions,
  directives: mergeObjectOptions,
  // watch
  watch: mergeWatchOptions,
  // provide / inject
  provide: mergeDataFn,
  inject: mergeInject
};
function mergeDataFn(to, from) {
  if (!from) {
    return to;
  }
  if (!to) {
    return from;
  }
  return function mergedDataFn() {
    return (shared_esm_bundler_extend)(
      shared_esm_bundler_isFunction(to) ? to.call(this, this) : to,
      shared_esm_bundler_isFunction(from) ? from.call(this, this) : from
    );
  };
}
function mergeInject(to, from) {
  return mergeObjectOptions(normalizeInject(to), normalizeInject(from));
}
function normalizeInject(raw) {
  if (shared_esm_bundler_isArray(raw)) {
    const res = {};
    for (let i = 0; i < raw.length; i++) {
      res[raw[i]] = raw[i];
    }
    return res;
  }
  return raw;
}
function mergeAsArray(to, from) {
  return to ? [...new Set([].concat(to, from))] : from;
}
function mergeObjectOptions(to, from) {
  return to ? shared_esm_bundler_extend(/* @__PURE__ */ Object.create(null), to, from) : from;
}
function mergeEmitsOrPropsOptions(to, from) {
  if (to) {
    if (shared_esm_bundler_isArray(to) && shared_esm_bundler_isArray(from)) {
      return [.../* @__PURE__ */ new Set([...to, ...from])];
    }
    return shared_esm_bundler_extend(
      /* @__PURE__ */ Object.create(null),
      normalizePropsOrEmits(to),
      normalizePropsOrEmits(from != null ? from : {})
    );
  } else {
    return from;
  }
}
function mergeWatchOptions(to, from) {
  if (!to) return from;
  if (!from) return to;
  const merged = shared_esm_bundler_extend(/* @__PURE__ */ Object.create(null), to);
  for (const key in from) {
    merged[key] = mergeAsArray(to[key], from[key]);
  }
  return merged;
}

function createAppContext() {
  return {
    app: null,
    config: {
      isNativeTag: NO,
      performance: false,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {}
    },
    mixins: [],
    components: {},
    directives: {},
    provides: /* @__PURE__ */ Object.create(null),
    optionsCache: /* @__PURE__ */ new WeakMap(),
    propsCache: /* @__PURE__ */ new WeakMap(),
    emitsCache: /* @__PURE__ */ new WeakMap()
  };
}
let uid$1 = 0;
function createAppAPI(render, hydrate) {
  return function createApp(rootComponent, rootProps = null) {
    if (!shared_esm_bundler_isFunction(rootComponent)) {
      rootComponent = shared_esm_bundler_extend({}, rootComponent);
    }
    if (rootProps != null && !shared_esm_bundler_isObject(rootProps)) {
       false && 0;
      rootProps = null;
    }
    const context = createAppContext();
    const installedPlugins = /* @__PURE__ */ new WeakSet();
    const pluginCleanupFns = [];
    let isMounted = false;
    const app = context.app = {
      _uid: uid$1++,
      _component: rootComponent,
      _props: rootProps,
      _container: null,
      _context: context,
      _instance: null,
      version,
      get config() {
        return context.config;
      },
      set config(v) {
        if (false) {}
      },
      use(plugin, ...options) {
        if (installedPlugins.has(plugin)) {
           false && 0;
        } else if (plugin && shared_esm_bundler_isFunction(plugin.install)) {
          installedPlugins.add(plugin);
          plugin.install(app, ...options);
        } else if (shared_esm_bundler_isFunction(plugin)) {
          installedPlugins.add(plugin);
          plugin(app, ...options);
        } else if (false) {}
        return app;
      },
      mixin(mixin) {
        if (true) {
          if (!context.mixins.includes(mixin)) {
            context.mixins.push(mixin);
          } else if (false) {}
        } else {}
        return app;
      },
      component(name, component) {
        if (false) {}
        if (!component) {
          return context.components[name];
        }
        if (false) {}
        context.components[name] = component;
        return app;
      },
      directive(name, directive) {
        if (false) {}
        if (!directive) {
          return context.directives[name];
        }
        if (false) {}
        context.directives[name] = directive;
        return app;
      },
      mount(rootContainer, isHydrate, namespace) {
        if (!isMounted) {
          if (false) {}
          const vnode = app._ceVNode || createVNode(rootComponent, rootProps);
          vnode.appContext = context;
          if (namespace === true) {
            namespace = "svg";
          } else if (namespace === false) {
            namespace = void 0;
          }
          if (false) {}
          if (isHydrate && hydrate) {
            hydrate(vnode, rootContainer);
          } else {
            render(vnode, rootContainer, namespace);
          }
          isMounted = true;
          app._container = rootContainer;
          rootContainer.__vue_app__ = app;
          if (false) {}
          return getComponentPublicInstance(vnode.component);
        } else if (false) {}
      },
      onUnmount(cleanupFn) {
        if (false) {}
        pluginCleanupFns.push(cleanupFn);
      },
      unmount() {
        if (isMounted) {
          callWithAsyncErrorHandling(
            pluginCleanupFns,
            app._instance,
            16
          );
          render(null, app._container);
          if (false) {}
          delete app._container.__vue_app__;
        } else if (false) {}
      },
      provide(key, value) {
        if (false) {}
        context.provides[key] = value;
        return app;
      },
      runWithContext(fn) {
        const lastApp = currentApp;
        currentApp = app;
        try {
          return fn();
        } finally {
          currentApp = lastApp;
        }
      }
    };
    return app;
  };
}
let currentApp = null;

function provide(key, value) {
  if (!currentInstance) {
    if (false) {}
  } else {
    let provides = currentInstance.provides;
    const parentProvides = currentInstance.parent && currentInstance.parent.provides;
    if (parentProvides === provides) {
      provides = currentInstance.provides = Object.create(parentProvides);
    }
    provides[key] = value;
  }
}
function runtime_core_esm_bundler_inject(key, defaultValue, treatDefaultAsFactory = false) {
  const instance = runtime_core_esm_bundler_getCurrentInstance();
  if (instance || currentApp) {
    let provides = currentApp ? currentApp._context.provides : instance ? instance.parent == null || instance.ce ? instance.vnode.appContext && instance.vnode.appContext.provides : instance.parent.provides : void 0;
    if (provides && key in provides) {
      return provides[key];
    } else if (arguments.length > 1) {
      return treatDefaultAsFactory && shared_esm_bundler_isFunction(defaultValue) ? defaultValue.call(instance && instance.proxy) : defaultValue;
    } else if (false) {}
  } else if (false) {}
}
function runtime_core_esm_bundler_hasInjectionContext() {
  return !!(runtime_core_esm_bundler_getCurrentInstance() || currentApp);
}

const internalObjectProto = {};
const createInternalObject = () => Object.create(internalObjectProto);
const isInternalObject = (obj) => Object.getPrototypeOf(obj) === internalObjectProto;

function initProps(instance, rawProps, isStateful, isSSR = false) {
  const props = {};
  const attrs = createInternalObject();
  instance.propsDefaults = /* @__PURE__ */ Object.create(null);
  setFullProps(instance, rawProps, props, attrs);
  for (const key in instance.propsOptions[0]) {
    if (!(key in props)) {
      props[key] = void 0;
    }
  }
  if (false) {}
  if (isStateful) {
    instance.props = isSSR ? props : shallowReactive(props);
  } else {
    if (!instance.type.props) {
      instance.props = attrs;
    } else {
      instance.props = props;
    }
  }
  instance.attrs = attrs;
}
function isInHmrContext(instance) {
  while (instance) {
    if (instance.type.__hmrId) return true;
    instance = instance.parent;
  }
}
function updateProps(instance, rawProps, rawPrevProps, optimized) {
  const {
    props,
    attrs,
    vnode: { patchFlag }
  } = instance;
  const rawCurrentProps = reactivity_esm_bundler_toRaw(props);
  const [options] = instance.propsOptions;
  let hasAttrsChanged = false;
  if (
    // always force full diff in dev
    // - #1942 if hmr is enabled with sfc component
    // - vite#872 non-sfc component used by sfc component
     true && (optimized || patchFlag > 0) && !(patchFlag & 16)
  ) {
    if (patchFlag & 8) {
      const propsToUpdate = instance.vnode.dynamicProps;
      for (let i = 0; i < propsToUpdate.length; i++) {
        let key = propsToUpdate[i];
        if (isEmitListener(instance.emitsOptions, key)) {
          continue;
        }
        const value = rawProps[key];
        if (options) {
          if (hasOwn(attrs, key)) {
            if (value !== attrs[key]) {
              attrs[key] = value;
              hasAttrsChanged = true;
            }
          } else {
            const camelizedKey = shared_esm_bundler_camelize(key);
            props[camelizedKey] = resolvePropValue(
              options,
              rawCurrentProps,
              camelizedKey,
              value,
              instance,
              false
            );
          }
        } else {
          if (value !== attrs[key]) {
            attrs[key] = value;
            hasAttrsChanged = true;
          }
        }
      }
    }
  } else {
    if (setFullProps(instance, rawProps, props, attrs)) {
      hasAttrsChanged = true;
    }
    let kebabKey;
    for (const key in rawCurrentProps) {
      if (!rawProps || // for camelCase
      !hasOwn(rawProps, key) && // it's possible the original props was passed in as kebab-case
      // and converted to camelCase (#955)
      ((kebabKey = shared_esm_bundler_hyphenate(key)) === key || !hasOwn(rawProps, kebabKey))) {
        if (options) {
          if (rawPrevProps && // for camelCase
          (rawPrevProps[key] !== void 0 || // for kebab-case
          rawPrevProps[kebabKey] !== void 0)) {
            props[key] = resolvePropValue(
              options,
              rawCurrentProps,
              key,
              void 0,
              instance,
              true
            );
          }
        } else {
          delete props[key];
        }
      }
    }
    if (attrs !== rawCurrentProps) {
      for (const key in attrs) {
        if (!rawProps || !hasOwn(rawProps, key) && true) {
          delete attrs[key];
          hasAttrsChanged = true;
        }
      }
    }
  }
  if (hasAttrsChanged) {
    trigger(instance.attrs, "set", "");
  }
  if (false) {}
}
function setFullProps(instance, rawProps, props, attrs) {
  const [options, needCastKeys] = instance.propsOptions;
  let hasAttrsChanged = false;
  let rawCastValues;
  if (rawProps) {
    for (let key in rawProps) {
      if (shared_esm_bundler_isReservedProp(key)) {
        continue;
      }
      const value = rawProps[key];
      let camelKey;
      if (options && hasOwn(options, camelKey = shared_esm_bundler_camelize(key))) {
        if (!needCastKeys || !needCastKeys.includes(camelKey)) {
          props[camelKey] = value;
        } else {
          (rawCastValues || (rawCastValues = {}))[camelKey] = value;
        }
      } else if (!isEmitListener(instance.emitsOptions, key)) {
        if (!(key in attrs) || value !== attrs[key]) {
          attrs[key] = value;
          hasAttrsChanged = true;
        }
      }
    }
  }
  if (needCastKeys) {
    const rawCurrentProps = reactivity_esm_bundler_toRaw(props);
    const castValues = rawCastValues || shared_esm_bundler_EMPTY_OBJ;
    for (let i = 0; i < needCastKeys.length; i++) {
      const key = needCastKeys[i];
      props[key] = resolvePropValue(
        options,
        rawCurrentProps,
        key,
        castValues[key],
        instance,
        !hasOwn(castValues, key)
      );
    }
  }
  return hasAttrsChanged;
}
function resolvePropValue(options, props, key, value, instance, isAbsent) {
  const opt = options[key];
  if (opt != null) {
    const hasDefault = hasOwn(opt, "default");
    if (hasDefault && value === void 0) {
      const defaultValue = opt.default;
      if (opt.type !== Function && !opt.skipFactory && shared_esm_bundler_isFunction(defaultValue)) {
        const { propsDefaults } = instance;
        if (key in propsDefaults) {
          value = propsDefaults[key];
        } else {
          const reset = setCurrentInstance(instance);
          value = propsDefaults[key] = defaultValue.call(
            null,
            props
          );
          reset();
        }
      } else {
        value = defaultValue;
      }
      if (instance.ce) {
        instance.ce._setProp(key, value);
      }
    }
    if (opt[0 /* shouldCast */]) {
      if (isAbsent && !hasDefault) {
        value = false;
      } else if (opt[1 /* shouldCastTrue */] && (value === "" || value === shared_esm_bundler_hyphenate(key))) {
        value = true;
      }
    }
  }
  return value;
}
const mixinPropsCache = /* @__PURE__ */ new WeakMap();
function normalizePropsOptions(comp, appContext, asMixin = false) {
  const cache =  true && asMixin ? mixinPropsCache : appContext.propsCache;
  const cached = cache.get(comp);
  if (cached) {
    return cached;
  }
  const raw = comp.props;
  const normalized = {};
  const needCastKeys = [];
  let hasExtends = false;
  if ( true && !shared_esm_bundler_isFunction(comp)) {
    const extendProps = (raw2) => {
      hasExtends = true;
      const [props, keys] = normalizePropsOptions(raw2, appContext, true);
      shared_esm_bundler_extend(normalized, props);
      if (keys) needCastKeys.push(...keys);
    };
    if (!asMixin && appContext.mixins.length) {
      appContext.mixins.forEach(extendProps);
    }
    if (comp.extends) {
      extendProps(comp.extends);
    }
    if (comp.mixins) {
      comp.mixins.forEach(extendProps);
    }
  }
  if (!raw && !hasExtends) {
    if (shared_esm_bundler_isObject(comp)) {
      cache.set(comp, EMPTY_ARR);
    }
    return EMPTY_ARR;
  }
  if (shared_esm_bundler_isArray(raw)) {
    for (let i = 0; i < raw.length; i++) {
      if (false) {}
      const normalizedKey = shared_esm_bundler_camelize(raw[i]);
      if (validatePropName(normalizedKey)) {
        normalized[normalizedKey] = shared_esm_bundler_EMPTY_OBJ;
      }
    }
  } else if (raw) {
    if (false) {}
    for (const key in raw) {
      const normalizedKey = shared_esm_bundler_camelize(key);
      if (validatePropName(normalizedKey)) {
        const opt = raw[key];
        const prop = normalized[normalizedKey] = shared_esm_bundler_isArray(opt) || shared_esm_bundler_isFunction(opt) ? { type: opt } : shared_esm_bundler_extend({}, opt);
        const propType = prop.type;
        let shouldCast = false;
        let shouldCastTrue = true;
        if (shared_esm_bundler_isArray(propType)) {
          for (let index = 0; index < propType.length; ++index) {
            const type = propType[index];
            const typeName = shared_esm_bundler_isFunction(type) && type.name;
            if (typeName === "Boolean") {
              shouldCast = true;
              break;
            } else if (typeName === "String") {
              shouldCastTrue = false;
            }
          }
        } else {
          shouldCast = shared_esm_bundler_isFunction(propType) && propType.name === "Boolean";
        }
        prop[0 /* shouldCast */] = shouldCast;
        prop[1 /* shouldCastTrue */] = shouldCastTrue;
        if (shouldCast || hasOwn(prop, "default")) {
          needCastKeys.push(normalizedKey);
        }
      }
    }
  }
  const res = [normalized, needCastKeys];
  if (shared_esm_bundler_isObject(comp)) {
    cache.set(comp, res);
  }
  return res;
}
function validatePropName(key) {
  if (key[0] !== "$" && !shared_esm_bundler_isReservedProp(key)) {
    return true;
  } else if (false) {}
  return false;
}
function getType(ctor) {
  if (ctor === null) {
    return "null";
  }
  if (typeof ctor === "function") {
    return ctor.name || "";
  } else if (typeof ctor === "object") {
    const name = ctor.constructor && ctor.constructor.name;
    return name || "";
  }
  return "";
}
function validateProps(rawProps, props, instance) {
  const resolvedValues = toRaw(props);
  const options = instance.propsOptions[0];
  const camelizePropsKey = Object.keys(rawProps).map((key) => camelize(key));
  for (const key in options) {
    let opt = options[key];
    if (opt == null) continue;
    validateProp(
      key,
      resolvedValues[key],
      opt,
       false ? 0 : resolvedValues,
      !camelizePropsKey.includes(key)
    );
  }
}
function validateProp(name, value, prop, props, isAbsent) {
  const { type, required, validator, skipCheck } = prop;
  if (required && isAbsent) {
    warn$1('Missing required prop: "' + name + '"');
    return;
  }
  if (value == null && !required) {
    return;
  }
  if (type != null && type !== true && !skipCheck) {
    let isValid = false;
    const types = isArray(type) ? type : [type];
    const expectedTypes = [];
    for (let i = 0; i < types.length && !isValid; i++) {
      const { valid, expectedType } = assertType(value, types[i]);
      expectedTypes.push(expectedType || "");
      isValid = valid;
    }
    if (!isValid) {
      warn$1(getInvalidTypeMessage(name, value, expectedTypes));
      return;
    }
  }
  if (validator && !validator(value, props)) {
    warn$1('Invalid prop: custom validator check failed for prop "' + name + '".');
  }
}
const isSimpleType = /* @__PURE__ */ (/* unused pure expression or super */ null && (makeMap(
  "String,Number,Boolean,Function,Symbol,BigInt"
)));
function assertType(value, type) {
  let valid;
  const expectedType = getType(type);
  if (expectedType === "null") {
    valid = value === null;
  } else if (isSimpleType(expectedType)) {
    const t = typeof value;
    valid = t === expectedType.toLowerCase();
    if (!valid && t === "object") {
      valid = value instanceof type;
    }
  } else if (expectedType === "Object") {
    valid = isObject(value);
  } else if (expectedType === "Array") {
    valid = isArray(value);
  } else {
    valid = value instanceof type;
  }
  return {
    valid,
    expectedType
  };
}
function getInvalidTypeMessage(name, value, expectedTypes) {
  if (expectedTypes.length === 0) {
    return `Prop type [] for prop "${name}" won't match anything. Did you mean to use type Array instead?`;
  }
  let message = `Invalid prop: type check failed for prop "${name}". Expected ${expectedTypes.map(capitalize).join(" | ")}`;
  const expectedType = expectedTypes[0];
  const receivedType = toRawType(value);
  const expectedValue = styleValue(value, expectedType);
  const receivedValue = styleValue(value, receivedType);
  if (expectedTypes.length === 1 && isExplicable(expectedType) && !isBoolean(expectedType, receivedType)) {
    message += ` with value ${expectedValue}`;
  }
  message += `, got ${receivedType} `;
  if (isExplicable(receivedType)) {
    message += `with value ${receivedValue}.`;
  }
  return message;
}
function styleValue(value, type) {
  if (type === "String") {
    return `"${value}"`;
  } else if (type === "Number") {
    return `${Number(value)}`;
  } else {
    return `${value}`;
  }
}
function isExplicable(type) {
  const explicitTypes = ["string", "number", "boolean"];
  return explicitTypes.some((elem) => type.toLowerCase() === elem);
}
function isBoolean(...args) {
  return args.some((elem) => elem.toLowerCase() === "boolean");
}

const isInternalKey = (key) => key === "_" || key === "_ctx" || key === "$stable";
const normalizeSlotValue = (value) => shared_esm_bundler_isArray(value) ? value.map(normalizeVNode) : [normalizeVNode(value)];
const normalizeSlot = (key, rawSlot, ctx) => {
  if (rawSlot._n) {
    return rawSlot;
  }
  const normalized = withCtx((...args) => {
    if (false) {}
    return normalizeSlotValue(rawSlot(...args));
  }, ctx);
  normalized._c = false;
  return normalized;
};
const normalizeObjectSlots = (rawSlots, slots, instance) => {
  const ctx = rawSlots._ctx;
  for (const key in rawSlots) {
    if (isInternalKey(key)) continue;
    const value = rawSlots[key];
    if (shared_esm_bundler_isFunction(value)) {
      slots[key] = normalizeSlot(key, value, ctx);
    } else if (value != null) {
      if (false) {}
      const normalized = normalizeSlotValue(value);
      slots[key] = () => normalized;
    }
  }
};
const normalizeVNodeSlots = (instance, children) => {
  if (false) {}
  const normalized = normalizeSlotValue(children);
  instance.slots.default = () => normalized;
};
const assignSlots = (slots, children, optimized) => {
  for (const key in children) {
    if (optimized || !isInternalKey(key)) {
      slots[key] = children[key];
    }
  }
};
const initSlots = (instance, children, optimized) => {
  const slots = instance.slots = createInternalObject();
  if (instance.vnode.shapeFlag & 32) {
    const type = children._;
    if (type) {
      assignSlots(slots, children, optimized);
      if (optimized) {
        def(slots, "_", type, true);
      }
    } else {
      normalizeObjectSlots(children, slots);
    }
  } else if (children) {
    normalizeVNodeSlots(instance, children);
  }
};
const updateSlots = (instance, children, optimized) => {
  const { vnode, slots } = instance;
  let needDeletionCheck = true;
  let deletionComparisonTarget = shared_esm_bundler_EMPTY_OBJ;
  if (vnode.shapeFlag & 32) {
    const type = children._;
    if (type) {
      if (false) {} else if (optimized && type === 1) {
        needDeletionCheck = false;
      } else {
        assignSlots(slots, children, optimized);
      }
    } else {
      needDeletionCheck = !children.$stable;
      normalizeObjectSlots(children, slots);
    }
    deletionComparisonTarget = children;
  } else if (children) {
    normalizeVNodeSlots(instance, children);
    deletionComparisonTarget = { default: 1 };
  }
  if (needDeletionCheck) {
    for (const key in slots) {
      if (!isInternalKey(key) && deletionComparisonTarget[key] == null) {
        delete slots[key];
      }
    }
  }
};

let supported;
let perf;
function startMeasure(instance, type) {
  if (instance.appContext.config.performance && isSupported()) {
    perf.mark(`vue-${type}-${instance.uid}`);
  }
  if (false) {}
}
function endMeasure(instance, type) {
  if (instance.appContext.config.performance && isSupported()) {
    const startTag = `vue-${type}-${instance.uid}`;
    const endTag = startTag + `:end`;
    const measureName = `<${formatComponentName(instance, instance.type)}> ${type}`;
    perf.mark(endTag);
    perf.measure(measureName, startTag, endTag);
    perf.clearMeasures(measureName);
    perf.clearMarks(startTag);
    perf.clearMarks(endTag);
  }
  if (false) {}
}
function isSupported() {
  if (supported !== void 0) {
    return supported;
  }
  if (typeof window !== "undefined" && window.performance) {
    supported = true;
    perf = window.performance;
  } else {
    supported = false;
  }
  return supported;
}

function initFeatureFlags() {
  const needWarn = [];
  if (false) {}
  if (false) {}
  if (false) {}
  if (false) {}
}

const queuePostRenderEffect = queueEffectWithSuspense ;
function createRenderer(options) {
  return baseCreateRenderer(options);
}
function runtime_core_esm_bundler_createHydrationRenderer(options) {
  return baseCreateRenderer(options, createHydrationFunctions);
}
function baseCreateRenderer(options, createHydrationFns) {
  {
    initFeatureFlags();
  }
  const target = getGlobalThis();
  target.__VUE__ = true;
  if (false) {}
  const {
    insert: hostInsert,
    remove: hostRemove,
    patchProp: hostPatchProp,
    createElement: hostCreateElement,
    createText: hostCreateText,
    createComment: hostCreateComment,
    setText: hostSetText,
    setElementText: hostSetElementText,
    parentNode: hostParentNode,
    nextSibling: hostNextSibling,
    setScopeId: hostSetScopeId = shared_esm_bundler_NOOP,
    insertStaticContent: hostInsertStaticContent
  } = options;
  const patch = (n1, n2, container, anchor = null, parentComponent = null, parentSuspense = null, namespace = void 0, slotScopeIds = null, optimized =  false ? 0 : !!n2.dynamicChildren) => {
    if (n1 === n2) {
      return;
    }
    if (n1 && !isSameVNodeType(n1, n2)) {
      anchor = getNextHostNode(n1);
      unmount(n1, parentComponent, parentSuspense, true);
      n1 = null;
    }
    if (n2.patchFlag === -2) {
      optimized = false;
      n2.dynamicChildren = null;
    }
    const { type, ref, shapeFlag } = n2;
    switch (type) {
      case Text:
        processText(n1, n2, container, anchor);
        break;
      case Comment:
        processCommentNode(n1, n2, container, anchor);
        break;
      case runtime_core_esm_bundler_Static:
        if (n1 == null) {
          mountStaticNode(n2, container, anchor, namespace);
        } else if (false) {}
        break;
      case runtime_core_esm_bundler_Fragment:
        processFragment(
          n1,
          n2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
        break;
      default:
        if (shapeFlag & 1) {
          processElement(
            n1,
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else if (shapeFlag & 6) {
          processComponent(
            n1,
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else if (shapeFlag & 64) {
          type.process(
            n1,
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized,
            internals
          );
        } else if (shapeFlag & 128) {
          type.process(
            n1,
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized,
            internals
          );
        } else if (false) {}
    }
    if (ref != null && parentComponent) {
      setRef(ref, n1 && n1.ref, parentSuspense, n2 || n1, !n2);
    } else if (ref == null && n1 && n1.ref != null) {
      setRef(n1.ref, null, parentSuspense, n1, true);
    }
  };
  const processText = (n1, n2, container, anchor) => {
    if (n1 == null) {
      hostInsert(
        n2.el = hostCreateText(n2.children),
        container,
        anchor
      );
    } else {
      const el = n2.el = n1.el;
      if (n2.children !== n1.children) {
        hostSetText(el, n2.children);
      }
    }
  };
  const processCommentNode = (n1, n2, container, anchor) => {
    if (n1 == null) {
      hostInsert(
        n2.el = hostCreateComment(n2.children || ""),
        container,
        anchor
      );
    } else {
      n2.el = n1.el;
    }
  };
  const mountStaticNode = (n2, container, anchor, namespace) => {
    [n2.el, n2.anchor] = hostInsertStaticContent(
      n2.children,
      container,
      anchor,
      namespace,
      n2.el,
      n2.anchor
    );
  };
  const patchStaticNode = (n1, n2, container, namespace) => {
    if (n2.children !== n1.children) {
      const anchor = hostNextSibling(n1.anchor);
      removeStaticNode(n1);
      [n2.el, n2.anchor] = hostInsertStaticContent(
        n2.children,
        container,
        anchor,
        namespace
      );
    } else {
      n2.el = n1.el;
      n2.anchor = n1.anchor;
    }
  };
  const moveStaticNode = ({ el, anchor }, container, nextSibling) => {
    let next;
    while (el && el !== anchor) {
      next = hostNextSibling(el);
      hostInsert(el, container, nextSibling);
      el = next;
    }
    hostInsert(anchor, container, nextSibling);
  };
  const removeStaticNode = ({ el, anchor }) => {
    let next;
    while (el && el !== anchor) {
      next = hostNextSibling(el);
      hostRemove(el);
      el = next;
    }
    hostRemove(anchor);
  };
  const processElement = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    if (n2.type === "svg") {
      namespace = "svg";
    } else if (n2.type === "math") {
      namespace = "mathml";
    }
    if (n1 == null) {
      mountElement(
        n2,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized
      );
    } else {
      patchElement(
        n1,
        n2,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized
      );
    }
  };
  const mountElement = (vnode, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    let el;
    let vnodeHook;
    const { props, shapeFlag, transition, dirs } = vnode;
    el = vnode.el = hostCreateElement(
      vnode.type,
      namespace,
      props && props.is,
      props
    );
    if (shapeFlag & 8) {
      hostSetElementText(el, vnode.children);
    } else if (shapeFlag & 16) {
      mountChildren(
        vnode.children,
        el,
        null,
        parentComponent,
        parentSuspense,
        resolveChildrenNamespace(vnode, namespace),
        slotScopeIds,
        optimized
      );
    }
    if (dirs) {
      invokeDirectiveHook(vnode, null, parentComponent, "created");
    }
    setScopeId(el, vnode, vnode.scopeId, slotScopeIds, parentComponent);
    if (props) {
      for (const key in props) {
        if (key !== "value" && !shared_esm_bundler_isReservedProp(key)) {
          hostPatchProp(el, key, null, props[key], namespace, parentComponent);
        }
      }
      if ("value" in props) {
        hostPatchProp(el, "value", null, props.value, namespace);
      }
      if (vnodeHook = props.onVnodeBeforeMount) {
        invokeVNodeHook(vnodeHook, parentComponent, vnode);
      }
    }
    if (false) {}
    if (dirs) {
      invokeDirectiveHook(vnode, null, parentComponent, "beforeMount");
    }
    const needCallTransitionHooks = needTransition(parentSuspense, transition);
    if (needCallTransitionHooks) {
      transition.beforeEnter(el);
    }
    hostInsert(el, container, anchor);
    if ((vnodeHook = props && props.onVnodeMounted) || needCallTransitionHooks || dirs) {
      queuePostRenderEffect(() => {
        vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
        needCallTransitionHooks && transition.enter(el);
        dirs && invokeDirectiveHook(vnode, null, parentComponent, "mounted");
      }, parentSuspense);
    }
  };
  const setScopeId = (el, vnode, scopeId, slotScopeIds, parentComponent) => {
    if (scopeId) {
      hostSetScopeId(el, scopeId);
    }
    if (slotScopeIds) {
      for (let i = 0; i < slotScopeIds.length; i++) {
        hostSetScopeId(el, slotScopeIds[i]);
      }
    }
    if (parentComponent) {
      let subTree = parentComponent.subTree;
      if (false) {}
      if (vnode === subTree || isSuspense(subTree.type) && (subTree.ssContent === vnode || subTree.ssFallback === vnode)) {
        const parentVNode = parentComponent.vnode;
        setScopeId(
          el,
          parentVNode,
          parentVNode.scopeId,
          parentVNode.slotScopeIds,
          parentComponent.parent
        );
      }
    }
  };
  const mountChildren = (children, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, start = 0) => {
    for (let i = start; i < children.length; i++) {
      const child = children[i] = optimized ? cloneIfMounted(children[i]) : normalizeVNode(children[i]);
      patch(
        null,
        child,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized
      );
    }
  };
  const patchElement = (n1, n2, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    const el = n2.el = n1.el;
    if (false) {}
    let { patchFlag, dynamicChildren, dirs } = n2;
    patchFlag |= n1.patchFlag & 16;
    const oldProps = n1.props || shared_esm_bundler_EMPTY_OBJ;
    const newProps = n2.props || shared_esm_bundler_EMPTY_OBJ;
    let vnodeHook;
    parentComponent && toggleRecurse(parentComponent, false);
    if (vnodeHook = newProps.onVnodeBeforeUpdate) {
      invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
    }
    if (dirs) {
      invokeDirectiveHook(n2, n1, parentComponent, "beforeUpdate");
    }
    parentComponent && toggleRecurse(parentComponent, true);
    if (false) {}
    if (oldProps.innerHTML && newProps.innerHTML == null || oldProps.textContent && newProps.textContent == null) {
      hostSetElementText(el, "");
    }
    if (dynamicChildren) {
      patchBlockChildren(
        n1.dynamicChildren,
        dynamicChildren,
        el,
        parentComponent,
        parentSuspense,
        resolveChildrenNamespace(n2, namespace),
        slotScopeIds
      );
      if (false) {}
    } else if (!optimized) {
      patchChildren(
        n1,
        n2,
        el,
        null,
        parentComponent,
        parentSuspense,
        resolveChildrenNamespace(n2, namespace),
        slotScopeIds,
        false
      );
    }
    if (patchFlag > 0) {
      if (patchFlag & 16) {
        patchProps(el, oldProps, newProps, parentComponent, namespace);
      } else {
        if (patchFlag & 2) {
          if (oldProps.class !== newProps.class) {
            hostPatchProp(el, "class", null, newProps.class, namespace);
          }
        }
        if (patchFlag & 4) {
          hostPatchProp(el, "style", oldProps.style, newProps.style, namespace);
        }
        if (patchFlag & 8) {
          const propsToUpdate = n2.dynamicProps;
          for (let i = 0; i < propsToUpdate.length; i++) {
            const key = propsToUpdate[i];
            const prev = oldProps[key];
            const next = newProps[key];
            if (next !== prev || key === "value") {
              hostPatchProp(el, key, prev, next, namespace, parentComponent);
            }
          }
        }
      }
      if (patchFlag & 1) {
        if (n1.children !== n2.children) {
          hostSetElementText(el, n2.children);
        }
      }
    } else if (!optimized && dynamicChildren == null) {
      patchProps(el, oldProps, newProps, parentComponent, namespace);
    }
    if ((vnodeHook = newProps.onVnodeUpdated) || dirs) {
      queuePostRenderEffect(() => {
        vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
        dirs && invokeDirectiveHook(n2, n1, parentComponent, "updated");
      }, parentSuspense);
    }
  };
  const patchBlockChildren = (oldChildren, newChildren, fallbackContainer, parentComponent, parentSuspense, namespace, slotScopeIds) => {
    for (let i = 0; i < newChildren.length; i++) {
      const oldVNode = oldChildren[i];
      const newVNode = newChildren[i];
      const container = (
        // oldVNode may be an errored async setup() component inside Suspense
        // which will not have a mounted element
        oldVNode.el && // - In the case of a Fragment, we need to provide the actual parent
        // of the Fragment itself so it can move its children.
        (oldVNode.type === runtime_core_esm_bundler_Fragment || // - In the case of different nodes, there is going to be a replacement
        // which also requires the correct parent container
        !isSameVNodeType(oldVNode, newVNode) || // - In the case of a component, it could contain anything.
        oldVNode.shapeFlag & (6 | 64 | 128)) ? hostParentNode(oldVNode.el) : (
          // In other cases, the parent container is not actually used so we
          // just pass the block element here to avoid a DOM parentNode call.
          fallbackContainer
        )
      );
      patch(
        oldVNode,
        newVNode,
        container,
        null,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        true
      );
    }
  };
  const patchProps = (el, oldProps, newProps, parentComponent, namespace) => {
    if (oldProps !== newProps) {
      if (oldProps !== shared_esm_bundler_EMPTY_OBJ) {
        for (const key in oldProps) {
          if (!shared_esm_bundler_isReservedProp(key) && !(key in newProps)) {
            hostPatchProp(
              el,
              key,
              oldProps[key],
              null,
              namespace,
              parentComponent
            );
          }
        }
      }
      for (const key in newProps) {
        if (shared_esm_bundler_isReservedProp(key)) continue;
        const next = newProps[key];
        const prev = oldProps[key];
        if (next !== prev && key !== "value") {
          hostPatchProp(el, key, prev, next, namespace, parentComponent);
        }
      }
      if ("value" in newProps) {
        hostPatchProp(el, "value", oldProps.value, newProps.value, namespace);
      }
    }
  };
  const processFragment = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    const fragmentStartAnchor = n2.el = n1 ? n1.el : hostCreateText("");
    const fragmentEndAnchor = n2.anchor = n1 ? n1.anchor : hostCreateText("");
    let { patchFlag, dynamicChildren, slotScopeIds: fragmentSlotScopeIds } = n2;
    if (false) {}
    if (fragmentSlotScopeIds) {
      slotScopeIds = slotScopeIds ? slotScopeIds.concat(fragmentSlotScopeIds) : fragmentSlotScopeIds;
    }
    if (n1 == null) {
      hostInsert(fragmentStartAnchor, container, anchor);
      hostInsert(fragmentEndAnchor, container, anchor);
      mountChildren(
        // #10007
        // such fragment like `<></>` will be compiled into
        // a fragment which doesn't have a children.
        // In this case fallback to an empty array
        n2.children || [],
        container,
        fragmentEndAnchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized
      );
    } else {
      if (patchFlag > 0 && patchFlag & 64 && dynamicChildren && // #2715 the previous fragment could've been a BAILed one as a result
      // of renderSlot() with no valid children
      n1.dynamicChildren) {
        patchBlockChildren(
          n1.dynamicChildren,
          dynamicChildren,
          container,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds
        );
        if (false) {} else if (
          // #2080 if the stable fragment has a key, it's a <template v-for> that may
          //  get moved around. Make sure all root level vnodes inherit el.
          // #2134 or if it's a component root, it may also get moved around
          // as the component is being moved.
          n2.key != null || parentComponent && n2 === parentComponent.subTree
        ) {
          traverseStaticChildren(
            n1,
            n2,
            true
            /* shallow */
          );
        }
      } else {
        patchChildren(
          n1,
          n2,
          container,
          fragmentEndAnchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      }
    }
  };
  const processComponent = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    n2.slotScopeIds = slotScopeIds;
    if (n1 == null) {
      if (n2.shapeFlag & 512) {
        parentComponent.ctx.activate(
          n2,
          container,
          anchor,
          namespace,
          optimized
        );
      } else {
        mountComponent(
          n2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          optimized
        );
      }
    } else {
      updateComponent(n1, n2, optimized);
    }
  };
  const mountComponent = (initialVNode, container, anchor, parentComponent, parentSuspense, namespace, optimized) => {
    const instance = (initialVNode.component = createComponentInstance(
      initialVNode,
      parentComponent,
      parentSuspense
    ));
    if (false) {}
    if (false) {}
    if (isKeepAlive(initialVNode)) {
      instance.ctx.renderer = internals;
    }
    {
      if (false) {}
      setupComponent(instance, false, optimized);
      if (false) {}
    }
    if (false) {}
    if (instance.asyncDep) {
      parentSuspense && parentSuspense.registerDep(instance, setupRenderEffect, optimized);
      if (!initialVNode.el) {
        const placeholder = instance.subTree = createVNode(Comment);
        processCommentNode(null, placeholder, container, anchor);
        initialVNode.placeholder = placeholder.el;
      }
    } else {
      setupRenderEffect(
        instance,
        initialVNode,
        container,
        anchor,
        parentSuspense,
        namespace,
        optimized
      );
    }
    if (false) {}
  };
  const updateComponent = (n1, n2, optimized) => {
    const instance = n2.component = n1.component;
    if (shouldUpdateComponent(n1, n2, optimized)) {
      if (instance.asyncDep && !instance.asyncResolved) {
        if (false) {}
        updateComponentPreRender(instance, n2, optimized);
        if (false) {}
        return;
      } else {
        instance.next = n2;
        instance.update();
      }
    } else {
      n2.el = n1.el;
      instance.vnode = n2;
    }
  };
  const setupRenderEffect = (instance, initialVNode, container, anchor, parentSuspense, namespace, optimized) => {
    const componentUpdateFn = () => {
      if (!instance.isMounted) {
        let vnodeHook;
        const { el, props } = initialVNode;
        const { bm, m, parent, root, type } = instance;
        const isAsyncWrapperVNode = isAsyncWrapper(initialVNode);
        toggleRecurse(instance, false);
        if (bm) {
          invokeArrayFns(bm);
        }
        if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeBeforeMount)) {
          invokeVNodeHook(vnodeHook, parent, initialVNode);
        }
        toggleRecurse(instance, true);
        if (el && hydrateNode) {
          const hydrateSubTree = () => {
            if (false) {}
            instance.subTree = renderComponentRoot(instance);
            if (false) {}
            if (false) {}
            hydrateNode(
              el,
              instance.subTree,
              instance,
              parentSuspense,
              null
            );
            if (false) {}
          };
          if (isAsyncWrapperVNode && type.__asyncHydrate) {
            type.__asyncHydrate(
              el,
              instance,
              hydrateSubTree
            );
          } else {
            hydrateSubTree();
          }
        } else {
          if (root.ce && // @ts-expect-error _def is private
          root.ce._def.shadowRoot !== false) {
            root.ce._injectChildStyle(type);
          }
          if (false) {}
          const subTree = instance.subTree = renderComponentRoot(instance);
          if (false) {}
          if (false) {}
          patch(
            null,
            subTree,
            container,
            anchor,
            instance,
            parentSuspense,
            namespace
          );
          if (false) {}
          initialVNode.el = subTree.el;
        }
        if (m) {
          queuePostRenderEffect(m, parentSuspense);
        }
        if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeMounted)) {
          const scopedInitialVNode = initialVNode;
          queuePostRenderEffect(
            () => invokeVNodeHook(vnodeHook, parent, scopedInitialVNode),
            parentSuspense
          );
        }
        if (initialVNode.shapeFlag & 256 || parent && isAsyncWrapper(parent.vnode) && parent.vnode.shapeFlag & 256) {
          instance.a && queuePostRenderEffect(instance.a, parentSuspense);
        }
        instance.isMounted = true;
        if (false) {}
        initialVNode = container = anchor = null;
      } else {
        let { next, bu, u, parent, vnode } = instance;
        {
          const nonHydratedAsyncRoot = locateNonHydratedAsyncRoot(instance);
          if (nonHydratedAsyncRoot) {
            if (next) {
              next.el = vnode.el;
              updateComponentPreRender(instance, next, optimized);
            }
            nonHydratedAsyncRoot.asyncDep.then(() => {
              if (!instance.isUnmounted) {
                componentUpdateFn();
              }
            });
            return;
          }
        }
        let originNext = next;
        let vnodeHook;
        if (false) {}
        toggleRecurse(instance, false);
        if (next) {
          next.el = vnode.el;
          updateComponentPreRender(instance, next, optimized);
        } else {
          next = vnode;
        }
        if (bu) {
          invokeArrayFns(bu);
        }
        if (vnodeHook = next.props && next.props.onVnodeBeforeUpdate) {
          invokeVNodeHook(vnodeHook, parent, next, vnode);
        }
        toggleRecurse(instance, true);
        if (false) {}
        const nextTree = renderComponentRoot(instance);
        if (false) {}
        const prevTree = instance.subTree;
        instance.subTree = nextTree;
        if (false) {}
        patch(
          prevTree,
          nextTree,
          // parent may have changed if it's in a teleport
          hostParentNode(prevTree.el),
          // anchor may have changed if it's in a fragment
          getNextHostNode(prevTree),
          instance,
          parentSuspense,
          namespace
        );
        if (false) {}
        next.el = nextTree.el;
        if (originNext === null) {
          updateHOCHostEl(instance, nextTree.el);
        }
        if (u) {
          queuePostRenderEffect(u, parentSuspense);
        }
        if (vnodeHook = next.props && next.props.onVnodeUpdated) {
          queuePostRenderEffect(
            () => invokeVNodeHook(vnodeHook, parent, next, vnode),
            parentSuspense
          );
        }
        if (false) {}
        if (false) {}
      }
    };
    instance.scope.on();
    const effect = instance.effect = new ReactiveEffect(componentUpdateFn);
    instance.scope.off();
    const update = instance.update = effect.run.bind(effect);
    const job = instance.job = effect.runIfDirty.bind(effect);
    job.i = instance;
    job.id = instance.uid;
    effect.scheduler = () => queueJob(job);
    toggleRecurse(instance, true);
    if (false) {}
    update();
  };
  const updateComponentPreRender = (instance, nextVNode, optimized) => {
    nextVNode.component = instance;
    const prevProps = instance.vnode.props;
    instance.vnode = nextVNode;
    instance.next = null;
    updateProps(instance, nextVNode.props, prevProps, optimized);
    updateSlots(instance, nextVNode.children, optimized);
    reactivity_esm_bundler_pauseTracking();
    flushPreFlushCbs(instance);
    reactivity_esm_bundler_resetTracking();
  };
  const patchChildren = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized = false) => {
    const c1 = n1 && n1.children;
    const prevShapeFlag = n1 ? n1.shapeFlag : 0;
    const c2 = n2.children;
    const { patchFlag, shapeFlag } = n2;
    if (patchFlag > 0) {
      if (patchFlag & 128) {
        patchKeyedChildren(
          c1,
          c2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
        return;
      } else if (patchFlag & 256) {
        patchUnkeyedChildren(
          c1,
          c2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
        return;
      }
    }
    if (shapeFlag & 8) {
      if (prevShapeFlag & 16) {
        unmountChildren(c1, parentComponent, parentSuspense);
      }
      if (c2 !== c1) {
        hostSetElementText(container, c2);
      }
    } else {
      if (prevShapeFlag & 16) {
        if (shapeFlag & 16) {
          patchKeyedChildren(
            c1,
            c2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else {
          unmountChildren(c1, parentComponent, parentSuspense, true);
        }
      } else {
        if (prevShapeFlag & 8) {
          hostSetElementText(container, "");
        }
        if (shapeFlag & 16) {
          mountChildren(
            c2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        }
      }
    }
  };
  const patchUnkeyedChildren = (c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    c1 = c1 || EMPTY_ARR;
    c2 = c2 || EMPTY_ARR;
    const oldLength = c1.length;
    const newLength = c2.length;
    const commonLength = Math.min(oldLength, newLength);
    let i;
    for (i = 0; i < commonLength; i++) {
      const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
      patch(
        c1[i],
        nextChild,
        container,
        null,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized
      );
    }
    if (oldLength > newLength) {
      unmountChildren(
        c1,
        parentComponent,
        parentSuspense,
        true,
        false,
        commonLength
      );
    } else {
      mountChildren(
        c2,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized,
        commonLength
      );
    }
  };
  const patchKeyedChildren = (c1, c2, container, parentAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    let i = 0;
    const l2 = c2.length;
    let e1 = c1.length - 1;
    let e2 = l2 - 1;
    while (i <= e1 && i <= e2) {
      const n1 = c1[i];
      const n2 = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
      if (isSameVNodeType(n1, n2)) {
        patch(
          n1,
          n2,
          container,
          null,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      } else {
        break;
      }
      i++;
    }
    while (i <= e1 && i <= e2) {
      const n1 = c1[e1];
      const n2 = c2[e2] = optimized ? cloneIfMounted(c2[e2]) : normalizeVNode(c2[e2]);
      if (isSameVNodeType(n1, n2)) {
        patch(
          n1,
          n2,
          container,
          null,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      } else {
        break;
      }
      e1--;
      e2--;
    }
    if (i > e1) {
      if (i <= e2) {
        const nextPos = e2 + 1;
        const anchor = nextPos < l2 ? c2[nextPos].el : parentAnchor;
        while (i <= e2) {
          patch(
            null,
            c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]),
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
          i++;
        }
      }
    } else if (i > e2) {
      while (i <= e1) {
        unmount(c1[i], parentComponent, parentSuspense, true);
        i++;
      }
    } else {
      const s1 = i;
      const s2 = i;
      const keyToNewIndexMap = /* @__PURE__ */ new Map();
      for (i = s2; i <= e2; i++) {
        const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
        if (nextChild.key != null) {
          if (false) {}
          keyToNewIndexMap.set(nextChild.key, i);
        }
      }
      let j;
      let patched = 0;
      const toBePatched = e2 - s2 + 1;
      let moved = false;
      let maxNewIndexSoFar = 0;
      const newIndexToOldIndexMap = new Array(toBePatched);
      for (i = 0; i < toBePatched; i++) newIndexToOldIndexMap[i] = 0;
      for (i = s1; i <= e1; i++) {
        const prevChild = c1[i];
        if (patched >= toBePatched) {
          unmount(prevChild, parentComponent, parentSuspense, true);
          continue;
        }
        let newIndex;
        if (prevChild.key != null) {
          newIndex = keyToNewIndexMap.get(prevChild.key);
        } else {
          for (j = s2; j <= e2; j++) {
            if (newIndexToOldIndexMap[j - s2] === 0 && isSameVNodeType(prevChild, c2[j])) {
              newIndex = j;
              break;
            }
          }
        }
        if (newIndex === void 0) {
          unmount(prevChild, parentComponent, parentSuspense, true);
        } else {
          newIndexToOldIndexMap[newIndex - s2] = i + 1;
          if (newIndex >= maxNewIndexSoFar) {
            maxNewIndexSoFar = newIndex;
          } else {
            moved = true;
          }
          patch(
            prevChild,
            c2[newIndex],
            container,
            null,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
          patched++;
        }
      }
      const increasingNewIndexSequence = moved ? getSequence(newIndexToOldIndexMap) : EMPTY_ARR;
      j = increasingNewIndexSequence.length - 1;
      for (i = toBePatched - 1; i >= 0; i--) {
        const nextIndex = s2 + i;
        const nextChild = c2[nextIndex];
        const anchorVNode = c2[nextIndex + 1];
        const anchor = nextIndex + 1 < l2 ? (
          // #13559, fallback to el placeholder for unresolved async component
          anchorVNode.el || anchorVNode.placeholder
        ) : parentAnchor;
        if (newIndexToOldIndexMap[i] === 0) {
          patch(
            null,
            nextChild,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else if (moved) {
          if (j < 0 || i !== increasingNewIndexSequence[j]) {
            move(nextChild, container, anchor, 2);
          } else {
            j--;
          }
        }
      }
    }
  };
  const move = (vnode, container, anchor, moveType, parentSuspense = null) => {
    const { el, type, transition, children, shapeFlag } = vnode;
    if (shapeFlag & 6) {
      move(vnode.component.subTree, container, anchor, moveType);
      return;
    }
    if (shapeFlag & 128) {
      vnode.suspense.move(container, anchor, moveType);
      return;
    }
    if (shapeFlag & 64) {
      type.move(vnode, container, anchor, internals);
      return;
    }
    if (type === runtime_core_esm_bundler_Fragment) {
      hostInsert(el, container, anchor);
      for (let i = 0; i < children.length; i++) {
        move(children[i], container, anchor, moveType);
      }
      hostInsert(vnode.anchor, container, anchor);
      return;
    }
    if (type === runtime_core_esm_bundler_Static) {
      moveStaticNode(vnode, container, anchor);
      return;
    }
    const needTransition2 = moveType !== 2 && shapeFlag & 1 && transition;
    if (needTransition2) {
      if (moveType === 0) {
        transition.beforeEnter(el);
        hostInsert(el, container, anchor);
        queuePostRenderEffect(() => transition.enter(el), parentSuspense);
      } else {
        const { leave, delayLeave, afterLeave } = transition;
        const remove2 = () => {
          if (vnode.ctx.isUnmounted) {
            hostRemove(el);
          } else {
            hostInsert(el, container, anchor);
          }
        };
        const performLeave = () => {
          if (el._isLeaving) {
            el[leaveCbKey](
              true
              /* cancelled */
            );
          }
          leave(el, () => {
            remove2();
            afterLeave && afterLeave();
          });
        };
        if (delayLeave) {
          delayLeave(el, remove2, performLeave);
        } else {
          performLeave();
        }
      }
    } else {
      hostInsert(el, container, anchor);
    }
  };
  const unmount = (vnode, parentComponent, parentSuspense, doRemove = false, optimized = false) => {
    const {
      type,
      props,
      ref,
      children,
      dynamicChildren,
      shapeFlag,
      patchFlag,
      dirs,
      cacheIndex
    } = vnode;
    if (patchFlag === -2) {
      optimized = false;
    }
    if (ref != null) {
      reactivity_esm_bundler_pauseTracking();
      setRef(ref, null, parentSuspense, vnode, true);
      reactivity_esm_bundler_resetTracking();
    }
    if (cacheIndex != null) {
      parentComponent.renderCache[cacheIndex] = void 0;
    }
    if (shapeFlag & 256) {
      parentComponent.ctx.deactivate(vnode);
      return;
    }
    const shouldInvokeDirs = shapeFlag & 1 && dirs;
    const shouldInvokeVnodeHook = !isAsyncWrapper(vnode);
    let vnodeHook;
    if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeBeforeUnmount)) {
      invokeVNodeHook(vnodeHook, parentComponent, vnode);
    }
    if (shapeFlag & 6) {
      unmountComponent(vnode.component, parentSuspense, doRemove);
    } else {
      if (shapeFlag & 128) {
        vnode.suspense.unmount(parentSuspense, doRemove);
        return;
      }
      if (shouldInvokeDirs) {
        invokeDirectiveHook(vnode, null, parentComponent, "beforeUnmount");
      }
      if (shapeFlag & 64) {
        vnode.type.remove(
          vnode,
          parentComponent,
          parentSuspense,
          internals,
          doRemove
        );
      } else if (dynamicChildren && // #5154
      // when v-once is used inside a block, setBlockTracking(-1) marks the
      // parent block with hasOnce: true
      // so that it doesn't take the fast path during unmount - otherwise
      // components nested in v-once are never unmounted.
      !dynamicChildren.hasOnce && // #1153: fast path should not be taken for non-stable (v-for) fragments
      (type !== runtime_core_esm_bundler_Fragment || patchFlag > 0 && patchFlag & 64)) {
        unmountChildren(
          dynamicChildren,
          parentComponent,
          parentSuspense,
          false,
          true
        );
      } else if (type === runtime_core_esm_bundler_Fragment && patchFlag & (128 | 256) || !optimized && shapeFlag & 16) {
        unmountChildren(children, parentComponent, parentSuspense);
      }
      if (doRemove) {
        remove(vnode);
      }
    }
    if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeUnmounted) || shouldInvokeDirs) {
      queuePostRenderEffect(() => {
        vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
        shouldInvokeDirs && invokeDirectiveHook(vnode, null, parentComponent, "unmounted");
      }, parentSuspense);
    }
  };
  const remove = (vnode) => {
    const { type, el, anchor, transition } = vnode;
    if (type === runtime_core_esm_bundler_Fragment) {
      if (false) {} else {
        removeFragment(el, anchor);
      }
      return;
    }
    if (type === runtime_core_esm_bundler_Static) {
      removeStaticNode(vnode);
      return;
    }
    const performRemove = () => {
      hostRemove(el);
      if (transition && !transition.persisted && transition.afterLeave) {
        transition.afterLeave();
      }
    };
    if (vnode.shapeFlag & 1 && transition && !transition.persisted) {
      const { leave, delayLeave } = transition;
      const performLeave = () => leave(el, performRemove);
      if (delayLeave) {
        delayLeave(vnode.el, performRemove, performLeave);
      } else {
        performLeave();
      }
    } else {
      performRemove();
    }
  };
  const removeFragment = (cur, end) => {
    let next;
    while (cur !== end) {
      next = hostNextSibling(cur);
      hostRemove(cur);
      cur = next;
    }
    hostRemove(end);
  };
  const unmountComponent = (instance, parentSuspense, doRemove) => {
    if (false) {}
    const { bum, scope, job, subTree, um, m, a } = instance;
    invalidateMount(m);
    invalidateMount(a);
    if (bum) {
      invokeArrayFns(bum);
    }
    scope.stop();
    if (job) {
      job.flags |= 8;
      unmount(subTree, instance, parentSuspense, doRemove);
    }
    if (um) {
      queuePostRenderEffect(um, parentSuspense);
    }
    queuePostRenderEffect(() => {
      instance.isUnmounted = true;
    }, parentSuspense);
    if (false) {}
  };
  const unmountChildren = (children, parentComponent, parentSuspense, doRemove = false, optimized = false, start = 0) => {
    for (let i = start; i < children.length; i++) {
      unmount(children[i], parentComponent, parentSuspense, doRemove, optimized);
    }
  };
  const getNextHostNode = (vnode) => {
    if (vnode.shapeFlag & 6) {
      return getNextHostNode(vnode.component.subTree);
    }
    if (vnode.shapeFlag & 128) {
      return vnode.suspense.next();
    }
    const el = hostNextSibling(vnode.anchor || vnode.el);
    const teleportEnd = el && el[TeleportEndKey];
    return teleportEnd ? hostNextSibling(teleportEnd) : el;
  };
  let isFlushing = false;
  const render = (vnode, container, namespace) => {
    if (vnode == null) {
      if (container._vnode) {
        unmount(container._vnode, null, null, true);
      }
    } else {
      patch(
        container._vnode || null,
        vnode,
        container,
        null,
        null,
        null,
        namespace
      );
    }
    container._vnode = vnode;
    if (!isFlushing) {
      isFlushing = true;
      flushPreFlushCbs();
      flushPostFlushCbs();
      isFlushing = false;
    }
  };
  const internals = {
    p: patch,
    um: unmount,
    m: move,
    r: remove,
    mt: mountComponent,
    mc: mountChildren,
    pc: patchChildren,
    pbc: patchBlockChildren,
    n: getNextHostNode,
    o: options
  };
  let hydrate;
  let hydrateNode;
  if (createHydrationFns) {
    [hydrate, hydrateNode] = createHydrationFns(
      internals
    );
  }
  return {
    render,
    hydrate,
    createApp: createAppAPI(render, hydrate)
  };
}
function resolveChildrenNamespace({ type, props }, currentNamespace) {
  return currentNamespace === "svg" && type === "foreignObject" || currentNamespace === "mathml" && type === "annotation-xml" && props && props.encoding && props.encoding.includes("html") ? void 0 : currentNamespace;
}
function toggleRecurse({ effect, job }, allowed) {
  if (allowed) {
    effect.flags |= 32;
    job.flags |= 4;
  } else {
    effect.flags &= -33;
    job.flags &= -5;
  }
}
function needTransition(parentSuspense, transition) {
  return (!parentSuspense || parentSuspense && !parentSuspense.pendingBranch) && transition && !transition.persisted;
}
function traverseStaticChildren(n1, n2, shallow = false) {
  const ch1 = n1.children;
  const ch2 = n2.children;
  if (shared_esm_bundler_isArray(ch1) && shared_esm_bundler_isArray(ch2)) {
    for (let i = 0; i < ch1.length; i++) {
      const c1 = ch1[i];
      let c2 = ch2[i];
      if (c2.shapeFlag & 1 && !c2.dynamicChildren) {
        if (c2.patchFlag <= 0 || c2.patchFlag === 32) {
          c2 = ch2[i] = cloneIfMounted(ch2[i]);
          c2.el = c1.el;
        }
        if (!shallow && c2.patchFlag !== -2)
          traverseStaticChildren(c1, c2);
      }
      if (c2.type === Text && // avoid cached text nodes retaining detached dom nodes
      c2.patchFlag !== -1) {
        c2.el = c1.el;
      }
      if (c2.type === Comment && !c2.el) {
        c2.el = c1.el;
      }
      if (false) {}
    }
  }
}
function getSequence(arr) {
  const p = arr.slice();
  const result = [0];
  let i, j, u, v, c;
  const len = arr.length;
  for (i = 0; i < len; i++) {
    const arrI = arr[i];
    if (arrI !== 0) {
      j = result[result.length - 1];
      if (arr[j] < arrI) {
        p[i] = j;
        result.push(i);
        continue;
      }
      u = 0;
      v = result.length - 1;
      while (u < v) {
        c = u + v >> 1;
        if (arr[result[c]] < arrI) {
          u = c + 1;
        } else {
          v = c;
        }
      }
      if (arrI < arr[result[u]]) {
        if (u > 0) {
          p[i] = result[u - 1];
        }
        result[u] = i;
      }
    }
  }
  u = result.length;
  v = result[u - 1];
  while (u-- > 0) {
    result[u] = v;
    v = p[v];
  }
  return result;
}
function locateNonHydratedAsyncRoot(instance) {
  const subComponent = instance.subTree.component;
  if (subComponent) {
    if (subComponent.asyncDep && !subComponent.asyncResolved) {
      return subComponent;
    } else {
      return locateNonHydratedAsyncRoot(subComponent);
    }
  }
}
function invalidateMount(hooks) {
  if (hooks) {
    for (let i = 0; i < hooks.length; i++)
      hooks[i].flags |= 8;
  }
}

const ssrContextKey = Symbol.for("v-scx");
const useSSRContext = () => {
  {
    const ctx = runtime_core_esm_bundler_inject(ssrContextKey);
    if (!ctx) {
       false && 0;
    }
    return ctx;
  }
};

function watchEffect(effect, options) {
  return doWatch(effect, null, options);
}
function watchPostEffect(effect, options) {
  return doWatch(
    effect,
    null,
     false ? 0 : { flush: "post" }
  );
}
function watchSyncEffect(effect, options) {
  return doWatch(
    effect,
    null,
     false ? 0 : { flush: "sync" }
  );
}
function runtime_core_esm_bundler_watch(source, cb, options) {
  if (false) {}
  return doWatch(source, cb, options);
}
function doWatch(source, cb, options = shared_esm_bundler_EMPTY_OBJ) {
  const { immediate, deep, flush, once } = options;
  if (false) {}
  const baseWatchOptions = shared_esm_bundler_extend({}, options);
  if (false) {}
  const runsImmediately = cb && immediate || !cb && flush !== "post";
  let ssrCleanup;
  if (isInSSRComponentSetup) {
    if (flush === "sync") {
      const ctx = useSSRContext();
      ssrCleanup = ctx.__watcherHandles || (ctx.__watcherHandles = []);
    } else if (!runsImmediately) {
      const watchStopHandle = () => {
      };
      watchStopHandle.stop = shared_esm_bundler_NOOP;
      watchStopHandle.resume = shared_esm_bundler_NOOP;
      watchStopHandle.pause = shared_esm_bundler_NOOP;
      return watchStopHandle;
    }
  }
  const instance = currentInstance;
  baseWatchOptions.call = (fn, type, args) => callWithAsyncErrorHandling(fn, instance, type, args);
  let isPre = false;
  if (flush === "post") {
    baseWatchOptions.scheduler = (job) => {
      queuePostRenderEffect(job, instance && instance.suspense);
    };
  } else if (flush !== "sync") {
    isPre = true;
    baseWatchOptions.scheduler = (job, isFirstRun) => {
      if (isFirstRun) {
        job();
      } else {
        queueJob(job);
      }
    };
  }
  baseWatchOptions.augmentJob = (job) => {
    if (cb) {
      job.flags |= 4;
    }
    if (isPre) {
      job.flags |= 2;
      if (instance) {
        job.id = instance.uid;
        job.i = instance;
      }
    }
  };
  const watchHandle = reactivity_esm_bundler_watch(source, cb, baseWatchOptions);
  if (isInSSRComponentSetup) {
    if (ssrCleanup) {
      ssrCleanup.push(watchHandle);
    } else if (runsImmediately) {
      watchHandle();
    }
  }
  return watchHandle;
}
function instanceWatch(source, value, options) {
  const publicThis = this.proxy;
  const getter = shared_esm_bundler_isString(source) ? source.includes(".") ? createPathGetter(publicThis, source) : () => publicThis[source] : source.bind(publicThis, publicThis);
  let cb;
  if (shared_esm_bundler_isFunction(value)) {
    cb = value;
  } else {
    cb = value.handler;
    options = value;
  }
  const reset = setCurrentInstance(this);
  const res = doWatch(getter, cb.bind(publicThis), options);
  reset();
  return res;
}
function createPathGetter(ctx, path) {
  const segments = path.split(".");
  return () => {
    let cur = ctx;
    for (let i = 0; i < segments.length && cur; i++) {
      cur = cur[segments[i]];
    }
    return cur;
  };
}

function useModel(props, name, options = EMPTY_OBJ) {
  const i = runtime_core_esm_bundler_getCurrentInstance();
  if (false) {}
  const camelizedName = camelize(name);
  if (false) {}
  const hyphenatedName = hyphenate(name);
  const modifiers = getModelModifiers(props, camelizedName);
  const res = customRef((track, trigger) => {
    let localValue;
    let prevSetValue = EMPTY_OBJ;
    let prevEmittedValue;
    watchSyncEffect(() => {
      const propValue = props[camelizedName];
      if (hasChanged(localValue, propValue)) {
        localValue = propValue;
        trigger();
      }
    });
    return {
      get() {
        track();
        return options.get ? options.get(localValue) : localValue;
      },
      set(value) {
        const emittedValue = options.set ? options.set(value) : value;
        if (!hasChanged(emittedValue, localValue) && !(prevSetValue !== EMPTY_OBJ && hasChanged(value, prevSetValue))) {
          return;
        }
        const rawProps = i.vnode.props;
        if (!(rawProps && // check if parent has passed v-model
        (name in rawProps || camelizedName in rawProps || hyphenatedName in rawProps) && (`onUpdate:${name}` in rawProps || `onUpdate:${camelizedName}` in rawProps || `onUpdate:${hyphenatedName}` in rawProps))) {
          localValue = value;
          trigger();
        }
        i.emit(`update:${name}`, emittedValue);
        if (hasChanged(value, emittedValue) && hasChanged(value, prevSetValue) && !hasChanged(emittedValue, prevEmittedValue)) {
          trigger();
        }
        prevSetValue = value;
        prevEmittedValue = emittedValue;
      }
    };
  });
  res[Symbol.iterator] = () => {
    let i2 = 0;
    return {
      next() {
        if (i2 < 2) {
          return { value: i2++ ? modifiers || EMPTY_OBJ : res, done: false };
        } else {
          return { done: true };
        }
      }
    };
  };
  return res;
}
const getModelModifiers = (props, modelName) => {
  return modelName === "modelValue" || modelName === "model-value" ? props.modelModifiers : props[`${modelName}Modifiers`] || props[`${shared_esm_bundler_camelize(modelName)}Modifiers`] || props[`${shared_esm_bundler_hyphenate(modelName)}Modifiers`];
};

function emit(instance, event, ...rawArgs) {
  if (instance.isUnmounted) return;
  const props = instance.vnode.props || shared_esm_bundler_EMPTY_OBJ;
  if (false) {}
  let args = rawArgs;
  const isModelListener = event.startsWith("update:");
  const modifiers = isModelListener && getModelModifiers(props, event.slice(7));
  if (modifiers) {
    if (modifiers.trim) {
      args = rawArgs.map((a) => shared_esm_bundler_isString(a) ? a.trim() : a);
    }
    if (modifiers.number) {
      args = rawArgs.map(looseToNumber);
    }
  }
  if (false) {}
  if (false) {}
  let handlerName;
  let handler = props[handlerName = shared_esm_bundler_toHandlerKey(event)] || // also try camelCase event handler (#2249)
  props[handlerName = shared_esm_bundler_toHandlerKey(shared_esm_bundler_camelize(event))];
  if (!handler && isModelListener) {
    handler = props[handlerName = shared_esm_bundler_toHandlerKey(shared_esm_bundler_hyphenate(event))];
  }
  if (handler) {
    callWithAsyncErrorHandling(
      handler,
      instance,
      6,
      args
    );
  }
  const onceHandler = props[handlerName + `Once`];
  if (onceHandler) {
    if (!instance.emitted) {
      instance.emitted = {};
    } else if (instance.emitted[handlerName]) {
      return;
    }
    instance.emitted[handlerName] = true;
    callWithAsyncErrorHandling(
      onceHandler,
      instance,
      6,
      args
    );
  }
}
function normalizeEmitsOptions(comp, appContext, asMixin = false) {
  const cache = appContext.emitsCache;
  const cached = cache.get(comp);
  if (cached !== void 0) {
    return cached;
  }
  const raw = comp.emits;
  let normalized = {};
  let hasExtends = false;
  if ( true && !shared_esm_bundler_isFunction(comp)) {
    const extendEmits = (raw2) => {
      const normalizedFromExtend = normalizeEmitsOptions(raw2, appContext, true);
      if (normalizedFromExtend) {
        hasExtends = true;
        shared_esm_bundler_extend(normalized, normalizedFromExtend);
      }
    };
    if (!asMixin && appContext.mixins.length) {
      appContext.mixins.forEach(extendEmits);
    }
    if (comp.extends) {
      extendEmits(comp.extends);
    }
    if (comp.mixins) {
      comp.mixins.forEach(extendEmits);
    }
  }
  if (!raw && !hasExtends) {
    if (shared_esm_bundler_isObject(comp)) {
      cache.set(comp, null);
    }
    return null;
  }
  if (shared_esm_bundler_isArray(raw)) {
    raw.forEach((key) => normalized[key] = null);
  } else {
    shared_esm_bundler_extend(normalized, raw);
  }
  if (shared_esm_bundler_isObject(comp)) {
    cache.set(comp, normalized);
  }
  return normalized;
}
function isEmitListener(options, key) {
  if (!options || !shared_esm_bundler_isOn(key)) {
    return false;
  }
  key = key.slice(2).replace(/Once$/, "");
  return hasOwn(options, key[0].toLowerCase() + key.slice(1)) || hasOwn(options, shared_esm_bundler_hyphenate(key)) || hasOwn(options, key);
}

let accessedAttrs = false;
function markAttrsAccessed() {
  accessedAttrs = true;
}
function renderComponentRoot(instance) {
  const {
    type: Component,
    vnode,
    proxy,
    withProxy,
    propsOptions: [propsOptions],
    slots,
    attrs,
    emit,
    render,
    renderCache,
    props,
    data,
    setupState,
    ctx,
    inheritAttrs
  } = instance;
  const prev = setCurrentRenderingInstance(instance);
  let result;
  let fallthroughAttrs;
  if (false) {}
  try {
    if (vnode.shapeFlag & 4) {
      const proxyToUse = withProxy || proxy;
      const thisProxy =  false ? 0 : proxyToUse;
      result = normalizeVNode(
        render.call(
          thisProxy,
          proxyToUse,
          renderCache,
           false ? 0 : props,
          setupState,
          data,
          ctx
        )
      );
      fallthroughAttrs = attrs;
    } else {
      const render2 = Component;
      if (false) {}
      result = normalizeVNode(
        render2.length > 1 ? render2(
           false ? 0 : props,
           false ? 0 : { attrs, slots, emit }
        ) : render2(
           false ? 0 : props,
          null
        )
      );
      fallthroughAttrs = Component.props ? attrs : getFunctionalFallthrough(attrs);
    }
  } catch (err) {
    blockStack.length = 0;
    handleError(err, instance, 1);
    result = createVNode(Comment);
  }
  let root = result;
  let setRoot = void 0;
  if (false) {}
  if (fallthroughAttrs && inheritAttrs !== false) {
    const keys = Object.keys(fallthroughAttrs);
    const { shapeFlag } = root;
    if (keys.length) {
      if (shapeFlag & (1 | 6)) {
        if (propsOptions && keys.some(isModelListener)) {
          fallthroughAttrs = filterModelListeners(
            fallthroughAttrs,
            propsOptions
          );
        }
        root = cloneVNode(root, fallthroughAttrs, false, true);
      } else if (false) {}
    }
  }
  if (vnode.dirs) {
    if (false) {}
    root = cloneVNode(root, null, false, true);
    root.dirs = root.dirs ? root.dirs.concat(vnode.dirs) : vnode.dirs;
  }
  if (vnode.transition) {
    if (false) {}
    setTransitionHooks(root, vnode.transition);
  }
  if (false) {} else {
    result = root;
  }
  setCurrentRenderingInstance(prev);
  return result;
}
const getChildRoot = (vnode) => {
  const rawChildren = vnode.children;
  const dynamicChildren = vnode.dynamicChildren;
  const childRoot = filterSingleRoot(rawChildren, false);
  if (!childRoot) {
    return [vnode, void 0];
  } else if (false) {}
  const index = rawChildren.indexOf(childRoot);
  const dynamicIndex = dynamicChildren ? dynamicChildren.indexOf(childRoot) : -1;
  const setRoot = (updatedRoot) => {
    rawChildren[index] = updatedRoot;
    if (dynamicChildren) {
      if (dynamicIndex > -1) {
        dynamicChildren[dynamicIndex] = updatedRoot;
      } else if (updatedRoot.patchFlag > 0) {
        vnode.dynamicChildren = [...dynamicChildren, updatedRoot];
      }
    }
  };
  return [normalizeVNode(childRoot), setRoot];
};
function filterSingleRoot(children, recurse = true) {
  let singleRoot;
  for (let i = 0; i < children.length; i++) {
    const child = children[i];
    if (isVNode(child)) {
      if (child.type !== Comment || child.children === "v-if") {
        if (singleRoot) {
          return;
        } else {
          singleRoot = child;
          if (false) {}
        }
      }
    } else {
      return;
    }
  }
  return singleRoot;
}
const getFunctionalFallthrough = (attrs) => {
  let res;
  for (const key in attrs) {
    if (key === "class" || key === "style" || shared_esm_bundler_isOn(key)) {
      (res || (res = {}))[key] = attrs[key];
    }
  }
  return res;
};
const filterModelListeners = (attrs, props) => {
  const res = {};
  for (const key in attrs) {
    if (!isModelListener(key) || !(key.slice(9) in props)) {
      res[key] = attrs[key];
    }
  }
  return res;
};
const isElementRoot = (vnode) => {
  return vnode.shapeFlag & (6 | 1) || vnode.type === Comment;
};
function shouldUpdateComponent(prevVNode, nextVNode, optimized) {
  const { props: prevProps, children: prevChildren, component } = prevVNode;
  const { props: nextProps, children: nextChildren, patchFlag } = nextVNode;
  const emits = component.emitsOptions;
  if (false) {}
  if (nextVNode.dirs || nextVNode.transition) {
    return true;
  }
  if (optimized && patchFlag >= 0) {
    if (patchFlag & 1024) {
      return true;
    }
    if (patchFlag & 16) {
      if (!prevProps) {
        return !!nextProps;
      }
      return hasPropsChanged(prevProps, nextProps, emits);
    } else if (patchFlag & 8) {
      const dynamicProps = nextVNode.dynamicProps;
      for (let i = 0; i < dynamicProps.length; i++) {
        const key = dynamicProps[i];
        if (nextProps[key] !== prevProps[key] && !isEmitListener(emits, key)) {
          return true;
        }
      }
    }
  } else {
    if (prevChildren || nextChildren) {
      if (!nextChildren || !nextChildren.$stable) {
        return true;
      }
    }
    if (prevProps === nextProps) {
      return false;
    }
    if (!prevProps) {
      return !!nextProps;
    }
    if (!nextProps) {
      return true;
    }
    return hasPropsChanged(prevProps, nextProps, emits);
  }
  return false;
}
function hasPropsChanged(prevProps, nextProps, emitsOptions) {
  const nextKeys = Object.keys(nextProps);
  if (nextKeys.length !== Object.keys(prevProps).length) {
    return true;
  }
  for (let i = 0; i < nextKeys.length; i++) {
    const key = nextKeys[i];
    if (nextProps[key] !== prevProps[key] && !isEmitListener(emitsOptions, key)) {
      return true;
    }
  }
  return false;
}
function updateHOCHostEl({ vnode, parent }, el) {
  while (parent) {
    const root = parent.subTree;
    if (root.suspense && root.suspense.activeBranch === vnode) {
      root.el = vnode.el;
    }
    if (root === vnode) {
      (vnode = parent.vnode).el = el;
      parent = parent.parent;
    } else {
      break;
    }
  }
}

const isSuspense = (type) => type.__isSuspense;
let suspenseId = 0;
const SuspenseImpl = {
  name: "Suspense",
  // In order to make Suspense tree-shakable, we need to avoid importing it
  // directly in the renderer. The renderer checks for the __isSuspense flag
  // on a vnode's type and calls the `process` method, passing in renderer
  // internals.
  __isSuspense: true,
  process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals) {
    if (n1 == null) {
      mountSuspense(
        n2,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized,
        rendererInternals
      );
    } else {
      if (parentSuspense && parentSuspense.deps > 0 && !n1.suspense.isInFallback) {
        n2.suspense = n1.suspense;
        n2.suspense.vnode = n2;
        n2.el = n1.el;
        return;
      }
      patchSuspense(
        n1,
        n2,
        container,
        anchor,
        parentComponent,
        namespace,
        slotScopeIds,
        optimized,
        rendererInternals
      );
    }
  },
  hydrate: hydrateSuspense,
  normalize: normalizeSuspenseChildren
};
const Suspense = (/* unused pure expression or super */ null && (SuspenseImpl)) ;
function triggerEvent(vnode, name) {
  const eventListener = vnode.props && vnode.props[name];
  if (shared_esm_bundler_isFunction(eventListener)) {
    eventListener();
  }
}
function mountSuspense(vnode, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals) {
  const {
    p: patch,
    o: { createElement }
  } = rendererInternals;
  const hiddenContainer = createElement("div");
  const suspense = vnode.suspense = createSuspenseBoundary(
    vnode,
    parentSuspense,
    parentComponent,
    container,
    hiddenContainer,
    anchor,
    namespace,
    slotScopeIds,
    optimized,
    rendererInternals
  );
  patch(
    null,
    suspense.pendingBranch = vnode.ssContent,
    hiddenContainer,
    null,
    parentComponent,
    suspense,
    namespace,
    slotScopeIds
  );
  if (suspense.deps > 0) {
    triggerEvent(vnode, "onPending");
    triggerEvent(vnode, "onFallback");
    patch(
      null,
      vnode.ssFallback,
      container,
      anchor,
      parentComponent,
      null,
      // fallback tree will not have suspense context
      namespace,
      slotScopeIds
    );
    setActiveBranch(suspense, vnode.ssFallback);
  } else {
    suspense.resolve(false, true);
  }
}
function patchSuspense(n1, n2, container, anchor, parentComponent, namespace, slotScopeIds, optimized, { p: patch, um: unmount, o: { createElement } }) {
  const suspense = n2.suspense = n1.suspense;
  suspense.vnode = n2;
  n2.el = n1.el;
  const newBranch = n2.ssContent;
  const newFallback = n2.ssFallback;
  const { activeBranch, pendingBranch, isInFallback, isHydrating } = suspense;
  if (pendingBranch) {
    suspense.pendingBranch = newBranch;
    if (isSameVNodeType(newBranch, pendingBranch)) {
      patch(
        pendingBranch,
        newBranch,
        suspense.hiddenContainer,
        null,
        parentComponent,
        suspense,
        namespace,
        slotScopeIds,
        optimized
      );
      if (suspense.deps <= 0) {
        suspense.resolve();
      } else if (isInFallback) {
        if (!isHydrating) {
          patch(
            activeBranch,
            newFallback,
            container,
            anchor,
            parentComponent,
            null,
            // fallback tree will not have suspense context
            namespace,
            slotScopeIds,
            optimized
          );
          setActiveBranch(suspense, newFallback);
        }
      }
    } else {
      suspense.pendingId = suspenseId++;
      if (isHydrating) {
        suspense.isHydrating = false;
        suspense.activeBranch = pendingBranch;
      } else {
        unmount(pendingBranch, parentComponent, suspense);
      }
      suspense.deps = 0;
      suspense.effects.length = 0;
      suspense.hiddenContainer = createElement("div");
      if (isInFallback) {
        patch(
          null,
          newBranch,
          suspense.hiddenContainer,
          null,
          parentComponent,
          suspense,
          namespace,
          slotScopeIds,
          optimized
        );
        if (suspense.deps <= 0) {
          suspense.resolve();
        } else {
          patch(
            activeBranch,
            newFallback,
            container,
            anchor,
            parentComponent,
            null,
            // fallback tree will not have suspense context
            namespace,
            slotScopeIds,
            optimized
          );
          setActiveBranch(suspense, newFallback);
        }
      } else if (activeBranch && isSameVNodeType(newBranch, activeBranch)) {
        patch(
          activeBranch,
          newBranch,
          container,
          anchor,
          parentComponent,
          suspense,
          namespace,
          slotScopeIds,
          optimized
        );
        suspense.resolve(true);
      } else {
        patch(
          null,
          newBranch,
          suspense.hiddenContainer,
          null,
          parentComponent,
          suspense,
          namespace,
          slotScopeIds,
          optimized
        );
        if (suspense.deps <= 0) {
          suspense.resolve();
        }
      }
    }
  } else {
    if (activeBranch && isSameVNodeType(newBranch, activeBranch)) {
      patch(
        activeBranch,
        newBranch,
        container,
        anchor,
        parentComponent,
        suspense,
        namespace,
        slotScopeIds,
        optimized
      );
      setActiveBranch(suspense, newBranch);
    } else {
      triggerEvent(n2, "onPending");
      suspense.pendingBranch = newBranch;
      if (newBranch.shapeFlag & 512) {
        suspense.pendingId = newBranch.component.suspenseId;
      } else {
        suspense.pendingId = suspenseId++;
      }
      patch(
        null,
        newBranch,
        suspense.hiddenContainer,
        null,
        parentComponent,
        suspense,
        namespace,
        slotScopeIds,
        optimized
      );
      if (suspense.deps <= 0) {
        suspense.resolve();
      } else {
        const { timeout, pendingId } = suspense;
        if (timeout > 0) {
          setTimeout(() => {
            if (suspense.pendingId === pendingId) {
              suspense.fallback(newFallback);
            }
          }, timeout);
        } else if (timeout === 0) {
          suspense.fallback(newFallback);
        }
      }
    }
  }
}
let hasWarned = false;
function createSuspenseBoundary(vnode, parentSuspense, parentComponent, container, hiddenContainer, anchor, namespace, slotScopeIds, optimized, rendererInternals, isHydrating = false) {
  if (false) {}
  const {
    p: patch,
    m: move,
    um: unmount,
    n: next,
    o: { parentNode, remove }
  } = rendererInternals;
  let parentSuspenseId;
  const isSuspensible = isVNodeSuspensible(vnode);
  if (isSuspensible) {
    if (parentSuspense && parentSuspense.pendingBranch) {
      parentSuspenseId = parentSuspense.pendingId;
      parentSuspense.deps++;
    }
  }
  const timeout = vnode.props ? toNumber(vnode.props.timeout) : void 0;
  if (false) {}
  const initialAnchor = anchor;
  const suspense = {
    vnode,
    parent: parentSuspense,
    parentComponent,
    namespace,
    container,
    hiddenContainer,
    deps: 0,
    pendingId: suspenseId++,
    timeout: typeof timeout === "number" ? timeout : -1,
    activeBranch: null,
    pendingBranch: null,
    isInFallback: !isHydrating,
    isHydrating,
    isUnmounted: false,
    effects: [],
    resolve(resume = false, sync = false) {
      if (false) {}
      const {
        vnode: vnode2,
        activeBranch,
        pendingBranch,
        pendingId,
        effects,
        parentComponent: parentComponent2,
        container: container2
      } = suspense;
      let delayEnter = false;
      if (suspense.isHydrating) {
        suspense.isHydrating = false;
      } else if (!resume) {
        delayEnter = activeBranch && pendingBranch.transition && pendingBranch.transition.mode === "out-in";
        if (delayEnter) {
          activeBranch.transition.afterLeave = () => {
            if (pendingId === suspense.pendingId) {
              move(
                pendingBranch,
                container2,
                anchor === initialAnchor ? next(activeBranch) : anchor,
                0
              );
              runtime_core_esm_bundler_queuePostFlushCb(effects);
            }
          };
        }
        if (activeBranch) {
          if (parentNode(activeBranch.el) === container2) {
            anchor = next(activeBranch);
          }
          unmount(activeBranch, parentComponent2, suspense, true);
        }
        if (!delayEnter) {
          move(pendingBranch, container2, anchor, 0);
        }
      }
      setActiveBranch(suspense, pendingBranch);
      suspense.pendingBranch = null;
      suspense.isInFallback = false;
      let parent = suspense.parent;
      let hasUnresolvedAncestor = false;
      while (parent) {
        if (parent.pendingBranch) {
          parent.effects.push(...effects);
          hasUnresolvedAncestor = true;
          break;
        }
        parent = parent.parent;
      }
      if (!hasUnresolvedAncestor && !delayEnter) {
        runtime_core_esm_bundler_queuePostFlushCb(effects);
      }
      suspense.effects = [];
      if (isSuspensible) {
        if (parentSuspense && parentSuspense.pendingBranch && parentSuspenseId === parentSuspense.pendingId) {
          parentSuspense.deps--;
          if (parentSuspense.deps === 0 && !sync) {
            parentSuspense.resolve();
          }
        }
      }
      triggerEvent(vnode2, "onResolve");
    },
    fallback(fallbackVNode) {
      if (!suspense.pendingBranch) {
        return;
      }
      const { vnode: vnode2, activeBranch, parentComponent: parentComponent2, container: container2, namespace: namespace2 } = suspense;
      triggerEvent(vnode2, "onFallback");
      const anchor2 = next(activeBranch);
      const mountFallback = () => {
        if (!suspense.isInFallback) {
          return;
        }
        patch(
          null,
          fallbackVNode,
          container2,
          anchor2,
          parentComponent2,
          null,
          // fallback tree will not have suspense context
          namespace2,
          slotScopeIds,
          optimized
        );
        setActiveBranch(suspense, fallbackVNode);
      };
      const delayEnter = fallbackVNode.transition && fallbackVNode.transition.mode === "out-in";
      if (delayEnter) {
        activeBranch.transition.afterLeave = mountFallback;
      }
      suspense.isInFallback = true;
      unmount(
        activeBranch,
        parentComponent2,
        null,
        // no suspense so unmount hooks fire now
        true
        // shouldRemove
      );
      if (!delayEnter) {
        mountFallback();
      }
    },
    move(container2, anchor2, type) {
      suspense.activeBranch && move(suspense.activeBranch, container2, anchor2, type);
      suspense.container = container2;
    },
    next() {
      return suspense.activeBranch && next(suspense.activeBranch);
    },
    registerDep(instance, setupRenderEffect, optimized2) {
      const isInPendingSuspense = !!suspense.pendingBranch;
      if (isInPendingSuspense) {
        suspense.deps++;
      }
      const hydratedEl = instance.vnode.el;
      instance.asyncDep.catch((err) => {
        handleError(err, instance, 0);
      }).then((asyncSetupResult) => {
        if (instance.isUnmounted || suspense.isUnmounted || suspense.pendingId !== instance.suspenseId) {
          return;
        }
        instance.asyncResolved = true;
        const { vnode: vnode2 } = instance;
        if (false) {}
        handleSetupResult(instance, asyncSetupResult, false);
        if (hydratedEl) {
          vnode2.el = hydratedEl;
        }
        const placeholder = !hydratedEl && instance.subTree.el;
        setupRenderEffect(
          instance,
          vnode2,
          // component may have been moved before resolve.
          // if this is not a hydration, instance.subTree will be the comment
          // placeholder.
          parentNode(hydratedEl || instance.subTree.el),
          // anchor will not be used if this is hydration, so only need to
          // consider the comment placeholder case.
          hydratedEl ? null : next(instance.subTree),
          suspense,
          namespace,
          optimized2
        );
        if (placeholder) {
          remove(placeholder);
        }
        updateHOCHostEl(instance, vnode2.el);
        if (false) {}
        if (isInPendingSuspense && --suspense.deps === 0) {
          suspense.resolve();
        }
      });
    },
    unmount(parentSuspense2, doRemove) {
      suspense.isUnmounted = true;
      if (suspense.activeBranch) {
        unmount(
          suspense.activeBranch,
          parentComponent,
          parentSuspense2,
          doRemove
        );
      }
      if (suspense.pendingBranch) {
        unmount(
          suspense.pendingBranch,
          parentComponent,
          parentSuspense2,
          doRemove
        );
      }
    }
  };
  return suspense;
}
function hydrateSuspense(node, vnode, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals, hydrateNode) {
  const suspense = vnode.suspense = createSuspenseBoundary(
    vnode,
    parentSuspense,
    parentComponent,
    node.parentNode,
    // eslint-disable-next-line no-restricted-globals
    document.createElement("div"),
    null,
    namespace,
    slotScopeIds,
    optimized,
    rendererInternals,
    true
  );
  const result = hydrateNode(
    node,
    suspense.pendingBranch = vnode.ssContent,
    parentComponent,
    suspense,
    slotScopeIds,
    optimized
  );
  if (suspense.deps === 0) {
    suspense.resolve(false, true);
  }
  return result;
}
function normalizeSuspenseChildren(vnode) {
  const { shapeFlag, children } = vnode;
  const isSlotChildren = shapeFlag & 32;
  vnode.ssContent = normalizeSuspenseSlot(
    isSlotChildren ? children.default : children
  );
  vnode.ssFallback = isSlotChildren ? normalizeSuspenseSlot(children.fallback) : createVNode(Comment);
}
function normalizeSuspenseSlot(s) {
  let block;
  if (shared_esm_bundler_isFunction(s)) {
    const trackBlock = isBlockTreeEnabled && s._c;
    if (trackBlock) {
      s._d = false;
      openBlock();
    }
    s = s();
    if (trackBlock) {
      s._d = true;
      block = currentBlock;
      closeBlock();
    }
  }
  if (shared_esm_bundler_isArray(s)) {
    const singleChild = filterSingleRoot(s);
    if (false) {}
    s = singleChild;
  }
  s = normalizeVNode(s);
  if (block && !s.dynamicChildren) {
    s.dynamicChildren = block.filter((c) => c !== s);
  }
  return s;
}
function queueEffectWithSuspense(fn, suspense) {
  if (suspense && suspense.pendingBranch) {
    if (shared_esm_bundler_isArray(fn)) {
      suspense.effects.push(...fn);
    } else {
      suspense.effects.push(fn);
    }
  } else {
    runtime_core_esm_bundler_queuePostFlushCb(fn);
  }
}
function setActiveBranch(suspense, branch) {
  suspense.activeBranch = branch;
  const { vnode, parentComponent } = suspense;
  let el = branch.el;
  while (!el && branch.component) {
    branch = branch.component.subTree;
    el = branch.el;
  }
  vnode.el = el;
  if (parentComponent && parentComponent.subTree === vnode) {
    parentComponent.vnode.el = el;
    updateHOCHostEl(parentComponent, el);
  }
}
function isVNodeSuspensible(vnode) {
  const suspensible = vnode.props && vnode.props.suspensible;
  return suspensible != null && suspensible !== false;
}

const runtime_core_esm_bundler_Fragment = Symbol.for("v-fgt");
const Text = Symbol.for("v-txt");
const Comment = Symbol.for("v-cmt");
const runtime_core_esm_bundler_Static = Symbol.for("v-stc");
const blockStack = [];
let currentBlock = null;
function openBlock(disableTracking = false) {
  blockStack.push(currentBlock = disableTracking ? null : []);
}
function closeBlock() {
  blockStack.pop();
  currentBlock = blockStack[blockStack.length - 1] || null;
}
let isBlockTreeEnabled = 1;
function setBlockTracking(value, inVOnce = false) {
  isBlockTreeEnabled += value;
  if (value < 0 && currentBlock && inVOnce) {
    currentBlock.hasOnce = true;
  }
}
function setupBlock(vnode) {
  vnode.dynamicChildren = isBlockTreeEnabled > 0 ? currentBlock || EMPTY_ARR : null;
  closeBlock();
  if (isBlockTreeEnabled > 0 && currentBlock) {
    currentBlock.push(vnode);
  }
  return vnode;
}
function createElementBlock(type, props, children, patchFlag, dynamicProps, shapeFlag) {
  return setupBlock(
    createBaseVNode(
      type,
      props,
      children,
      patchFlag,
      dynamicProps,
      shapeFlag,
      true
    )
  );
}
function createBlock(type, props, children, patchFlag, dynamicProps) {
  return setupBlock(
    createVNode(
      type,
      props,
      children,
      patchFlag,
      dynamicProps,
      true
    )
  );
}
function isVNode(value) {
  return value ? value.__v_isVNode === true : false;
}
function isSameVNodeType(n1, n2) {
  if (false) {}
  return n1.type === n2.type && n1.key === n2.key;
}
let vnodeArgsTransformer;
function transformVNodeArgs(transformer) {
  vnodeArgsTransformer = transformer;
}
const createVNodeWithArgsTransform = (...args) => {
  return _createVNode(
    ...vnodeArgsTransformer ? vnodeArgsTransformer(args, currentRenderingInstance) : args
  );
};
const normalizeKey = ({ key }) => key != null ? key : null;
const normalizeRef = ({
  ref,
  ref_key,
  ref_for
}) => {
  if (typeof ref === "number") {
    ref = "" + ref;
  }
  return ref != null ? shared_esm_bundler_isString(ref) || reactivity_esm_bundler_isRef(ref) || shared_esm_bundler_isFunction(ref) ? { i: currentRenderingInstance, r: ref, k: ref_key, f: !!ref_for } : ref : null;
};
function createBaseVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, shapeFlag = type === runtime_core_esm_bundler_Fragment ? 0 : 1, isBlockNode = false, needFullChildrenNormalization = false) {
  const vnode = {
    __v_isVNode: true,
    __v_skip: true,
    type,
    props,
    key: props && normalizeKey(props),
    ref: props && normalizeRef(props),
    scopeId: currentScopeId,
    slotScopeIds: null,
    children,
    component: null,
    suspense: null,
    ssContent: null,
    ssFallback: null,
    dirs: null,
    transition: null,
    el: null,
    anchor: null,
    target: null,
    targetStart: null,
    targetAnchor: null,
    staticCount: 0,
    shapeFlag,
    patchFlag,
    dynamicProps,
    dynamicChildren: null,
    appContext: null,
    ctx: currentRenderingInstance
  };
  if (needFullChildrenNormalization) {
    normalizeChildren(vnode, children);
    if (shapeFlag & 128) {
      type.normalize(vnode);
    }
  } else if (children) {
    vnode.shapeFlag |= shared_esm_bundler_isString(children) ? 8 : 16;
  }
  if (false) {}
  if (isBlockTreeEnabled > 0 && // avoid a block node from tracking itself
  !isBlockNode && // has current parent block
  currentBlock && // presence of a patch flag indicates this node needs patching on updates.
  // component nodes also should always be patched, because even if the
  // component doesn't need to update, it needs to persist the instance on to
  // the next vnode so that it can be properly unmounted later.
  (vnode.patchFlag > 0 || shapeFlag & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
  // vnode should not be considered dynamic due to handler caching.
  vnode.patchFlag !== 32) {
    currentBlock.push(vnode);
  }
  return vnode;
}
const createVNode =  false ? 0 : _createVNode;
function _createVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, isBlockNode = false) {
  if (!type || type === NULL_DYNAMIC_COMPONENT) {
    if (false) {}
    type = Comment;
  }
  if (isVNode(type)) {
    const cloned = cloneVNode(
      type,
      props,
      true
      /* mergeRef: true */
    );
    if (children) {
      normalizeChildren(cloned, children);
    }
    if (isBlockTreeEnabled > 0 && !isBlockNode && currentBlock) {
      if (cloned.shapeFlag & 6) {
        currentBlock[currentBlock.indexOf(type)] = cloned;
      } else {
        currentBlock.push(cloned);
      }
    }
    cloned.patchFlag = -2;
    return cloned;
  }
  if (isClassComponent(type)) {
    type = type.__vccOpts;
  }
  if (props) {
    props = guardReactiveProps(props);
    let { class: klass, style } = props;
    if (klass && !shared_esm_bundler_isString(klass)) {
      props.class = shared_esm_bundler_normalizeClass(klass);
    }
    if (shared_esm_bundler_isObject(style)) {
      if (isProxy(style) && !shared_esm_bundler_isArray(style)) {
        style = shared_esm_bundler_extend({}, style);
      }
      props.style = shared_esm_bundler_normalizeStyle(style);
    }
  }
  const shapeFlag = shared_esm_bundler_isString(type) ? 1 : isSuspense(type) ? 128 : isTeleport(type) ? 64 : shared_esm_bundler_isObject(type) ? 4 : shared_esm_bundler_isFunction(type) ? 2 : 0;
  if (false) {}
  return createBaseVNode(
    type,
    props,
    children,
    patchFlag,
    dynamicProps,
    shapeFlag,
    isBlockNode,
    true
  );
}
function guardReactiveProps(props) {
  if (!props) return null;
  return isProxy(props) || isInternalObject(props) ? shared_esm_bundler_extend({}, props) : props;
}
function cloneVNode(vnode, extraProps, mergeRef = false, cloneTransition = false) {
  const { props, ref, patchFlag, children, transition } = vnode;
  const mergedProps = extraProps ? mergeProps(props || {}, extraProps) : props;
  const cloned = {
    __v_isVNode: true,
    __v_skip: true,
    type: vnode.type,
    props: mergedProps,
    key: mergedProps && normalizeKey(mergedProps),
    ref: extraProps && extraProps.ref ? (
      // #2078 in the case of <component :is="vnode" ref="extra"/>
      // if the vnode itself already has a ref, cloneVNode will need to merge
      // the refs so the single vnode can be set on multiple refs
      mergeRef && ref ? shared_esm_bundler_isArray(ref) ? ref.concat(normalizeRef(extraProps)) : [ref, normalizeRef(extraProps)] : normalizeRef(extraProps)
    ) : ref,
    scopeId: vnode.scopeId,
    slotScopeIds: vnode.slotScopeIds,
    children:  false ? 0 : children,
    target: vnode.target,
    targetStart: vnode.targetStart,
    targetAnchor: vnode.targetAnchor,
    staticCount: vnode.staticCount,
    shapeFlag: vnode.shapeFlag,
    // if the vnode is cloned with extra props, we can no longer assume its
    // existing patch flag to be reliable and need to add the FULL_PROPS flag.
    // note: preserve flag for fragments since they use the flag for children
    // fast paths only.
    patchFlag: extraProps && vnode.type !== runtime_core_esm_bundler_Fragment ? patchFlag === -1 ? 16 : patchFlag | 16 : patchFlag,
    dynamicProps: vnode.dynamicProps,
    dynamicChildren: vnode.dynamicChildren,
    appContext: vnode.appContext,
    dirs: vnode.dirs,
    transition,
    // These should technically only be non-null on mounted VNodes. However,
    // they *should* be copied for kept-alive vnodes. So we just always copy
    // them since them being non-null during a mount doesn't affect the logic as
    // they will simply be overwritten.
    component: vnode.component,
    suspense: vnode.suspense,
    ssContent: vnode.ssContent && cloneVNode(vnode.ssContent),
    ssFallback: vnode.ssFallback && cloneVNode(vnode.ssFallback),
    placeholder: vnode.placeholder,
    el: vnode.el,
    anchor: vnode.anchor,
    ctx: vnode.ctx,
    ce: vnode.ce
  };
  if (transition && cloneTransition) {
    setTransitionHooks(
      cloned,
      transition.clone(cloned)
    );
  }
  return cloned;
}
function deepCloneVNode(vnode) {
  const cloned = cloneVNode(vnode);
  if (isArray(vnode.children)) {
    cloned.children = vnode.children.map(deepCloneVNode);
  }
  return cloned;
}
function createTextVNode(text = " ", flag = 0) {
  return createVNode(Text, null, text, flag);
}
function createStaticVNode(content, numberOfNodes) {
  const vnode = createVNode(runtime_core_esm_bundler_Static, null, content);
  vnode.staticCount = numberOfNodes;
  return vnode;
}
function createCommentVNode(text = "", asBlock = false) {
  return asBlock ? (openBlock(), createBlock(Comment, null, text)) : createVNode(Comment, null, text);
}
function normalizeVNode(child) {
  if (child == null || typeof child === "boolean") {
    return createVNode(Comment);
  } else if (shared_esm_bundler_isArray(child)) {
    return createVNode(
      runtime_core_esm_bundler_Fragment,
      null,
      // #3666, avoid reference pollution when reusing vnode
      child.slice()
    );
  } else if (isVNode(child)) {
    return cloneIfMounted(child);
  } else {
    return createVNode(Text, null, String(child));
  }
}
function cloneIfMounted(child) {
  return child.el === null && child.patchFlag !== -1 || child.memo ? child : cloneVNode(child);
}
function normalizeChildren(vnode, children) {
  let type = 0;
  const { shapeFlag } = vnode;
  if (children == null) {
    children = null;
  } else if (shared_esm_bundler_isArray(children)) {
    type = 16;
  } else if (typeof children === "object") {
    if (shapeFlag & (1 | 64)) {
      const slot = children.default;
      if (slot) {
        slot._c && (slot._d = false);
        normalizeChildren(vnode, slot());
        slot._c && (slot._d = true);
      }
      return;
    } else {
      type = 32;
      const slotFlag = children._;
      if (!slotFlag && !isInternalObject(children)) {
        children._ctx = currentRenderingInstance;
      } else if (slotFlag === 3 && currentRenderingInstance) {
        if (currentRenderingInstance.slots._ === 1) {
          children._ = 1;
        } else {
          children._ = 2;
          vnode.patchFlag |= 1024;
        }
      }
    }
  } else if (shared_esm_bundler_isFunction(children)) {
    children = { default: children, _ctx: currentRenderingInstance };
    type = 32;
  } else {
    children = String(children);
    if (shapeFlag & 64) {
      type = 16;
      children = [createTextVNode(children)];
    } else {
      type = 8;
    }
  }
  vnode.children = children;
  vnode.shapeFlag |= type;
}
function mergeProps(...args) {
  const ret = {};
  for (let i = 0; i < args.length; i++) {
    const toMerge = args[i];
    for (const key in toMerge) {
      if (key === "class") {
        if (ret.class !== toMerge.class) {
          ret.class = shared_esm_bundler_normalizeClass([ret.class, toMerge.class]);
        }
      } else if (key === "style") {
        ret.style = shared_esm_bundler_normalizeStyle([ret.style, toMerge.style]);
      } else if (shared_esm_bundler_isOn(key)) {
        const existing = ret[key];
        const incoming = toMerge[key];
        if (incoming && existing !== incoming && !(shared_esm_bundler_isArray(existing) && existing.includes(incoming))) {
          ret[key] = existing ? [].concat(existing, incoming) : incoming;
        }
      } else if (key !== "") {
        ret[key] = toMerge[key];
      }
    }
  }
  return ret;
}
function invokeVNodeHook(hook, instance, vnode, prevVNode = null) {
  callWithAsyncErrorHandling(hook, instance, 7, [
    vnode,
    prevVNode
  ]);
}

const emptyAppContext = createAppContext();
let uid = 0;
function createComponentInstance(vnode, parent, suspense) {
  const type = vnode.type;
  const appContext = (parent ? parent.appContext : vnode.appContext) || emptyAppContext;
  const instance = {
    uid: uid++,
    vnode,
    type,
    parent,
    appContext,
    root: null,
    // to be immediately set
    next: null,
    subTree: null,
    // will be set synchronously right after creation
    effect: null,
    update: null,
    // will be set synchronously right after creation
    job: null,
    scope: new EffectScope(
      true
      /* detached */
    ),
    render: null,
    proxy: null,
    exposed: null,
    exposeProxy: null,
    withProxy: null,
    provides: parent ? parent.provides : Object.create(appContext.provides),
    ids: parent ? parent.ids : ["", 0, 0],
    accessCache: null,
    renderCache: [],
    // local resolved assets
    components: null,
    directives: null,
    // resolved props and emits options
    propsOptions: normalizePropsOptions(type, appContext),
    emitsOptions: normalizeEmitsOptions(type, appContext),
    // emit
    emit: null,
    // to be set immediately
    emitted: null,
    // props default value
    propsDefaults: shared_esm_bundler_EMPTY_OBJ,
    // inheritAttrs
    inheritAttrs: type.inheritAttrs,
    // state
    ctx: shared_esm_bundler_EMPTY_OBJ,
    data: shared_esm_bundler_EMPTY_OBJ,
    props: shared_esm_bundler_EMPTY_OBJ,
    attrs: shared_esm_bundler_EMPTY_OBJ,
    slots: shared_esm_bundler_EMPTY_OBJ,
    refs: shared_esm_bundler_EMPTY_OBJ,
    setupState: shared_esm_bundler_EMPTY_OBJ,
    setupContext: null,
    // suspense related
    suspense,
    suspenseId: suspense ? suspense.pendingId : 0,
    asyncDep: null,
    asyncResolved: false,
    // lifecycle hooks
    // not using enums here because it results in computed properties
    isMounted: false,
    isUnmounted: false,
    isDeactivated: false,
    bc: null,
    c: null,
    bm: null,
    m: null,
    bu: null,
    u: null,
    um: null,
    bum: null,
    da: null,
    a: null,
    rtg: null,
    rtc: null,
    ec: null,
    sp: null
  };
  if (false) {} else {
    instance.ctx = { _: instance };
  }
  instance.root = parent ? parent.root : instance;
  instance.emit = emit.bind(null, instance);
  if (vnode.ce) {
    vnode.ce(instance);
  }
  return instance;
}
let currentInstance = null;
const runtime_core_esm_bundler_getCurrentInstance = () => currentInstance || currentRenderingInstance;
let internalSetCurrentInstance;
let setInSSRSetupState;
{
  const g = getGlobalThis();
  const registerGlobalSetter = (key, setter) => {
    let setters;
    if (!(setters = g[key])) setters = g[key] = [];
    setters.push(setter);
    return (v) => {
      if (setters.length > 1) setters.forEach((set) => set(v));
      else setters[0](v);
    };
  };
  internalSetCurrentInstance = registerGlobalSetter(
    `__VUE_INSTANCE_SETTERS__`,
    (v) => currentInstance = v
  );
  setInSSRSetupState = registerGlobalSetter(
    `__VUE_SSR_SETTERS__`,
    (v) => isInSSRComponentSetup = v
  );
}
const setCurrentInstance = (instance) => {
  const prev = currentInstance;
  internalSetCurrentInstance(instance);
  instance.scope.on();
  return () => {
    instance.scope.off();
    internalSetCurrentInstance(prev);
  };
};
const unsetCurrentInstance = () => {
  currentInstance && currentInstance.scope.off();
  internalSetCurrentInstance(null);
};
const isBuiltInTag = /* @__PURE__ */ (/* unused pure expression or super */ null && (makeMap("slot,component")));
function validateComponentName(name, { isNativeTag }) {
  if (isBuiltInTag(name) || isNativeTag(name)) {
    warn$1(
      "Do not use built-in or reserved HTML elements as component id: " + name
    );
  }
}
function isStatefulComponent(instance) {
  return instance.vnode.shapeFlag & 4;
}
let isInSSRComponentSetup = false;
function setupComponent(instance, isSSR = false, optimized = false) {
  isSSR && setInSSRSetupState(isSSR);
  const { props, children } = instance.vnode;
  const isStateful = isStatefulComponent(instance);
  initProps(instance, props, isStateful, isSSR);
  initSlots(instance, children, optimized || isSSR);
  const setupResult = isStateful ? setupStatefulComponent(instance, isSSR) : void 0;
  isSSR && setInSSRSetupState(false);
  return setupResult;
}
function setupStatefulComponent(instance, isSSR) {
  var _a;
  const Component = instance.type;
  if (false) {}
  instance.accessCache = /* @__PURE__ */ Object.create(null);
  instance.proxy = new Proxy(instance.ctx, PublicInstanceProxyHandlers);
  if (false) {}
  const { setup } = Component;
  if (setup) {
    reactivity_esm_bundler_pauseTracking();
    const setupContext = instance.setupContext = setup.length > 1 ? createSetupContext(instance) : null;
    const reset = setCurrentInstance(instance);
    const setupResult = callWithErrorHandling(
      setup,
      instance,
      0,
      [
         false ? 0 : instance.props,
        setupContext
      ]
    );
    const isAsyncSetup = shared_esm_bundler_isPromise(setupResult);
    reactivity_esm_bundler_resetTracking();
    reset();
    if ((isAsyncSetup || instance.sp) && !isAsyncWrapper(instance)) {
      markAsyncBoundary(instance);
    }
    if (isAsyncSetup) {
      setupResult.then(unsetCurrentInstance, unsetCurrentInstance);
      if (isSSR) {
        return setupResult.then((resolvedResult) => {
          handleSetupResult(instance, resolvedResult, isSSR);
        }).catch((e) => {
          handleError(e, instance, 0);
        });
      } else {
        instance.asyncDep = setupResult;
        if (false) {}
      }
    } else {
      handleSetupResult(instance, setupResult, isSSR);
    }
  } else {
    finishComponentSetup(instance, isSSR);
  }
}
function handleSetupResult(instance, setupResult, isSSR) {
  if (shared_esm_bundler_isFunction(setupResult)) {
    if (instance.type.__ssrInlineRender) {
      instance.ssrRender = setupResult;
    } else {
      instance.render = setupResult;
    }
  } else if (shared_esm_bundler_isObject(setupResult)) {
    if (false) {}
    if (false) {}
    instance.setupState = proxyRefs(setupResult);
    if (false) {}
  } else if (false) {}
  finishComponentSetup(instance, isSSR);
}
let compile;
let installWithProxy;
function registerRuntimeCompiler(_compile) {
  compile = _compile;
  installWithProxy = (i) => {
    if (i.render._rc) {
      i.withProxy = new Proxy(i.ctx, RuntimeCompiledPublicInstanceProxyHandlers);
    }
  };
}
const runtime_core_esm_bundler_isRuntimeOnly = () => !compile;
function finishComponentSetup(instance, isSSR, skipOptions) {
  const Component = instance.type;
  if (!instance.render) {
    if (!isSSR && compile && !Component.render) {
      const template = Component.template ||  true && resolveMergedOptions(instance).template;
      if (template) {
        if (false) {}
        const { isCustomElement, compilerOptions } = instance.appContext.config;
        const { delimiters, compilerOptions: componentCompilerOptions } = Component;
        const finalCompilerOptions = shared_esm_bundler_extend(
          shared_esm_bundler_extend(
            {
              isCustomElement,
              delimiters
            },
            compilerOptions
          ),
          componentCompilerOptions
        );
        Component.render = compile(template, finalCompilerOptions);
        if (false) {}
      }
    }
    instance.render = Component.render || shared_esm_bundler_NOOP;
    if (installWithProxy) {
      installWithProxy(instance);
    }
  }
  if (true) {
    const reset = setCurrentInstance(instance);
    reactivity_esm_bundler_pauseTracking();
    try {
      applyOptions(instance);
    } finally {
      reactivity_esm_bundler_resetTracking();
      reset();
    }
  }
  if (false) {}
}
const attrsProxyHandlers =  false ? 0 : {
  get(target, key) {
    reactivity_esm_bundler_track(target, "get", "");
    return target[key];
  }
};
function getSlotsProxy(instance) {
  return new Proxy(instance.slots, {
    get(target, key) {
      track(instance, "get", "$slots");
      return target[key];
    }
  });
}
function createSetupContext(instance) {
  const expose = (exposed) => {
    if (false) {}
    instance.exposed = exposed || {};
  };
  if (false) {} else {
    return {
      attrs: new Proxy(instance.attrs, attrsProxyHandlers),
      slots: instance.slots,
      emit: instance.emit,
      expose
    };
  }
}
function getComponentPublicInstance(instance) {
  if (instance.exposed) {
    return instance.exposeProxy || (instance.exposeProxy = new Proxy(proxyRefs(reactivity_esm_bundler_markRaw(instance.exposed)), {
      get(target, key) {
        if (key in target) {
          return target[key];
        } else if (key in publicPropertiesMap) {
          return publicPropertiesMap[key](instance);
        }
      },
      has(target, key) {
        return key in target || key in publicPropertiesMap;
      }
    }));
  } else {
    return instance.proxy;
  }
}
const classifyRE = /(?:^|[-_])(\w)/g;
const classify = (str) => str.replace(classifyRE, (c) => c.toUpperCase()).replace(/[-_]/g, "");
function getComponentName(Component, includeInferred = true) {
  return shared_esm_bundler_isFunction(Component) ? Component.displayName || Component.name : Component.name || includeInferred && Component.__name;
}
function formatComponentName(instance, Component, isRoot = false) {
  let name = getComponentName(Component);
  if (!name && Component.__file) {
    const match = Component.__file.match(/([^/\\]+)\.\w+$/);
    if (match) {
      name = match[1];
    }
  }
  if (!name && instance && instance.parent) {
    const inferFromRegistry = (registry) => {
      for (const key in registry) {
        if (registry[key] === Component) {
          return key;
        }
      }
    };
    name = inferFromRegistry(
      instance.components || instance.parent.type.components
    ) || inferFromRegistry(instance.appContext.components);
  }
  return name ? classify(name) : isRoot ? `App` : `Anonymous`;
}
function isClassComponent(value) {
  return shared_esm_bundler_isFunction(value) && "__vccOpts" in value;
}

const runtime_core_esm_bundler_computed = (getterOrOptions, debugOptions) => {
  const c = reactivity_esm_bundler_computed(getterOrOptions, debugOptions, isInSSRComponentSetup);
  if (false) {}
  return c;
};

function h(type, propsOrChildren, children) {
  const l = arguments.length;
  if (l === 2) {
    if (shared_esm_bundler_isObject(propsOrChildren) && !shared_esm_bundler_isArray(propsOrChildren)) {
      if (isVNode(propsOrChildren)) {
        return createVNode(type, null, [propsOrChildren]);
      }
      return createVNode(type, propsOrChildren);
    } else {
      return createVNode(type, null, propsOrChildren);
    }
  } else {
    if (l > 3) {
      children = Array.prototype.slice.call(arguments, 2);
    } else if (l === 3 && isVNode(children)) {
      children = [children];
    }
    return createVNode(type, propsOrChildren, children);
  }
}

function initCustomFormatter() {
  if (true) {
    return;
  }
  const vueStyle = { style: "color:#3ba776" };
  const numberStyle = { style: "color:#1677ff" };
  const stringStyle = { style: "color:#f5222d" };
  const keywordStyle = { style: "color:#eb2f96" };
  const formatter = {
    __vue_custom_formatter: true,
    header(obj) {
      if (!isObject(obj)) {
        return null;
      }
      if (obj.__isVue) {
        return ["div", vueStyle, `VueInstance`];
      } else if (isRef(obj)) {
        pauseTracking();
        const value = obj.value;
        resetTracking();
        return [
          "div",
          {},
          ["span", vueStyle, genRefFlag(obj)],
          "<",
          formatValue(value),
          `>`
        ];
      } else if (isReactive(obj)) {
        return [
          "div",
          {},
          ["span", vueStyle, isShallow(obj) ? "ShallowReactive" : "Reactive"],
          "<",
          formatValue(obj),
          `>${isReadonly(obj) ? ` (readonly)` : ``}`
        ];
      } else if (isReadonly(obj)) {
        return [
          "div",
          {},
          ["span", vueStyle, isShallow(obj) ? "ShallowReadonly" : "Readonly"],
          "<",
          formatValue(obj),
          ">"
        ];
      }
      return null;
    },
    hasBody(obj) {
      return obj && obj.__isVue;
    },
    body(obj) {
      if (obj && obj.__isVue) {
        return [
          "div",
          {},
          ...formatInstance(obj.$)
        ];
      }
    }
  };
  function formatInstance(instance) {
    const blocks = [];
    if (instance.type.props && instance.props) {
      blocks.push(createInstanceBlock("props", toRaw(instance.props)));
    }
    if (instance.setupState !== EMPTY_OBJ) {
      blocks.push(createInstanceBlock("setup", instance.setupState));
    }
    if (instance.data !== EMPTY_OBJ) {
      blocks.push(createInstanceBlock("data", toRaw(instance.data)));
    }
    const computed = extractKeys(instance, "computed");
    if (computed) {
      blocks.push(createInstanceBlock("computed", computed));
    }
    const injected = extractKeys(instance, "inject");
    if (injected) {
      blocks.push(createInstanceBlock("injected", injected));
    }
    blocks.push([
      "div",
      {},
      [
        "span",
        {
          style: keywordStyle.style + ";opacity:0.66"
        },
        "$ (internal): "
      ],
      ["object", { object: instance }]
    ]);
    return blocks;
  }
  function createInstanceBlock(type, target) {
    target = extend({}, target);
    if (!Object.keys(target).length) {
      return ["span", {}];
    }
    return [
      "div",
      { style: "line-height:1.25em;margin-bottom:0.6em" },
      [
        "div",
        {
          style: "color:#476582"
        },
        type
      ],
      [
        "div",
        {
          style: "padding-left:1.25em"
        },
        ...Object.keys(target).map((key) => {
          return [
            "div",
            {},
            ["span", keywordStyle, key + ": "],
            formatValue(target[key], false)
          ];
        })
      ]
    ];
  }
  function formatValue(v, asRaw = true) {
    if (typeof v === "number") {
      return ["span", numberStyle, v];
    } else if (typeof v === "string") {
      return ["span", stringStyle, JSON.stringify(v)];
    } else if (typeof v === "boolean") {
      return ["span", keywordStyle, v];
    } else if (isObject(v)) {
      return ["object", { object: asRaw ? toRaw(v) : v }];
    } else {
      return ["span", stringStyle, String(v)];
    }
  }
  function extractKeys(instance, type) {
    const Comp = instance.type;
    if (isFunction(Comp)) {
      return;
    }
    const extracted = {};
    for (const key in instance.ctx) {
      if (isKeyOfType(Comp, key, type)) {
        extracted[key] = instance.ctx[key];
      }
    }
    return extracted;
  }
  function isKeyOfType(Comp, key, type) {
    const opts = Comp[type];
    if (isArray(opts) && opts.includes(key) || isObject(opts) && key in opts) {
      return true;
    }
    if (Comp.extends && isKeyOfType(Comp.extends, key, type)) {
      return true;
    }
    if (Comp.mixins && Comp.mixins.some((m) => isKeyOfType(m, key, type))) {
      return true;
    }
  }
  function genRefFlag(v) {
    if (isShallow(v)) {
      return `ShallowRef`;
    }
    if (v.effect) {
      return `ComputedRef`;
    }
    return `Ref`;
  }
  if (window.devtoolsFormatters) {
    window.devtoolsFormatters.push(formatter);
  } else {
    window.devtoolsFormatters = [formatter];
  }
}

function withMemo(memo, render, cache, index) {
  const cached = cache[index];
  if (cached && isMemoSame(cached, memo)) {
    return cached;
  }
  const ret = render();
  ret.memo = memo.slice();
  ret.cacheIndex = index;
  return cache[index] = ret;
}
function isMemoSame(cached, memo) {
  const prev = cached.memo;
  if (prev.length != memo.length) {
    return false;
  }
  for (let i = 0; i < prev.length; i++) {
    if (hasChanged(prev[i], memo[i])) {
      return false;
    }
  }
  if (isBlockTreeEnabled > 0 && currentBlock) {
    currentBlock.push(cached);
  }
  return true;
}

const version = "3.5.20";
const runtime_core_esm_bundler_warn = (/* unused pure expression or super */ null && ( false ? 0 : NOOP));
const ErrorTypeStrings = (/* unused pure expression or super */ null && (ErrorTypeStrings$1)) ;
const devtools =  true ? devtools$1 : 0;
const setDevtoolsHook = (/* unused pure expression or super */ null && ( true ? setDevtoolsHook$1 : 0));
const _ssrUtils = {
  createComponentInstance,
  setupComponent,
  renderComponentRoot,
  setCurrentRenderingInstance,
  isVNode: isVNode,
  normalizeVNode,
  getComponentPublicInstance,
  ensureValidVNode,
  pushWarningContext,
  popWarningContext
};
const ssrUtils = (/* unused pure expression or super */ null && (_ssrUtils)) ;
const resolveFilter = null;
const compatUtils = null;
const DeprecationTypes = null;



;// CONCATENATED MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
/**
* @vue/runtime-dom v3.5.20
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/




let policy = void 0;
const tt = typeof window !== "undefined" && window.trustedTypes;
if (tt) {
  try {
    policy = /* @__PURE__ */ tt.createPolicy("vue", {
      createHTML: (val) => val
    });
  } catch (e) {
     false && 0;
  }
}
const unsafeToTrustedHTML = policy ? (val) => policy.createHTML(val) : (val) => val;
const svgNS = "http://www.w3.org/2000/svg";
const mathmlNS = "http://www.w3.org/1998/Math/MathML";
const doc = typeof document !== "undefined" ? document : null;
const templateContainer = doc && /* @__PURE__ */ doc.createElement("template");
const nodeOps = {
  insert: (child, parent, anchor) => {
    parent.insertBefore(child, anchor || null);
  },
  remove: (child) => {
    const parent = child.parentNode;
    if (parent) {
      parent.removeChild(child);
    }
  },
  createElement: (tag, namespace, is, props) => {
    const el = namespace === "svg" ? doc.createElementNS(svgNS, tag) : namespace === "mathml" ? doc.createElementNS(mathmlNS, tag) : is ? doc.createElement(tag, { is }) : doc.createElement(tag);
    if (tag === "select" && props && props.multiple != null) {
      el.setAttribute("multiple", props.multiple);
    }
    return el;
  },
  createText: (text) => doc.createTextNode(text),
  createComment: (text) => doc.createComment(text),
  setText: (node, text) => {
    node.nodeValue = text;
  },
  setElementText: (el, text) => {
    el.textContent = text;
  },
  parentNode: (node) => node.parentNode,
  nextSibling: (node) => node.nextSibling,
  querySelector: (selector) => doc.querySelector(selector),
  setScopeId(el, id) {
    el.setAttribute(id, "");
  },
  // __UNSAFE__
  // Reason: innerHTML.
  // Static content here can only come from compiled templates.
  // As long as the user only uses trusted templates, this is safe.
  insertStaticContent(content, parent, anchor, namespace, start, end) {
    const before = anchor ? anchor.previousSibling : parent.lastChild;
    if (start && (start === end || start.nextSibling)) {
      while (true) {
        parent.insertBefore(start.cloneNode(true), anchor);
        if (start === end || !(start = start.nextSibling)) break;
      }
    } else {
      templateContainer.innerHTML = unsafeToTrustedHTML(
        namespace === "svg" ? `<svg>${content}</svg>` : namespace === "mathml" ? `<math>${content}</math>` : content
      );
      const template = templateContainer.content;
      if (namespace === "svg" || namespace === "mathml") {
        const wrapper = template.firstChild;
        while (wrapper.firstChild) {
          template.appendChild(wrapper.firstChild);
        }
        template.removeChild(wrapper);
      }
      parent.insertBefore(template, anchor);
    }
    return [
      // first
      before ? before.nextSibling : parent.firstChild,
      // last
      anchor ? anchor.previousSibling : parent.lastChild
    ];
  }
};

const TRANSITION = "transition";
const ANIMATION = "animation";
const vtcKey = Symbol("_vtc");
const DOMTransitionPropsValidators = {
  name: String,
  type: String,
  css: {
    type: Boolean,
    default: true
  },
  duration: [String, Number, Object],
  enterFromClass: String,
  enterActiveClass: String,
  enterToClass: String,
  appearFromClass: String,
  appearActiveClass: String,
  appearToClass: String,
  leaveFromClass: String,
  leaveActiveClass: String,
  leaveToClass: String
};
const TransitionPropsValidators = /* @__PURE__ */ shared_esm_bundler_extend(
  {},
  BaseTransitionPropsValidators,
  DOMTransitionPropsValidators
);
const decorate$1 = (t) => {
  t.displayName = "Transition";
  t.props = TransitionPropsValidators;
  return t;
};
const Transition = /* @__PURE__ */ decorate$1(
  (props, { slots }) => h(BaseTransition, resolveTransitionProps(props), slots)
);
const runtime_dom_esm_bundler_callHook = (hook, args = []) => {
  if (shared_esm_bundler_isArray(hook)) {
    hook.forEach((h2) => h2(...args));
  } else if (hook) {
    hook(...args);
  }
};
const hasExplicitCallback = (hook) => {
  return hook ? shared_esm_bundler_isArray(hook) ? hook.some((h2) => h2.length > 1) : hook.length > 1 : false;
};
function resolveTransitionProps(rawProps) {
  const baseProps = {};
  for (const key in rawProps) {
    if (!(key in DOMTransitionPropsValidators)) {
      baseProps[key] = rawProps[key];
    }
  }
  if (rawProps.css === false) {
    return baseProps;
  }
  const {
    name = "v",
    type,
    duration,
    enterFromClass = `${name}-enter-from`,
    enterActiveClass = `${name}-enter-active`,
    enterToClass = `${name}-enter-to`,
    appearFromClass = enterFromClass,
    appearActiveClass = enterActiveClass,
    appearToClass = enterToClass,
    leaveFromClass = `${name}-leave-from`,
    leaveActiveClass = `${name}-leave-active`,
    leaveToClass = `${name}-leave-to`
  } = rawProps;
  const durations = normalizeDuration(duration);
  const enterDuration = durations && durations[0];
  const leaveDuration = durations && durations[1];
  const {
    onBeforeEnter,
    onEnter,
    onEnterCancelled,
    onLeave,
    onLeaveCancelled,
    onBeforeAppear = onBeforeEnter,
    onAppear = onEnter,
    onAppearCancelled = onEnterCancelled
  } = baseProps;
  const finishEnter = (el, isAppear, done, isCancelled) => {
    el._enterCancelled = isCancelled;
    removeTransitionClass(el, isAppear ? appearToClass : enterToClass);
    removeTransitionClass(el, isAppear ? appearActiveClass : enterActiveClass);
    done && done();
  };
  const finishLeave = (el, done) => {
    el._isLeaving = false;
    removeTransitionClass(el, leaveFromClass);
    removeTransitionClass(el, leaveToClass);
    removeTransitionClass(el, leaveActiveClass);
    done && done();
  };
  const makeEnterHook = (isAppear) => {
    return (el, done) => {
      const hook = isAppear ? onAppear : onEnter;
      const resolve = () => finishEnter(el, isAppear, done);
      runtime_dom_esm_bundler_callHook(hook, [el, resolve]);
      nextFrame(() => {
        removeTransitionClass(el, isAppear ? appearFromClass : enterFromClass);
        addTransitionClass(el, isAppear ? appearToClass : enterToClass);
        if (!hasExplicitCallback(hook)) {
          whenTransitionEnds(el, type, enterDuration, resolve);
        }
      });
    };
  };
  return shared_esm_bundler_extend(baseProps, {
    onBeforeEnter(el) {
      runtime_dom_esm_bundler_callHook(onBeforeEnter, [el]);
      addTransitionClass(el, enterFromClass);
      addTransitionClass(el, enterActiveClass);
    },
    onBeforeAppear(el) {
      runtime_dom_esm_bundler_callHook(onBeforeAppear, [el]);
      addTransitionClass(el, appearFromClass);
      addTransitionClass(el, appearActiveClass);
    },
    onEnter: makeEnterHook(false),
    onAppear: makeEnterHook(true),
    onLeave(el, done) {
      el._isLeaving = true;
      const resolve = () => finishLeave(el, done);
      addTransitionClass(el, leaveFromClass);
      if (!el._enterCancelled) {
        forceReflow();
        addTransitionClass(el, leaveActiveClass);
      } else {
        addTransitionClass(el, leaveActiveClass);
        forceReflow();
      }
      nextFrame(() => {
        if (!el._isLeaving) {
          return;
        }
        removeTransitionClass(el, leaveFromClass);
        addTransitionClass(el, leaveToClass);
        if (!hasExplicitCallback(onLeave)) {
          whenTransitionEnds(el, type, leaveDuration, resolve);
        }
      });
      runtime_dom_esm_bundler_callHook(onLeave, [el, resolve]);
    },
    onEnterCancelled(el) {
      finishEnter(el, false, void 0, true);
      runtime_dom_esm_bundler_callHook(onEnterCancelled, [el]);
    },
    onAppearCancelled(el) {
      finishEnter(el, true, void 0, true);
      runtime_dom_esm_bundler_callHook(onAppearCancelled, [el]);
    },
    onLeaveCancelled(el) {
      finishLeave(el);
      runtime_dom_esm_bundler_callHook(onLeaveCancelled, [el]);
    }
  });
}
function normalizeDuration(duration) {
  if (duration == null) {
    return null;
  } else if (shared_esm_bundler_isObject(duration)) {
    return [NumberOf(duration.enter), NumberOf(duration.leave)];
  } else {
    const n = NumberOf(duration);
    return [n, n];
  }
}
function NumberOf(val) {
  const res = toNumber(val);
  if (false) {}
  return res;
}
function addTransitionClass(el, cls) {
  cls.split(/\s+/).forEach((c) => c && el.classList.add(c));
  (el[vtcKey] || (el[vtcKey] = /* @__PURE__ */ new Set())).add(cls);
}
function removeTransitionClass(el, cls) {
  cls.split(/\s+/).forEach((c) => c && el.classList.remove(c));
  const _vtc = el[vtcKey];
  if (_vtc) {
    _vtc.delete(cls);
    if (!_vtc.size) {
      el[vtcKey] = void 0;
    }
  }
}
function nextFrame(cb) {
  requestAnimationFrame(() => {
    requestAnimationFrame(cb);
  });
}
let endId = 0;
function whenTransitionEnds(el, expectedType, explicitTimeout, resolve) {
  const id = el._endId = ++endId;
  const resolveIfNotStale = () => {
    if (id === el._endId) {
      resolve();
    }
  };
  if (explicitTimeout != null) {
    return setTimeout(resolveIfNotStale, explicitTimeout);
  }
  const { type, timeout, propCount } = getTransitionInfo(el, expectedType);
  if (!type) {
    return resolve();
  }
  const endEvent = type + "end";
  let ended = 0;
  const end = () => {
    el.removeEventListener(endEvent, onEnd);
    resolveIfNotStale();
  };
  const onEnd = (e) => {
    if (e.target === el && ++ended >= propCount) {
      end();
    }
  };
  setTimeout(() => {
    if (ended < propCount) {
      end();
    }
  }, timeout + 1);
  el.addEventListener(endEvent, onEnd);
}
function getTransitionInfo(el, expectedType) {
  const styles = window.getComputedStyle(el);
  const getStyleProperties = (key) => (styles[key] || "").split(", ");
  const transitionDelays = getStyleProperties(`${TRANSITION}Delay`);
  const transitionDurations = getStyleProperties(`${TRANSITION}Duration`);
  const transitionTimeout = getTimeout(transitionDelays, transitionDurations);
  const animationDelays = getStyleProperties(`${ANIMATION}Delay`);
  const animationDurations = getStyleProperties(`${ANIMATION}Duration`);
  const animationTimeout = getTimeout(animationDelays, animationDurations);
  let type = null;
  let timeout = 0;
  let propCount = 0;
  if (expectedType === TRANSITION) {
    if (transitionTimeout > 0) {
      type = TRANSITION;
      timeout = transitionTimeout;
      propCount = transitionDurations.length;
    }
  } else if (expectedType === ANIMATION) {
    if (animationTimeout > 0) {
      type = ANIMATION;
      timeout = animationTimeout;
      propCount = animationDurations.length;
    }
  } else {
    timeout = Math.max(transitionTimeout, animationTimeout);
    type = timeout > 0 ? transitionTimeout > animationTimeout ? TRANSITION : ANIMATION : null;
    propCount = type ? type === TRANSITION ? transitionDurations.length : animationDurations.length : 0;
  }
  const hasTransform = type === TRANSITION && /\b(transform|all)(,|$)/.test(
    getStyleProperties(`${TRANSITION}Property`).toString()
  );
  return {
    type,
    timeout,
    propCount,
    hasTransform
  };
}
function getTimeout(delays, durations) {
  while (delays.length < durations.length) {
    delays = delays.concat(delays);
  }
  return Math.max(...durations.map((d, i) => toMs(d) + toMs(delays[i])));
}
function toMs(s) {
  if (s === "auto") return 0;
  return Number(s.slice(0, -1).replace(",", ".")) * 1e3;
}
function forceReflow() {
  return document.body.offsetHeight;
}

function patchClass(el, value, isSVG) {
  const transitionClasses = el[vtcKey];
  if (transitionClasses) {
    value = (value ? [value, ...transitionClasses] : [...transitionClasses]).join(" ");
  }
  if (value == null) {
    el.removeAttribute("class");
  } else if (isSVG) {
    el.setAttribute("class", value);
  } else {
    el.className = value;
  }
}

const vShowOriginalDisplay = Symbol("_vod");
const vShowHidden = Symbol("_vsh");
const vShow = {
  // used for prop mismatch check during hydration
  name: "show",
  beforeMount(el, { value }, { transition }) {
    el[vShowOriginalDisplay] = el.style.display === "none" ? "" : el.style.display;
    if (transition && value) {
      transition.beforeEnter(el);
    } else {
      setDisplay(el, value);
    }
  },
  mounted(el, { value }, { transition }) {
    if (transition && value) {
      transition.enter(el);
    }
  },
  updated(el, { value, oldValue }, { transition }) {
    if (!value === !oldValue) return;
    if (transition) {
      if (value) {
        transition.beforeEnter(el);
        setDisplay(el, true);
        transition.enter(el);
      } else {
        transition.leave(el, () => {
          setDisplay(el, false);
        });
      }
    } else {
      setDisplay(el, value);
    }
  },
  beforeUnmount(el, { value }) {
    setDisplay(el, value);
  }
};
function setDisplay(el, value) {
  el.style.display = value ? el[vShowOriginalDisplay] : "none";
  el[vShowHidden] = !value;
}
function initVShowForSSR() {
  vShow.getSSRProps = ({ value }) => {
    if (!value) {
      return { style: { display: "none" } };
    }
  };
}

const CSS_VAR_TEXT = Symbol( false ? 0 : "");
function useCssVars(getter) {
  const instance = getCurrentInstance();
  if (!instance) {
     false && 0;
    return;
  }
  const updateTeleports = instance.ut = (vars = getter(instance.proxy)) => {
    Array.from(
      document.querySelectorAll(`[data-v-owner="${instance.uid}"]`)
    ).forEach((node) => setVarsOnNode(node, vars));
  };
  if (false) {}
  const setVars = () => {
    const vars = getter(instance.proxy);
    if (instance.ce) {
      setVarsOnNode(instance.ce, vars);
    } else {
      setVarsOnVNode(instance.subTree, vars);
    }
    updateTeleports(vars);
  };
  onBeforeUpdate(() => {
    queuePostFlushCb(setVars);
  });
  onMounted(() => {
    watch(setVars, NOOP, { flush: "post" });
    const ob = new MutationObserver(setVars);
    ob.observe(instance.subTree.el.parentNode, { childList: true });
    onUnmounted(() => ob.disconnect());
  });
}
function setVarsOnVNode(vnode, vars) {
  if (vnode.shapeFlag & 128) {
    const suspense = vnode.suspense;
    vnode = suspense.activeBranch;
    if (suspense.pendingBranch && !suspense.isHydrating) {
      suspense.effects.push(() => {
        setVarsOnVNode(suspense.activeBranch, vars);
      });
    }
  }
  while (vnode.component) {
    vnode = vnode.component.subTree;
  }
  if (vnode.shapeFlag & 1 && vnode.el) {
    setVarsOnNode(vnode.el, vars);
  } else if (vnode.type === Fragment) {
    vnode.children.forEach((c) => setVarsOnVNode(c, vars));
  } else if (vnode.type === Static) {
    let { el, anchor } = vnode;
    while (el) {
      setVarsOnNode(el, vars);
      if (el === anchor) break;
      el = el.nextSibling;
    }
  }
}
function setVarsOnNode(el, vars) {
  if (el.nodeType === 1) {
    const style = el.style;
    let cssText = "";
    for (const key in vars) {
      const value = normalizeCssVarValue(vars[key]);
      style.setProperty(`--${key}`, value);
      cssText += `--${key}: ${value};`;
    }
    style[CSS_VAR_TEXT] = cssText;
  }
}

const displayRE = /(^|;)\s*display\s*:/;
function patchStyle(el, prev, next) {
  const style = el.style;
  const isCssString = shared_esm_bundler_isString(next);
  let hasControlledDisplay = false;
  if (next && !isCssString) {
    if (prev) {
      if (!shared_esm_bundler_isString(prev)) {
        for (const key in prev) {
          if (next[key] == null) {
            setStyle(style, key, "");
          }
        }
      } else {
        for (const prevStyle of prev.split(";")) {
          const key = prevStyle.slice(0, prevStyle.indexOf(":")).trim();
          if (next[key] == null) {
            setStyle(style, key, "");
          }
        }
      }
    }
    for (const key in next) {
      if (key === "display") {
        hasControlledDisplay = true;
      }
      setStyle(style, key, next[key]);
    }
  } else {
    if (isCssString) {
      if (prev !== next) {
        const cssVarText = style[CSS_VAR_TEXT];
        if (cssVarText) {
          next += ";" + cssVarText;
        }
        style.cssText = next;
        hasControlledDisplay = displayRE.test(next);
      }
    } else if (prev) {
      el.removeAttribute("style");
    }
  }
  if (vShowOriginalDisplay in el) {
    el[vShowOriginalDisplay] = hasControlledDisplay ? style.display : "";
    if (el[vShowHidden]) {
      style.display = "none";
    }
  }
}
const semicolonRE = /[^\\];\s*$/;
const importantRE = /\s*!important$/;
function setStyle(style, name, val) {
  if (shared_esm_bundler_isArray(val)) {
    val.forEach((v) => setStyle(style, name, v));
  } else {
    if (val == null) val = "";
    if (false) {}
    if (name.startsWith("--")) {
      style.setProperty(name, val);
    } else {
      const prefixed = autoPrefix(style, name);
      if (importantRE.test(val)) {
        style.setProperty(
          shared_esm_bundler_hyphenate(prefixed),
          val.replace(importantRE, ""),
          "important"
        );
      } else {
        style[prefixed] = val;
      }
    }
  }
}
const prefixes = ["Webkit", "Moz", "ms"];
const prefixCache = {};
function autoPrefix(style, rawName) {
  const cached = prefixCache[rawName];
  if (cached) {
    return cached;
  }
  let name = shared_esm_bundler_camelize(rawName);
  if (name !== "filter" && name in style) {
    return prefixCache[rawName] = name;
  }
  name = shared_esm_bundler_capitalize(name);
  for (let i = 0; i < prefixes.length; i++) {
    const prefixed = prefixes[i] + name;
    if (prefixed in style) {
      return prefixCache[rawName] = prefixed;
    }
  }
  return rawName;
}

const xlinkNS = "http://www.w3.org/1999/xlink";
function patchAttr(el, key, value, isSVG, instance, isBoolean = isSpecialBooleanAttr(key)) {
  if (isSVG && key.startsWith("xlink:")) {
    if (value == null) {
      el.removeAttributeNS(xlinkNS, key.slice(6, key.length));
    } else {
      el.setAttributeNS(xlinkNS, key, value);
    }
  } else {
    if (value == null || isBoolean && !shared_esm_bundler_includeBooleanAttr(value)) {
      el.removeAttribute(key);
    } else {
      el.setAttribute(
        key,
        isBoolean ? "" : shared_esm_bundler_isSymbol(value) ? String(value) : value
      );
    }
  }
}

function patchDOMProp(el, key, value, parentComponent, attrName) {
  if (key === "innerHTML" || key === "textContent") {
    if (value != null) {
      el[key] = key === "innerHTML" ? unsafeToTrustedHTML(value) : value;
    }
    return;
  }
  const tag = el.tagName;
  if (key === "value" && tag !== "PROGRESS" && // custom elements may use _value internally
  !tag.includes("-")) {
    const oldValue = tag === "OPTION" ? el.getAttribute("value") || "" : el.value;
    const newValue = value == null ? (
      // #11647: value should be set as empty string for null and undefined,
      // but <input type="checkbox"> should be set as 'on'.
      el.type === "checkbox" ? "on" : ""
    ) : String(value);
    if (oldValue !== newValue || !("_value" in el)) {
      el.value = newValue;
    }
    if (value == null) {
      el.removeAttribute(key);
    }
    el._value = value;
    return;
  }
  let needRemove = false;
  if (value === "" || value == null) {
    const type = typeof el[key];
    if (type === "boolean") {
      value = shared_esm_bundler_includeBooleanAttr(value);
    } else if (value == null && type === "string") {
      value = "";
      needRemove = true;
    } else if (type === "number") {
      value = 0;
      needRemove = true;
    }
  }
  try {
    el[key] = value;
  } catch (e) {
    if (false) {}
  }
  needRemove && el.removeAttribute(attrName || key);
}

function addEventListener(el, event, handler, options) {
  el.addEventListener(event, handler, options);
}
function removeEventListener(el, event, handler, options) {
  el.removeEventListener(event, handler, options);
}
const veiKey = Symbol("_vei");
function patchEvent(el, rawName, prevValue, nextValue, instance = null) {
  const invokers = el[veiKey] || (el[veiKey] = {});
  const existingInvoker = invokers[rawName];
  if (nextValue && existingInvoker) {
    existingInvoker.value =  false ? 0 : nextValue;
  } else {
    const [name, options] = parseName(rawName);
    if (nextValue) {
      const invoker = invokers[rawName] = createInvoker(
         false ? 0 : nextValue,
        instance
      );
      addEventListener(el, name, invoker, options);
    } else if (existingInvoker) {
      removeEventListener(el, name, existingInvoker, options);
      invokers[rawName] = void 0;
    }
  }
}
const optionsModifierRE = /(?:Once|Passive|Capture)$/;
function parseName(name) {
  let options;
  if (optionsModifierRE.test(name)) {
    options = {};
    let m;
    while (m = name.match(optionsModifierRE)) {
      name = name.slice(0, name.length - m[0].length);
      options[m[0].toLowerCase()] = true;
    }
  }
  const event = name[2] === ":" ? name.slice(3) : shared_esm_bundler_hyphenate(name.slice(2));
  return [event, options];
}
let cachedNow = 0;
const p = /* @__PURE__ */ Promise.resolve();
const getNow = () => cachedNow || (p.then(() => cachedNow = 0), cachedNow = Date.now());
function createInvoker(initialValue, instance) {
  const invoker = (e) => {
    if (!e._vts) {
      e._vts = Date.now();
    } else if (e._vts <= invoker.attached) {
      return;
    }
    callWithAsyncErrorHandling(
      patchStopImmediatePropagation(e, invoker.value),
      instance,
      5,
      [e]
    );
  };
  invoker.value = initialValue;
  invoker.attached = getNow();
  return invoker;
}
function sanitizeEventValue(value, propName) {
  if (isFunction(value) || isArray(value)) {
    return value;
  }
  warn(
    `Wrong type passed as event handler to ${propName} - did you forget @ or : in front of your prop?
Expected function or array of functions, received type ${typeof value}.`
  );
  return NOOP;
}
function patchStopImmediatePropagation(e, value) {
  if (shared_esm_bundler_isArray(value)) {
    const originalStop = e.stopImmediatePropagation;
    e.stopImmediatePropagation = () => {
      originalStop.call(e);
      e._stopped = true;
    };
    return value.map(
      (fn) => (e2) => !e2._stopped && fn && fn(e2)
    );
  } else {
    return value;
  }
}

const isNativeOn = (key) => key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && // lowercase letter
key.charCodeAt(2) > 96 && key.charCodeAt(2) < 123;
const patchProp = (el, key, prevValue, nextValue, namespace, parentComponent) => {
  const isSVG = namespace === "svg";
  if (key === "class") {
    patchClass(el, nextValue, isSVG);
  } else if (key === "style") {
    patchStyle(el, prevValue, nextValue);
  } else if (shared_esm_bundler_isOn(key)) {
    if (!isModelListener(key)) {
      patchEvent(el, key, prevValue, nextValue, parentComponent);
    }
  } else if (key[0] === "." ? (key = key.slice(1), true) : key[0] === "^" ? (key = key.slice(1), false) : shouldSetAsProp(el, key, nextValue, isSVG)) {
    patchDOMProp(el, key, nextValue);
    if (!el.tagName.includes("-") && (key === "value" || key === "checked" || key === "selected")) {
      patchAttr(el, key, nextValue, isSVG, parentComponent, key !== "value");
    }
  } else if (
    // #11081 force set props for possible async custom element
    el._isVueCE && (/[A-Z]/.test(key) || !shared_esm_bundler_isString(nextValue))
  ) {
    patchDOMProp(el, shared_esm_bundler_camelize(key), nextValue, parentComponent, key);
  } else {
    if (key === "true-value") {
      el._trueValue = nextValue;
    } else if (key === "false-value") {
      el._falseValue = nextValue;
    }
    patchAttr(el, key, nextValue, isSVG);
  }
};
function shouldSetAsProp(el, key, value, isSVG) {
  if (isSVG) {
    if (key === "innerHTML" || key === "textContent") {
      return true;
    }
    if (key in el && isNativeOn(key) && shared_esm_bundler_isFunction(value)) {
      return true;
    }
    return false;
  }
  if (key === "spellcheck" || key === "draggable" || key === "translate" || key === "autocorrect") {
    return false;
  }
  if (key === "form") {
    return false;
  }
  if (key === "list" && el.tagName === "INPUT") {
    return false;
  }
  if (key === "type" && el.tagName === "TEXTAREA") {
    return false;
  }
  if (key === "width" || key === "height") {
    const tag = el.tagName;
    if (tag === "IMG" || tag === "VIDEO" || tag === "CANVAS" || tag === "SOURCE") {
      return false;
    }
  }
  if (isNativeOn(key) && shared_esm_bundler_isString(value)) {
    return false;
  }
  return key in el;
}

const REMOVAL = {};
/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function defineCustomElement(options, extraOptions, _createApp) {
  const Comp = defineComponent(options, extraOptions);
  if (isPlainObject(Comp)) extend(Comp, extraOptions);
  class VueCustomElement extends VueElement {
    constructor(initialProps) {
      super(Comp, initialProps, _createApp);
    }
  }
  VueCustomElement.def = Comp;
  return VueCustomElement;
}

const defineSSRCustomElement = (/* @__NO_SIDE_EFFECTS__ */ (options, extraOptions) => {
  return /* @__PURE__ */ defineCustomElement(options, extraOptions, createSSRApp);
});
const BaseClass = typeof HTMLElement !== "undefined" ? HTMLElement : class {
};
class VueElement extends BaseClass {
  constructor(_def, _props = {}, _createApp = createApp) {
    super();
    this._def = _def;
    this._props = _props;
    this._createApp = _createApp;
    this._isVueCE = true;
    /**
     * @internal
     */
    this._instance = null;
    /**
     * @internal
     */
    this._app = null;
    /**
     * @internal
     */
    this._nonce = this._def.nonce;
    this._connected = false;
    this._resolved = false;
    this._numberProps = null;
    this._styleChildren = /* @__PURE__ */ new WeakSet();
    this._ob = null;
    if (this.shadowRoot && _createApp !== createApp) {
      this._root = this.shadowRoot;
    } else {
      if (false) {}
      if (_def.shadowRoot !== false) {
        this.attachShadow({ mode: "open" });
        this._root = this.shadowRoot;
      } else {
        this._root = this;
      }
    }
  }
  connectedCallback() {
    if (!this.isConnected) return;
    if (!this.shadowRoot && !this._resolved) {
      this._parseSlots();
    }
    this._connected = true;
    let parent = this;
    while (parent = parent && (parent.parentNode || parent.host)) {
      if (parent instanceof VueElement) {
        this._parent = parent;
        break;
      }
    }
    if (!this._instance) {
      if (this._resolved) {
        this._mount(this._def);
      } else {
        if (parent && parent._pendingResolve) {
          this._pendingResolve = parent._pendingResolve.then(() => {
            this._pendingResolve = void 0;
            this._resolveDef();
          });
        } else {
          this._resolveDef();
        }
      }
    }
  }
  _setParent(parent = this._parent) {
    if (parent) {
      this._instance.parent = parent._instance;
      this._inheritParentContext(parent);
    }
  }
  _inheritParentContext(parent = this._parent) {
    if (parent && this._app) {
      Object.setPrototypeOf(
        this._app._context.provides,
        parent._instance.provides
      );
    }
  }
  disconnectedCallback() {
    this._connected = false;
    nextTick(() => {
      if (!this._connected) {
        if (this._ob) {
          this._ob.disconnect();
          this._ob = null;
        }
        this._app && this._app.unmount();
        if (this._instance) this._instance.ce = void 0;
        this._app = this._instance = null;
      }
    });
  }
  /**
   * resolve inner component definition (handle possible async component)
   */
  _resolveDef() {
    if (this._pendingResolve) {
      return;
    }
    for (let i = 0; i < this.attributes.length; i++) {
      this._setAttr(this.attributes[i].name);
    }
    this._ob = new MutationObserver((mutations) => {
      for (const m of mutations) {
        this._setAttr(m.attributeName);
      }
    });
    this._ob.observe(this, { attributes: true });
    const resolve = (def, isAsync = false) => {
      this._resolved = true;
      this._pendingResolve = void 0;
      const { props, styles } = def;
      let numberProps;
      if (props && !shared_esm_bundler_isArray(props)) {
        for (const key in props) {
          const opt = props[key];
          if (opt === Number || opt && opt.type === Number) {
            if (key in this._props) {
              this._props[key] = toNumber(this._props[key]);
            }
            (numberProps || (numberProps = /* @__PURE__ */ Object.create(null)))[shared_esm_bundler_camelize(key)] = true;
          }
        }
      }
      this._numberProps = numberProps;
      this._resolveProps(def);
      if (this.shadowRoot) {
        this._applyStyles(styles);
      } else if (false) {}
      this._mount(def);
    };
    const asyncDef = this._def.__asyncLoader;
    if (asyncDef) {
      this._pendingResolve = asyncDef().then((def) => {
        def.configureApp = this._def.configureApp;
        resolve(this._def = def, true);
      });
    } else {
      resolve(this._def);
    }
  }
  _mount(def) {
    if (false) {}
    this._app = this._createApp(def);
    this._inheritParentContext();
    if (def.configureApp) {
      def.configureApp(this._app);
    }
    this._app._ceVNode = this._createVNode();
    this._app.mount(this._root);
    const exposed = this._instance && this._instance.exposed;
    if (!exposed) return;
    for (const key in exposed) {
      if (!hasOwn(this, key)) {
        Object.defineProperty(this, key, {
          // unwrap ref to be consistent with public instance behavior
          get: () => reactivity_esm_bundler_unref(exposed[key])
        });
      } else if (false) {}
    }
  }
  _resolveProps(def) {
    const { props } = def;
    const declaredPropKeys = shared_esm_bundler_isArray(props) ? props : Object.keys(props || {});
    for (const key of Object.keys(this)) {
      if (key[0] !== "_" && declaredPropKeys.includes(key)) {
        this._setProp(key, this[key]);
      }
    }
    for (const key of declaredPropKeys.map(shared_esm_bundler_camelize)) {
      Object.defineProperty(this, key, {
        get() {
          return this._getProp(key);
        },
        set(val) {
          this._setProp(key, val, true, true);
        }
      });
    }
  }
  _setAttr(key) {
    if (key.startsWith("data-v-")) return;
    const has = this.hasAttribute(key);
    let value = has ? this.getAttribute(key) : REMOVAL;
    const camelKey = shared_esm_bundler_camelize(key);
    if (has && this._numberProps && this._numberProps[camelKey]) {
      value = toNumber(value);
    }
    this._setProp(camelKey, value, false, true);
  }
  /**
   * @internal
   */
  _getProp(key) {
    return this._props[key];
  }
  /**
   * @internal
   */
  _setProp(key, val, shouldReflect = true, shouldUpdate = false) {
    if (val !== this._props[key]) {
      if (val === REMOVAL) {
        delete this._props[key];
      } else {
        this._props[key] = val;
        if (key === "key" && this._app) {
          this._app._ceVNode.key = val;
        }
      }
      if (shouldUpdate && this._instance) {
        this._update();
      }
      if (shouldReflect) {
        const ob = this._ob;
        ob && ob.disconnect();
        if (val === true) {
          this.setAttribute(shared_esm_bundler_hyphenate(key), "");
        } else if (typeof val === "string" || typeof val === "number") {
          this.setAttribute(shared_esm_bundler_hyphenate(key), val + "");
        } else if (!val) {
          this.removeAttribute(shared_esm_bundler_hyphenate(key));
        }
        ob && ob.observe(this, { attributes: true });
      }
    }
  }
  _update() {
    const vnode = this._createVNode();
    if (this._app) vnode.appContext = this._app._context;
    render(vnode, this._root);
  }
  _createVNode() {
    const baseProps = {};
    if (!this.shadowRoot) {
      baseProps.onVnodeMounted = baseProps.onVnodeUpdated = this._renderSlots.bind(this);
    }
    const vnode = createVNode(this._def, shared_esm_bundler_extend(baseProps, this._props));
    if (!this._instance) {
      vnode.ce = (instance) => {
        this._instance = instance;
        instance.ce = this;
        instance.isCE = true;
        if (false) {}
        const dispatch = (event, args) => {
          this.dispatchEvent(
            new CustomEvent(
              event,
              shared_esm_bundler_isPlainObject(args[0]) ? shared_esm_bundler_extend({ detail: args }, args[0]) : { detail: args }
            )
          );
        };
        instance.emit = (event, ...args) => {
          dispatch(event, args);
          if (shared_esm_bundler_hyphenate(event) !== event) {
            dispatch(shared_esm_bundler_hyphenate(event), args);
          }
        };
        this._setParent();
      };
    }
    return vnode;
  }
  _applyStyles(styles, owner) {
    if (!styles) return;
    if (owner) {
      if (owner === this._def || this._styleChildren.has(owner)) {
        return;
      }
      this._styleChildren.add(owner);
    }
    const nonce = this._nonce;
    for (let i = styles.length - 1; i >= 0; i--) {
      const s = document.createElement("style");
      if (nonce) s.setAttribute("nonce", nonce);
      s.textContent = styles[i];
      this.shadowRoot.prepend(s);
      if (false) {}
    }
  }
  /**
   * Only called when shadowRoot is false
   */
  _parseSlots() {
    const slots = this._slots = {};
    let n;
    while (n = this.firstChild) {
      const slotName = n.nodeType === 1 && n.getAttribute("slot") || "default";
      (slots[slotName] || (slots[slotName] = [])).push(n);
      this.removeChild(n);
    }
  }
  /**
   * Only called when shadowRoot is false
   */
  _renderSlots() {
    const outlets = (this._teleportTarget || this).querySelectorAll("slot");
    const scopeId = this._instance.type.__scopeId;
    for (let i = 0; i < outlets.length; i++) {
      const o = outlets[i];
      const slotName = o.getAttribute("name") || "default";
      const content = this._slots[slotName];
      const parent = o.parentNode;
      if (content) {
        for (const n of content) {
          if (scopeId && n.nodeType === 1) {
            const id = scopeId + "-s";
            const walker = document.createTreeWalker(n, 1);
            n.setAttribute(id, "");
            let child;
            while (child = walker.nextNode()) {
              child.setAttribute(id, "");
            }
          }
          parent.insertBefore(n, o);
        }
      } else {
        while (o.firstChild) parent.insertBefore(o.firstChild, o);
      }
      parent.removeChild(o);
    }
  }
  /**
   * @internal
   */
  _injectChildStyle(comp) {
    this._applyStyles(comp.styles, comp);
  }
  /**
   * @internal
   */
  _removeChildStyle(comp) {
    if (false) {}
  }
}
function useHost(caller) {
  const instance = getCurrentInstance();
  const el = instance && instance.ce;
  if (el) {
    return el;
  } else if (false) {}
  return null;
}
function useShadowRoot() {
  const el =  false ? 0 : useHost();
  return el && el.shadowRoot;
}

function useCssModule(name = "$style") {
  {
    const instance = getCurrentInstance();
    if (!instance) {
       false && 0;
      return EMPTY_OBJ;
    }
    const modules = instance.type.__cssModules;
    if (!modules) {
       false && 0;
      return EMPTY_OBJ;
    }
    const mod = modules[name];
    if (!mod) {
       false && 0;
      return EMPTY_OBJ;
    }
    return mod;
  }
}

const positionMap = /* @__PURE__ */ new WeakMap();
const newPositionMap = /* @__PURE__ */ new WeakMap();
const moveCbKey = Symbol("_moveCb");
const runtime_dom_esm_bundler_enterCbKey = Symbol("_enterCb");
const decorate = (t) => {
  delete t.props.mode;
  return t;
};
const TransitionGroupImpl = /* @__PURE__ */ decorate({
  name: "TransitionGroup",
  props: /* @__PURE__ */ shared_esm_bundler_extend({}, TransitionPropsValidators, {
    tag: String,
    moveClass: String
  }),
  setup(props, { slots }) {
    const instance = runtime_core_esm_bundler_getCurrentInstance();
    const state = useTransitionState();
    let prevChildren;
    let children;
    onUpdated(() => {
      if (!prevChildren.length) {
        return;
      }
      const moveClass = props.moveClass || `${props.name || "v"}-move`;
      if (!hasCSSTransform(
        prevChildren[0].el,
        instance.vnode.el,
        moveClass
      )) {
        prevChildren = [];
        return;
      }
      prevChildren.forEach(callPendingCbs);
      prevChildren.forEach(recordPosition);
      const movedChildren = prevChildren.filter(applyTranslation);
      forceReflow();
      movedChildren.forEach((c) => {
        const el = c.el;
        const style = el.style;
        addTransitionClass(el, moveClass);
        style.transform = style.webkitTransform = style.transitionDuration = "";
        const cb = el[moveCbKey] = (e) => {
          if (e && e.target !== el) {
            return;
          }
          if (!e || /transform$/.test(e.propertyName)) {
            el.removeEventListener("transitionend", cb);
            el[moveCbKey] = null;
            removeTransitionClass(el, moveClass);
          }
        };
        el.addEventListener("transitionend", cb);
      });
      prevChildren = [];
    });
    return () => {
      const rawProps = reactivity_esm_bundler_toRaw(props);
      const cssTransitionProps = resolveTransitionProps(rawProps);
      let tag = rawProps.tag || runtime_core_esm_bundler_Fragment;
      prevChildren = [];
      if (children) {
        for (let i = 0; i < children.length; i++) {
          const child = children[i];
          if (child.el && child.el instanceof Element) {
            prevChildren.push(child);
            setTransitionHooks(
              child,
              resolveTransitionHooks(
                child,
                cssTransitionProps,
                state,
                instance
              )
            );
            positionMap.set(
              child,
              child.el.getBoundingClientRect()
            );
          }
        }
      }
      children = slots.default ? getTransitionRawChildren(slots.default()) : [];
      for (let i = 0; i < children.length; i++) {
        const child = children[i];
        if (child.key != null) {
          setTransitionHooks(
            child,
            resolveTransitionHooks(child, cssTransitionProps, state, instance)
          );
        } else if (false) {}
      }
      return createVNode(tag, null, children);
    };
  }
});
const TransitionGroup = (/* unused pure expression or super */ null && (TransitionGroupImpl));
function callPendingCbs(c) {
  const el = c.el;
  if (el[moveCbKey]) {
    el[moveCbKey]();
  }
  if (el[runtime_dom_esm_bundler_enterCbKey]) {
    el[runtime_dom_esm_bundler_enterCbKey]();
  }
}
function recordPosition(c) {
  newPositionMap.set(c, c.el.getBoundingClientRect());
}
function applyTranslation(c) {
  const oldPos = positionMap.get(c);
  const newPos = newPositionMap.get(c);
  const dx = oldPos.left - newPos.left;
  const dy = oldPos.top - newPos.top;
  if (dx || dy) {
    const s = c.el.style;
    s.transform = s.webkitTransform = `translate(${dx}px,${dy}px)`;
    s.transitionDuration = "0s";
    return c;
  }
}
function hasCSSTransform(el, root, moveClass) {
  const clone = el.cloneNode();
  const _vtc = el[vtcKey];
  if (_vtc) {
    _vtc.forEach((cls) => {
      cls.split(/\s+/).forEach((c) => c && clone.classList.remove(c));
    });
  }
  moveClass.split(/\s+/).forEach((c) => c && clone.classList.add(c));
  clone.style.display = "none";
  const container = root.nodeType === 1 ? root : root.parentNode;
  container.appendChild(clone);
  const { hasTransform } = getTransitionInfo(clone);
  container.removeChild(clone);
  return hasTransform;
}

const getModelAssigner = (vnode) => {
  const fn = vnode.props["onUpdate:modelValue"] || false;
  return shared_esm_bundler_isArray(fn) ? (value) => invokeArrayFns(fn, value) : fn;
};
function onCompositionStart(e) {
  e.target.composing = true;
}
function onCompositionEnd(e) {
  const target = e.target;
  if (target.composing) {
    target.composing = false;
    target.dispatchEvent(new Event("input"));
  }
}
const assignKey = Symbol("_assign");
const vModelText = {
  created(el, { modifiers: { lazy, trim, number } }, vnode) {
    el[assignKey] = getModelAssigner(vnode);
    const castToNumber = number || vnode.props && vnode.props.type === "number";
    addEventListener(el, lazy ? "change" : "input", (e) => {
      if (e.target.composing) return;
      let domValue = el.value;
      if (trim) {
        domValue = domValue.trim();
      }
      if (castToNumber) {
        domValue = looseToNumber(domValue);
      }
      el[assignKey](domValue);
    });
    if (trim) {
      addEventListener(el, "change", () => {
        el.value = el.value.trim();
      });
    }
    if (!lazy) {
      addEventListener(el, "compositionstart", onCompositionStart);
      addEventListener(el, "compositionend", onCompositionEnd);
      addEventListener(el, "change", onCompositionEnd);
    }
  },
  // set value on mounted so it's after min/max for type="range"
  mounted(el, { value }) {
    el.value = value == null ? "" : value;
  },
  beforeUpdate(el, { value, oldValue, modifiers: { lazy, trim, number } }, vnode) {
    el[assignKey] = getModelAssigner(vnode);
    if (el.composing) return;
    const elValue = (number || el.type === "number") && !/^0\d/.test(el.value) ? looseToNumber(el.value) : el.value;
    const newValue = value == null ? "" : value;
    if (elValue === newValue) {
      return;
    }
    if (document.activeElement === el && el.type !== "range") {
      if (lazy && value === oldValue) {
        return;
      }
      if (trim && el.value.trim() === newValue) {
        return;
      }
    }
    el.value = newValue;
  }
};
const vModelCheckbox = {
  // #4096 array checkboxes need to be deep traversed
  deep: true,
  created(el, _, vnode) {
    el[assignKey] = getModelAssigner(vnode);
    addEventListener(el, "change", () => {
      const modelValue = el._modelValue;
      const elementValue = getValue(el);
      const checked = el.checked;
      const assign = el[assignKey];
      if (shared_esm_bundler_isArray(modelValue)) {
        const index = shared_esm_bundler_looseIndexOf(modelValue, elementValue);
        const found = index !== -1;
        if (checked && !found) {
          assign(modelValue.concat(elementValue));
        } else if (!checked && found) {
          const filtered = [...modelValue];
          filtered.splice(index, 1);
          assign(filtered);
        }
      } else if (shared_esm_bundler_isSet(modelValue)) {
        const cloned = new Set(modelValue);
        if (checked) {
          cloned.add(elementValue);
        } else {
          cloned.delete(elementValue);
        }
        assign(cloned);
      } else {
        assign(getCheckboxValue(el, checked));
      }
    });
  },
  // set initial checked on mount to wait for true-value/false-value
  mounted: setChecked,
  beforeUpdate(el, binding, vnode) {
    el[assignKey] = getModelAssigner(vnode);
    setChecked(el, binding, vnode);
  }
};
function setChecked(el, { value, oldValue }, vnode) {
  el._modelValue = value;
  let checked;
  if (shared_esm_bundler_isArray(value)) {
    checked = shared_esm_bundler_looseIndexOf(value, vnode.props.value) > -1;
  } else if (shared_esm_bundler_isSet(value)) {
    checked = value.has(vnode.props.value);
  } else {
    if (value === oldValue) return;
    checked = shared_esm_bundler_looseEqual(value, getCheckboxValue(el, true));
  }
  if (el.checked !== checked) {
    el.checked = checked;
  }
}
const vModelRadio = {
  created(el, { value }, vnode) {
    el.checked = shared_esm_bundler_looseEqual(value, vnode.props.value);
    el[assignKey] = getModelAssigner(vnode);
    addEventListener(el, "change", () => {
      el[assignKey](getValue(el));
    });
  },
  beforeUpdate(el, { value, oldValue }, vnode) {
    el[assignKey] = getModelAssigner(vnode);
    if (value !== oldValue) {
      el.checked = shared_esm_bundler_looseEqual(value, vnode.props.value);
    }
  }
};
const vModelSelect = {
  // <select multiple> value need to be deep traversed
  deep: true,
  created(el, { value, modifiers: { number } }, vnode) {
    const isSetModel = shared_esm_bundler_isSet(value);
    addEventListener(el, "change", () => {
      const selectedVal = Array.prototype.filter.call(el.options, (o) => o.selected).map(
        (o) => number ? looseToNumber(getValue(o)) : getValue(o)
      );
      el[assignKey](
        el.multiple ? isSetModel ? new Set(selectedVal) : selectedVal : selectedVal[0]
      );
      el._assigning = true;
      nextTick(() => {
        el._assigning = false;
      });
    });
    el[assignKey] = getModelAssigner(vnode);
  },
  // set value in mounted & updated because <select> relies on its children
  // <option>s.
  mounted(el, { value }) {
    setSelected(el, value);
  },
  beforeUpdate(el, _binding, vnode) {
    el[assignKey] = getModelAssigner(vnode);
  },
  updated(el, { value }) {
    if (!el._assigning) {
      setSelected(el, value);
    }
  }
};
function setSelected(el, value) {
  const isMultiple = el.multiple;
  const isArrayValue = shared_esm_bundler_isArray(value);
  if (isMultiple && !isArrayValue && !shared_esm_bundler_isSet(value)) {
     false && 0;
    return;
  }
  for (let i = 0, l = el.options.length; i < l; i++) {
    const option = el.options[i];
    const optionValue = getValue(option);
    if (isMultiple) {
      if (isArrayValue) {
        const optionType = typeof optionValue;
        if (optionType === "string" || optionType === "number") {
          option.selected = value.some((v) => String(v) === String(optionValue));
        } else {
          option.selected = shared_esm_bundler_looseIndexOf(value, optionValue) > -1;
        }
      } else {
        option.selected = value.has(optionValue);
      }
    } else if (shared_esm_bundler_looseEqual(getValue(option), value)) {
      if (el.selectedIndex !== i) el.selectedIndex = i;
      return;
    }
  }
  if (!isMultiple && el.selectedIndex !== -1) {
    el.selectedIndex = -1;
  }
}
function getValue(el) {
  return "_value" in el ? el._value : el.value;
}
function getCheckboxValue(el, checked) {
  const key = checked ? "_trueValue" : "_falseValue";
  return key in el ? el[key] : checked;
}
const vModelDynamic = {
  created(el, binding, vnode) {
    callModelHook(el, binding, vnode, null, "created");
  },
  mounted(el, binding, vnode) {
    callModelHook(el, binding, vnode, null, "mounted");
  },
  beforeUpdate(el, binding, vnode, prevVNode) {
    callModelHook(el, binding, vnode, prevVNode, "beforeUpdate");
  },
  updated(el, binding, vnode, prevVNode) {
    callModelHook(el, binding, vnode, prevVNode, "updated");
  }
};
function resolveDynamicModel(tagName, type) {
  switch (tagName) {
    case "SELECT":
      return vModelSelect;
    case "TEXTAREA":
      return vModelText;
    default:
      switch (type) {
        case "checkbox":
          return vModelCheckbox;
        case "radio":
          return vModelRadio;
        default:
          return vModelText;
      }
  }
}
function callModelHook(el, binding, vnode, prevVNode, hook) {
  const modelToUse = resolveDynamicModel(
    el.tagName,
    vnode.props && vnode.props.type
  );
  const fn = modelToUse[hook];
  fn && fn(el, binding, vnode, prevVNode);
}
function initVModelForSSR() {
  vModelText.getSSRProps = ({ value }) => ({ value });
  vModelRadio.getSSRProps = ({ value }, vnode) => {
    if (vnode.props && looseEqual(vnode.props.value, value)) {
      return { checked: true };
    }
  };
  vModelCheckbox.getSSRProps = ({ value }, vnode) => {
    if (isArray(value)) {
      if (vnode.props && looseIndexOf(value, vnode.props.value) > -1) {
        return { checked: true };
      }
    } else if (isSet(value)) {
      if (vnode.props && value.has(vnode.props.value)) {
        return { checked: true };
      }
    } else if (value) {
      return { checked: true };
    }
  };
  vModelDynamic.getSSRProps = (binding, vnode) => {
    if (typeof vnode.type !== "string") {
      return;
    }
    const modelToUse = resolveDynamicModel(
      // resolveDynamicModel expects an uppercase tag name, but vnode.type is lowercase
      vnode.type.toUpperCase(),
      vnode.props && vnode.props.type
    );
    if (modelToUse.getSSRProps) {
      return modelToUse.getSSRProps(binding, vnode);
    }
  };
}

const systemModifiers = ["ctrl", "shift", "alt", "meta"];
const modifierGuards = {
  stop: (e) => e.stopPropagation(),
  prevent: (e) => e.preventDefault(),
  self: (e) => e.target !== e.currentTarget,
  ctrl: (e) => !e.ctrlKey,
  shift: (e) => !e.shiftKey,
  alt: (e) => !e.altKey,
  meta: (e) => !e.metaKey,
  left: (e) => "button" in e && e.button !== 0,
  middle: (e) => "button" in e && e.button !== 1,
  right: (e) => "button" in e && e.button !== 2,
  exact: (e, modifiers) => systemModifiers.some((m) => e[`${m}Key`] && !modifiers.includes(m))
};
const withModifiers = (fn, modifiers) => {
  const cache = fn._withMods || (fn._withMods = {});
  const cacheKey = modifiers.join(".");
  return cache[cacheKey] || (cache[cacheKey] = ((event, ...args) => {
    for (let i = 0; i < modifiers.length; i++) {
      const guard = modifierGuards[modifiers[i]];
      if (guard && guard(event, modifiers)) return;
    }
    return fn(event, ...args);
  }));
};
const keyNames = {
  esc: "escape",
  space: " ",
  up: "arrow-up",
  left: "arrow-left",
  right: "arrow-right",
  down: "arrow-down",
  delete: "backspace"
};
const withKeys = (fn, modifiers) => {
  const cache = fn._withKeys || (fn._withKeys = {});
  const cacheKey = modifiers.join(".");
  return cache[cacheKey] || (cache[cacheKey] = ((event) => {
    if (!("key" in event)) {
      return;
    }
    const eventKey = shared_esm_bundler_hyphenate(event.key);
    if (modifiers.some(
      (k) => k === eventKey || keyNames[k] === eventKey
    )) {
      return fn(event);
    }
  }));
};

const rendererOptions = /* @__PURE__ */ shared_esm_bundler_extend({ patchProp }, nodeOps);
let renderer;
let enabledHydration = false;
function ensureRenderer() {
  return renderer || (renderer = createRenderer(rendererOptions));
}
function ensureHydrationRenderer() {
  renderer = enabledHydration ? renderer : createHydrationRenderer(rendererOptions);
  enabledHydration = true;
  return renderer;
}
const render = ((...args) => {
  ensureRenderer().render(...args);
});
const hydrate = ((...args) => {
  ensureHydrationRenderer().hydrate(...args);
});
const createApp = ((...args) => {
  const app = ensureRenderer().createApp(...args);
  if (false) {}
  const { mount } = app;
  app.mount = (containerOrSelector) => {
    const container = normalizeContainer(containerOrSelector);
    if (!container) return;
    const component = app._component;
    if (!shared_esm_bundler_isFunction(component) && !component.render && !component.template) {
      component.template = container.innerHTML;
    }
    if (container.nodeType === 1) {
      container.textContent = "";
    }
    const proxy = mount(container, false, resolveRootNamespace(container));
    if (container instanceof Element) {
      container.removeAttribute("v-cloak");
      container.setAttribute("data-v-app", "");
    }
    return proxy;
  };
  return app;
});
const createSSRApp = ((...args) => {
  const app = ensureHydrationRenderer().createApp(...args);
  if (false) {}
  const { mount } = app;
  app.mount = (containerOrSelector) => {
    const container = normalizeContainer(containerOrSelector);
    if (container) {
      return mount(container, true, resolveRootNamespace(container));
    }
  };
  return app;
});
function resolveRootNamespace(container) {
  if (container instanceof SVGElement) {
    return "svg";
  }
  if (typeof MathMLElement === "function" && container instanceof MathMLElement) {
    return "mathml";
  }
}
function injectNativeTagCheck(app) {
  Object.defineProperty(app.config, "isNativeTag", {
    value: (tag) => isHTMLTag(tag) || isSVGTag(tag) || isMathMLTag(tag),
    writable: false
  });
}
function injectCompilerOptionsCheck(app) {
  if (isRuntimeOnly()) {
    const isCustomElement = app.config.isCustomElement;
    Object.defineProperty(app.config, "isCustomElement", {
      get() {
        return isCustomElement;
      },
      set() {
        warn(
          `The \`isCustomElement\` config option is deprecated. Use \`compilerOptions.isCustomElement\` instead.`
        );
      }
    });
    const compilerOptions = app.config.compilerOptions;
    const msg = `The \`compilerOptions\` config option is only respected when using a build of Vue.js that includes the runtime compiler (aka "full build"). Since you are using the runtime-only build, \`compilerOptions\` must be passed to \`@vue/compiler-dom\` in the build setup instead.
- For vue-loader: pass it via vue-loader's \`compilerOptions\` loader option.
- For vue-cli: see https://cli.vuejs.org/guide/webpack.html#modifying-options-of-a-loader
- For vite: pass it via @vitejs/plugin-vue options. See https://github.com/vitejs/vite-plugin-vue/tree/main/packages/plugin-vue#example-for-passing-options-to-vuecompiler-sfc`;
    Object.defineProperty(app.config, "compilerOptions", {
      get() {
        warn(msg);
        return compilerOptions;
      },
      set() {
        warn(msg);
      }
    });
  }
}
function normalizeContainer(container) {
  if (shared_esm_bundler_isString(container)) {
    const res = document.querySelector(container);
    if (false) {}
    return res;
  }
  if (false) {}
  return container;
}
let ssrDirectiveInitialized = false;
const initDirectivesForSSR = () => {
  if (!ssrDirectiveInitialized) {
    ssrDirectiveInitialized = true;
    initVModelForSSR();
    initVShowForSSR();
  }
} ;



;// CONCATENATED MODULE: ./node_modules/vue-router/dist/vue-router.mjs
/*!
  * vue-router v4.5.1
  * (c) 2025 Eduardo San Martin Morote
  * @license MIT
  */



const isBrowser = typeof document !== 'undefined';

/**
 * Allows differentiating lazy components from functional components and vue-class-component
 * @internal
 *
 * @param component
 */
function isRouteComponent(component) {
    return (typeof component === 'object' ||
        'displayName' in component ||
        'props' in component ||
        '__vccOpts' in component);
}
function isESModule(obj) {
    return (obj.__esModule ||
        obj[Symbol.toStringTag] === 'Module' ||
        // support CF with dynamic imports that do not
        // add the Module string tag
        (obj.default && isRouteComponent(obj.default)));
}
const vue_router_assign = Object.assign;
function applyToParams(fn, params) {
    const newParams = {};
    for (const key in params) {
        const value = params[key];
        newParams[key] = vue_router_isArray(value)
            ? value.map(fn)
            : fn(value);
    }
    return newParams;
}
const noop = () => { };
/**
 * Typesafe alternative to Array.isArray
 * https://github.com/microsoft/TypeScript/pull/48228
 */
const vue_router_isArray = Array.isArray;

function vue_router_warn(msg) {
    // avoid using ...args as it breaks in older Edge builds
    const args = Array.from(arguments).slice(1);
    console.warn.apply(console, ['[Vue Router warn]: ' + msg].concat(args));
}

/**
 * Encoding Rules (␣ = Space)
 * - Path: ␣ " < > # ? { }
 * - Query: ␣ " < > # & =
 * - Hash: ␣ " < > `
 *
 * On top of that, the RFC3986 (https://tools.ietf.org/html/rfc3986#section-2.2)
 * defines some extra characters to be encoded. Most browsers do not encode them
 * in encodeURI https://github.com/whatwg/url/issues/369, so it may be safer to
 * also encode `!'()*`. Leaving un-encoded only ASCII alphanumeric(`a-zA-Z0-9`)
 * plus `-._~`. This extra safety should be applied to query by patching the
 * string returned by encodeURIComponent encodeURI also encodes `[\]^`. `\`
 * should be encoded to avoid ambiguity. Browsers (IE, FF, C) transform a `\`
 * into a `/` if directly typed in. The _backtick_ (`````) should also be
 * encoded everywhere because some browsers like FF encode it when directly
 * written while others don't. Safari and IE don't encode ``"<>{}``` in hash.
 */
// const EXTRA_RESERVED_RE = /[!'()*]/g
// const encodeReservedReplacer = (c: string) => '%' + c.charCodeAt(0).toString(16)
const HASH_RE = /#/g; // %23
const AMPERSAND_RE = /&/g; // %26
const SLASH_RE = /\//g; // %2F
const EQUAL_RE = /=/g; // %3D
const IM_RE = /\?/g; // %3F
const PLUS_RE = /\+/g; // %2B
/**
 * NOTE: It's not clear to me if we should encode the + symbol in queries, it
 * seems to be less flexible than not doing so and I can't find out the legacy
 * systems requiring this for regular requests like text/html. In the standard,
 * the encoding of the plus character is only mentioned for
 * application/x-www-form-urlencoded
 * (https://url.spec.whatwg.org/#urlencoded-parsing) and most browsers seems lo
 * leave the plus character as is in queries. To be more flexible, we allow the
 * plus character on the query, but it can also be manually encoded by the user.
 *
 * Resources:
 * - https://url.spec.whatwg.org/#urlencoded-parsing
 * - https://stackoverflow.com/questions/1634271/url-encoding-the-space-character-or-20
 */
const ENC_BRACKET_OPEN_RE = /%5B/g; // [
const ENC_BRACKET_CLOSE_RE = /%5D/g; // ]
const ENC_CARET_RE = /%5E/g; // ^
const ENC_BACKTICK_RE = /%60/g; // `
const ENC_CURLY_OPEN_RE = /%7B/g; // {
const ENC_PIPE_RE = /%7C/g; // |
const ENC_CURLY_CLOSE_RE = /%7D/g; // }
const ENC_SPACE_RE = /%20/g; // }
/**
 * Encode characters that need to be encoded on the path, search and hash
 * sections of the URL.
 *
 * @internal
 * @param text - string to encode
 * @returns encoded string
 */
function commonEncode(text) {
    return encodeURI('' + text)
        .replace(ENC_PIPE_RE, '|')
        .replace(ENC_BRACKET_OPEN_RE, '[')
        .replace(ENC_BRACKET_CLOSE_RE, ']');
}
/**
 * Encode characters that need to be encoded on the hash section of the URL.
 *
 * @param text - string to encode
 * @returns encoded string
 */
function encodeHash(text) {
    return commonEncode(text)
        .replace(ENC_CURLY_OPEN_RE, '{')
        .replace(ENC_CURLY_CLOSE_RE, '}')
        .replace(ENC_CARET_RE, '^');
}
/**
 * Encode characters that need to be encoded query values on the query
 * section of the URL.
 *
 * @param text - string to encode
 * @returns encoded string
 */
function encodeQueryValue(text) {
    return (commonEncode(text)
        // Encode the space as +, encode the + to differentiate it from the space
        .replace(PLUS_RE, '%2B')
        .replace(ENC_SPACE_RE, '+')
        .replace(HASH_RE, '%23')
        .replace(AMPERSAND_RE, '%26')
        .replace(ENC_BACKTICK_RE, '`')
        .replace(ENC_CURLY_OPEN_RE, '{')
        .replace(ENC_CURLY_CLOSE_RE, '}')
        .replace(ENC_CARET_RE, '^'));
}
/**
 * Like `encodeQueryValue` but also encodes the `=` character.
 *
 * @param text - string to encode
 */
function encodeQueryKey(text) {
    return encodeQueryValue(text).replace(EQUAL_RE, '%3D');
}
/**
 * Encode characters that need to be encoded on the path section of the URL.
 *
 * @param text - string to encode
 * @returns encoded string
 */
function encodePath(text) {
    return commonEncode(text).replace(HASH_RE, '%23').replace(IM_RE, '%3F');
}
/**
 * Encode characters that need to be encoded on the path section of the URL as a
 * param. This function encodes everything {@link encodePath} does plus the
 * slash (`/`) character. If `text` is `null` or `undefined`, returns an empty
 * string instead.
 *
 * @param text - string to encode
 * @returns encoded string
 */
function encodeParam(text) {
    return text == null ? '' : encodePath(text).replace(SLASH_RE, '%2F');
}
/**
 * Decode text using `decodeURIComponent`. Returns the original text if it
 * fails.
 *
 * @param text - string to decode
 * @returns decoded string
 */
function decode(text) {
    try {
        return decodeURIComponent('' + text);
    }
    catch (err) {
        ( false) && 0;
    }
    return '' + text;
}

const TRAILING_SLASH_RE = /\/$/;
const removeTrailingSlash = (path) => path.replace(TRAILING_SLASH_RE, '');
/**
 * Transforms a URI into a normalized history location
 *
 * @param parseQuery
 * @param location - URI to normalize
 * @param currentLocation - current absolute location. Allows resolving relative
 * paths. Must start with `/`. Defaults to `/`
 * @returns a normalized history location
 */
function parseURL(parseQuery, location, currentLocation = '/') {
    let path, query = {}, searchString = '', hash = '';
    // Could use URL and URLSearchParams but IE 11 doesn't support it
    // TODO: move to new URL()
    const hashPos = location.indexOf('#');
    let searchPos = location.indexOf('?');
    // the hash appears before the search, so it's not part of the search string
    if (hashPos < searchPos && hashPos >= 0) {
        searchPos = -1;
    }
    if (searchPos > -1) {
        path = location.slice(0, searchPos);
        searchString = location.slice(searchPos + 1, hashPos > -1 ? hashPos : location.length);
        query = parseQuery(searchString);
    }
    if (hashPos > -1) {
        path = path || location.slice(0, hashPos);
        // keep the # character
        hash = location.slice(hashPos, location.length);
    }
    // no search and no query
    path = resolveRelativePath(path != null ? path : location, currentLocation);
    // empty path means a relative query or hash `?foo=f`, `#thing`
    return {
        fullPath: path + (searchString && '?') + searchString + hash,
        path,
        query,
        hash: decode(hash),
    };
}
/**
 * Stringifies a URL object
 *
 * @param stringifyQuery
 * @param location
 */
function stringifyURL(stringifyQuery, location) {
    const query = location.query ? stringifyQuery(location.query) : '';
    return location.path + (query && '?') + query + (location.hash || '');
}
/**
 * Strips off the base from the beginning of a location.pathname in a non-case-sensitive way.
 *
 * @param pathname - location.pathname
 * @param base - base to strip off
 */
function stripBase(pathname, base) {
    // no base or base is not found at the beginning
    if (!base || !pathname.toLowerCase().startsWith(base.toLowerCase()))
        return pathname;
    return pathname.slice(base.length) || '/';
}
/**
 * Checks if two RouteLocation are equal. This means that both locations are
 * pointing towards the same {@link RouteRecord} and that all `params`, `query`
 * parameters and `hash` are the same
 *
 * @param stringifyQuery - A function that takes a query object of type LocationQueryRaw and returns a string representation of it.
 * @param a - first {@link RouteLocation}
 * @param b - second {@link RouteLocation}
 */
function isSameRouteLocation(stringifyQuery, a, b) {
    const aLastIndex = a.matched.length - 1;
    const bLastIndex = b.matched.length - 1;
    return (aLastIndex > -1 &&
        aLastIndex === bLastIndex &&
        isSameRouteRecord(a.matched[aLastIndex], b.matched[bLastIndex]) &&
        isSameRouteLocationParams(a.params, b.params) &&
        stringifyQuery(a.query) === stringifyQuery(b.query) &&
        a.hash === b.hash);
}
/**
 * Check if two `RouteRecords` are equal. Takes into account aliases: they are
 * considered equal to the `RouteRecord` they are aliasing.
 *
 * @param a - first {@link RouteRecord}
 * @param b - second {@link RouteRecord}
 */
function isSameRouteRecord(a, b) {
    // since the original record has an undefined value for aliasOf
    // but all aliases point to the original record, this will always compare
    // the original record
    return (a.aliasOf || a) === (b.aliasOf || b);
}
function isSameRouteLocationParams(a, b) {
    if (Object.keys(a).length !== Object.keys(b).length)
        return false;
    for (const key in a) {
        if (!isSameRouteLocationParamsValue(a[key], b[key]))
            return false;
    }
    return true;
}
function isSameRouteLocationParamsValue(a, b) {
    return vue_router_isArray(a)
        ? isEquivalentArray(a, b)
        : vue_router_isArray(b)
            ? isEquivalentArray(b, a)
            : a === b;
}
/**
 * Check if two arrays are the same or if an array with one single entry is the
 * same as another primitive value. Used to check query and parameters
 *
 * @param a - array of values
 * @param b - array of values or a single value
 */
function isEquivalentArray(a, b) {
    return vue_router_isArray(b)
        ? a.length === b.length && a.every((value, i) => value === b[i])
        : a.length === 1 && a[0] === b;
}
/**
 * Resolves a relative path that starts with `.`.
 *
 * @param to - path location we are resolving
 * @param from - currentLocation.path, should start with `/`
 */
function resolveRelativePath(to, from) {
    if (to.startsWith('/'))
        return to;
    if (false) {}
    if (!to)
        return from;
    const fromSegments = from.split('/');
    const toSegments = to.split('/');
    const lastToSegment = toSegments[toSegments.length - 1];
    // make . and ./ the same (../ === .., ../../ === ../..)
    // this is the same behavior as new URL()
    if (lastToSegment === '..' || lastToSegment === '.') {
        toSegments.push('');
    }
    let position = fromSegments.length - 1;
    let toPosition;
    let segment;
    for (toPosition = 0; toPosition < toSegments.length; toPosition++) {
        segment = toSegments[toPosition];
        // we stay on the same position
        if (segment === '.')
            continue;
        // go up in the from array
        if (segment === '..') {
            // we can't go below zero, but we still need to increment toPosition
            if (position > 1)
                position--;
            // continue
        }
        // we reached a non-relative path, we stop here
        else
            break;
    }
    return (fromSegments.slice(0, position).join('/') +
        '/' +
        toSegments.slice(toPosition).join('/'));
}
/**
 * Initial route location where the router is. Can be used in navigation guards
 * to differentiate the initial navigation.
 *
 * @example
 * ```js
 * import { START_LOCATION } from 'vue-router'
 *
 * router.beforeEach((to, from) => {
 *   if (from === START_LOCATION) {
 *     // initial navigation
 *   }
 * })
 * ```
 */
const START_LOCATION_NORMALIZED = {
    path: '/',
    // TODO: could we use a symbol in the future?
    name: undefined,
    params: {},
    query: {},
    hash: '',
    fullPath: '/',
    matched: [],
    meta: {},
    redirectedFrom: undefined,
};

var NavigationType;
(function (NavigationType) {
    NavigationType["pop"] = "pop";
    NavigationType["push"] = "push";
})(NavigationType || (NavigationType = {}));
var NavigationDirection;
(function (NavigationDirection) {
    NavigationDirection["back"] = "back";
    NavigationDirection["forward"] = "forward";
    NavigationDirection["unknown"] = "";
})(NavigationDirection || (NavigationDirection = {}));
/**
 * Starting location for Histories
 */
const START = '';
// Generic utils
/**
 * Normalizes a base by removing any trailing slash and reading the base tag if
 * present.
 *
 * @param base - base to normalize
 */
function normalizeBase(base) {
    if (!base) {
        if (isBrowser) {
            // respect <base> tag
            const baseEl = document.querySelector('base');
            base = (baseEl && baseEl.getAttribute('href')) || '/';
            // strip full URL origin
            base = base.replace(/^\w+:\/\/[^\/]+/, '');
        }
        else {
            base = '/';
        }
    }
    // ensure leading slash when it was removed by the regex above avoid leading
    // slash with hash because the file could be read from the disk like file://
    // and the leading slash would cause problems
    if (base[0] !== '/' && base[0] !== '#')
        base = '/' + base;
    // remove the trailing slash so all other method can just do `base + fullPath`
    // to build an href
    return removeTrailingSlash(base);
}
// remove any character before the hash
const BEFORE_HASH_RE = /^[^#]+#/;
function createHref(base, location) {
    return base.replace(BEFORE_HASH_RE, '#') + location;
}

function getElementPosition(el, offset) {
    const docRect = document.documentElement.getBoundingClientRect();
    const elRect = el.getBoundingClientRect();
    return {
        behavior: offset.behavior,
        left: elRect.left - docRect.left - (offset.left || 0),
        top: elRect.top - docRect.top - (offset.top || 0),
    };
}
const computeScrollPosition = () => ({
    left: window.scrollX,
    top: window.scrollY,
});
function scrollToPosition(position) {
    let scrollToOptions;
    if ('el' in position) {
        const positionEl = position.el;
        const isIdSelector = typeof positionEl === 'string' && positionEl.startsWith('#');
        /**
         * `id`s can accept pretty much any characters, including CSS combinators
         * like `>` or `~`. It's still possible to retrieve elements using
         * `document.getElementById('~')` but it needs to be escaped when using
         * `document.querySelector('#\\~')` for it to be valid. The only
         * requirements for `id`s are them to be unique on the page and to not be
         * empty (`id=""`). Because of that, when passing an id selector, it should
         * be properly escaped for it to work with `querySelector`. We could check
         * for the id selector to be simple (no CSS combinators `+ >~`) but that
         * would make things inconsistent since they are valid characters for an
         * `id` but would need to be escaped when using `querySelector`, breaking
         * their usage and ending up in no selector returned. Selectors need to be
         * escaped:
         *
         * - `#1-thing` becomes `#\31 -thing`
         * - `#with~symbols` becomes `#with\\~symbols`
         *
         * - More information about  the topic can be found at
         *   https://mathiasbynens.be/notes/html5-id-class.
         * - Practical example: https://mathiasbynens.be/demo/html5-id
         */
        if (false) {}
        const el = typeof positionEl === 'string'
            ? isIdSelector
                ? document.getElementById(positionEl.slice(1))
                : document.querySelector(positionEl)
            : positionEl;
        if (!el) {
            ( false) &&
                0;
            return;
        }
        scrollToOptions = getElementPosition(el, position);
    }
    else {
        scrollToOptions = position;
    }
    if ('scrollBehavior' in document.documentElement.style)
        window.scrollTo(scrollToOptions);
    else {
        window.scrollTo(scrollToOptions.left != null ? scrollToOptions.left : window.scrollX, scrollToOptions.top != null ? scrollToOptions.top : window.scrollY);
    }
}
function getScrollKey(path, delta) {
    const position = history.state ? history.state.position - delta : -1;
    return position + path;
}
const scrollPositions = new Map();
function saveScrollPosition(key, scrollPosition) {
    scrollPositions.set(key, scrollPosition);
}
function getSavedScrollPosition(key) {
    const scroll = scrollPositions.get(key);
    // consume it so it's not used again
    scrollPositions.delete(key);
    return scroll;
}
// TODO: RFC about how to save scroll position
/**
 * ScrollBehavior instance used by the router to compute and restore the scroll
 * position when navigating.
 */
// export interface ScrollHandler<ScrollPositionEntry extends HistoryStateValue, ScrollPosition extends ScrollPositionEntry> {
//   // returns a scroll position that can be saved in history
//   compute(): ScrollPositionEntry
//   // can take an extended ScrollPositionEntry
//   scroll(position: ScrollPosition): void
// }
// export const scrollHandler: ScrollHandler<ScrollPosition> = {
//   compute: computeScroll,
//   scroll: scrollToPosition,
// }

let createBaseLocation = () => location.protocol + '//' + location.host;
/**
 * Creates a normalized history location from a window.location object
 * @param base - The base path
 * @param location - The window.location object
 */
function createCurrentLocation(base, location) {
    const { pathname, search, hash } = location;
    // allows hash bases like #, /#, #/, #!, #!/, /#!/, or even /folder#end
    const hashPos = base.indexOf('#');
    if (hashPos > -1) {
        let slicePos = hash.includes(base.slice(hashPos))
            ? base.slice(hashPos).length
            : 1;
        let pathFromHash = hash.slice(slicePos);
        // prepend the starting slash to hash so the url starts with /#
        if (pathFromHash[0] !== '/')
            pathFromHash = '/' + pathFromHash;
        return stripBase(pathFromHash, '');
    }
    const path = stripBase(pathname, base);
    return path + search + hash;
}
function useHistoryListeners(base, historyState, currentLocation, replace) {
    let listeners = [];
    let teardowns = [];
    // TODO: should it be a stack? a Dict. Check if the popstate listener
    // can trigger twice
    let pauseState = null;
    const popStateHandler = ({ state, }) => {
        const to = createCurrentLocation(base, location);
        const from = currentLocation.value;
        const fromState = historyState.value;
        let delta = 0;
        if (state) {
            currentLocation.value = to;
            historyState.value = state;
            // ignore the popstate and reset the pauseState
            if (pauseState && pauseState === from) {
                pauseState = null;
                return;
            }
            delta = fromState ? state.position - fromState.position : 0;
        }
        else {
            replace(to);
        }
        // Here we could also revert the navigation by calling history.go(-delta)
        // this listener will have to be adapted to not trigger again and to wait for the url
        // to be updated before triggering the listeners. Some kind of validation function would also
        // need to be passed to the listeners so the navigation can be accepted
        // call all listeners
        listeners.forEach(listener => {
            listener(currentLocation.value, from, {
                delta,
                type: NavigationType.pop,
                direction: delta
                    ? delta > 0
                        ? NavigationDirection.forward
                        : NavigationDirection.back
                    : NavigationDirection.unknown,
            });
        });
    };
    function pauseListeners() {
        pauseState = currentLocation.value;
    }
    function listen(callback) {
        // set up the listener and prepare teardown callbacks
        listeners.push(callback);
        const teardown = () => {
            const index = listeners.indexOf(callback);
            if (index > -1)
                listeners.splice(index, 1);
        };
        teardowns.push(teardown);
        return teardown;
    }
    function beforeUnloadListener() {
        const { history } = window;
        if (!history.state)
            return;
        history.replaceState(vue_router_assign({}, history.state, { scroll: computeScrollPosition() }), '');
    }
    function destroy() {
        for (const teardown of teardowns)
            teardown();
        teardowns = [];
        window.removeEventListener('popstate', popStateHandler);
        window.removeEventListener('beforeunload', beforeUnloadListener);
    }
    // set up the listeners and prepare teardown callbacks
    window.addEventListener('popstate', popStateHandler);
    // TODO: could we use 'pagehide' or 'visibilitychange' instead?
    // https://developer.chrome.com/blog/page-lifecycle-api/
    window.addEventListener('beforeunload', beforeUnloadListener, {
        passive: true,
    });
    return {
        pauseListeners,
        listen,
        destroy,
    };
}
/**
 * Creates a state object
 */
function buildState(back, current, forward, replaced = false, computeScroll = false) {
    return {
        back,
        current,
        forward,
        replaced,
        position: window.history.length,
        scroll: computeScroll ? computeScrollPosition() : null,
    };
}
function useHistoryStateNavigation(base) {
    const { history, location } = window;
    // private variables
    const currentLocation = {
        value: createCurrentLocation(base, location),
    };
    const historyState = { value: history.state };
    // build current history entry as this is a fresh navigation
    if (!historyState.value) {
        changeLocation(currentLocation.value, {
            back: null,
            current: currentLocation.value,
            forward: null,
            // the length is off by one, we need to decrease it
            position: history.length - 1,
            replaced: true,
            // don't add a scroll as the user may have an anchor, and we want
            // scrollBehavior to be triggered without a saved position
            scroll: null,
        }, true);
    }
    function changeLocation(to, state, replace) {
        /**
         * if a base tag is provided, and we are on a normal domain, we have to
         * respect the provided `base` attribute because pushState() will use it and
         * potentially erase anything before the `#` like at
         * https://github.com/vuejs/router/issues/685 where a base of
         * `/folder/#` but a base of `/` would erase the `/folder/` section. If
         * there is no host, the `<base>` tag makes no sense and if there isn't a
         * base tag we can just use everything after the `#`.
         */
        const hashIndex = base.indexOf('#');
        const url = hashIndex > -1
            ? (location.host && document.querySelector('base')
                ? base
                : base.slice(hashIndex)) + to
            : createBaseLocation() + base + to;
        try {
            // BROWSER QUIRK
            // NOTE: Safari throws a SecurityError when calling this function 100 times in 30 seconds
            history[replace ? 'replaceState' : 'pushState'](state, '', url);
            historyState.value = state;
        }
        catch (err) {
            if ((false)) {}
            else {
                console.error(err);
            }
            // Force the navigation, this also resets the call count
            location[replace ? 'replace' : 'assign'](url);
        }
    }
    function replace(to, data) {
        const state = vue_router_assign({}, history.state, buildState(historyState.value.back, 
        // keep back and forward entries but override current position
        to, historyState.value.forward, true), data, { position: historyState.value.position });
        changeLocation(to, state, true);
        currentLocation.value = to;
    }
    function push(to, data) {
        // Add to current entry the information of where we are going
        // as well as saving the current position
        const currentState = vue_router_assign({}, 
        // use current history state to gracefully handle a wrong call to
        // history.replaceState
        // https://github.com/vuejs/router/issues/366
        historyState.value, history.state, {
            forward: to,
            scroll: computeScrollPosition(),
        });
        if (false) {}
        changeLocation(currentState.current, currentState, true);
        const state = vue_router_assign({}, buildState(currentLocation.value, to, null), { position: currentState.position + 1 }, data);
        changeLocation(to, state, false);
        currentLocation.value = to;
    }
    return {
        location: currentLocation,
        state: historyState,
        push,
        replace,
    };
}
/**
 * Creates an HTML5 history. Most common history for single page applications.
 *
 * @param base -
 */
function createWebHistory(base) {
    base = normalizeBase(base);
    const historyNavigation = useHistoryStateNavigation(base);
    const historyListeners = useHistoryListeners(base, historyNavigation.state, historyNavigation.location, historyNavigation.replace);
    function go(delta, triggerListeners = true) {
        if (!triggerListeners)
            historyListeners.pauseListeners();
        history.go(delta);
    }
    const routerHistory = vue_router_assign({
        // it's overridden right after
        location: '',
        base,
        go,
        createHref: createHref.bind(null, base),
    }, historyNavigation, historyListeners);
    Object.defineProperty(routerHistory, 'location', {
        enumerable: true,
        get: () => historyNavigation.location.value,
    });
    Object.defineProperty(routerHistory, 'state', {
        enumerable: true,
        get: () => historyNavigation.state.value,
    });
    return routerHistory;
}

/**
 * Creates an in-memory based history. The main purpose of this history is to handle SSR. It starts in a special location that is nowhere.
 * It's up to the user to replace that location with the starter location by either calling `router.push` or `router.replace`.
 *
 * @param base - Base applied to all urls, defaults to '/'
 * @returns a history object that can be passed to the router constructor
 */
function createMemoryHistory(base = '') {
    let listeners = [];
    let queue = [[START, {}]];
    let position = 0;
    base = normalizeBase(base);
    function setLocation(location, state = {}) {
        position++;
        if (position !== queue.length) {
            // we are in the middle, we remove everything from here in the queue
            queue.splice(position);
        }
        queue.push([location, state]);
    }
    function triggerListeners(to, from, { direction, delta }) {
        const info = {
            direction,
            delta,
            type: NavigationType.pop,
        };
        for (const callback of listeners) {
            callback(to, from, info);
        }
    }
    const routerHistory = {
        // rewritten by Object.defineProperty
        location: START,
        // rewritten by Object.defineProperty
        state: {},
        base,
        createHref: createHref.bind(null, base),
        replace(to, state) {
            // remove current entry and decrement position
            queue.splice(position--, 1);
            setLocation(to, state);
        },
        push(to, state) {
            setLocation(to, state);
        },
        listen(callback) {
            listeners.push(callback);
            return () => {
                const index = listeners.indexOf(callback);
                if (index > -1)
                    listeners.splice(index, 1);
            };
        },
        destroy() {
            listeners = [];
            queue = [[START, {}]];
            position = 0;
        },
        go(delta, shouldTrigger = true) {
            const from = this.location;
            const direction = 
            // we are considering delta === 0 going forward, but in abstract mode
            // using 0 for the delta doesn't make sense like it does in html5 where
            // it reloads the page
            delta < 0 ? NavigationDirection.back : NavigationDirection.forward;
            position = Math.max(0, Math.min(position + delta, queue.length - 1));
            if (shouldTrigger) {
                triggerListeners(this.location, from, {
                    direction,
                    delta,
                });
            }
        },
    };
    Object.defineProperty(routerHistory, 'location', {
        enumerable: true,
        get: () => queue[position][0],
    });
    Object.defineProperty(routerHistory, 'state', {
        enumerable: true,
        get: () => queue[position][1],
    });
    return routerHistory;
}

/**
 * Creates a hash history. Useful for web applications with no host (e.g. `file://`) or when configuring a server to
 * handle any URL is not possible.
 *
 * @param base - optional base to provide. Defaults to `location.pathname + location.search` If there is a `<base>` tag
 * in the `head`, its value will be ignored in favor of this parameter **but note it affects all the history.pushState()
 * calls**, meaning that if you use a `<base>` tag, it's `href` value **has to match this parameter** (ignoring anything
 * after the `#`).
 *
 * @example
 * ```js
 * // at https://example.com/folder
 * createWebHashHistory() // gives a url of `https://example.com/folder#`
 * createWebHashHistory('/folder/') // gives a url of `https://example.com/folder/#`
 * // if the `#` is provided in the base, it won't be added by `createWebHashHistory`
 * createWebHashHistory('/folder/#/app/') // gives a url of `https://example.com/folder/#/app/`
 * // you should avoid doing this because it changes the original url and breaks copying urls
 * createWebHashHistory('/other-folder/') // gives a url of `https://example.com/other-folder/#`
 *
 * // at file:///usr/etc/folder/index.html
 * // for locations with no `host`, the base is ignored
 * createWebHashHistory('/iAmIgnored') // gives a url of `file:///usr/etc/folder/index.html#`
 * ```
 */
function createWebHashHistory(base) {
    // Make sure this implementation is fine in terms of encoding, specially for IE11
    // for `file://`, directly use the pathname and ignore the base
    // location.pathname contains an initial `/` even at the root: `https://example.com`
    base = location.host ? base || location.pathname + location.search : '';
    // allow the user to provide a `#` in the middle: `/base/#/app`
    if (!base.includes('#'))
        base += '#';
    if (false) {}
    return createWebHistory(base);
}

function isRouteLocation(route) {
    return typeof route === 'string' || (route && typeof route === 'object');
}
function isRouteName(name) {
    return typeof name === 'string' || typeof name === 'symbol';
}

const NavigationFailureSymbol = Symbol(( false) ? 0 : '');
/**
 * Enumeration with all possible types for navigation failures. Can be passed to
 * {@link isNavigationFailure} to check for specific failures.
 */
var NavigationFailureType;
(function (NavigationFailureType) {
    /**
     * An aborted navigation is a navigation that failed because a navigation
     * guard returned `false` or called `next(false)`
     */
    NavigationFailureType[NavigationFailureType["aborted"] = 4] = "aborted";
    /**
     * A cancelled navigation is a navigation that failed because a more recent
     * navigation finished started (not necessarily finished).
     */
    NavigationFailureType[NavigationFailureType["cancelled"] = 8] = "cancelled";
    /**
     * A duplicated navigation is a navigation that failed because it was
     * initiated while already being at the exact same location.
     */
    NavigationFailureType[NavigationFailureType["duplicated"] = 16] = "duplicated";
})(NavigationFailureType || (NavigationFailureType = {}));
// DEV only debug messages
const ErrorTypeMessages = {
    [1 /* ErrorTypes.MATCHER_NOT_FOUND */]({ location, currentLocation }) {
        return `No match for\n ${JSON.stringify(location)}${currentLocation
            ? '\nwhile being at\n' + JSON.stringify(currentLocation)
            : ''}`;
    },
    [2 /* ErrorTypes.NAVIGATION_GUARD_REDIRECT */]({ from, to, }) {
        return `Redirected from "${from.fullPath}" to "${stringifyRoute(to)}" via a navigation guard.`;
    },
    [4 /* ErrorTypes.NAVIGATION_ABORTED */]({ from, to }) {
        return `Navigation aborted from "${from.fullPath}" to "${to.fullPath}" via a navigation guard.`;
    },
    [8 /* ErrorTypes.NAVIGATION_CANCELLED */]({ from, to }) {
        return `Navigation cancelled from "${from.fullPath}" to "${to.fullPath}" with a new navigation.`;
    },
    [16 /* ErrorTypes.NAVIGATION_DUPLICATED */]({ from, to }) {
        return `Avoided redundant navigation to current location: "${from.fullPath}".`;
    },
};
/**
 * Creates a typed NavigationFailure object.
 * @internal
 * @param type - NavigationFailureType
 * @param params - { from, to }
 */
function createRouterError(type, params) {
    // keep full error messages in cjs versions
    if (false) {}
    else {
        return vue_router_assign(new Error(), {
            type,
            [NavigationFailureSymbol]: true,
        }, params);
    }
}
function isNavigationFailure(error, type) {
    return (error instanceof Error &&
        NavigationFailureSymbol in error &&
        (type == null || !!(error.type & type)));
}
const propertiesToLog = ['params', 'query', 'hash'];
function stringifyRoute(to) {
    if (typeof to === 'string')
        return to;
    if (to.path != null)
        return to.path;
    const location = {};
    for (const key of propertiesToLog) {
        if (key in to)
            location[key] = to[key];
    }
    return JSON.stringify(location, null, 2);
}

// default pattern for a param: non-greedy everything but /
const BASE_PARAM_PATTERN = '[^/]+?';
const BASE_PATH_PARSER_OPTIONS = {
    sensitive: false,
    strict: false,
    start: true,
    end: true,
};
// Special Regex characters that must be escaped in static tokens
const REGEX_CHARS_RE = /[.+*?^${}()[\]/\\]/g;
/**
 * Creates a path parser from an array of Segments (a segment is an array of Tokens)
 *
 * @param segments - array of segments returned by tokenizePath
 * @param extraOptions - optional options for the regexp
 * @returns a PathParser
 */
function tokensToParser(segments, extraOptions) {
    const options = vue_router_assign({}, BASE_PATH_PARSER_OPTIONS, extraOptions);
    // the amount of scores is the same as the length of segments except for the root segment "/"
    const score = [];
    // the regexp as a string
    let pattern = options.start ? '^' : '';
    // extracted keys
    const keys = [];
    for (const segment of segments) {
        // the root segment needs special treatment
        const segmentScores = segment.length ? [] : [90 /* PathScore.Root */];
        // allow trailing slash
        if (options.strict && !segment.length)
            pattern += '/';
        for (let tokenIndex = 0; tokenIndex < segment.length; tokenIndex++) {
            const token = segment[tokenIndex];
            // resets the score if we are inside a sub-segment /:a-other-:b
            let subSegmentScore = 40 /* PathScore.Segment */ +
                (options.sensitive ? 0.25 /* PathScore.BonusCaseSensitive */ : 0);
            if (token.type === 0 /* TokenType.Static */) {
                // prepend the slash if we are starting a new segment
                if (!tokenIndex)
                    pattern += '/';
                pattern += token.value.replace(REGEX_CHARS_RE, '\\$&');
                subSegmentScore += 40 /* PathScore.Static */;
            }
            else if (token.type === 1 /* TokenType.Param */) {
                const { value, repeatable, optional, regexp } = token;
                keys.push({
                    name: value,
                    repeatable,
                    optional,
                });
                const re = regexp ? regexp : BASE_PARAM_PATTERN;
                // the user provided a custom regexp /:id(\\d+)
                if (re !== BASE_PARAM_PATTERN) {
                    subSegmentScore += 10 /* PathScore.BonusCustomRegExp */;
                    // make sure the regexp is valid before using it
                    try {
                        new RegExp(`(${re})`);
                    }
                    catch (err) {
                        throw new Error(`Invalid custom RegExp for param "${value}" (${re}): ` +
                            err.message);
                    }
                }
                // when we repeat we must take care of the repeating leading slash
                let subPattern = repeatable ? `((?:${re})(?:/(?:${re}))*)` : `(${re})`;
                // prepend the slash if we are starting a new segment
                if (!tokenIndex)
                    subPattern =
                        // avoid an optional / if there are more segments e.g. /:p?-static
                        // or /:p?-:p2
                        optional && segment.length < 2
                            ? `(?:/${subPattern})`
                            : '/' + subPattern;
                if (optional)
                    subPattern += '?';
                pattern += subPattern;
                subSegmentScore += 20 /* PathScore.Dynamic */;
                if (optional)
                    subSegmentScore += -8 /* PathScore.BonusOptional */;
                if (repeatable)
                    subSegmentScore += -20 /* PathScore.BonusRepeatable */;
                if (re === '.*')
                    subSegmentScore += -50 /* PathScore.BonusWildcard */;
            }
            segmentScores.push(subSegmentScore);
        }
        // an empty array like /home/ -> [[{home}], []]
        // if (!segment.length) pattern += '/'
        score.push(segmentScores);
    }
    // only apply the strict bonus to the last score
    if (options.strict && options.end) {
        const i = score.length - 1;
        score[i][score[i].length - 1] += 0.7000000000000001 /* PathScore.BonusStrict */;
    }
    // TODO: dev only warn double trailing slash
    if (!options.strict)
        pattern += '/?';
    if (options.end)
        pattern += '$';
    // allow paths like /dynamic to only match dynamic or dynamic/... but not dynamic_something_else
    else if (options.strict && !pattern.endsWith('/'))
        pattern += '(?:/|$)';
    const re = new RegExp(pattern, options.sensitive ? '' : 'i');
    function parse(path) {
        const match = path.match(re);
        const params = {};
        if (!match)
            return null;
        for (let i = 1; i < match.length; i++) {
            const value = match[i] || '';
            const key = keys[i - 1];
            params[key.name] = value && key.repeatable ? value.split('/') : value;
        }
        return params;
    }
    function stringify(params) {
        let path = '';
        // for optional parameters to allow to be empty
        let avoidDuplicatedSlash = false;
        for (const segment of segments) {
            if (!avoidDuplicatedSlash || !path.endsWith('/'))
                path += '/';
            avoidDuplicatedSlash = false;
            for (const token of segment) {
                if (token.type === 0 /* TokenType.Static */) {
                    path += token.value;
                }
                else if (token.type === 1 /* TokenType.Param */) {
                    const { value, repeatable, optional } = token;
                    const param = value in params ? params[value] : '';
                    if (vue_router_isArray(param) && !repeatable) {
                        throw new Error(`Provided param "${value}" is an array but it is not repeatable (* or + modifiers)`);
                    }
                    const text = vue_router_isArray(param)
                        ? param.join('/')
                        : param;
                    if (!text) {
                        if (optional) {
                            // if we have more than one optional param like /:a?-static we don't need to care about the optional param
                            if (segment.length < 2) {
                                // remove the last slash as we could be at the end
                                if (path.endsWith('/'))
                                    path = path.slice(0, -1);
                                // do not append a slash on the next iteration
                                else
                                    avoidDuplicatedSlash = true;
                            }
                        }
                        else
                            throw new Error(`Missing required param "${value}"`);
                    }
                    path += text;
                }
            }
        }
        // avoid empty path when we have multiple optional params
        return path || '/';
    }
    return {
        re,
        score,
        keys,
        parse,
        stringify,
    };
}
/**
 * Compares an array of numbers as used in PathParser.score and returns a
 * number. This function can be used to `sort` an array
 *
 * @param a - first array of numbers
 * @param b - second array of numbers
 * @returns 0 if both are equal, < 0 if a should be sorted first, > 0 if b
 * should be sorted first
 */
function compareScoreArray(a, b) {
    let i = 0;
    while (i < a.length && i < b.length) {
        const diff = b[i] - a[i];
        // only keep going if diff === 0
        if (diff)
            return diff;
        i++;
    }
    // if the last subsegment was Static, the shorter segments should be sorted first
    // otherwise sort the longest segment first
    if (a.length < b.length) {
        return a.length === 1 && a[0] === 40 /* PathScore.Static */ + 40 /* PathScore.Segment */
            ? -1
            : 1;
    }
    else if (a.length > b.length) {
        return b.length === 1 && b[0] === 40 /* PathScore.Static */ + 40 /* PathScore.Segment */
            ? 1
            : -1;
    }
    return 0;
}
/**
 * Compare function that can be used with `sort` to sort an array of PathParser
 *
 * @param a - first PathParser
 * @param b - second PathParser
 * @returns 0 if both are equal, < 0 if a should be sorted first, > 0 if b
 */
function comparePathParserScore(a, b) {
    let i = 0;
    const aScore = a.score;
    const bScore = b.score;
    while (i < aScore.length && i < bScore.length) {
        const comp = compareScoreArray(aScore[i], bScore[i]);
        // do not return if both are equal
        if (comp)
            return comp;
        i++;
    }
    if (Math.abs(bScore.length - aScore.length) === 1) {
        if (isLastScoreNegative(aScore))
            return 1;
        if (isLastScoreNegative(bScore))
            return -1;
    }
    // if a and b share the same score entries but b has more, sort b first
    return bScore.length - aScore.length;
    // this is the ternary version
    // return aScore.length < bScore.length
    //   ? 1
    //   : aScore.length > bScore.length
    //   ? -1
    //   : 0
}
/**
 * This allows detecting splats at the end of a path: /home/:id(.*)*
 *
 * @param score - score to check
 * @returns true if the last entry is negative
 */
function isLastScoreNegative(score) {
    const last = score[score.length - 1];
    return score.length > 0 && last[last.length - 1] < 0;
}

const ROOT_TOKEN = {
    type: 0 /* TokenType.Static */,
    value: '',
};
const VALID_PARAM_RE = /[a-zA-Z0-9_]/;
// After some profiling, the cache seems to be unnecessary because tokenizePath
// (the slowest part of adding a route) is very fast
// const tokenCache = new Map<string, Token[][]>()
function tokenizePath(path) {
    if (!path)
        return [[]];
    if (path === '/')
        return [[ROOT_TOKEN]];
    if (!path.startsWith('/')) {
        throw new Error(( false)
            ? 0
            : `Invalid path "${path}"`);
    }
    // if (tokenCache.has(path)) return tokenCache.get(path)!
    function crash(message) {
        throw new Error(`ERR (${state})/"${buffer}": ${message}`);
    }
    let state = 0 /* TokenizerState.Static */;
    let previousState = state;
    const tokens = [];
    // the segment will always be valid because we get into the initial state
    // with the leading /
    let segment;
    function finalizeSegment() {
        if (segment)
            tokens.push(segment);
        segment = [];
    }
    // index on the path
    let i = 0;
    // char at index
    let char;
    // buffer of the value read
    let buffer = '';
    // custom regexp for a param
    let customRe = '';
    function consumeBuffer() {
        if (!buffer)
            return;
        if (state === 0 /* TokenizerState.Static */) {
            segment.push({
                type: 0 /* TokenType.Static */,
                value: buffer,
            });
        }
        else if (state === 1 /* TokenizerState.Param */ ||
            state === 2 /* TokenizerState.ParamRegExp */ ||
            state === 3 /* TokenizerState.ParamRegExpEnd */) {
            if (segment.length > 1 && (char === '*' || char === '+'))
                crash(`A repeatable param (${buffer}) must be alone in its segment. eg: '/:ids+.`);
            segment.push({
                type: 1 /* TokenType.Param */,
                value: buffer,
                regexp: customRe,
                repeatable: char === '*' || char === '+',
                optional: char === '*' || char === '?',
            });
        }
        else {
            crash('Invalid state to consume buffer');
        }
        buffer = '';
    }
    function addCharToBuffer() {
        buffer += char;
    }
    while (i < path.length) {
        char = path[i++];
        if (char === '\\' && state !== 2 /* TokenizerState.ParamRegExp */) {
            previousState = state;
            state = 4 /* TokenizerState.EscapeNext */;
            continue;
        }
        switch (state) {
            case 0 /* TokenizerState.Static */:
                if (char === '/') {
                    if (buffer) {
                        consumeBuffer();
                    }
                    finalizeSegment();
                }
                else if (char === ':') {
                    consumeBuffer();
                    state = 1 /* TokenizerState.Param */;
                }
                else {
                    addCharToBuffer();
                }
                break;
            case 4 /* TokenizerState.EscapeNext */:
                addCharToBuffer();
                state = previousState;
                break;
            case 1 /* TokenizerState.Param */:
                if (char === '(') {
                    state = 2 /* TokenizerState.ParamRegExp */;
                }
                else if (VALID_PARAM_RE.test(char)) {
                    addCharToBuffer();
                }
                else {
                    consumeBuffer();
                    state = 0 /* TokenizerState.Static */;
                    // go back one character if we were not modifying
                    if (char !== '*' && char !== '?' && char !== '+')
                        i--;
                }
                break;
            case 2 /* TokenizerState.ParamRegExp */:
                // TODO: is it worth handling nested regexp? like :p(?:prefix_([^/]+)_suffix)
                // it already works by escaping the closing )
                // https://paths.esm.dev/?p=AAMeJbiAwQEcDKbAoAAkP60PG2R6QAvgNaA6AFACM2ABuQBB#
                // is this really something people need since you can also write
                // /prefix_:p()_suffix
                if (char === ')') {
                    // handle the escaped )
                    if (customRe[customRe.length - 1] == '\\')
                        customRe = customRe.slice(0, -1) + char;
                    else
                        state = 3 /* TokenizerState.ParamRegExpEnd */;
                }
                else {
                    customRe += char;
                }
                break;
            case 3 /* TokenizerState.ParamRegExpEnd */:
                // same as finalizing a param
                consumeBuffer();
                state = 0 /* TokenizerState.Static */;
                // go back one character if we were not modifying
                if (char !== '*' && char !== '?' && char !== '+')
                    i--;
                customRe = '';
                break;
            default:
                crash('Unknown state');
                break;
        }
    }
    if (state === 2 /* TokenizerState.ParamRegExp */)
        crash(`Unfinished custom RegExp for param "${buffer}"`);
    consumeBuffer();
    finalizeSegment();
    // tokenCache.set(path, tokens)
    return tokens;
}

function createRouteRecordMatcher(record, parent, options) {
    const parser = tokensToParser(tokenizePath(record.path), options);
    // warn against params with the same name
    if ((false)) {}
    const matcher = vue_router_assign(parser, {
        record,
        parent,
        // these needs to be populated by the parent
        children: [],
        alias: [],
    });
    if (parent) {
        // both are aliases or both are not aliases
        // we don't want to mix them because the order is used when
        // passing originalRecord in Matcher.addRoute
        if (!matcher.record.aliasOf === !parent.record.aliasOf)
            parent.children.push(matcher);
    }
    return matcher;
}

/**
 * Creates a Router Matcher.
 *
 * @internal
 * @param routes - array of initial routes
 * @param globalOptions - global route options
 */
function createRouterMatcher(routes, globalOptions) {
    // normalized ordered array of matchers
    const matchers = [];
    const matcherMap = new Map();
    globalOptions = vue_router_mergeOptions({ strict: false, end: true, sensitive: false }, globalOptions);
    function getRecordMatcher(name) {
        return matcherMap.get(name);
    }
    function addRoute(record, parent, originalRecord) {
        // used later on to remove by name
        const isRootAdd = !originalRecord;
        const mainNormalizedRecord = normalizeRouteRecord(record);
        if ((false)) {}
        // we might be the child of an alias
        mainNormalizedRecord.aliasOf = originalRecord && originalRecord.record;
        const options = vue_router_mergeOptions(globalOptions, record);
        // generate an array of records to correctly handle aliases
        const normalizedRecords = [mainNormalizedRecord];
        if ('alias' in record) {
            const aliases = typeof record.alias === 'string' ? [record.alias] : record.alias;
            for (const alias of aliases) {
                normalizedRecords.push(
                // we need to normalize again to ensure the `mods` property
                // being non enumerable
                normalizeRouteRecord(vue_router_assign({}, mainNormalizedRecord, {
                    // this allows us to hold a copy of the `components` option
                    // so that async components cache is hold on the original record
                    components: originalRecord
                        ? originalRecord.record.components
                        : mainNormalizedRecord.components,
                    path: alias,
                    // we might be the child of an alias
                    aliasOf: originalRecord
                        ? originalRecord.record
                        : mainNormalizedRecord,
                    // the aliases are always of the same kind as the original since they
                    // are defined on the same record
                })));
            }
        }
        let matcher;
        let originalMatcher;
        for (const normalizedRecord of normalizedRecords) {
            const { path } = normalizedRecord;
            // Build up the path for nested routes if the child isn't an absolute
            // route. Only add the / delimiter if the child path isn't empty and if the
            // parent path doesn't have a trailing slash
            if (parent && path[0] !== '/') {
                const parentPath = parent.record.path;
                const connectingSlash = parentPath[parentPath.length - 1] === '/' ? '' : '/';
                normalizedRecord.path =
                    parent.record.path + (path && connectingSlash + path);
            }
            if (false) {}
            // create the object beforehand, so it can be passed to children
            matcher = createRouteRecordMatcher(normalizedRecord, parent, options);
            if (false)
                {}
            // if we are an alias we must tell the original record that we exist,
            // so we can be removed
            if (originalRecord) {
                originalRecord.alias.push(matcher);
                if ((false)) {}
            }
            else {
                // otherwise, the first record is the original and others are aliases
                originalMatcher = originalMatcher || matcher;
                if (originalMatcher !== matcher)
                    originalMatcher.alias.push(matcher);
                // remove the route if named and only for the top record (avoid in nested calls)
                // this works because the original record is the first one
                if (isRootAdd && record.name && !isAliasRecord(matcher)) {
                    if ((false)) {}
                    removeRoute(record.name);
                }
            }
            // Avoid adding a record that doesn't display anything. This allows passing through records without a component to
            // not be reached and pass through the catch all route
            if (isMatchable(matcher)) {
                insertMatcher(matcher);
            }
            if (mainNormalizedRecord.children) {
                const children = mainNormalizedRecord.children;
                for (let i = 0; i < children.length; i++) {
                    addRoute(children[i], matcher, originalRecord && originalRecord.children[i]);
                }
            }
            // if there was no original record, then the first one was not an alias and all
            // other aliases (if any) need to reference this record when adding children
            originalRecord = originalRecord || matcher;
            // TODO: add normalized records for more flexibility
            // if (parent && isAliasRecord(originalRecord)) {
            //   parent.children.push(originalRecord)
            // }
        }
        return originalMatcher
            ? () => {
                // since other matchers are aliases, they should be removed by the original matcher
                removeRoute(originalMatcher);
            }
            : noop;
    }
    function removeRoute(matcherRef) {
        if (isRouteName(matcherRef)) {
            const matcher = matcherMap.get(matcherRef);
            if (matcher) {
                matcherMap.delete(matcherRef);
                matchers.splice(matchers.indexOf(matcher), 1);
                matcher.children.forEach(removeRoute);
                matcher.alias.forEach(removeRoute);
            }
        }
        else {
            const index = matchers.indexOf(matcherRef);
            if (index > -1) {
                matchers.splice(index, 1);
                if (matcherRef.record.name)
                    matcherMap.delete(matcherRef.record.name);
                matcherRef.children.forEach(removeRoute);
                matcherRef.alias.forEach(removeRoute);
            }
        }
    }
    function getRoutes() {
        return matchers;
    }
    function insertMatcher(matcher) {
        const index = vue_router_findInsertionIndex(matcher, matchers);
        matchers.splice(index, 0, matcher);
        // only add the original record to the name map
        if (matcher.record.name && !isAliasRecord(matcher))
            matcherMap.set(matcher.record.name, matcher);
    }
    function resolve(location, currentLocation) {
        let matcher;
        let params = {};
        let path;
        let name;
        if ('name' in location && location.name) {
            matcher = matcherMap.get(location.name);
            if (!matcher)
                throw createRouterError(1 /* ErrorTypes.MATCHER_NOT_FOUND */, {
                    location,
                });
            // warn if the user is passing invalid params so they can debug it better when they get removed
            if ((false)) {}
            name = matcher.record.name;
            params = vue_router_assign(
            // paramsFromLocation is a new object
            paramsFromLocation(currentLocation.params, 
            // only keep params that exist in the resolved location
            // only keep optional params coming from a parent record
            matcher.keys
                .filter(k => !k.optional)
                .concat(matcher.parent ? matcher.parent.keys.filter(k => k.optional) : [])
                .map(k => k.name)), 
            // discard any existing params in the current location that do not exist here
            // #1497 this ensures better active/exact matching
            location.params &&
                paramsFromLocation(location.params, matcher.keys.map(k => k.name)));
            // throws if cannot be stringified
            path = matcher.stringify(params);
        }
        else if (location.path != null) {
            // no need to resolve the path with the matcher as it was provided
            // this also allows the user to control the encoding
            path = location.path;
            if (false) {}
            matcher = matchers.find(m => m.re.test(path));
            // matcher should have a value after the loop
            if (matcher) {
                // we know the matcher works because we tested the regexp
                params = matcher.parse(path);
                name = matcher.record.name;
            }
            // location is a relative path
        }
        else {
            // match by name or path of current route
            matcher = currentLocation.name
                ? matcherMap.get(currentLocation.name)
                : matchers.find(m => m.re.test(currentLocation.path));
            if (!matcher)
                throw createRouterError(1 /* ErrorTypes.MATCHER_NOT_FOUND */, {
                    location,
                    currentLocation,
                });
            name = matcher.record.name;
            // since we are navigating to the same location, we don't need to pick the
            // params like when `name` is provided
            params = vue_router_assign({}, currentLocation.params, location.params);
            path = matcher.stringify(params);
        }
        const matched = [];
        let parentMatcher = matcher;
        while (parentMatcher) {
            // reversed order so parents are at the beginning
            matched.unshift(parentMatcher.record);
            parentMatcher = parentMatcher.parent;
        }
        return {
            name,
            path,
            params,
            matched,
            meta: mergeMetaFields(matched),
        };
    }
    // add initial routes
    routes.forEach(route => addRoute(route));
    function clearRoutes() {
        matchers.length = 0;
        matcherMap.clear();
    }
    return {
        addRoute,
        resolve,
        removeRoute,
        clearRoutes,
        getRoutes,
        getRecordMatcher,
    };
}
function paramsFromLocation(params, keys) {
    const newParams = {};
    for (const key of keys) {
        if (key in params)
            newParams[key] = params[key];
    }
    return newParams;
}
/**
 * Normalizes a RouteRecordRaw. Creates a copy
 *
 * @param record
 * @returns the normalized version
 */
function normalizeRouteRecord(record) {
    const normalized = {
        path: record.path,
        redirect: record.redirect,
        name: record.name,
        meta: record.meta || {},
        aliasOf: record.aliasOf,
        beforeEnter: record.beforeEnter,
        props: normalizeRecordProps(record),
        children: record.children || [],
        instances: {},
        leaveGuards: new Set(),
        updateGuards: new Set(),
        enterCallbacks: {},
        // must be declared afterwards
        // mods: {},
        components: 'components' in record
            ? record.components || null
            : record.component && { default: record.component },
    };
    // mods contain modules and shouldn't be copied,
    // logged or anything. It's just used for internal
    // advanced use cases like data loaders
    Object.defineProperty(normalized, 'mods', {
        value: {},
    });
    return normalized;
}
/**
 * Normalize the optional `props` in a record to always be an object similar to
 * components. Also accept a boolean for components.
 * @param record
 */
function normalizeRecordProps(record) {
    const propsObject = {};
    // props does not exist on redirect records, but we can set false directly
    const props = record.props || false;
    if ('component' in record) {
        propsObject.default = props;
    }
    else {
        // NOTE: we could also allow a function to be applied to every component.
        // Would need user feedback for use cases
        for (const name in record.components)
            propsObject[name] = typeof props === 'object' ? props[name] : props;
    }
    return propsObject;
}
/**
 * Checks if a record or any of its parent is an alias
 * @param record
 */
function isAliasRecord(record) {
    while (record) {
        if (record.record.aliasOf)
            return true;
        record = record.parent;
    }
    return false;
}
/**
 * Merge meta fields of an array of records
 *
 * @param matched - array of matched records
 */
function mergeMetaFields(matched) {
    return matched.reduce((meta, record) => vue_router_assign(meta, record.meta), {});
}
function vue_router_mergeOptions(defaults, partialOptions) {
    const options = {};
    for (const key in defaults) {
        options[key] = key in partialOptions ? partialOptions[key] : defaults[key];
    }
    return options;
}
function isSameParam(a, b) {
    return (a.name === b.name &&
        a.optional === b.optional &&
        a.repeatable === b.repeatable);
}
/**
 * Check if a path and its alias have the same required params
 *
 * @param a - original record
 * @param b - alias record
 */
function checkSameParams(a, b) {
    for (const key of a.keys) {
        if (!key.optional && !b.keys.find(isSameParam.bind(null, key)))
            return vue_router_warn(`Alias "${b.record.path}" and the original record: "${a.record.path}" must have the exact same param named "${key.name}"`);
    }
    for (const key of b.keys) {
        if (!key.optional && !a.keys.find(isSameParam.bind(null, key)))
            return vue_router_warn(`Alias "${b.record.path}" and the original record: "${a.record.path}" must have the exact same param named "${key.name}"`);
    }
}
/**
 * A route with a name and a child with an empty path without a name should warn when adding the route
 *
 * @param mainNormalizedRecord - RouteRecordNormalized
 * @param parent - RouteRecordMatcher
 */
function checkChildMissingNameWithEmptyPath(mainNormalizedRecord, parent) {
    if (parent &&
        parent.record.name &&
        !mainNormalizedRecord.name &&
        !mainNormalizedRecord.path) {
        vue_router_warn(`The route named "${String(parent.record.name)}" has a child without a name and an empty path. Using that name won't render the empty path child so you probably want to move the name to the child instead. If this is intentional, add a name to the child route to remove the warning.`);
    }
}
function checkSameNameAsAncestor(record, parent) {
    for (let ancestor = parent; ancestor; ancestor = ancestor.parent) {
        if (ancestor.record.name === record.name) {
            throw new Error(`A route named "${String(record.name)}" has been added as a ${parent === ancestor ? 'child' : 'descendant'} of a route with the same name. Route names must be unique and a nested route cannot use the same name as an ancestor.`);
        }
    }
}
function checkMissingParamsInAbsolutePath(record, parent) {
    for (const key of parent.keys) {
        if (!record.keys.find(isSameParam.bind(null, key)))
            return vue_router_warn(`Absolute path "${record.record.path}" must have the exact same param named "${key.name}" as its parent "${parent.record.path}".`);
    }
}
/**
 * Performs a binary search to find the correct insertion index for a new matcher.
 *
 * Matchers are primarily sorted by their score. If scores are tied then we also consider parent/child relationships,
 * with descendants coming before ancestors. If there's still a tie, new routes are inserted after existing routes.
 *
 * @param matcher - new matcher to be inserted
 * @param matchers - existing matchers
 */
function vue_router_findInsertionIndex(matcher, matchers) {
    // First phase: binary search based on score
    let lower = 0;
    let upper = matchers.length;
    while (lower !== upper) {
        const mid = (lower + upper) >> 1;
        const sortOrder = comparePathParserScore(matcher, matchers[mid]);
        if (sortOrder < 0) {
            upper = mid;
        }
        else {
            lower = mid + 1;
        }
    }
    // Second phase: check for an ancestor with the same score
    const insertionAncestor = getInsertionAncestor(matcher);
    if (insertionAncestor) {
        upper = matchers.lastIndexOf(insertionAncestor, upper - 1);
        if (false) {}
    }
    return upper;
}
function getInsertionAncestor(matcher) {
    let ancestor = matcher;
    while ((ancestor = ancestor.parent)) {
        if (isMatchable(ancestor) &&
            comparePathParserScore(matcher, ancestor) === 0) {
            return ancestor;
        }
    }
    return;
}
/**
 * Checks if a matcher can be reachable. This means if it's possible to reach it as a route. For example, routes without
 * a component, or name, or redirect, are just used to group other routes.
 * @param matcher
 * @param matcher.record record of the matcher
 * @returns
 */
function isMatchable({ record }) {
    return !!(record.name ||
        (record.components && Object.keys(record.components).length) ||
        record.redirect);
}

/**
 * Transforms a queryString into a {@link LocationQuery} object. Accept both, a
 * version with the leading `?` and without Should work as URLSearchParams

 * @internal
 *
 * @param search - search string to parse
 * @returns a query object
 */
function parseQuery(search) {
    const query = {};
    // avoid creating an object with an empty key and empty value
    // because of split('&')
    if (search === '' || search === '?')
        return query;
    const hasLeadingIM = search[0] === '?';
    const searchParams = (hasLeadingIM ? search.slice(1) : search).split('&');
    for (let i = 0; i < searchParams.length; ++i) {
        // pre decode the + into space
        const searchParam = searchParams[i].replace(PLUS_RE, ' ');
        // allow the = character
        const eqPos = searchParam.indexOf('=');
        const key = decode(eqPos < 0 ? searchParam : searchParam.slice(0, eqPos));
        const value = eqPos < 0 ? null : decode(searchParam.slice(eqPos + 1));
        if (key in query) {
            // an extra variable for ts types
            let currentValue = query[key];
            if (!vue_router_isArray(currentValue)) {
                currentValue = query[key] = [currentValue];
            }
            currentValue.push(value);
        }
        else {
            query[key] = value;
        }
    }
    return query;
}
/**
 * Stringifies a {@link LocationQueryRaw} object. Like `URLSearchParams`, it
 * doesn't prepend a `?`
 *
 * @internal
 *
 * @param query - query object to stringify
 * @returns string version of the query without the leading `?`
 */
function stringifyQuery(query) {
    let search = '';
    for (let key in query) {
        const value = query[key];
        key = encodeQueryKey(key);
        if (value == null) {
            // only null adds the value
            if (value !== undefined) {
                search += (search.length ? '&' : '') + key;
            }
            continue;
        }
        // keep null values
        const values = vue_router_isArray(value)
            ? value.map(v => v && encodeQueryValue(v))
            : [value && encodeQueryValue(value)];
        values.forEach(value => {
            // skip undefined values in arrays as if they were not present
            // smaller code than using filter
            if (value !== undefined) {
                // only append & with non-empty search
                search += (search.length ? '&' : '') + key;
                if (value != null)
                    search += '=' + value;
            }
        });
    }
    return search;
}
/**
 * Transforms a {@link LocationQueryRaw} into a {@link LocationQuery} by casting
 * numbers into strings, removing keys with an undefined value and replacing
 * undefined with null in arrays
 *
 * @param query - query object to normalize
 * @returns a normalized query object
 */
function normalizeQuery(query) {
    const normalizedQuery = {};
    for (const key in query) {
        const value = query[key];
        if (value !== undefined) {
            normalizedQuery[key] = vue_router_isArray(value)
                ? value.map(v => (v == null ? null : '' + v))
                : value == null
                    ? value
                    : '' + value;
        }
    }
    return normalizedQuery;
}

/**
 * RouteRecord being rendered by the closest ancestor Router View. Used for
 * `onBeforeRouteUpdate` and `onBeforeRouteLeave`. rvlm stands for Router View
 * Location Matched
 *
 * @internal
 */
const matchedRouteKey = Symbol(( false) ? 0 : '');
/**
 * Allows overriding the router view depth to control which component in
 * `matched` is rendered. rvd stands for Router View Depth
 *
 * @internal
 */
const viewDepthKey = Symbol(( false) ? 0 : '');
/**
 * Allows overriding the router instance returned by `useRouter` in tests. r
 * stands for router
 *
 * @internal
 */
const routerKey = Symbol(( false) ? 0 : '');
/**
 * Allows overriding the current route returned by `useRoute` in tests. rl
 * stands for route location
 *
 * @internal
 */
const routeLocationKey = Symbol(( false) ? 0 : '');
/**
 * Allows overriding the current route used by router-view. Internally this is
 * used when the `route` prop is passed.
 *
 * @internal
 */
const routerViewLocationKey = Symbol(( false) ? 0 : '');

/**
 * Create a list of callbacks that can be reset. Used to create before and after navigation guards list
 */
function useCallbacks() {
    let handlers = [];
    function add(handler) {
        handlers.push(handler);
        return () => {
            const i = handlers.indexOf(handler);
            if (i > -1)
                handlers.splice(i, 1);
        };
    }
    function reset() {
        handlers = [];
    }
    return {
        add,
        list: () => handlers.slice(),
        reset,
    };
}

function registerGuard(record, name, guard) {
    const removeFromList = () => {
        record[name].delete(guard);
    };
    onUnmounted(removeFromList);
    onDeactivated(removeFromList);
    onActivated(() => {
        record[name].add(guard);
    });
    record[name].add(guard);
}
/**
 * Add a navigation guard that triggers whenever the component for the current
 * location is about to be left. Similar to {@link beforeRouteLeave} but can be
 * used in any component. The guard is removed when the component is unmounted.
 *
 * @param leaveGuard - {@link NavigationGuard}
 */
function onBeforeRouteLeave(leaveGuard) {
    if (false) {}
    const activeRecord = inject(matchedRouteKey, 
    // to avoid warning
    {}).value;
    if (!activeRecord) {
        ( false) &&
            0;
        return;
    }
    registerGuard(activeRecord, 'leaveGuards', leaveGuard);
}
/**
 * Add a navigation guard that triggers whenever the current location is about
 * to be updated. Similar to {@link beforeRouteUpdate} but can be used in any
 * component. The guard is removed when the component is unmounted.
 *
 * @param updateGuard - {@link NavigationGuard}
 */
function onBeforeRouteUpdate(updateGuard) {
    if (false) {}
    const activeRecord = inject(matchedRouteKey, 
    // to avoid warning
    {}).value;
    if (!activeRecord) {
        ( false) &&
            0;
        return;
    }
    registerGuard(activeRecord, 'updateGuards', updateGuard);
}
function guardToPromiseFn(guard, to, from, record, name, runWithContext = fn => fn()) {
    // keep a reference to the enterCallbackArray to prevent pushing callbacks if a new navigation took place
    const enterCallbackArray = record &&
        // name is defined if record is because of the function overload
        (record.enterCallbacks[name] = record.enterCallbacks[name] || []);
    return () => new Promise((resolve, reject) => {
        const next = (valid) => {
            if (valid === false) {
                reject(createRouterError(4 /* ErrorTypes.NAVIGATION_ABORTED */, {
                    from,
                    to,
                }));
            }
            else if (valid instanceof Error) {
                reject(valid);
            }
            else if (isRouteLocation(valid)) {
                reject(createRouterError(2 /* ErrorTypes.NAVIGATION_GUARD_REDIRECT */, {
                    from: to,
                    to: valid,
                }));
            }
            else {
                if (enterCallbackArray &&
                    // since enterCallbackArray is truthy, both record and name also are
                    record.enterCallbacks[name] === enterCallbackArray &&
                    typeof valid === 'function') {
                    enterCallbackArray.push(valid);
                }
                resolve();
            }
        };
        // wrapping with Promise.resolve allows it to work with both async and sync guards
        const guardReturn = runWithContext(() => guard.call(record && record.instances[name], to, from, ( false) ? 0 : next));
        let guardCall = Promise.resolve(guardReturn);
        if (guard.length < 3)
            guardCall = guardCall.then(next);
        if (false) {}
        guardCall.catch(err => reject(err));
    });
}
function canOnlyBeCalledOnce(next, to, from) {
    let called = 0;
    return function () {
        if (called++ === 1)
            vue_router_warn(`The "next" callback was called more than once in one navigation guard when going from "${from.fullPath}" to "${to.fullPath}". It should be called exactly one time in each navigation guard. This will fail in production.`);
        // @ts-expect-error: we put it in the original one because it's easier to check
        next._called = true;
        if (called === 1)
            next.apply(null, arguments);
    };
}
function extractComponentsGuards(matched, guardType, to, from, runWithContext = fn => fn()) {
    const guards = [];
    for (const record of matched) {
        if (false) {}
        for (const name in record.components) {
            let rawComponent = record.components[name];
            if ((false)) {}
            // skip update and leave guards if the route component is not mounted
            if (guardType !== 'beforeRouteEnter' && !record.instances[name])
                continue;
            if (isRouteComponent(rawComponent)) {
                // __vccOpts is added by vue-class-component and contain the regular options
                const options = rawComponent.__vccOpts || rawComponent;
                const guard = options[guardType];
                guard &&
                    guards.push(guardToPromiseFn(guard, to, from, record, name, runWithContext));
            }
            else {
                // start requesting the chunk already
                let componentPromise = rawComponent();
                if (false) {}
                guards.push(() => componentPromise.then(resolved => {
                    if (!resolved)
                        throw new Error(`Couldn't resolve component "${name}" at "${record.path}"`);
                    const resolvedComponent = isESModule(resolved)
                        ? resolved.default
                        : resolved;
                    // keep the resolved module for plugins like data loaders
                    record.mods[name] = resolved;
                    // replace the function with the resolved component
                    // cannot be null or undefined because we went into the for loop
                    record.components[name] = resolvedComponent;
                    // __vccOpts is added by vue-class-component and contain the regular options
                    const options = resolvedComponent.__vccOpts || resolvedComponent;
                    const guard = options[guardType];
                    return (guard &&
                        guardToPromiseFn(guard, to, from, record, name, runWithContext)());
                }));
            }
        }
    }
    return guards;
}
/**
 * Ensures a route is loaded, so it can be passed as o prop to `<RouterView>`.
 *
 * @param route - resolved route to load
 */
function loadRouteLocation(route) {
    return route.matched.every(record => record.redirect)
        ? Promise.reject(new Error('Cannot load a route that redirects.'))
        : Promise.all(route.matched.map(record => record.components &&
            Promise.all(Object.keys(record.components).reduce((promises, name) => {
                const rawComponent = record.components[name];
                if (typeof rawComponent === 'function' &&
                    !('displayName' in rawComponent)) {
                    promises.push(rawComponent().then(resolved => {
                        if (!resolved)
                            return Promise.reject(new Error(`Couldn't resolve component "${name}" at "${record.path}". Ensure you passed a function that returns a promise.`));
                        const resolvedComponent = isESModule(resolved)
                            ? resolved.default
                            : resolved;
                        // keep the resolved module for plugins like data loaders
                        record.mods[name] = resolved;
                        // replace the function with the resolved component
                        // cannot be null or undefined because we went into the for loop
                        record.components[name] = resolvedComponent;
                        return;
                    }));
                }
                return promises;
            }, [])))).then(() => route);
}

// TODO: we could allow currentRoute as a prop to expose `isActive` and
// `isExactActive` behavior should go through an RFC
/**
 * Returns the internal behavior of a {@link RouterLink} without the rendering part.
 *
 * @param props - a `to` location and an optional `replace` flag
 */
function useLink(props) {
    const router = runtime_core_esm_bundler_inject(routerKey);
    const currentRoute = runtime_core_esm_bundler_inject(routeLocationKey);
    let hasPrevious = false;
    let previousTo = null;
    const route = runtime_core_esm_bundler_computed(() => {
        const to = reactivity_esm_bundler_unref(props.to);
        if (false) {}
        return router.resolve(to);
    });
    const activeRecordIndex = runtime_core_esm_bundler_computed(() => {
        const { matched } = route.value;
        const { length } = matched;
        const routeMatched = matched[length - 1];
        const currentMatched = currentRoute.matched;
        if (!routeMatched || !currentMatched.length)
            return -1;
        const index = currentMatched.findIndex(isSameRouteRecord.bind(null, routeMatched));
        if (index > -1)
            return index;
        // possible parent record
        const parentRecordPath = getOriginalPath(matched[length - 2]);
        return (
        // we are dealing with nested routes
        length > 1 &&
            // if the parent and matched route have the same path, this link is
            // referring to the empty child. Or we currently are on a different
            // child of the same parent
            getOriginalPath(routeMatched) === parentRecordPath &&
            // avoid comparing the child with its parent
            currentMatched[currentMatched.length - 1].path !== parentRecordPath
            ? currentMatched.findIndex(isSameRouteRecord.bind(null, matched[length - 2]))
            : index);
    });
    const isActive = runtime_core_esm_bundler_computed(() => activeRecordIndex.value > -1 &&
        includesParams(currentRoute.params, route.value.params));
    const isExactActive = runtime_core_esm_bundler_computed(() => activeRecordIndex.value > -1 &&
        activeRecordIndex.value === currentRoute.matched.length - 1 &&
        isSameRouteLocationParams(currentRoute.params, route.value.params));
    function navigate(e = {}) {
        if (guardEvent(e)) {
            const p = router[reactivity_esm_bundler_unref(props.replace) ? 'replace' : 'push'](reactivity_esm_bundler_unref(props.to)
            // avoid uncaught errors are they are logged anyway
            ).catch(noop);
            if (props.viewTransition &&
                typeof document !== 'undefined' &&
                'startViewTransition' in document) {
                document.startViewTransition(() => p);
            }
            return p;
        }
        return Promise.resolve();
    }
    // devtools only
    if (false) {}
    /**
     * NOTE: update {@link _RouterLinkI}'s `$slots` type when updating this
     */
    return {
        route,
        href: runtime_core_esm_bundler_computed(() => route.value.href),
        isActive,
        isExactActive,
        navigate,
    };
}
function preferSingleVNode(vnodes) {
    return vnodes.length === 1 ? vnodes[0] : vnodes;
}
const RouterLinkImpl = /*#__PURE__*/ runtime_core_esm_bundler_defineComponent({
    name: 'RouterLink',
    compatConfig: { MODE: 3 },
    props: {
        to: {
            type: [String, Object],
            required: true,
        },
        replace: Boolean,
        activeClass: String,
        // inactiveClass: String,
        exactActiveClass: String,
        custom: Boolean,
        ariaCurrentValue: {
            type: String,
            default: 'page',
        },
        viewTransition: Boolean,
    },
    useLink,
    setup(props, { slots }) {
        const link = reactive(useLink(props));
        const { options } = runtime_core_esm_bundler_inject(routerKey);
        const elClass = runtime_core_esm_bundler_computed(() => ({
            [getLinkClass(props.activeClass, options.linkActiveClass, 'router-link-active')]: link.isActive,
            // [getLinkClass(
            //   props.inactiveClass,
            //   options.linkInactiveClass,
            //   'router-link-inactive'
            // )]: !link.isExactActive,
            [getLinkClass(props.exactActiveClass, options.linkExactActiveClass, 'router-link-exact-active')]: link.isExactActive,
        }));
        return () => {
            const children = slots.default && preferSingleVNode(slots.default(link));
            return props.custom
                ? children
                : h('a', {
                    'aria-current': link.isExactActive
                        ? props.ariaCurrentValue
                        : null,
                    href: link.href,
                    // this would override user added attrs but Vue will still add
                    // the listener, so we end up triggering both
                    onClick: link.navigate,
                    class: elClass.value,
                }, children);
        };
    },
});
// export the public type for h/tsx inference
// also to avoid inline import() in generated d.ts files
/**
 * Component to render a link that triggers a navigation on click.
 */
const RouterLink = RouterLinkImpl;
function guardEvent(e) {
    // don't redirect with control keys
    if (e.metaKey || e.altKey || e.ctrlKey || e.shiftKey)
        return;
    // don't redirect when preventDefault called
    if (e.defaultPrevented)
        return;
    // don't redirect on right click
    if (e.button !== undefined && e.button !== 0)
        return;
    // don't redirect if `target="_blank"`
    // @ts-expect-error getAttribute does exist
    if (e.currentTarget && e.currentTarget.getAttribute) {
        // @ts-expect-error getAttribute exists
        const target = e.currentTarget.getAttribute('target');
        if (/\b_blank\b/i.test(target))
            return;
    }
    // this may be a Weex event which doesn't have this method
    if (e.preventDefault)
        e.preventDefault();
    return true;
}
function includesParams(outer, inner) {
    for (const key in inner) {
        const innerValue = inner[key];
        const outerValue = outer[key];
        if (typeof innerValue === 'string') {
            if (innerValue !== outerValue)
                return false;
        }
        else {
            if (!vue_router_isArray(outerValue) ||
                outerValue.length !== innerValue.length ||
                innerValue.some((value, i) => value !== outerValue[i]))
                return false;
        }
    }
    return true;
}
/**
 * Get the original path value of a record by following its aliasOf
 * @param record
 */
function getOriginalPath(record) {
    return record ? (record.aliasOf ? record.aliasOf.path : record.path) : '';
}
/**
 * Utility class to get the active class based on defaults.
 * @param propClass
 * @param globalClass
 * @param defaultClass
 */
const getLinkClass = (propClass, globalClass, defaultClass) => propClass != null
    ? propClass
    : globalClass != null
        ? globalClass
        : defaultClass;

const RouterViewImpl = /*#__PURE__*/ runtime_core_esm_bundler_defineComponent({
    name: 'RouterView',
    // #674 we manually inherit them
    inheritAttrs: false,
    props: {
        name: {
            type: String,
            default: 'default',
        },
        route: Object,
    },
    // Better compat for @vue/compat users
    // https://github.com/vuejs/router/issues/1315
    compatConfig: { MODE: 3 },
    setup(props, { attrs, slots }) {
        ( false) && 0;
        const injectedRoute = runtime_core_esm_bundler_inject(routerViewLocationKey);
        const routeToDisplay = runtime_core_esm_bundler_computed(() => props.route || injectedRoute.value);
        const injectedDepth = runtime_core_esm_bundler_inject(viewDepthKey, 0);
        // The depth changes based on empty components option, which allows passthrough routes e.g. routes with children
        // that are used to reuse the `path` property
        const depth = runtime_core_esm_bundler_computed(() => {
            let initialDepth = reactivity_esm_bundler_unref(injectedDepth);
            const { matched } = routeToDisplay.value;
            let matchedRoute;
            while ((matchedRoute = matched[initialDepth]) &&
                !matchedRoute.components) {
                initialDepth++;
            }
            return initialDepth;
        });
        const matchedRouteRef = runtime_core_esm_bundler_computed(() => routeToDisplay.value.matched[depth.value]);
        provide(viewDepthKey, runtime_core_esm_bundler_computed(() => depth.value + 1));
        provide(matchedRouteKey, matchedRouteRef);
        provide(routerViewLocationKey, routeToDisplay);
        const viewRef = reactivity_esm_bundler_ref();
        // watch at the same time the component instance, the route record we are
        // rendering, and the name
        runtime_core_esm_bundler_watch(() => [viewRef.value, matchedRouteRef.value, props.name], ([instance, to, name], [oldInstance, from, oldName]) => {
            // copy reused instances
            if (to) {
                // this will update the instance for new instances as well as reused
                // instances when navigating to a new route
                to.instances[name] = instance;
                // the component instance is reused for a different route or name, so
                // we copy any saved update or leave guards. With async setup, the
                // mounting component will mount before the matchedRoute changes,
                // making instance === oldInstance, so we check if guards have been
                // added before. This works because we remove guards when
                // unmounting/deactivating components
                if (from && from !== to && instance && instance === oldInstance) {
                    if (!to.leaveGuards.size) {
                        to.leaveGuards = from.leaveGuards;
                    }
                    if (!to.updateGuards.size) {
                        to.updateGuards = from.updateGuards;
                    }
                }
            }
            // trigger beforeRouteEnter next callbacks
            if (instance &&
                to &&
                // if there is no instance but to and from are the same this might be
                // the first visit
                (!from || !isSameRouteRecord(to, from) || !oldInstance)) {
                (to.enterCallbacks[name] || []).forEach(callback => callback(instance));
            }
        }, { flush: 'post' });
        return () => {
            const route = routeToDisplay.value;
            // we need the value at the time we render because when we unmount, we
            // navigated to a different location so the value is different
            const currentName = props.name;
            const matchedRoute = matchedRouteRef.value;
            const ViewComponent = matchedRoute && matchedRoute.components[currentName];
            if (!ViewComponent) {
                return vue_router_normalizeSlot(slots.default, { Component: ViewComponent, route });
            }
            // props from route configuration
            const routePropsOption = matchedRoute.props[currentName];
            const routeProps = routePropsOption
                ? routePropsOption === true
                    ? route.params
                    : typeof routePropsOption === 'function'
                        ? routePropsOption(route)
                        : routePropsOption
                : null;
            const onVnodeUnmounted = vnode => {
                // remove the instance reference to prevent leak
                if (vnode.component.isUnmounted) {
                    matchedRoute.instances[currentName] = null;
                }
            };
            const component = h(ViewComponent, vue_router_assign({}, routeProps, attrs, {
                onVnodeUnmounted,
                ref: viewRef,
            }));
            if (false) {}
            return (
            // pass the vnode to the slot as a prop.
            // h and <component :is="..."> both accept vnodes
            vue_router_normalizeSlot(slots.default, { Component: component, route }) ||
                component);
        };
    },
});
function vue_router_normalizeSlot(slot, data) {
    if (!slot)
        return null;
    const slotContent = slot(data);
    return slotContent.length === 1 ? slotContent[0] : slotContent;
}
// export the public type for h/tsx inference
// also to avoid inline import() in generated d.ts files
/**
 * Component to display the current route the user is at.
 */
const RouterView = RouterViewImpl;
// warn against deprecated usage with <transition> & <keep-alive>
// due to functional component being no longer eager in Vue 3
function warnDeprecatedUsage() {
    const instance = getCurrentInstance();
    const parentName = instance.parent && instance.parent.type.name;
    const parentSubTreeType = instance.parent && instance.parent.subTree && instance.parent.subTree.type;
    if (parentName &&
        (parentName === 'KeepAlive' || parentName.includes('Transition')) &&
        typeof parentSubTreeType === 'object' &&
        parentSubTreeType.name === 'RouterView') {
        const comp = parentName === 'KeepAlive' ? 'keep-alive' : 'transition';
        vue_router_warn(`<router-view> can no longer be used directly inside <transition> or <keep-alive>.\n` +
            `Use slot props instead:\n\n` +
            `<router-view v-slot="{ Component }">\n` +
            `  <${comp}>\n` +
            `    <component :is="Component" />\n` +
            `  </${comp}>\n` +
            `</router-view>`);
    }
}

/**
 * Copies a route location and removes any problematic properties that cannot be shown in devtools (e.g. Vue instances).
 *
 * @param routeLocation - routeLocation to format
 * @param tooltip - optional tooltip
 * @returns a copy of the routeLocation
 */
function formatRouteLocation(routeLocation, tooltip) {
    const copy = vue_router_assign({}, routeLocation, {
        // remove variables that can contain vue instances
        matched: routeLocation.matched.map(matched => omit(matched, ['instances', 'children', 'aliasOf'])),
    });
    return {
        _custom: {
            type: null,
            readOnly: true,
            display: routeLocation.fullPath,
            tooltip,
            value: copy,
        },
    };
}
function formatDisplay(display) {
    return {
        _custom: {
            display,
        },
    };
}
// to support multiple router instances
let routerId = 0;
function addDevtools(app, router, matcher) {
    // Take over router.beforeEach and afterEach
    // make sure we are not registering the devtool twice
    if (router.__hasDevtools)
        return;
    router.__hasDevtools = true;
    // increment to support multiple router instances
    const id = routerId++;
    setupDevtoolsPlugin({
        id: 'org.vuejs.router' + (id ? '.' + id : ''),
        label: 'Vue Router',
        packageName: 'vue-router',
        homepage: 'https://router.vuejs.org',
        logo: 'https://router.vuejs.org/logo.png',
        componentStateTypes: ['Routing'],
        app,
    }, api => {
        if (typeof api.now !== 'function') {
            console.warn('[Vue Router]: You seem to be using an outdated version of Vue Devtools. Are you still using the Beta release instead of the stable one? You can find the links at https://devtools.vuejs.org/guide/installation.html.');
        }
        // display state added by the router
        api.on.inspectComponent((payload, ctx) => {
            if (payload.instanceData) {
                payload.instanceData.state.push({
                    type: 'Routing',
                    key: '$route',
                    editable: false,
                    value: formatRouteLocation(router.currentRoute.value, 'Current Route'),
                });
            }
        });
        // mark router-link as active and display tags on router views
        api.on.visitComponentTree(({ treeNode: node, componentInstance }) => {
            if (componentInstance.__vrv_devtools) {
                const info = componentInstance.__vrv_devtools;
                node.tags.push({
                    label: (info.name ? `${info.name.toString()}: ` : '') + info.path,
                    textColor: 0,
                    tooltip: 'This component is rendered by &lt;router-view&gt;',
                    backgroundColor: PINK_500,
                });
            }
            // if multiple useLink are used
            if (vue_router_isArray(componentInstance.__vrl_devtools)) {
                componentInstance.__devtoolsApi = api;
                componentInstance.__vrl_devtools.forEach(devtoolsData => {
                    let label = devtoolsData.route.path;
                    let backgroundColor = ORANGE_400;
                    let tooltip = '';
                    let textColor = 0;
                    if (devtoolsData.error) {
                        label = devtoolsData.error;
                        backgroundColor = RED_100;
                        textColor = RED_700;
                    }
                    else if (devtoolsData.isExactActive) {
                        backgroundColor = LIME_500;
                        tooltip = 'This is exactly active';
                    }
                    else if (devtoolsData.isActive) {
                        backgroundColor = BLUE_600;
                        tooltip = 'This link is active';
                    }
                    node.tags.push({
                        label,
                        textColor,
                        tooltip,
                        backgroundColor,
                    });
                });
            }
        });
        watch(router.currentRoute, () => {
            // refresh active state
            refreshRoutesView();
            api.notifyComponentUpdate();
            api.sendInspectorTree(routerInspectorId);
            api.sendInspectorState(routerInspectorId);
        });
        const navigationsLayerId = 'router:navigations:' + id;
        api.addTimelineLayer({
            id: navigationsLayerId,
            label: `Router${id ? ' ' + id : ''} Navigations`,
            color: 0x40a8c4,
        });
        // const errorsLayerId = 'router:errors'
        // api.addTimelineLayer({
        //   id: errorsLayerId,
        //   label: 'Router Errors',
        //   color: 0xea5455,
        // })
        router.onError((error, to) => {
            api.addTimelineEvent({
                layerId: navigationsLayerId,
                event: {
                    title: 'Error during Navigation',
                    subtitle: to.fullPath,
                    logType: 'error',
                    time: api.now(),
                    data: { error },
                    groupId: to.meta.__navigationId,
                },
            });
        });
        // attached to `meta` and used to group events
        let navigationId = 0;
        router.beforeEach((to, from) => {
            const data = {
                guard: formatDisplay('beforeEach'),
                from: formatRouteLocation(from, 'Current Location during this navigation'),
                to: formatRouteLocation(to, 'Target location'),
            };
            // Used to group navigations together, hide from devtools
            Object.defineProperty(to.meta, '__navigationId', {
                value: navigationId++,
            });
            api.addTimelineEvent({
                layerId: navigationsLayerId,
                event: {
                    time: api.now(),
                    title: 'Start of navigation',
                    subtitle: to.fullPath,
                    data,
                    groupId: to.meta.__navigationId,
                },
            });
        });
        router.afterEach((to, from, failure) => {
            const data = {
                guard: formatDisplay('afterEach'),
            };
            if (failure) {
                data.failure = {
                    _custom: {
                        type: Error,
                        readOnly: true,
                        display: failure ? failure.message : '',
                        tooltip: 'Navigation Failure',
                        value: failure,
                    },
                };
                data.status = formatDisplay('❌');
            }
            else {
                data.status = formatDisplay('✅');
            }
            // we set here to have the right order
            data.from = formatRouteLocation(from, 'Current Location during this navigation');
            data.to = formatRouteLocation(to, 'Target location');
            api.addTimelineEvent({
                layerId: navigationsLayerId,
                event: {
                    title: 'End of navigation',
                    subtitle: to.fullPath,
                    time: api.now(),
                    data,
                    logType: failure ? 'warning' : 'default',
                    groupId: to.meta.__navigationId,
                },
            });
        });
        /**
         * Inspector of Existing routes
         */
        const routerInspectorId = 'router-inspector:' + id;
        api.addInspector({
            id: routerInspectorId,
            label: 'Routes' + (id ? ' ' + id : ''),
            icon: 'book',
            treeFilterPlaceholder: 'Search routes',
        });
        function refreshRoutesView() {
            // the routes view isn't active
            if (!activeRoutesPayload)
                return;
            const payload = activeRoutesPayload;
            // children routes will appear as nested
            let routes = matcher.getRoutes().filter(route => !route.parent ||
                // these routes have a parent with no component which will not appear in the view
                // therefore we still need to include them
                !route.parent.record.components);
            // reset match state to false
            routes.forEach(resetMatchStateOnRouteRecord);
            // apply a match state if there is a payload
            if (payload.filter) {
                routes = routes.filter(route => 
                // save matches state based on the payload
                isRouteMatching(route, payload.filter.toLowerCase()));
            }
            // mark active routes
            routes.forEach(route => markRouteRecordActive(route, router.currentRoute.value));
            payload.rootNodes = routes.map(formatRouteRecordForInspector);
        }
        let activeRoutesPayload;
        api.on.getInspectorTree(payload => {
            activeRoutesPayload = payload;
            if (payload.app === app && payload.inspectorId === routerInspectorId) {
                refreshRoutesView();
            }
        });
        /**
         * Display information about the currently selected route record
         */
        api.on.getInspectorState(payload => {
            if (payload.app === app && payload.inspectorId === routerInspectorId) {
                const routes = matcher.getRoutes();
                const route = routes.find(route => route.record.__vd_id === payload.nodeId);
                if (route) {
                    payload.state = {
                        options: formatRouteRecordMatcherForStateInspector(route),
                    };
                }
            }
        });
        api.sendInspectorTree(routerInspectorId);
        api.sendInspectorState(routerInspectorId);
    });
}
function modifierForKey(key) {
    if (key.optional) {
        return key.repeatable ? '*' : '?';
    }
    else {
        return key.repeatable ? '+' : '';
    }
}
function formatRouteRecordMatcherForStateInspector(route) {
    const { record } = route;
    const fields = [
        { editable: false, key: 'path', value: record.path },
    ];
    if (record.name != null) {
        fields.push({
            editable: false,
            key: 'name',
            value: record.name,
        });
    }
    fields.push({ editable: false, key: 'regexp', value: route.re });
    if (route.keys.length) {
        fields.push({
            editable: false,
            key: 'keys',
            value: {
                _custom: {
                    type: null,
                    readOnly: true,
                    display: route.keys
                        .map(key => `${key.name}${modifierForKey(key)}`)
                        .join(' '),
                    tooltip: 'Param keys',
                    value: route.keys,
                },
            },
        });
    }
    if (record.redirect != null) {
        fields.push({
            editable: false,
            key: 'redirect',
            value: record.redirect,
        });
    }
    if (route.alias.length) {
        fields.push({
            editable: false,
            key: 'aliases',
            value: route.alias.map(alias => alias.record.path),
        });
    }
    if (Object.keys(route.record.meta).length) {
        fields.push({
            editable: false,
            key: 'meta',
            value: route.record.meta,
        });
    }
    fields.push({
        key: 'score',
        editable: false,
        value: {
            _custom: {
                type: null,
                readOnly: true,
                display: route.score.map(score => score.join(', ')).join(' | '),
                tooltip: 'Score used to sort routes',
                value: route.score,
            },
        },
    });
    return fields;
}
/**
 * Extracted from tailwind palette
 */
const PINK_500 = 0xec4899;
const BLUE_600 = 0x2563eb;
const LIME_500 = 0x84cc16;
const CYAN_400 = 0x22d3ee;
const ORANGE_400 = 0xfb923c;
// const GRAY_100 = 0xf4f4f5
const DARK = 0x666666;
const RED_100 = 0xfee2e2;
const RED_700 = 0xb91c1c;
function formatRouteRecordForInspector(route) {
    const tags = [];
    const { record } = route;
    if (record.name != null) {
        tags.push({
            label: String(record.name),
            textColor: 0,
            backgroundColor: CYAN_400,
        });
    }
    if (record.aliasOf) {
        tags.push({
            label: 'alias',
            textColor: 0,
            backgroundColor: ORANGE_400,
        });
    }
    if (route.__vd_match) {
        tags.push({
            label: 'matches',
            textColor: 0,
            backgroundColor: PINK_500,
        });
    }
    if (route.__vd_exactActive) {
        tags.push({
            label: 'exact',
            textColor: 0,
            backgroundColor: LIME_500,
        });
    }
    if (route.__vd_active) {
        tags.push({
            label: 'active',
            textColor: 0,
            backgroundColor: BLUE_600,
        });
    }
    if (record.redirect) {
        tags.push({
            label: typeof record.redirect === 'string'
                ? `redirect: ${record.redirect}`
                : 'redirects',
            textColor: 0xffffff,
            backgroundColor: DARK,
        });
    }
    // add an id to be able to select it. Using the `path` is not possible because
    // empty path children would collide with their parents
    let id = record.__vd_id;
    if (id == null) {
        id = String(routeRecordId++);
        record.__vd_id = id;
    }
    return {
        id,
        label: record.path,
        tags,
        children: route.children.map(formatRouteRecordForInspector),
    };
}
//  incremental id for route records and inspector state
let routeRecordId = 0;
const EXTRACT_REGEXP_RE = /^\/(.*)\/([a-z]*)$/;
function markRouteRecordActive(route, currentRoute) {
    // no route will be active if matched is empty
    // reset the matching state
    const isExactActive = currentRoute.matched.length &&
        isSameRouteRecord(currentRoute.matched[currentRoute.matched.length - 1], route.record);
    route.__vd_exactActive = route.__vd_active = isExactActive;
    if (!isExactActive) {
        route.__vd_active = currentRoute.matched.some(match => isSameRouteRecord(match, route.record));
    }
    route.children.forEach(childRoute => markRouteRecordActive(childRoute, currentRoute));
}
function resetMatchStateOnRouteRecord(route) {
    route.__vd_match = false;
    route.children.forEach(resetMatchStateOnRouteRecord);
}
function isRouteMatching(route, filter) {
    const found = String(route.re).match(EXTRACT_REGEXP_RE);
    route.__vd_match = false;
    if (!found || found.length < 3) {
        return false;
    }
    // use a regexp without $ at the end to match nested routes better
    const nonEndingRE = new RegExp(found[1].replace(/\$$/, ''), found[2]);
    if (nonEndingRE.test(filter)) {
        // mark children as matches
        route.children.forEach(child => isRouteMatching(child, filter));
        // exception case: `/`
        if (route.record.path !== '/' || filter === '/') {
            route.__vd_match = route.re.test(filter);
            return true;
        }
        // hide the / route
        return false;
    }
    const path = route.record.path.toLowerCase();
    const decodedPath = decode(path);
    // also allow partial matching on the path
    if (!filter.startsWith('/') &&
        (decodedPath.includes(filter) || path.includes(filter)))
        return true;
    if (decodedPath.startsWith(filter) || path.startsWith(filter))
        return true;
    if (route.record.name && String(route.record.name).includes(filter))
        return true;
    return route.children.some(child => isRouteMatching(child, filter));
}
function omit(obj, keys) {
    const ret = {};
    for (const key in obj) {
        if (!keys.includes(key)) {
            // @ts-expect-error
            ret[key] = obj[key];
        }
    }
    return ret;
}

/**
 * Creates a Router instance that can be used by a Vue app.
 *
 * @param options - {@link RouterOptions}
 */
function createRouter(options) {
    const matcher = createRouterMatcher(options.routes, options);
    const parseQuery$1 = options.parseQuery || parseQuery;
    const stringifyQuery$1 = options.stringifyQuery || stringifyQuery;
    const routerHistory = options.history;
    if (false)
        {}
    const beforeGuards = useCallbacks();
    const beforeResolveGuards = useCallbacks();
    const afterGuards = useCallbacks();
    const currentRoute = reactivity_esm_bundler_shallowRef(START_LOCATION_NORMALIZED);
    let pendingLocation = START_LOCATION_NORMALIZED;
    // leave the scrollRestoration if no scrollBehavior is provided
    if (isBrowser && options.scrollBehavior && 'scrollRestoration' in history) {
        history.scrollRestoration = 'manual';
    }
    const normalizeParams = applyToParams.bind(null, paramValue => '' + paramValue);
    const encodeParams = applyToParams.bind(null, encodeParam);
    const decodeParams = 
    // @ts-expect-error: intentionally avoid the type check
    applyToParams.bind(null, decode);
    function addRoute(parentOrRoute, route) {
        let parent;
        let record;
        if (isRouteName(parentOrRoute)) {
            parent = matcher.getRecordMatcher(parentOrRoute);
            if (false) {}
            record = route;
        }
        else {
            record = parentOrRoute;
        }
        return matcher.addRoute(record, parent);
    }
    function removeRoute(name) {
        const recordMatcher = matcher.getRecordMatcher(name);
        if (recordMatcher) {
            matcher.removeRoute(recordMatcher);
        }
        else if ((false)) {}
    }
    function getRoutes() {
        return matcher.getRoutes().map(routeMatcher => routeMatcher.record);
    }
    function hasRoute(name) {
        return !!matcher.getRecordMatcher(name);
    }
    function resolve(rawLocation, currentLocation) {
        // const resolve: Router['resolve'] = (rawLocation: RouteLocationRaw, currentLocation) => {
        // const objectLocation = routerLocationAsObject(rawLocation)
        // we create a copy to modify it later
        currentLocation = vue_router_assign({}, currentLocation || currentRoute.value);
        if (typeof rawLocation === 'string') {
            const locationNormalized = parseURL(parseQuery$1, rawLocation, currentLocation.path);
            const matchedRoute = matcher.resolve({ path: locationNormalized.path }, currentLocation);
            const href = routerHistory.createHref(locationNormalized.fullPath);
            if ((false)) {}
            // locationNormalized is always a new object
            return vue_router_assign(locationNormalized, matchedRoute, {
                params: decodeParams(matchedRoute.params),
                hash: decode(locationNormalized.hash),
                redirectedFrom: undefined,
                href,
            });
        }
        if (false) {}
        let matcherLocation;
        // path could be relative in object as well
        if (rawLocation.path != null) {
            if (false) {}
            matcherLocation = vue_router_assign({}, rawLocation, {
                path: parseURL(parseQuery$1, rawLocation.path, currentLocation.path).path,
            });
        }
        else {
            // remove any nullish param
            const targetParams = vue_router_assign({}, rawLocation.params);
            for (const key in targetParams) {
                if (targetParams[key] == null) {
                    delete targetParams[key];
                }
            }
            // pass encoded values to the matcher, so it can produce encoded path and fullPath
            matcherLocation = vue_router_assign({}, rawLocation, {
                params: encodeParams(targetParams),
            });
            // current location params are decoded, we need to encode them in case the
            // matcher merges the params
            currentLocation.params = encodeParams(currentLocation.params);
        }
        const matchedRoute = matcher.resolve(matcherLocation, currentLocation);
        const hash = rawLocation.hash || '';
        if (false) {}
        // the matcher might have merged current location params, so
        // we need to run the decoding again
        matchedRoute.params = normalizeParams(decodeParams(matchedRoute.params));
        const fullPath = stringifyURL(stringifyQuery$1, vue_router_assign({}, rawLocation, {
            hash: encodeHash(hash),
            path: matchedRoute.path,
        }));
        const href = routerHistory.createHref(fullPath);
        if ((false)) {}
        return vue_router_assign({
            fullPath,
            // keep the hash encoded so fullPath is effectively path + encodedQuery +
            // hash
            hash,
            query: 
            // if the user is using a custom query lib like qs, we might have
            // nested objects, so we keep the query as is, meaning it can contain
            // numbers at `$route.query`, but at the point, the user will have to
            // use their own type anyway.
            // https://github.com/vuejs/router/issues/328#issuecomment-649481567
            stringifyQuery$1 === stringifyQuery
                ? normalizeQuery(rawLocation.query)
                : (rawLocation.query || {}),
        }, matchedRoute, {
            redirectedFrom: undefined,
            href,
        });
    }
    function locationAsObject(to) {
        return typeof to === 'string'
            ? parseURL(parseQuery$1, to, currentRoute.value.path)
            : vue_router_assign({}, to);
    }
    function checkCanceledNavigation(to, from) {
        if (pendingLocation !== to) {
            return createRouterError(8 /* ErrorTypes.NAVIGATION_CANCELLED */, {
                from,
                to,
            });
        }
    }
    function push(to) {
        return pushWithRedirect(to);
    }
    function replace(to) {
        return push(vue_router_assign(locationAsObject(to), { replace: true }));
    }
    function handleRedirectRecord(to) {
        const lastMatched = to.matched[to.matched.length - 1];
        if (lastMatched && lastMatched.redirect) {
            const { redirect } = lastMatched;
            let newTargetLocation = typeof redirect === 'function' ? redirect(to) : redirect;
            if (typeof newTargetLocation === 'string') {
                newTargetLocation =
                    newTargetLocation.includes('?') || newTargetLocation.includes('#')
                        ? (newTargetLocation = locationAsObject(newTargetLocation))
                        : // force empty params
                            { path: newTargetLocation };
                // @ts-expect-error: force empty params when a string is passed to let
                // the router parse them again
                newTargetLocation.params = {};
            }
            if (false) {}
            return vue_router_assign({
                query: to.query,
                hash: to.hash,
                // avoid transferring params if the redirect has a path
                params: newTargetLocation.path != null ? {} : to.params,
            }, newTargetLocation);
        }
    }
    function pushWithRedirect(to, redirectedFrom) {
        const targetLocation = (pendingLocation = resolve(to));
        const from = currentRoute.value;
        const data = to.state;
        const force = to.force;
        // to could be a string where `replace` is a function
        const replace = to.replace === true;
        const shouldRedirect = handleRedirectRecord(targetLocation);
        if (shouldRedirect)
            return pushWithRedirect(vue_router_assign(locationAsObject(shouldRedirect), {
                state: typeof shouldRedirect === 'object'
                    ? vue_router_assign({}, data, shouldRedirect.state)
                    : data,
                force,
                replace,
            }), 
            // keep original redirectedFrom if it exists
            redirectedFrom || targetLocation);
        // if it was a redirect we already called `pushWithRedirect` above
        const toLocation = targetLocation;
        toLocation.redirectedFrom = redirectedFrom;
        let failure;
        if (!force && isSameRouteLocation(stringifyQuery$1, from, targetLocation)) {
            failure = createRouterError(16 /* ErrorTypes.NAVIGATION_DUPLICATED */, { to: toLocation, from });
            // trigger scroll to allow scrolling to the same anchor
            handleScroll(from, from, 
            // this is a push, the only way for it to be triggered from a
            // history.listen is with a redirect, which makes it become a push
            true, 
            // This cannot be the first navigation because the initial location
            // cannot be manually navigated to
            false);
        }
        return (failure ? Promise.resolve(failure) : navigate(toLocation, from))
            .catch((error) => isNavigationFailure(error)
            ? // navigation redirects still mark the router as ready
                isNavigationFailure(error, 2 /* ErrorTypes.NAVIGATION_GUARD_REDIRECT */)
                    ? error
                    : markAsReady(error) // also returns the error
            : // reject any unknown error
                triggerError(error, toLocation, from))
            .then((failure) => {
            if (failure) {
                if (isNavigationFailure(failure, 2 /* ErrorTypes.NAVIGATION_GUARD_REDIRECT */)) {
                    if (false) {}
                    return pushWithRedirect(
                    // keep options
                    vue_router_assign({
                        // preserve an existing replacement but allow the redirect to override it
                        replace,
                    }, locationAsObject(failure.to), {
                        state: typeof failure.to === 'object'
                            ? vue_router_assign({}, data, failure.to.state)
                            : data,
                        force,
                    }), 
                    // preserve the original redirectedFrom if any
                    redirectedFrom || toLocation);
                }
            }
            else {
                // if we fail we don't finalize the navigation
                failure = finalizeNavigation(toLocation, from, true, replace, data);
            }
            triggerAfterEach(toLocation, from, failure);
            return failure;
        });
    }
    /**
     * Helper to reject and skip all navigation guards if a new navigation happened
     * @param to
     * @param from
     */
    function checkCanceledNavigationAndReject(to, from) {
        const error = checkCanceledNavigation(to, from);
        return error ? Promise.reject(error) : Promise.resolve();
    }
    function runWithContext(fn) {
        const app = installedApps.values().next().value;
        // support Vue < 3.3
        return app && typeof app.runWithContext === 'function'
            ? app.runWithContext(fn)
            : fn();
    }
    // TODO: refactor the whole before guards by internally using router.beforeEach
    function navigate(to, from) {
        let guards;
        const [leavingRecords, updatingRecords, enteringRecords] = extractChangingRecords(to, from);
        // all components here have been resolved once because we are leaving
        guards = extractComponentsGuards(leavingRecords.reverse(), 'beforeRouteLeave', to, from);
        // leavingRecords is already reversed
        for (const record of leavingRecords) {
            record.leaveGuards.forEach(guard => {
                guards.push(guardToPromiseFn(guard, to, from));
            });
        }
        const canceledNavigationCheck = checkCanceledNavigationAndReject.bind(null, to, from);
        guards.push(canceledNavigationCheck);
        // run the queue of per route beforeRouteLeave guards
        return (runGuardQueue(guards)
            .then(() => {
            // check global guards beforeEach
            guards = [];
            for (const guard of beforeGuards.list()) {
                guards.push(guardToPromiseFn(guard, to, from));
            }
            guards.push(canceledNavigationCheck);
            return runGuardQueue(guards);
        })
            .then(() => {
            // check in components beforeRouteUpdate
            guards = extractComponentsGuards(updatingRecords, 'beforeRouteUpdate', to, from);
            for (const record of updatingRecords) {
                record.updateGuards.forEach(guard => {
                    guards.push(guardToPromiseFn(guard, to, from));
                });
            }
            guards.push(canceledNavigationCheck);
            // run the queue of per route beforeEnter guards
            return runGuardQueue(guards);
        })
            .then(() => {
            // check the route beforeEnter
            guards = [];
            for (const record of enteringRecords) {
                // do not trigger beforeEnter on reused views
                if (record.beforeEnter) {
                    if (vue_router_isArray(record.beforeEnter)) {
                        for (const beforeEnter of record.beforeEnter)
                            guards.push(guardToPromiseFn(beforeEnter, to, from));
                    }
                    else {
                        guards.push(guardToPromiseFn(record.beforeEnter, to, from));
                    }
                }
            }
            guards.push(canceledNavigationCheck);
            // run the queue of per route beforeEnter guards
            return runGuardQueue(guards);
        })
            .then(() => {
            // NOTE: at this point to.matched is normalized and does not contain any () => Promise<Component>
            // clear existing enterCallbacks, these are added by extractComponentsGuards
            to.matched.forEach(record => (record.enterCallbacks = {}));
            // check in-component beforeRouteEnter
            guards = extractComponentsGuards(enteringRecords, 'beforeRouteEnter', to, from, runWithContext);
            guards.push(canceledNavigationCheck);
            // run the queue of per route beforeEnter guards
            return runGuardQueue(guards);
        })
            .then(() => {
            // check global guards beforeResolve
            guards = [];
            for (const guard of beforeResolveGuards.list()) {
                guards.push(guardToPromiseFn(guard, to, from));
            }
            guards.push(canceledNavigationCheck);
            return runGuardQueue(guards);
        })
            // catch any navigation canceled
            .catch(err => isNavigationFailure(err, 8 /* ErrorTypes.NAVIGATION_CANCELLED */)
            ? err
            : Promise.reject(err)));
    }
    function triggerAfterEach(to, from, failure) {
        // navigation is confirmed, call afterGuards
        // TODO: wrap with error handlers
        afterGuards
            .list()
            .forEach(guard => runWithContext(() => guard(to, from, failure)));
    }
    /**
     * - Cleans up any navigation guards
     * - Changes the url if necessary
     * - Calls the scrollBehavior
     */
    function finalizeNavigation(toLocation, from, isPush, replace, data) {
        // a more recent navigation took place
        const error = checkCanceledNavigation(toLocation, from);
        if (error)
            return error;
        // only consider as push if it's not the first navigation
        const isFirstNavigation = from === START_LOCATION_NORMALIZED;
        const state = !isBrowser ? {} : history.state;
        // change URL only if the user did a push/replace and if it's not the initial navigation because
        // it's just reflecting the url
        if (isPush) {
            // on the initial navigation, we want to reuse the scroll position from
            // history state if it exists
            if (replace || isFirstNavigation)
                routerHistory.replace(toLocation.fullPath, vue_router_assign({
                    scroll: isFirstNavigation && state && state.scroll,
                }, data));
            else
                routerHistory.push(toLocation.fullPath, data);
        }
        // accept current navigation
        currentRoute.value = toLocation;
        handleScroll(toLocation, from, isPush, isFirstNavigation);
        markAsReady();
    }
    let removeHistoryListener;
    // attach listener to history to trigger navigations
    function setupListeners() {
        // avoid setting up listeners twice due to an invalid first navigation
        if (removeHistoryListener)
            return;
        removeHistoryListener = routerHistory.listen((to, _from, info) => {
            if (!router.listening)
                return;
            // cannot be a redirect route because it was in history
            const toLocation = resolve(to);
            // due to dynamic routing, and to hash history with manual navigation
            // (manually changing the url or calling history.hash = '#/somewhere'),
            // there could be a redirect record in history
            const shouldRedirect = handleRedirectRecord(toLocation);
            if (shouldRedirect) {
                pushWithRedirect(vue_router_assign(shouldRedirect, { replace: true, force: true }), toLocation).catch(noop);
                return;
            }
            pendingLocation = toLocation;
            const from = currentRoute.value;
            // TODO: should be moved to web history?
            if (isBrowser) {
                saveScrollPosition(getScrollKey(from.fullPath, info.delta), computeScrollPosition());
            }
            navigate(toLocation, from)
                .catch((error) => {
                if (isNavigationFailure(error, 4 /* ErrorTypes.NAVIGATION_ABORTED */ | 8 /* ErrorTypes.NAVIGATION_CANCELLED */)) {
                    return error;
                }
                if (isNavigationFailure(error, 2 /* ErrorTypes.NAVIGATION_GUARD_REDIRECT */)) {
                    // Here we could call if (info.delta) routerHistory.go(-info.delta,
                    // false) but this is bug prone as we have no way to wait the
                    // navigation to be finished before calling pushWithRedirect. Using
                    // a setTimeout of 16ms seems to work but there is no guarantee for
                    // it to work on every browser. So instead we do not restore the
                    // history entry and trigger a new navigation as requested by the
                    // navigation guard.
                    // the error is already handled by router.push we just want to avoid
                    // logging the error
                    pushWithRedirect(vue_router_assign(locationAsObject(error.to), {
                        force: true,
                    }), toLocation
                    // avoid an uncaught rejection, let push call triggerError
                    )
                        .then(failure => {
                        // manual change in hash history #916 ending up in the URL not
                        // changing, but it was changed by the manual url change, so we
                        // need to manually change it ourselves
                        if (isNavigationFailure(failure, 4 /* ErrorTypes.NAVIGATION_ABORTED */ |
                            16 /* ErrorTypes.NAVIGATION_DUPLICATED */) &&
                            !info.delta &&
                            info.type === NavigationType.pop) {
                            routerHistory.go(-1, false);
                        }
                    })
                        .catch(noop);
                    // avoid the then branch
                    return Promise.reject();
                }
                // do not restore history on unknown direction
                if (info.delta) {
                    routerHistory.go(-info.delta, false);
                }
                // unrecognized error, transfer to the global handler
                return triggerError(error, toLocation, from);
            })
                .then((failure) => {
                failure =
                    failure ||
                        finalizeNavigation(
                        // after navigation, all matched components are resolved
                        toLocation, from, false);
                // revert the navigation
                if (failure) {
                    if (info.delta &&
                        // a new navigation has been triggered, so we do not want to revert, that will change the current history
                        // entry while a different route is displayed
                        !isNavigationFailure(failure, 8 /* ErrorTypes.NAVIGATION_CANCELLED */)) {
                        routerHistory.go(-info.delta, false);
                    }
                    else if (info.type === NavigationType.pop &&
                        isNavigationFailure(failure, 4 /* ErrorTypes.NAVIGATION_ABORTED */ | 16 /* ErrorTypes.NAVIGATION_DUPLICATED */)) {
                        // manual change in hash history #916
                        // it's like a push but lacks the information of the direction
                        routerHistory.go(-1, false);
                    }
                }
                triggerAfterEach(toLocation, from, failure);
            })
                // avoid warnings in the console about uncaught rejections, they are logged by triggerErrors
                .catch(noop);
        });
    }
    // Initialization and Errors
    let readyHandlers = useCallbacks();
    let errorListeners = useCallbacks();
    let ready;
    /**
     * Trigger errorListeners added via onError and throws the error as well
     *
     * @param error - error to throw
     * @param to - location we were navigating to when the error happened
     * @param from - location we were navigating from when the error happened
     * @returns the error as a rejected promise
     */
    function triggerError(error, to, from) {
        markAsReady(error);
        const list = errorListeners.list();
        if (list.length) {
            list.forEach(handler => handler(error, to, from));
        }
        else {
            if ((false)) {}
            console.error(error);
        }
        // reject the error no matter there were error listeners or not
        return Promise.reject(error);
    }
    function isReady() {
        if (ready && currentRoute.value !== START_LOCATION_NORMALIZED)
            return Promise.resolve();
        return new Promise((resolve, reject) => {
            readyHandlers.add([resolve, reject]);
        });
    }
    function markAsReady(err) {
        if (!ready) {
            // still not ready if an error happened
            ready = !err;
            setupListeners();
            readyHandlers
                .list()
                .forEach(([resolve, reject]) => (err ? reject(err) : resolve()));
            readyHandlers.reset();
        }
        return err;
    }
    // Scroll behavior
    function handleScroll(to, from, isPush, isFirstNavigation) {
        const { scrollBehavior } = options;
        if (!isBrowser || !scrollBehavior)
            return Promise.resolve();
        const scrollPosition = (!isPush && getSavedScrollPosition(getScrollKey(to.fullPath, 0))) ||
            ((isFirstNavigation || !isPush) &&
                history.state &&
                history.state.scroll) ||
            null;
        return nextTick()
            .then(() => scrollBehavior(to, from, scrollPosition))
            .then(position => position && scrollToPosition(position))
            .catch(err => triggerError(err, to, from));
    }
    const go = (delta) => routerHistory.go(delta);
    let started;
    const installedApps = new Set();
    const router = {
        currentRoute,
        listening: true,
        addRoute,
        removeRoute,
        clearRoutes: matcher.clearRoutes,
        hasRoute,
        getRoutes,
        resolve,
        options,
        push,
        replace,
        go,
        back: () => go(-1),
        forward: () => go(1),
        beforeEach: beforeGuards.add,
        beforeResolve: beforeResolveGuards.add,
        afterEach: afterGuards.add,
        onError: errorListeners.add,
        isReady,
        install(app) {
            const router = this;
            app.component('RouterLink', RouterLink);
            app.component('RouterView', RouterView);
            app.config.globalProperties.$router = router;
            Object.defineProperty(app.config.globalProperties, '$route', {
                enumerable: true,
                get: () => reactivity_esm_bundler_unref(currentRoute),
            });
            // this initial navigation is only necessary on client, on server it doesn't
            // make sense because it will create an extra unnecessary navigation and could
            // lead to problems
            if (isBrowser &&
                // used for the initial navigation client side to avoid pushing
                // multiple times when the router is used in multiple apps
                !started &&
                currentRoute.value === START_LOCATION_NORMALIZED) {
                // see above
                started = true;
                push(routerHistory.location).catch(err => {
                    if ((false))
                        {}
                });
            }
            const reactiveRoute = {};
            for (const key in START_LOCATION_NORMALIZED) {
                Object.defineProperty(reactiveRoute, key, {
                    get: () => currentRoute.value[key],
                    enumerable: true,
                });
            }
            app.provide(routerKey, router);
            app.provide(routeLocationKey, shallowReactive(reactiveRoute));
            app.provide(routerViewLocationKey, currentRoute);
            const unmountApp = app.unmount;
            installedApps.add(app);
            app.unmount = function () {
                installedApps.delete(app);
                // the router is not attached to an app anymore
                if (installedApps.size < 1) {
                    // invalidate the current navigation
                    pendingLocation = START_LOCATION_NORMALIZED;
                    removeHistoryListener && removeHistoryListener();
                    removeHistoryListener = null;
                    currentRoute.value = START_LOCATION_NORMALIZED;
                    started = false;
                    ready = false;
                }
                unmountApp();
            };
            // TODO: this probably needs to be updated so it can be used by vue-termui
            if (false) {}
        },
    };
    // TODO: type this as NavigationGuardReturn or similar instead of any
    function runGuardQueue(guards) {
        return guards.reduce((promise, guard) => promise.then(() => runWithContext(guard)), Promise.resolve());
    }
    return router;
}
function extractChangingRecords(to, from) {
    const leavingRecords = [];
    const updatingRecords = [];
    const enteringRecords = [];
    const len = Math.max(from.matched.length, to.matched.length);
    for (let i = 0; i < len; i++) {
        const recordFrom = from.matched[i];
        if (recordFrom) {
            if (to.matched.find(record => isSameRouteRecord(record, recordFrom)))
                updatingRecords.push(recordFrom);
            else
                leavingRecords.push(recordFrom);
        }
        const recordTo = to.matched[i];
        if (recordTo) {
            // the type doesn't matter because we are comparing per reference
            if (!from.matched.find(record => isSameRouteRecord(record, recordTo))) {
                enteringRecords.push(recordTo);
            }
        }
    }
    return [leavingRecords, updatingRecords, enteringRecords];
}

/**
 * Returns the router instance. Equivalent to using `$router` inside
 * templates.
 */
function useRouter() {
    return runtime_core_esm_bundler_inject(routerKey);
}
/**
 * Returns the current route location. Equivalent to using `$route` inside
 * templates.
 */
function useRoute(_name) {
    return runtime_core_esm_bundler_inject(routeLocationKey);
}



;// CONCATENATED MODULE: ./node_modules/pinia/dist/pinia.mjs
/*!
 * pinia v3.0.3
 * (c) 2025 Eduardo San Martin Morote
 * @license MIT
 */



/**
 * setActivePinia must be called to handle SSR at the top of functions like
 * `fetch`, `setup`, `serverPrefetch` and others
 */
let activePinia;
/**
 * Sets or unsets the active pinia. Used in SSR and internally when calling
 * actions and getters
 *
 * @param pinia - Pinia instance
 */
// @ts-expect-error: cannot constrain the type of the return
const setActivePinia = (pinia) => (activePinia = pinia);
/**
 * Get the currently active pinia if there is any.
 */
const getActivePinia = () => (hasInjectionContext() && inject(piniaSymbol)) || activePinia;
const piniaSymbol = (( false) ? 0 : /* istanbul ignore next */ Symbol());

function pinia_isPlainObject(
// eslint-disable-next-line @typescript-eslint/no-explicit-any
o) {
    return (o &&
        typeof o === 'object' &&
        Object.prototype.toString.call(o) === '[object Object]' &&
        typeof o.toJSON !== 'function');
}
// type DeepReadonly<T> = { readonly [P in keyof T]: DeepReadonly<T[P]> }
// TODO: can we change these to numbers?
/**
 * Possible types for SubscriptionCallback
 */
var MutationType;
(function (MutationType) {
    /**
     * Direct mutation of the state:
     *
     * - `store.name = 'new name'`
     * - `store.$state.name = 'new name'`
     * - `store.list.push('new item')`
     */
    MutationType["direct"] = "direct";
    /**
     * Mutated the state with `$patch` and an object
     *
     * - `store.$patch({ name: 'newName' })`
     */
    MutationType["patchObject"] = "patch object";
    /**
     * Mutated the state with `$patch` and a function
     *
     * - `store.$patch(state => state.name = 'newName')`
     */
    MutationType["patchFunction"] = "patch function";
    // maybe reset? for $state = {} and $reset
})(MutationType || (MutationType = {}));

const IS_CLIENT = typeof window !== 'undefined';

/*
 * FileSaver.js A saveAs() FileSaver implementation.
 *
 * Originally by Eli Grey, adapted as an ESM module by Eduardo San Martin
 * Morote.
 *
 * License : MIT
 */
// The one and only way of getting global scope in all environments
// https://stackoverflow.com/q/3277182/1008999
const _global = /*#__PURE__*/ (() => typeof window === 'object' && window.window === window
    ? window
    : typeof self === 'object' && self.self === self
        ? self
        : typeof global === 'object' && global.global === global
            ? global
            : typeof globalThis === 'object'
                ? globalThis
                : { HTMLElement: null })();
function bom(blob, { autoBom = false } = {}) {
    // prepend BOM for UTF-8 XML and text/* types (including HTML)
    // note: your browser will automatically convert UTF-16 U+FEFF to EF BB BF
    if (autoBom &&
        /^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(blob.type)) {
        return new Blob([String.fromCharCode(0xfeff), blob], { type: blob.type });
    }
    return blob;
}
function download(url, name, opts) {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', url);
    xhr.responseType = 'blob';
    xhr.onload = function () {
        saveAs(xhr.response, name, opts);
    };
    xhr.onerror = function () {
        console.error('could not download file');
    };
    xhr.send();
}
function corsEnabled(url) {
    const xhr = new XMLHttpRequest();
    // use sync to avoid popup blocker
    xhr.open('HEAD', url, false);
    try {
        xhr.send();
    }
    catch (e) { }
    return xhr.status >= 200 && xhr.status <= 299;
}
// `a.click()` doesn't work for all browsers (#465)
function click(node) {
    try {
        node.dispatchEvent(new MouseEvent('click'));
    }
    catch (e) {
        const evt = new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
            detail: 0,
            screenX: 80,
            screenY: 20,
            clientX: 80,
            clientY: 20,
            ctrlKey: false,
            altKey: false,
            shiftKey: false,
            metaKey: false,
            button: 0,
            relatedTarget: null,
        });
        node.dispatchEvent(evt);
    }
}
const _navigator = typeof navigator === 'object' ? navigator : { userAgent: '' };
// Detect WebView inside a native macOS app by ruling out all browsers
// We just need to check for 'Safari' because all other browsers (besides Firefox) include that too
// https://www.whatismybrowser.com/guides/the-latest-user-agent/macos
const isMacOSWebView = /*#__PURE__*/ (() => /Macintosh/.test(_navigator.userAgent) &&
    /AppleWebKit/.test(_navigator.userAgent) &&
    !/Safari/.test(_navigator.userAgent))();
const saveAs = !IS_CLIENT
    ? () => { } // noop
    : // Use download attribute first if possible (#193 Lumia mobile) unless this is a macOS WebView or mini program
        typeof HTMLAnchorElement !== 'undefined' &&
            'download' in HTMLAnchorElement.prototype &&
            !isMacOSWebView
            ? downloadSaveAs
            : // Use msSaveOrOpenBlob as a second approach
                'msSaveOrOpenBlob' in _navigator
                    ? msSaveAs
                    : // Fallback to using FileReader and a popup
                        fileSaverSaveAs;
function downloadSaveAs(blob, name = 'download', opts) {
    const a = document.createElement('a');
    a.download = name;
    a.rel = 'noopener'; // tabnabbing
    // TODO: detect chrome extensions & packaged apps
    // a.target = '_blank'
    if (typeof blob === 'string') {
        // Support regular links
        a.href = blob;
        if (a.origin !== location.origin) {
            if (corsEnabled(a.href)) {
                download(blob, name, opts);
            }
            else {
                a.target = '_blank';
                click(a);
            }
        }
        else {
            click(a);
        }
    }
    else {
        // Support blobs
        a.href = URL.createObjectURL(blob);
        setTimeout(function () {
            URL.revokeObjectURL(a.href);
        }, 4e4); // 40s
        setTimeout(function () {
            click(a);
        }, 0);
    }
}
function msSaveAs(blob, name = 'download', opts) {
    if (typeof blob === 'string') {
        if (corsEnabled(blob)) {
            download(blob, name, opts);
        }
        else {
            const a = document.createElement('a');
            a.href = blob;
            a.target = '_blank';
            setTimeout(function () {
                click(a);
            });
        }
    }
    else {
        // @ts-ignore: works on windows
        navigator.msSaveOrOpenBlob(bom(blob, opts), name);
    }
}
function fileSaverSaveAs(blob, name, opts, popup) {
    // Open a popup immediately do go around popup blocker
    // Mostly only available on user interaction and the fileReader is async so...
    popup = popup || open('', '_blank');
    if (popup) {
        popup.document.title = popup.document.body.innerText = 'downloading...';
    }
    if (typeof blob === 'string')
        return download(blob, name, opts);
    const force = blob.type === 'application/octet-stream';
    const isSafari = /constructor/i.test(String(_global.HTMLElement)) || 'safari' in _global;
    const isChromeIOS = /CriOS\/[\d]+/.test(navigator.userAgent);
    if ((isChromeIOS || (force && isSafari) || isMacOSWebView) &&
        typeof FileReader !== 'undefined') {
        // Safari doesn't allow downloading of blob URLs
        const reader = new FileReader();
        reader.onloadend = function () {
            let url = reader.result;
            if (typeof url !== 'string') {
                popup = null;
                throw new Error('Wrong reader.result type');
            }
            url = isChromeIOS
                ? url
                : url.replace(/^data:[^;]*;/, 'data:attachment/file;');
            if (popup) {
                popup.location.href = url;
            }
            else {
                location.assign(url);
            }
            popup = null; // reverse-tabnabbing #460
        };
        reader.readAsDataURL(blob);
    }
    else {
        const url = URL.createObjectURL(blob);
        if (popup)
            popup.location.assign(url);
        else
            location.href = url;
        popup = null; // reverse-tabnabbing #460
        setTimeout(function () {
            URL.revokeObjectURL(url);
        }, 4e4); // 40s
    }
}

/**
 * Shows a toast or console.log
 *
 * @param message - message to log
 * @param type - different color of the tooltip
 */
function toastMessage(message, type) {
    const piniaMessage = '🍍 ' + message;
    if (typeof __VUE_DEVTOOLS_TOAST__ === 'function') {
        // No longer available :(
        __VUE_DEVTOOLS_TOAST__(piniaMessage, type);
    }
    else if (type === 'error') {
        console.error(piniaMessage);
    }
    else if (type === 'warn') {
        console.warn(piniaMessage);
    }
    else {
        console.log(piniaMessage);
    }
}
function isPinia(o) {
    return '_a' in o && 'install' in o;
}

/**
 * This file contain devtools actions, they are not Pinia actions.
 */
// ---
function checkClipboardAccess() {
    if (!('clipboard' in navigator)) {
        toastMessage(`Your browser doesn't support the Clipboard API`, 'error');
        return true;
    }
}
function checkNotFocusedError(error) {
    if (error instanceof Error &&
        error.message.toLowerCase().includes('document is not focused')) {
        toastMessage('You need to activate the "Emulate a focused page" setting in the "Rendering" panel of devtools.', 'warn');
        return true;
    }
    return false;
}
async function actionGlobalCopyState(pinia) {
    if (checkClipboardAccess())
        return;
    try {
        await navigator.clipboard.writeText(JSON.stringify(pinia.state.value));
        toastMessage('Global state copied to clipboard.');
    }
    catch (error) {
        if (checkNotFocusedError(error))
            return;
        toastMessage(`Failed to serialize the state. Check the console for more details.`, 'error');
        console.error(error);
    }
}
async function actionGlobalPasteState(pinia) {
    if (checkClipboardAccess())
        return;
    try {
        loadStoresState(pinia, JSON.parse(await navigator.clipboard.readText()));
        toastMessage('Global state pasted from clipboard.');
    }
    catch (error) {
        if (checkNotFocusedError(error))
            return;
        toastMessage(`Failed to deserialize the state from clipboard. Check the console for more details.`, 'error');
        console.error(error);
    }
}
async function actionGlobalSaveState(pinia) {
    try {
        saveAs(new Blob([JSON.stringify(pinia.state.value)], {
            type: 'text/plain;charset=utf-8',
        }), 'pinia-state.json');
    }
    catch (error) {
        toastMessage(`Failed to export the state as JSON. Check the console for more details.`, 'error');
        console.error(error);
    }
}
let fileInput;
function getFileOpener() {
    if (!fileInput) {
        fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = '.json';
    }
    function openFile() {
        return new Promise((resolve, reject) => {
            fileInput.onchange = async () => {
                const files = fileInput.files;
                if (!files)
                    return resolve(null);
                const file = files.item(0);
                if (!file)
                    return resolve(null);
                return resolve({ text: await file.text(), file });
            };
            // @ts-ignore: TODO: changed from 4.3 to 4.4
            fileInput.oncancel = () => resolve(null);
            fileInput.onerror = reject;
            fileInput.click();
        });
    }
    return openFile;
}
async function actionGlobalOpenStateFile(pinia) {
    try {
        const open = getFileOpener();
        const result = await open();
        if (!result)
            return;
        const { text, file } = result;
        loadStoresState(pinia, JSON.parse(text));
        toastMessage(`Global state imported from "${file.name}".`);
    }
    catch (error) {
        toastMessage(`Failed to import the state from JSON. Check the console for more details.`, 'error');
        console.error(error);
    }
}
function loadStoresState(pinia, state) {
    for (const key in state) {
        const storeState = pinia.state.value[key];
        // store is already instantiated, patch it
        if (storeState) {
            Object.assign(storeState, state[key]);
        }
        else {
            // store is not instantiated, set the initial state
            pinia.state.value[key] = state[key];
        }
    }
}

function pinia_formatDisplay(display) {
    return {
        _custom: {
            display,
        },
    };
}
const PINIA_ROOT_LABEL = '🍍 Pinia (root)';
const PINIA_ROOT_ID = '_root';
function formatStoreForInspectorTree(store) {
    return isPinia(store)
        ? {
            id: PINIA_ROOT_ID,
            label: PINIA_ROOT_LABEL,
        }
        : {
            id: store.$id,
            label: store.$id,
        };
}
function formatStoreForInspectorState(store) {
    if (isPinia(store)) {
        const storeNames = Array.from(store._s.keys());
        const storeMap = store._s;
        const state = {
            state: storeNames.map((storeId) => ({
                editable: true,
                key: storeId,
                value: store.state.value[storeId],
            })),
            getters: storeNames
                .filter((id) => storeMap.get(id)._getters)
                .map((id) => {
                const store = storeMap.get(id);
                return {
                    editable: false,
                    key: id,
                    value: store._getters.reduce((getters, key) => {
                        getters[key] = store[key];
                        return getters;
                    }, {}),
                };
            }),
        };
        return state;
    }
    const state = {
        state: Object.keys(store.$state).map((key) => ({
            editable: true,
            key,
            value: store.$state[key],
        })),
    };
    // avoid adding empty getters
    if (store._getters && store._getters.length) {
        state.getters = store._getters.map((getterName) => ({
            editable: false,
            key: getterName,
            value: store[getterName],
        }));
    }
    if (store._customProperties.size) {
        state.customProperties = Array.from(store._customProperties).map((key) => ({
            editable: true,
            key,
            value: store[key],
        }));
    }
    return state;
}
function formatEventData(events) {
    if (!events)
        return {};
    if (Array.isArray(events)) {
        // TODO: handle add and delete for arrays and objects
        return events.reduce((data, event) => {
            data.keys.push(event.key);
            data.operations.push(event.type);
            data.oldValue[event.key] = event.oldValue;
            data.newValue[event.key] = event.newValue;
            return data;
        }, {
            oldValue: {},
            keys: [],
            operations: [],
            newValue: {},
        });
    }
    else {
        return {
            operation: pinia_formatDisplay(events.type),
            key: pinia_formatDisplay(events.key),
            oldValue: events.oldValue,
            newValue: events.newValue,
        };
    }
}
function formatMutationType(type) {
    switch (type) {
        case MutationType.direct:
            return 'mutation';
        case MutationType.patchFunction:
            return '$patch';
        case MutationType.patchObject:
            return '$patch';
        default:
            return 'unknown';
    }
}

// timeline can be paused when directly changing the state
let isTimelineActive = true;
const componentStateTypes = (/* unused pure expression or super */ null && ([]));
const MUTATIONS_LAYER_ID = 'pinia:mutations';
const INSPECTOR_ID = 'pinia';
const { assign: assign$1 } = Object;
/**
 * Gets the displayed name of a store in devtools
 *
 * @param id - id of the store
 * @returns a formatted string
 */
const getStoreType = (id) => '🍍 ' + id;
/**
 * Add the pinia plugin without any store. Allows displaying a Pinia plugin tab
 * as soon as it is added to the application.
 *
 * @param app - Vue application
 * @param pinia - pinia instance
 */
function registerPiniaDevtools(app, pinia) {
    setupDevtoolsPlugin({
        id: 'dev.esm.pinia',
        label: 'Pinia 🍍',
        logo: 'https://pinia.vuejs.org/logo.svg',
        packageName: 'pinia',
        homepage: 'https://pinia.vuejs.org',
        componentStateTypes,
        app,
    }, (api) => {
        if (typeof api.now !== 'function') {
            toastMessage('You seem to be using an outdated version of Vue Devtools. Are you still using the Beta release instead of the stable one? You can find the links at https://devtools.vuejs.org/guide/installation.html.');
        }
        api.addTimelineLayer({
            id: MUTATIONS_LAYER_ID,
            label: `Pinia 🍍`,
            color: 0xe5df88,
        });
        api.addInspector({
            id: INSPECTOR_ID,
            label: 'Pinia 🍍',
            icon: 'storage',
            treeFilterPlaceholder: 'Search stores',
            actions: [
                {
                    icon: 'content_copy',
                    action: () => {
                        actionGlobalCopyState(pinia);
                    },
                    tooltip: 'Serialize and copy the state',
                },
                {
                    icon: 'content_paste',
                    action: async () => {
                        await actionGlobalPasteState(pinia);
                        api.sendInspectorTree(INSPECTOR_ID);
                        api.sendInspectorState(INSPECTOR_ID);
                    },
                    tooltip: 'Replace the state with the content of your clipboard',
                },
                {
                    icon: 'save',
                    action: () => {
                        actionGlobalSaveState(pinia);
                    },
                    tooltip: 'Save the state as a JSON file',
                },
                {
                    icon: 'folder_open',
                    action: async () => {
                        await actionGlobalOpenStateFile(pinia);
                        api.sendInspectorTree(INSPECTOR_ID);
                        api.sendInspectorState(INSPECTOR_ID);
                    },
                    tooltip: 'Import the state from a JSON file',
                },
            ],
            nodeActions: [
                {
                    icon: 'restore',
                    tooltip: 'Reset the state (with "$reset")',
                    action: (nodeId) => {
                        const store = pinia._s.get(nodeId);
                        if (!store) {
                            toastMessage(`Cannot reset "${nodeId}" store because it wasn't found.`, 'warn');
                        }
                        else if (typeof store.$reset !== 'function') {
                            toastMessage(`Cannot reset "${nodeId}" store because it doesn't have a "$reset" method implemented.`, 'warn');
                        }
                        else {
                            store.$reset();
                            toastMessage(`Store "${nodeId}" reset.`);
                        }
                    },
                },
            ],
        });
        api.on.inspectComponent((payload) => {
            const proxy = (payload.componentInstance &&
                payload.componentInstance.proxy);
            if (proxy && proxy._pStores) {
                const piniaStores = payload.componentInstance.proxy._pStores;
                Object.values(piniaStores).forEach((store) => {
                    payload.instanceData.state.push({
                        type: getStoreType(store.$id),
                        key: 'state',
                        editable: true,
                        value: store._isOptionsAPI
                            ? {
                                _custom: {
                                    value: toRaw(store.$state),
                                    actions: [
                                        {
                                            icon: 'restore',
                                            tooltip: 'Reset the state of this store',
                                            action: () => store.$reset(),
                                        },
                                    ],
                                },
                            }
                            : // NOTE: workaround to unwrap transferred refs
                                Object.keys(store.$state).reduce((state, key) => {
                                    state[key] = store.$state[key];
                                    return state;
                                }, {}),
                    });
                    if (store._getters && store._getters.length) {
                        payload.instanceData.state.push({
                            type: getStoreType(store.$id),
                            key: 'getters',
                            editable: false,
                            value: store._getters.reduce((getters, key) => {
                                try {
                                    getters[key] = store[key];
                                }
                                catch (error) {
                                    // @ts-expect-error: we just want to show it in devtools
                                    getters[key] = error;
                                }
                                return getters;
                            }, {}),
                        });
                    }
                });
            }
        });
        api.on.getInspectorTree((payload) => {
            if (payload.app === app && payload.inspectorId === INSPECTOR_ID) {
                let stores = [pinia];
                stores = stores.concat(Array.from(pinia._s.values()));
                payload.rootNodes = (payload.filter
                    ? stores.filter((store) => '$id' in store
                        ? store.$id
                            .toLowerCase()
                            .includes(payload.filter.toLowerCase())
                        : PINIA_ROOT_LABEL.toLowerCase().includes(payload.filter.toLowerCase()))
                    : stores).map(formatStoreForInspectorTree);
            }
        });
        // Expose pinia instance as $pinia to window
        globalThis.$pinia = pinia;
        api.on.getInspectorState((payload) => {
            if (payload.app === app && payload.inspectorId === INSPECTOR_ID) {
                const inspectedStore = payload.nodeId === PINIA_ROOT_ID
                    ? pinia
                    : pinia._s.get(payload.nodeId);
                if (!inspectedStore) {
                    // this could be the selected store restored for a different project
                    // so it's better not to say anything here
                    return;
                }
                if (inspectedStore) {
                    // Expose selected store as $store to window
                    if (payload.nodeId !== PINIA_ROOT_ID)
                        globalThis.$store = toRaw(inspectedStore);
                    payload.state = formatStoreForInspectorState(inspectedStore);
                }
            }
        });
        api.on.editInspectorState((payload) => {
            if (payload.app === app && payload.inspectorId === INSPECTOR_ID) {
                const inspectedStore = payload.nodeId === PINIA_ROOT_ID
                    ? pinia
                    : pinia._s.get(payload.nodeId);
                if (!inspectedStore) {
                    return toastMessage(`store "${payload.nodeId}" not found`, 'error');
                }
                const { path } = payload;
                if (!isPinia(inspectedStore)) {
                    // access only the state
                    if (path.length !== 1 ||
                        !inspectedStore._customProperties.has(path[0]) ||
                        path[0] in inspectedStore.$state) {
                        path.unshift('$state');
                    }
                }
                else {
                    // Root access, we can omit the `.value` because the devtools API does it for us
                    path.unshift('state');
                }
                isTimelineActive = false;
                payload.set(inspectedStore, path, payload.state.value);
                isTimelineActive = true;
            }
        });
        api.on.editComponentState((payload) => {
            if (payload.type.startsWith('🍍')) {
                const storeId = payload.type.replace(/^🍍\s*/, '');
                const store = pinia._s.get(storeId);
                if (!store) {
                    return toastMessage(`store "${storeId}" not found`, 'error');
                }
                const { path } = payload;
                if (path[0] !== 'state') {
                    return toastMessage(`Invalid path for store "${storeId}":\n${path}\nOnly state can be modified.`);
                }
                // rewrite the first entry to be able to directly set the state as
                // well as any other path
                path[0] = '$state';
                isTimelineActive = false;
                payload.set(store, path, payload.state.value);
                isTimelineActive = true;
            }
        });
    });
}
function addStoreToDevtools(app, store) {
    if (!componentStateTypes.includes(getStoreType(store.$id))) {
        componentStateTypes.push(getStoreType(store.$id));
    }
    setupDevtoolsPlugin({
        id: 'dev.esm.pinia',
        label: 'Pinia 🍍',
        logo: 'https://pinia.vuejs.org/logo.svg',
        packageName: 'pinia',
        homepage: 'https://pinia.vuejs.org',
        componentStateTypes,
        app,
        settings: {
            logStoreChanges: {
                label: 'Notify about new/deleted stores',
                type: 'boolean',
                defaultValue: true,
            },
            // useEmojis: {
            //   label: 'Use emojis in messages ⚡️',
            //   type: 'boolean',
            //   defaultValue: true,
            // },
        },
    }, (api) => {
        // gracefully handle errors
        const now = typeof api.now === 'function' ? api.now.bind(api) : Date.now;
        store.$onAction(({ after, onError, name, args }) => {
            const groupId = runningActionId++;
            api.addTimelineEvent({
                layerId: MUTATIONS_LAYER_ID,
                event: {
                    time: now(),
                    title: '🛫 ' + name,
                    subtitle: 'start',
                    data: {
                        store: pinia_formatDisplay(store.$id),
                        action: pinia_formatDisplay(name),
                        args,
                    },
                    groupId,
                },
            });
            after((result) => {
                activeAction = undefined;
                api.addTimelineEvent({
                    layerId: MUTATIONS_LAYER_ID,
                    event: {
                        time: now(),
                        title: '🛬 ' + name,
                        subtitle: 'end',
                        data: {
                            store: pinia_formatDisplay(store.$id),
                            action: pinia_formatDisplay(name),
                            args,
                            result,
                        },
                        groupId,
                    },
                });
            });
            onError((error) => {
                activeAction = undefined;
                api.addTimelineEvent({
                    layerId: MUTATIONS_LAYER_ID,
                    event: {
                        time: now(),
                        logType: 'error',
                        title: '💥 ' + name,
                        subtitle: 'end',
                        data: {
                            store: pinia_formatDisplay(store.$id),
                            action: pinia_formatDisplay(name),
                            args,
                            error,
                        },
                        groupId,
                    },
                });
            });
        }, true);
        store._customProperties.forEach((name) => {
            watch(() => unref(store[name]), (newValue, oldValue) => {
                api.notifyComponentUpdate();
                api.sendInspectorState(INSPECTOR_ID);
                if (isTimelineActive) {
                    api.addTimelineEvent({
                        layerId: MUTATIONS_LAYER_ID,
                        event: {
                            time: now(),
                            title: 'Change',
                            subtitle: name,
                            data: {
                                newValue,
                                oldValue,
                            },
                            groupId: activeAction,
                        },
                    });
                }
            }, { deep: true });
        });
        store.$subscribe(({ events, type }, state) => {
            api.notifyComponentUpdate();
            api.sendInspectorState(INSPECTOR_ID);
            if (!isTimelineActive)
                return;
            // rootStore.state[store.id] = state
            const eventData = {
                time: now(),
                title: formatMutationType(type),
                data: assign$1({ store: pinia_formatDisplay(store.$id) }, formatEventData(events)),
                groupId: activeAction,
            };
            if (type === MutationType.patchFunction) {
                eventData.subtitle = '⤵️';
            }
            else if (type === MutationType.patchObject) {
                eventData.subtitle = '🧩';
            }
            else if (events && !Array.isArray(events)) {
                eventData.subtitle = events.type;
            }
            if (events) {
                eventData.data['rawEvent(s)'] = {
                    _custom: {
                        display: 'DebuggerEvent',
                        type: 'object',
                        tooltip: 'raw DebuggerEvent[]',
                        value: events,
                    },
                };
            }
            api.addTimelineEvent({
                layerId: MUTATIONS_LAYER_ID,
                event: eventData,
            });
        }, { detached: true, flush: 'sync' });
        const hotUpdate = store._hotUpdate;
        store._hotUpdate = markRaw((newStore) => {
            hotUpdate(newStore);
            api.addTimelineEvent({
                layerId: MUTATIONS_LAYER_ID,
                event: {
                    time: now(),
                    title: '🔥 ' + store.$id,
                    subtitle: 'HMR update',
                    data: {
                        store: pinia_formatDisplay(store.$id),
                        info: pinia_formatDisplay(`HMR update`),
                    },
                },
            });
            // update the devtools too
            api.notifyComponentUpdate();
            api.sendInspectorTree(INSPECTOR_ID);
            api.sendInspectorState(INSPECTOR_ID);
        });
        const { $dispose } = store;
        store.$dispose = () => {
            $dispose();
            api.notifyComponentUpdate();
            api.sendInspectorTree(INSPECTOR_ID);
            api.sendInspectorState(INSPECTOR_ID);
            api.getSettings().logStoreChanges &&
                toastMessage(`Disposed "${store.$id}" store 🗑`);
        };
        // trigger an update so it can display new registered stores
        api.notifyComponentUpdate();
        api.sendInspectorTree(INSPECTOR_ID);
        api.sendInspectorState(INSPECTOR_ID);
        api.getSettings().logStoreChanges &&
            toastMessage(`"${store.$id}" store installed 🆕`);
    });
}
let runningActionId = 0;
let activeAction;
/**
 * Patches a store to enable action grouping in devtools by wrapping the store with a Proxy that is passed as the
 * context of all actions, allowing us to set `runningAction` on each access and effectively associating any state
 * mutation to the action.
 *
 * @param store - store to patch
 * @param actionNames - list of actionst to patch
 */
function patchActionForGrouping(store, actionNames, wrapWithProxy) {
    // original actions of the store as they are given by pinia. We are going to override them
    const actions = actionNames.reduce((storeActions, actionName) => {
        // use toRaw to avoid tracking #541
        storeActions[actionName] = toRaw(store)[actionName];
        return storeActions;
    }, {});
    for (const actionName in actions) {
        store[actionName] = function () {
            // the running action id is incremented in a before action hook
            const _actionId = runningActionId;
            const trackedStore = wrapWithProxy
                ? new Proxy(store, {
                    get(...args) {
                        activeAction = _actionId;
                        return Reflect.get(...args);
                    },
                    set(...args) {
                        activeAction = _actionId;
                        return Reflect.set(...args);
                    },
                })
                : store;
            // For Setup Stores we need https://github.com/tc39/proposal-async-context
            activeAction = _actionId;
            const retValue = actions[actionName].apply(trackedStore, arguments);
            // this is safer as async actions in Setup Stores would associate mutations done outside of the action
            activeAction = undefined;
            return retValue;
        };
    }
}
/**
 * pinia.use(devtoolsPlugin)
 */
function devtoolsPlugin({ app, store, options }) {
    // HMR module
    if (store.$id.startsWith('__hot:')) {
        return;
    }
    // detect option api vs setup api
    store._isOptionsAPI = !!options.state;
    // Do not overwrite actions mocked by @pinia/testing (#2298)
    if (!store._p._testing) {
        patchActionForGrouping(store, Object.keys(options.actions), store._isOptionsAPI);
        // Upgrade the HMR to also update the new actions
        const originalHotUpdate = store._hotUpdate;
        toRaw(store)._hotUpdate = function (newStore) {
            originalHotUpdate.apply(this, arguments);
            patchActionForGrouping(store, Object.keys(newStore._hmrPayload.actions), !!store._isOptionsAPI);
        };
    }
    addStoreToDevtools(app, 
    // FIXME: is there a way to allow the assignment from Store<Id, S, G, A> to StoreGeneric?
    store);
}

/**
 * Creates a Pinia instance to be used by the application
 */
function createPinia() {
    const scope = effectScope(true);
    // NOTE: here we could check the window object for a state and directly set it
    // if there is anything like it with Vue 3 SSR
    const state = scope.run(() => reactivity_esm_bundler_ref({}));
    let _p = [];
    // plugins added before calling app.use(pinia)
    let toBeInstalled = [];
    const pinia = reactivity_esm_bundler_markRaw({
        install(app) {
            // this allows calling useStore() outside of a component setup after
            // installing pinia's plugin
            setActivePinia(pinia);
            pinia._a = app;
            app.provide(piniaSymbol, pinia);
            app.config.globalProperties.$pinia = pinia;
            /* istanbul ignore else */
            if (false) {}
            toBeInstalled.forEach((plugin) => _p.push(plugin));
            toBeInstalled = [];
        },
        use(plugin) {
            if (!this._a) {
                toBeInstalled.push(plugin);
            }
            else {
                _p.push(plugin);
            }
            return this;
        },
        _p,
        // it's actually undefined here
        // @ts-expect-error
        _a: null,
        _e: scope,
        _s: new Map(),
        state,
    });
    // pinia devtools rely on dev only features so they cannot be forced unless
    // the dev build of Vue is used. Avoid old browsers like IE11.
    if (false) {}
    return pinia;
}
/**
 * Dispose a Pinia instance by stopping its effectScope and removing the state, plugins and stores. This is mostly
 * useful in tests, with both a testing pinia or a regular pinia and in applications that use multiple pinia instances.
 * Once disposed, the pinia instance cannot be used anymore.
 *
 * @param pinia - pinia instance
 */
function disposePinia(pinia) {
    pinia._e.stop();
    pinia._s.clear();
    pinia._p.splice(0);
    pinia.state.value = {};
    // @ts-expect-error: non valid
    pinia._a = null;
}

/**
 * Checks if a function is a `StoreDefinition`.
 *
 * @param fn - object to test
 * @returns true if `fn` is a StoreDefinition
 */
const isUseStore = (fn) => {
    return typeof fn === 'function' && typeof fn.$id === 'string';
};
/**
 * Mutates in place `newState` with `oldState` to _hot update_ it. It will
 * remove any key not existing in `newState` and recursively merge plain
 * objects.
 *
 * @param newState - new state object to be patched
 * @param oldState - old state that should be used to patch newState
 * @returns - newState
 */
function patchObject(newState, oldState) {
    // no need to go through symbols because they cannot be serialized anyway
    for (const key in oldState) {
        const subPatch = oldState[key];
        // skip the whole sub tree
        if (!(key in newState)) {
            continue;
        }
        const targetValue = newState[key];
        if (pinia_isPlainObject(targetValue) &&
            pinia_isPlainObject(subPatch) &&
            !isRef(subPatch) &&
            !isReactive(subPatch)) {
            newState[key] = patchObject(targetValue, subPatch);
        }
        else {
            // objects are either a bit more complex (e.g. refs) or primitives, so we
            // just set the whole thing
            newState[key] = subPatch;
        }
    }
    return newState;
}
/**
 * Creates an _accept_ function to pass to `import.meta.hot` in Vite applications.
 *
 * @example
 * ```js
 * const useUser = defineStore(...)
 * if (import.meta.hot) {
 *   import.meta.hot.accept(acceptHMRUpdate(useUser, import.meta.hot))
 * }
 * ```
 *
 * @param initialUseStore - return of the defineStore to hot update
 * @param hot - `import.meta.hot`
 */
function acceptHMRUpdate(initialUseStore, hot) {
    // strip as much as possible from iife.prod
    if (true) {
        return () => { };
    }
    return (newModule) => {
        const pinia = hot.data.pinia || initialUseStore._pinia;
        if (!pinia) {
            // this store is still not used
            return;
        }
        // preserve the pinia instance across loads
        hot.data.pinia = pinia;
        // console.log('got data', newStore)
        for (const exportName in newModule) {
            const useStore = newModule[exportName];
            // console.log('checking for', exportName)
            if (isUseStore(useStore) && pinia._s.has(useStore.$id)) {
                // console.log('Accepting update for', useStore.$id)
                const id = useStore.$id;
                if (id !== initialUseStore.$id) {
                    console.warn(`The id of the store changed from "${initialUseStore.$id}" to "${id}". Reloading.`);
                    // return import.meta.hot.invalidate()
                    return hot.invalidate();
                }
                const existingStore = pinia._s.get(id);
                if (!existingStore) {
                    console.log(`[Pinia]: skipping hmr because store doesn't exist yet`);
                    return;
                }
                useStore(pinia, existingStore);
            }
        }
    };
}

const pinia_noop = () => { };
function addSubscription(subscriptions, callback, detached, onCleanup = pinia_noop) {
    subscriptions.push(callback);
    const removeSubscription = () => {
        const idx = subscriptions.indexOf(callback);
        if (idx > -1) {
            subscriptions.splice(idx, 1);
            onCleanup();
        }
    };
    if (!detached && getCurrentScope()) {
        onScopeDispose(removeSubscription);
    }
    return removeSubscription;
}
function triggerSubscriptions(subscriptions, ...args) {
    subscriptions.slice().forEach((callback) => {
        callback(...args);
    });
}

const fallbackRunWithContext = (fn) => fn();
/**
 * Marks a function as an action for `$onAction`
 * @internal
 */
const ACTION_MARKER = Symbol();
/**
 * Action name symbol. Allows to add a name to an action after defining it
 * @internal
 */
const ACTION_NAME = Symbol();
function mergeReactiveObjects(target, patchToApply) {
    // Handle Map instances
    if (target instanceof Map && patchToApply instanceof Map) {
        patchToApply.forEach((value, key) => target.set(key, value));
    }
    else if (target instanceof Set && patchToApply instanceof Set) {
        // Handle Set instances
        patchToApply.forEach(target.add, target);
    }
    // no need to go through symbols because they cannot be serialized anyway
    for (const key in patchToApply) {
        if (!patchToApply.hasOwnProperty(key))
            continue;
        const subPatch = patchToApply[key];
        const targetValue = target[key];
        if (pinia_isPlainObject(targetValue) &&
            pinia_isPlainObject(subPatch) &&
            target.hasOwnProperty(key) &&
            !reactivity_esm_bundler_isRef(subPatch) &&
            !reactivity_esm_bundler_isReactive(subPatch)) {
            // NOTE: here I wanted to warn about inconsistent types but it's not possible because in setup stores one might
            // start the value of a property as a certain type e.g. a Map, and then for some reason, during SSR, change that
            // to `undefined`. When trying to hydrate, we want to override the Map with `undefined`.
            target[key] = mergeReactiveObjects(targetValue, subPatch);
        }
        else {
            // @ts-expect-error: subPatch is a valid value
            target[key] = subPatch;
        }
    }
    return target;
}
const skipHydrateSymbol = ( false)
    ? 0
    : /* istanbul ignore next */ Symbol();
/**
 * Tells Pinia to skip the hydration process of a given object. This is useful in setup stores (only) when you return a
 * stateful object in the store but it isn't really state. e.g. returning a router instance in a setup store.
 *
 * @param obj - target object
 * @returns obj
 */
function skipHydrate(obj) {
    return Object.defineProperty(obj, skipHydrateSymbol, {});
}
/**
 * Returns whether a value should be hydrated
 *
 * @param obj - target variable
 * @returns true if `obj` should be hydrated
 */
function shouldHydrate(obj) {
    return (!pinia_isPlainObject(obj) ||
        !Object.prototype.hasOwnProperty.call(obj, skipHydrateSymbol));
}
const { assign: pinia_assign } = Object;
function isComputed(o) {
    return !!(reactivity_esm_bundler_isRef(o) && o.effect);
}
function createOptionsStore(id, options, pinia, hot) {
    const { state, actions, getters } = options;
    const initialState = pinia.state.value[id];
    let store;
    function setup() {
        if (!initialState && ( true || 0)) {
            /* istanbul ignore if */
            pinia.state.value[id] = state ? state() : {};
        }
        // avoid creating a state in pinia.state.value
        const localState =  false
            ? // use ref() to unwrap refs inside state TODO: check if this is still necessary
                0
            : toRefs(pinia.state.value[id]);
        return pinia_assign(localState, actions, Object.keys(getters || {}).reduce((computedGetters, name) => {
            if (false) {}
            computedGetters[name] = reactivity_esm_bundler_markRaw(runtime_core_esm_bundler_computed(() => {
                setActivePinia(pinia);
                // it was created just before
                const store = pinia._s.get(id);
                // allow cross using stores
                // @ts-expect-error
                // return getters![name].call(context, context)
                // TODO: avoid reading the getter while assigning with a global variable
                return getters[name].call(store, store);
            }));
            return computedGetters;
        }, {}));
    }
    store = createSetupStore(id, setup, options, pinia, hot, true);
    return store;
}
function createSetupStore($id, setup, options = {}, pinia, hot, isOptionsStore) {
    let scope;
    const optionsForPlugin = pinia_assign({ actions: {} }, options);
    /* istanbul ignore if */
    if (false) {}
    // watcher options for $subscribe
    const $subscribeOptions = { deep: true };
    /* istanbul ignore else */
    if ((false)) {}
    // internal state
    let isListening; // set to true at the end
    let isSyncListening; // set to true at the end
    let subscriptions = [];
    let actionSubscriptions = [];
    let debuggerEvents;
    const initialState = pinia.state.value[$id];
    // avoid setting the state for option stores if it is set
    // by the setup
    if (!isOptionsStore && !initialState && ( true || 0)) {
        /* istanbul ignore if */
        pinia.state.value[$id] = {};
    }
    const hotState = reactivity_esm_bundler_ref({});
    // avoid triggering too many listeners
    // https://github.com/vuejs/pinia/issues/1129
    let activeListener;
    function $patch(partialStateOrMutator) {
        let subscriptionMutation;
        isListening = isSyncListening = false;
        // reset the debugger events since patches are sync
        /* istanbul ignore else */
        if ((false)) {}
        if (typeof partialStateOrMutator === 'function') {
            partialStateOrMutator(pinia.state.value[$id]);
            subscriptionMutation = {
                type: MutationType.patchFunction,
                storeId: $id,
                events: debuggerEvents,
            };
        }
        else {
            mergeReactiveObjects(pinia.state.value[$id], partialStateOrMutator);
            subscriptionMutation = {
                type: MutationType.patchObject,
                payload: partialStateOrMutator,
                storeId: $id,
                events: debuggerEvents,
            };
        }
        const myListenerId = (activeListener = Symbol());
        nextTick().then(() => {
            if (activeListener === myListenerId) {
                isListening = true;
            }
        });
        isSyncListening = true;
        // because we paused the watcher, we need to manually call the subscriptions
        triggerSubscriptions(subscriptions, subscriptionMutation, pinia.state.value[$id]);
    }
    const $reset = isOptionsStore
        ? function $reset() {
            const { state } = options;
            const newState = state ? state() : {};
            // we use a patch to group all changes into one single subscription
            this.$patch(($state) => {
                // @ts-expect-error: FIXME: shouldn't error?
                pinia_assign($state, newState);
            });
        }
        : /* istanbul ignore next */
            ( false)
                ? 0
                : pinia_noop;
    function $dispose() {
        scope.stop();
        subscriptions = [];
        actionSubscriptions = [];
        pinia._s.delete($id);
    }
    /**
     * Helper that wraps function so it can be tracked with $onAction
     * @param fn - action to wrap
     * @param name - name of the action
     */
    const action = (fn, name = '') => {
        if (ACTION_MARKER in fn) {
            fn[ACTION_NAME] = name;
            return fn;
        }
        const wrappedAction = function () {
            setActivePinia(pinia);
            const args = Array.from(arguments);
            const afterCallbackList = [];
            const onErrorCallbackList = [];
            function after(callback) {
                afterCallbackList.push(callback);
            }
            function onError(callback) {
                onErrorCallbackList.push(callback);
            }
            // @ts-expect-error
            triggerSubscriptions(actionSubscriptions, {
                args,
                name: wrappedAction[ACTION_NAME],
                store,
                after,
                onError,
            });
            let ret;
            try {
                ret = fn.apply(this && this.$id === $id ? this : store, args);
                // handle sync errors
            }
            catch (error) {
                triggerSubscriptions(onErrorCallbackList, error);
                throw error;
            }
            if (ret instanceof Promise) {
                return ret
                    .then((value) => {
                    triggerSubscriptions(afterCallbackList, value);
                    return value;
                })
                    .catch((error) => {
                    triggerSubscriptions(onErrorCallbackList, error);
                    return Promise.reject(error);
                });
            }
            // trigger after callbacks
            triggerSubscriptions(afterCallbackList, ret);
            return ret;
        };
        wrappedAction[ACTION_MARKER] = true;
        wrappedAction[ACTION_NAME] = name; // will be set later
        // @ts-expect-error: we are intentionally limiting the returned type to just Fn
        // because all the added properties are internals that are exposed through `$onAction()` only
        return wrappedAction;
    };
    const _hmrPayload = /*#__PURE__*/ reactivity_esm_bundler_markRaw({
        actions: {},
        getters: {},
        state: [],
        hotState,
    });
    const partialStore = {
        _p: pinia,
        // _s: scope,
        $id,
        $onAction: addSubscription.bind(null, actionSubscriptions),
        $patch,
        $reset,
        $subscribe(callback, options = {}) {
            const removeSubscription = addSubscription(subscriptions, callback, options.detached, () => stopWatcher());
            const stopWatcher = scope.run(() => runtime_core_esm_bundler_watch(() => pinia.state.value[$id], (state) => {
                if (options.flush === 'sync' ? isSyncListening : isListening) {
                    callback({
                        storeId: $id,
                        type: MutationType.direct,
                        events: debuggerEvents,
                    }, state);
                }
            }, pinia_assign({}, $subscribeOptions, options)));
            return removeSubscription;
        },
        $dispose,
    };
    const store = reactive( false
        ? 0
        : partialStore);
    // store the partial store now so the setup of stores can instantiate each other before they are finished without
    // creating infinite loops.
    pinia._s.set($id, store);
    const runWithContext = (pinia._a && pinia._a.runWithContext) || fallbackRunWithContext;
    // TODO: idea create skipSerialize that marks properties as non serializable and they are skipped
    const setupStore = runWithContext(() => pinia._e.run(() => (scope = effectScope()).run(() => setup({ action }))));
    // overwrite existing actions to support $onAction
    for (const key in setupStore) {
        const prop = setupStore[key];
        if ((reactivity_esm_bundler_isRef(prop) && !isComputed(prop)) || reactivity_esm_bundler_isReactive(prop)) {
            // mark it as a piece of state to be serialized
            if (false) {}
            else if (!isOptionsStore) {
                // in setup stores we must hydrate the state and sync pinia state tree with the refs the user just created
                if (initialState && shouldHydrate(prop)) {
                    if (reactivity_esm_bundler_isRef(prop)) {
                        prop.value = initialState[key];
                    }
                    else {
                        // probably a reactive object, lets recursively assign
                        // @ts-expect-error: prop is unknown
                        mergeReactiveObjects(prop, initialState[key]);
                    }
                }
                // transfer the ref to the pinia state to keep everything in sync
                pinia.state.value[$id][key] = prop;
            }
            /* istanbul ignore else */
            if ((false)) {}
            // action
        }
        else if (typeof prop === 'function') {
            const actionValue =  false ? 0 : action(prop, key);
            // this a hot module replacement store because the hotUpdate method needs
            // to do it with the right context
            // @ts-expect-error
            setupStore[key] = actionValue;
            /* istanbul ignore else */
            if ((false)) {}
            // list actions so they can be used in plugins
            // @ts-expect-error
            optionsForPlugin.actions[key] = prop;
        }
        else if ((false)) {}
    }
    // add the state, getters, and action properties
    /* istanbul ignore if */
    pinia_assign(store, setupStore);
    // allows retrieving reactive objects with `storeToRefs()`. Must be called after assigning to the reactive object.
    // Make `storeToRefs()` work with `reactive()` #799
    pinia_assign(reactivity_esm_bundler_toRaw(store), setupStore);
    // use this instead of a computed with setter to be able to create it anywhere
    // without linking the computed lifespan to wherever the store is first
    // created.
    Object.defineProperty(store, '$state', {
        get: () => ( false ? 0 : pinia.state.value[$id]),
        set: (state) => {
            /* istanbul ignore if */
            if (false) {}
            $patch(($state) => {
                // @ts-expect-error: FIXME: shouldn't error?
                pinia_assign($state, state);
            });
        },
    });
    // add the hotUpdate before plugins to allow them to override it
    /* istanbul ignore else */
    if ((false)) {}
    if (false) {}
    // apply all plugins
    pinia._p.forEach((extender) => {
        /* istanbul ignore else */
        if (false) {}
        else {
            pinia_assign(store, scope.run(() => extender({
                store: store,
                app: pinia._a,
                pinia,
                options: optionsForPlugin,
            })));
        }
    });
    if (false) {}
    // only apply hydrate to option stores with an initial state in pinia
    if (initialState &&
        isOptionsStore &&
        options.hydrate) {
        options.hydrate(store.$state, initialState);
    }
    isListening = true;
    isSyncListening = true;
    return store;
}
// allows unused stores to be tree shaken
/*! #__NO_SIDE_EFFECTS__ */
function defineStore(
// TODO: add proper types from above
id, setup, setupOptions) {
    let options;
    const isSetupStore = typeof setup === 'function';
    // the option store setup will contain the actual options in this case
    options = isSetupStore ? setupOptions : setup;
    function useStore(pinia, hot) {
        const hasContext = runtime_core_esm_bundler_hasInjectionContext();
        pinia =
            // in test mode, ignore the argument provided as we can always retrieve a
            // pinia instance with getActivePinia()
            ( false ? 0 : pinia) ||
                (hasContext ? runtime_core_esm_bundler_inject(piniaSymbol, null) : null);
        if (pinia)
            setActivePinia(pinia);
        if (false) {}
        pinia = activePinia;
        if (!pinia._s.has(id)) {
            // creating the store registers it in `pinia._s`
            if (isSetupStore) {
                createSetupStore(id, setup, options, pinia);
            }
            else {
                createOptionsStore(id, options, pinia);
            }
            /* istanbul ignore else */
            if ((false)) {}
        }
        const store = pinia._s.get(id);
        if (false) {}
        if (false) {}
        // StoreGeneric cannot be casted towards Store
        return store;
    }
    useStore.$id = id;
    return useStore;
}

let mapStoreSuffix = 'Store';
/**
 * Changes the suffix added by `mapStores()`. Can be set to an empty string.
 * Defaults to `"Store"`. Make sure to extend the MapStoresCustomization
 * interface if you are using TypeScript.
 *
 * @param suffix - new suffix
 */
function setMapStoreSuffix(suffix // could be 'Store' but that would be annoying for JS
) {
    mapStoreSuffix = suffix;
}
/**
 * Allows using stores without the composition API (`setup()`) by generating an
 * object to be spread in the `computed` field of a component. It accepts a list
 * of store definitions.
 *
 * @example
 * ```js
 * export default {
 *   computed: {
 *     // other computed properties
 *     ...mapStores(useUserStore, useCartStore)
 *   },
 *
 *   created() {
 *     this.userStore // store with id "user"
 *     this.cartStore // store with id "cart"
 *   }
 * }
 * ```
 *
 * @param stores - list of stores to map to an object
 */
function mapStores(...stores) {
    if (false) {}
    return stores.reduce((reduced, useStore) => {
        // @ts-expect-error: $id is added by defineStore
        reduced[useStore.$id + mapStoreSuffix] = function () {
            return useStore(this.$pinia);
        };
        return reduced;
    }, {});
}
/**
 * Allows using state and getters from one store without using the composition
 * API (`setup()`) by generating an object to be spread in the `computed` field
 * of a component.
 *
 * @param useStore - store to map from
 * @param keysOrMapper - array or object
 */
function mapState(useStore, keysOrMapper) {
    return Array.isArray(keysOrMapper)
        ? keysOrMapper.reduce((reduced, key) => {
            reduced[key] = function () {
                // @ts-expect-error: FIXME: should work?
                return useStore(this.$pinia)[key];
            };
            return reduced;
        }, {})
        : Object.keys(keysOrMapper).reduce((reduced, key) => {
            // @ts-expect-error
            reduced[key] = function () {
                const store = useStore(this.$pinia);
                const storeKey = keysOrMapper[key];
                // for some reason TS is unable to infer the type of storeKey to be a
                // function
                return typeof storeKey === 'function'
                    ? storeKey.call(this, store)
                    : // @ts-expect-error: FIXME: should work?
                        store[storeKey];
            };
            return reduced;
        }, {});
}
/**
 * Alias for `mapState()`. You should use `mapState()` instead.
 * @deprecated use `mapState()` instead.
 */
const mapGetters = (/* unused pure expression or super */ null && (mapState));
/**
 * Allows directly using actions from your store without using the composition
 * API (`setup()`) by generating an object to be spread in the `methods` field
 * of a component.
 *
 * @param useStore - store to map from
 * @param keysOrMapper - array or object
 */
function mapActions(useStore, keysOrMapper) {
    return Array.isArray(keysOrMapper)
        ? keysOrMapper.reduce((reduced, key) => {
            // @ts-expect-error
            reduced[key] = function (...args) {
                // @ts-expect-error: FIXME: should work?
                return useStore(this.$pinia)[key](...args);
            };
            return reduced;
        }, {})
        : Object.keys(keysOrMapper).reduce((reduced, key) => {
            // @ts-expect-error
            reduced[key] = function (...args) {
                // @ts-expect-error: FIXME: should work?
                return useStore(this.$pinia)[keysOrMapper[key]](...args);
            };
            return reduced;
        }, {});
}
/**
 * Allows using state and getters from one store without using the composition
 * API (`setup()`) by generating an object to be spread in the `computed` field
 * of a component.
 *
 * @param useStore - store to map from
 * @param keysOrMapper - array or object
 */
function mapWritableState(useStore, keysOrMapper) {
    return Array.isArray(keysOrMapper)
        ? keysOrMapper.reduce((reduced, key) => {
            reduced[key] = {
                get() {
                    return useStore(this.$pinia)[key];
                },
                set(value) {
                    return (useStore(this.$pinia)[key] = value);
                },
            };
            return reduced;
        }, {})
        : Object.keys(keysOrMapper).reduce((reduced, key) => {
            reduced[key] = {
                get() {
                    return useStore(this.$pinia)[keysOrMapper[key]];
                },
                set(value) {
                    return (useStore(this.$pinia)[keysOrMapper[key]] = value);
                },
            };
            return reduced;
        }, {});
}

/**
 * Creates an object of references with all the state, getters, and plugin-added
 * state properties of the store. Similar to `toRefs()` but specifically
 * designed for Pinia stores so methods and non reactive properties are
 * completely ignored.
 *
 * @param store - store to extract the refs from
 */
function storeToRefs(store) {
    const rawStore = toRaw(store);
    const refs = {};
    for (const key in rawStore) {
        const value = rawStore[key];
        // There is no native method to check for a computed
        // https://github.com/vuejs/core/pull/4165
        if (value.effect) {
            // @ts-expect-error: too hard to type correctly
            refs[key] =
                // ...
                computed({
                    get: () => store[key],
                    set(value) {
                        store[key] = value;
                    },
                });
        }
        else if (isRef(value) || isReactive(value)) {
            // @ts-expect-error: the key is state or getter
            refs[key] =
                // ---
                toRef(store, key);
        }
    }
    return refs;
}



;// CONCATENATED MODULE: ./src/modals/memory-store.ts



// 实体类型配置
const ENTITY_TYPE_CONFIG = {
  'Person': {
    name: '人物',
    icon: '👥',
    description: '团队成员、联系人、项目相关人员等'
  },
  'Project': {
    name: '项目',
    icon: '🚀',
    description: '工作项目、产品开发、研究项目等'
  },
  'Task': {
    name: '任务',
    icon: '📋',
    description: '具体工作任务、待办事项、行动项等'
  },
  'Organization': {
    name: '组织',
    icon: '🏢',
    description: '公司、部门、团队、客户组织等'
  },
  'Document': {
    name: '文档',
    icon: '📄',
    description: '文件、资料、规范、报告等'
  },
  'Technology': {
    name: '技术',
    icon: '🔧',
    description: '技术栈、工具、框架、平台等'
  },
  'Topic': {
    name: '主题',
    icon: '💡',
    description: '讨论话题、知识领域、专业概念等'
  }
};

// Chrome Extension API 封装
const chromeAPI = {
  async sendMessage(message) {
    if (typeof chrome !== 'undefined' && chrome.runtime) {
      return new Promise(resolve => {
        chrome.runtime.sendMessage(message, resolve);
      });
    }
    console.log('模拟Chrome API调用:', message);
    return {
      success: true,
      data: null
    };
  }
};

// Pinia Store
const useMemoryStore = defineStore('memory', () => {
  const isLoading = reactivity_esm_bundler_ref(false);
  const searchQuery = reactivity_esm_bundler_ref('');
  const entities = reactivity_esm_bundler_ref([]);
  const entityTypes = reactivity_esm_bundler_ref([{
    type: 'Project',
    name: '项目',
    icon: '🚀',
    count: 12
  }, {
    type: 'Topic',
    name: '主题',
    icon: '💡',
    count: 28
  }, {
    type: 'Person',
    name: '人物',
    icon: '👥',
    count: 45
  }, {
    type: 'Organization',
    name: '组织',
    icon: '🏢',
    count: 8
  }, {
    type: 'Document',
    name: '文档',
    icon: '📄',
    count: 156
  }, {
    type: 'Technology',
    name: '技术',
    icon: '🔧',
    count: 23
  }]);
  const overviewStats = reactivity_esm_bundler_ref({
    totalEntities: 272,
    totalRelationships: 156,
    entitiesCreatedToday: 5,
    entitiesCreatedThisWeek: 23,
    entitiesCreatedThisMonth: 89
  });
  const topicDetailData = reactivity_esm_bundler_ref(null);
  const personDetailData = reactivity_esm_bundler_ref(null);
  const initialize = async () => {
    isLoading.value = true;
    try {
      const response = await chromeAPI.sendMessage({
        type: 'GET_ENTITY_STATISTICS'
      });
      if (response && response.success) {
        overviewStats.value = response.data;
      }
    } catch (error) {
      console.warn('获取实体统计失败，使用模拟数据');
    } finally {
      isLoading.value = false;
    }
  };
  const loadEntitiesByType = async function (entityType) {
    let offset = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
    let limit = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 30;
    isLoading.value = true;
    try {
      const response = await chromeAPI.sendMessage({
        type: 'GET_ENTITIES_BY_TYPE',
        entityType,
        limit,
        offset
      });
      if (response && response.success) {
        entities.value = response.data || [];

        // 如果是第一页数据，检查 Topic 类型实体是否需要补充 recent data
        if (offset === 0 && entityType === 'Topic') {
          await enrichTopicEntitiesWithDetails(entities.value);
        }
      } else {
        entities.value = generateMockEntities(entityType);
      }
    } catch (error) {
      entities.value = generateMockEntities(entityType);
    } finally {
      isLoading.value = false;
    }
  };

  // 为 Topic 实体补充详细信息
  const enrichTopicEntitiesWithDetails = async topicEntities => {
    for (const entity of topicEntities) {
      // 检查是否缺少 recent data（没有讨论、资源、项目）
      const hasRecentData = entity.statistic?.conversations > 0 || entity.recentDataDetails?.conversations && entity.recentDataDetails.conversations.length > 0 || entity.recentDataDetails?.resources && entity.recentDataDetails.resources.length > 0 || entity.recentDataDetails?.projects && entity.recentDataDetails.projects.length > 0;
      if (!hasRecentData) {
        try {
          // 调用 handleGetTopicDetail 获取详细信息
          const detailResponse = await chromeAPI.sendMessage({
            type: 'GET_TOPIC_DETAIL',
            topicId: entity.id
          });
          if (detailResponse && detailResponse.success && detailResponse.data) {
            const details = detailResponse.data;

            // 更新实体信息（使用统一的 CachedEntityDetail 结构）
            if (!entity.statistic) entity.statistic = {};
            entity.statistic.conversations = details.statistic?.conversations || 0;
            entity.statistic.webpages = details.statistic?.webpages || 0;
            if (!entity.recentDataDetails) entity.recentDataDetails = {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            };
            entity.recentDataDetails.conversations = details.recentDataDetails?.conversations?.slice(0, 2) || [];
            entity.recentDataDetails.resources = details.recentDataDetails?.resources?.slice(0, 2) || [];
            entity.recentDataDetails.projects = details.recentDataDetails?.projects?.slice(0, 2) || [];
            entity.cachedAt = details.cachedAt || Date.now();
          }
        } catch (error) {
          console.error(`补充 Topic ${entity.id} 详细信息失败:`, error);
        }
      }
    }
  };
  const searchEntities = async query => {
    if (!query.trim()) return;
    isLoading.value = true;
    try {
      const response = await chromeAPI.sendMessage({
        type: 'SEARCH_ENTITIES',
        query,
        limit: 30
      });
      if (response && response.success) {
        entities.value = response.data || [];
      }
    } catch (error) {
      console.error('搜索失败:', error);
    } finally {
      isLoading.value = false;
    }
  };
  const vectorSearchEntities = async query => {
    if (!query.trim()) return;
    isLoading.value = true;
    searchQuery.value = query;
    try {
      const response = await chromeAPI.sendMessage({
        type: 'VECTOR_SEARCH_ENTITIES',
        query,
        limit: 20
      });
      if (response && response.success) {
        entities.value = response.data || [];
      } else {
        // 使用模拟数据展示向量搜索结果
        entities.value = generateMockVectorSearchResults(query);
      }
    } catch (error) {
      console.error('向量搜索失败:', error);
      // 使用模拟数据
      entities.value = generateMockVectorSearchResults(query);
    } finally {
      isLoading.value = false;
    }
  };
  const loadTopicDetail = async topicId => {
    isLoading.value = true;
    try {
      const response = await chromeAPI.sendMessage({
        type: 'GET_TOPIC_DETAIL',
        topicId
      });
      if (response && response.success) {
        topicDetailData.value = response.data;
      } else {
        topicDetailData.value = getMockTopicDetail(topicId);
      }
    } catch (error) {
      topicDetailData.value = getMockTopicDetail(topicId);
    } finally {
      isLoading.value = false;
    }
  };
  const generateMockEntities = entityType => {
    const config = ENTITY_TYPE_CONFIG[entityType];
    if (!config) return [];
    if (entityType === 'Topic') {
      return [{
        id: 'topic-ai-workflow',
        name: 'AI 工作流自动化',
        type: entityType,
        description: '讨论AI在工作流程中的应用和自动化实践',
        importance: 0.9,
        updated: Date.now() - 1800000,
        // 30分钟前
        latestConversations: [{
          id: 'msg-1',
          sender: '张三',
          group: '技术讨论组',
          datetime: new Date(Date.now() - 1800000).toISOString(),
          summary: '分享了最新的GPT-4 API集成经验，讨论了Token优化策略',
          originalContent: '我找到了一些优化Token使用的方法，可以减少30%的成本',
          highlightText: 'GPT-4 API Token优化策略',
          teamUrl: '#',
          matchedRules: ['AI', '优化'],
          relevanceScore: 0.95,
          context: []
        }, {
          id: 'msg-2',
          sender: '李四',
          group: '产品团队',
          datetime: new Date(Date.now() - 7200000).toISOString(),
          summary: '讨论了自动化测试的实现方案，提出了新的测试框架选型建议',
          originalContent: '建议采用Playwright + Jest的组合，覆盖率会更高',
          highlightText: '自动化测试实现方案',
          teamUrl: '#',
          matchedRules: ['测试', '自动化'],
          relevanceScore: 0.88,
          context: []
        }],
        relatedResources: [{
          id: 'resource-1',
          name: 'GPT-4 API 官方文档',
          url: 'https://platform.openai.com/docs'
        }, {
          id: 'resource-2',
          name: '自动化实践指南',
          url: '#'
        }],
        relatedProjects: [{
          id: 'project-1',
          name: 'Personal-AI',
          status: '开发中'
        }, {
          id: 'project-2',
          name: 'Automation Tools',
          status: '规划中'
        }],
        tags: ['AI', '自动化', '工作流'],
        status: 'active',
        cachedAt: Date.now(),
        statistic: {
          conversations: 12,
          projects: 2,
          participants: 8,
          resources: 2,
          documents: 1,
          webpages: 3,
          relationships: 5
        }
      }, {
        id: 'topic-frontend-optimization',
        name: '前端性能优化策略',
        type: entityType,
        description: '前端应用性能优化的技术讨论和最佳实践分享',
        importance: 0.8,
        updated: Date.now() - 7200000,
        // 2小时前
        latestConversations: [{
          id: 'msg-3',
          sender: '王五',
          group: '前端团队',
          datetime: new Date(Date.now() - 7200000).toISOString(),
          summary: '分析了React 18的并发特性对性能的影响',
          originalContent: 'React 18的并发特性可以显著提升用户体验',
          highlightText: 'React 18并发特性',
          teamUrl: '#',
          matchedRules: ['React', '性能'],
          relevanceScore: 0.92,
          context: []
        }, {
          id: 'msg-4',
          sender: '张三',
          group: '技术讨论组',
          datetime: new Date(Date.now() - 14400000).toISOString(),
          summary: 'Bundle体积优化技巧分享，减少30%的包大小',
          originalContent: '通过Webpack配置优化，我们成功减少了30%的Bundle大小',
          highlightText: 'Bundle体积优化',
          teamUrl: '#',
          matchedRules: ['优化', 'Webpack'],
          relevanceScore: 0.89,
          context: []
        }],
        relatedResources: [{
          id: 'resource-3',
          name: 'React 18 性能指南',
          url: '#'
        }, {
          id: 'resource-4',
          name: 'Webpack 优化手册',
          url: '#'
        }],
        relatedProjects: [{
          id: 'project-3',
          name: 'Web Platform',
          status: '优化中'
        }],
        tags: ['前端', '性能', 'React'],
        status: 'active',
        cachedAt: Date.now(),
        statistic: {
          conversations: 8,
          projects: 1,
          participants: 5,
          resources: 2,
          documents: 2,
          webpages: 1,
          relationships: 3
        }
      }, {
        id: 'topic-design-thinking',
        name: '产品设计思维方法',
        type: entityType,
        description: '产品设计流程、用户体验设计方法论的探讨',
        importance: 0.7,
        updated: Date.now() - 14400000,
        // 4小时前
        latestConversations: [{
          id: 'msg-5',
          sender: '李四',
          group: '设计团队',
          datetime: new Date(Date.now() - 14400000).toISOString(),
          summary: '用户研究方法在产品迭代中的应用案例分析',
          originalContent: '通过用户访谈和行为分析，我们发现了几个重要的改进点',
          highlightText: '用户研究方法应用',
          teamUrl: '#',
          matchedRules: ['用户研究', '产品迭代'],
          relevanceScore: 0.87,
          context: []
        }, {
          id: 'msg-6',
          sender: '产品经理',
          group: '产品团队',
          datetime: new Date(Date.now() - 21600000).toISOString(),
          summary: '设计系统在大型项目中的管理经验分享',
          originalContent: '建立统一的设计系统对大型项目的协作效率有显著提升',
          highlightText: '设计系统管理经验',
          teamUrl: '#',
          matchedRules: ['设计系统', '项目管理'],
          relevanceScore: 0.85,
          context: []
        }],
        relatedResources: [{
          id: 'resource-5',
          name: '设计思维实践手册',
          url: '#'
        }],
        relatedProjects: [{
          id: 'project-4',
          name: 'Design System',
          status: '进行中'
        }, {
          id: 'project-5',
          name: 'Mobile App',
          status: '设计中'
        }],
        tags: ['设计', 'UX', '产品'],
        status: 'active',
        cachedAt: Date.now(),
        statistic: {
          conversations: 6,
          projects: 2,
          participants: 4,
          resources: 1,
          documents: 1,
          webpages: 2,
          relationships: 2
        }
      }];
    }
    if (entityType === 'Project') {
      return [{
        id: 'project-personal-ai',
        name: 'Personal-AI',
        type: entityType,
        description: 'Chrome扩展智能助手，帮助用户管理知识图谱和提升工作效率',
        importance: 0.95,
        accessCount: 156,
        lastAccessed: Date.now() - 7200000,
        // 2小时前
        tags: ['Chrome扩展', 'AI', '智能助手'],
        status: 'active',
        isHighlighted: true,
        cachedAt: Date.now(),
        statistic: {
          conversations: 67,
          projects: 1,
          participants: 8,
          resources: 15,
          documents: 10,
          webpages: 34,
          relationships: 23
        },
        latestConversations: [],
        latestWebpages: [],
        relatedResources: [],
        relatedProjects: []
      }, {
        id: 'project-data-pipeline',
        name: 'Data Pipeline',
        type: entityType,
        description: '数据处理流水线，支持大规模数据的ETL处理和分析',
        importance: 0.8,
        accessCount: 89,
        lastAccessed: Date.now() - 18000000,
        // 5小时前
        tags: ['数据处理', 'ETL', '大数据'],
        status: 'active',
        isHighlighted: false,
        cachedAt: Date.now(),
        statistic: {
          conversations: 42,
          projects: 1,
          participants: 5,
          resources: 8,
          documents: 5,
          webpages: 18,
          relationships: 15
        },
        latestConversations: [],
        latestWebpages: [],
        relatedResources: [],
        relatedProjects: []
      }, {
        id: 'project-web-platform',
        name: 'Web Platform',
        type: entityType,
        description: '前端Web平台，提供统一的用户界面和交互体验',
        importance: 0.7,
        accessCount: 134,
        lastAccessed: Date.now() - 43200000,
        // 12小时前
        tags: ['前端', 'Web', '用户体验'],
        status: 'active',
        isHighlighted: true,
        cachedAt: Date.now(),
        statistic: {
          conversations: 78,
          projects: 1,
          participants: 12,
          resources: 20,
          documents: 15,
          webpages: 45,
          relationships: 28
        },
        latestConversations: [],
        latestWebpages: [],
        relatedResources: [],
        relatedProjects: []
      }, {
        id: 'project-design-system',
        name: 'Design System',
        type: entityType,
        description: '设计系统组件库，统一产品设计语言和组件规范',
        importance: 0.6,
        accessCount: 67,
        lastAccessed: Date.now() - 86400000,
        // 1天前
        tags: ['设计系统', 'UI组件', '规范'],
        status: 'active',
        isHighlighted: false,
        cachedAt: Date.now(),
        statistic: {
          conversations: 29,
          projects: 1,
          participants: 6,
          resources: 10,
          documents: 8,
          webpages: 16,
          relationships: 12
        },
        latestConversations: [],
        latestWebpages: [],
        relatedResources: [],
        relatedProjects: []
      }, {
        id: 'project-automation-tools',
        name: 'Automation Tools',
        type: entityType,
        description: 'CI/CD自动化工具链，提升开发和部署效率',
        importance: 0.75,
        accessCount: 93,
        lastAccessed: Date.now() - 172800000,
        // 2天前
        tags: ['自动化', 'CI/CD', '工具链'],
        status: 'active',
        isHighlighted: false,
        cachedAt: Date.now(),
        statistic: {
          conversations: 36,
          projects: 1,
          participants: 8,
          resources: 12,
          documents: 7,
          webpages: 22,
          relationships: 18
        },
        latestConversations: [],
        latestWebpages: [],
        relatedResources: [],
        relatedProjects: []
      }];
    }
    if (entityType === 'Person') {
      return [{
        id: 'person-zhangsan',
        name: '张三',
        type: entityType,
        description: '前端开发工程师，擅长React和TypeScript开发，团队中的技术专家',
        role: '前端工程师',
        team: '技术团队',
        lastContact: Date.now() - 3600000,
        // 1小时前
        expertise: ['React', 'TypeScript', '性能优化', '组件设计'],
        recentCollaborations: [{
          id: 'collab-1',
          projectId: 'project-personal-ai',
          projectName: 'Personal-AI',
          time: '1小时前'
        }, {
          id: 'collab-2',
          projectId: 'project-web-platform',
          projectName: 'Web Platform',
          time: '3小时前'
        }],
        recentMessages: [{
          id: 'msg-1',
          summary: '代码审查反馈：建议优化组件性能',
          time: '1小时前'
        }, {
          id: 'msg-2',
          summary: '分享了一个有用的React Hook实现方案',
          time: '2小时前'
        }],
        tags: ['前端', '技术专家', 'React'],
        status: 'active',
        cachedAt: Date.now(),
        statistic: {
          conversations: 25,
          projects: 2,
          participants: 1,
          resources: 5,
          documents: 3,
          webpages: 8,
          relationships: 12
        },
        latestConversations: [],
        latestWebpages: []
      }, {
        id: 'person-lisi',
        name: '李四',
        type: entityType,
        description: 'UI/UX设计师，专注用户体验设计和交互原型，设计团队核心成员',
        role: 'UI/UX设计师',
        team: '设计团队',
        lastContact: Date.now() - 10800000,
        // 3小时前
        expertise: ['用户体验', 'Figma', '交互设计', '设计系统'],
        recentCollaborations: [{
          id: 'collab-3',
          projectId: 'project-design-system',
          projectName: 'Design System',
          time: '3小时前'
        }, {
          id: 'collab-4',
          projectId: 'project-personal-ai',
          projectName: 'Personal-AI',
          time: '5小时前'
        }],
        recentMessages: [{
          id: 'msg-3',
          summary: '设计稿更新通知：新版用户界面已完成',
          time: '3小时前'
        }, {
          id: 'msg-4',
          summary: '用户体验测试报告分享，发现了几个可改进点',
          time: '4小时前'
        }],
        tags: ['设计', 'UX', '原型'],
        status: 'active',
        cachedAt: Date.now(),
        statistic: {
          conversations: 18,
          projects: 2,
          participants: 1,
          resources: 8,
          documents: 5,
          webpages: 12,
          relationships: 8
        },
        latestConversations: [],
        latestWebpages: []
      }, {
        id: 'person-wangwu',
        name: '王五',
        type: entityType,
        description: '后端开发工程师，负责系统架构设计和API开发，技术栈涵盖多种语言',
        role: '后端工程师',
        team: '技术团队',
        lastContact: Date.now() - 21600000,
        // 6小时前
        expertise: ['系统架构', 'API设计', 'Node.js', '数据库'],
        recentCollaborations: [{
          id: 'collab-5',
          projectId: 'project-data-pipeline',
          projectName: 'Data Pipeline',
          time: '6小时前'
        }, {
          id: 'collab-6',
          projectId: 'project-automation-tools',
          projectName: 'Automation Tools',
          time: '1天前'
        }],
        recentMessages: [{
          id: 'msg-5',
          summary: '会议纪要分享：API架构优化方案讨论',
          time: '6小时前'
        }, {
          id: 'msg-6',
          summary: '数据库性能优化建议和实施计划',
          time: '8小时前'
        }],
        tags: ['后端', '架构师', 'API'],
        status: 'active',
        cachedAt: Date.now(),
        statistic: {
          conversations: 22,
          projects: 2,
          participants: 1,
          resources: 12,
          documents: 8,
          webpages: 6,
          relationships: 15
        },
        latestConversations: [],
        latestWebpages: []
      }];
    }

    // 其他类型实体的原始生成逻辑
    return Array.from({
      length: 5
    }, (_, i) => ({
      id: `${entityType.toLowerCase()}-${i + 1}`,
      name: `${config.name} ${i + 1}`,
      type: entityType,
      description: `这是一个${config.description}的示例`,
      importance: Math.random(),
      accessCount: Math.floor(Math.random() * 100),
      lastAccessed: Date.now() - Math.floor(Math.random() * 86400000),
      tags: ['示例', '测试'],
      status: 'active',
      cachedAt: Date.now(),
      statistic: {
        conversations: Math.floor(Math.random() * 50),
        projects: Math.floor(Math.random() * 10),
        participants: Math.floor(Math.random() * 15),
        resources: Math.floor(Math.random() * 20),
        documents: Math.floor(Math.random() * 10),
        webpages: Math.floor(Math.random() * 30),
        relationships: Math.floor(Math.random() * 20)
      },
      latestConversations: [],
      latestWebpages: [],
      relatedResources: [],
      relatedProjects: []
    }));
  };
  const generateMockVectorSearchResults = query => {
    // 基于查询生成模拟的向量搜索结果，包含多种类型的实体
    const searchTerms = query.toLowerCase();
    const results = [];

    // AI相关搜索
    if (searchTerms.includes('ai') || searchTerms.includes('人工智能') || searchTerms.includes('智能')) {
      results.push({
        id: 'topic-ai-workflow',
        name: 'AI 工作流自动化',
        type: 'Topic',
        description: '讨论AI在工作流程中的应用和自动化实践',
        relevanceScore: 0.95,
        tags: ['AI', '自动化', '工作流']
      }, {
        id: 'project-personal-ai',
        name: 'Personal-AI',
        type: 'Project',
        description: 'Chrome扩展智能助手，帮助用户管理知识图谱',
        relevanceScore: 0.88,
        tags: ['Chrome扩展', 'AI', '智能助手']
      });
    }

    // 前端相关搜索
    if (searchTerms.includes('前端') || searchTerms.includes('react') || searchTerms.includes('web')) {
      results.push({
        id: 'topic-frontend-optimization',
        name: '前端性能优化策略',
        type: 'Topic',
        description: '前端应用性能优化的技术讨论和最佳实践分享',
        relevanceScore: 0.82,
        tags: ['前端', '性能', 'React']
      }, {
        id: 'person-zhangsan',
        name: '张三',
        type: 'Person',
        description: '前端开发工程师，擅长React和TypeScript开发',
        relevanceScore: 0.75,
        tags: ['前端', '技术专家', 'React']
      });
    }

    // 设计相关搜索
    if (searchTerms.includes('设计') || searchTerms.includes('ui') || searchTerms.includes('ux')) {
      results.push({
        id: 'topic-design-thinking',
        name: '产品设计思维方法',
        type: 'Topic',
        description: '产品设计流程、用户体验设计方法论的探讨',
        relevanceScore: 0.78,
        tags: ['设计', 'UX', '产品']
      }, {
        id: 'person-lisi',
        name: '李四',
        type: 'Person',
        description: 'UI/UX设计师，专注用户体验设计和交互原型',
        relevanceScore: 0.73,
        tags: ['设计', 'UX', '原型']
      });
    }

    // 默认结果（通用搜索）
    if (results.length === 0) {
      results.push({
        id: 'topic-ai-workflow',
        name: 'AI 工作流自动化',
        type: 'Topic',
        description: '讨论AI在工作流程中的应用和自动化实践',
        relevanceScore: 0.65,
        tags: ['AI', '自动化', '工作流']
      }, {
        id: 'project-web-platform',
        name: 'Web Platform',
        type: 'Project',
        description: '前端Web平台，提供统一的用户界面和交互体验',
        relevanceScore: 0.58,
        tags: ['前端', 'Web', '用户体验']
      });
    }

    // 按相关性分数排序
    return results.sort((a, b) => b.relevanceScore - a.relevanceScore);
  };
  const getMockTopicDetail = topicId => {
    return {
      id: topicId,
      title: 'AI 工作流自动化',
      overview: {
        discussions: 12,
        projects: 5,
        participants: 8,
        resources: 15
      },
      relatedProjects: [{
        id: 'project-1',
        name: 'Personal-AI',
        status: '开发中',
        description: 'Chrome扩展智能助手'
      }, {
        id: 'project-2',
        name: 'Automation Tools',
        status: '规划中',
        description: 'CI/CD自动化工具链'
      }],
      relatedResources: [{
        id: 'resource-1',
        name: 'AI开发最佳实践',
        type: '技术文档',
        url: '#'
      }, {
        id: 'resource-2',
        name: '自动化工具指南',
        type: '教程',
        url: '#'
      }],
      relatedTickets: [{
        id: 'AI-123',
        title: '实现智能推荐算法',
        status: '进行中',
        assignee: '张三',
        priority: '高'
      }, {
        id: 'AI-124',
        title: '优化用户界面响应速度',
        status: '待开始',
        assignee: '李四',
        priority: '中'
      }, {
        id: 'AI-125',
        title: '集成第三方AI服务',
        status: '已完成',
        assignee: '王五',
        priority: '低'
      }],
      conversations: [{
        id: 'conv-1',
        sender: '张三',
        group: '技术讨论组',
        time: '30分钟前',
        summary: '分享了最新的GPT-4 API集成经验，讨论了Token优化策略',
        context: [{
          sender: '李四',
          content: '最近GPT-4的API调用成本有点高',
          time: '35分钟前'
        }, {
          sender: '张三',
          content: '我找到了一些优化Token使用的方法，可以减少30%的成本',
          time: '30分钟前',
          isMainMessage: true
        }, {
          sender: '王五',
          content: '能分享一下具体的优化策略吗？',
          time: '28分钟前'
        }]
      }, {
        id: 'conv-2',
        sender: '李四',
        group: '产品团队',
        time: '2小时前',
        summary: '讨论了自动化测试的实现方案，提出了新的测试框架选型建议',
        context: [{
          sender: '产品经理',
          content: '我们需要一个更好的自动化测试方案',
          time: '2.5小时前'
        }, {
          sender: '李四',
          content: '建议采用Playwright + Jest的组合，覆盖率会更高',
          time: '2小时前',
          isMainMessage: true
        }, {
          sender: '测试负责人',
          content: '这个方案看起来不错，我们可以试试',
          time: '1.5小时前'
        }]
      }, {
        id: 'conv-3',
        sender: '王五',
        group: 'AI研发团队',
        time: '4小时前',
        summary: '探讨了多模态AI模型在产品中的应用场景',
        context: [{
          sender: '技术总监',
          content: '现在多模态AI技术越来越成熟了',
          time: '4.5小时前'
        }, {
          sender: '王五',
          content: '我们可以考虑在用户界面中集成图像识别和文本理解',
          time: '4小时前',
          isMainMessage: true
        }, {
          sender: '产品经理',
          content: '这样可以大大提升用户体验',
          time: '3.5小时前'
        }]
      }],
      webpages: [{
        id: 'webpage-1',
        title: 'OpenAI GPT-4 API 官方文档',
        url: 'https://platform.openai.com/docs/models/gpt-4',
        type: 'docs',
        visitTime: '2小时前',
        relevanceScore: 0.95,
        summary: '详细介绍了GPT-4 API的使用方法、参数配置和最佳实践',
        tags: ['API文档', 'GPT-4', '官方文档']
      }, {
        id: 'webpage-2',
        title: 'Chrome Extension Automation Best Practices',
        url: 'https://developer.chrome.com/docs/extensions/mv3/automation',
        type: 'docs',
        visitTime: '昨天',
        relevanceScore: 0.78,
        summary: 'Chrome扩展自动化开发的最佳实践和技术指南',
        tags: ['Chrome扩展', '自动化', '最佳实践']
      }, {
        id: 'webpage-3',
        title: 'GitHub Actions 工作流配置指南',
        url: 'https://docs.github.com/en/actions/workflows',
        type: 'github',
        visitTime: '3天前',
        relevanceScore: 0.82,
        summary: 'CI/CD自动化工作流的配置方法和实用技巧',
        tags: ['GitHub Actions', 'CI/CD', '自动化']
      }]
    };
  };
  return {
    isLoading,
    searchQuery,
    entities,
    entityTypes,
    overviewStats,
    topicDetailData,
    personDetailData,
    initialize,
    loadEntitiesByType,
    searchEntities,
    vectorSearchEntities,
    loadTopicDetail
  };
});
;// CONCATENATED MODULE: ./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[6].use[0]!./src/modals/memory-exploring.vue?vue&type=script&setup=true&lang=ts


const _hoisted_1 = {
  id: "memory-app"
};
const _hoisted_2 = {
  class: "memory-container"
};
const _hoisted_3 = {
  class: "sidebar"
};
const _hoisted_4 = {
  class: "entity-types"
};
const _hoisted_5 = {
  class: "entity-icon"
};
const _hoisted_6 = {
  class: "entity-name"
};
const _hoisted_7 = {
  class: "entity-count"
};
const _hoisted_8 = {
  class: "main-content"
};
const _hoisted_9 = {
  class: "search-header"
};
const _hoisted_10 = {
  class: "search-box"
};




// 应用初始化逻辑

/* harmony default export */ const memory_exploringvue_type_script_setup_true_lang_ts = (/*@__PURE__*/runtime_core_esm_bundler_defineComponent({
  __name: 'memory-exploring',
  setup(__props) {
    const store = useMemoryStore();
    const router = useRouter();
    const entityTypes = runtime_core_esm_bundler_computed(() => store.entityTypes);
    const searchQuery = reactivity_esm_bundler_ref('');
    const handleSearchInput = () => {
      if (searchQuery.value.length > 2) {
        performSearch();
      }
    };
    const handleSearch = () => {
      if (searchQuery.value.trim()) {
        performSearch();
      }
    };
    const performSearch = () => {
      if (searchQuery.value.trim().length >= 2) {
        // 使用云端向量检索进行搜索
        store.vectorSearchEntities(searchQuery.value);
        router.push({
          path: '/search',
          query: {
            q: searchQuery.value
          }
        });
      }
    };
    const clearSearch = () => {
      searchQuery.value = '';
      store.searchQuery = '';
      router.push('/');
    };
    runtime_core_esm_bundler_onMounted(() => {
      store.initialize();
    });
    return (_ctx, _cache) => {
      const _component_router_link = resolveComponent("router-link");
      const _component_router_view = resolveComponent("router-view");
      return openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("div", _hoisted_2, [createCommentVNode(" 侧边栏 "), createBaseVNode("div", _hoisted_3, [_cache[5] || (_cache[5] = createBaseVNode("div", {
        class: "sidebar-header"
      }, [createBaseVNode("div", {
        class: "logo"
      }, "🧠 记忆查询系统")], -1 /* CACHED */)), createBaseVNode("div", _hoisted_4, [createVNode(_component_router_link, {
        to: "/",
        class: "entity-type",
        "active-class": "router-link-active"
      }, {
        default: withCtx(() => [...(_cache[1] || (_cache[1] = [createBaseVNode("div", {
          class: "entity-icon"
        }, "🏠", -1 /* CACHED */), createBaseVNode("div", {
          class: "entity-name"
        }, "首页概览", -1 /* CACHED */)]))]),
        _: 1 /* STABLE */
      }), createVNode(_component_router_link, {
        to: "/timeline",
        class: "entity-type",
        "active-class": "router-link-active"
      }, {
        default: withCtx(() => [...(_cache[2] || (_cache[2] = [createBaseVNode("div", {
          class: "entity-icon"
        }, "⏰", -1 /* CACHED */), createBaseVNode("div", {
          class: "entity-name"
        }, "时间轴", -1 /* CACHED */)]))]),
        _: 1 /* STABLE */
      }), createVNode(_component_router_link, {
        to: "/user-profile",
        class: "entity-type",
        "active-class": "router-link-active"
      }, {
        default: withCtx(() => [...(_cache[3] || (_cache[3] = [createBaseVNode("div", {
          class: "entity-icon"
        }, "👤", -1 /* CACHED */), createBaseVNode("div", {
          class: "entity-name"
        }, "用户画像", -1 /* CACHED */)]))]),
        _: 1 /* STABLE */
      }), _cache[4] || (_cache[4] = createBaseVNode("hr", {
        class: "sidebar-divider"
      }, null, -1 /* CACHED */)), (openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(entityTypes.value, entityType => {
        return openBlock(), createBlock(_component_router_link, {
          key: entityType.type,
          to: `/entity/${entityType.type}`,
          class: "entity-type",
          "active-class": "router-link-active"
        }, {
          default: withCtx(() => [createBaseVNode("div", _hoisted_5, toDisplayString(entityType.icon), 1 /* TEXT */), createBaseVNode("div", _hoisted_6, toDisplayString(entityType.name), 1 /* TEXT */), createBaseVNode("div", _hoisted_7, toDisplayString(entityType.count), 1 /* TEXT */)]),
          _: 2 /* DYNAMIC */
        }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["to"]);
      }), 128 /* KEYED_FRAGMENT */))])]), createCommentVNode(" 主内容区 "), createBaseVNode("div", _hoisted_8, [createCommentVNode(" 搜索头部 "), createBaseVNode("div", _hoisted_9, [createBaseVNode("div", _hoisted_10, [_cache[6] || (_cache[6] = createBaseVNode("div", {
        class: "search-icon"
      }, "🔍", -1 /* CACHED */)), withDirectives(createBaseVNode("input", {
        type: "text",
        class: "search-input",
        placeholder: "搜索任何内容、实体或关键词...",
        "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => searchQuery.value = $event),
        onInput: handleSearchInput,
        onKeypress: withKeys(handleSearch, ["enter"])
      }, null, 544 /* NEED_HYDRATION, NEED_PATCH */), [[vModelText, searchQuery.value]])]), createBaseVNode("button", {
        class: "filter-btn",
        onClick: handleSearch
      }, "📊 搜索"), createBaseVNode("button", {
        class: "filter-btn",
        onClick: clearSearch
      }, "🔄 重置")]), createCommentVNode(" 路由内容 "), createVNode(_component_router_view, null, {
        default: withCtx(_ref => {
          let {
            Component
          } = _ref;
          return [createVNode(Transition, {
            name: "fade",
            mode: "out-in"
          }, {
            default: withCtx(() => [(openBlock(), createBlock(resolveDynamicComponent(Component)))]),
            _: 2 /* DYNAMIC */
          }, 1024 /* DYNAMIC_SLOTS */)];
        }),
        _: 1 /* STABLE */
      })])])]);
    };
  }
}));
;// CONCATENATED MODULE: ./src/modals/memory-exploring.vue?vue&type=script&setup=true&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[6].use[0]!./src/modals/memory-exploring.vue?vue&type=style&index=0&id=e69bba54&lang=css
var memory_exploringvue_type_style_index_0_id_e69bba54_lang_css = __webpack_require__(2325);
;// CONCATENATED MODULE: ./src/modals/memory-exploring.vue?vue&type=style&index=0&id=e69bba54&lang=css

;// CONCATENATED MODULE: ./src/modals/memory-exploring.vue



;

const __exports__ = memory_exploringvue_type_script_setup_true_lang_ts;

/* harmony default export */ const memory_exploring = (__exports__);
;// CONCATENATED MODULE: ./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[6].use[0]!./src/modals/components/OverviewPage.vue?vue&type=script&setup=true&lang=ts


const OverviewPagevue_type_script_setup_true_lang_ts_hoisted_1 = {
  class: "overview-section"
};
const OverviewPagevue_type_script_setup_true_lang_ts_hoisted_2 = {
  class: "greeting-card"
};
const OverviewPagevue_type_script_setup_true_lang_ts_hoisted_3 = {
  class: "greeting-content"
};
const OverviewPagevue_type_script_setup_true_lang_ts_hoisted_4 = {
  class: "quick-summary"
};
const OverviewPagevue_type_script_setup_true_lang_ts_hoisted_5 = {
  class: "content-grid"
};
const OverviewPagevue_type_script_setup_true_lang_ts_hoisted_6 = {
  class: "card-header"
};
const OverviewPagevue_type_script_setup_true_lang_ts_hoisted_7 = {
  class: "card-badge"
};
const OverviewPagevue_type_script_setup_true_lang_ts_hoisted_8 = {
  class: "card-header"
};
const OverviewPagevue_type_script_setup_true_lang_ts_hoisted_9 = {
  class: "card-badge"
};
const OverviewPagevue_type_script_setup_true_lang_ts_hoisted_10 = {
  class: "info-list"
};



/* harmony default export */ const OverviewPagevue_type_script_setup_true_lang_ts = (/*@__PURE__*/runtime_core_esm_bundler_defineComponent({
  __name: 'OverviewPage',
  setup(__props) {
    const store = useMemoryStore();
    const router = useRouter();
    const overviewStats = runtime_core_esm_bundler_computed(() => store.overviewStats);
    const navigateToEntityType = entityType => {
      router.push(`/entity/${entityType}`);
    };
    const navigateToTopic = topicId => {
      router.push(`/topic/${topicId}`);
    };
    const getEntityCount = entityType => {
      const entity = store.entityTypes.find(e => e.type === entityType);
      return entity ? entity.count : 0;
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", OverviewPagevue_type_script_setup_true_lang_ts_hoisted_1, [createBaseVNode("div", OverviewPagevue_type_script_setup_true_lang_ts_hoisted_2, [_cache[6] || (_cache[6] = createBaseVNode("div", {
        class: "greeting-title"
      }, [createBaseVNode("span", null, "🌅"), createBaseVNode("span", null, "欢迎来到记忆查询系统")], -1 /* CACHED */)), createBaseVNode("div", OverviewPagevue_type_script_setup_true_lang_ts_hoisted_3, [_cache[4] || (_cache[4] = createBaseVNode("p", null, "您的个人知识图谱中包含:", -1 /* CACHED */)), createBaseVNode("ul", OverviewPagevue_type_script_setup_true_lang_ts_hoisted_4, [createBaseVNode("li", null, "📊 " + toDisplayString(overviewStats.value?.totalEntities || 0) + " 个实体，" + toDisplayString(overviewStats.value?.totalRelationships || 0) + " 个关系", 1 /* TEXT */), createBaseVNode("li", null, "📈 今日新增 " + toDisplayString(overviewStats.value?.entitiesCreatedToday || 0) + " 个实体", 1 /* TEXT */), createBaseVNode("li", null, "📅 本周新增 " + toDisplayString(overviewStats.value?.entitiesCreatedThisWeek || 0) + " 个实体", 1 /* TEXT */), createBaseVNode("li", null, "📆 本月新增 " + toDisplayString(overviewStats.value?.entitiesCreatedThisMonth || 0) + " 个实体", 1 /* TEXT */)]), _cache[5] || (_cache[5] = createBaseVNode("p", null, "点击左侧类别开始探索您的记忆 👈", -1 /* CACHED */))])]), createBaseVNode("div", OverviewPagevue_type_script_setup_true_lang_ts_hoisted_5, [createCommentVNode(" 今日重点项目 "), createBaseVNode("div", {
        class: "content-card",
        onClick: _cache[0] || (_cache[0] = $event => navigateToEntityType('Project'))
      }, [createBaseVNode("div", OverviewPagevue_type_script_setup_true_lang_ts_hoisted_6, [_cache[7] || (_cache[7] = createBaseVNode("div", {
        class: "card-title"
      }, [createBaseVNode("span", null, "🚀"), createBaseVNode("span", null, "今日重点项目")], -1 /* CACHED */)), createBaseVNode("div", OverviewPagevue_type_script_setup_true_lang_ts_hoisted_7, toDisplayString(getEntityCount('Project')) + " 个活跃", 1 /* TEXT */)]), _cache[8] || (_cache[8] = createStaticVNode("<div class=\"card-content\">最近活跃的项目和相关信息</div><ul class=\"info-list\"><li class=\"info-item\"><span>🔥</span><span>Personal-AI - Chrome 扩展开发</span><span class=\"info-time\">2 小时前</span></li><li class=\"info-item\"><span>📊</span><span>Data Pipeline - 性能优化</span><span class=\"info-time\">5 小时前</span></li><li class=\"info-item\"><span>🎨</span><span>Design System - 组件库更新</span><span class=\"info-time\">1 天前</span></li></ul><div class=\"view-more-btn\"><span>查看所有项目</span><span>→</span></div>", 3))]), createCommentVNode(" 热门主题讨论 "), createBaseVNode("div", {
        class: "content-card",
        onClick: _cache[2] || (_cache[2] = $event => navigateToEntityType('Topic'))
      }, [createBaseVNode("div", OverviewPagevue_type_script_setup_true_lang_ts_hoisted_8, [_cache[9] || (_cache[9] = createBaseVNode("div", {
        class: "card-title"
      }, [createBaseVNode("span", null, "💡"), createBaseVNode("span", null, "热门主题讨论")], -1 /* CACHED */)), createBaseVNode("div", OverviewPagevue_type_script_setup_true_lang_ts_hoisted_9, toDisplayString(getEntityCount('Topic')) + " 个活跃", 1 /* TEXT */)]), _cache[13] || (_cache[13] = createBaseVNode("div", {
        class: "card-content"
      }, "最近讨论频繁的话题和观点", -1 /* CACHED */)), createBaseVNode("ul", OverviewPagevue_type_script_setup_true_lang_ts_hoisted_10, [createBaseVNode("li", {
        class: "info-item",
        onClick: _cache[1] || (_cache[1] = withModifiers($event => navigateToTopic('ai-workflow'), ["stop"]))
      }, [...(_cache[10] || (_cache[10] = [createBaseVNode("span", null, "🤖", -1 /* CACHED */), createBaseVNode("span", null, "AI 工作流自动化实践", -1 /* CACHED */), createBaseVNode("span", {
        class: "info-time"
      }, "30 分钟前", -1 /* CACHED */)]))]), _cache[11] || (_cache[11] = createBaseVNode("li", {
        class: "info-item"
      }, [createBaseVNode("span", null, "⚡"), createBaseVNode("span", null, "前端性能优化策略"), createBaseVNode("span", {
        class: "info-time"
      }, "2 小时前")], -1 /* CACHED */)), _cache[12] || (_cache[12] = createBaseVNode("li", {
        class: "info-item"
      }, [createBaseVNode("span", null, "🎯"), createBaseVNode("span", null, "产品设计思维方法"), createBaseVNode("span", {
        class: "info-time"
      }, "4 小时前")], -1 /* CACHED */))]), _cache[14] || (_cache[14] = createBaseVNode("div", {
        class: "view-more-btn"
      }, [createBaseVNode("span", null, "查看所有主题"), createBaseVNode("span", null, "→")], -1 /* CACHED */))]), createCommentVNode(" 重要联系人动态 "), createBaseVNode("div", {
        class: "content-card",
        onClick: _cache[3] || (_cache[3] = $event => navigateToEntityType('Person'))
      }, [...(_cache[15] || (_cache[15] = [createStaticVNode("<div class=\"card-header\"><div class=\"card-title\"><span>👥</span><span>重要联系人动态</span></div><div class=\"card-badge\">新消息</div></div><div class=\"card-content\">来自同事和合作伙伴的重要更新</div><ul class=\"info-list\"><li class=\"info-item\"><span>👤</span><span>张三 - 代码审查反馈</span><span class=\"info-time\">1 小时前</span></li><li class=\"info-item\"><span>👤</span><span>李四 - 设计稿更新通知</span><span class=\"info-time\">3 小时前</span></li><li class=\"info-item\"><span>👤</span><span>王五 - 会议纪要分享</span><span class=\"info-time\">6 小时前</span></li></ul><div class=\"view-more-btn\"><span>查看所有联系人</span><span>→</span></div>", 4)]))]), createCommentVNode(" AI 推荐内容 "), _cache[16] || (_cache[16] = createStaticVNode("<div class=\"content-card\"><div class=\"card-header\"><div class=\"card-title\"><span>🎯</span><span>AI 推荐内容</span></div><div class=\"card-badge\">智能推荐</div></div><div class=\"card-content\">基于你的兴趣和工作习惯推荐的内容</div><ul class=\"info-list\"><li class=\"info-item\"><span>📖</span><span>《Clean Architecture》读书笔记复习</span><span class=\"info-time\">推荐</span></li><li class=\"info-item\"><span>🔧</span><span>Webpack 5 迁移指南</span><span class=\"info-time\">推荐</span></li><li class=\"info-item\"><span>💡</span><span>React 18 新特性总结</span><span class=\"info-time\">推荐</span></li></ul><div class=\"view-more-btn\"><span>查看更多推荐</span><span>→</span></div></div>", 1))])]);
    };
  }
}));
;// CONCATENATED MODULE: ./src/modals/components/OverviewPage.vue?vue&type=script&setup=true&lang=ts
 
;// CONCATENATED MODULE: ./src/modals/components/OverviewPage.vue



const OverviewPage_exports_ = OverviewPagevue_type_script_setup_true_lang_ts;

/* harmony default export */ const OverviewPage = (OverviewPage_exports_);
;// CONCATENATED MODULE: ./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[6].use[0]!./src/modals/components/TimelinePage.vue?vue&type=script&setup=true&lang=ts


const TimelinePagevue_type_script_setup_true_lang_ts_hoisted_1 = {
  class: "timeline-view"
};
const TimelinePagevue_type_script_setup_true_lang_ts_hoisted_2 = {
  key: 0,
  class: "loading-container"
};
const TimelinePagevue_type_script_setup_true_lang_ts_hoisted_3 = {
  key: 1,
  class: "timeline-container"
};
const TimelinePagevue_type_script_setup_true_lang_ts_hoisted_4 = {
  class: "timeline-dot"
};
const TimelinePagevue_type_script_setup_true_lang_ts_hoisted_5 = {
  class: "timeline-content"
};
const TimelinePagevue_type_script_setup_true_lang_ts_hoisted_6 = {
  class: "timeline-time"
};
const TimelinePagevue_type_script_setup_true_lang_ts_hoisted_7 = {
  class: "content-card",
  style: {
    "margin": "0"
  }
};
const TimelinePagevue_type_script_setup_true_lang_ts_hoisted_8 = {
  class: "card-title"
};
const TimelinePagevue_type_script_setup_true_lang_ts_hoisted_9 = {
  class: "card-content"
};
const TimelinePagevue_type_script_setup_true_lang_ts_hoisted_10 = {
  key: 0,
  class: "event-source"
};
const _hoisted_11 = {
  key: 0,
  class: "empty-state"
};


/* harmony default export */ const TimelinePagevue_type_script_setup_true_lang_ts = (/*@__PURE__*/runtime_core_esm_bundler_defineComponent({
  __name: 'TimelinePage',
  setup(__props) {
    const store = useMemoryStore();
    const timelineEvents = reactivity_esm_bundler_ref([{
      id: 'event-1',
      type: 'start',
      title: '开始新的一天',
      content: '查看了昨天的工作总结和今日计划',
      timestamp: Date.now() - 4 * 3600000
    }, {
      id: 'event-2',
      type: 'message',
      title: '团队晨会讨论',
      content: '讨论了 Personal-AI 项目的进展，张三提出了代码审查建议',
      timestamp: Date.now() - 3 * 3600000,
      source: '团队会议'
    }, {
      id: 'event-3',
      type: 'update',
      title: '技术文档更新',
      content: '更新了 React Query 集成文档，添加了错误处理最佳实践',
      timestamp: Date.now() - 2 * 3600000
    }, {
      id: 'event-4',
      type: 'task',
      title: 'Jira 任务更新',
      content: '完成了 3 个 bug 修复，更新了任务状态到"待测试"',
      timestamp: Date.now() - 1 * 3600000,
      source: 'Jira'
    }]);
    const isLoading = runtime_core_esm_bundler_computed(() => store.isLoading);
    const getTimelineIcon = type => {
      const icons = {
        'start': '🌅',
        'message': '💬',
        'update': '🔧',
        'task': '📊',
        'webpage': '🌐',
        'relation_created': '🔗',
        'entity_updated': '📝'
      };
      return icons[type] || '📅';
    };
    const formatTime = timestamp => {
      const now = Date.now();
      const diff = now - timestamp;
      const minutes = Math.floor(diff / 60000);
      const hours = Math.floor(diff / 3600000);
      const days = Math.floor(diff / 86400000);
      if (minutes < 60) return `${minutes}分钟前`;
      if (hours < 24) return `${hours}小时前`;
      if (days < 30) return `${days}天前`;
      return new Date(timestamp).toLocaleDateString();
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", TimelinePagevue_type_script_setup_true_lang_ts_hoisted_1, [_cache[2] || (_cache[2] = createBaseVNode("h2", {
        style: {
          "margin-bottom": "2rem",
          "font-size": "1.5rem",
          "font-weight": "600"
        }
      }, "📅 今日时间轴", -1 /* CACHED */)), isLoading.value ? (openBlock(), createElementBlock("div", TimelinePagevue_type_script_setup_true_lang_ts_hoisted_2, [...(_cache[0] || (_cache[0] = [createBaseVNode("div", {
        class: "loading-spinner"
      }, null, -1 /* CACHED */), createBaseVNode("span", null, "加载时间轴数据...", -1 /* CACHED */)]))])) : (openBlock(), createElementBlock("div", TimelinePagevue_type_script_setup_true_lang_ts_hoisted_3, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(timelineEvents.value, event => {
        return openBlock(), createElementBlock("div", {
          key: event.id,
          class: "timeline-item"
        }, [createBaseVNode("div", TimelinePagevue_type_script_setup_true_lang_ts_hoisted_4, toDisplayString(getTimelineIcon(event.type)), 1 /* TEXT */), createBaseVNode("div", TimelinePagevue_type_script_setup_true_lang_ts_hoisted_5, [createBaseVNode("div", TimelinePagevue_type_script_setup_true_lang_ts_hoisted_6, toDisplayString(formatTime(event.timestamp)), 1 /* TEXT */), createBaseVNode("div", TimelinePagevue_type_script_setup_true_lang_ts_hoisted_7, [createBaseVNode("div", TimelinePagevue_type_script_setup_true_lang_ts_hoisted_8, toDisplayString(event.title), 1 /* TEXT */), createBaseVNode("div", TimelinePagevue_type_script_setup_true_lang_ts_hoisted_9, toDisplayString(event.content), 1 /* TEXT */), event.source ? (openBlock(), createElementBlock("div", TimelinePagevue_type_script_setup_true_lang_ts_hoisted_10, "来源: " + toDisplayString(event.source), 1 /* TEXT */)) : createCommentVNode("v-if", true)])])]);
      }), 128 /* KEYED_FRAGMENT */)), timelineEvents.value.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_11, [...(_cache[1] || (_cache[1] = [createBaseVNode("span", null, "📭", -1 /* CACHED */), createBaseVNode("p", null, "暂无时间轴数据", -1 /* CACHED */)]))])) : createCommentVNode("v-if", true)]))]);
    };
  }
}));
;// CONCATENATED MODULE: ./src/modals/components/TimelinePage.vue?vue&type=script&setup=true&lang=ts
 
;// CONCATENATED MODULE: ./src/modals/components/TimelinePage.vue



const TimelinePage_exports_ = TimelinePagevue_type_script_setup_true_lang_ts;

/* harmony default export */ const TimelinePage = (TimelinePage_exports_);
;// CONCATENATED MODULE: ./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[6].use[0]!./src/modals/components/EntityListPage.vue?vue&type=script&setup=true&lang=ts


const EntityListPagevue_type_script_setup_true_lang_ts_hoisted_1 = {
  class: "entity-list"
};
const EntityListPagevue_type_script_setup_true_lang_ts_hoisted_2 = {
  class: "entity-header"
};
const EntityListPagevue_type_script_setup_true_lang_ts_hoisted_3 = {
  class: "entity-avatar"
};
const EntityListPagevue_type_script_setup_true_lang_ts_hoisted_4 = {
  class: "entity-info"
};
const EntityListPagevue_type_script_setup_true_lang_ts_hoisted_5 = {
  class: "entity-meta"
};
const EntityListPagevue_type_script_setup_true_lang_ts_hoisted_6 = {
  key: 0
};
const EntityListPagevue_type_script_setup_true_lang_ts_hoisted_7 = {
  key: 0,
  class: "filter-controls"
};
const EntityListPagevue_type_script_setup_true_lang_ts_hoisted_8 = {
  key: 0,
  class: "filter-select-wrapper"
};
const EntityListPagevue_type_script_setup_true_lang_ts_hoisted_9 = {
  value: "all"
};
const EntityListPagevue_type_script_setup_true_lang_ts_hoisted_10 = {
  key: 0,
  value: "high_activity"
};
const EntityListPagevue_type_script_setup_true_lang_ts_hoisted_11 = {
  key: 1,
  value: "recent_discussion"
};
const _hoisted_12 = {
  key: 2,
  value: "recent_contact"
};
const _hoisted_13 = {
  key: 3,
  value: "frequent_collaboration"
};
const _hoisted_14 = {
  key: 4,
  value: "highlighted"
};
const _hoisted_15 = {
  key: 5,
  value: "active"
};
const _hoisted_16 = {
  class: "results-count"
};
const _hoisted_17 = {
  key: 0
};
const _hoisted_18 = {
  key: 1,
  class: "loading-container"
};
const _hoisted_19 = {
  key: 2,
  class: "entities-grid"
};
const _hoisted_20 = ["onClick"];
const _hoisted_21 = {
  class: "card-header topic-card-header"
};
const _hoisted_22 = {
  class: "card-title"
};
const _hoisted_23 = {
  class: "card-badge topic-card-badge"
};
const _hoisted_24 = {
  key: 0,
  class: "card-content"
};
const _hoisted_25 = {
  key: 1,
  class: "topic-preview-section"
};
const _hoisted_26 = {
  class: "preview-list"
};
const _hoisted_27 = ["onClick"];
const _hoisted_28 = {
  class: "preview-content"
};
const _hoisted_29 = {
  class: "preview-time"
};
const _hoisted_30 = {
  key: 2,
  class: "topic-preview-section"
};
const _hoisted_31 = {
  class: "preview-list"
};
const _hoisted_32 = ["onClick"];
const _hoisted_33 = {
  class: "preview-content"
};
const _hoisted_34 = {
  key: 3,
  class: "topic-preview-section"
};
const _hoisted_35 = {
  class: "preview-list"
};
const _hoisted_36 = ["onClick"];
const _hoisted_37 = {
  class: "preview-content"
};
const _hoisted_38 = {
  class: "project-status"
};
const _hoisted_39 = {
  class: "entity-footer"
};
const _hoisted_40 = {
  class: "last-accessed"
};
const _hoisted_41 = ["onClick"];
const _hoisted_42 = {
  class: "entity-card-header person-card-header"
};
const _hoisted_43 = {
  class: "entity-card-title"
};
const _hoisted_44 = {
  class: "person-card-badge"
};
const _hoisted_45 = {
  key: 0,
  class: "entity-description"
};
const _hoisted_46 = {
  key: 1,
  class: "person-preview-section"
};
const _hoisted_47 = {
  class: "preview-list"
};
const _hoisted_48 = ["onClick"];
const _hoisted_49 = {
  class: "preview-content"
};
const _hoisted_50 = {
  class: "preview-time"
};
const _hoisted_51 = {
  key: 2,
  class: "person-preview-section"
};
const _hoisted_52 = {
  class: "expertise-tags"
};
const _hoisted_53 = {
  key: 3,
  class: "person-preview-section"
};
const _hoisted_54 = {
  class: "preview-list"
};
const _hoisted_55 = ["onClick"];
const _hoisted_56 = {
  class: "preview-content"
};
const _hoisted_57 = {
  class: "preview-time"
};
const _hoisted_58 = {
  class: "entity-footer"
};
const _hoisted_59 = {
  class: "last-accessed"
};
const _hoisted_60 = {
  key: 0,
  class: "team-indicator"
};
const _hoisted_61 = ["onClick"];
const _hoisted_62 = {
  class: "entity-card-header"
};
const _hoisted_63 = {
  class: "entity-card-title"
};
const _hoisted_64 = {
  key: 0,
  class: "importance-indicator"
};
const _hoisted_65 = {
  key: 0,
  class: "entity-description"
};
const _hoisted_66 = {
  class: "entity-stats"
};
const _hoisted_67 = {
  class: "stat-item"
};
const _hoisted_68 = {
  class: "stat-item"
};
const _hoisted_69 = {
  class: "stat-item"
};
const _hoisted_70 = {
  class: "stat-item"
};
const _hoisted_71 = {
  class: "project-actions"
};
const _hoisted_72 = ["onClick"];
const _hoisted_73 = ["onClick"];
const _hoisted_74 = {
  key: 1,
  class: "entity-tags"
};
const _hoisted_75 = {
  key: 0,
  class: "entity-tag more-tags"
};
const _hoisted_76 = {
  class: "entity-footer"
};
const _hoisted_77 = {
  class: "last-accessed"
};
const _hoisted_78 = ["onClick"];
const _hoisted_79 = {
  class: "entity-card-header"
};
const _hoisted_80 = {
  class: "entity-card-title"
};
const _hoisted_81 = {
  key: 0,
  class: "importance-indicator"
};
const _hoisted_82 = {
  key: 0,
  class: "entity-description"
};
const _hoisted_83 = {
  class: "entity-stats"
};
const _hoisted_84 = {
  class: "stat-item"
};
const _hoisted_85 = {
  class: "stat-item"
};
const _hoisted_86 = {
  class: "stat-item"
};
const _hoisted_87 = {
  class: "stat-item"
};
const _hoisted_88 = {
  key: 1,
  class: "entity-tags"
};
const _hoisted_89 = {
  key: 0,
  class: "entity-tag more-tags"
};
const _hoisted_90 = {
  class: "entity-footer"
};
const _hoisted_91 = {
  class: "last-accessed"
};
const _hoisted_92 = {
  key: 4,
  class: "empty-state"
};
const _hoisted_93 = {
  key: 0
};
const _hoisted_94 = {
  key: 1
};



/* harmony default export */ const EntityListPagevue_type_script_setup_true_lang_ts = (/*@__PURE__*/runtime_core_esm_bundler_defineComponent({
  __name: 'EntityListPage',
  setup(__props) {
    const route = useRoute();
    const router = useRouter();
    const store = useMemoryStore();
    const entityType = runtime_core_esm_bundler_computed(() => route.params.type);
    const entities = runtime_core_esm_bundler_computed(() => store.entities);
    const isLoading = runtime_core_esm_bundler_computed(() => store.isLoading);
    const searchQuery = runtime_core_esm_bundler_computed(() => store.searchQuery);

    // 本地过滤状态
    const selectedFilter = reactivity_esm_bundler_ref('all');

    // 过滤后的实体列表
    const filteredEntities = runtime_core_esm_bundler_computed(() => {
      let filtered = [...entities.value];

      // 文本搜索过滤（使用顶部搜索框的搜索词）
      if (searchQuery.value.trim()) {
        const query = searchQuery.value.toLowerCase();
        filtered = filtered.filter(entity => entity.name.toLowerCase().includes(query) || entity.description && entity.description.toLowerCase().includes(query) || entity.tags && entity.tags.some(tag => tag.toLowerCase().includes(query)));
      }

      // 分类过滤
      if (selectedFilter.value !== 'all') {
        switch (selectedFilter.value) {
          case 'high_activity':
            // Topic: 高活跃度（讨论数多或最近更新）
            filtered = filtered.filter(entity => entity.discussionsCount > 5 || entity.updated && Date.now() - entity.updated < 86400000 // 24小时内
            );
            break;
          case 'recent_discussion':
            // Topic: 最近讨论
            filtered = filtered.filter(entity => entity.latestDiscussions && entity.latestDiscussions.length > 0);
            break;
          case 'recent_contact':
            // Person: 最近联系
            filtered = filtered.filter(entity => entity.lastContact && Date.now() - entity.lastContact < 604800000 // 7天内
            );
            break;
          case 'frequent_collaboration':
            // Person: 频繁协作
            filtered = filtered.filter(entity => entity.recentCollaborations && entity.recentCollaborations.length >= 2);
            break;
          case 'highlighted':
            // Project: 重点项目
            filtered = filtered.filter(entity => entity.isHighlighted);
            break;
          case 'active':
            // Project: 活跃项目
            filtered = filtered.filter(entity => entity.status === 'active' && entity.lastAccessed && Date.now() - entity.lastAccessed < 604800000 // 7天内
            );
            break;
        }
      }
      return filtered;
    });
    const getEntityIcon = type => {
      return ENTITY_TYPE_CONFIG[type]?.icon || '📂';
    };
    const getEntityTypeName = type => {
      return ENTITY_TYPE_CONFIG[type]?.name || type;
    };
    const handleEntityClick = entity => {
      if (entity.type === 'Topic') {
        router.push(`/topic/${entity.id}`);
      } else if (entity.type === 'Person') {
        router.push(`/person/${entity.id}`);
      } else {
        console.log('点击实体:', entity);
      }
    };
    const handlePersonClick = entity => {
      router.push(`/person/${entity.id}`);
    };
    const navigateToPersonMessage = (personId, messageId) => {
      router.push(`/person/${personId}?messageId=${messageId}`);
    };
    const navigateToTopicDiscussion = (topicId, messageId) => {
      router.push(`/topic/${topicId}?messageId=${messageId}`);
    };
    const openResource = resource => {
      if (resource.url && resource.url !== '#') {
        window.open(resource.url, '_blank');
      } else {
        console.log('打开资源:', resource);
      }
    };
    const navigateToProject = projectId => {
      router.push(`/project/${projectId}`);
    };
    const handleMarkAsHighlightProject = async entity => {
      try {
        // 通过Chrome API获取现有的重点项目列表
        const response = await chromeAPI.sendMessage({
          type: 'GET_HIGHLIGHT_PROJECTS'
        });
        const highlightProjects = response?.data || [];
        const isAlreadyHighlighted = highlightProjects.some(p => p.id === entity.id);
        if (isAlreadyHighlighted) {
          // 移除重点标记
          await chromeAPI.sendMessage({
            type: 'REMOVE_HIGHLIGHT_PROJECT',
            projectId: entity.id
          });
          entity.isHighlighted = false;
          console.log(`已移除重点项目标记: ${entity.name}`);
        } else {
          // 添加重点标记
          await chromeAPI.sendMessage({
            type: 'ADD_HIGHLIGHT_PROJECT',
            project: {
              id: entity.id,
              name: entity.name,
              type: entity.type,
              description: entity.description,
              addedAt: Date.now()
            }
          });
          entity.isHighlighted = true;
          console.log(`已标记为重点项目: ${entity.name}`);
        }
      } catch (error) {
        console.error('标记重点项目失败:', error);
        alert('操作失败，请稍后重试');
      }
    };
    const openProjectDashboard = async entity => {
      try {
        // 先确保项目在重点项目列表中
        const response = await chromeAPI.sendMessage({
          type: 'GET_HIGHLIGHT_PROJECTS'
        });
        const highlightProjects = response?.data || [];
        const isHighlighted = highlightProjects.some(p => p.id === entity.id);
        if (!isHighlighted) {
          // 如果不在重点项目中，询问是否添加
          const shouldAdd = confirm(`"${entity.name}" 不在重点项目列表中，是否添加并打开仪表盘？`);
          if (shouldAdd) {
            await handleMarkAsHighlightProject(entity);
          }
        }

        // 通过Chrome API打开项目仪表盘
        await chromeAPI.sendMessage({
          type: 'OPEN_PROJECT_DASHBOARD',
          projectId: entity.id,
          projectName: entity.name
        });
      } catch (error) {
        console.error('打开项目仪表盘失败:', error);
        alert('打开项目仪表盘失败，请稍后重试');
      }
    };
    const formatTime = timestamp => {
      const now = Date.now();
      const diff = now - timestamp;
      const hours = Math.floor(diff / 3600000);
      const days = Math.floor(diff / 86400000);
      if (hours < 24) return `${hours}小时前`;
      if (days < 30) return `${days}天前`;
      return new Date(timestamp).toLocaleDateString();
    };
    runtime_core_esm_bundler_watch(entityType, newType => {
      if (newType) {
        store.loadEntitiesByType(newType);
      }
    }, {
      immediate: true
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", EntityListPagevue_type_script_setup_true_lang_ts_hoisted_1, [createBaseVNode("div", EntityListPagevue_type_script_setup_true_lang_ts_hoisted_2, [createBaseVNode("div", EntityListPagevue_type_script_setup_true_lang_ts_hoisted_3, toDisplayString(getEntityIcon(entityType.value)), 1 /* TEXT */), createBaseVNode("div", EntityListPagevue_type_script_setup_true_lang_ts_hoisted_4, [createBaseVNode("h2", null, toDisplayString(getEntityTypeName(entityType.value)), 1 /* TEXT */), createBaseVNode("div", EntityListPagevue_type_script_setup_true_lang_ts_hoisted_5, [createTextVNode(" 共 " + toDisplayString(entities.value.length) + " 个" + toDisplayString(getEntityTypeName(entityType.value)) + " ", 1 /* TEXT */), searchQuery.value ? (openBlock(), createElementBlock("span", EntityListPagevue_type_script_setup_true_lang_ts_hoisted_6, " • 搜索: \"" + toDisplayString(searchQuery.value) + "\"", 1 /* TEXT */)) : createCommentVNode("v-if", true)])])]), createCommentVNode(" 过滤控件 "), !isLoading.value && entities.value.length > 0 ? (openBlock(), createElementBlock("div", EntityListPagevue_type_script_setup_true_lang_ts_hoisted_7, [entityType.value === 'Topic' || entityType.value === 'Person' || entityType.value === 'Project' ? (openBlock(), createElementBlock("div", EntityListPagevue_type_script_setup_true_lang_ts_hoisted_8, [withDirectives(createBaseVNode("select", {
        class: "filter-select",
        "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => selectedFilter.value = $event)
      }, [createBaseVNode("option", EntityListPagevue_type_script_setup_true_lang_ts_hoisted_9, "全部" + toDisplayString(getEntityTypeName(entityType.value)), 1 /* TEXT */), entityType.value === 'Topic' ? (openBlock(), createElementBlock("option", EntityListPagevue_type_script_setup_true_lang_ts_hoisted_10, "高活跃度")) : createCommentVNode("v-if", true), entityType.value === 'Topic' ? (openBlock(), createElementBlock("option", EntityListPagevue_type_script_setup_true_lang_ts_hoisted_11, "最近讨论")) : createCommentVNode("v-if", true), entityType.value === 'Person' ? (openBlock(), createElementBlock("option", _hoisted_12, "最近联系")) : createCommentVNode("v-if", true), entityType.value === 'Person' ? (openBlock(), createElementBlock("option", _hoisted_13, "频繁协作")) : createCommentVNode("v-if", true), entityType.value === 'Project' ? (openBlock(), createElementBlock("option", _hoisted_14, "重点项目")) : createCommentVNode("v-if", true), entityType.value === 'Project' ? (openBlock(), createElementBlock("option", _hoisted_15, "活跃项目")) : createCommentVNode("v-if", true)], 512 /* NEED_PATCH */), [[vModelSelect, selectedFilter.value]])])) : createCommentVNode("v-if", true), createBaseVNode("div", _hoisted_16, [searchQuery.value ? (openBlock(), createElementBlock("span", _hoisted_17, "搜索结果：")) : createCommentVNode("v-if", true), createTextVNode(" 显示 " + toDisplayString(filteredEntities.value.length) + " / " + toDisplayString(entities.value.length) + " 项 ", 1 /* TEXT */)])])) : createCommentVNode("v-if", true), isLoading.value ? (openBlock(), createElementBlock("div", _hoisted_18, [...(_cache[1] || (_cache[1] = [createBaseVNode("div", {
        class: "loading-spinner"
      }, null, -1 /* CACHED */), createBaseVNode("span", null, "加载实体数据...", -1 /* CACHED */)]))])) : (openBlock(), createElementBlock("div", _hoisted_19, [createCommentVNode(" Topic类型实体卡片 - 带预览 "), entityType.value === 'Topic' ? (openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, {
        key: 0
      }, renderList(filteredEntities.value, entity => {
        return openBlock(), createElementBlock("div", {
          key: entity.id,
          class: "content-card topic-card",
          onClick: $event => handleEntityClick(entity)
        }, [createBaseVNode("div", _hoisted_21, [createBaseVNode("div", _hoisted_22, [_cache[2] || (_cache[2] = createBaseVNode("span", null, "💡", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(entity.name), 1 /* TEXT */)]), createBaseVNode("div", _hoisted_23, toDisplayString(entity.discussionsCount || 0) + " 讨论 ", 1 /* TEXT */)]), entity.description ? (openBlock(), createElementBlock("div", _hoisted_24, toDisplayString(entity.description), 1 /* TEXT */)) : createCommentVNode("v-if", true), createCommentVNode(" 最新讨论预览 "), entity.recentDataDetails?.conversations && entity.recentDataDetails.conversations.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_25, [_cache[4] || (_cache[4] = createBaseVNode("h4", {
          class: "preview-section-title"
        }, "💬 最新讨论", -1 /* CACHED */)), createBaseVNode("ul", _hoisted_26, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(entity.recentDataDetails.conversations.slice(0, 2), discussion => {
          return openBlock(), createElementBlock("li", {
            key: discussion.id,
            class: "preview-item discussion-item",
            onClick: withModifiers($event => navigateToTopicDiscussion(entity.id, discussion.id), ["stop"])
          }, [_cache[3] || (_cache[3] = createBaseVNode("span", null, "💭", -1 /* CACHED */)), createBaseVNode("span", _hoisted_28, toDisplayString(discussion.summary), 1 /* TEXT */), createBaseVNode("span", _hoisted_29, toDisplayString(discussion.datetime), 1 /* TEXT */)], 8 /* PROPS */, _hoisted_27);
        }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true), createCommentVNode(" 相关资源预览 "), entity.recentDataDetails?.resources && entity.recentDataDetails.resources.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_30, [_cache[6] || (_cache[6] = createBaseVNode("h4", {
          class: "preview-section-title"
        }, "📚 相关资源", -1 /* CACHED */)), createBaseVNode("ul", _hoisted_31, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(entity.recentDataDetails.resources.slice(0, 2), resource => {
          return openBlock(), createElementBlock("li", {
            key: resource.id,
            class: "preview-item resource-item",
            onClick: withModifiers($event => openResource(resource), ["stop"])
          }, [_cache[5] || (_cache[5] = createBaseVNode("span", null, "📖", -1 /* CACHED */)), createBaseVNode("span", _hoisted_33, toDisplayString(resource.name), 1 /* TEXT */)], 8 /* PROPS */, _hoisted_32);
        }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true), createCommentVNode(" 关联项目预览 "), entity.recentDataDetails?.projects && entity.recentDataDetails.projects.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_34, [_cache[8] || (_cache[8] = createBaseVNode("h4", {
          class: "preview-section-title"
        }, "🚀 关联项目", -1 /* CACHED */)), createBaseVNode("ul", _hoisted_35, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(entity.recentDataDetails.projects.slice(0, 2), project => {
          return openBlock(), createElementBlock("li", {
            key: project.id,
            class: "preview-item project-item",
            onClick: withModifiers($event => navigateToProject(project.id), ["stop"])
          }, [_cache[7] || (_cache[7] = createBaseVNode("span", null, "🚀", -1 /* CACHED */)), createBaseVNode("span", _hoisted_37, toDisplayString(project.name), 1 /* TEXT */), createBaseVNode("span", _hoisted_38, toDisplayString(project.status), 1 /* TEXT */)], 8 /* PROPS */, _hoisted_36);
        }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true), createBaseVNode("div", _hoisted_39, [createBaseVNode("span", _hoisted_40, " 最后更新: " + toDisplayString(formatTime(entity.updated || Date.now())), 1 /* TEXT */)])], 8 /* PROPS */, _hoisted_20);
      }), 128 /* KEYED_FRAGMENT */)) : entityType.value === 'Person' ? (openBlock(), createElementBlock(runtime_core_esm_bundler_Fragment, {
        key: 1
      }, [createCommentVNode(" Person类型实体卡片 - 带人物预览 "), (openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(filteredEntities.value, entity => {
        return openBlock(), createElementBlock("div", {
          key: entity.id,
          class: "entity-card person-card",
          onClick: $event => handlePersonClick(entity)
        }, [createBaseVNode("div", _hoisted_42, [createBaseVNode("div", _hoisted_43, [_cache[9] || (_cache[9] = createBaseVNode("span", null, "👤", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(entity.name), 1 /* TEXT */)]), createBaseVNode("div", _hoisted_44, toDisplayString(entity.role || '团队成员'), 1 /* TEXT */)]), entity.description ? (openBlock(), createElementBlock("div", _hoisted_45, toDisplayString(entity.description), 1 /* TEXT */)) : createCommentVNode("v-if", true), createCommentVNode(" 最近协作预览 "), entity.recentCollaborations && entity.recentCollaborations.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_46, [_cache[11] || (_cache[11] = createBaseVNode("h4", {
          class: "preview-section-title"
        }, "🤝 最近协作", -1 /* CACHED */)), createBaseVNode("ul", _hoisted_47, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(entity.recentCollaborations.slice(0, 2), collaboration => {
          return openBlock(), createElementBlock("li", {
            key: collaboration.id,
            class: "preview-item collaboration-item",
            onClick: withModifiers($event => navigateToProject(collaboration.projectId), ["stop"])
          }, [_cache[10] || (_cache[10] = createBaseVNode("span", null, "🚀", -1 /* CACHED */)), createBaseVNode("span", _hoisted_49, toDisplayString(collaboration.projectName), 1 /* TEXT */), createBaseVNode("span", _hoisted_50, toDisplayString(collaboration.time), 1 /* TEXT */)], 8 /* PROPS */, _hoisted_48);
        }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true), createCommentVNode(" 专业技能预览 "), entity.expertise && entity.expertise.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_51, [_cache[12] || (_cache[12] = createBaseVNode("h4", {
          class: "preview-section-title"
        }, "🎯 专业技能", -1 /* CACHED */)), createBaseVNode("div", _hoisted_52, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(entity.expertise.slice(0, 4), skill => {
          return openBlock(), createElementBlock("span", {
            key: skill,
            class: "expertise-tag"
          }, toDisplayString(skill), 1 /* TEXT */);
        }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true), createCommentVNode(" 最近消息预览 "), entity.recentMessages && entity.recentMessages.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_53, [_cache[14] || (_cache[14] = createBaseVNode("h4", {
          class: "preview-section-title"
        }, "💬 最近消息", -1 /* CACHED */)), createBaseVNode("ul", _hoisted_54, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(entity.recentMessages.slice(0, 2), message => {
          return openBlock(), createElementBlock("li", {
            key: message.id,
            class: "preview-item message-item",
            onClick: withModifiers($event => navigateToPersonMessage(entity.id, message.id), ["stop"])
          }, [_cache[13] || (_cache[13] = createBaseVNode("span", null, "💭", -1 /* CACHED */)), createBaseVNode("span", _hoisted_56, toDisplayString(message.summary), 1 /* TEXT */), createBaseVNode("span", _hoisted_57, toDisplayString(message.time), 1 /* TEXT */)], 8 /* PROPS */, _hoisted_55);
        }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true), createBaseVNode("div", _hoisted_58, [createBaseVNode("span", _hoisted_59, " 最后联系: " + toDisplayString(formatTime(entity.lastContact || Date.now())), 1 /* TEXT */), entity.team ? (openBlock(), createElementBlock("span", _hoisted_60, toDisplayString(entity.team), 1 /* TEXT */)) : createCommentVNode("v-if", true)])], 8 /* PROPS */, _hoisted_41);
      }), 128 /* KEYED_FRAGMENT */))], 64 /* STABLE_FRAGMENT */)) : entityType.value === 'Project' ? (openBlock(), createElementBlock(runtime_core_esm_bundler_Fragment, {
        key: 2
      }, [createCommentVNode(" Project类型实体卡片 - 带项目操作 "), (openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(filteredEntities.value, entity => {
        return openBlock(), createElementBlock("div", {
          key: entity.id,
          class: "entity-card project-card",
          onClick: $event => handleEntityClick(entity)
        }, [createBaseVNode("div", _hoisted_62, [createBaseVNode("div", _hoisted_63, [_cache[15] || (_cache[15] = createBaseVNode("span", null, "🚀", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(entity.name), 1 /* TEXT */)]), entity.importance !== undefined ? (openBlock(), createElementBlock("div", _hoisted_64, [createBaseVNode("div", {
          class: "importance-bar",
          style: shared_esm_bundler_normalizeStyle({
            width: entity.importance * 100 + '%'
          })
        }, null, 4 /* STYLE */)])) : createCommentVNode("v-if", true)]), entity.description ? (openBlock(), createElementBlock("div", _hoisted_65, toDisplayString(entity.description), 1 /* TEXT */)) : createCommentVNode("v-if", true), createBaseVNode("div", _hoisted_66, [createBaseVNode("div", _hoisted_67, [_cache[16] || (_cache[16] = createBaseVNode("span", null, "🔗", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(entity.relationshipsCount || 0) + " 关系", 1 /* TEXT */)]), createBaseVNode("div", _hoisted_68, [_cache[17] || (_cache[17] = createBaseVNode("span", null, "💬", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(entity.relatedMessagesCount || 0) + " 消息", 1 /* TEXT */)]), createBaseVNode("div", _hoisted_69, [_cache[18] || (_cache[18] = createBaseVNode("span", null, "🌐", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(entity.relatedWebpagesCount || 0) + " 网页", 1 /* TEXT */)]), createBaseVNode("div", _hoisted_70, [_cache[19] || (_cache[19] = createBaseVNode("span", null, "👁️", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(entity.accessCount || 0) + " 访问", 1 /* TEXT */)])]), createCommentVNode(" 项目特有操作按钮 "), createBaseVNode("div", _hoisted_71, [createBaseVNode("button", {
          class: shared_esm_bundler_normalizeClass(["project-action-btn highlight", {
            active: entity.isHighlighted
          }]),
          onClick: withModifiers($event => handleMarkAsHighlightProject(entity), ["stop"]),
          title: "标记为重点项目"
        }, " ⭐ " + toDisplayString(entity.isHighlighted ? '已标记' : '重点项目'), 11 /* TEXT, CLASS, PROPS */, _hoisted_72), createBaseVNode("button", {
          class: "project-action-btn dashboard",
          onClick: withModifiers($event => openProjectDashboard(entity), ["stop"]),
          title: "打开项目仪表盘"
        }, " 📊 仪表盘 ", 8 /* PROPS */, _hoisted_73)]), entity.tags && entity.tags.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_74, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(entity.tags.slice(0, 3), (tag, index) => {
          return openBlock(), createElementBlock("span", {
            key: index,
            class: "entity-tag"
          }, toDisplayString(tag), 1 /* TEXT */);
        }), 128 /* KEYED_FRAGMENT */)), entity.tags.length > 3 ? (openBlock(), createElementBlock("span", _hoisted_75, " +" + toDisplayString(entity.tags.length - 3), 1 /* TEXT */)) : createCommentVNode("v-if", true)])) : createCommentVNode("v-if", true), createBaseVNode("div", _hoisted_76, [createBaseVNode("span", _hoisted_77, " 最后访问: " + toDisplayString(formatTime(entity.lastAccessed || Date.now())), 1 /* TEXT */), entity.status ? (openBlock(), createElementBlock("span", {
          key: 0,
          class: shared_esm_bundler_normalizeClass('status-indicator ' + entity.status)
        }, toDisplayString(entity.status), 3 /* TEXT, CLASS */)) : createCommentVNode("v-if", true)])], 8 /* PROPS */, _hoisted_61);
      }), 128 /* KEYED_FRAGMENT */))], 64 /* STABLE_FRAGMENT */)) : (openBlock(), createElementBlock(runtime_core_esm_bundler_Fragment, {
        key: 3
      }, [createCommentVNode(" 其他类型实体卡片 - 原始布局 "), (openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(filteredEntities.value, entity => {
        return openBlock(), createElementBlock("div", {
          key: entity.id,
          class: "entity-card",
          onClick: $event => handleEntityClick(entity)
        }, [createBaseVNode("div", _hoisted_79, [createBaseVNode("div", _hoisted_80, [createBaseVNode("span", null, toDisplayString(getEntityIcon(entity.type)), 1 /* TEXT */), createBaseVNode("span", null, toDisplayString(entity.name), 1 /* TEXT */)]), entity.importance !== undefined ? (openBlock(), createElementBlock("div", _hoisted_81, [createBaseVNode("div", {
          class: "importance-bar",
          style: shared_esm_bundler_normalizeStyle({
            width: entity.importance * 100 + '%'
          })
        }, null, 4 /* STYLE */)])) : createCommentVNode("v-if", true)]), entity.description ? (openBlock(), createElementBlock("div", _hoisted_82, toDisplayString(entity.description), 1 /* TEXT */)) : createCommentVNode("v-if", true), createBaseVNode("div", _hoisted_83, [createBaseVNode("div", _hoisted_84, [_cache[20] || (_cache[20] = createBaseVNode("span", null, "🔗", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(entity.relationshipsCount || 0) + " 关系", 1 /* TEXT */)]), createBaseVNode("div", _hoisted_85, [_cache[21] || (_cache[21] = createBaseVNode("span", null, "💬", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(entity.relatedMessagesCount || 0) + " 消息", 1 /* TEXT */)]), createBaseVNode("div", _hoisted_86, [_cache[22] || (_cache[22] = createBaseVNode("span", null, "🌐", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(entity.relatedWebpagesCount || 0) + " 网页", 1 /* TEXT */)]), createBaseVNode("div", _hoisted_87, [_cache[23] || (_cache[23] = createBaseVNode("span", null, "👁️", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(entity.accessCount || 0) + " 访问", 1 /* TEXT */)])]), entity.tags && entity.tags.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_88, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(entity.tags.slice(0, 3), (tag, index) => {
          return openBlock(), createElementBlock("span", {
            key: index,
            class: "entity-tag"
          }, toDisplayString(tag), 1 /* TEXT */);
        }), 128 /* KEYED_FRAGMENT */)), entity.tags.length > 3 ? (openBlock(), createElementBlock("span", _hoisted_89, " +" + toDisplayString(entity.tags.length - 3), 1 /* TEXT */)) : createCommentVNode("v-if", true)])) : createCommentVNode("v-if", true), createBaseVNode("div", _hoisted_90, [createBaseVNode("span", _hoisted_91, " 最后访问: " + toDisplayString(formatTime(entity.lastAccessed || Date.now())), 1 /* TEXT */), entity.status ? (openBlock(), createElementBlock("span", {
          key: 0,
          class: shared_esm_bundler_normalizeClass('status-indicator ' + entity.status)
        }, toDisplayString(entity.status), 3 /* TEXT, CLASS */)) : createCommentVNode("v-if", true)])], 8 /* PROPS */, _hoisted_78);
      }), 128 /* KEYED_FRAGMENT */))], 64 /* STABLE_FRAGMENT */)), filteredEntities.value.length === 0 && !isLoading.value ? (openBlock(), createElementBlock("div", _hoisted_92, [createBaseVNode("span", null, toDisplayString(getEntityIcon(entityType.value)), 1 /* TEXT */), entities.value.length === 0 ? (openBlock(), createElementBlock("p", _hoisted_93, "暂无" + toDisplayString(getEntityTypeName(entityType.value)) + "数据", 1 /* TEXT */)) : (openBlock(), createElementBlock("p", _hoisted_94, "没有找到匹配的" + toDisplayString(getEntityTypeName(entityType.value)), 1 /* TEXT */))])) : createCommentVNode("v-if", true)]))]);
    };
  }
}));
;// CONCATENATED MODULE: ./src/modals/components/EntityListPage.vue?vue&type=script&setup=true&lang=ts
 
;// CONCATENATED MODULE: ./src/modals/components/EntityListPage.vue



const EntityListPage_exports_ = EntityListPagevue_type_script_setup_true_lang_ts;

/* harmony default export */ const EntityListPage = (EntityListPage_exports_);
;// CONCATENATED MODULE: ./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[6].use[0]!./src/modals/components/TopicDetailPage.vue?vue&type=script&setup=true&lang=ts


const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_1 = {
  class: "topic-detail"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_2 = {
  class: "detail-header"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_3 = {
  key: 0,
  class: "topic-header"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_4 = {
  class: "topic-info"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_5 = {
  class: "topic-meta"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_6 = {
  class: "meta-item"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_7 = {
  class: "meta-item"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_8 = {
  class: "meta-item"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_9 = {
  class: "meta-item"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_10 = {
  key: 0,
  class: "loading-container"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_11 = {
  key: 1,
  class: "topic-detail-content"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_12 = {
  class: "tab-navigation"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_13 = ["onClick"];
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_14 = {
  key: 0,
  class: "tab-content active"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_15 = {
  class: "items-grid"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_16 = {
  class: "item-header"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_17 = {
  class: "item-title"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_18 = {
  class: "item-content"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_19 = {
  style: {
    "margin-bottom": "0.5rem"
  }
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_20 = {
  class: "card-badge"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_21 = {
  key: 1,
  class: "tab-content active"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_22 = {
  class: "items-grid"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_23 = {
  class: "item-header"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_24 = {
  class: "item-title"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_25 = {
  class: "item-content"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_26 = {
  style: {
    "margin-bottom": "0.5rem"
  }
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_27 = {
  class: "card-badge"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_28 = ["href"];
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_29 = {
  key: 2,
  class: "tab-content active"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_30 = {
  class: "items-grid"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_31 = {
  class: "item-header"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_32 = {
  class: "item-title"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_33 = {
  class: "item-content"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_34 = {
  style: {
    "margin-bottom": "0.5rem",
    "font-weight": "600"
  }
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_35 = {
  style: {
    "display": "flex",
    "gap": "0.5rem",
    "margin-bottom": "0.5rem"
  }
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_36 = {
  class: "card-badge"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_37 = {
  style: {
    "font-size": "0.875rem",
    "color": "#94a3b8"
  }
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_38 = {
  key: 3,
  class: "tab-content active"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_39 = {
  class: "section-header"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_40 = {
  class: "search-controls"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_41 = {
  class: "conversations-list"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_42 = {
  class: "conversation-header"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_43 = {
  class: "conversation-meta"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_44 = {
  class: "sender-avatar"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_45 = {
  class: "sender-info"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_46 = {
  class: "sender-name"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_47 = {
  class: "group-name"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_48 = {
  class: "conversation-time"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_49 = ["innerHTML"];
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_50 = ["onClick"];
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_51 = {
  class: "indicator-text"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_52 = {
  class: "context-header"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_53 = {
  class: "context-sender"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_54 = {
  class: "context-time"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_55 = ["innerHTML"];
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_56 = {
  key: 4,
  class: "tab-content active"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_57 = {
  class: "section-header"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_58 = {
  class: "search-controls"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_59 = {
  class: "webpages-list"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_60 = {
  class: "webpage-header"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_61 = {
  class: "webpage-icon"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_62 = {
  class: "webpage-info"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_63 = {
  class: "webpage-title"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_64 = {
  class: "webpage-url"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_65 = {
  class: "webpage-meta"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_66 = {
  key: 0
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_67 = {
  class: "webpage-content"
};
const TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_68 = {
  key: 0,
  class: "webpage-tags"
};



/* harmony default export */ const TopicDetailPagevue_type_script_setup_true_lang_ts = (/*@__PURE__*/runtime_core_esm_bundler_defineComponent({
  __name: 'TopicDetailPage',
  setup(__props) {
    const route = useRoute();
    const router = useRouter();
    const store = useMemoryStore();
    const topicId = runtime_core_esm_bundler_computed(() => route.params.id);
    const topicData = runtime_core_esm_bundler_computed(() => store.topicDetailData);
    const isLoading = runtime_core_esm_bundler_computed(() => store.isLoading);
    const activeTab = reactivity_esm_bundler_ref('conversations');
    const convSearchQuery = reactivity_esm_bundler_ref('');
    const convFilter = reactivity_esm_bundler_ref('all');
    const webSearchQuery = reactivity_esm_bundler_ref('');
    const webTypeFilter = reactivity_esm_bundler_ref('all');
    const expandedConversations = reactivity_esm_bundler_ref(new Set());
    const tabs = [{
      key: 'projects',
      label: '🚀 相关项目'
    }, {
      key: 'resources',
      label: '📚 相关资源'
    }, {
      key: 'tickets',
      label: '🎯 相关Tickets'
    }, {
      key: 'conversations',
      label: '💬 聊天记录'
    }, {
      key: 'webpages',
      label: '🌐 网页记录'
    }];
    const filteredConversations = runtime_core_esm_bundler_computed(() => {
      let filtered = topicData.value?.recentDataDetails?.conversations || [];
      if (convSearchQuery.value.trim()) {
        const query = convSearchQuery.value.toLowerCase();
        filtered = filtered.filter(conv => conv.summary.toLowerCase().includes(query) || conv.sender.toLowerCase().includes(query) || conv.group.toLowerCase().includes(query));
      }
      if (convFilter.value !== 'all') {
        filtered = filtered.filter(conv => {
          switch (convFilter.value) {
            case 'team':
              return conv.group.includes('团队') || conv.group.includes('Team');
            case 'project':
              return conv.group.includes('项目') || conv.group.includes('Project');
            case 'tech':
              return conv.group.includes('技术') || conv.group.includes('Tech') || conv.group.includes('开发');
            default:
              return true;
          }
        });
      }
      return filtered;
    });
    const filteredWebpages = runtime_core_esm_bundler_computed(() => {
      let filtered = topicData.value?.recentDataDetails?.webpages || [];
      if (webSearchQuery.value.trim()) {
        const query = webSearchQuery.value.toLowerCase();
        filtered = filtered.filter(webpage => webpage.title.toLowerCase().includes(query) || webpage.summary.toLowerCase().includes(query) || webpage.url.toLowerCase().includes(query));
      }
      if (webTypeFilter.value !== 'all') {
        filtered = filtered.filter(webpage => webpage.type === webTypeFilter.value);
      }
      return filtered;
    });
    const goBack = () => {
      router.push('/entity/Topic');
    };
    const toggleConversationExpand = conversationId => {
      const newExpanded = new Set(expandedConversations.value);
      if (newExpanded.has(conversationId)) {
        newExpanded.delete(conversationId);
      } else {
        newExpanded.clear();
        newExpanded.add(conversationId);
      }
      expandedConversations.value = newExpanded;
    };
    const highlightText = (text, searchQuery) => {
      if (!searchQuery.trim()) return text;
      const regex = new RegExp(`(${searchQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
      return text.replace(regex, '<mark style="background: rgba(251, 191, 36, 0.3); color: #fbbf24; padding: 0.125rem 0.25rem; border-radius: 0.25rem; font-weight: 600;">$1</mark>');
    };
    const getWebpageIcon = type => {
      const icons = {
        jira: '🎯',
        confluence: '📝',
        github: '🐙',
        docs: '📄',
        blog: '📰'
      };
      return icons[type] || '🌐';
    };
    const getPriorityStyle = priority => {
      const styles = {
        '高': {
          background: 'rgba(239, 68, 68, 0.2)',
          color: '#ef4444'
        },
        '中': {
          background: 'rgba(251, 191, 36, 0.2)',
          color: '#f59e0b'
        },
        '低': {
          background: 'rgba(34, 197, 94, 0.2)',
          color: '#22c55e'
        }
      };
      return styles[priority] || styles['中'];
    };

    /**
     * 格式化时间为相对时间
     */
    const formatTimeAgo = timestamp => {
      const now = Date.now();
      const diff = now - timestamp;
      const hours = Math.floor(diff / 3600000);
      const days = Math.floor(diff / 86400000);
      const weeks = Math.floor(diff / 604800000);
      if (hours < 1) return '刚刚';
      if (hours < 24) return `${hours}小时前`;
      if (days < 7) return `${days}天前`;
      if (weeks < 4) return `${weeks}周前`;
      return new Date(timestamp).toLocaleDateString();
    };
    runtime_core_esm_bundler_watch(topicId, newId => {
      if (newId) {
        store.loadTopicDetail(newId);
      }
    }, {
      immediate: true
    });
    runtime_core_esm_bundler_watch(() => route.query, newQuery => {
      if (newQuery.messageId) {
        activeTab.value = 'conversations';
        console.log('定位到消息:', newQuery.messageId);
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_1, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_2, [createBaseVNode("button", {
        class: "back-btn",
        onClick: goBack
      }, [...(_cache[4] || (_cache[4] = [createBaseVNode("span", null, "←", -1 /* CACHED */), createBaseVNode("span", null, "返回主题列表", -1 /* CACHED */)]))]), topicData.value ? (openBlock(), createElementBlock("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_3, [_cache[6] || (_cache[6] = createBaseVNode("div", {
        class: "topic-avatar"
      }, "💡", -1 /* CACHED */)), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_4, [createBaseVNode("h2", null, toDisplayString(topicData.value.name), 1 /* TEXT */), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_5, [createBaseVNode("span", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_6, "📈 " + toDisplayString(topicData.value.statistic?.conversations || 0) + " 条讨论", 1 /* TEXT */), createBaseVNode("span", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_7, "🔗 " + toDisplayString(topicData.value.statistic?.projects || 0) + " 个关联项目", 1 /* TEXT */), createBaseVNode("span", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_8, "👥 " + toDisplayString(topicData.value.statistic?.participants || 0) + " 位参与者", 1 /* TEXT */), createBaseVNode("span", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_9, "📚 " + toDisplayString(topicData.value.statistic?.resources || 0) + " 个资源", 1 /* TEXT */), _cache[5] || (_cache[5] = createBaseVNode("span", {
        class: "meta-item"
      }, "⏰ 最后更新：30 分钟前", -1 /* CACHED */))])]), _cache[7] || (_cache[7] = createBaseVNode("div", {
        class: "topic-actions"
      }, [createBaseVNode("button", {
        class: "action-btn"
      }, "📝 编辑主题"), createBaseVNode("button", {
        class: "action-btn"
      }, "🔗 添加关联")], -1 /* CACHED */))])) : createCommentVNode("v-if", true)]), isLoading.value ? (openBlock(), createElementBlock("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_10, [...(_cache[8] || (_cache[8] = [createBaseVNode("div", {
        class: "loading-spinner"
      }, null, -1 /* CACHED */), createBaseVNode("span", null, "加载主题详情...", -1 /* CACHED */)]))])) : topicData.value ? (openBlock(), createElementBlock("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_11, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_12, [(openBlock(), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(tabs, tab => {
        return createBaseVNode("button", {
          key: tab.key,
          class: shared_esm_bundler_normalizeClass(['tab-btn', {
            active: activeTab.value === tab.key
          }]),
          onClick: $event => activeTab.value = tab.key
        }, toDisplayString(tab.label), 11 /* TEXT, CLASS, PROPS */, TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_13);
      }), 64 /* STABLE_FRAGMENT */))]), createCommentVNode(" 相关项目标签页 "), activeTab.value === 'projects' ? (openBlock(), createElementBlock("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_14, [_cache[11] || (_cache[11] = createBaseVNode("div", {
        class: "section-header"
      }, [createBaseVNode("h3", null, "📂 相关项目"), createBaseVNode("button", {
        class: "add-btn"
      }, "+ 添加项目")], -1 /* CACHED */)), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_15, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(topicData.value.recentDataDetails.projects, project => {
        return openBlock(), createElementBlock("div", {
          key: project.id,
          class: "item-card"
        }, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_16, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_17, [_cache[9] || (_cache[9] = createBaseVNode("span", null, "🚀", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(project.name), 1 /* TEXT */)]), _cache[10] || (_cache[10] = createBaseVNode("div", {
          class: "item-actions"
        }, [createBaseVNode("button", {
          class: "item-action",
          title: "取消关联"
        }, "❌")], -1 /* CACHED */))]), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_18, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_19, [createBaseVNode("span", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_20, toDisplayString(project.status), 1 /* TEXT */)]), createBaseVNode("p", null, toDisplayString(project.description), 1 /* TEXT */)])]);
      }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true), createCommentVNode(" 相关资源标签页 "), activeTab.value === 'resources' ? (openBlock(), createElementBlock("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_21, [_cache[14] || (_cache[14] = createBaseVNode("div", {
        class: "section-header"
      }, [createBaseVNode("h3", null, "📚 相关资源"), createBaseVNode("button", {
        class: "add-btn"
      }, "+ 添加资源")], -1 /* CACHED */)), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_22, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(topicData.value.recentDataDetails.resources, resource => {
        return openBlock(), createElementBlock("div", {
          key: resource.id,
          class: "item-card"
        }, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_23, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_24, [_cache[12] || (_cache[12] = createBaseVNode("span", null, "📚", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(resource.name), 1 /* TEXT */)]), _cache[13] || (_cache[13] = createBaseVNode("div", {
          class: "item-actions"
        }, [createBaseVNode("button", {
          class: "item-action",
          title: "删除资源"
        }, "❌")], -1 /* CACHED */))]), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_25, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_26, [createBaseVNode("span", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_27, toDisplayString(resource.type), 1 /* TEXT */)]), createBaseVNode("p", null, [createBaseVNode("a", {
          href: resource.url,
          style: {
            "color": "#60a5fa"
          }
        }, "查看资源", 8 /* PROPS */, TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_28)])])]);
      }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true), createCommentVNode(" 相关Tickets标签页 "), activeTab.value === 'tickets' ? (openBlock(), createElementBlock("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_29, [_cache[17] || (_cache[17] = createBaseVNode("div", {
        class: "section-header"
      }, [createBaseVNode("h3", null, "🎯 相关Tickets"), createBaseVNode("button", {
        class: "add-btn"
      }, "+ 添加Ticket")], -1 /* CACHED */)), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_30, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(topicData.value.recentDataDetails.jiraTickets, ticket => {
        return openBlock(), createElementBlock("div", {
          key: ticket.id,
          class: "item-card"
        }, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_31, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_32, [_cache[15] || (_cache[15] = createBaseVNode("span", null, "🎯", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(ticket.id), 1 /* TEXT */)]), _cache[16] || (_cache[16] = createBaseVNode("div", {
          class: "item-actions"
        }, [createBaseVNode("button", {
          class: "item-action",
          title: "取消关联"
        }, "❌")], -1 /* CACHED */))]), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_33, [createBaseVNode("h4", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_34, toDisplayString(ticket.title), 1 /* TEXT */), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_35, [createBaseVNode("span", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_36, toDisplayString(ticket.status), 1 /* TEXT */), createBaseVNode("span", {
          class: "card-badge",
          style: shared_esm_bundler_normalizeStyle(getPriorityStyle(ticket.priority))
        }, toDisplayString(ticket.priority), 5 /* TEXT, STYLE */)]), createBaseVNode("p", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_37, "负责人：" + toDisplayString(ticket.assignee), 1 /* TEXT */)])]);
      }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true), createCommentVNode(" 聊天记录标签页 "), activeTab.value === 'conversations' ? (openBlock(), createElementBlock("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_38, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_39, [_cache[19] || (_cache[19] = createBaseVNode("h3", null, "💬 聊天记录", -1 /* CACHED */)), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_40, [withDirectives(createBaseVNode("input", {
        type: "text",
        class: "search-input",
        placeholder: "搜索聊天记录...",
        "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => convSearchQuery.value = $event)
      }, null, 512 /* NEED_PATCH */), [[vModelText, convSearchQuery.value]]), withDirectives(createBaseVNode("select", {
        class: "filter-select",
        "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => convFilter.value = $event)
      }, [...(_cache[18] || (_cache[18] = [createBaseVNode("option", {
        value: "all"
      }, "全部群组", -1 /* CACHED */), createBaseVNode("option", {
        value: "team"
      }, "团队群", -1 /* CACHED */), createBaseVNode("option", {
        value: "project"
      }, "项目群", -1 /* CACHED */), createBaseVNode("option", {
        value: "tech"
      }, "技术讨论", -1 /* CACHED */)]))], 512 /* NEED_PATCH */), [[vModelSelect, convFilter.value]])])]), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_41, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(filteredConversations.value, conv => {
        return openBlock(), createElementBlock("div", {
          key: conv.id,
          class: shared_esm_bundler_normalizeClass(["conversation-item", {
            expanded: expandedConversations.value.has(conv.id)
          }])
        }, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_42, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_43, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_44, toDisplayString((conv.sender || '?').charAt(0)), 1 /* TEXT */), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_45, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_46, toDisplayString(conv.sender || '未知用户'), 1 /* TEXT */), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_47, toDisplayString(conv.group || '未知群组'), 1 /* TEXT */)])]), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_48, toDisplayString(formatTimeAgo(conv.datetime) || '未知时间'), 1 /* TEXT */)]), createBaseVNode("div", {
          class: "conversation-summary",
          innerHTML: highlightText(conv.summary || '暂无摘要', convSearchQuery.value)
        }, null, 8 /* PROPS */, TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_49), createBaseVNode("div", {
          class: shared_esm_bundler_normalizeClass(["context-indicator", {
            expanded: expandedConversations.value.has(conv.id)
          }]),
          onClick: $event => toggleConversationExpand(conv.id)
        }, [createBaseVNode("span", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_51, toDisplayString(expandedConversations.value.has(conv.id) ? '🔼 收起上下文' : `🔍 查看上下文 (${conv.context?.length || 0} 条相关消息)`), 1 /* TEXT */)], 10 /* CLASS, PROPS */, TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_50), conv.context ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: shared_esm_bundler_normalizeClass(["context-content", {
            expanded: expandedConversations.value.has(conv.id)
          }])
        }, [_cache[20] || (_cache[20] = createBaseVNode("div", {
          class: "context-divider"
        }, null, -1 /* CACHED */)), (openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(conv.context, (contextMsg, index) => {
          return openBlock(), createElementBlock("div", {
            key: index,
            class: shared_esm_bundler_normalizeClass(["context-item", {
              'main-message': contextMsg.isMainMessage
            }])
          }, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_52, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_53, toDisplayString(contextMsg.sender || '未知用户'), 1 /* TEXT */), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_54, toDisplayString(contextMsg.time || '未知时间'), 1 /* TEXT */)]), createBaseVNode("div", {
            class: "context-content-text",
            innerHTML: contextMsg.isMainMessage ? highlightText(contextMsg.content || '', convSearchQuery.value) : contextMsg.content || '内容为空'
          }, null, 8 /* PROPS */, TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_55)], 2 /* CLASS */);
        }), 128 /* KEYED_FRAGMENT */))], 2 /* CLASS */)) : createCommentVNode("v-if", true)], 2 /* CLASS */);
      }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true), createCommentVNode(" 网页记录标签页 "), activeTab.value === 'webpages' ? (openBlock(), createElementBlock("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_56, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_57, [_cache[22] || (_cache[22] = createBaseVNode("h3", null, "🌐 网页记录", -1 /* CACHED */)), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_58, [withDirectives(createBaseVNode("input", {
        type: "text",
        class: "search-input",
        placeholder: "搜索网页记录...",
        "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => webSearchQuery.value = $event)
      }, null, 512 /* NEED_PATCH */), [[vModelText, webSearchQuery.value]]), withDirectives(createBaseVNode("select", {
        class: "filter-select",
        "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => webTypeFilter.value = $event)
      }, [...(_cache[21] || (_cache[21] = [createStaticVNode("<option value=\"all\">全部类型</option><option value=\"jira\">Jira</option><option value=\"confluence\">Confluence</option><option value=\"github\">GitHub</option><option value=\"docs\">文档</option><option value=\"blog\">博客</option>", 6)]))], 512 /* NEED_PATCH */), [[vModelSelect, webTypeFilter.value]])])]), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_59, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(filteredWebpages.value, webpage => {
        return openBlock(), createElementBlock("div", {
          key: webpage.id,
          class: "webpage-item"
        }, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_60, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_61, toDisplayString(getWebpageIcon(webpage.type)), 1 /* TEXT */), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_62, [createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_63, toDisplayString(webpage.title || '未知标题'), 1 /* TEXT */), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_64, toDisplayString(webpage.url || '#'), 1 /* TEXT */), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_65, [createBaseVNode("span", null, "访问时间：" + toDisplayString(webpage.visitTime || '未知时间'), 1 /* TEXT */), webpage.relevanceScore ? (openBlock(), createElementBlock("span", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_66, "相关性：" + toDisplayString((webpage.relevanceScore * 100).toFixed(0)) + "%", 1 /* TEXT */)) : createCommentVNode("v-if", true)])])]), createBaseVNode("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_67, toDisplayString(webpage.summary || '暂无摘要'), 1 /* TEXT */), webpage.tags ? (openBlock(), createElementBlock("div", TopicDetailPagevue_type_script_setup_true_lang_ts_hoisted_68, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(webpage.tags, tag => {
          return openBlock(), createElementBlock("span", {
            key: tag,
            class: "webpage-tag"
          }, toDisplayString(tag), 1 /* TEXT */);
        }), 128 /* KEYED_FRAGMENT */))])) : createCommentVNode("v-if", true)]);
      }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true)])) : createCommentVNode("v-if", true)]);
    };
  }
}));
;// CONCATENATED MODULE: ./src/modals/components/TopicDetailPage.vue?vue&type=script&setup=true&lang=ts
 
;// CONCATENATED MODULE: ./src/modals/components/TopicDetailPage.vue



const TopicDetailPage_exports_ = TopicDetailPagevue_type_script_setup_true_lang_ts;

/* harmony default export */ const TopicDetailPage = (TopicDetailPage_exports_);
;// CONCATENATED MODULE: ./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[6].use[0]!./src/modals/components/UserProfilePage.vue?vue&type=script&setup=true&lang=ts


const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_1 = {
  class: "user-profile-section"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_2 = {
  key: 0,
  class: "loading-container"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_3 = {
  key: 1,
  class: "profile-content"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_4 = {
  class: "profile-card"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_5 = {
  class: "interest-grid"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_6 = {
  class: "interest-category"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_7 = {
  class: "interest-list"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_8 = {
  class: "interest-category"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_9 = {
  class: "interest-list"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_10 = {
  class: "interest-category"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_11 = {
  class: "interest-list"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_12 = {
  class: "profile-card"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_13 = {
  class: "insights-grid"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_14 = {
  class: "insight-item"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_15 = {
  class: "insight-item"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_16 = {
  class: "insight-item"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_17 = {
  class: "tag-list"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_18 = {
  class: "profile-card"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_19 = {
  class: "suggestions-list"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_20 = {
  key: 0,
  class: "profile-card"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_21 = {
  class: "predictions-list"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_22 = {
  class: "prediction-header"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_23 = {
  class: "prediction-type"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_24 = {
  class: "prediction-confidence"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_25 = {
  class: "prediction-name"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_26 = {
  class: "prediction-reason"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_27 = {
  class: "profile-card"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_28 = {
  class: "stats-grid"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_29 = {
  class: "stat-card"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_30 = {
  class: "stat-value"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_31 = {
  class: "stat-card"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_32 = {
  class: "stat-value"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_33 = {
  class: "stat-card"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_34 = {
  class: "stat-value"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_35 = {
  class: "stat-card"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_36 = {
  class: "stat-value"
};
const UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_37 = {
  key: 2,
  class: "empty-state"
};



// 类型定义（基于memory.tsx中的接口）

/* harmony default export */ const UserProfilePagevue_type_script_setup_true_lang_ts = (/*@__PURE__*/runtime_core_esm_bundler_defineComponent({
  __name: 'UserProfilePage',
  setup(__props) {
    const isLoading = reactivity_esm_bundler_ref(true);
    const userProfile = reactivity_esm_bundler_ref(null);
    const userProfileAnalysis = reactivity_esm_bundler_ref(null);
    const loadUserProfile = async () => {
      isLoading.value = true;
      try {
        const response = await chromeAPI.sendMessage({
          type: 'GET_USER_PROFILE'
        });
        if (response && response.success) {
          userProfile.value = response.data.profile;
          userProfileAnalysis.value = response.data.analysis;
        } else {
          // 使用模拟数据
          userProfile.value = getMockUserProfile();
          userProfileAnalysis.value = getMockUserProfileAnalysis();
        }
      } catch (error) {
        console.error('加载用户画像失败:', error);
        // 使用模拟数据
        userProfile.value = getMockUserProfile();
        userProfileAnalysis.value = getMockUserProfileAnalysis();
      } finally {
        isLoading.value = false;
      }
    };
    const getMockUserProfile = () => {
      return {
        userId: 'default_user',
        interests: {
          projects: [{
            id: 'personal-ai',
            name: 'Personal-AI',
            weight: 0.9
          }, {
            id: 'data-pipeline',
            name: 'Data Pipeline',
            weight: 0.7
          }],
          people: [{
            id: 'zhangsan',
            name: '张三',
            weight: 0.8
          }, {
            id: 'lisi',
            name: '李四',
            weight: 0.6
          }],
          topics: [{
            id: 'ai-workflow',
            name: 'AI工作流自动化',
            weight: 0.9
          }, {
            id: 'frontend-opt',
            name: '前端性能优化',
            weight: 0.7
          }],
          jiraItems: [],
          technologies: [],
          documents: []
        },
        statistics: {
          totalInteractions: 156,
          averageDailyActivity: 12.3,
          lastActiveTime: Date.now()
        },
        lastUpdated: Date.now()
      };
    };
    const getMockUserProfileAnalysis = () => {
      return {
        topInterests: {
          projects: ['Personal-AI', 'Data Pipeline', 'Web Platform'],
          people: ['张三', '李四', '王五'],
          topics: ['AI工作流自动化', '前端性能优化', '产品设计思维']
        },
        insights: {
          workingPattern: '您倾向于在上午9-11点进行深度思考工作，下午主要处理协作和沟通任务。',
          collaborationStyle: '您是一个积极的团队协作者，经常主动分享技术见解和参与讨论。',
          focusAreas: ['前端开发', 'AI技术', '性能优化', '用户体验'],
          suggestedContent: ['《Clean Architecture》读书笔记复习', 'React 18 新特性深度解析', 'AI驱动的代码审查工具探索', '前端性能监控最佳实践']
        },
        predictedInterests: [{
          type: '技术话题',
          name: 'Web3.0 前端开发',
          confidence: 0.82,
          reason: '基于您对前端技术和新兴技术的关注'
        }, {
          type: '项目协作',
          name: '敏捷开发方法论',
          confidence: 0.75,
          reason: '您经常参与项目讨论和团队协作'
        }],
        lastUpdated: Date.now()
      };
    };
    runtime_core_esm_bundler_onMounted(() => {
      loadUserProfile();
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_1, [_cache[21] || (_cache[21] = createBaseVNode("div", {
        class: "profile-header"
      }, [createBaseVNode("h2", null, "👤 用户画像分析"), createBaseVNode("p", null, "基于您的行为模式和兴趣偏好生成的个性化画像")], -1 /* CACHED */)), isLoading.value ? (openBlock(), createElementBlock("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_2, [...(_cache[0] || (_cache[0] = [createBaseVNode("div", {
        class: "loading-spinner"
      }, null, -1 /* CACHED */), createBaseVNode("span", null, "加载用户画像数据...", -1 /* CACHED */)]))])) : userProfile.value && userProfileAnalysis.value ? (openBlock(), createElementBlock("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_3, [createCommentVNode(" 核心兴趣概览 "), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_4, [_cache[7] || (_cache[7] = createBaseVNode("h3", null, "🎯 当前关注重点", -1 /* CACHED */)), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_5, [createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_6, [_cache[2] || (_cache[2] = createBaseVNode("h4", null, "📁 项目", -1 /* CACHED */)), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_7, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(userProfileAnalysis.value.topInterests.projects, (project, idx) => {
        return openBlock(), createElementBlock("div", {
          key: idx,
          class: "interest-item"
        }, [_cache[1] || (_cache[1] = createBaseVNode("span", {
          class: "interest-icon"
        }, "🚀", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(project), 1 /* TEXT */)]);
      }), 128 /* KEYED_FRAGMENT */))])]), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_8, [_cache[4] || (_cache[4] = createBaseVNode("h4", null, "👥 人员", -1 /* CACHED */)), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_9, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(userProfileAnalysis.value.topInterests.people, (person, idx) => {
        return openBlock(), createElementBlock("div", {
          key: idx,
          class: "interest-item"
        }, [_cache[3] || (_cache[3] = createBaseVNode("span", {
          class: "interest-icon"
        }, "👤", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(person), 1 /* TEXT */)]);
      }), 128 /* KEYED_FRAGMENT */))])]), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_10, [_cache[6] || (_cache[6] = createBaseVNode("h4", null, "💡 主题", -1 /* CACHED */)), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_11, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(userProfileAnalysis.value.topInterests.topics, (topic, idx) => {
        return openBlock(), createElementBlock("div", {
          key: idx,
          class: "interest-item"
        }, [_cache[5] || (_cache[5] = createBaseVNode("span", {
          class: "interest-icon"
        }, "💭", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(topic), 1 /* TEXT */)]);
      }), 128 /* KEYED_FRAGMENT */))])])])]), createCommentVNode(" 行为洞察 "), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_12, [_cache[11] || (_cache[11] = createBaseVNode("h3", null, "🔍 行为洞察", -1 /* CACHED */)), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_13, [createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_14, [_cache[8] || (_cache[8] = createBaseVNode("h4", null, "⏰ 工作模式", -1 /* CACHED */)), createBaseVNode("p", null, toDisplayString(userProfileAnalysis.value.insights.workingPattern), 1 /* TEXT */)]), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_15, [_cache[9] || (_cache[9] = createBaseVNode("h4", null, "🤝 协作风格", -1 /* CACHED */)), createBaseVNode("p", null, toDisplayString(userProfileAnalysis.value.insights.collaborationStyle), 1 /* TEXT */)]), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_16, [_cache[10] || (_cache[10] = createBaseVNode("h4", null, "🎓 专业领域", -1 /* CACHED */)), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_17, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(userProfileAnalysis.value.insights.focusAreas, (area, idx) => {
        return openBlock(), createElementBlock("span", {
          key: idx,
          class: "focus-tag"
        }, toDisplayString(area), 1 /* TEXT */);
      }), 128 /* KEYED_FRAGMENT */))])])])]), createCommentVNode(" 智能推荐 "), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_18, [_cache[13] || (_cache[13] = createBaseVNode("h3", null, "💡 智能推荐", -1 /* CACHED */)), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_19, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(userProfileAnalysis.value.insights.suggestedContent, (suggestion, idx) => {
        return openBlock(), createElementBlock("div", {
          key: idx,
          class: "suggestion-item"
        }, [_cache[12] || (_cache[12] = createBaseVNode("span", {
          class: "suggestion-icon"
        }, "📌", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(suggestion), 1 /* TEXT */)]);
      }), 128 /* KEYED_FRAGMENT */))])]), createCommentVNode(" 预测兴趣 "), userProfileAnalysis.value.predictedInterests.length > 0 ? (openBlock(), createElementBlock("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_20, [_cache[14] || (_cache[14] = createBaseVNode("h3", null, "🔮 预测您可能感兴趣的内容", -1 /* CACHED */)), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_21, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(userProfileAnalysis.value.predictedInterests, (prediction, idx) => {
        return openBlock(), createElementBlock("div", {
          key: idx,
          class: "prediction-item"
        }, [createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_22, [createBaseVNode("span", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_23, toDisplayString(prediction.type), 1 /* TEXT */), createBaseVNode("span", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_24, " 置信度: " + toDisplayString(Math.round(prediction.confidence * 100)) + "% ", 1 /* TEXT */)]), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_25, toDisplayString(prediction.name), 1 /* TEXT */), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_26, toDisplayString(prediction.reason), 1 /* TEXT */)]);
      }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true), createCommentVNode(" 统计数据 "), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_27, [_cache[19] || (_cache[19] = createBaseVNode("h3", null, "📊 活动统计", -1 /* CACHED */)), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_28, [createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_29, [createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_30, toDisplayString(userProfile.value.statistics.totalInteractions), 1 /* TEXT */), _cache[15] || (_cache[15] = createBaseVNode("div", {
        class: "stat-label"
      }, "总交互次数", -1 /* CACHED */))]), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_31, [createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_32, toDisplayString(userProfile.value.statistics.averageDailyActivity.toFixed(1)), 1 /* TEXT */), _cache[16] || (_cache[16] = createBaseVNode("div", {
        class: "stat-label"
      }, "日均活动", -1 /* CACHED */))]), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_33, [createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_34, toDisplayString(userProfile.value.interests.projects.length), 1 /* TEXT */), _cache[17] || (_cache[17] = createBaseVNode("div", {
        class: "stat-label"
      }, "关注项目数", -1 /* CACHED */))]), createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_35, [createBaseVNode("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_36, toDisplayString(userProfile.value.interests.people.length), 1 /* TEXT */), _cache[18] || (_cache[18] = createBaseVNode("div", {
        class: "stat-label"
      }, "协作人员数", -1 /* CACHED */))])])])])) : (openBlock(), createElementBlock("div", UserProfilePagevue_type_script_setup_true_lang_ts_hoisted_37, [...(_cache[20] || (_cache[20] = [createBaseVNode("span", null, "👤", -1 /* CACHED */), createBaseVNode("p", null, "暂无用户画像数据", -1 /* CACHED */), createBaseVNode("p", {
        class: "empty-hint"
      }, "随着您使用系统，我们将逐步为您建立个性化画像", -1 /* CACHED */)]))]))]);
    };
  }
}));
;// CONCATENATED MODULE: ./src/modals/components/UserProfilePage.vue?vue&type=script&setup=true&lang=ts
 
;// CONCATENATED MODULE: ./src/modals/components/UserProfilePage.vue



const UserProfilePage_exports_ = UserProfilePagevue_type_script_setup_true_lang_ts;

/* harmony default export */ const UserProfilePage = (UserProfilePage_exports_);
;// CONCATENATED MODULE: ./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[6].use[0]!./src/modals/components/PersonDetailPage.vue?vue&type=script&setup=true&lang=ts


const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_1 = {
  class: "person-detail"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_2 = {
  class: "detail-header"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_3 = {
  key: 0,
  class: "person-header"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_4 = {
  class: "person-info"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_5 = {
  class: "person-meta"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_6 = {
  class: "meta-item"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_7 = {
  class: "meta-item"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_8 = {
  class: "meta-item"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_9 = {
  class: "meta-item"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_10 = {
  key: 0,
  class: "loading-container"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_11 = {
  key: 1,
  class: "person-detail-content"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_12 = {
  class: "tab-navigation"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_13 = ["onClick"];
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_14 = {
  key: 0,
  class: "tab-content active"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_15 = {
  class: "items-grid"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_16 = {
  class: "item-header"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_17 = {
  class: "item-title"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_18 = {
  class: "item-content"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_19 = {
  style: {
    "margin-bottom": "0.5rem"
  }
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_20 = {
  class: "card-badge"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_21 = {
  class: "card-badge",
  style: {
    "background": "rgba(147, 51, 234, 0.2)",
    "color": "#a78bfa"
  }
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_22 = {
  key: 1,
  class: "tab-content active"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_23 = {
  class: "skills-grid"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_24 = {
  class: "skill-header"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_25 = {
  class: "skill-name"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_26 = {
  class: "skill-level"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_27 = {
  class: "skill-progress"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_28 = {
  key: 0,
  class: "skill-projects"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_29 = {
  key: 2,
  class: "tab-content active"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_30 = {
  class: "section-header"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_31 = {
  class: "search-controls"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_32 = {
  class: "conversations-list"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_33 = {
  class: "conversation-header"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_34 = {
  class: "conversation-meta"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_35 = {
  class: "sender-avatar"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_36 = {
  class: "sender-info"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_37 = {
  class: "sender-name"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_38 = {
  class: "group-name"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_39 = {
  class: "conversation-time"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_40 = ["innerHTML"];
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_41 = ["onClick"];
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_42 = {
  class: "indicator-text"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_43 = {
  class: "context-header"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_44 = {
  class: "context-sender"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_45 = {
  class: "context-time"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_46 = ["innerHTML"];
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_47 = {
  key: 3,
  class: "tab-content active"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_48 = {
  class: "items-grid"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_49 = {
  class: "item-header"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_50 = {
  class: "item-title"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_51 = {
  class: "item-content"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_52 = {
  style: {
    "margin-bottom": "0.5rem"
  }
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_53 = {
  class: "card-badge"
};
const PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_54 = ["href"];



/* harmony default export */ const PersonDetailPagevue_type_script_setup_true_lang_ts = (/*@__PURE__*/runtime_core_esm_bundler_defineComponent({
  __name: 'PersonDetailPage',
  setup(__props) {
    const route = useRoute();
    const router = useRouter();
    const store = useMemoryStore();
    const personId = runtime_core_esm_bundler_computed(() => route.params.id);
    const personData = runtime_core_esm_bundler_computed(() => store.personDetailData);
    const isLoading = runtime_core_esm_bundler_computed(() => store.isLoading);
    const activeTab = reactivity_esm_bundler_ref('projects');
    const convSearchQuery = reactivity_esm_bundler_ref('');
    const convFilter = reactivity_esm_bundler_ref('all');
    const expandedConversations = reactivity_esm_bundler_ref(new Set());
    const tabs = [{
      key: 'projects',
      label: '🚀 协作项目'
    }, {
      key: 'skills',
      label: '🎯 专业技能'
    }, {
      key: 'conversations',
      label: '💬 聊天记录'
    }, {
      key: 'resources',
      label: '📚 相关资源'
    }];
    const filteredConversations = runtime_core_esm_bundler_computed(() => {
      let filtered = personData.value?.conversations || [];
      if (convSearchQuery.value.trim()) {
        const query = convSearchQuery.value.toLowerCase();
        filtered = filtered.filter(conv => conv.summary.toLowerCase().includes(query) || conv.sender.toLowerCase().includes(query) || conv.group.toLowerCase().includes(query));
      }
      if (convFilter.value !== 'all') {
        filtered = filtered.filter(conv => {
          switch (convFilter.value) {
            case 'team':
              return conv.group.includes('团队') || conv.group.includes('Team');
            case 'project':
              return conv.group.includes('项目') || conv.group.includes('Project');
            case 'tech':
              return conv.group.includes('技术') || conv.group.includes('Tech') || conv.group.includes('开发');
            default:
              return true;
          }
        });
      }
      return filtered;
    });
    const goBack = () => {
      router.push('/entity/Person');
    };
    const toggleConversationExpand = conversationId => {
      const newExpanded = new Set(expandedConversations.value);
      if (newExpanded.has(conversationId)) {
        newExpanded.delete(conversationId);
      } else {
        newExpanded.clear();
        newExpanded.add(conversationId);
      }
      expandedConversations.value = newExpanded;
    };
    const highlightText = (text, searchQuery) => {
      if (!searchQuery.trim()) return text;
      const regex = new RegExp(`(${searchQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
      return text.replace(regex, '<mark style="background: rgba(251, 191, 36, 0.3); color: #fbbf24; padding: 0.125rem 0.25rem; border-radius: 0.25rem; font-weight: 600;">$1</mark>');
    };

    // 模拟加载人物详情数据
    const loadPersonDetail = personId => {
      store.personDetailData = {
        id: personId,
        title: '张三',
        overview: {
          team: '技术团队',
          collaborations: 3,
          messages: 25,
          resources: 8
        },
        collaborationProjects: [{
          id: 'project-1',
          name: 'Personal-AI',
          status: '开发中',
          role: '前端负责人',
          description: 'Chrome扩展智能助手开发'
        }, {
          id: 'project-2',
          name: 'Web Platform',
          status: '维护中',
          role: '核心开发',
          description: '前端平台维护和优化'
        }],
        skills: [{
          id: 'skill-1',
          name: 'React',
          level: '专家',
          proficiency: 95,
          projects: ['Personal-AI', 'Web Platform']
        }, {
          id: 'skill-2',
          name: 'TypeScript',
          level: '高级',
          proficiency: 88,
          projects: ['Personal-AI']
        }, {
          id: 'skill-3',
          name: '性能优化',
          level: '中级',
          proficiency: 75,
          projects: ['Web Platform']
        }],
        conversations: [{
          id: 'conv-1',
          sender: '张三',
          group: '技术讨论组',
          time: '1小时前',
          summary: '代码审查反馈：建议优化组件性能',
          context: [{
            sender: '李四',
            content: '这个组件的渲染次数有点多',
            time: '2小时前'
          }, {
            sender: '张三',
            content: '我建议使用useMemo来优化',
            time: '1小时前',
            isMainMessage: true
          }]
        }],
        relatedResources: [{
          id: 'resource-1',
          name: 'React 性能优化指南',
          type: '技术文档',
          url: '#'
        }, {
          id: 'resource-2',
          name: 'TypeScript 最佳实践',
          type: '教程',
          url: '#'
        }]
      };
    };
    runtime_core_esm_bundler_watch(personId, newId => {
      if (newId) {
        loadPersonDetail(newId);
      }
    }, {
      immediate: true
    });
    runtime_core_esm_bundler_watch(() => route.query, newQuery => {
      if (newQuery.messageId) {
        activeTab.value = 'conversations';
        console.log('定位到消息:', newQuery.messageId);
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_1, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_2, [createBaseVNode("button", {
        class: "back-btn",
        onClick: goBack
      }, [...(_cache[2] || (_cache[2] = [createBaseVNode("span", null, "←", -1 /* CACHED */), createBaseVNode("span", null, "返回人物列表", -1 /* CACHED */)]))]), personData.value ? (openBlock(), createElementBlock("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_3, [_cache[4] || (_cache[4] = createBaseVNode("div", {
        class: "person-avatar"
      }, "👤", -1 /* CACHED */)), createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_4, [createBaseVNode("h2", null, toDisplayString(personData.value.title), 1 /* TEXT */), createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_5, [createBaseVNode("span", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_6, "🏢 " + toDisplayString(personData.value.overview?.team || '技术团队'), 1 /* TEXT */), createBaseVNode("span", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_7, "🤝 " + toDisplayString(personData.value.overview?.collaborations || 0) + " 个协作项目", 1 /* TEXT */), createBaseVNode("span", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_8, "💬 " + toDisplayString(personData.value.overview?.messages || 0) + " 条消息", 1 /* TEXT */), createBaseVNode("span", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_9, "📚 " + toDisplayString(personData.value.overview?.resources || 0) + " 个资源", 1 /* TEXT */), _cache[3] || (_cache[3] = createBaseVNode("span", {
        class: "meta-item"
      }, "⏰ 最后联系：1小时前", -1 /* CACHED */))])]), _cache[5] || (_cache[5] = createBaseVNode("div", {
        class: "person-actions"
      }, [createBaseVNode("button", {
        class: "action-btn"
      }, "💬 发送消息"), createBaseVNode("button", {
        class: "action-btn"
      }, "🤝 查看协作")], -1 /* CACHED */))])) : createCommentVNode("v-if", true)]), isLoading.value ? (openBlock(), createElementBlock("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_10, [...(_cache[6] || (_cache[6] = [createBaseVNode("div", {
        class: "loading-spinner"
      }, null, -1 /* CACHED */), createBaseVNode("span", null, "加载人物详情...", -1 /* CACHED */)]))])) : personData.value ? (openBlock(), createElementBlock("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_11, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_12, [(openBlock(), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(tabs, tab => {
        return createBaseVNode("button", {
          key: tab.key,
          class: shared_esm_bundler_normalizeClass(['tab-btn', {
            active: activeTab.value === tab.key
          }]),
          onClick: $event => activeTab.value = tab.key
        }, toDisplayString(tab.label), 11 /* TEXT, CLASS, PROPS */, PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_13);
      }), 64 /* STABLE_FRAGMENT */))]), createCommentVNode(" 协作项目标签页 "), activeTab.value === 'projects' ? (openBlock(), createElementBlock("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_14, [_cache[9] || (_cache[9] = createBaseVNode("div", {
        class: "section-header"
      }, [createBaseVNode("h3", null, "🚀 协作项目"), createBaseVNode("button", {
        class: "add-btn"
      }, "+ 添加协作")], -1 /* CACHED */)), createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_15, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(personData.value.collaborationProjects, project => {
        return openBlock(), createElementBlock("div", {
          key: project.id,
          class: "item-card"
        }, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_16, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_17, [_cache[7] || (_cache[7] = createBaseVNode("span", null, "🚀", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(project.name), 1 /* TEXT */)]), _cache[8] || (_cache[8] = createBaseVNode("div", {
          class: "item-actions"
        }, [createBaseVNode("button", {
          class: "item-action",
          title: "移除协作"
        }, "❌")], -1 /* CACHED */))]), createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_18, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_19, [createBaseVNode("span", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_20, toDisplayString(project.status), 1 /* TEXT */), createBaseVNode("span", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_21, toDisplayString(project.role), 1 /* TEXT */)]), createBaseVNode("p", null, toDisplayString(project.description), 1 /* TEXT */)])]);
      }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true), createCommentVNode(" 专业技能标签页 "), activeTab.value === 'skills' ? (openBlock(), createElementBlock("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_22, [_cache[11] || (_cache[11] = createBaseVNode("div", {
        class: "section-header"
      }, [createBaseVNode("h3", null, "🎯 专业技能"), createBaseVNode("button", {
        class: "add-btn"
      }, "+ 添加技能")], -1 /* CACHED */)), createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_23, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(personData.value.skills, skill => {
        return openBlock(), createElementBlock("div", {
          key: skill.id,
          class: "skill-card"
        }, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_24, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_25, toDisplayString(skill.name), 1 /* TEXT */), createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_26, toDisplayString(skill.level), 1 /* TEXT */)]), createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_27, [createBaseVNode("div", {
          class: "skill-progress-bar",
          style: shared_esm_bundler_normalizeStyle({
            width: skill.proficiency + '%'
          })
        }, null, 4 /* STYLE */)]), skill.projects ? (openBlock(), createElementBlock("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_28, [_cache[10] || (_cache[10] = createBaseVNode("span", {
          class: "projects-label"
        }, "相关项目：", -1 /* CACHED */)), (openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(skill.projects, (project, index) => {
          return openBlock(), createElementBlock("span", {
            key: index,
            class: "skill-project-tag"
          }, toDisplayString(project), 1 /* TEXT */);
        }), 128 /* KEYED_FRAGMENT */))])) : createCommentVNode("v-if", true)]);
      }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true), createCommentVNode(" 聊天记录标签页 "), activeTab.value === 'conversations' ? (openBlock(), createElementBlock("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_29, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_30, [_cache[13] || (_cache[13] = createBaseVNode("h3", null, "💬 聊天记录", -1 /* CACHED */)), createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_31, [withDirectives(createBaseVNode("input", {
        type: "text",
        class: "search-input",
        placeholder: "搜索聊天记录...",
        "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => convSearchQuery.value = $event)
      }, null, 512 /* NEED_PATCH */), [[vModelText, convSearchQuery.value]]), withDirectives(createBaseVNode("select", {
        class: "filter-select",
        "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => convFilter.value = $event)
      }, [...(_cache[12] || (_cache[12] = [createBaseVNode("option", {
        value: "all"
      }, "全部群组", -1 /* CACHED */), createBaseVNode("option", {
        value: "team"
      }, "团队群", -1 /* CACHED */), createBaseVNode("option", {
        value: "project"
      }, "项目群", -1 /* CACHED */), createBaseVNode("option", {
        value: "tech"
      }, "技术讨论", -1 /* CACHED */)]))], 512 /* NEED_PATCH */), [[vModelSelect, convFilter.value]])])]), createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_32, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(filteredConversations.value, conv => {
        return openBlock(), createElementBlock("div", {
          key: conv.id,
          class: shared_esm_bundler_normalizeClass(["conversation-item", {
            expanded: expandedConversations.value.has(conv.id)
          }])
        }, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_33, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_34, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_35, toDisplayString(conv.sender.charAt(0)), 1 /* TEXT */), createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_36, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_37, toDisplayString(conv.sender), 1 /* TEXT */), createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_38, toDisplayString(conv.group), 1 /* TEXT */)])]), createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_39, toDisplayString(conv.time), 1 /* TEXT */)]), createBaseVNode("div", {
          class: "conversation-summary",
          innerHTML: highlightText(conv.summary, convSearchQuery.value)
        }, null, 8 /* PROPS */, PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_40), createBaseVNode("div", {
          class: shared_esm_bundler_normalizeClass(["context-indicator", {
            expanded: expandedConversations.value.has(conv.id)
          }]),
          onClick: $event => toggleConversationExpand(conv.id)
        }, [createBaseVNode("span", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_42, toDisplayString(expandedConversations.value.has(conv.id) ? '🔼 收起上下文' : `🔍 查看上下文 (${conv.context?.length || 0} 条相关消息)`), 1 /* TEXT */)], 10 /* CLASS, PROPS */, PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_41), conv.context ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: shared_esm_bundler_normalizeClass(["context-content", {
            expanded: expandedConversations.value.has(conv.id)
          }])
        }, [_cache[14] || (_cache[14] = createBaseVNode("div", {
          class: "context-divider"
        }, null, -1 /* CACHED */)), (openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(conv.context, (contextMsg, index) => {
          return openBlock(), createElementBlock("div", {
            key: index,
            class: shared_esm_bundler_normalizeClass(["context-item", {
              'main-message': contextMsg.isMainMessage
            }])
          }, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_43, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_44, toDisplayString(contextMsg.sender), 1 /* TEXT */), createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_45, toDisplayString(contextMsg.time), 1 /* TEXT */)]), createBaseVNode("div", {
            class: "context-content-text",
            innerHTML: contextMsg.isMainMessage ? highlightText(contextMsg.content, convSearchQuery.value) : contextMsg.content
          }, null, 8 /* PROPS */, PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_46)], 2 /* CLASS */);
        }), 128 /* KEYED_FRAGMENT */))], 2 /* CLASS */)) : createCommentVNode("v-if", true)], 2 /* CLASS */);
      }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true), createCommentVNode(" 相关资源标签页 "), activeTab.value === 'resources' ? (openBlock(), createElementBlock("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_47, [_cache[17] || (_cache[17] = createBaseVNode("div", {
        class: "section-header"
      }, [createBaseVNode("h3", null, "📚 相关资源"), createBaseVNode("button", {
        class: "add-btn"
      }, "+ 添加资源")], -1 /* CACHED */)), createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_48, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(personData.value.recentDataDetails.resources, resource => {
        return openBlock(), createElementBlock("div", {
          key: resource.id,
          class: "item-card"
        }, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_49, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_50, [_cache[15] || (_cache[15] = createBaseVNode("span", null, "📚", -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(resource.name), 1 /* TEXT */)]), _cache[16] || (_cache[16] = createBaseVNode("div", {
          class: "item-actions"
        }, [createBaseVNode("button", {
          class: "item-action",
          title: "删除资源"
        }, "❌")], -1 /* CACHED */))]), createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_51, [createBaseVNode("div", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_52, [createBaseVNode("span", PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_53, toDisplayString(resource.type), 1 /* TEXT */)]), createBaseVNode("p", null, [createBaseVNode("a", {
          href: resource.url,
          style: {
            "color": "#60a5fa"
          }
        }, "查看资源", 8 /* PROPS */, PersonDetailPagevue_type_script_setup_true_lang_ts_hoisted_54)])])]);
      }), 128 /* KEYED_FRAGMENT */))])])) : createCommentVNode("v-if", true)])) : createCommentVNode("v-if", true)]);
    };
  }
}));
;// CONCATENATED MODULE: ./src/modals/components/PersonDetailPage.vue?vue&type=script&setup=true&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[6].use[0]!./src/modals/components/PersonDetailPage.vue?vue&type=style&index=0&id=744c8b2e&scoped=true&lang=css
var PersonDetailPagevue_type_style_index_0_id_744c8b2e_scoped_true_lang_css = __webpack_require__(3299);
;// CONCATENATED MODULE: ./src/modals/components/PersonDetailPage.vue?vue&type=style&index=0&id=744c8b2e&scoped=true&lang=css

// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(6262);
;// CONCATENATED MODULE: ./src/modals/components/PersonDetailPage.vue



;


const PersonDetailPage_exports_ = /*#__PURE__*/(0,exportHelper/* default */.A)(PersonDetailPagevue_type_script_setup_true_lang_ts, [['__scopeId',"data-v-744c8b2e"]])

/* harmony default export */ const PersonDetailPage = (PersonDetailPage_exports_);
;// CONCATENATED MODULE: ./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[6].use[0]!./src/modals/components/SearchResultPage.vue?vue&type=script&setup=true&lang=ts


const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_1 = {
  class: "search-results-section"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_2 = {
  class: "search-header"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_3 = {
  key: 0
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_4 = {
  key: 0,
  class: "loading-container"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_5 = {
  key: 1,
  class: "search-results"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_6 = {
  class: "results-summary"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_7 = {
  class: "results-count"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_8 = {
  class: "results-filters"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_9 = ["onClick"];
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_10 = {
  class: "search-results-grid"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_11 = ["onClick"];
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_12 = {
  class: "result-header"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_13 = {
  class: "result-type-indicator"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_14 = {
  class: "type-icon"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_15 = {
  class: "type-name"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_16 = {
  key: 0,
  class: "relevance-score"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_17 = {
  class: "result-content"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_18 = {
  class: "result-title"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_19 = {
  key: 0,
  class: "result-description"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_20 = {
  key: 1,
  class: "result-tags"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_21 = {
  key: 0,
  class: "result-tag more-tags"
};
const SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_22 = {
  key: 2,
  class: "empty-search-state"
};



/* harmony default export */ const SearchResultPagevue_type_script_setup_true_lang_ts = (/*@__PURE__*/runtime_core_esm_bundler_defineComponent({
  __name: 'SearchResultPage',
  setup(__props) {
    const route = useRoute();
    const router = useRouter();
    const store = useMemoryStore();
    const searchQuery = runtime_core_esm_bundler_computed(() => route.query.q || '');
    const entities = runtime_core_esm_bundler_computed(() => store.entities);
    const isLoading = runtime_core_esm_bundler_computed(() => store.isLoading);
    const selectedTypeFilter = reactivity_esm_bundler_ref('all');

    // 获取可用的实体类型及其数量
    const availableTypes = runtime_core_esm_bundler_computed(() => {
      const typeMap = new Map();
      typeMap.set('all', {
        key: 'all',
        name: '全部',
        icon: '📁',
        count: entities.value.length
      });
      entities.value.forEach(entity => {
        const config = ENTITY_TYPE_CONFIG[entity.type];
        if (config) {
          const existing = typeMap.get(entity.type) || {
            key: entity.type,
            name: config.name,
            icon: config.icon,
            count: 0
          };
          existing.count++;
          typeMap.set(entity.type, existing);
        }
      });
      return Array.from(typeMap.values()).filter(type => type.count > 0);
    });

    // 根据类型过滤的结果
    const filteredResults = runtime_core_esm_bundler_computed(() => {
      if (selectedTypeFilter.value === 'all') {
        return entities.value;
      }
      return entities.value.filter(entity => entity.type === selectedTypeFilter.value);
    });
    const getEntityIcon = type => {
      return ENTITY_TYPE_CONFIG[type]?.icon || '📂';
    };
    const getEntityTypeName = type => {
      return ENTITY_TYPE_CONFIG[type]?.name || type;
    };
    const handleResultClick = entity => {
      switch (entity.type) {
        case 'Topic':
          router.push(`/topic/${entity.id}`);
          break;
        case 'Person':
          router.push(`/person/${entity.id}`);
          break;
        case 'Project':
          router.push(`/project/${entity.id}`);
          break;
        default:
          router.push(`/entity/${entity.type}`);
          break;
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_1, [createBaseVNode("div", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_2, [_cache[0] || (_cache[0] = createBaseVNode("h2", null, "🔍 搜索结果", -1 /* CACHED */)), searchQuery.value ? (openBlock(), createElementBlock("p", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_3, "关键词: \"" + toDisplayString(searchQuery.value) + "\"", 1 /* TEXT */)) : createCommentVNode("v-if", true)]), isLoading.value ? (openBlock(), createElementBlock("div", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_4, [...(_cache[1] || (_cache[1] = [createBaseVNode("div", {
        class: "loading-spinner"
      }, null, -1 /* CACHED */), createBaseVNode("span", null, "正在搜索...", -1 /* CACHED */)]))])) : entities.value.length > 0 ? (openBlock(), createElementBlock("div", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_5, [createBaseVNode("div", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_6, [createBaseVNode("span", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_7, "找到 " + toDisplayString(entities.value.length) + " 个相关结果", 1 /* TEXT */), createBaseVNode("div", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_8, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(availableTypes.value, type => {
        return openBlock(), createElementBlock("button", {
          key: type.key,
          class: shared_esm_bundler_normalizeClass(['type-filter', {
            active: selectedTypeFilter.value === type.key
          }]),
          onClick: $event => selectedTypeFilter.value = type.key
        }, toDisplayString(type.icon) + " " + toDisplayString(type.name) + " (" + toDisplayString(type.count) + ") ", 11 /* TEXT, CLASS, PROPS */, SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_9);
      }), 128 /* KEYED_FRAGMENT */))])]), createBaseVNode("div", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_10, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(filteredResults.value, entity => {
        return openBlock(), createElementBlock("div", {
          key: entity.id,
          class: "search-result-card",
          onClick: $event => handleResultClick(entity)
        }, [createBaseVNode("div", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_12, [createBaseVNode("div", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_13, [createBaseVNode("span", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_14, toDisplayString(getEntityIcon(entity.type)), 1 /* TEXT */), createBaseVNode("span", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_15, toDisplayString(getEntityTypeName(entity.type)), 1 /* TEXT */)]), entity.relevanceScore ? (openBlock(), createElementBlock("div", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_16, toDisplayString(Math.round(entity.relevanceScore * 100)) + "% 匹配 ", 1 /* TEXT */)) : createCommentVNode("v-if", true)]), createBaseVNode("div", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_17, [createBaseVNode("h3", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_18, toDisplayString(entity.name), 1 /* TEXT */), entity.description ? (openBlock(), createElementBlock("p", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_19, toDisplayString(entity.description), 1 /* TEXT */)) : createCommentVNode("v-if", true), entity.tags && entity.tags.length > 0 ? (openBlock(), createElementBlock("div", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_20, [(openBlock(true), createElementBlock(runtime_core_esm_bundler_Fragment, null, renderList(entity.tags.slice(0, 3), tag => {
          return openBlock(), createElementBlock("span", {
            key: tag,
            class: "result-tag"
          }, toDisplayString(tag), 1 /* TEXT */);
        }), 128 /* KEYED_FRAGMENT */)), entity.tags.length > 3 ? (openBlock(), createElementBlock("span", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_21, " +" + toDisplayString(entity.tags.length - 3), 1 /* TEXT */)) : createCommentVNode("v-if", true)])) : createCommentVNode("v-if", true)]), _cache[2] || (_cache[2] = createBaseVNode("div", {
          class: "result-actions"
        }, [createBaseVNode("button", {
          class: "action-btn primary"
        }, " 查看详情 → ")], -1 /* CACHED */))], 8 /* PROPS */, SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_11);
      }), 128 /* KEYED_FRAGMENT */))])])) : (openBlock(), createElementBlock("div", SearchResultPagevue_type_script_setup_true_lang_ts_hoisted_22, [...(_cache[3] || (_cache[3] = [createBaseVNode("span", null, "🔍", -1 /* CACHED */), createBaseVNode("p", null, "没有找到相关结果", -1 /* CACHED */), createBaseVNode("p", {
        class: "search-tips"
      }, " 尝试使用不同的关键词或更具体的描述 ", -1 /* CACHED */)]))]))]);
    };
  }
}));
;// CONCATENATED MODULE: ./src/modals/components/SearchResultPage.vue?vue&type=script&setup=true&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[6].use[0]!./src/modals/components/SearchResultPage.vue?vue&type=style&index=0&id=26a7e817&scoped=true&lang=css
var SearchResultPagevue_type_style_index_0_id_26a7e817_scoped_true_lang_css = __webpack_require__(4816);
;// CONCATENATED MODULE: ./src/modals/components/SearchResultPage.vue?vue&type=style&index=0&id=26a7e817&scoped=true&lang=css

;// CONCATENATED MODULE: ./src/modals/components/SearchResultPage.vue



;


const SearchResultPage_exports_ = /*#__PURE__*/(0,exportHelper/* default */.A)(SearchResultPagevue_type_script_setup_true_lang_ts, [['__scopeId',"data-v-26a7e817"]])

/* harmony default export */ const SearchResultPage = (SearchResultPage_exports_);
;// CONCATENATED MODULE: ./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[6].use[0]!./src/modals/components/PlaceholderPage.vue?vue&type=script&setup=true&lang=ts


const PlaceholderPagevue_type_script_setup_true_lang_ts_hoisted_1 = {
  class: "loading-container"
};

/* harmony default export */ const PlaceholderPagevue_type_script_setup_true_lang_ts = (/*@__PURE__*/runtime_core_esm_bundler_defineComponent({
  __name: 'PlaceholderPage',
  setup(__props) {
    const route = useRoute();
    const getPageMessage = () => {
      const routeName = route.name;
      switch (routeName) {
        case 'UserProfile':
          return '用户画像页面开发中...';
        case 'Search':
          return '搜索结果页面开发中...';
        default:
          return '页面开发中...';
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", PlaceholderPagevue_type_script_setup_true_lang_ts_hoisted_1, [_cache[0] || (_cache[0] = createBaseVNode("div", {
        class: "loading-spinner"
      }, null, -1 /* CACHED */)), createBaseVNode("span", null, toDisplayString(getPageMessage()), 1 /* TEXT */)]);
    };
  }
}));
;// CONCATENATED MODULE: ./src/modals/components/PlaceholderPage.vue?vue&type=script&setup=true&lang=ts
 
;// CONCATENATED MODULE: ./src/modals/components/PlaceholderPage.vue



const PlaceholderPage_exports_ = PlaceholderPagevue_type_script_setup_true_lang_ts;

/* harmony default export */ const PlaceholderPage = (PlaceholderPage_exports_);
;// CONCATENATED MODULE: ./src/modals/memory-exploring-entry.ts





// 导入页面组件









// 路由配置
const routes = [{
  path: '/',
  name: 'Overview',
  component: OverviewPage
}, {
  path: '/timeline',
  name: 'Timeline',
  component: TimelinePage
}, {
  path: '/user-profile',
  name: 'UserProfile',
  component: UserProfilePage
}, {
  path: '/entity/:type',
  name: 'EntityDetail',
  component: EntityListPage,
  props: true
}, {
  path: '/topic/:id',
  name: 'TopicDetail',
  component: TopicDetailPage,
  props: true
}, {
  path: '/person/:id',
  name: 'PersonDetail',
  component: PersonDetailPage,
  props: true
}, {
  path: '/project/:id',
  name: 'ProjectDetail',
  component: PlaceholderPage,
  props: true
}, {
  path: '/search',
  name: 'Search',
  component: SearchResultPage
}];

// 等待DOM加载完成
document.addEventListener('DOMContentLoaded', () => {
  const mountElement = document.getElementById('memory-app');
  if (mountElement) {
    // 创建路由实例
    const router = createRouter({
      history: createWebHashHistory(),
      routes
    });

    // 创建 Pinia 实例
    const pinia = createPinia();

    // 创建 Vue 应用
    const app = createApp(memory_exploring);

    // 使用插件
    app.use(pinia);
    app.use(router);

    // 挂载应用
    app.mount('#memory-app');
  }
});

// 导出应用实例（可选，用于调试）
/* harmony default export */ const memory_exploring_entry = ((/* unused pure expression or super */ null && (MemoryExploring)));
})();

/******/ })()
;
//# sourceMappingURL=memory-exploring.js.map