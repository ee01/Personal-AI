/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 5228:
/***/ ((module) => {

/*
object-assign
(c) Sindre Sorhus
@license MIT
*/


/* eslint-disable no-unused-vars */
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;

function toObject(val) {
	if (val === null || val === undefined) {
		throw new TypeError('Object.assign cannot be called with null or undefined');
	}

	return Object(val);
}

function shouldUseNative() {
	try {
		if (!Object.assign) {
			return false;
		}

		// Detect buggy property enumeration order in older V8 versions.

		// https://bugs.chromium.org/p/v8/issues/detail?id=4118
		var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
		test1[5] = 'de';
		if (Object.getOwnPropertyNames(test1)[0] === '5') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test2 = {};
		for (var i = 0; i < 10; i++) {
			test2['_' + String.fromCharCode(i)] = i;
		}
		var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
			return test2[n];
		});
		if (order2.join('') !== '0123456789') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test3 = {};
		'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
			test3[letter] = letter;
		});
		if (Object.keys(Object.assign({}, test3)).join('') !==
				'abcdefghijklmnopqrst') {
			return false;
		}

		return true;
	} catch (err) {
		// We don't expect any of the above to throw, but better to be safe.
		return false;
	}
}

module.exports = shouldUseNative() ? Object.assign : function (target, source) {
	var from;
	var to = toObject(target);
	var symbols;

	for (var s = 1; s < arguments.length; s++) {
		from = Object(arguments[s]);

		for (var key in from) {
			if (hasOwnProperty.call(from, key)) {
				to[key] = from[key];
			}
		}

		if (getOwnPropertySymbols) {
			symbols = getOwnPropertySymbols(from);
			for (var i = 0; i < symbols.length; i++) {
				if (propIsEnumerable.call(from, symbols[i])) {
					to[symbols[i]] = from[symbols[i]];
				}
			}
		}
	}

	return to;
};


/***/ }),

/***/ 5287:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var __webpack_unused_export__;
/** @license React v17.0.2
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var l=__webpack_require__(5228),n=60103,p=60106;__webpack_unused_export__=60107;__webpack_unused_export__=60108;__webpack_unused_export__=60114;var q=60109,r=60110,t=60112;__webpack_unused_export__=60113;var u=60115,v=60116;
if("function"===typeof Symbol&&Symbol.for){var w=Symbol.for;n=w("react.element");p=w("react.portal");__webpack_unused_export__=w("react.fragment");__webpack_unused_export__=w("react.strict_mode");__webpack_unused_export__=w("react.profiler");q=w("react.provider");r=w("react.context");t=w("react.forward_ref");__webpack_unused_export__=w("react.suspense");u=w("react.memo");v=w("react.lazy")}var x="function"===typeof Symbol&&Symbol.iterator;
function y(a){if(null===a||"object"!==typeof a)return null;a=x&&a[x]||a["@@iterator"];return"function"===typeof a?a:null}function z(a){for(var b="https://reactjs.org/docs/error-decoder.html?invariant="+a,c=1;c<arguments.length;c++)b+="&args[]="+encodeURIComponent(arguments[c]);return"Minified React error #"+a+"; visit "+b+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}
var A={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},B={};function C(a,b,c){this.props=a;this.context=b;this.refs=B;this.updater=c||A}C.prototype.isReactComponent={};C.prototype.setState=function(a,b){if("object"!==typeof a&&"function"!==typeof a&&null!=a)throw Error(z(85));this.updater.enqueueSetState(this,a,b,"setState")};C.prototype.forceUpdate=function(a){this.updater.enqueueForceUpdate(this,a,"forceUpdate")};
function D(){}D.prototype=C.prototype;function E(a,b,c){this.props=a;this.context=b;this.refs=B;this.updater=c||A}var F=E.prototype=new D;F.constructor=E;l(F,C.prototype);F.isPureReactComponent=!0;var G={current:null},H=Object.prototype.hasOwnProperty,I={key:!0,ref:!0,__self:!0,__source:!0};
function J(a,b,c){var e,d={},k=null,h=null;if(null!=b)for(e in void 0!==b.ref&&(h=b.ref),void 0!==b.key&&(k=""+b.key),b)H.call(b,e)&&!I.hasOwnProperty(e)&&(d[e]=b[e]);var g=arguments.length-2;if(1===g)d.children=c;else if(1<g){for(var f=Array(g),m=0;m<g;m++)f[m]=arguments[m+2];d.children=f}if(a&&a.defaultProps)for(e in g=a.defaultProps,g)void 0===d[e]&&(d[e]=g[e]);return{$$typeof:n,type:a,key:k,ref:h,props:d,_owner:G.current}}
function K(a,b){return{$$typeof:n,type:a.type,key:b,ref:a.ref,props:a.props,_owner:a._owner}}function L(a){return"object"===typeof a&&null!==a&&a.$$typeof===n}function escape(a){var b={"=":"=0",":":"=2"};return"$"+a.replace(/[=:]/g,function(a){return b[a]})}var M=/\/+/g;function N(a,b){return"object"===typeof a&&null!==a&&null!=a.key?escape(""+a.key):b.toString(36)}
function O(a,b,c,e,d){var k=typeof a;if("undefined"===k||"boolean"===k)a=null;var h=!1;if(null===a)h=!0;else switch(k){case "string":case "number":h=!0;break;case "object":switch(a.$$typeof){case n:case p:h=!0}}if(h)return h=a,d=d(h),a=""===e?"."+N(h,0):e,Array.isArray(d)?(c="",null!=a&&(c=a.replace(M,"$&/")+"/"),O(d,b,c,"",function(a){return a})):null!=d&&(L(d)&&(d=K(d,c+(!d.key||h&&h.key===d.key?"":(""+d.key).replace(M,"$&/")+"/")+a)),b.push(d)),1;h=0;e=""===e?".":e+":";if(Array.isArray(a))for(var g=
0;g<a.length;g++){k=a[g];var f=e+N(k,g);h+=O(k,b,c,f,d)}else if(f=y(a),"function"===typeof f)for(a=f.call(a),g=0;!(k=a.next()).done;)k=k.value,f=e+N(k,g++),h+=O(k,b,c,f,d);else if("object"===k)throw b=""+a,Error(z(31,"[object Object]"===b?"object with keys {"+Object.keys(a).join(", ")+"}":b));return h}function P(a,b,c){if(null==a)return a;var e=[],d=0;O(a,e,"","",function(a){return b.call(c,a,d++)});return e}
function Q(a){if(-1===a._status){var b=a._result;b=b();a._status=0;a._result=b;b.then(function(b){0===a._status&&(b=b.default,a._status=1,a._result=b)},function(b){0===a._status&&(a._status=2,a._result=b)})}if(1===a._status)return a._result;throw a._result;}var R={current:null};function S(){var a=R.current;if(null===a)throw Error(z(321));return a}var T={ReactCurrentDispatcher:R,ReactCurrentBatchConfig:{transition:0},ReactCurrentOwner:G,IsSomeRendererActing:{current:!1},assign:l};
__webpack_unused_export__={map:P,forEach:function(a,b,c){P(a,function(){b.apply(this,arguments)},c)},count:function(a){var b=0;P(a,function(){b++});return b},toArray:function(a){return P(a,function(a){return a})||[]},only:function(a){if(!L(a))throw Error(z(143));return a}};__webpack_unused_export__=C;__webpack_unused_export__=E;__webpack_unused_export__=T;
__webpack_unused_export__=function(a,b,c){if(null===a||void 0===a)throw Error(z(267,a));var e=l({},a.props),d=a.key,k=a.ref,h=a._owner;if(null!=b){void 0!==b.ref&&(k=b.ref,h=G.current);void 0!==b.key&&(d=""+b.key);if(a.type&&a.type.defaultProps)var g=a.type.defaultProps;for(f in b)H.call(b,f)&&!I.hasOwnProperty(f)&&(e[f]=void 0===b[f]&&void 0!==g?g[f]:b[f])}var f=arguments.length-2;if(1===f)e.children=c;else if(1<f){g=Array(f);for(var m=0;m<f;m++)g[m]=arguments[m+2];e.children=g}return{$$typeof:n,type:a.type,
key:d,ref:k,props:e,_owner:h}};__webpack_unused_export__=function(a,b){void 0===b&&(b=null);a={$$typeof:r,_calculateChangedBits:b,_currentValue:a,_currentValue2:a,_threadCount:0,Provider:null,Consumer:null};a.Provider={$$typeof:q,_context:a};return a.Consumer=a};__webpack_unused_export__=J;__webpack_unused_export__=function(a){var b=J.bind(null,a);b.type=a;return b};__webpack_unused_export__=function(){return{current:null}};__webpack_unused_export__=function(a){return{$$typeof:t,render:a}};__webpack_unused_export__=L;
__webpack_unused_export__=function(a){return{$$typeof:v,_payload:{_status:-1,_result:a},_init:Q}};__webpack_unused_export__=function(a,b){return{$$typeof:u,type:a,compare:void 0===b?null:b}};__webpack_unused_export__=function(a,b){return S().useCallback(a,b)};__webpack_unused_export__=function(a,b){return S().useContext(a,b)};__webpack_unused_export__=function(){};__webpack_unused_export__=function(a,b){return S().useEffect(a,b)};__webpack_unused_export__=function(a,b,c){return S().useImperativeHandle(a,b,c)};
__webpack_unused_export__=function(a,b){return S().useLayoutEffect(a,b)};__webpack_unused_export__=function(a,b){return S().useMemo(a,b)};__webpack_unused_export__=function(a,b,c){return S().useReducer(a,b,c)};__webpack_unused_export__=function(a){return S().useRef(a)};__webpack_unused_export__=function(a){return S().useState(a)};__webpack_unused_export__="17.0.2";


/***/ }),

/***/ 6540:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



if (true) {
  /* unused reexport */ __webpack_require__(5287);
} else {}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
/* unused harmony exports AgentVisualizer, AgentFlowVisualizer, AgentResultSummary */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6540);


const AgentVisualizer = _ref => {
  let {
    thoughtProcess,
    isProcessing = false
  } = _ref;
  const [expandedSteps, setExpandedSteps] = useState([]);

  // 当一个新的思考步骤被添加时，自动展开它
  useEffect(() => {
    if (thoughtProcess.length > 0) {
      setExpandedSteps(prevExpanded => {
        if (!prevExpanded.includes(thoughtProcess.length - 1)) {
          return [...prevExpanded, thoughtProcess.length - 1];
        }
        return prevExpanded;
      });
    }
  }, [thoughtProcess.length]);

  // 切换展开/折叠状态
  const toggleExpand = index => {
    setExpandedSteps(prevExpanded => {
      if (prevExpanded.includes(index)) {
        return prevExpanded.filter(i => i !== index);
      } else {
        return [...prevExpanded, index];
      }
    });
  };

  // 格式化时间戳
  const formatTime = timestamp => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString();
  };

  // 格式化工具结果，限制显示长度
  const formatToolResult = result => {
    if (!result) return '无结果';
    try {
      const resultStr = JSON.stringify(result, null, 2);
      if (resultStr.length > 500) {
        return resultStr.substring(0, 500) + '...';
      }
      return resultStr;
    } catch (e) {
      return '无法显示结果';
    }
  };

  // 获取步骤类型的颜色和图标
  const getStepStyle = step => {
    if (step.action === 'finish') {
      return {
        color: '#4CAF50',
        icon: '✓'
      }; // 完成-绿色
    }
    if (step.toolUsed) {
      // 检查是否有错误
      if (!step.toolResult) {
        return {
          color: '#F44336',
          icon: '✗'
        }; // 错误-红色
      }
      return {
        color: '#2196F3',
        icon: '🔧'
      }; // 工具调用-蓝色
    }
    return {
      color: '#FF9800',
      icon: '💭'
    }; // 思考-橙色
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "agent-visualizer"
  }, /*#__PURE__*/React.createElement("h3", null, "\u667A\u80FDAgent\u5904\u7406\u6D41\u7A0B ", isProcessing && /*#__PURE__*/React.createElement("span", {
    className: "processing-indicator"
  }, "\u5904\u7406\u4E2D...")), thoughtProcess.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "empty-state"
  }, isProcessing ? '等待Agent开始处理...' : '没有处理记录') : /*#__PURE__*/React.createElement("div", {
    className: "thought-timeline"
  }, thoughtProcess.map((step, index) => {
    const isExpanded = expandedSteps.includes(index);
    const {
      color,
      icon
    } = getStepStyle(step);
    return /*#__PURE__*/React.createElement("div", {
      key: index,
      className: `thought-step ${isExpanded ? 'expanded' : ''}`,
      style: {
        borderLeftColor: color
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "step-header",
      onClick: () => toggleExpand(index)
    }, /*#__PURE__*/React.createElement("span", {
      className: "step-icon",
      style: {
        backgroundColor: color
      }
    }, icon), /*#__PURE__*/React.createElement("span", {
      className: "step-time"
    }, formatTime(step.timestamp)), /*#__PURE__*/React.createElement("span", {
      className: "step-title"
    }, step.toolUsed ? `使用工具: ${step.toolUsed}` : step.action === 'finish' ? '完成处理' : '思考分析'), /*#__PURE__*/React.createElement("span", {
      className: "expand-icon"
    }, isExpanded ? '▼' : '▶')), isExpanded && /*#__PURE__*/React.createElement("div", {
      className: "step-details"
    }, /*#__PURE__*/React.createElement("div", {
      className: "thought-content"
    }, /*#__PURE__*/React.createElement("h4", null, "\u601D\u8003\u8FC7\u7A0B:"), /*#__PURE__*/React.createElement("p", null, step.thought)), /*#__PURE__*/React.createElement("div", {
      className: "action-content"
    }, /*#__PURE__*/React.createElement("h4", null, "\u51B3\u5B9A\u7684\u884C\u52A8:"), /*#__PURE__*/React.createElement("p", null, step.action)), step.toolUsed && /*#__PURE__*/React.createElement("div", {
      className: "tool-result"
    }, /*#__PURE__*/React.createElement("h4", null, "\u5DE5\u5177\u7ED3\u679C:"), /*#__PURE__*/React.createElement("pre", null, formatToolResult(step.toolResult)))));
  })));
};

// 创建一个流程图组件，以可视化方式展示Agent处理流程
const AgentFlowVisualizer = _ref2 => {
  let {
    thoughtProcess
  } = _ref2;
  if (thoughtProcess.length === 0) {
    return /*#__PURE__*/React.createElement("div", {
      className: "agent-flow-visualizer empty"
    }, /*#__PURE__*/React.createElement("p", null, "\u6CA1\u6709\u5904\u7406\u8BB0\u5F55"));
  }

  // 构建流程数据
  const flowSteps = [];

  // 添加初始分析步骤
  flowSteps.push({
    type: 'analysis',
    name: '初始分析',
    time: formatTime(thoughtProcess[0].timestamp - 1000)
  });

  // 添加每个思考和工具调用步骤
  thoughtProcess.forEach((step, index) => {
    if (step.toolUsed) {
      flowSteps.push({
        type: 'tool',
        name: step.toolUsed,
        result: !step.toolResult ? '失败' : '成功',
        time: formatTime(step.timestamp)
      });
    } else if (index > 0 || step.action !== 'finish') {
      flowSteps.push({
        type: 'thought',
        name: '思考分析',
        time: formatTime(step.timestamp)
      });
    }
  });

  // 添加决策步骤
  flowSteps.push({
    type: 'decision',
    name: '最终决策',
    time: formatTime(thoughtProcess[thoughtProcess.length - 1].timestamp + 1000)
  });
  function formatTime(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleTimeString();
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "agent-flow-visualizer"
  }, /*#__PURE__*/React.createElement("h3", null, "\u5904\u7406\u6D41\u7A0B\u56FE"), /*#__PURE__*/React.createElement("div", {
    className: "flow-diagram"
  }, flowSteps.map((step, index) => {
    let iconClass = '';
    switch (step.type) {
      case 'analysis':
        iconClass = 'icon-analysis';
        break;
      case 'thought':
        iconClass = 'icon-thought';
        break;
      case 'tool':
        iconClass = 'icon-tool';
        break;
      case 'decision':
        iconClass = 'icon-decision';
        break;
    }
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: index
    }, /*#__PURE__*/React.createElement("div", {
      className: `flow-node ${step.type} ${step.result === '失败' ? 'error' : ''}`
    }, /*#__PURE__*/React.createElement("div", {
      className: `node-icon ${iconClass}`
    }), /*#__PURE__*/React.createElement("div", {
      className: "node-content"
    }, /*#__PURE__*/React.createElement("div", {
      className: "node-title"
    }, step.name), /*#__PURE__*/React.createElement("div", {
      className: "node-time"
    }, step.time))), index < flowSteps.length - 1 && /*#__PURE__*/React.createElement("div", {
      className: "flow-connector"
    }));
  })));
};

// Agent处理结果组件

const AgentResultSummary = _ref3 => {
  let {
    result
  } = _ref3;
  return /*#__PURE__*/React.createElement("div", {
    className: "agent-result-summary"
  }, /*#__PURE__*/React.createElement("h3", null, "\u5904\u7406\u7ED3\u679C"), /*#__PURE__*/React.createElement("div", {
    className: "result-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "result-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "confidence-meter",
    title: `置信度: ${Math.round(result.confidence * 100)}%`
  }, /*#__PURE__*/React.createElement("div", {
    className: "confidence-fill",
    style: {
      width: `${Math.round(result.confidence * 100)}%`
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "result-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "summary-section"
  }, /*#__PURE__*/React.createElement("h4", null, "\u6D88\u606F\u603B\u7ED3"), /*#__PURE__*/React.createElement("p", null, result.summary)), /*#__PURE__*/React.createElement("div", {
    className: "decisions-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: `decision-badge ${result.isImportant ? 'important' : 'not-important'}`
  }, result.isImportant ? '重要' : '非重要'), /*#__PURE__*/React.createElement("div", {
    className: `decision-badge ${result.shouldStore ? 'store' : 'no-store'}`
  }, result.shouldStore ? '已存储' : '未存储'), /*#__PURE__*/React.createElement("div", {
    className: `decision-badge ${result.shouldNotify ? 'notify' : 'no-notify'}`
  }, result.shouldNotify ? '已通知' : '未通知')), result.reasonsToStore && result.reasonsToStore.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "reasons-section"
  }, /*#__PURE__*/React.createElement("h4", null, "\u5B58\u50A8\u7406\u7531"), /*#__PURE__*/React.createElement("ul", null, result.reasonsToStore.map((reason, index) => /*#__PURE__*/React.createElement("li", {
    key: index
  }, reason)))))));
};

/******/ })()
;
//# sourceMappingURL=agentVisualizer.js.map