/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 70378:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   V: () => (/* binding */ IntelligentAgent)
/* harmony export */ });
/* unused harmony export registerTool */
/* harmony import */ var _llm__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(68400);
/* harmony import */ var _vectorStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9041);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(43922);
/**
 * 智能Agent系统 - 新版实现
 * 基于新的接口设计，提供通用分析框架
 */





/**
 * 工具接口定义
 */

/**
 * 参数定义接口
 */

/**
 * 工具注册表
 */
const toolRegistry = {};

/**
 * 注册工具
 */
function registerTool(tool) {
  toolRegistry[tool.id] = tool;
  console.log(`工具已注册: ${tool.name} (${tool.id})`);
}

// 导入旧版IntelligentAgent相关接口以支持兼容层
// 从旧版intelligentAgent.ts文件导出的接口

/**
 * 思考结果接口
 */

/**
 * 行动历史记录项
 */

/**
 * 思考步骤
 */

/**
 * 核心智能Agent类，提供通用分析框架
 */
class IntelligentAgent {
  constructor() {
    this.thoughtProcess = [];
    this.aggregateLlmCallCount = 0;
    this.aggregateLlmCallTokens = 0;
    // 确保工具已注册
    this.initializeDefaultTools();
  }

  /**
   * 初始化并注册默认工具
   */
  initializeDefaultTools() {
    // 检查工具是否已经注册，避免重复注册
    if (Object.keys(toolRegistry).length > 0) {
      return;
    }

    // 历史消息搜索工具
    registerTool({
      id: 'historySearch',
      name: '历史消息搜索',
      description: '搜索与当前消息相关的历史消息',
      parameterDefs: [{
        name: 'content',
        description: '作为搜索上下文的消息内容',
        required: true,
        type: 'string'
      }, {
        name: 'customQuery',
        description: '自定义搜索查询',
        required: false,
        type: 'string'
      }, {
        name: 'people',
        description: '需要包含的人物名称数组',
        required: false,
        type: 'string[]'
      }, {
        name: 'projects',
        description: '需要包含的项目名称数组',
        required: false,
        type: 'string[]'
      }, {
        name: 'timeRange',
        description: '时间范围',
        required: false,
        type: 'object'
      }, {
        name: 'limit',
        description: '返回结果数量限制',
        required: false,
        type: 'number',
        defaultValue: 5
      }],
      execute: async params => {
        // 构建搜索查询
        const query = params.customQuery || `与以下内容相关的消息: ${params.content.substring(0, 100)}...`;
        const filters = {};

        // 如果提供了特定筛选条件
        if (params.people?.length) {
          filters.entities = {
            people: params.people.map(name => ({
              name,
              required: true
            }))
          };
        }
        if (params.projects?.length) {
          if (!filters.entities) filters.entities = {};
          filters.entities.projects = params.projects.map(name => ({
            name,
            required: true
          }));
        }
        if (params.timeRange) {
          filters.timeRange = params.timeRange;
        }
        const result = await (0,_vectorStore__WEBPACK_IMPORTED_MODULE_1__/* .naturalLanguageQuery */ .Az)(query, filters, {
          limit: params.limit || 5,
          sort: {
            field: 'timestamp',
            order: 'desc'
          }
        });
        console.log('历史消息搜索结果:', result);
        return {
          message: `「${params.content.substring(0, 100)}...」相关历史消息：\n  - ${result.results.documents.map((doc, index) => `${result.results.metadatas[index].summary}——${result.results.metadatas[index].source}`).join('\n  - ')}`,
          result: result.results.documents.map((doc, index) => ({
            summary: result.results.metadatas[index].summary,
            sender: result.results.metadatas[index].source
          }))
        };
      }
    });

    // 添加JIRA查询缓存
    const jiraCache = {};

    // 缓存有效期（毫秒）
    const JIRA_CACHE_TTL = 30 * 60 * 1000; // 30分钟

    registerTool({
      id: 'jiraQuery',
      name: 'JIRA信息查询',
      description: '直接调用JIRA REST API查询任务、需求和bug信息。如果有issueId可直接查询单issue结果，否则用其他参数进行多issues查询',
      parameterDefs: [{
        name: 'issueId',
        description: 'JIRA任务ID/key，例如 PROJ-1234',
        required: false,
        type: 'string'
      }, {
        name: 'issueIds',
        description: '多个JIRA任务ID/key，例如 ["PROJ-1234", "PROJ-1235"]',
        required: false,
        type: 'array'
      }, {
        name: 'keywords',
        description: '搜索关键词，使用JQL中的text搜索',
        required: false,
        type: 'string'
      }, {
        name: 'forceRefresh',
        description: '强制刷新缓存，不使用已缓存的数据',
        required: false,
        type: 'boolean',
        defaultValue: false
      }],
      execute: async params => {
        try {
          // 从环境配置或参数中获取JIRA连接信息
          const envConfig = await (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .getEnvConfig */ .Un)();
          const jiraBaseUrl = envConfig.JIRA_BASE_URL || 'https://your-domain.atlassian.net';
          const apiToken = envConfig.JIRA_API_TOKEN;
          const excludeCommentKeyworkds = ['Esone\'s AI', 'SDET bot'];

          // 检查认证信息是否可用
          if (!apiToken) {
            return {
              success: false,
              source: 'jira-api',
              error: '缺少JIRA认证信息，请在参数中提供username和apiToken或在环境配置中设置'
            };
          }

          // 生成缓存键
          let cacheKey = '';
          if (params.issueId) {
            cacheKey = `issue-${params.issueId}`;
          } else {
            // 使用JQL参数生成缓存键
            const jqlParams = [params.project ? `project=${params.project}` : '', params.status ? `status=${params.status}` : '', params.keywords ? `keywords=${params.keywords}` : ''].filter(Boolean).join('&');
            cacheKey = `search-${jqlParams}`;
          }

          // 检查缓存是否有效且未过期
          const now = Date.now();
          const cacheEntry = jiraCache[cacheKey];
          if (!params.forceRefresh && cacheEntry && cacheEntry.expiresAt > now) {
            console.log(`使用缓存的JIRA数据: ${cacheKey}`);
            return cacheEntry.data;
          }

          // 为Basic认证创建Authorization头
          const authHeader = `Bearer ${apiToken}`;
          let result;
          let resultMessage = '';
          // 处理不同的查询类型
          if (params.issueId) {
            // 查询单个JIRA问题
            const issueUrl = `${jiraBaseUrl}/rest/api/2/issue/${params.issueId}`;
            const response = await fetch(issueUrl, {
              method: 'GET',
              headers: {
                'Accept': 'application/json',
                'Authorization': authHeader
              }
            });
            if (!response.ok) {
              const errorText = await response.text();
              throw new Error(`查询JIRA问题失败 (${response.status}): ${errorText}`);
            }
            const responseData = await response.json();
            result = {
              summary: responseData.fields.summary,
              status: responseData.fields.status.name,
              assignee: responseData.fields.assignee?.displayName || '',
              reporter: responseData.fields.reporter?.displayName || '',
              priority: responseData.fields.priority.name,
              issuetype: responseData.fields.issuetype.name,
              duedate: responseData.fields.duedate,
              comments: responseData.fields.comment.comments.splice(-3).map(comment => comment.author.displayName + ': ' + comment.body).filter(comment => !excludeCommentKeyworkds.some(keyword => comment.includes(keyword))),
              description: responseData.fields.description
            };
            resultMessage = `[${params.issueId}][${result.status}]的查询数据: ${result.summary}\n - 执行者: ${result.assignee}\n - 预计完成时间: ${result.duedate}\n - 评论:\n  - ${result.comments.join('\n  - ').replace('\n', '')}`;
          } else {
            // 构建JQL查询
            let jql = '';
            if (params.project) {
              jql += `project = ${params.project}`;
            }
            if (params.status) {
              jql += jql ? ` AND status = "${params.status}"` : `status = "${params.status}"`;
            }
            if (params.keywords) {
              const keywordQuery = `text ~ "${params.keywords}"`;
              jql += jql ? ` AND ${keywordQuery}` : keywordQuery;
            }

            // 如果没有任何条件，搜索最近更新的问题
            if (!jql) {
              jql = 'updated >= -30d ORDER BY updated DESC';
            }
            console.log(`执行JQL查询: ${jql}`);

            // 使用POST方法进行搜索以处理可能较长的JQL
            const searchUrl = `${jiraBaseUrl}/rest/api/2/search`;
            const response = await fetch(searchUrl, {
              method: 'POST',
              headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': authHeader
              },
              body: JSON.stringify({
                jql: jql,
                maxResults: 10,
                fields: ['summary', 'status', 'assignee', 'description', 'priority', 'issuetype', 'created', 'updated', 'duedate', 'reporter']
              })
            });
            if (!response.ok) {
              const errorText = await response.text();
              throw new Error(`JIRA搜索查询失败 (${response.status}): ${errorText}`);
            }
            result = await response.json();
            resultMessage = result.issues.map(issue => `[${issue.key}][${issue.fields.status.name}]${issue.fields.summary}`).join('\n');
          }

          // 存储结果到缓存
          jiraCache[cacheKey] = {
            data: {
              message: resultMessage,
              result
            },
            timestamp: now,
            expiresAt: now + JIRA_CACHE_TTL
          };
          return {
            message: resultMessage,
            result
          };
        } catch (error) {
          console.error('JIRA API查询失败:', error);

          // 增强错误消息
          let errorMessage = '查询JIRA时发生错误';
          if (error.message) {
            errorMessage = error.message;

            // 细化错误消息
            if (error.message.includes('401')) {
              errorMessage = `JIRA认证失败: ${error.message}。请检查用户名和API令牌是否正确。`;
            } else if (error.message.includes('403')) {
              errorMessage = `JIRA权限不足: ${error.message}。请确保用户有权访问请求的资源。`;
            } else if (error.message.includes('404')) {
              errorMessage = `JIRA资源未找到: ${error.message}。请检查JIRA基础URL和问题ID是否正确。`;
            } else if (error.message.includes('400')) {
              errorMessage = `JIRA请求无效: ${error.message}。请检查JQL查询语法。`;
            }
          }
          return {
            success: false,
            source: 'jira-api',
            message: errorMessage,
            originalError: error
          };
        }
      }
    });
    /* 
        // 组织架构查询工具
        registerTool({
          id: 'orgStructure',
          name: '组织架构查询',
          description: '查询人员的组织架构关系',
          execute: async (params) => {
            // 模拟实现，实际环境中需要集成组织架构API
            console.log(`查询组织架构信息: ${JSON.stringify(params)}`);
            
            if (params.person) {
              return {
                message: `人员 ${params.person} 的查询数据: 角色: 高级工程师, 部门: 研发部, 经理: 张经理, 下属: 李工程师, 王工程师, 同事: 高工程师, 刘工程师`,
                result: {
                  success: true,
                  person: params.person,
                  role: '高级工程师',
                  department: '研发部',
                  manager: '张经理',
                  directReports: ['李工程师', '王工程师'],
                  peers: ['高工程师', '刘工程师']
                }
              };
            }
            
            if (params.department) {
              return {
                message: `部门 ${params.department} 的查询数据: 部门负责人: 李总监, 成员: 张经理, 高工程师, 李工程师, 王工程师, 刘工程师`,
                result: {
                  success: true,
                  department: params.department,
                  head: '李总监',
                  members: ['张经理', '高工程师', '李工程师', '王工程师', '刘工程师']
                }
              };
            }
            
            return {
              success: false,
              message: '缺少必要的组织架构查询参数'
            };
          }
        });
    
        // 发布任务查询工具
        registerTool({
          id: 'releaseTaskQuery',
          name: '发布任务查询',
          description: '查询本月发布任务信息',
          execute: async (params) => {
            // 模拟实现，实际环境中需要集成相关API
            console.log(`查询发布任务信息: ${JSON.stringify(params)}`);
            
            const now = new Date();
            const thisMonth = now.getMonth() + 1;
            const thisYear = now.getFullYear();
            
            return {
              message: `本月发布任务信息: ${thisYear}-${thisMonth}`,
              result: {
                success: true,
                month: `${thisYear}-${thisMonth}`,
                releases: [
                  {
                    id: 'REL-2023-001',
                    name: '产品A 3.5版本',
                    scheduledDate: '2023-10-15',
                    status: '准备中',
                    features: ['功能1', '功能2', '功能3'],
                    owner: '张发布经理'
                  },
                  {
                    id: 'REL-2023-002',
                    name: '产品B 2.0版本',
                    scheduledDate: '2023-10-25',
                    status: '规划中',
                    features: ['新功能A', '性能优化'],
                    owner: '李发布经理'
                  }
                ]
              }
            };
          }
        });
    
        // Sprint数据查询工具
        registerTool({
          id: 'sprintDataQuery',
          name: 'Sprint数据查询',
          description: '查询当前Sprint的进度和bug数据',
          execute: async (params) => {
            // 模拟实现，实际环境中需要集成相关API
            console.log(`查询Sprint数据: ${JSON.stringify(params)}`);
            
            return {
              message: `当前Sprint数据: ${params.sprintId}`,
              result: {
                success: true,
                sprintId: params.sprintId,
                name: '2023年10月第2个Sprint',
                startDate: '2023-10-09',
                endDate: '2023-10-20',
                progress: {
                  totalStoryPoints: 120,
                  completedStoryPoints: 45,
                  completionPercentage: 37.5
                },
                bugs: {
                  total: 24,
                  critical: 2,
                  major: 8,
                  minor: 14,
                  resolved: 10,
                  pending: 14
                },
                topContributors: ['张工程师', '李工程师', '王测试']
              }
            };
          }
        }); */
  }

  /**
   * 分析任何类型的输入并返回适当的分析结果
   */
  async analyze(input, config, context, onStepCompleted) {
    // 根据配置选择合适的分析流程
    switch (config.type) {
      case 'message':
        return this.analyzeMessage(input, config, context, onStepCompleted);
      case 'project':
        return this.analyzeProject(input, config, context);
      case 'meeting':
        return this.analyzeMeeting(input, config, context);
      case 'document':
        return this.analyzeDocument(input, config, context);
      default:
        return this.analyzeGeneric(input, config, context);
    }
  }

  /**
   * 批量分析多个项目
   */
  async analyzeBatch(items, config, context, onProgress) {
    const results = [];
    for (let i = 0; i < items.length; i++) {
      const result = await this.analyze(items[i], config, context);
      if (onProgress) {
        onProgress(result);
      }
      results.push(result);
    }
    return results;
  }

  /**
   * 分析消息
   */
  async analyzeMessage(input, config, context, onEveryGroupCompleted) {
    // 检测输入格式
    const format = this.detectMessageFormat(input);
    console.log(`检测到消息格式: ${format}`);

    // 根据消息格式决定处理方式
    if (format === 'message_groups') {
      // 处理多个消息组
      const results = [];

      // 获取环境配置
      const envConfig = await (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .getEnvConfig */ .Un)();
      if (envConfig.ANALYZE_BY_GROUP === true) {
        // 为每个消息组单独批量处理
        for (let i = 0; i < input.length; i++) {
          const group = input[i];
          const groupContext = {
            ...context,
            groupInfo: {
              id: group.groupId,
              index: i,
              name: group.groupName,
              members: group.members || []
            }
          };

          // 提取组中的消息并标准化
          const groupMessages = group.posts.map(post => ({
            messageContent: post.content,
            sender: post.sender,
            datetime: post.datetime,
            groupName: group.groupName,
            groupId: group.groupId,
            postId: post.post_id
          }));

          // 分析该组的消息
          const groupResults = await this.analyzeGroupMessages(groupMessages, config, groupContext, onEveryGroupCompleted);
          results.push(...groupResults);
        }
      } else {
        // 将所有消息组合并处理
        const allMessages = [];
        for (const group of input) {
          const groupMessages = group.posts.map(post => ({
            messageContent: post.content,
            sender: post.sender,
            datetime: post.datetime,
            groupName: group.groupName,
            groupId: group.groupId,
            postId: post.post_id
          }));
          allMessages.push(...groupMessages);
        }
        const globalContext = {
          ...context,
          groupInfo: {
            id: '',
            name: '多群组分析',
            members: []
          }
        };
        const groupResults = await this.analyzeGroupMessages(allMessages, config, globalContext, onEveryGroupCompleted);
        results.push(...groupResults);
      }
      return results;
    } else if (format === 'message_group') {
      // 处理单个消息组
      const groupContext = {
        ...context,
        groupInfo: {
          id: input.groupId,
          name: input.groupName,
          members: input.members || []
        }
      };

      // 提取消息并标准化
      const messages = input.posts.map(post => ({
        messageContent: post.content,
        sender: post.sender,
        datetime: post.datetime,
        groupName: input.groupName,
        groupId: input.groupId,
        postId: post.post_id
      }));

      // 分析消息
      return await this.analyzeGroupMessages(messages, config, groupContext, onEveryGroupCompleted);
    } else {
      // 处理单条消息
      // 标准化
      const normalizedInput = this.normalizeInput(input, config);

      // 将单条消息转换为数组进行处理
      const results = await this.analyzeGroupMessages([normalizedInput], config, context, onEveryGroupCompleted);

      // 返回第一个结果
      return results[0];
    }
  }

  /**
   * 分析消息组
   * 处理标准化后的消息数组
   * 降噪处理
   */
  async analyzeGroupMessages(messages, config, context, onGroupCompleted) {
    try {
      if (messages.length === 0) {
        return [];
      }

      // 初始化统计
      let llmCallCount = 0;
      let llmCallTokens = 0;
      let groupIndex = 0;
      const usedTools = new Set();

      // 调用LLM分析
      const analysisResult = await this.initialAnalysis(messages, config, context);

      // 记录初始LLM调用
      llmCallCount += 1;
      llmCallTokens += this.estimateTokens(messages, analysisResult);

      // 准备最终结果数组
      const finalResults = [];

      // 为每条消息进行深度分析（思考-行动循环）
      for (let i = 0; i < messages.length; i++) {
        const message = messages[i];
        const analysis = analysisResult.find(r => r.messageIndex === i) || {
          summary: "没有分析结果",
          importanceLevel: "low",
          needsProcessing: false,
          isNoiseMessage: false
        };

        // 如果是噪音消息且不需要处理，创建简化的结果
        if (analysis.isNoiseMessage === true && analysis.needsProcessing === false) {
          finalResults.push({
            type: 'message',
            messageIndex: i,
            groupIndex: context.groupInfo?.index || groupIndex,
            messageContext: message,
            isImportant: false,
            shouldNotify: false,
            shouldStore: false,
            reasonsToStore: [],
            confidence: 1.0,
            // 高确信度，这是噪音消息
            summary: analysis.summary || "噪音消息",
            thoughtProcess: [{
              timestamp: Date.now(),
              thought: "经分析，这是噪音消息，无需进一步处理",
              action: "跳过处理"
            }]
          });
          if (i === messages.length - 1 || messages[i].team_id !== messages[i + 1]?.team_id) {
            groupIndex++;
            // 找出当前组的所有消息结果
            const currentGroupResults = finalResults.filter(r => r.groupId === message.team_id);
            // 调用回调函数
            if (onGroupCompleted && currentGroupResults.length > 0) {
              onGroupCompleted(currentGroupResults);
            }
          }
          continue;
        }
        const messageThoughtProcess = [];
        const messageUsedTools = [];
        const result = {
          type: 'message',
          messageIndex: i,
          groupIndex: context.groupInfo?.index || groupIndex,
          isImportant: analysis.importanceLevel === "high",
          shouldStore: false,
          shouldNotify: false,
          confidence: 0,
          summary: analysis.summary || "",
          enrichedData: {
            entities: analysis.entities || {},
            relationships: analysis.relationships || [],
            actions: analysis.actions || [],
            sentiment: analysis.sentiment || 'neutral',
            category: analysis.category || []
          },
          reasonsToStore: [],
          thoughtProcess: messageThoughtProcess,
          messageContext: message,
          matchedRule: analysis.matchedRules && analysis.matchedRules.length > 0 ? analysis.matchedRules.join('; ') : '',
          metaData: {
            llmCallCount: 0,
            llmCallTokens: 0,
            usedTools: messageUsedTools,
            timestamp: Date.now()
          }
        };

        // 执行思考-行动循环
        this.loopThinking(result, message, analysis, config, context, usedTools);

        // 添加到最终结果列表
        finalResults.push(result);

        // 每条消息处理完成后，检查是否所有同一组的消息都已处理完毕
        if (i === messages.length - 1 || messages[i].team_id !== messages[i + 1]?.team_id) {
          groupIndex++;
          // 找出当前组的所有消息结果
          const currentGroupResults = finalResults.filter(r => r.groupId === message.team_id);
          // 调用回调函数
          if (onGroupCompleted && currentGroupResults.length > 0) {
            onGroupCompleted(currentGroupResults);
          }
        }

        // 记录批量处理完成
        const batchEndStep = {
          timestamp: Date.now(),
          thought: `完成批量处理 ${messages.length} 条消息，其中 ${finalResults.filter(r => r.shouldStore).length} 条被存储，${finalResults.filter(r => r.shouldNotify).length} 条需要通知。共调用 LLM ${this.aggregateLlmCallCount} 次，估计使用 ${this.aggregateLlmCallTokens} tokens，使用工具：${Array.from(usedTools).join(', ')}`,
          action: '完成批量处理'
        };
        this.thoughtProcess.push(batchEndStep);
        result.thoughtProcess.push(batchEndStep);
        console.log(`智能Agent批量处理完成，共处理 ${finalResults.length} 条消息，其中 ${finalResults.filter(r => r.shouldStore).length} 条被存储，${finalResults.filter(r => r.shouldNotify).length} 条需要通知。共调用 LLM ${this.aggregateLlmCallCount} 次，估计使用 ${this.aggregateLlmCallTokens} tokens，使用工具：${Array.from(usedTools).join(', ')}`);
        return finalResults;
      }
    } catch (error) {
      console.error('智能Agent批量处理消息失败:', error);

      // 记录错误
      this.thoughtProcess.push({
        timestamp: Date.now(),
        thought: error.message,
        action: '终止处理'
      });

      // 返回错误结果
      const errorResults = messages.map((message, index) => ({
        type: 'message',
        messageIndex: index,
        isImportant: false,
        shouldStore: false,
        shouldNotify: false,
        confidence: 0,
        summary: `批量处理失败: ${error.message}`,
        reasonsToStore: [],
        messageContext: message,
        metaData: {
          llmCallCount: this.aggregateLlmCallCount,
          llmCallTokens: this.aggregateLlmCallTokens,
          usedTools: Array.from(new Set()),
          timestamp: Date.now()
        }
      }));

      // 调用回调函数，通知处理失败
      if (onGroupCompleted) {
        onGroupCompleted(errorResults);
      }
      return errorResults;
    }
  }

  /**
   * 获取可用工具列表
   */
  getAvailableTools() {
    // 根据配置返回工具列表
    return Object.values(toolRegistry);
  }

  /**
   * 获取工具描述文本
   */
  getToolDescriptions() {
    return this.getAvailableTools().map(tool => {
      let description = `- ${tool.name} (${tool.id}): ${tool.description}`;

      // 添加参数描述
      if (tool.parameterDefs && tool.parameterDefs.length > 0) {
        description += '\n  参数:';
        for (const param of tool.parameterDefs) {
          const requiredMark = param.required ? '(必填)' : '(可选)';
          const typeMark = param.type ? `[${param.type}]` : '';
          const optionsMark = param.options ? ` 可选值:${param.options.join('/')}` : '';
          description += `\n    - ${param.name} ${requiredMark} ${typeMark}: ${param.description}${optionsMark}`;
        }
      }
      return description;
    });
  }

  /**
   * 估算token数量
   */
  estimateTokens(input, output) {
    // 一个简单的估算方法是计算字符数，然后按照一定比例转换为tokens
    // 英文中大约每4个字符为1个token，为了简化我们使用字符数/4作为token估算
    const inputStr = typeof input === 'string' ? input : JSON.stringify(input);
    const outputStr = typeof output === 'string' ? output : JSON.stringify(output);
    const totalChars = inputStr.length + outputStr.length;
    const estimatedTokens = Math.ceil(totalChars / 4);
    return estimatedTokens;
  }

  /**
   * 执行思考-行动循环
   * 抽取自原analyzeMessage方法，用于单条消息的深度分析
   */
  async loopThinking(result, normalizedInput, initialAnalysis, config, context) {
    let usedTools = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : new Set();
    // 初始化统计
    let llmCallCount = result.metaData.llmCallCount || 0;
    let llmCallTokens = result.metaData.llmCallTokens || 0;

    // 思考-行动循环
    const maxActions = config.maxActions || 5;
    const currentState = {
      input: normalizedInput,
      analysis: initialAnalysis,
      result,
      memory: {},
      actionCount: 0,
      config,
      context,
      actionHistory: [],
      currentDecision: {
        confidence: result.confidence,
        summary: result.summary,
        // message
        reasons: result.reasonsToStore || [],
        isImportant: !!result.isImportant,
        shouldStore: !!result.shouldStore,
        shouldNotify: !!result.shouldNotify,
        notificationPriority: result.notificationPriority,
        replyAdvice: result.replyAdvice,
        // project
        riskLevel: result.riskLevel,
        suggestions: result.suggestions || {}
      }
    };
    while (currentState.actionCount < maxActions) {
      // 思考下一步
      let thoughtResult;
      if (currentState.actionCount > 0) {
        thoughtResult = await this.think(currentState);
        llmCallCount += 1;
        llmCallTokens += this.estimateTokens(currentState, thoughtResult); // todo: 评估buildPromptTokens
      } else {
        thoughtResult = {
          thought: initialAnalysis.thought || '',
          nextAction: initialAnalysis.nextAction || 'finish',
          tools: initialAnalysis.tools || []
        };
      }

      // 记录思考过程
      const thoughtStep = {
        timestamp: Date.now(),
        thought: thoughtResult.thought,
        action: thoughtResult.nextAction
      };
      this.thoughtProcess.push(thoughtStep);
      result.thoughtProcess.push(thoughtStep);

      // 检查是否结束
      if (thoughtResult.nextAction === 'finish') {
        // 更新最终决策
        this.updateFinalDecision(result, thoughtResult, currentState);
        break;
      }

      // 执行工具
      if (thoughtResult.tools && thoughtResult.tools.length > 0) {
        await this.executeTools(thoughtResult.tools, currentState, thoughtStep, usedTools);

        // 特殊处理某些工具的结果
        thoughtResult.tools.forEach(tool => {
          // 如果是存储或通知工具，更新最终结果
          if (tool.id === 'messageStore') {
            result.shouldStore = true;
            currentState.currentDecision.shouldStore = true;
          } else if (tool.id === 'notifier') {
            result.shouldNotify = true;
            currentState.currentDecision.shouldNotify = true;
          }
        });
        if (thoughtResult.tools.some(tool => tool.id === 'jiraQuery') && currentState.memory['jiraQuery']) {
          const latestJiraResult = currentState.memory['jiraQuery'][currentState.memory['jiraQuery'].length - 1];
          if (latestJiraResult && latestJiraResult.result) {
            result.jiraData = {
              ...result.jiraData,
              ...latestJiraResult.result
            };
          }
        }
      }

      // 增加行动计数
      currentState.actionCount++;
    }

    // 更新元数据
    result.metaData.llmCallCount = llmCallCount;
    result.metaData.llmCallTokens = llmCallTokens;
    result.metaData.usedTools = Array.from(usedTools);
    this.aggregateLlmCallCount += llmCallCount;
    this.aggregateLlmCallTokens += llmCallTokens;
  }

  /**
   * 检测消息格式
   * 从全局函数移动到类方法
   */
  detectMessageFormat(input) {
    if (Array.isArray(input) && input[0].posts && Array.isArray(input[0].posts)) {
      return 'message_groups'; // 多个消息组
    } else if (input.posts && Array.isArray(input.posts)) {
      return 'message_group'; // 单个消息组
    } else if (input.message_content || input.content) {
      return 'single_message'; // 单个消息
    } else {
      console.warn('未知的消息格式:', input);
      return 'unknown';
    }
  }

  /**
   * 更新最终决策
   */
  updateFinalDecision(result, thoughtResult, state) {
    // 更新消息分析结果
    if (result.type === 'message') {
      if (thoughtResult.isImportant !== undefined) {
        result.isImportant = thoughtResult.isImportant;
        state.currentDecision.isImportant = thoughtResult.isImportant;
      }
      if (thoughtResult.shouldStore !== undefined) {
        result.shouldStore = thoughtResult.shouldStore;
        state.currentDecision.shouldStore = thoughtResult.shouldStore;
      }
      if (thoughtResult.shouldNotify !== undefined) {
        result.shouldNotify = thoughtResult.shouldNotify;
        state.currentDecision.shouldNotify = thoughtResult.shouldNotify;
      }
      if (thoughtResult.confidence !== undefined) {
        result.confidence = thoughtResult.confidence;
        state.currentDecision.confidence = thoughtResult.confidence;
      }
      if (thoughtResult.summary) {
        result.summary = thoughtResult.summary;
        state.currentDecision.summary = thoughtResult.summary;
      }
      if (thoughtResult.reasons) {
        result.reasonsToStore = thoughtResult.reasons;
        state.currentDecision.reasons = thoughtResult.reasons;
      }
      if (thoughtResult.notificationPriority) {
        result.notificationPriority = thoughtResult.notificationPriority;
        state.currentDecision.notificationPriority = thoughtResult.notificationPriority;
      }
      if (thoughtResult.replyAdvice) {
        result.replyAdvice = thoughtResult.replyAdvice;
        state.currentDecision.replyAdvice = thoughtResult.replyAdvice;
      }
    }
    // 更新项目分析结果
    else if (result.type === 'project') {
      if (thoughtResult.riskLevel) {
        result.riskLevel = thoughtResult.riskLevel;
        state.currentDecision.riskLevel = thoughtResult.riskLevel;
      }
      if (thoughtResult.confidence !== undefined) {
        result.confidence = thoughtResult.confidence;
        state.currentDecision.confidence = thoughtResult.confidence;
      }
      if (thoughtResult.summary) {
        result.summary = thoughtResult.summary;
        state.currentDecision.summary = thoughtResult.summary;
      }
      if (thoughtResult.suggestions) {
        result.suggestions = {
          ...result.suggestions,
          ...thoughtResult.suggestions
        };
        state.currentDecision.suggestions = result.suggestions;
      }
      if (thoughtResult.timeline) {
        result.timeline = thoughtResult.timeline;
      }
      if (thoughtResult.resourceAllocation) {
        result.resourceAllocation = thoughtResult.resourceAllocation;
      }
    }
    // 如果需要，可以添加其他类型的结果更新逻辑
  }

  /**
   * 分析项目
   */
  async analyzeProject(input, config, context) {
    // 初始化思考过程记录
    this.thoughtProcess = [];

    // 初始化统计
    let llmCallCount = 0;
    let llmCallTokens = 0;
    const usedTools = new Set();
    try {
      // 标准化输入
      const normalizedInput = this.normalizeInput(input, config);

      // 初始分析
      const initialAnalysis = await this.initialAnalysis(normalizedInput, config, context);
      llmCallCount += 1;
      llmCallTokens += this.estimateTokens(normalizedInput, initialAnalysis);

      // 创建初始结果对象
      const result = {
        type: 'project',
        confidence: initialAnalysis.confidence || 0,
        summary: initialAnalysis.summary || '',
        projectId: normalizedInput.id || normalizedInput.project?.id || '',
        projectName: normalizedInput.name || normalizedInput.project?.name || '',
        riskLevel: initialAnalysis.riskLevel || 'normal',
        timeline: initialAnalysis.timeline || {
          onTrack: true,
          concerns: []
        },
        resourceAllocation: initialAnalysis.resourceAllocation || {
          concerns: []
        },
        suggestions: initialAnalysis.suggestions || {},
        thoughtProcess: [],
        metaData: {
          llmCallCount,
          llmCallTokens,
          usedTools: Array.from(usedTools),
          timestamp: Date.now()
        }
      };

      // 如果有Jira数据，添加到结果
      if (initialAnalysis.jiraData) {
        result.jiraData = initialAnalysis.jiraData;
      }

      // 执行思考-行动循环
      await this.loopThinking(result, normalizedInput, initialAnalysis, config, context, usedTools);
      return result;
    } catch (error) {
      console.error('项目分析失败:', error);
      return {
        type: 'project',
        confidence: 0,
        summary: `分析失败: ${error.message}`,
        projectId: input.id || input.project?.id || '',
        projectName: input.name || input.project?.name || '',
        riskLevel: 'normal',
        metaData: {
          llmCallCount,
          llmCallTokens,
          usedTools: Array.from(usedTools),
          timestamp: Date.now()
        },
        suggestions: {}
      };
    }
  }

  /**
   * 执行工具
   */
  async executeTool(toolId, params, state) {
    // 检查工具是否存在
    if (!toolRegistry[toolId]) {
      throw new Error(`未找到工具: ${toolId}`);
    }
    const tool = toolRegistry[toolId];

    // 验证必填参数
    if (tool.parameterDefs) {
      for (const param of tool.parameterDefs) {
        if (param.required && (params[param.name] === undefined || params[param.name] === null)) {
          throw new Error(`工具 ${toolId} 缺少必填参数: ${param.name}`);
        }
      }
    }

    // 执行工具
    try {
      const result = await tool.execute(params, state);
      return result;
    } catch (error) {
      console.error(`工具 ${toolId} 执行错误:`, error);
      throw error;
    }
  }

  /**
   * 批量执行多个工具
   */
  async executeTools(tools, state, thoughtStep, usedTools) {
    if (!tools || tools.length === 0) {
      return {};
    }
    thoughtStep.toolUsed = tools.join(', '); // 记录所有使用的工具

    // 并发执行所有选择的工具
    const toolPromises = tools.map(async t => {
      const toolId = t.id;
      const tool = toolRegistry[toolId];
      if (!tool) {
        console.warn(`未找到工具: ${toolId}`);
        return {
          toolId,
          error: `未找到工具: ${toolId}`
        };
      }
      console.log(`执行工具: ${tool.name} (${tool.id})`, t.params);
      try {
        const toolResult = await tool.execute(t.params, state);

        // 添加到已使用工具集合
        usedTools.add(toolId);
        return {
          toolId: tool.id,
          params: t.params,
          result: toolResult
        };
      } catch (error) {
        console.error(`工具执行失败: ${tool.id}`, error);
        return {
          toolId: tool.id,
          error: `工具执行失败: ${error.message}`
        };
      }
    });

    // 等待所有工具执行完毕
    const toolResults = await Promise.all(toolPromises);

    // 更新思考步骤结果
    const resultMap = toolResults.reduce((acc, curr) => {
      acc[curr.toolId] = curr.error ? {
        error: curr.error
      } : curr.result;
      return acc;
    }, {});

    // 将执行结果添加到思考步骤
    thoughtStep.toolResult = JSON.stringify(resultMap);

    // 将所有工具结果存入内存
    toolResults.forEach(tr => {
      if (!tr.error) {
        if (!state.memory[tr.toolId]) {
          state.memory[tr.toolId] = [];
        }
        state.memory[tr.toolId].push({
          params: tr.params,
          result: tr.result
        });

        // 记录到动作历史
        state.actionHistory.push({
          tool: tr.toolId,
          params: tr.params,
          result: JSON.stringify(tr.result).substring(0, 500) // 限制长度
        });
      }
    });
    return resultMap;
  }

  /**
   * 分析会议
   */
  async analyzeMeeting(input, config, context) {
    // 会议分析的具体实现
    // 实际类似于analyzeMessage，但返回MeetingAnalysisResult

    // 示例实现（实际项目中需要完善）
    return {
      type: 'meeting',
      confidence: 0.8,
      summary: "会议分析结果",
      topics: [],
      decisions: [],
      actionItems: [],
      followups: [],
      metaData: {
        llmCallCount: 1,
        llmCallTokens: 1000,
        usedTools: [],
        timestamp: Date.now()
      }
    };
  }

  /**
   * 分析文档
   */
  async analyzeDocument(input, config, context) {
    // 文档分析的具体实现
    // 未来需要完善

    return {
      type: 'document',
      confidence: 0.8,
      summary: "文档分析结果",
      title: input.title || "未知文档",
      documentType: input.type || "other",
      sections: [],
      keyPoints: [],
      metaData: {
        llmCallCount: 1,
        llmCallTokens: 1000,
        usedTools: [],
        timestamp: Date.now()
      }
    };
  }

  /**
   * 通用分析（当未指定具体类型时）
   */
  async analyzeGeneric(input, config, context) {
    // 通用分析的具体实现
    return {
      type: 'generic',
      confidence: 0.5,
      summary: "通用分析结果",
      metaData: {
        llmCallCount: 1,
        llmCallTokens: 500,
        usedTools: [],
        timestamp: Date.now()
      }
    };
  }

  /**
   * 标准化输入数据格式
   */
  normalizeInput(input, config) {
    // 根据分析类型标准化输入
    const normalized = {
      ...input
    };

    // 消息类型的标准化处理
    if (config.type === 'message') {
      // 确保message_content字段存在
      if (!normalized.message_content && normalized.content) {
        normalized.message_content = normalized.content;
      }

      // 确保groupName和groupId字段存在
      if (!normalized.groupName && normalized.team_name) {
        normalized.groupName = normalized.team_name;
      }
      if (!normalized.groupId && normalized.team_id) {
        normalized.groupId = normalized.team_id;
      }

      // 确保datetime字段存在
      if (!normalized.datetime && normalized.timestamp) {
        normalized.datetime = new Date(normalized.timestamp).toISOString();
      }

      // 如果username字段存在但没有current_user字段，添加它
      if (normalized.username && !normalized.current_user) {
        normalized.current_user = normalized.username;
      }
    }
    return normalized;
  }

  /**
   * 初始LLM分析
   */
  async initialAnalysis(normalizedInput, config, context) {
    // 根据分析类型构建提示
    let analysisPrompt = '';
    switch (config.type) {
      case 'message':
        analysisPrompt = await this.buildMessageAnalysisPrompt(normalizedInput, config, context);
        break;
      case 'project':
        analysisPrompt = this.buildProjectAnalysisPrompt(normalizedInput, config, context);
        break;
      case 'meeting':
        analysisPrompt = this.buildMeetingAnalysisPrompt(normalizedInput, config, context);
        break;
      case 'document':
        analysisPrompt = this.buildDocumentAnalysisPrompt(normalizedInput, config, context);
        break;
      default:
        analysisPrompt = this.buildGenericAnalysisPrompt(normalizedInput, config, context);
    }

    // 如果存在自定义分析提示，则使用自定义提示
    if (config.customPrompts?.analysis) {
      analysisPrompt = config.customPrompts.analysis;
    }
    try {
      // 调用LLM API进行分析
      const analysis = await (0,_llm__WEBPACK_IMPORTED_MODULE_0__/* .callLLMJsonAPI */ .sc)({
        prompt: analysisPrompt,
        type: 'analysis'
      });
      return analysis;
    } catch (error) {
      console.error('初始分析失败:', error);
      // 返回基本分析结果以避免流程中断
      return {
        summary: `分析失败: ${error.message}`,
        importanceLevel: "low",
        needsAttention: false,
        sentiment: "neutral",
        nextAction: "finish",
        tools: [],
        shouldStore: false,
        shouldNotify: false,
        confidence: 0,
        reasons: ["分析失败"],
        entities: {}
      };
    }
  }

  /**
   * 构建消息分析提示
   * 修改以支持不同数量的消息
   */
  async buildMessageAnalysisPrompt(messages, config, context) {
    // 获取环境配置
    const envConfig = await (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .getEnvConfig */ .Un)();
    const analyzeByGroup = envConfig.ANALYZE_BY_GROUP === true;

    // 构建消息内容部分
    const messagesContent = messages.map((msg, index) => {
      return `消息 #${index + 1}:
发送者: ${msg.sender || '未知发送者'}
${messages.length > 1 && !analyzeByGroup ? `所在群组: ${msg.groupName || '未知群组'}` : ''}
时间: ${msg.datetime || '未知时间'}
内容: ${msg.messageContent || '无内容'}`;
    }).join('\n\n');

    // 构建群组上下文信息
    let contextInfo = '';
    if (messages.length > 1 && analyzeByGroup) {
      // 如果是批量分析且按群组分析
      contextInfo = [`群组名称: ${context?.groupInfo?.name || messages[0].groupName || '未知群组'}`, `群组ID: ${context?.groupInfo?.id || messages[0].groupId || '未知ID'}`, context?.currentUser ? `当前用户: ${context.currentUser}` : ''].filter(Boolean).join('\n');
    } else if (messages.length === 1) {
      // 单条消息的上下文
      contextInfo = [`发送者: ${messages[0].sender || '未知发送者'}`, messages[0].groupName ? `群组名称: ${messages[0].groupName}` : '', messages[0].datetime ? `发送时间: ${messages[0].datetime}` : '', context?.currentUser ? `当前用户: ${context.currentUser}` : ''].filter(Boolean).join('\n');
    }

    // 构建关注规则
    const concernedRules = context?.concernedRules || [];
    const filterRulesInfo = concernedRules.length > 0 ? `关注规则:\n${concernedRules.map((rule, i) => `- 规则${i + 1}: ${rule.text}`).join('\n')}` : '';

    // 获取工具描述
    const toolDescriptions = this.getToolDescriptions().join('\n');

    // 构造分析深度提示
    let depthNote = '';
    if (config.analysisDepth === 'quick') {
      depthNote = '注意：这是快速分析，无需使用工具，直接返回基本判断。';
    } else if (config.analysisDepth === 'deep') {
      depthNote = '注意：这是深度分析，尽可能使用多个工具收集完整信息，做出全面判断。';
    }

    // 构建提示前缀
    const promptPrefix = messages.length > 1 ? `分析以下群组中的一组消息，提取关键信息并判断各消息的重要性:` : `分析以下消息，提取关键信息并判断其重要性:`;

    // 构建分析要点
    const analysisPoints = `请分析:
1. 这条消息是关于什么的？简要总结。
2. 消息中提到了哪些人物、项目、时间点或其他关键实体？
3. 消息的情感是正面、负面还是中性的？
4. 消息是否匹配任何上述关注规则？如果是，请指出匹配的规则和原因。
5. 消息的重要程度如何？(低/中/高)
6. 消息是否需要特别关注或回复？
7. 这条消息可能与哪些其他信息或系统(如JIRA, Wiki)相关？
8. 是否建议使用某些工具来进一步处理这条消息？如果是，请推荐工具和参数。
${messages.length > 1 ? `9. 消息间存在什么关联？后续消息是否是对前面消息的回应？` : ''}`;

    // 构建返回格式说明
    const returnFormat = `请以JSON数组格式返回分析结果，每个元素对应一条消息:
[
  {
    ${messages.length > 1 ? '"messageIndex": 0,' : ''}
    "summary": "根据消息上下文，总结消息的简要内容",
    "matchedRules": ["匹配的关注规则1", "匹配的关注规则2"],
    "matchReasons": ["匹配原因1", "匹配原因2"],
    "importanceLevel": "low|medium|high",
    "needsAttention": true|false,
    "needsProcessing": true|false,
    "isNoiseMessage": false,
    "sentiment": "positive|negative|neutral",
    "context": "消息在对话中的角色，如'提问','回答','确认'等",
    "mentionedSystems": ["系统1", "系统2"],
    
    // 决策和工具字段
    "thought": "分析当前情况和下一步行动的详细思考过程",
    "nextAction": "use_tool|finish",
    "tools": [{
      "id": "工具ID",
      "params": {}, // 工具所需参数
    }], // 如果nextAction为use_tool
    "shouldStore": false,
    "shouldNotify": false,
    "confidence": 0.7,
    "reasons": ["存储/忽略的理由1", "理由2"],
    "notificationPriority": "low|medium|high",
    "replyAdvice": "",
    
    // 实体提取结果
    "entities": {
      "people": [{"name": "人名", "role": "角色", "mentioned_context": "提及上下文"}],
      "time": [{"raw": "原始表述", "normalized": "标准化时间", "type": "deadline|schedule|mentioned"}],
      "projects": [{"name": "项目名", "status": "状态", "related_people": []}],
      "topics": [{"name": "主题名", "category": "类别", "keywords": []}],
      "location": [],
      "resources": []
    },
    "relationships": [],
    "actions": []
  },
  // ... 其他消息的分析结果
]`;

    // 构建特别说明
    const specialNotes = `特别说明:
1. 'needsProcessing'字段表示消息是否需要进一步处理(如存储、通知等)
2. 'isNoiseMessage'字段标识是否为噪音消息(如单纯的"好的"、"谢谢"等)
3. 'nextAction'应该是'use_tool'或'finish'，表示是否需要进一步处理
4. 如果不需要处理(nextAction为finish)，请提供完整的决策信息(shouldStore, shouldNotify等)
5. 对于entities字段，请尽可能完整提取实体信息
6. 'tools'字段中只能包含上面列出的可用工具ID
7. 'params'字段应该根据选择的工具提供合适的参数，参考工具描述中的参数定义`;

    // 构建最终提示
    return `
${promptPrefix}

${messages.length > 1 ? `群组信息:\n${contextInfo}` : `上下文信息:\n${contextInfo}`}

${messages.length > 1 ? `消息列表:\n${messagesContent}` : `消息内容:\n${messagesContent}`}

${filterRulesInfo}

${depthNote}

# 可用工具
以下是可用于处理消息的工具，可以在分析时考虑是否需要使用这些工具：
${toolDescriptions}
${config.preferredTools && config.preferredTools.length > 0 ? `\n推荐优先考虑使用这些工具: ${config.preferredTools.join(', ')}` : ''}

${analysisPoints}

${returnFormat}

${specialNotes}

工具选择建议:
- 如果消息提到项目进度或问题，考虑使用jiraQuery
- 如果消息涉及组织关系或人员，考虑使用orgStructure
- 如果需要了解历史上下文，考虑使用historySearch
`;
  }

  /**
   * 构建项目分析提示
   */
  buildProjectAnalysisPrompt(normalizedInput, config, context) {
    // 获取项目基本信息
    const projectId = normalizedInput.project?.id || '未知项目ID';
    const projectName = normalizedInput.name || normalizedInput.project?.name || '未知项目';
    const projectType = normalizedInput.type || 'generic'; // 可能的类型：jira_ticket, release, sprint, project

    // 处理可能的Jira数据
    const jiraData = normalizedInput.jiraData || normalizedInput.jiraData || null;

    // 构建上下文信息
    const contextInfo = [`项目ID: ${projectId}`, `项目名称: ${projectName}`, `项目类型: ${projectType}`, context?.currentUser ? `当前用户: ${context.currentUser}` : '', normalizedInput.project?.owner ? `负责人: ${normalizedInput.project?.owner}` : '', normalizedInput.project?.status ? `当前状态: ${normalizedInput.project?.status}` : '', normalizedInput.project?.dueDate ? `截止日期: ${normalizedInput.project?.dueDate}` : '', normalizedInput.project?.track ? `赛道: ${normalizedInput.project?.track}` : '', normalizedInput.project?.comments ? `备注: ${normalizedInput.project?.comments}` : ''].filter(Boolean).join('\n');

    // 构建Jira数据信息
    let jiraInfo = '';
    if (jiraData) {
      jiraInfo = `
Jira工单信息:
- 工单ID: ${jiraData.key || jiraData.id || '未知'}
${jiraData.summary || jiraData.fields?.summary ? `- 摘要: ${jiraData.summary || jiraData.fields?.summary}` : ''}
- 工单状态: ${jiraData.status || jiraData.fields?.status?.name || '未知'}
- 负责人: ${jiraData.assignee || jiraData.fields?.assignee?.displayName || '未知'}
- 预计完成时间: ${jiraData.duedate || jiraData.fields?.duedate || '未知'}
`;
    }

    // 构建项目内容描述
    let contentDescription = '';
    if (normalizedInput.project?.description) {
      contentDescription = `项目描述:\n${normalizedInput.project?.description}`;
    } else if (normalizedInput.project?.content || normalizedInput.project?.message_content) {
      contentDescription = `项目内容:\n${normalizedInput.project?.content || normalizedInput.project?.message_content}`;
    } else if (normalizedInput.project?.tickets && Array.isArray(normalizedInput.project?.tickets)) {
      contentDescription = `相关工单:\n${normalizedInput.project?.tickets.map((ticket, i) => `- 工单${i + 1}: ${ticket.id || ''} ${ticket.title || ''} [${ticket.status || ''}]`).join('\n')}`;
    }

    // 获取工具描述
    const toolDescriptions = this.getToolDescriptions().join('\n');

    // 添加分析深度相关内容
    let depthNote = '';
    if (config.analysisDepth === 'quick') {
      depthNote = '注意：这是快速分析，无需使用工具，直接返回基本判断。';
    } else if (config.analysisDepth === 'deep') {
      depthNote = '注意：这是深度分析，尽可能使用多个工具收集完整信息，做出全面判断。';
    }

    // 构建最终提示
    return `
分析以下项目信息，评估项目状态与风险:

项目基本信息:
${contextInfo}

${jiraInfo}

${contentDescription}

${depthNote}

# 可用工具
以下是可用于分析项目的工具:
${toolDescriptions}
${config.preferredTools && config.preferredTools.length > 0 ? `\n推荐优先考虑使用这些工具: ${config.preferredTools.join(', ')}` : ''}

# 分析指南
请根据项目信息的结构类型进行分析:

1. 如果是单个JIRA工单(ticket)，请分析:
   - 工单的当前状态是否合理
   - 负责人分配是否合适
   - 截止日期是否存在风险
   - 评论/行动项是否需要更新
   - 是否需要关联其他信息源(如JIRA评论、聊天历史)来做更全面判断

2. 如果是发布/迭代(release/sprint)信息，请分析:
   - 整体发布状态和健康度
   - 包含的各个工单状态是否一致
   - 是否存在时间风险或资源冲突
   - 是否有工单可能会延迟整体发布
   - 行动项是否完整，是否需要添加新的行动项

3. 如果是项目级别信息，请分析:
   - 项目整体状态和健康度
   - 关键里程碑是否存在风险
   - 资源分配是否合理
   - 是否有需要特别关注的子项目或工单
   - 项目文档是否需要更新

请分析项目中可能存在的风险点，并提出相应的建议。如果需要更多信息来做判断，请指出可以使用哪些工具获取这些信息。

以JSON格式返回:
{
  "summary": "项目简要总结",
  "projectType": "识别出的项目类型(jira_ticket|release|sprint|project)",
  "status": "项目当前状态评估",
  "riskLevel": "low|medium|high",
  "riskPoints": ["风险点1", "风险点2"],
  "timeline": {
    "onTrack": true|false,
    "concerns": ["时间线问题1", "时间线问题2"]
  },
  "resourceAllocation": {
    "concerns": ["资源问题1", "资源问题2"]
  },
  
  // 决策和工具字段
  "thought": "分析当前情况和下一步行动的详细思考过程",
  "nextAction": "use_tool|finish",
  "tools": [{
    "id": "工具ID",
    "params": {}, // 工具所需参数
  }], // 如果nextAction为use_tool
  "confidence": 0.7,
  
  // 建议
  "suggestions": {
    "status": "(In Progress|Done|Blocked|Released)", // 用英文直接填入具体的状态值（如：进行中、已完成、阻塞中），没有变化可留空
    "statusReason": "建议修改状态的原因", // 用中文给出状态变化的原因
    "owner": "", // 用英文直接填入具体的人名，没有变化可留空
    "ownerReason": "建议修改负责人的原因", // 用中文给出修改负责人的原因
    "track": "", // 用英文直接填入具体的赛道名称或团队名，没有变化可留空
    "highlights": ["highlight1", "highlight2"], // 用英文直接填入具体的备注内容，没有变化可留空
    "highlightsReason": "建议修改备注的原因", // 用中文给出备注变化的原因
    "actionItems": ["actionItem1", "actionItem2"],  // 用英文直接填入具体的行动项，没有变化可留空
    "actionItemsReason": "建议修改行动项的原因", // 用中文给出行动项变化的原因
    "documentation": ["文档更新建议"],
    "risks": ["风险描述1", "风险描述2"],
    "followUp": ["后续跟进项1", "后续跟进项2"]
  },
  
  // 提取的实体
  "entities": {
    "tickets": [{"id": "JIRA-123", "status": "状态", "owner": "负责人", "dueDate": "日期"}],
    "milestones": [{"name": "里程碑名称", "date": "日期", "status": "状态"}],
    "dependencies": [{"from": "项目A", "to": "项目B", "type": "类型"}]
  },
  
  // Jira相关数据
  "jiraData": {
    "status": "Jira工单状态",
    "assignee": "Jira负责人",
    "updated": "最后更新时间",
    "comments": ["Jira评论1", "Jira评论2"],
    "statusMatch": true|false
  }
}
`;
  }

  /**
   * 构建会议分析提示
   */
  buildMeetingAnalysisPrompt(normalizedInput, config, context) {
    // 获取会议基本信息
    const meetingId = normalizedInput.id || normalizedInput.meetingId || '未知会议ID';
    const meetingTitle = normalizedInput.title || normalizedInput.name || '未知会议';
    const meetingType = normalizedInput.type || 'generic'; // 可能的类型：daily, weekly, review, planning

    // 构建会议上下文信息
    const contextInfo = [`会议ID: ${meetingId}`, `会议标题: ${meetingTitle}`, `会议类型: ${meetingType}`, normalizedInput.organizer ? `组织者: ${normalizedInput.organizer}` : '', normalizedInput.datetime ? `会议时间: ${normalizedInput.datetime}` : '', normalizedInput.duration ? `会议时长: ${normalizedInput.duration}分钟` : '', normalizedInput.location ? `会议地点: ${normalizedInput.location}` : '', normalizedInput.attendees ? `参会人员: ${Array.isArray(normalizedInput.attendees) ? normalizedInput.attendees.join(', ') : normalizedInput.attendees}` : '', context?.currentUser ? `当前用户: ${context.currentUser}` : ''].filter(Boolean).join('\n');

    // 构建会议内容描述
    let contentDescription = '';
    if (normalizedInput.transcript) {
      contentDescription = `会议记录:\n${normalizedInput.transcript}`;
    } else if (normalizedInput.content) {
      contentDescription = `会议内容:\n${normalizedInput.content}`;
    } else if (normalizedInput.agenda) {
      contentDescription = `会议议程:\n${Array.isArray(normalizedInput.agenda) ? normalizedInput.agenda.map((item, i) => `- 议题${i + 1}: ${item}`).join('\n') : normalizedInput.agenda}`;
    }

    // 获取工具描述
    const toolDescriptions = this.getToolDescriptions().join('\n');

    // 添加分析深度相关内容
    let depthNote = '';
    if (config.analysisDepth === 'quick') {
      depthNote = '注意：这是快速分析，无需使用工具，直接返回基本会议摘要。';
    } else if (config.analysisDepth === 'deep') {
      depthNote = '注意：这是深度分析，请尽可能提取详细的会议信息，包括决策点、行动项和跟进事项。';
    }

    // 构建最终提示
    return `
分析以下会议内容，提取关键信息并总结重要决策与行动项:

会议基本信息:
${contextInfo}

${contentDescription}

${depthNote}

# 可用工具
以下是可用于分析会议的工具:
${toolDescriptions}
${config.preferredTools && config.preferredTools.length > 0 ? `\n推荐优先考虑使用这些工具: ${config.preferredTools.join(', ')}` : ''}

# 分析指南
根据会议类型进行有针对性的分析:

1. 如果是日常/周常会议:
   - 识别团队进展更新
   - 提取遇到的阻碍和问题
   - 总结需要协助的事项
   - 跟踪行动项的完成情况
   
2. 如果是评审会议:
   - 提取关键决策和批准事项
   - 识别需要修改的内容
   - 总结评审结果和后续步骤
   
3. 如果是规划会议:
   - 总结确定的目标和优先级
   - 提取资源分配决策
   - 识别关键里程碑和时间点
   - 总结风险评估结果

请提取会议中讨论的所有主题，识别关键决策，列出所有行动项及其负责人和截止日期，并总结需要跟进的事项。

以JSON格式返回:
{
  "summary": "会议总体摘要",
  "meetingType": "识别出的会议类型",
  "attendees": ["参会人员1", "参会人员2"],
  "topics": [
    {
      "title": "讨论主题",
      "summary": "讨论内容摘要",
      "keyPoints": ["要点1", "要点2"]
    }
  ],
  "decisions": [
    {
      "topic": "相关主题",
      "decision": "决策内容",
      "rationale": "决策理由",
      "stakeholders": ["相关人员"]
    }
  ],
  "actionItems": [
    {
      "description": "行动项描述",
      "assignee": "负责人",
      "dueDate": "截止日期",
      "priority": "high|medium|low",
      "relatedTopic": "相关主题"
    }
  ],
  "followups": [
    {
      "description": "需要跟进的事项",
      "by": "跟进人",
      "byWhen": "跟进时间"
    }
  ],
  
  // 决策和工具字段
  "thought": "分析当前情况和下一步行动的详细思考过程",
  "nextAction": "use_tool|finish",
  "tools": [{
    "id": "工具ID",
    "params": {}, // 工具所需参数
  }], // 如果nextAction为use_tool
  "confidence": 0.7,
  
  // 会议效果评估
  "meetingEffectiveness": {
    "clarity": "high|medium|low", // 会议目标清晰度
    "participation": "high|medium|low", // 参与度
    "decisions": "effective|mixed|ineffective", // 决策有效性
    "timeUsage": "efficient|adequate|inefficient" // 时间利用
  },
  
  // 实体提取
  "entities": {
    "projects": [{"name": "项目名", "status": "状态"}],
    "issues": [{"id": "问题ID", "description": "问题描述"}],
    "deadlines": [{"event": "事件", "date": "日期"}]
  }
}
`;
  }

  /**
   * 构建文档分析提示
   */
  buildDocumentAnalysisPrompt(normalizedInput, config, context) {
    // 获取文档基本信息
    const documentId = normalizedInput.id || normalizedInput.documentId || '未知文档ID';
    const documentTitle = normalizedInput.title || normalizedInput.name || '未知文档';
    const documentType = normalizedInput.type || normalizedInput.format || 'generic'; // 可能的类型：report, spec, proposal, presentation

    // 构建文档上下文信息
    const contextInfo = [`文档ID: ${documentId}`, `文档标题: ${documentTitle}`, `文档类型: ${documentType}`, normalizedInput.author ? `作者: ${normalizedInput.author}` : '', normalizedInput.createdAt ? `创建时间: ${normalizedInput.createdAt}` : '', normalizedInput.lastModified ? `最后修改: ${normalizedInput.lastModified}` : '', normalizedInput.version ? `版本: ${normalizedInput.version}` : '', normalizedInput.tags ? `标签: ${Array.isArray(normalizedInput.tags) ? normalizedInput.tags.join(', ') : normalizedInput.tags}` : '', context?.currentUser ? `当前用户: ${context.currentUser}` : ''].filter(Boolean).join('\n');

    // 构建文档内容描述
    let contentDescription = '';
    if (normalizedInput.content) {
      contentDescription = `文档内容:\n${normalizedInput.content}`;
    } else if (normalizedInput.summary) {
      contentDescription = `文档摘要:\n${normalizedInput.summary}`;
    } else if (normalizedInput.sections && Array.isArray(normalizedInput.sections)) {
      contentDescription = `文档章节:\n${normalizedInput.sections.map((section, i) => `## ${section.title || `章节${i + 1}`}\n${section.content || '无内容'}`).join('\n\n')}`;
    }

    // 获取工具描述
    const toolDescriptions = this.getToolDescriptions().join('\n');

    // 添加分析深度相关内容
    let depthNote = '';
    if (config.analysisDepth === 'quick') {
      depthNote = '注意：这是快速分析，直接返回文档基本摘要和关键点。';
    } else if (config.analysisDepth === 'deep') {
      depthNote = '注意：这是深度分析，请详细提取文档结构、主题、观点、论据和建议等内容。';
    }

    // 构建最终提示
    return `
分析以下文档内容，提取关键信息和主要观点:

文档基本信息:
${contextInfo}

${contentDescription}

${depthNote}

# 可用工具
以下是可用于分析文档的工具:
${toolDescriptions}
${config.preferredTools && config.preferredTools.length > 0 ? `\n推荐优先考虑使用这些工具: ${config.preferredTools.join(', ')}` : ''}

# 分析指南
根据文档类型进行有针对性的分析:

1. 如果是技术规格/设计文档:
   - 分析功能需求和技术要求
   - 提取架构设计和组件关系
   - 总结技术限制和依赖条件
   - 识别可能的实现风险
   
2. 如果是项目报告/提案:
   - 提取项目背景和问题定义
   - 分析解决方案和论据支持
   - 总结建议行动和预期结果
   - 识别资源需求和时间线
   
3. 如果是演示文稿/培训材料:
   - 提取主要观点和教学目标
   - 分析内容组织和逻辑流程
   - 总结关键示例和案例研究
   - 识别适用场景和预期受众

请分析文档的整体结构、主要主题、关键论点和支持证据，并总结文档的主要目的和关键发现。

以JSON格式返回:
{
  "summary": "文档整体摘要",
  "documentType": "识别出的文档类型",
  "purpose": "文档目的",
  "audience": "目标受众",
  "structure": {
    "sections": [
      {
        "title": "章节标题",
        "summary": "章节内容摘要",
        "keyPoints": ["关键点1", "关键点2"]
      }
    ]
  },
  "keyThemes": [
    {
      "theme": "主题名称",
      "description": "主题描述",
      "relatedSections": ["相关章节"]
    }
  ],
  "arguments": [
    {
      "claim": "论点",
      "evidence": ["支持证据1", "支持证据2"],
      "strength": "strong|moderate|weak"
    }
  ],
  "findings": ["发现1", "发现2"],
  "recommendations": ["建议1", "建议2"],
  
  // 决策和工具字段
  "thought": "分析当前情况和下一步行动的详细思考过程",
  "nextAction": "use_tool|finish",
  "tools": [{
    "id": "工具ID",
    "params": {}, // 工具所需参数
  }], // 如果nextAction为use_tool
  "confidence": 0.7,
  
  // 质量评估
  "documentQuality": {
    "clarity": "high|medium|low", // 清晰度
    "completeness": "high|medium|low", // 完整性
    "consistency": "high|medium|low", // 一致性
    "supportedClaims": "well|partially|poorly" // 观点支持程度
  },
  
  // 实体提取
  "entities": {
    "concepts": [{"name": "概念名", "definition": "定义"}],
    "technologies": [{"name": "技术名", "context": "使用上下文"}],
    "references": [{"text": "引用文本", "source": "来源"}]
  }
}
`;
  }

  /**
   * 构建通用分析提示
   */
  buildGenericAnalysisPrompt(normalizedInput, config, context) {
    // 尝试确定输入类型
    let inputType = 'unknown';
    let inputTitle = '未命名内容';

    // 基于输入属性尝试推断类型
    if (normalizedInput.message_content || normalizedInput.content && normalizedInput.sender) {
      inputType = 'message';
    } else if (normalizedInput.transcript || normalizedInput.attendees) {
      inputType = 'meeting';
    } else if (normalizedInput.tickets || normalizedInput.release) {
      inputType = 'project';
    } else if (normalizedInput.sections || normalizedInput.author) {
      inputType = 'document';
    }

    // 尝试获取标题
    if (normalizedInput.title) {
      inputTitle = normalizedInput.title;
    } else if (normalizedInput.name) {
      inputTitle = normalizedInput.name;
    } else if (normalizedInput.subject) {
      inputTitle = normalizedInput.subject;
    }

    // 构建上下文信息
    const contextInfo = [`内容标题: ${inputTitle}`, `推测类型: ${inputType}`, normalizedInput.datetime ? `时间: ${normalizedInput.datetime}` : '', normalizedInput.source ? `来源: ${normalizedInput.source}` : '', context?.currentUser ? `当前用户: ${context.currentUser}` : ''].filter(Boolean).join('\n');

    // 构建内容描述
    let contentDescription = '';
    if (typeof normalizedInput === 'string') {
      contentDescription = `内容:\n${normalizedInput}`;
    } else if (normalizedInput.content) {
      contentDescription = `内容:\n${normalizedInput.content}`;
    } else if (normalizedInput.text) {
      contentDescription = `内容:\n${normalizedInput.text}`;
    } else {
      // 尝试将整个输入作为内容
      const inputStr = JSON.stringify(normalizedInput, null, 2);
      if (inputStr.length < 5000) {
        // 避免过长内容
        contentDescription = `原始内容:\n${inputStr}`;
      } else {
        contentDescription = `原始内容过长，请使用工具查看完整内容。`;
      }
    }

    // 获取工具描述
    const toolDescriptions = this.getToolDescriptions().join('\n');

    // 添加分析深度相关内容
    let depthNote = '';
    if (config.analysisDepth === 'quick') {
      depthNote = '注意：这是快速分析，直接返回基本总结。';
    } else if (config.analysisDepth === 'deep') {
      depthNote = '注意：这是深度分析，请尽可能详细地提取信息和见解。';
    }

    // 构建最终提示
    return `
分析以下内容，提取关键信息和见解:

基本信息:
${contextInfo}

${contentDescription}

${depthNote}

# 可用工具
以下是可用于分析的工具:
${toolDescriptions}
${config.preferredTools && config.preferredTools.length > 0 ? `\n推荐优先考虑使用这些工具: ${config.preferredTools.join(', ')}` : ''}

# 分析指南
由于输入类型不明确，请进行通用分析:

1. 首先，尝试确定内容的类型和性质
2. 提取关键信息、主题和要点
3. 分析内容的重要性和相关性
4. 识别任何需要关注、跟进或行动的项目
5. 总结内容的主要价值和见解

请根据内容类型的最佳做法进行分析，并根据需要使用工具获取更多信息。

以JSON格式返回:
{
  "summary": "内容总结",
  "contentType": "识别出的内容类型",
  "keyPoints": ["要点1", "要点2"],
  "topics": ["主题1", "主题2"],
  "importance": "high|medium|low",
  "relevance": "内容相关性描述",
  "insightValue": "内容提供的见解价值",
  
  // 决策和工具字段
  "thought": "分析当前情况和下一步行动的详细思考过程",
  "nextAction": "use_tool|finish",
  "tools": [{
    "id": "工具ID",
    "params": {}, // 工具所需参数
  }], // 如果nextAction为use_tool
  "confidence": 0.7,
  
  // 建议
  "suggestions": {
    "actionItems": ["建议行动项1", "建议行动项2"],
    "followUp": ["后续跟进项1", "后续跟进项2"]
  },
  
  // 实体提取
  "entities": {
    "people": [{"name": "人名", "role": "角色"}],
    "organizations": [{"name": "组织名", "type": "类型"}],
    "dates": [{"text": "日期文本", "normalized": "标准化日期"}],
    "locations": [{"name": "位置名", "type": "类型"}],
    "concepts": [{"name": "概念名", "description": "描述"}]
  }
}
`;
  }

  /**
   * 思考下一步行动
   */
  async think(state) {
    // 构建思考提示
    const thinkPrompt = this.buildThinkingPrompt(state);

    // 如果存在自定义思考提示，则使用自定义提示
    if (state.config.customPrompts?.thinking) {
      const customThinkPrompt = state.config.customPrompts.thinking;
    }
    try {
      // 调用LLM API进行思考
      const thoughtResult = await (0,_llm__WEBPACK_IMPORTED_MODULE_0__/* .callLLMJsonAPI */ .sc)({
        prompt: thinkPrompt,
        type: 'think'
      });
      return thoughtResult;
    } catch (error) {
      console.error('思考过程失败:', error);
      // 返回直接结束处理的决定
      return {
        thought: `思考过程中出错: ${error.message}，决定结束处理`,
        nextAction: 'finish',
        tools: [],
        ...state.currentDecision
      };
    }
  }

  /**
   * 构建思考提示
   */
  buildThinkingPrompt(state) {
    // 获取当前状态信息
    const currentActionCount = state.actionCount || 0;
    const maxActions = state.config.maxActions || 5;
    const analysisType = state.config.type || 'generic';

    // 获取已有分析信息
    const currentResult = state.result || {};
    const currentAnalysis = state.analysis || {};
    const memory = state.memory || {};

    // 构建当前状态描述
    let stateDescription = '';

    // 根据分析类型构建不同的状态描述
    switch (analysisType) {
      case 'message':
        stateDescription = `
当前分析的消息内容: ${state.input.message_content || state.input.content || '无内容'}
发送者: ${state.input.sender || '未知'}
发送时间: ${state.input.datetime || '未知'}
群组/团队: ${state.input.groupName || '未知'}

当前决策:
- 重要性: ${state.currentDecision.isImportant ? '重要' : '不重要'}
- 需要存储: ${state.currentDecision.shouldStore ? '是' : '否'}
- 需要通知: ${state.currentDecision.shouldNotify ? '是' : '否'}
- 置信度: ${state.currentDecision.confidence || 0}
- 摘要: ${state.currentDecision.summary || '无摘要'}
- 理由: ${state.currentDecision.reasons?.join(', ') || '无理由'}
- 通知优先级: ${state.currentDecision.notificationPriority || 'low'}
- 回复建议: ${state.currentDecision.replyAdvice || '无建议'}
`;
        break;
      case 'project':
        stateDescription = `
当前分析的项目: ${state.input.project?.name || '未命名项目'}
项目ID: ${state.input.project?.id || '未知ID'}
状态: ${state.input.project?.status || state.input.jiraData?.status || '未知状态'}
负责人: ${state.input.project?.owner || '未知'}

当前分析结果:
- 风险级别: ${currentResult.riskLevel || '未评估'}
- 时间线状态: ${currentResult.timeline?.onTrack ? '正常' : '有风险'}
- 建议操作: ${currentResult.suggestions?.actionItems?.join(', ') || '无'}
`;
        break;

      // Todo: 未命名会议
      case 'meeting':
        stateDescription = `
当前分析的会议: ${state.input.title || '未命名会议'}
会议时间: ${state.input.datetime || '未知时间'}
参会人员: ${Array.isArray(state.input.attendees) ? state.input.attendees.join(', ') : state.input.attendees || '未知'}

当前分析结果:
- 主题数量: ${currentResult.topics?.length || 0}
- 决策数量: ${currentResult.decisions?.length || 0}
- 行动项数量: ${currentResult.actionItems?.length || 0}
- 需要跟进项: ${currentResult.followups?.length || 0}
`;
        break;

      // Todo: 未命名文档
      case 'document':
        stateDescription = `
当前分析的文档: ${state.input.title || '未命名文档'}
文档类型: ${state.input.type || '未知类型'}
作者: ${state.input.author || '未知'}

当前分析结果:
- 文档目的: ${currentResult.purpose || '未确定'}
- 提取的主题数: ${currentResult.keyThemes?.length || 0}
- 提取的论点数: ${currentResult.arguments?.length || 0}
- 主要发现: ${currentResult.findings?.join(', ') || '无'}
`;
        break;
      default:
        stateDescription = `
当前分析的内容类型: ${analysisType || '未知类型'}
内容摘要: ${currentResult.summary || '无摘要'}
当前分析状态: 已执行${currentActionCount}个操作，最多可执行${maxActions}个操作
当前分析置信度: ${currentResult.confidence || currentAnalysis.confidence || 0}
`;
    }

    // 添加历史行动记录
    let actionHistory = '';
    if (state.actionHistory && state.actionHistory.length > 0) {
      actionHistory = `
过去采取的行动:
${state.actionHistory.map((action, index) => `${index + 1}. 工具: ${action.tool || '无'}, 参数: ${JSON.stringify(action.params || {})}, 结果: 参见[已执行的工具和收集的信息]`).join('\n')}
`;
    }

    // 添加记忆内容
    let memoryContent = '';
    if (Object.keys(memory).length > 0) {
      memoryContent = `
已执行的工具和收集的信息:
${Object.entries(memory).map(_ref => {
        let [key, results] = _ref;
        return results.map(r => `- ${key} [已执行]: ${r.result.message.substring(0, 500)}${r.result.message.length > 300 ? '...' : ''}`);
      }).join('\n')}
`;
    }

    // 获取工具描述
    const toolDescriptions = this.getToolDescriptions().join('\n');

    // 构建最终提示
    return `
作为智能分析助手，你正在分析一个${analysisType}类型的内容。你已经执行了${currentActionCount}个操作，最多可以执行${maxActions}个操作。

## 当前状态
${stateDescription}

${actionHistory}

${memoryContent}

## 可用工具
${toolDescriptions}
${state.config.preferredTools && state.config.preferredTools.length > 0 ? `\n推荐优先考虑使用这些工具: ${state.config.preferredTools.join(', ')}` : ''}

## 思考指南
请仔细思考当前状态和已有信息，决定下一步行动:

1. 评估已获取的信息是否足够做出决策
2. 考虑是否需要使用工具获取更多信息(如果已经执行过同样或类似参数的工具，则不需要重复执行)
3. 如果需要使用工具，选择最合适的工具并确定参数
4. 如果已有足够信息，可以结束分析并给出最终决策

请以JSON格式返回你的思考结果:
{
  "thought": "详细解释你的思考过程，包括对当前状态的分析和决策理由",
  "nextAction": "use_tool或finish",
  "tools": [{
    "id": "工具ID",
    "params": {}, // 工具所需参数
  }], // 如果nextAction为use_tool
  
  // 如果决定结束，更新当前决策
  "isImportant": true|false,
  "shouldStore": true|false,
  "shouldNotify": true|false,
  "confidence": 0.9,
  "summary": "最终摘要",
  "reasons": ["理由1", "理由2"],
  "notificationPriority": "high|medium|low",
  "replyAdvice": "回复建议"
}
`;
  }
}

// 导出所有需要的接口和函数


/***/ }),

/***/ 42331:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   S: () => (/* binding */ SlideAnalyzerFactoryImpl)
/* harmony export */ });
/* harmony import */ var _tableAnalyzer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6945);
/* harmony import */ var _textAnalyzer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(21394);
/* harmony import */ var _llmAnalyzer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97254);
/**
 * 幻灯片分析器工厂实现
 */





/**
 * 分析器工厂类
 * 根据幻灯片内容类型创建合适的分析器
 */
class SlideAnalyzerFactoryImpl {
  // 是否使用LLM作为后备分析器

  /**
   * 构造函数
   * @param options 可选的配置选项
   */
  constructor(options) {
    this.analyzerCache = new Map();
    this.useLLMFallback = false;
    if (options) {
      this.useLLMFallback = options.useLLMFallback || false;
    }
  }

  /**
   * 创建适合幻灯片内容的分析器
   * @param slide 幻灯片对象
   * @returns 适合的内容分析器
   */
  createAnalyzer(slide) {
    // 如果缓存中已有此幻灯片的分析器，直接返回
    if (slide.objectId && this.analyzerCache.has(slide.objectId)) {
      return this.analyzerCache.get(slide.objectId);
    }

    // 创建所有可用的分析器，按优先级排序
    const availableAnalyzers = [new _tableAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .TableContentAnalyzerImpl */ .E(), new _textAnalyzer__WEBPACK_IMPORTED_MODULE_1__/* .TextContentAnalyzerImpl */ .N()];

    // 如果启用了LLM后备，添加LLM分析器（最低优先级）
    if (this.useLLMFallback) {
      availableAnalyzers.push(new _llmAnalyzer__WEBPACK_IMPORTED_MODULE_2__/* .LLMContentAnalyzer */ .j());
    }

    // 查找能处理此幻灯片的分析器
    for (const analyzer of availableAnalyzers) {
      if (analyzer.canHandle(slide)) {
        // 缓存并返回找到的分析器
        if (slide.objectId) {
          this.analyzerCache.set(slide.objectId, analyzer);
        }
        return analyzer;
      }
    }

    // 如果没有找到，优先使用LLM分析器（如果启用），否则使用默认分析器
    const defaultAnalyzer = this.useLLMFallback ? new _llmAnalyzer__WEBPACK_IMPORTED_MODULE_2__/* .LLMContentAnalyzer */ .j() : availableAnalyzers[0];
    if (slide.objectId) {
      this.analyzerCache.set(slide.objectId, defaultAnalyzer);
    }
    return defaultAnalyzer;
  }

  /**
   * 清除分析器缓存
   */
  clearCache() {
    this.analyzerCache.clear();
  }
}

/***/ }),

/***/ 26308:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ BaseSlideAnalyzer)
/* harmony export */ });
/* harmony import */ var _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(38275);
/**
 * 幻灯片内容分析器基类
 */


/**
 * 基础分析器抽象类
 * 提供通用功能和框架，具体分析由子类实现
 */
class BaseSlideAnalyzer {
  /**
   * 分析幻灯片内容
   * @param slide 幻灯片对象
   * @returns 分析结果
   */
  async analyze(slide) {
    // 进行基本幻灯片元素分析
    const metadata = this.analyzeSlideMetadata(slide);
    const contentType = this.determineContentType(slide);

    // 初始化结果
    const result = {
      contentType,
      projectStructure: _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .ProjectStructureType */ .t.UNKNOWN,
      projectFields: [],
      projects: [],
      confidence: 0,
      metadata
    };
    try {
      // 分析项目结构
      result.projectStructure = this.analyzeProjectStructure(slide);

      // 进行具体内容分析，由子类实现
      const analysisResult = await this.analyzeContent(slide, contentType);

      // 合并分析结果
      Object.assign(result, analysisResult);
      return result;
    } catch (error) {
      console.error('幻灯片分析错误:', error);
      result.warnings = [`分析错误: ${error instanceof Error ? error.message : String(error)}`];
      return result;
    }
  }

  /**
   * 判断是否可以处理此类型的幻灯片
   * 子类应该重写此方法以提供具体的判断逻辑
   * @param slide 幻灯片对象
   * @returns 是否可以处理
   */

  /**
   * 分析具体内容
   * 子类需要实现此方法进行具体分析逻辑
   * @param slide 幻灯片对象
   * @param contentType 内容类型
   * @returns 部分分析结果
   */

  /**
   * 分析幻灯片元数据
   * @param slide 幻灯片对象
   * @returns 幻灯片元数据
   */
  analyzeSlideMetadata(slide) {
    const pageElements = slide.pageElements || [];

    // 计数不同类型的元素
    let tableCount = 0;
    let textCount = 0;
    let shapeCount = 0;
    let listCount = 0;
    for (const element of pageElements) {
      if (element.table) tableCount++;
      if (element.shape?.text) {
        textCount++;
        // 检查文本是否包含列表
        if (this.containsList(element.shape.text.textElements)) {
          listCount++;
        }
      }
      if (element.shape && !element.shape.text) shapeCount++;
    }
    return {
      slideId: slide.objectId,
      elementCount: pageElements.length,
      hasTable: tableCount > 0,
      hasText: textCount > 0,
      hasShapes: shapeCount > 0,
      hasLists: listCount > 0
    };
  }

  /**
   * 确定幻灯片内容类型
   * @param slide 幻灯片对象
   * @returns 内容类型
   */
  determineContentType(slide) {
    const metadata = this.analyzeSlideMetadata(slide);
    if (metadata.hasTable) {
      // 如果有表格，可以是表格或混合
      return metadata.hasText && !this.isTableDominant(slide) ? _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .SlideContentType */ .l.MIXED : _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .SlideContentType */ .l.TABLE;
    } else if (metadata.hasLists) {
      // 如果有列表但没有表格
      return _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .SlideContentType */ .l.LIST;
    } else if (metadata.hasText) {
      // 如果有文本但没有表格和列表
      return _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .SlideContentType */ .l.TEXT;
    } else if (metadata.hasShapes) {
      // 只有形状
      return _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .SlideContentType */ .l.SHAPE;
    }
    return _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .SlideContentType */ .l.UNKNOWN;
  }

  /**
   * 分析项目结构类型
   * @param slide 幻灯片对象
   * @returns 项目结构类型
   */
  analyzeProjectStructure(slide) {
    // 查找幻灯片标题或文本内容中的关键词
    const textContent = this.extractAllTextContent(slide);
    const lowerText = textContent.toLowerCase();

    // 根据关键词判断项目结构类型
    if (lowerText.includes('sprint') || lowerText.includes('迭代') || lowerText.includes('iteration') || lowerText.includes('周报')) {
      return _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .ProjectStructureType */ .t.SPRINT;
    } else if (lowerText.includes('epic') || lowerText.includes('特性') || lowerText.includes('feature')) {
      return _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .ProjectStructureType */ .t.EPIC;
    } else if (lowerText.includes('release') || lowerText.includes('发布') || lowerText.includes('版本')) {
      return _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .ProjectStructureType */ .t.RELEASE;
    } else if (this.containsMultipleJiraTickets(textContent)) {
      // 如果检测到多个Jira工单ID，但没有其他关键词，默认为混合结构
      return _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .ProjectStructureType */ .t.MIXED;
    } else if (this.containsSingleJiraTicket(textContent)) {
      // 如果只检测到一个Jira工单ID
      return _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .ProjectStructureType */ .t.SINGLE_TICKET;
    }

    // 默认为自定义结构
    return _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .ProjectStructureType */ .t.CUSTOM;
  }

  /**
   * 提取幻灯片所有文本内容
   * @param slide 幻灯片对象
   * @returns 所有文本内容
   */
  extractAllTextContent(slide) {
    const textContent = [];
    if (!slide.pageElements) return '';
    for (const element of slide.pageElements) {
      // 从表格中提取文本
      if (element.table && element.table.tableRows) {
        for (const row of element.table.tableRows) {
          if (!row.tableCells) continue;
          for (const cell of row.tableCells) {
            if (!cell.text || !cell.text.textElements) continue;
            const cellText = cell.text.textElements.map(e => e.textRun?.content || '').join('');
            if (cellText.trim()) {
              textContent.push(cellText);
            }
          }
        }
      }

      // 从形状中提取文本
      if (element.shape && element.shape.text && element.shape.text.textElements) {
        const shapeText = element.shape.text.textElements.map(e => e.textRun?.content || '').join('');
        if (shapeText.trim()) {
          textContent.push(shapeText);
        }
      }
    }
    return textContent.join('\n');
  }

  /**
   * 检查是否包含单个Jira工单
   * @param text 文本内容
   * @returns 是否包含单个Jira工单
   */
  containsSingleJiraTicket(text) {
    const jiraTicketPattern = /[A-Z]+-\d+/g;
    const matches = text.match(jiraTicketPattern);
    return matches !== null && matches.length === 1;
  }

  /**
   * 检查是否包含多个Jira工单
   * @param text 文本内容
   * @returns 是否包含多个Jira工单
   */
  containsMultipleJiraTickets(text) {
    const jiraTicketPattern = /[A-Z]+-\d+/g;
    const matches = text.match(jiraTicketPattern);
    return matches !== null && matches.length > 1;
  }

  /**
   * 检查文本元素是否包含列表
   * @param textElements 文本元素数组
   * @returns 是否包含列表
   */
  containsList(textElements) {
    if (!textElements) return false;
    return textElements.some(element => element.paragraphMarker?.style?.bulletPreset !== undefined);
  }

  /**
   * 判断表格是否是幻灯片的主要内容
   * @param slide 幻灯片对象
   * @returns 表格是否为主要内容
   */
  isTableDominant(slide) {
    if (!slide.pageElements) return false;
    const totalElements = slide.pageElements.length;
    const tableElements = slide.pageElements.filter(e => e.table).length;

    // 如果表格元素占比超过50%，或者只有一个表格和少量其他元素
    return tableElements / totalElements > 0.5 || tableElements === 1 && totalElements <= 3;
  }

  /**
   * 从文本中提取所有Jira工单ID
   * @param text 文本内容
   * @returns Jira工单ID数组
   */
  extractJiraTickets(text) {
    const jiraTicketPattern = /[A-Z]+-\d+/g;
    return text.match(jiraTicketPattern) || [];
  }
}

/***/ }),

/***/ 97254:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   j: () => (/* binding */ LLMContentAnalyzer)
/* harmony export */ });
/* harmony import */ var _baseAnalyzer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(26308);
/* harmony import */ var _llm__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(68400);
/**
 * LLM辅助分析器实现
 */


 // 导入callLLMJsonAPI函数

/**
 * LLM辅助分析器类
 * 使用LLM分析难以结构化解析的幻灯片内容
 */
class LLMContentAnalyzer extends _baseAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .BaseSlideAnalyzer */ .Z {
  /**
   * 判断是否可以处理此类型的幻灯片
   * @param slide 幻灯片对象
   * @returns 是否可以处理
   */
  canHandle(slide) {
    // 这是后备分析器，可以处理任何幻灯片，但优先级较低
    return true;
  }

  /**
   * 分析具体内容
   * @param slide 幻灯片对象
   * @param contentType 内容类型
   * @returns 部分分析结果
   */
  async analyzeContent(slide, contentType) {
    try {
      // 生成分析提示
      const {
        prompt,
        elementMap
      } = this.generateAnalysisPrompt(slide);

      // 调用LLM API进行分析
      const llmResponse = await this.callLLMAPI(prompt);

      // 解析LLM响应
      const projects = this.parseLLMResponse(llmResponse, elementMap, slide.objectId);

      // 计算置信度和项目字段
      const confidence = this.calculateLLMConfidence(projects, llmResponse);
      const projectFields = this.determineCommonFields(projects);
      return {
        projects,
        projectFields,
        confidence,
        warnings: confidence < LLMContentAnalyzer.MIN_CONFIDENCE_THRESHOLD ? ['LLM分析置信度较低，可能需要手动检查项目数据'] : undefined
      };
    } catch (error) {
      console.error('LLM分析错误:', error);
      return {
        projects: [],
        confidence: 0,
        warnings: [`LLM分析错误: ${error instanceof Error ? error.message : String(error)}`]
      };
    }
  }

  /**
   * 生成分析提示
   * @param slide 幻灯片对象
   * @returns 分析提示和元素映射
   */
  generateAnalysisPrompt(slide) {
    const elementMap = new Map();
    let slideContent = '';

    // 提取幻灯片内容，同时生成元素ID映射
    if (slide.pageElements) {
      slideContent = this.extractSlideContent(slide, elementMap);
    }

    // 构建LLM提示
    const prompt = `
分析以下Google Slides幻灯片内容，提取其中的项目信息：

=== 幻灯片内容 ===
${slideContent}
=== 幻灯片内容结束 ===

从以上内容中提取所有项目信息，包括：
1. 项目ID/Jira工单号（如有，通常是形如"ABC-123"的格式）
2. 项目名称
3. 项目状态（如：进行中、完成、阻塞等）
4. 项目负责人/Owner
5. 项目赛道/团队（如有）
6. 项目备注/行动项（如有）

对于每个识别的项目，请同时提供其对应的元素ID，方便后续定位和更新。
如果从内容中无法确定某些字段，请将其留空。

返回JSON格式如下：
{
  "projects": [
    {
      "id": "项目ID或Jira工单号",
      "name": "项目名称",
      "status": "项目状态",
      "owner": "负责人",
      "track": "赛道/团队",
      "comments": "备注/行动项",
      "elementId": "对应的元素ID"
    }
  ],
  "confidence": 0.8, // 分析结果的置信度(0-1)
  "analysis": "分析过程和考虑因素的简要说明"
}
`;
    return {
      prompt,
      elementMap
    };
  }

  /**
   * 提取幻灯片内容并创建元素ID映射
   * @param slide 幻灯片对象
   * @param elementMap 元素ID映射表
   * @returns 幻灯片内容文本
   */
  extractSlideContent(slide, elementMap) {
    const contentParts = [];
    let elementIndex = 0;
    if (!slide.pageElements) {
      return '';
    }

    // 处理所有页面元素
    for (const element of slide.pageElements) {
      const elementId = element.objectId;
      const mappedId = `element_${elementIndex++}`;
      elementMap.set(mappedId, elementId);

      // 根据元素类型提取内容
      if (element.shape && element.shape.text) {
        // 处理形状中的文本
        const textContent = this.extractTextFromTextElements(element.shape.text.textElements || []);
        if (textContent) {
          contentParts.push(`[文本元素 ID:${mappedId}]\n${textContent}\n`);
        }
      } else if (element.table) {
        // 处理表格
        const tableContent = this.extractTableContent(element.table);
        if (tableContent) {
          contentParts.push(`[表格元素 ID:${mappedId}]\n${tableContent}\n`);
        }
      }
      // 可以添加更多元素类型的提取逻辑
    }
    return contentParts.join('\n');
  }

  /**
   * 从文本元素数组中提取文本
   * @param textElements 文本元素数组
   * @returns 提取的文本
   */
  extractTextFromTextElements(textElements) {
    return textElements.map(element => element.textRun?.content || '').join('').trim();
  }

  /**
   * 提取表格内容
   * @param table 表格对象
   * @returns 表格内容文本表示
   */
  extractTableContent(table) {
    if (!table.tableRows) {
      return '';
    }
    const rows = [];

    // 遍历表格行
    for (const row of table.tableRows) {
      if (!row.tableCells) continue;
      const cells = [];

      // 遍历单元格
      for (const cell of row.tableCells) {
        const cellText = cell.text && cell.text.textElements ? this.extractTextFromTextElements(cell.text.textElements) : '';
        cells.push(cellText);
      }

      // 添加行，用|分隔单元格
      rows.push(cells.join(' | '));
    }
    return rows.join('\n');
  }

  /**
   * 调用LLM API进行分析
   * 注意：这里需要实现具体的API调用逻辑，可以使用Chrome extension的消息传递机制
   * @param prompt 提示内容
   * @returns LLM响应
   */
  async callLLMAPI(prompt) {
    try {
      // 使用callLLMJsonAPI函数调用实际的LLM API
      console.log('调用LLM API进行分析', prompt.substring(0, 100) + '...');

      // 准备请求体
      const requestBody = {
        prompt: prompt,
        type: 'analyze' // 根据实际需要调整类型
      };

      // 调用API并获取响应
      const response = await (0,_llm__WEBPACK_IMPORTED_MODULE_1__/* .callLLMJsonAPI */ .sc)(requestBody);

      // 如果没有有效响应，提供默认结构
      if (!response || typeof response !== 'object') {
        return {
          projects: [],
          confidence: 0,
          analysis: "LLM分析未返回有效数据"
        };
      }
      return response;
    } catch (error) {
      console.error('LLM API调用错误:', error);
      // 出错时返回默认结构
      return {
        projects: [],
        confidence: 0,
        analysis: `LLM API调用错误: ${error instanceof Error ? error.message : String(error)}`
      };
    }
  }

  /**
   * 解析LLM响应
   * @param response LLM响应对象
   * @param elementMap 元素ID映射表
   * @param slideId 幻灯片ID
   * @returns 项目数据数组
   */
  parseLLMResponse(response, elementMap, slideId) {
    if (!response || !response.projects || !Array.isArray(response.projects)) {
      return [];
    }

    // 转换LLM返回的项目数据
    return response.projects.map(project => {
      // 获取实际元素ID
      const mappedElementId = project.elementId && elementMap.has(project.elementId) ? elementMap.get(project.elementId) : undefined;

      // 创建项目数据对象
      const projectData = {
        id: project.id || `llm-project-${slideId}-${Math.random().toString(36).substr(2, 9)}`,
        name: project.name || '',
        status: project.status || '',
        owner: project.owner || '',
        slideId: slideId,
        slideElementId: mappedElementId
      };

      // 添加可选字段
      if (project.track) {
        projectData.track = project.track;
      }
      if (project.comments) {
        projectData.comments = project.comments;
      }
      return projectData;
    });
  }

  /**
   * 计算LLM分析结果的置信度
   * @param projects 项目数据数组
   * @param llmResponse LLM响应
   * @returns 置信度(0-1)
   */
  calculateLLMConfidence(projects, llmResponse) {
    // 如果LLM提供了置信度，直接使用
    if (llmResponse.confidence !== undefined && typeof llmResponse.confidence === 'number' && llmResponse.confidence >= 0 && llmResponse.confidence <= 1) {
      return llmResponse.confidence;
    }

    // 否则计算基于项目数据的置信度
    if (projects.length === 0) {
      return 0;
    }
    let score = 0;

    // 1. 项目数量评分
    if (projects.length >= 3) {
      score += 0.3;
    } else if (projects.length >= 1) {
      score += 0.1;
    }

    // 2. 字段完整性评分
    let completenessScore = 0;
    let totalFields = 0;
    for (const project of projects) {
      let projectFields = 0;
      let filledFields = 0;
      for (const field of ['id', 'name', 'status', 'owner', 'track', 'comments']) {
        projectFields++;
        if (project[field]) {
          filledFields++;
        }
      }
      completenessScore += filledFields / projectFields;
      totalFields++;
    }
    score += completenessScore / totalFields * 0.4;

    // 3. Jira ID评分
    const jiraProjects = projects.filter(p => /[A-Z]+-\d+/.test(p.id));
    score += jiraProjects.length / projects.length * 0.3;
    return Math.min(1, score);
  }

  /**
   * 确定项目共有的字段
   * @param projects 项目数组
   * @returns 共有字段名数组
   */
  determineCommonFields(projects) {
    if (projects.length === 0) {
      return [];
    }
    const fields = new Set(['id', 'name']);

    // 计算每个字段的存在比例
    const fieldCounts = {
      status: 0,
      owner: 0,
      track: 0,
      comments: 0
    };
    for (const project of projects) {
      if (project.status) fieldCounts.status++;
      if (project.owner) fieldCounts.owner++;
      if (project.track) fieldCounts.track++;
      if (project.comments) fieldCounts.comments++;
    }

    // 如果字段在超过30%的项目中存在，认为是共有字段
    const threshold = projects.length * 0.3;
    for (const [field, count] of Object.entries(fieldCounts)) {
      if (count >= threshold) {
        fields.add(field);
      }
    }
    return Array.from(fields);
  }
}
// 最小需要的置信度阈值
LLMContentAnalyzer.MIN_CONFIDENCE_THRESHOLD = 0.4;

/***/ }),

/***/ 6945:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ TableContentAnalyzerImpl)
/* harmony export */ });
/* harmony import */ var _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(38275);
/* harmony import */ var _baseAnalyzer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26308);
/**
 * 表格内容分析器实现
 */



/**
 * 表格分析器类
 * 专门处理表格样式的项目数据
 */
class TableContentAnalyzerImpl extends _baseAnalyzer__WEBPACK_IMPORTED_MODULE_1__/* .BaseSlideAnalyzer */ .Z {
  /**
   * 判断是否可以处理此类型的幻灯片
   * @param slide 幻灯片对象
   * @returns 是否可以处理
   */
  canHandle(slide) {
    // 检查是否有表格元素
    if (!slide.pageElements) return false;
    const hasTable = slide.pageElements.some(element => element.table !== undefined);
    if (!hasTable) return false;

    // 如果有表格，进一步检查表格是否可能包含项目数据
    const contentType = this.determineContentType(slide);
    return contentType === _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .SlideContentType */ .l.TABLE || contentType === _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .SlideContentType */ .l.MIXED;
  }

  /**
   * 分析表格内容
   * @param slide 幻灯片对象
   * @param contentType 内容类型
   * @returns 分析结果
   */
  async analyzeContent(slide, contentType) {
    if (!slide.pageElements) {
      return {
        projects: [],
        confidence: 0
      };
    }

    // 查找所有表格元素
    const tableElements = slide.pageElements.filter(element => element.table);
    if (tableElements.length === 0) {
      return {
        projects: [],
        confidence: 0
      };
    }

    // 分析所有表格，找出最可能包含项目数据的表格
    const allTableResults = [];
    for (const tableElement of tableElements) {
      try {
        const result = await this.analyzeTable(tableElement);

        // 计算此表格的置信度
        const confidence = this.calculateTableConfidence(result.headers, result.columnMapping, result.projectRows);

        // 提取项目字段名称
        const projectFields = Object.keys(result.columnMapping).filter(field => result.columnMapping[field] !== -1);
        allTableResults.push({
          projects: result.projectRows,
          tableElement,
          confidence,
          columnMapping: result.columnMapping,
          projectFields
        });
      } catch (error) {
        console.error('表格分析错误:', error);
        // 继续分析下一个表格
      }
    }

    // 如果没有找到任何项目数据，返回空结果
    if (allTableResults.length === 0) {
      return {
        projects: [],
        confidence: 0
      };
    }

    // 选择置信度最高的表格结果
    allTableResults.sort((a, b) => b.confidence - a.confidence);
    const bestResult = allTableResults[0];
    const warnings = [];

    // 如果有多个表格，但无法确定主表格，添加警告
    if (allTableResults.length > 1 && bestResult.confidence > 0 && allTableResults[1].confidence > bestResult.confidence * 0.8) {
      warnings.push('幻灯片包含多个可能的项目表格，已选择最可能的一个进行分析');
    }

    // 如果最佳表格的置信度仍然很低，添加警告
    if (bestResult.confidence < 0.5) {
      warnings.push('表格结构识别置信度较低，可能不是标准项目表格');
    }
    return {
      projects: bestResult.projects,
      confidence: bestResult.confidence,
      projectFields: bestResult.projectFields,
      warnings: warnings.length > 0 ? warnings : undefined
    };
  }

  /**
   * 分析表格结构
   * @param tableElement 表格元素
   * @returns 表格分析结果
   */
  async analyzeTable(tableElement) {
    if (!tableElement.table || !tableElement.table.tableRows) {
      throw new Error('无效的表格元素');
    }
    const tableData = tableElement.table;
    const tableId = tableElement.objectId;
    if (tableData.tableRows.length < 2) {
      throw new Error('表格行数不足');
    }

    // 获取表头行
    const headerRow = tableData.tableRows[0];
    if (!headerRow.tableCells) {
      throw new Error('表头行不包含单元格');
    }

    // 解析表头
    const headers = headerRow.tableCells.map(cell => {
      if (!cell.text || !cell.text.textElements) return '';
      return cell.text.textElements.map(textElement => textElement.textRun?.content || '').join('').toLowerCase().trim();
    });

    // 识别列索引，采用更智能的列名匹配
    const columnMapping = this.mapColumnIndices(headers);

    // 处理数据行
    const projectRows = [];
    for (let i = 1; i < tableData.tableRows.length; i++) {
      const row = tableData.tableRows[i];
      if (!row.tableCells) continue;
      const cells = row.tableCells;

      // 确保有足够的单元格
      const requiredColumns = [columnMapping.description, columnMapping.status].filter(idx => idx !== -1);
      const maxRequiredColumn = Math.max(...requiredColumns);
      if (cells.length <= maxRequiredColumn) {
        // 跳过没有足够列的行
        continue;
      }
      try {
        // 提取项目数据
        const project = this.extractProjectFromRow(tableId, cells, columnMapping, i);
        if (project) {
          projectRows.push(project);
        }
      } catch (error) {
        console.warn(`处理第${i}行时出错:`, error);
        // 继续处理下一行
      }
    }
    return {
      headers,
      columnMapping,
      projectRows
    };
  }

  /**
   * 智能匹配列索引
   * 使用模糊匹配和同义词来识别列的用途
   * @param headers 表头文本数组
   * @returns 列映射
   */
  mapColumnIndices(headers) {
    const columnMapping = {
      status: -1,
      description: -1,
      owner: -1,
      track: -1,
      comments: -1
    };

    // 对每个表头，检查是否匹配任一类型的列
    for (let i = 0; i < headers.length; i++) {
      const header = headers[i];

      // 状态列检查
      if (TableContentAnalyzerImpl.STATUS_COLUMNS.some(keyword => header.includes(keyword))) {
        columnMapping.status = i;
      }

      // 描述列检查
      if (TableContentAnalyzerImpl.DESCRIPTION_COLUMNS.some(keyword => header.includes(keyword))) {
        columnMapping.description = i;
      }

      // 负责人列检查
      if (TableContentAnalyzerImpl.OWNER_COLUMNS.some(keyword => header.includes(keyword))) {
        columnMapping.owner = i;
      }

      // 赛道列检查
      if (TableContentAnalyzerImpl.TRACK_COLUMNS.some(keyword => header.includes(keyword))) {
        columnMapping.track = i;
      }

      // 备注列检查
      if (TableContentAnalyzerImpl.COMMENTS_COLUMNS.some(keyword => header.includes(keyword))) {
        columnMapping.comments = i;
      }
    }

    // 如果找不到显式的描述列，尝试使用第一列作为描述列
    if (columnMapping.description === -1 && headers.length > 0) {
      columnMapping.description = 0;
    }
    return columnMapping;
  }

  /**
   * 从表格行提取项目数据
   * @param tableId 表格ID
   * @param cells 行单元格
   * @param columnMapping 列索引映射
   * @param rowIndex 行索引
   * @returns 项目数据
   */
  extractProjectFromRow(tableId, cells, columnMapping, rowIndex) {
    // 提取描述单元格内容
    if (columnMapping.description === -1) {
      return null; // 缺少描述列，无法识别项目
    }
    const descriptionCell = cells[columnMapping.description];
    if (!descriptionCell.text || !descriptionCell.text.textElements) {
      return null; // 描述单元格为空
    }
    const descriptionText = descriptionCell.text.textElements.map(textElement => textElement.textRun?.content || '').join('');

    // 如果描述为空，跳过此行
    if (!descriptionText.trim()) {
      return null;
    }

    // 提取Jira工单ID
    const jiraTicketMatch = descriptionText.match(/([A-Z]+-\d+)/);
    const jiraTicketId = jiraTicketMatch ? jiraTicketMatch[0] : '';

    // 提取项目名称
    let projectName = descriptionText;
    if (jiraTicketId) {
      projectName = projectName.replace(jiraTicketId, '').trim();
      // 如果有冒号，取冒号后的部分
      if (projectName.includes(':')) {
        projectName = projectName.split(':')[1].trim();
      }
    }

    // 获取状态信息
    let statusText = '';
    if (columnMapping.status !== -1) {
      const statusCell = cells[columnMapping.status];
      statusText = statusCell.text && statusCell.text.textElements ? statusCell.text.textElements.map(textElement => textElement.textRun?.content || '').join('').trim() : '';
    }

    // 获取负责人信息
    let ownerText = '';
    if (columnMapping.owner !== -1) {
      const ownerCell = cells[columnMapping.owner];
      ownerText = ownerCell.text && ownerCell.text.textElements ? ownerCell.text.textElements.map(textElement => textElement.textRun?.content || '').join('').trim() : '';
    }

    // 创建项目数据对象
    const project = {
      id: jiraTicketId || `project-${tableId}-${rowIndex}`,
      name: projectName,
      status: statusText,
      owner: ownerText,
      tableId: tableId,
      row: rowIndex,
      columnIndices: columnMapping
    };

    // 添加可选字段
    if (columnMapping.track !== -1) {
      const trackCell = cells[columnMapping.track];
      project.track = trackCell.text && trackCell.text.textElements ? trackCell.text.textElements.map(textElement => textElement.textRun?.content || '').join('').trim() : '';
    }
    if (columnMapping.comments !== -1) {
      const commentsCell = cells[columnMapping.comments];
      project.comments = commentsCell.text && commentsCell.text.textElements ? commentsCell.text.textElements.map(textElement => textElement.textRun?.content || '').join('').trim() : '';
    }
    return project;
  }

  /**
   * 计算表格的项目数据置信度
   * @param headers 表头
   * @param columnMapping 列映射
   * @param projects 提取的项目数据
   * @returns 置信度分数(0-1)
   */
  calculateTableConfidence(headers, columnMapping, projects) {
    let score = 0;

    // 1. 检查是否识别到关键列
    if (columnMapping.status !== -1) score += 0.2;
    if (columnMapping.description !== -1) score += 0.2;
    if (columnMapping.owner !== -1) score += 0.1;
    if (columnMapping.track !== -1) score += 0.05;
    if (columnMapping.comments !== -1) score += 0.05;

    // 2. 检查项目数据有效性
    if (projects.length === 0) {
      return 0; // 没有提取到项目
    }

    // 计算包含Jira工单ID的项目比例
    const jiraProjects = projects.filter(p => /[A-Z]+-\d+/.test(p.id));
    const jiraRatio = jiraProjects.length / projects.length;
    score += jiraRatio * 0.2;

    // 3. 检查表格结构
    if (headers.length >= 3) score += 0.1; // 表格列数适中
    if (projects.length >= 2) score += 0.1; // 有多行项目数据

    return Math.min(1, score);
  }
}
// 识别项目状态的常见列名
TableContentAnalyzerImpl.STATUS_COLUMNS = ['status', 'state', 'stage', '状态', '阶段'];
// 识别项目描述的常见列名
TableContentAnalyzerImpl.DESCRIPTION_COLUMNS = ['project', 'description', 'summary', 'name', 'title', '项目', '描述', '名称', '标题'];
// 识别项目负责人的常见列名
TableContentAnalyzerImpl.OWNER_COLUMNS = ['owner', 'assignee', 'responsible', 'person', 'lead', 'reporter', '负责人', '责任人', '所有者', '执行者'];
// 识别赛道/团队的常见列名
TableContentAnalyzerImpl.TRACK_COLUMNS = ['track', 'team', 'group', 'department', 'area', '赛道', '团队', '组别', '部门', '分类'];
// 识别备注/注释的常见列名
TableContentAnalyzerImpl.COMMENTS_COLUMNS = ['comment', 'note', 'action', 'item', 'todo', 'remarks', 'hightlight', '备注', '注释', '行动项', '待办'];

/***/ }),

/***/ 21394:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   N: () => (/* binding */ TextContentAnalyzerImpl)
/* harmony export */ });
/* harmony import */ var _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(38275);
/* harmony import */ var _baseAnalyzer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26308);
/**
 * 文本内容分析器实现
 */



/**
 * 文本结构类型
 */
var TextStructureType = /*#__PURE__*/function (TextStructureType) {
  TextStructureType["PARAGRAPH"] = "paragraph";
  TextStructureType["BULLET_LIST"] = "bullet_list";
  TextStructureType["NUMBERED_LIST"] = "numbered_list";
  TextStructureType["MIXED"] = "mixed";
  return TextStructureType;
}(TextStructureType || {});
/**
 * 文本块信息
 */
/**
 * 文本内容分析器类
 * 处理基于文本和列表的项目信息
 */
class TextContentAnalyzerImpl extends _baseAnalyzer__WEBPACK_IMPORTED_MODULE_1__/* .BaseSlideAnalyzer */ .Z {
  /**
   * 判断是否可以处理此类型的幻灯片
   * @param slide 幻灯片对象
   * @returns 是否可以处理
   */
  canHandle(slide) {
    if (!slide.pageElements) return false;
    const metadata = this.analyzeSlideMetadata(slide);
    const contentType = this.determineContentType(slide);

    // 能处理文本、列表或混合(但不以表格为主)的幻灯片
    return contentType === _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .SlideContentType */ .l.TEXT || contentType === _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .SlideContentType */ .l.LIST || contentType === _interfaces_slideAnalyzer__WEBPACK_IMPORTED_MODULE_0__/* .SlideContentType */ .l.MIXED && !metadata.hasTable;
  }

  /**
   * 分析文本内容
   * @param slide 幻灯片对象
   * @param contentType 内容类型
   * @returns 分析结果
   */
  async analyzeContent(slide, contentType) {
    if (!slide.pageElements) {
      return {
        projects: [],
        confidence: 0
      };
    }

    // 获取所有文本元素
    const textElements = slide.pageElements.filter(element => element.shape && element.shape.text || element.table && element.table.tableRows);
    if (textElements.length === 0) {
      return {
        projects: [],
        confidence: 0
      };
    }
    try {
      // 分析文本元素
      const result = await this.analyzeTextElements(textElements);

      // 计算置信度
      const confidence = this.calculateTextConfidence(result.projects);

      // 生成警告
      const warnings = [];
      if (confidence < 0.4) {
        warnings.push('文本结构识别置信度较低，可能无法准确提取所有项目信息');
      }
      if (result.projects.length === 0) {
        warnings.push('未能从文本中提取项目数据，请检查幻灯片内容格式');
      }
      return {
        projects: result.projects,
        projectFields: result.projectFields,
        confidence,
        warnings: warnings.length > 0 ? warnings : undefined
      };
    } catch (error) {
      console.error('文本分析错误:', error);
      return {
        projects: [],
        confidence: 0,
        warnings: [`文本分析错误: ${error instanceof Error ? error.message : String(error)}`]
      };
    }
  }

  /**
   * 分析文本元素
   * @param elements 页面元素数组
   * @returns 文本分析结果
   */
  async analyzeTextElements(elements) {
    // 提取文本块
    const textBlocks = this.extractTextBlocks(elements);

    // 构建文本结构树
    const structuredBlocks = this.buildTextStructureTree(textBlocks);

    // 根据结构提取项目
    const projects = this.extractProjectsFromTextStructure(structuredBlocks);

    // 确定项目共有字段
    const projectFields = this.determineCommonFields(projects);
    return {
      projectFields,
      projects
    };
  }

  /**
   * 从页面元素中提取文本块
   * @param elements 页面元素数组
   * @returns 文本块数组
   */
  extractTextBlocks(elements) {
    const blocks = [];
    let index = 0;
    for (const element of elements) {
      // 处理形状中的文本
      if (element.shape && element.shape.text && element.shape.text.textElements) {
        const shapeBlocks = this.extractTextBlocksFromShape(element.shape, element.objectId, index);
        blocks.push(...shapeBlocks);
        index += shapeBlocks.length;
      }
    }
    return blocks;
  }

  /**
   * 从形状中提取文本块
   * @param shape 形状对象
   * @param elementId 元素ID
   * @param startIndex 起始索引
   * @returns 文本块数组
   */
  extractTextBlocksFromShape(shape, elementId, startIndex) {
    const blocks = [];
    if (!shape.text || !shape.text.textElements) {
      return blocks;
    }
    let currentBlock = null;
    let currentContent = [];
    let currentType = TextStructureType.PARAGRAPH;
    let currentLevel = 0;
    let isBold = false;
    let fontSize = 0;

    // 遍历文本元素
    for (const textElement of shape.text.textElements) {
      // 处理段落标记
      if (textElement.paragraphMarker) {
        // 如果已经有内容，保存当前块
        if (currentContent.length > 0 && currentBlock) {
          currentBlock.content = currentContent.join('').trim();
          if (currentBlock.content) {
            blocks.push(currentBlock);
          }
        }

        // 开始新块
        currentContent = [];

        // 确定块类型
        if (textElement.paragraphMarker.style?.bulletPreset) {
          currentType = TextStructureType.BULLET_LIST;

          // 根据缩进确定级别
          const indent = textElement.paragraphMarker.style.indent?.magnitude || 0;
          currentLevel = Math.floor(indent / 20); // 假设每级缩进20单位
        } else {
          currentType = TextStructureType.PARAGRAPH;
          currentLevel = 0;
        }
        currentBlock = {
          elementId,
          content: '',
          type: currentType,
          level: currentLevel,
          isBold: false,
          fontSize: 0,
          isTitle: false,
          index: startIndex + blocks.length
        };
      }

      // 处理文本内容
      if (textElement.textRun) {
        // 获取样式信息
        const style = textElement.textRun.style;
        if (style) {
          isBold = style.bold || false;
          fontSize = style.fontSize?.magnitude || 0;
        }

        // 添加文本
        const content = textElement.textRun.content || '';
        currentContent.push(content);

        // 如果是第一个文本元素，更新块的样式信息
        if (currentBlock && currentContent.length === 1) {
          currentBlock.isBold = isBold;
          currentBlock.fontSize = fontSize;
          currentBlock.isTitle = fontSize > 14 || isBold; // 根据字体大小和粗体判断是否是标题
        }
      }
    }

    // 保存最后一个块
    if (currentContent.length > 0 && currentBlock) {
      currentBlock.content = currentContent.join('').trim();
      if (currentBlock.content) {
        blocks.push(currentBlock);
      }
    }
    return blocks;
  }

  /**
   * 构建文本结构树
   * @param blocks 文本块数组
   * @returns 结构化的文本块数组
   */
  buildTextStructureTree(blocks) {
    // 按索引排序
    blocks.sort((a, b) => a.index - b.index);

    // 构建层级结构树
    const rootBlocks = [];
    const stack = [];
    for (const block of blocks) {
      // 重置堆栈，直到找到适当的父级
      while (stack.length > 0 && stack[stack.length - 1].level >= block.level) {
        stack.pop();
      }
      if (stack.length === 0) {
        // 顶层块
        rootBlocks.push(block);
      } else {
        // 添加为子块
        const parent = stack[stack.length - 1];
        if (!parent.children) {
          parent.children = [];
        }
        parent.children.push(block);
      }

      // 如果不是列表项，或者是标题，不入栈
      if (block.type !== TextStructureType.BULLET_LIST || block.isTitle) {
        continue;
      }

      // 当前块入栈
      stack.push(block);
    }
    return rootBlocks;
  }

  /**
   * 从文本结构中提取项目
   * @param blocks 结构化的文本块数组
   * @returns 项目数据数组
   */
  extractProjectsFromTextStructure(blocks) {
    const projects = [];

    // 识别不同的项目结构模式并提取

    // 模式1: 标题或列表项是项目名称，子项是项目详情
    this.extractProjectsFromTitleChildrenPattern(blocks, projects);

    // 模式2: 列表项包含完整的项目信息
    this.extractProjectsFromListItemPattern(blocks, projects);

    // 模式3: 段落文本包含完整的项目信息
    this.extractProjectsFromParagraphPattern(blocks, projects);
    return projects;
  }

  /**
   * 从标题-子项模式中提取项目
   * @param blocks 文本块数组
   * @param projects 项目数组（输出）
   */
  extractProjectsFromTitleChildrenPattern(blocks, projects) {
    for (const block of blocks) {
      // 只考虑有子项的标题或列表项
      if (!block.children || block.children.length === 0) {
        continue;
      }

      // 尝试从标题中提取项目ID和名称
      const titleText = block.content;
      const jiraMatch = TextContentAnalyzerImpl.JIRA_TICKET_PATTERN.exec(titleText);
      if (!jiraMatch) {
        // 如果没有Jira ID，可能不是项目标题，递归处理子项
        if (block.children) {
          this.extractProjectsFromTitleChildrenPattern(block.children, projects);
        }
        continue;
      }
      const jiraId = jiraMatch[1];
      let projectName = titleText.replace(jiraId, '').trim();

      // 如果有冒号，取冒号后的部分
      if (projectName.includes(':')) {
        projectName = projectName.split(':')[1].trim();
      } else if (projectName.includes('：')) {
        projectName = projectName.split('：')[1].trim();
      }

      // 从子项中提取项目详情
      let status = '';
      let owner = '';
      let track = '';
      let comments = '';
      for (const child of block.children) {
        const childText = child.content.toLowerCase();

        // 尝试匹配状态
        for (const pattern of TextContentAnalyzerImpl.STATUS_PATTERNS) {
          const match = pattern.exec(child.content);
          if (match) {
            status = match[1] || match[0];
            break;
          }
        }

        // 如果没有通过模式匹配找到，通过关键词查找
        if (!status && (childText.includes('状态') || childText.includes('status'))) {
          status = child.content.replace(/状态[:：]|status[:：]/i, '').trim();
        }

        // 尝试匹配负责人
        for (const pattern of TextContentAnalyzerImpl.OWNER_PATTERNS) {
          const match = pattern.exec(child.content);
          if (match) {
            owner = match[1] || match[0];
            break;
          }
        }

        // 如果没有通过模式匹配找到，通过关键词查找
        if (!owner && (childText.includes('负责人') || childText.includes('责任人') || childText.includes('owner') || childText.includes('assignee'))) {
          owner = child.content.replace(/负责人[:：]|责任人[:：]|owner[:：]|assignee[:：]/i, '').trim();
        }

        // 尝试匹配赛道/团队
        for (const pattern of TextContentAnalyzerImpl.TRACK_PATTERNS) {
          const match = pattern.exec(child.content);
          if (match) {
            track = match[1] || match[0];
            break;
          }
        }

        // 添加其他未识别内容为备注
        if (!childText.includes('状态') && !childText.includes('status') && !childText.includes('负责人') && !childText.includes('责任人') && !childText.includes('owner') && !childText.includes('assignee') && !childText.includes('赛道') && !childText.includes('团队') && !childText.includes('track') && !childText.includes('team')) {
          if (comments) {
            comments += '\n';
          }
          comments += child.content;
        }
      }

      // 创建项目数据
      projects.push({
        id: jiraId,
        name: projectName,
        status: status,
        owner: owner,
        track: track,
        comments: comments,
        slideElementId: block.elementId
      });
    }
  }

  /**
   * 从列表项模式中提取项目
   * @param blocks 文本块数组
   * @param projects 项目数组（输出）
   */
  extractProjectsFromListItemPattern(blocks, projects) {
    for (const block of blocks) {
      if (block.type !== TextStructureType.BULLET_LIST && block.type !== TextStructureType.NUMBERED_LIST) {
        // 递归处理子项
        if (block.children) {
          this.extractProjectsFromListItemPattern(block.children, projects);
        }
        continue;
      }
      const content = block.content;
      const jiraMatch = TextContentAnalyzerImpl.JIRA_TICKET_PATTERN.exec(content);
      if (!jiraMatch) {
        // 递归处理子项
        if (block.children) {
          this.extractProjectsFromListItemPattern(block.children, projects);
        }
        continue;
      }
      const jiraId = jiraMatch[1];
      let projectName = content.replace(jiraId, '').trim();

      // 分离项目名称和其他信息
      let status = '';
      let owner = '';
      const track = '';
      let comments = '';

      // 尝试提取状态（通常在方括号或其他标记中）
      const statusMatches = content.match(/\[(.*?)\]/);
      if (statusMatches) {
        status = statusMatches[1];
        projectName = projectName.replace(/\[.*?\]/, '').trim();
      }

      // 尝试提取负责人（通常使用@符号）
      const ownerMatches = content.match(/@([^\s]+)/);
      if (ownerMatches) {
        owner = ownerMatches[1];
        projectName = projectName.replace(/@[^\s]+/, '').trim();
      }

      // 提取项目名称（通常在冒号后）
      if (projectName.includes(':')) {
        const parts = projectName.split(':');
        if (parts.length >= 2) {
          comments = parts.slice(2).join(':').trim();
          projectName = parts[1].trim();
        }
      } else if (projectName.includes('：')) {
        const parts = projectName.split('：');
        if (parts.length >= 2) {
          comments = parts.slice(2).join('：').trim();
          projectName = parts[1].trim();
        }
      }

      // 创建项目数据
      projects.push({
        id: jiraId,
        name: projectName,
        status: status,
        owner: owner,
        track: track,
        comments: comments,
        slideElementId: block.elementId
      });

      // 递归处理子项（如果有）
      if (block.children) {
        // 将子项内容作为当前项目的评论/备注
        for (const child of block.children) {
          if (projects[projects.length - 1].comments) {
            projects[projects.length - 1].comments += '\n';
          } else {
            projects[projects.length - 1].comments = '';
          }
          projects[projects.length - 1].comments += child.content;
        }
      }
    }
  }

  /**
   * 从段落模式中提取项目
   * @param blocks 文本块数组
   * @param projects 项目数组（输出）
   */
  extractProjectsFromParagraphPattern(blocks, projects) {
    for (const block of blocks) {
      if (block.type !== TextStructureType.PARAGRAPH) {
        // 递归处理子项
        if (block.children) {
          this.extractProjectsFromParagraphPattern(block.children, projects);
        }
        continue;
      }
      const content = block.content;
      const jiraMatches = content.match(/[A-Z]+-\d+/g);
      if (!jiraMatches || jiraMatches.length === 0) {
        continue;
      }

      // 对于每个匹配的Jira ID，尝试提取相关项目信息
      for (const jiraId of jiraMatches) {
        const jiraIndex = content.indexOf(jiraId);
        const textAfterJira = content.substring(jiraIndex + jiraId.length);

        // 提取项目名称（假设在Jira ID后面的文本到下一个分隔符）
        let projectName = textAfterJira.trim();
        let status = '';
        let owner = '';
        let comments = '';

        // 处理冒号后的内容
        if (projectName.startsWith(':')) {
          projectName = projectName.substring(1).trim();
        }

        // 提取状态（如果有）
        const statusMatch = textAfterJira.match(/\[(.*?)\]/);
        if (statusMatch) {
          status = statusMatch[1];
          projectName = projectName.replace(/\[.*?\]/, '').trim();
        }

        // 提取负责人（如果有）
        const ownerMatch = textAfterJira.match(/@([^\s]+)/);
        if (ownerMatch) {
          owner = ownerMatch[1];
          projectName = projectName.replace(/@[^\s]+/, '').trim();
        }

        // 如果有多个句子，可能后面的是评论
        const sentences = projectName.split(/[.。]/);
        if (sentences.length > 1) {
          projectName = sentences[0].trim();
          comments = sentences.slice(1).join('.').trim();
        }

        // 创建项目数据
        projects.push({
          id: jiraId,
          name: projectName,
          status: status,
          owner: owner,
          comments: comments,
          slideElementId: block.elementId
        });
      }
    }
  }

  /**
   * 确定项目共有的字段
   * @param projects 项目数组
   * @returns 共有字段名数组
   */
  determineCommonFields(projects) {
    if (projects.length === 0) {
      return [];
    }
    const fields = new Set(['id', 'name']);

    // 计算每个字段的存在比例
    const fieldCounts = {
      status: 0,
      owner: 0,
      track: 0,
      comments: 0
    };
    for (const project of projects) {
      if (project.status) fieldCounts.status++;
      if (project.owner) fieldCounts.owner++;
      if (project.track) fieldCounts.track++;
      if (project.comments) fieldCounts.comments++;
    }

    // 如果字段在超过30%的项目中存在，认为是共有字段
    const threshold = projects.length * 0.3;
    for (const [field, count] of Object.entries(fieldCounts)) {
      if (count >= threshold) {
        fields.add(field);
      }
    }
    return Array.from(fields);
  }

  /**
   * 计算文本分析的置信度
   * @param projects 提取的项目
   * @returns 置信度分数(0-1)
   */
  calculateTextConfidence(projects) {
    if (projects.length === 0) {
      return 0;
    }
    let score = 0;

    // 1. 项目数量评分
    if (projects.length >= 3) {
      score += 0.3;
    } else if (projects.length >= 1) {
      score += 0.1;
    }

    // 2. 字段完整性评分
    let completenessScore = 0;
    let totalFields = 0;
    for (const project of projects) {
      let projectFields = 0;
      let filledFields = 0;
      for (const field of ['id', 'name', 'status', 'owner', 'track', 'comments']) {
        projectFields++;
        if (project[field]) {
          filledFields++;
        }
      }
      completenessScore += filledFields / projectFields;
      totalFields++;
    }
    score += completenessScore / totalFields * 0.4;

    // 3. Jira ID评分
    const jiraProjects = projects.filter(p => /[A-Z]+-\d+/.test(p.id));
    score += jiraProjects.length / projects.length * 0.3;
    return Math.min(1, score);
  }
}
// Jira工单ID模式
TextContentAnalyzerImpl.JIRA_TICKET_PATTERN = /([A-Z]+-\d+)/;
// 项目状态关键词和正则表达式
TextContentAnalyzerImpl.STATUS_PATTERNS = [/状态[:：]\s*([^,，。\n]+)/i, /status[:：]\s*([^,，。\n]+)/i, /\[(进行中|完成|待办|阻塞|延期|取消)\]/i, /\[(in progress|done|todo|blocked|delayed|cancelled)\]/i];
// 负责人关键词和正则表达式
TextContentAnalyzerImpl.OWNER_PATTERNS = [/负责人[:：]\s*([^,，。\n]+)/i, /owner[:：]\s*([^,，。\n]+)/i, /责任人[:：]\s*([^,，。\n]+)/i, /assignee[:：]\s*([^,，。\n]+)/i, /@([^\s]+)/];
// 赛道/团队关键词和正则表达式
TextContentAnalyzerImpl.TRACK_PATTERNS = [/赛道[:：]\s*([^,，。\n]+)/i, /团队[:：]\s*([^,，。\n]+)/i, /track[:：]\s*([^,，。\n]+)/i, /team[:：]\s*([^,，。\n]+)/i];

/***/ }),

/***/ 81929:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   zP: () => (/* binding */ getEmbeddingViaOffscreen)
/* harmony export */ });
/* unused harmony exports createOffscreenDocument, handleEmbeddingResult */
// 创建新文件处理嵌入相关功能
const pendingEmbeddingRequests = new Map();

// 创建离屏文档
async function createOffscreenDocument() {
  try {
    // 检查是否已经存在离屏文档
    const existingContexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT']
    });
    if (existingContexts.length > 0) {
      console.log('离屏文档已存在');
      return;
    }
    console.log('创建离屏文档...');
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['WORKERS'],
      justification: '需要使用 WebAssembly 来运行嵌入模型'
    });
    console.log('离屏文档创建成功');
  } catch (error) {
    console.error('创建离屏文档失败:', error);
  }
}

// 通过离屏文档获取嵌入向量
async function getEmbeddingViaOffscreen(text) {
  try {
    await createOffscreenDocument();

    // 生成唯一请求ID
    const requestId = Date.now().toString() + Math.random().toString().slice(2);

    // 创建Promise并存储
    const resultPromise = new Promise((resolve, reject) => {
      pendingEmbeddingRequests.set(requestId, {
        resolve,
        reject
      });

      // 设置超时
      setTimeout(() => {
        if (pendingEmbeddingRequests.has(requestId)) {
          pendingEmbeddingRequests.delete(requestId);
          reject(new Error('获取嵌入向量超时'));
        }
      }, 30000); // 30秒超时
    });

    // 发送消息到离屏文档
    chrome.runtime.sendMessage({
      type: 'GET_EMBEDDING',
      requestId,
      text
    });
    return resultPromise;
  } catch (error) {
    console.error('通过离屏文档获取嵌入向量失败:', error);
    return new Array(384).fill(0);
  }
}

// 处理嵌入结果
function handleEmbeddingResult(message) {
  if (message.type === 'EMBEDDING_RESULT') {
    const requestId = message.requestId;
    const pendingRequest = pendingEmbeddingRequests.get(requestId);
    if (pendingRequest) {
      pendingEmbeddingRequests.delete(requestId);
      pendingRequest.resolve(message.embedding);
    }
  }
}

/***/ }),

/***/ 38089:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony exports extractEntitiesToStore, extractEntitiesForQuery */
/* harmony import */ var _llm__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(68400);
// 新文件：实体识别和提取


// 使用LLM提取消息中的实体
async function extractEntitiesToStore(content) {
  let metadata = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  try {
    const prompt = `
    请分析以下消息，提取所有相关的实体信息和关系：
    
    消息内容：
    ${content}
    ${metadata.sender ? `消息发送者：${metadata.sender}` : ''}
    ${metadata.team_name ? `消息所在群组：${metadata.team_name}` : ''}
    ${metadata.summary ? `根据上下文得到的总结：${metadata.summary}` : ''}

    请严格按照以下 JSON 格式提取实体信息：
    {
      "entities": {
        "people": [
          {
            "name": "",
            "role": "",  // 角色，如"员工"、"客户"等
            "mentioned_context": ""  // 在消息中提及的上下文
          }
        ],
        "time": [
          {
            "raw": "",  // 原始时间表述
            "normalized": "",  // 标准化时间
            "type": ""  // deadline/schedule/mentioned
          }
        ],
        "location": [
          {
            "name": "",
            "type": ""  // office/remote/physical
          }
        ],
        "projects": [
          {
            "name": "",
            "status": "",  // 进行中/已完成/计划中
            "related_people": []  // 相关人员
          }
        ],
        "topics": [
          {
            "name": "",
            "category": "",  // 技术/业务/管理等
            "keywords": []
          }
        ],
        "resources": [
          {
            "type": "",  // 文档/链接/工具等
            "name": "",
            "location": ""
          }
        ]
      },
      "metadata": {
        "sentiment": "",  // positive/negative/neutral
        "priority": "",   // high/medium/low
        "category": [],   // 消息类别：决策/讨论/公告等
        "tags": []       // 自动标签
      },
      "relationships": [
        {
          "source": "",      // 实体1
          "target": "",      // 实体2
          "relationship": "" // 关系类型
        }
      ],
      "actions": [
        {
          "type": "",        // task/decision/followup
          "description": "", 
          "assignee": "",
          "deadline": null,  // 时间戳
          "status": ""      // pending/completed
        }
      ]
    }
    
    仅返回JSON，不要有其他内容。如果某类实体不存在，返回空数组。
    `;
    const entityData = await callLLMJsonAPI({
      prompt,
      type: 'query'
    });
    console.log('提取出的实体信息：', entityData);
    if (typeof entityData === 'object') {
      return {
        entities: {
          people: entityData.entities?.people || [],
          time: entityData.entities?.time || [],
          location: entityData.entities?.location || [],
          projects: entityData.entities?.projects || [],
          topics: entityData.entities?.topics || [],
          resources: entityData.entities?.resources || []
        },
        metadata: {
          sentiment: entityData.metadata?.sentiment || "neutral",
          priority: entityData.metadata?.priority || "medium",
          category: entityData.metadata?.category || [],
          tags: entityData.metadata?.tags || []
        },
        relationships: entityData.relationships || [],
        actions: entityData.actions || []
      };
    }
    return {
      entities: {
        people: [],
        time: [],
        location: [],
        projects: [],
        topics: [],
        resources: []
      },
      metadata: {
        sentiment: "neutral",
        priority: "medium",
        category: [],
        tags: []
      },
      relationships: [],
      actions: []
    };
  } catch (error) {
    console.error('实体提取失败:', error);
    return {
      entities: {
        people: [],
        time: [],
        location: [],
        projects: [],
        topics: [],
        resources: []
      },
      metadata: {
        sentiment: "neutral",
        priority: "medium",
        category: [],
        tags: []
      },
      relationships: [],
      actions: []
    };
  }
}
async function extractEntitiesForQuery(question) {
  try {
    const analysisPrompt = `
    分析以下问题，提取查询意图和关键实体。按JSON格式返回：
    
    问题: "${question}"
    
    {
      "query": {
        "intent": {
          "primary": "",     // search/analyze/summarize/compare
          "secondary": "",   // 具体查询类型，如project_status/person_info等
          "action_type": "" // retrieve/count/timeline/relationship
        },
        "filters": {
          "time_range": {
            "type": "recent|all|specific|range",
            "start": null,   // 时间戳
            "end": null,     // 时间戳
            "description": "" // 对时间范围的文字描述，如"今年"、"这个月"、"最近一周"等
          },
          "entities": {
            "people": [
              {
                "name": "",
                "role": "",
                "required": true  // 是否必须包含该人物
              }
            ],
            "projects": [
              {
                "name": "",
                "status": "",
                "required": true
              }
            ],
            "topics": [
              {
                "name": "",
                "category": "",
                "required": true
              }
            ],
            "location": [
              {
                "name": "",
                "type": "",
                "required": true
              }
            ]
          }
        },
        "output": {
          "format": "",     // list/timeline/summary/graph
          "fields": [],     // 需要返回的字段
          "sort": {
            "field": "",
            "order": "asc|desc"
          },
          "limit": null    // 结果数量限制
        }
      },
      "context": {
        "reference_time": null,  // 参考时间点
        "user_context": "",     // 用户查询上下文
        "priority": ""         // high/medium/low
      }
    }
    
    注意：
    1. time_range.type 必须是以下值之一：
       - "all"：表示所有时间，不指定则默认是 all
       - "recent"：仅表示最近几天，如"最近"、"近期"、"最近几天"
       - "specific"：表示具体时间点
       - "range"：表示时间范围
    2. 对于包含较长时间段的描述：
       - "这个月"、"本月"应设为range类型，而非recent
       - "今年"、"本年"应设为range类型，而非recent
       - "去年"、"上个月"等也应设为range类型
    3. 请在description字段中保留原始时间描述词，如"今年"、"这个月"等
    4. 所有时间戳必须是数字或null，不能是字符串
    5. 如果无法确定具体时间，相关时间字段设为null
    6. 时间疑问词表示查询事件发生时间，不是限制查询范围
    7. required 字段表示该实体是否为必需匹配项
    8. 重要：如果问题中没有明确的时间限定词（如"最近"、"今年"、"这个月"等），请将time_range.type设为"all"
    `;

    // 使用LLM分析问题
    const queryIntent = await callLLMJsonAPI({
      prompt: analysisPrompt,
      type: 'query'
    });
    return queryIntent;
  } catch (error) {
    console.error('查询意图分析失败:', error);
    return {
      query: {
        intent: {
          primary: "search",
          secondary: "general",
          action_type: "retrieve"
        },
        filters: {
          time_range: {
            type: "all",
            start: null,
            end: null,
            description: ""
          },
          entities: {
            people: [],
            projects: [],
            topics: [],
            location: []
          }
        },
        output: {
          format: "list",
          fields: [],
          sort: {
            field: "",
            order: "desc"
          },
          limit: 10
        }
      },
      context: {
        reference_time: null,
        user_context: "",
        priority: "medium"
      }
    };
  }
}

/***/ }),

/***/ 38275:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   l: () => (/* binding */ SlideContentType),
/* harmony export */   t: () => (/* binding */ ProjectStructureType)
/* harmony export */ });
/**
 * 幻灯片分析器接口定义
 */

/**
 * 幻灯片内容类型枚举
 */
let SlideContentType = /*#__PURE__*/function (SlideContentType) {
  SlideContentType["TABLE"] = "table";
  SlideContentType["TEXT"] = "text";
  SlideContentType["SHAPE"] = "shape";
  SlideContentType["LIST"] = "list";
  SlideContentType["MIXED"] = "mixed";
  SlideContentType["UNKNOWN"] = "unknown";
  return SlideContentType;
}({});

/**
 * 项目结构类型枚举
 */
let ProjectStructureType = /*#__PURE__*/function (ProjectStructureType) {
  ProjectStructureType["SINGLE_TICKET"] = "single_ticket";
  ProjectStructureType["SPRINT"] = "sprint";
  ProjectStructureType["EPIC"] = "epic";
  ProjectStructureType["RELEASE"] = "release";
  ProjectStructureType["MIXED"] = "mixed";
  ProjectStructureType["CUSTOM"] = "custom";
  ProjectStructureType["UNKNOWN"] = "unknown";
  return ProjectStructureType;
}({});

/**
 * 幻灯片内容分析结果
 */

/**
 * 幻灯片内容分析器接口
 */

/**
 * 表格内容分析器接口
 */

/**
 * 文本内容分析器接口
 */

/**
 * 元素引用记录
 */

/**
 * 带有元素引用的项目数据
 */

/**
 * 项目字段建议
 */

/**
 * 幻灯片分析器工厂接口
 */

/***/ }),

/***/ 68400:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   sc: () => (/* binding */ callLLMJsonAPI)
/* harmony export */ });
/* unused harmony exports handleLLMRequest, knowledgeQuery, OpenAIChat, DifyChat, GroqChat, OllamaChat */
/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16065);
/* harmony import */ var groq_sdk__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57025);
/* harmony import */ var _vectorStore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9041);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43922);
/* harmony import */ var _entityExtraction__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(38089);






// 根据不同 LLM 服务处理 LLM 请求，并提取 JSON 数据
async function handleLLMRequest(body) {
  const envConfig = await (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .getEnvConfig */ .Un)();
  let handler;
  switch (envConfig.LLM_TYPE) {
    case 'local':
      handler = handleOllamaRequest;
      if (body.type === 'review') body.model = envConfig.OLLAMA_REVIEW_MODEL;
      if (body.type === 'query') body.model = envConfig.OLLAMA_QUERY_MODEL;
      break;
    case 'groq':
      handler = handleGroqRequest;
      if (body.type === 'review') body.model = envConfig.GROQ_REVIEW_MODEL;
      break;
    case 'dify':
      handler = handleDifyRequest;
      if (body.type === 'review') body.apiKey = envConfig.DIFY_REVIEW_API_KEY;
      break;
    default:
      handler = handleOpenAIRequest;
      if (body.type === 'review') body.model = envConfig.OPENAI_REVIEW_MODEL;
  }
  const response = await handler(body);
  return response;
}

// 处理 Ollama 请求。Ollama 安装后需要把 launchctl setenv OLLAMA_ORIGINS "*" 加入到 .bashrc 中
async function handleOllamaRequest(body) {
  const envConfig = await (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .getEnvConfig */ .Un)();
  const response = await fetch(`${envConfig.OLLAMA_BASE_URL}/api/generate`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: body.model || envConfig.OLLAMA_MODEL,
      prompt: body.prompt,
      stream: false,
      temperature: 0.3,
      top_p: 0.9
    })
  });
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  const result = await response.json();
  return result.response;
}

// 处理 OpenAI 请求
async function handleOpenAIRequest(body) {
  const envConfig = await (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .getEnvConfig */ .Un)();
  // 初始化 OpenAI 客户端
  const openai = new openai__WEBPACK_IMPORTED_MODULE_3__["default"]({
    apiKey: envConfig.OPENAI_API_KEY,
    baseURL: envConfig.OPENAI_API_BASE_URL,
    dangerouslyAllowBrowser: true
  });
  const completion = await openai.chat.completions.create({
    model: envConfig.OPENAI_MODEL,
    messages: body.system_prompt ? [{
      role: "system",
      content: body.system_prompt
    }, {
      role: "user",
      content: body.user_prompt
    }] : [{
      role: "user",
      content: body.prompt
    }],
    temperature: 0.3,
    top_p: 0.9
  });
  return completion.choices[0].message.content || '';
}

// 处理 Groq 请求
async function handleGroqRequest(body) {
  const envConfig = await (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .getEnvConfig */ .Un)();
  // 初始化 Groq 客户端
  const groq = new groq_sdk__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Ay({
    apiKey: envConfig.GROQ_API_KEY,
    dangerouslyAllowBrowser: true
  });
  const completion = await groq.chat.completions.create({
    model: envConfig.GROQ_MODEL || 'mixtral-8x7b-32768',
    messages: body.system_prompt ? [{
      role: "system",
      content: body.system_prompt
    }, {
      role: "user",
      content: body.user_prompt
    }] : [{
      role: "user",
      content: body.prompt
    }],
    temperature: 0.3,
    top_p: 0.9
  });
  return completion.choices[0].message.content || '';
}

// 新增：处理 Dify 请求
async function handleDifyRequest(body) {
  const envConfig = await (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .getEnvConfig */ .Un)();
  // 新增：初始化 Dify API 配置
  const difyConfig = {
    apiKey: envConfig.DIFY_API_KEY,
    reviewApiKey: envConfig.DIFY_REVIEW_API_KEY,
    baseURL: envConfig.DIFY_API_BASE_URL || 'https://api.dify.ai/v1'
  };
  const response = await fetch(`${difyConfig.baseURL}/completion-messages`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${body.apiKey || difyConfig.apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      inputs: {
        query: body.prompt
      },
      // 可选的输入参数
      response_mode: 'blocking',
      // 改为 streaming 模式
      user: body.user || 'default-user' // 可选
    })
  });
  if (!response.ok) {
    throw new Error(`Dify API error! status: ${response.status}`);
  }
  const result = await response.json();
  return result.answer || '';
}

// 新增：从响应文本中提取 JSON 数据
function extractJsonFromResponse(response) {
  let jsonData = [];
  try {
    // 首先尝试直接解析整个响应
    try {
      const directParse = JSON.parse(response.trim());
      return directParse;
    } catch (e) {
      // 如果直接解析失败，继续尝试其他方法
    }

    // 尝试从响应中查找 JSON 代码块
    const jsonMatch = response.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
    if (jsonMatch) {
      const parsedData = JSON.parse(jsonMatch[1].trim());
      jsonData = parsedData;
    } else {
      // 尝试查找可能的 JSON 字符串（方括号或大括号开头和结尾）
      const jsonRegex = /(\[[\s\S]*\]|\{[\s\S]*\})/;
      const potentialJson = response.match(jsonRegex);
      if (potentialJson) {
        const parsedData = JSON.parse(potentialJson[1].trim());
        jsonData = parsedData;
      }
    }
  } catch (e) {
    console.warn('Failed to parse JSON from LLM response:', e);
  }
  return jsonData;
}

// 用通用查询函数替代原来的项目进展查询函数
async function knowledgeQuery(question) {
  console.log('knowledgeQuery', question, new Date().getTime());
  try {
    // 1. 从问题中识别查询意图和关键实体
    const queryIntent = await extractEntitiesForQuery(question);
    console.log('queryIntent', queryIntent, new Date().getTime());

    // 类型安全处理：确保时间范围有效
    if (queryIntent?.query?.filters?.time_range) {
      const timeRange = queryIntent.query.filters.time_range;

      // 处理时间疑问词
      if (timeRange.type === 'specific' && typeof timeRange.start === 'string') {
        console.warn(`非法的时间值: ${timeRange.start}，类型: ${typeof timeRange.start}`);

        // 检查是否是常见的时间疑问词
        const timeQuestionWords = ["什么时候", "何时", "几点", "哪天", "什么日期", "什么时间", "几号", "什么时段", "几月", "哪一天", "什么季节"];
        if (timeQuestionWords.some(word => timeRange.start.includes(word))) {
          console.log(`检测到时间疑问词: "${timeRange.start}"，将time_range.type设为"all"`);
          timeRange.type = "all";
          timeRange.start = null;
          timeRange.end = null;
        }
      }

      // 根据时间描述设置具体的时间范围
      if (timeRange.type === 'range' && timeRange.description) {
        const now = new Date();
        const thisYear = now.getFullYear();
        const thisMonth = now.getMonth();
        if (/今年|本年|今年度|本年度/.test(timeRange.description)) {
          // 今年范围：从今年1月1日到现在
          const startOfYear = new Date(thisYear, 0, 1).getTime();
          timeRange.start = startOfYear;
          timeRange.end = now.getTime();
          console.log(`设置今年时间范围: ${new Date(startOfYear).toISOString()} 到 ${new Date().toISOString()}`);
        } else if (/这个月|本月|当月/.test(timeRange.description)) {
          // 这个月范围：从本月1日到现在
          const startOfMonth = new Date(thisYear, thisMonth, 1).getTime();
          timeRange.start = startOfMonth;
          timeRange.end = now.getTime();
          console.log(`设置本月时间范围: ${new Date(startOfMonth).toISOString()} 到 ${new Date().toISOString()}`);
        } else if (/上个月|上月|前一个月/.test(timeRange.description)) {
          // 上个月范围
          const lastMonth = thisMonth === 0 ? 11 : thisMonth - 1;
          const lastMonthYear = thisMonth === 0 ? thisYear - 1 : thisYear;
          const startOfLastMonth = new Date(lastMonthYear, lastMonth, 1).getTime();
          const endOfLastMonth = new Date(thisYear, thisMonth, 0).getTime();
          timeRange.start = startOfLastMonth;
          timeRange.end = endOfLastMonth;
          console.log(`设置上月时间范围: ${new Date(startOfLastMonth).toISOString()} 到 ${new Date(endOfLastMonth).toISOString()}`);
        } else if (/去年|上一年|前一年/.test(timeRange.description)) {
          // 去年范围
          const lastYear = thisYear - 1;
          const startOfLastYear = new Date(lastYear, 0, 1).getTime();
          const endOfLastYear = new Date(lastYear, 11, 31, 23, 59, 59).getTime();
          timeRange.start = startOfLastYear;
          timeRange.end = endOfLastYear;
          console.log(`设置去年时间范围: ${new Date(startOfLastYear).toISOString()} 到 ${new Date(endOfLastYear).toISOString()}`);
        } else if (/过去(\d+)天|最近(\d+)天/.test(timeRange.description)) {
          // 过去N天
          const matches = timeRange.description.match(/过去(\d+)天|最近(\d+)天/);
          if (matches) {
            const days = parseInt(matches[1] || matches[2]);
            if (!isNaN(days)) {
              const pastDays = now.getTime() - days * 24 * 60 * 60 * 1000;
              timeRange.start = pastDays;
              timeRange.end = now.getTime();
              console.log(`设置过去${days}天时间范围: ${new Date(pastDays).toISOString()} 到 ${new Date().toISOString()}`);
            }
          }
        }
      }

      // 如果是recent类型，设置默认为过去7天
      if (timeRange.type === 'recent') {
        const now = new Date();
        const sevenDaysAgo = now.getTime() - 7 * 24 * 60 * 60 * 1000;
        timeRange.start = sevenDaysAgo;
        timeRange.end = now.getTime();
        console.log(`设置最近时间范围(7天): ${new Date(sevenDaysAgo).toISOString()} 到 ${new Date().toISOString()}`);
      }
    }

    // 1.5 获取所有已知人名、项目和主题进行模糊匹配
    // 1.5.1 人名模糊匹配
    if (queryIntent?.query?.filters?.entities?.people?.length > 0) {
      // 获取所有已知人名
      const knownPeople = await getAllKnownPeople();
      console.log('已知人名列表:', knownPeople);

      // 对每个识别出的人名进行模糊匹配
      const matchedPeople = [];
      for (const person of queryIntent.query.filters.entities.people) {
        const matchedPerson = fuzzyMatchPerson(person.name, knownPeople);
        if (matchedPerson) {
          console.log(`人名模糊匹配: "${person.name}" => "${matchedPerson}"`);
          matchedPeople.push({
            name: matchedPerson,
            role: person.role,
            required: person.required
          });
        } else {
          // 如果没有匹配到，保留原始人名
          matchedPeople.push(person);
        }
      }

      // 更新查询意图中的人名
      queryIntent.query.filters.entities.people = matchedPeople;
      console.log('更新后的人名列表:', queryIntent.query.filters.entities.people);
    }

    // 1.5.2 项目和主题的模糊匹配
    // 获取所有已知项目和主题
    const knownProjects = await getAllKnownProjects();
    const knownTopics = await getAllKnownTopics();
    console.log('已知项目列表:', knownProjects);
    console.log('已知主题列表:', knownTopics);

    // 项目模糊匹配
    if (queryIntent?.query?.filters?.entities?.projects?.length > 0) {
      const matchedProjects = [];
      for (const project of queryIntent.query.filters.entities.projects) {
        const matchedNames = fuzzyMatchEntityName(project.name, knownProjects);
        if (matchedNames.length > 0) {
          console.log(`项目模糊匹配: "${project.name}" => `, matchedNames);
          matchedNames.forEach(name => {
            matchedProjects.push({
              name,
              status: project.status,
              required: project.required
            });
          });
        } else {
          // 如果项目没匹配到，检查是否可以在主题中找到
          const matchedTopics = fuzzyMatchEntityName(project.name, knownTopics);
          if (matchedTopics.length > 0) {
            console.log(`项目在主题中匹配: "${project.name}" => `, matchedTopics);
            // 将匹配到的主题添加到主题列表中
            if (!queryIntent.query.filters.entities.topics) {
              queryIntent.query.filters.entities.topics = [];
            }
            matchedTopics.forEach(name => {
              queryIntent.query.filters.entities.topics.push({
                name,
                category: '',
                required: project.required
              });
            });
          } else {
            matchedProjects.push(project);
          }
        }
      }

      // 更新查询意图中的项目
      queryIntent.query.filters.entities.projects = matchedProjects;
    }

    // 主题模糊匹配
    if (queryIntent?.query?.filters?.entities?.topics?.length > 0) {
      const matchedTopics = [];
      for (const topic of queryIntent.query.filters.entities.topics) {
        const matchedNames = fuzzyMatchEntityName(topic.name, knownTopics);
        if (matchedNames.length > 0) {
          console.log(`主题模糊匹配: "${topic.name}" => `, matchedNames);
          matchedNames.forEach(name => {
            matchedTopics.push({
              name,
              category: topic.category,
              required: topic.required
            });
          });
        } else {
          // 如果主题没匹配到，检查是否可以在项目中找到
          const matchedProjects = fuzzyMatchEntityName(topic.name, knownProjects);
          if (matchedProjects.length > 0) {
            console.log(`主题在项目中匹配: "${topic.name}" => `, matchedProjects);
            // 将匹配到的项目添加到项目列表中
            if (!queryIntent.query.filters.entities.projects) {
              queryIntent.query.filters.entities.projects = [];
            }
            matchedProjects.forEach(name => {
              queryIntent.query.filters.entities.projects.push({
                name,
                status: '',
                required: topic.required
              });
            });
          } else {
            matchedTopics.push(topic);
          }
        }
      }

      // 更新查询意图中的主题
      queryIntent.query.filters.entities.topics = matchedTopics;
    }

    // 1.5.3 特殊处理：如果用户查询既没有指定项目也没有指定主题，但问题中含有实体名称，尝试从两者中匹配
    if (!queryIntent?.query?.filters?.entities?.projects?.length && !queryIntent?.query?.filters?.entities?.topics?.length) {
      // 从问题中提取可能的实体名称（简单策略：提取所有名词短语）
      const words = question.split(/\s+/);
      for (let i = 0; i < words.length; i++) {
        // 尝试不同长度的词组
        for (let j = Math.min(i + 3, words.length); j > i; j--) {
          const phrase = words.slice(i, j).join(' ');

          // 在项目中查找
          const matchedProjects = fuzzyMatchEntityName(phrase, knownProjects);
          if (matchedProjects.length > 0) {
            console.log(`从问题中提取项目: "${phrase}" => `, matchedProjects);
            if (!queryIntent.query.filters.entities.projects) {
              queryIntent.query.filters.entities.projects = [];
            }
            matchedProjects.forEach(name => {
              queryIntent.query.filters.entities.projects.push({
                name,
                status: '',
                required: true
              });
            });
          }

          // 在主题中查找
          const matchedTopics = fuzzyMatchEntityName(phrase, knownTopics);
          if (matchedTopics.length > 0) {
            console.log(`从问题中提取主题: "${phrase}" => `, matchedTopics);
            if (!queryIntent.query.filters.entities.topics) {
              queryIntent.query.filters.entities.topics = [];
            }
            matchedTopics.forEach(name => {
              queryIntent.query.filters.entities.topics.push({
                name,
                category: '',
                required: true
              });
            });
          }
        }
      }
    }

    // 去重（基于name字段）
    if (queryIntent?.query?.filters?.entities?.projects) {
      queryIntent.query.filters.entities.projects = Array.from(new Map(queryIntent.query.filters.entities.projects.map(item => [item.name, item])).values());
    }
    if (queryIntent?.query?.filters?.entities?.topics) {
      queryIntent.query.filters.entities.topics = Array.from(new Map(queryIntent.query.filters.entities.topics.map(item => [item.name, item])).values());
    }
    console.log('最终查询意图:', queryIntent);

    // 2. 构建查询过滤条件
    const filters = {};

    // 添加安全检查，确保 queryIntent 结构完整
    if (queryIntent?.query?.filters) {
      // 复制实体过滤器
      if (queryIntent.query.filters.entities) {
        filters.entities = queryIntent.query.filters.entities;
      }

      // 复制时间范围
      if (queryIntent.query.filters.time_range) {
        filters.time_range = queryIntent.query.filters.time_range;
      }
    }

    // 设置输出选项
    const output = queryIntent?.query?.output || {
      format: "list",
      limit: 20,
      sort: {
        field: "timestamp",
        order: "desc"
      }
    };

    // 4. 查询向量数据库
    let queryResults;
    try {
      queryResults = await naturalLanguageQuery(question, filters, output);
      console.log('queryResults', queryResults, new Date().getTime());
    } catch (error) {
      console.error('向量数据库查询失败:', error);
      queryResults = {
        question: question,
        results: {
          ids: [],
          documents: [],
          metadatas: [],
          distances: []
        }
      };
    }

    // 添加空值检查
    if (!queryResults) {
      console.warn('向量数据库查询返回空结果');
      queryResults = {
        question: question,
        results: {
          ids: [],
          documents: [],
          metadatas: [],
          distances: []
        }
      };
    }
    const {
      question: formattedQuestion,
      results
    } = queryResults;
    if (!results || !results.documents || results.documents.length === 0) {
      return {
        success: false,
        message: `没有找到关于"${question}"的相关信息。`
      };
    }
    console.log('results', !results, !results.documents, results.documents.length === 0, new Date().getTime());
    // 5. 根据查询类型构建不同的提示模板
    let promptTemplate = "";
    switch (queryIntent?.query?.intent?.secondary) {
      case "project_status":
        promptTemplate = `
        以下是关于项目的一些信息:
        {{context}}
        
        基于以上信息,请分析并回答关于项目进展的问题:
        ${formattedQuestion}
        
        请包括:
        1. 项目当前进展
        2. 存在的风险和挑战
        3. 下一步计划
        `;
        break;
      case "person_info":
        promptTemplate = `
        以下是关于{{person}}的一些信息:
        {{context}}
        
        基于这些信息,请回答:
        ${formattedQuestion}
        
        请分析此人:
        1. 关注的重点话题/项目
        2. 交流和决策风格
        3. 可能的兴趣和关注点
        `;
        break;
      case "topic_discussion":
        promptTemplate = `
        以下是关于"{{topic}}"话题的相关信息:
        {{context}}
        
        基于这些信息,请回答:
        ${formattedQuestion}
        
        请分析:
        1. 这个话题的主要讨论点
        2. 不同观点和立场
        3. 最新的发展或决策
        `;
        break;
      case "action_items":
        promptTemplate = `
        以下是一些可能包含行动项的消息:
        {{context}}
        
        基于这些信息,请回答:
        ${formattedQuestion}
        
        请列出:
        1. 所有需要注意的行动项
        2. 各项的截止日期(如有提及)
        3. 负责人(如有提及)
        `;
        break;
      default:
        promptTemplate = `
        以下是与问题"${formattedQuestion}"相关的信息:
        {{context}}
        
        请基于以上信息提供详细回答。仅使用提供的信息,不要添加额外知识。
        如果信息不足,请明确指出。
        `;
    }

    // 6. 插入上下文
    const messagesContext = results.documents.map((doc, idx) => {
      const metadata = results.metadatas[idx];
      const source = metadata.source;
      const date = new Date(Number(metadata.timestamp)).toLocaleString();
      return `[${date} - ${source}] ${doc}`;
    }).join('\n\n');
    let prompt = promptTemplate.replace('{{context}}', messagesContext);

    // 替换实体
    if (queryIntent?.query?.intent?.secondary === "person_info" && queryIntent?.query?.filters?.entities?.people?.length > 0) {
      prompt = prompt.replace('{{person}}', queryIntent.query.filters.entities.people[0].name);
    }
    if (queryIntent?.query?.intent?.secondary === "topic_discussion" && queryIntent?.query?.filters?.entities?.topics?.length > 0) {
      prompt = prompt.replace('{{topic}}', queryIntent.query.filters.entities.topics[0].name);
    }

    // 7. 调用 LLM 生成回答
    const llmResponse = await handleLLMRequest({
      prompt
    });

    // 8. 构建符合 QueryResult 接口的结果
    const formattedResults = results.documents.map((doc, idx) => {
      const metadata = results.metadatas[idx];
      const id = String(results.ids[idx]);
      const relevance = 1 - results.distances[idx]; // 转换距离为相关性分数

      // 解析标签
      let tags = [];
      try {
        if (metadata.tags) {
          tags = JSON.parse(String(metadata.tags));
        } else if (metadata.category) {
          tags = JSON.parse(String(metadata.category));
        }
      } catch (e) {
        console.error('解析标签失败:', e);
        tags = [];
      }

      // 构建团队信息
      const teamInfo = metadata.teamName || metadata.teamId ? {
        name: String(metadata.teamName || '未知群组'),
        id: String(metadata.teamId || ''),
        url: metadata.teamId ? `https://app.ringcentral.com/messages/${metadata.teamId}` : ''
      } : undefined;

      // 构建 QueryResult 对象
      return {
        id: id,
        summary: String(metadata.summary) || doc.substring(0, 100) + '...',
        details: String(metadata.details || doc),
        timestamp: new Date(Number(metadata.timestamp)).toISOString(),
        source: String(metadata.source),
        relevance: relevance,
        tags: tags,
        team: teamInfo,
        reply_advice: metadata.reply_advice || ''
      };
    });
    return {
      success: true,
      analysis: llmResponse,
      relatedMessages: results.documents.length,
      queryIntent: queryIntent,
      results: formattedResults
    };
  } catch (error) {
    console.error('通用查询失败:', error);
    return {
      success: false,
      message: '查询时发生错误,请稍后再试。'
    };
  }
}

// 实现 callLLMJsonAPI 函数
async function callLLMJsonAPI(body) {
  // 复用现有的 LLM 请求代码
  const response = await handleLLMRequest(body);
  const jsonData = extractJsonFromResponse(response);
  return jsonData;
}

// 通用聊天消息接口

// OPENAI聊天实现
class OpenAIChat {
  // 存储不同会话的历史记录

  constructor(apiKey) {
    let baseUrl = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'https://api.openai.com/v1';
    // OpenAI实例
    this.conversationId = '';
    // 添加会话ID存储
    this.conversationHistory = new Map();
    this.apiKey = apiKey;
    this.baseUrl = baseUrl;

    // 初始化OpenAI客户端
    this.openai = new OpenAI({
      apiKey: this.apiKey,
      baseURL: this.baseUrl,
      dangerouslyAllowBrowser: true
    });
  }

  // 重置会话，开始新对话
  resetConversation() {
    this.conversationId = '';
    return this;
  }

  // 设置会话ID
  setConversationId(id) {
    this.conversationId = id;
    if (!this.conversationHistory.has(id)) {
      this.conversationHistory.set(id, []);
    }
    return this;
  }

  // 获取当前会话ID
  getConversationId() {
    return this.conversationId;
  }

  // 获取当前会话的历史记录
  getConversationHistory() {
    return this.conversationHistory.get(this.conversationId) || [];
  }
  async chat(options) {
    const {
      model,
      messages,
      temperature = 0.7,
      max_tokens,
      stream = false,
      onMessage,
      onComplete,
      onError
    } = options;
    try {
      // 如果没有会话ID，创建一个新的
      if (!this.conversationId) {
        this.conversationId = Date.now().toString();
        this.conversationHistory.set(this.conversationId, []);
      }

      // 获取当前会话的历史记录
      const history = this.conversationHistory.get(this.conversationId) || [];
      const tokenLimit = model.includes('gpt-4') ? 8000 : 4000; // 根据模型调整
      const optimizedHistory = this.optimizeHistory(history, tokenLimit);
      const allMessages = [...optimizedHistory, ...messages];

      // 使用OpenAI SDK
      if (stream) {
        const stream = await this.openai.chat.completions.create({
          model,
          messages: allMessages,
          temperature,
          max_tokens,
          stream: true
        });
        let fullResponse = '';
        for await (const part of stream) {
          const content = part.choices[0]?.delta?.content || '';
          if (content) {
            fullResponse += content;
            onMessage?.(content);
          }
        }

        // 更新会话历史
        if (fullResponse) {
          history.push(...messages); // 添加用户消息
          history.push({
            role: 'assistant',
            content: fullResponse
          }); // 添加助手回复
          this.conversationHistory.set(this.conversationId, history);
        }
        onComplete?.(fullResponse);
        return fullResponse;
      } else {
        const completion = await this.openai.chat.completions.create({
          model,
          messages: allMessages,
          temperature,
          max_tokens
        });
        const content = completion.choices[0].message.content || '';

        // 更新会话历史
        if (content) {
          history.push(...messages); // 添加用户消息
          history.push({
            role: 'assistant',
            content
          }); // 添加助手回复
          this.conversationHistory.set(this.conversationId, history);
        }
        onComplete?.(content);
        return content;
      }
    } catch (error) {
      onError?.(error);
      throw error;
    }
  }
  optimizeHistory(messages) {
    let maxTokens = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 4000;
    // 如果消息数量少，直接返回
    if (messages.length <= 3) return messages;

    // 保留系统消息
    const systemMessages = messages.filter(m => m.role === 'system');

    // 获取非系统消息
    let conversationMessages = messages.filter(m => m.role !== 'system');

    // 估算当前token数量（简单估算：每4个字符约1个token）
    const estimateTokens = msgs => {
      return msgs.reduce((sum, msg) => sum + Math.ceil(msg.content.length / 4), 0);
    };

    // 如果预估token数量超过限制，开始裁剪历史
    let estimatedTokens = estimateTokens(conversationMessages);

    // 保留最新的消息，逐步移除较早的消息对
    while (estimatedTokens > maxTokens && conversationMessages.length > 2) {
      // 移除最早的一对对话（用户+助手）
      conversationMessages = conversationMessages.slice(2);
      estimatedTokens = estimateTokens(conversationMessages);
    }

    // 合并系统消息和优化后的对话
    return [...systemMessages, ...conversationMessages];
  }
}

// DIFY聊天实现
class DifyChat {
  // 添加会话ID存储

  constructor(apiKey, baseUrl) {
    this.conversationId = '';
    this.apiKey = apiKey;
    this.baseUrl = baseUrl;
  }

  // 重置会话，开始新对话
  resetConversation() {
    this.conversationId = '';
    return this;
  }

  // 设置会话ID
  setConversationId(id) {
    this.conversationId = id;
    return this;
  }

  // 获取当前会话ID
  getConversationId() {
    return this.conversationId;
  }
  async chat(options) {
    const {
      messages,
      temperature = 0.7,
      stream = false,
      onMessage,
      onComplete,
      onError
    } = options;

    // 提取用户输入（最后一条用户消息）
    const userInput = messages.filter(m => m.role === 'user').pop()?.content || '';

    // 提取历史消息
    const history = messages.slice(0, -1).map(m => ({
      role: m.role,
      content: m.content
    }));
    try {
      const requestBody = {
        inputs: {},
        query: userInput,
        response_mode: stream ? 'streaming' : 'blocking',
        user: 'user-id',
        // 可自定义
        temperature
      };

      // 如果有会话ID，添加到请求中
      if (this.conversationId) {
        requestBody.conversation_id = this.conversationId;
      }

      // 只在没有会话ID时添加历史消息
      if (!this.conversationId && history.length > 0) {
        requestBody.history = history;
      }
      const response = await fetch(`${this.baseUrl}/chat-messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify(requestBody)
      });
      if (stream) {
        // 处理流式响应
        const reader = response.body?.getReader();
        let fullResponse = '';
        let metaDataProcessed = false;
        if (reader) {
          let isDone = false;
          while (!isDone) {
            const {
              done,
              value
            } = await reader.read();
            isDone = done;
            if (done) break;
            const chunk = new TextDecoder().decode(value);
            const lines = chunk.split('\n').filter(line => line.trim());
            for (const line of lines) {
              try {
                const json = JSON.parse(line);

                // 保存会话ID (只需处理一次)
                if (!metaDataProcessed && json.conversation_id) {
                  this.conversationId = json.conversation_id;
                  metaDataProcessed = true;
                }
                if (json.event === 'message' && json.data) {
                  fullResponse += json.data.answer || '';
                  onMessage?.(json.data.answer || '');
                }
              } catch (e) {
                // 忽略解析错误
              }
            }
          }
          onComplete?.(fullResponse);
        }
      } else {
        const json = await response.json();

        // 保存会话ID
        if (json.conversation_id) {
          this.conversationId = json.conversation_id;
        }
        const content = json.answer || '';
        onComplete?.(content);
        return content;
      }
    } catch (error) {
      onError?.(error);
      throw error;
    }
  }
}

// GROQ聊天实现
class GroqChat {
  // 存储不同会话的历史记录

  constructor(apiKey) {
    // Groq实例
    this.conversationId = '';
    // 添加会话ID存储
    this.conversationHistory = new Map();
    this.apiKey = apiKey;

    // 初始化Groq客户端
    this.groq = new Groq({
      apiKey: this.apiKey,
      dangerouslyAllowBrowser: true
    });
  }

  // 重置会话，开始新对话
  resetConversation() {
    this.conversationId = '';
    return this;
  }

  // 设置会话ID
  setConversationId(id) {
    this.conversationId = id;
    if (!this.conversationHistory.has(id)) {
      this.conversationHistory.set(id, []);
    }
    return this;
  }

  // 获取当前会话ID
  getConversationId() {
    return this.conversationId;
  }

  // 获取当前会话的历史记录
  getConversationHistory() {
    return this.conversationHistory.get(this.conversationId) || [];
  }
  async chat(options) {
    const {
      model,
      messages,
      temperature = 0.7,
      max_tokens,
      stream = false,
      onMessage,
      onComplete,
      onError
    } = options;
    try {
      // 如果没有会话ID，创建一个新的
      if (!this.conversationId) {
        this.conversationId = Date.now().toString();
        this.conversationHistory.set(this.conversationId, []);
      }

      // 获取当前会话的历史记录
      const history = this.conversationHistory.get(this.conversationId) || [];
      const tokenLimit = model.includes('gpt-4') ? 8000 : 4000; // 根据模型调整
      const optimizedHistory = this.optimizeHistory(history, tokenLimit);
      const allMessages = [...optimizedHistory, ...messages];

      // 使用Groq SDK
      if (stream) {
        const stream = await this.groq.chat.completions.create({
          model,
          messages: allMessages,
          temperature,
          max_tokens,
          stream: true
        });
        let fullResponse = '';
        for await (const part of stream) {
          const content = part.choices[0]?.delta?.content || '';
          if (content) {
            fullResponse += content;
            onMessage?.(content);
          }
        }

        // 更新会话历史
        if (fullResponse) {
          history.push(...messages); // 添加用户消息
          history.push({
            role: 'assistant',
            content: fullResponse
          }); // 添加助手回复
          this.conversationHistory.set(this.conversationId, history);
        }
        onComplete?.(fullResponse);
        return fullResponse;
      } else {
        const completion = await this.groq.chat.completions.create({
          model,
          messages: allMessages,
          temperature,
          max_tokens
        });
        const content = completion.choices[0].message.content || '';

        // 更新会话历史
        if (content) {
          history.push(...messages); // 添加用户消息
          history.push({
            role: 'assistant',
            content
          }); // 添加助手回复
          this.conversationHistory.set(this.conversationId, history);
        }
        onComplete?.(content);
        return content;
      }
    } catch (error) {
      onError?.(error);
      throw error;
    }
  }
  optimizeHistory(messages) {
    let maxTokens = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 4000;
    // 如果消息数量少，直接返回
    if (messages.length <= 3) return messages;

    // 保留系统消息
    const systemMessages = messages.filter(m => m.role === 'system');

    // 获取非系统消息
    let conversationMessages = messages.filter(m => m.role !== 'system');

    // 估算当前token数量（简单估算：每4个字符约1个token）
    const estimateTokens = msgs => {
      return msgs.reduce((sum, msg) => sum + Math.ceil(msg.content.length / 4), 0);
    };

    // 如果预估token数量超过限制，开始裁剪历史
    let estimatedTokens = estimateTokens(conversationMessages);

    // 保留最新的消息，逐步移除较早的消息对
    while (estimatedTokens > maxTokens && conversationMessages.length > 2) {
      // 移除最早的一对对话（用户+助手）
      conversationMessages = conversationMessages.slice(2);
      estimatedTokens = estimateTokens(conversationMessages);
    }

    // 合并系统消息和优化后的对话
    return [...systemMessages, ...conversationMessages];
  }
}

// Ollama聊天实现
class OllamaChat {
  // 存储不同会话的历史记录

  constructor() {
    let baseUrl = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'http://localhost:11434';
    this.conversationId = '';
    // 移除了`: string`类型注解
    this.conversationHistory = new Map();
    this.baseUrl = baseUrl;
  }

  // 重置会话，开始新对话
  resetConversation() {
    this.conversationId = '';
    return this;
  }

  // 设置会话ID
  setConversationId(id) {
    this.conversationId = id;
    if (!this.conversationHistory.has(id)) {
      this.conversationHistory.set(id, []);
    }
    return this;
  }

  // 获取当前会话ID
  getConversationId() {
    return this.conversationId;
  }

  // 获取当前会话的历史记录
  getConversationHistory() {
    return this.conversationHistory.get(this.conversationId) || [];
  }
  async chat(options) {
    const {
      model,
      messages,
      temperature = 0.7,
      stream = false,
      onMessage,
      onComplete,
      onError
    } = options;
    try {
      // 如果没有会话ID，创建一个新的
      if (!this.conversationId) {
        this.conversationId = Date.now().toString();
        this.conversationHistory.set(this.conversationId, []);
      }

      // 获取当前会话的历史记录
      const history = this.conversationHistory.get(this.conversationId) || [];

      // 合并历史记录和新消息，转换为Ollama的格式
      const allMessages = [...history, ...messages].map(m => ({
        role: m.role,
        content: m.content
      }));
      const response = await fetch(`${this.baseUrl}/api/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model,
          messages: allMessages,
          temperature,
          stream
        })
      });
      if (stream) {
        // 处理流式响应
        const reader = response.body?.getReader();
        let fullResponse = '';
        if (reader) {
          let isDone = false;
          while (!isDone) {
            const {
              done,
              value
            } = await reader.read();
            isDone = done;
            if (done) break;
            const chunk = new TextDecoder().decode(value);
            const lines = chunk.split('\n').filter(line => line.trim());
            for (const line of lines) {
              try {
                const json = JSON.parse(line);
                if (json.message && json.message.content) {
                  const content = json.message.content;
                  fullResponse += content;
                  onMessage?.(content);
                }
              } catch (e) {
                // 忽略解析错误
              }
            }
          }

          // 更新会话历史
          if (fullResponse) {
            history.push(...messages); // 添加用户消息
            history.push({
              role: 'assistant',
              content: fullResponse
            }); // 添加助手回复
            this.conversationHistory.set(this.conversationId, history);
          }
          onComplete?.(fullResponse);
        }
      } else {
        const json = await response.json();
        const content = json.message?.content || '';

        // 更新会话历史
        if (content) {
          history.push(...messages); // 添加用户消息
          history.push({
            role: 'assistant',
            content
          }); // 添加助手回复
          this.conversationHistory.set(this.conversationId, history);
        }
        onComplete?.(content);
        return content;
      }
    } catch (error) {
      onError?.(error);
      throw error;
    }
  }
}

// 导出所有实现


/***/ }),

/***/ 43922:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Un: () => (/* binding */ getEnvConfig)
/* harmony export */ });
/* unused harmony exports formatDate, uniqBy, showToast, transformGroupLinks, transformPostLinks, defaultEnvConfig, getDefaultEnvConfig, getUserInfo */


// 环境配置类型定义

function formatDate(dateString) {
  const date = new Date(dateString);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}
function uniqBy(array, key) {
  const seen = new Set();
  return array.filter(item => {
    const keyValue = item[key];
    if (seen.has(keyValue)) {
      return false;
    }
    seen.add(keyValue);
    return true;
  });
}
function showToast(message, type, onClose) {
  // 获取或创建容器元素
  const container = document.getElementById('radar-poc-result');
  if (!container) return;

  // 移除现有的 Toast 元素
  const existingToast = container.querySelector('.radar-poc-toast');
  if (existingToast) {
    container.removeChild(existingToast);
  }

  // 创建新的 Toast 元素
  const toast = document.createElement('div');
  toast.className = `radar-poc-toast radar-poc-toast-${type}`;
  const toastInner = document.createElement('div');
  toastInner.className = 'radar-poc-toast-inner';
  toastInner.textContent = message;
  toast.appendChild(toastInner);
  container.appendChild(toast);

  // 设置定时器在 3 秒后关闭 Toast
  const timer = setTimeout(() => {
    if (container.contains(toast)) {
      container.removeChild(toast);
    }
    if (onClose) {
      onClose();
    }
  }, 3000);

  // 返回一个函数以便手动关闭 Toast
  return () => {
    clearTimeout(timer);
    if (container.contains(toast)) {
      container.removeChild(toast);
    }
    if (onClose) {
      onClose();
    }
  };
}
function transformGroupLinks(inputString) {
  const groupLinkPattern = /\[group:(.+):(\d+)\]/g;
  const transformedString = inputString.replace(groupLinkPattern, (match, groupName, groupId) => {
    return `[${groupName}](/messages/${groupId})`;
  });
  return transformedString;
}
function transformPostLinks(inputString) {
  const postLinkPattern = /\[post:(\d+)\]/g;
  let index = 1;
  const transformedString = inputString.replace(postLinkPattern, (match, postId) => {
    return `[[${index++}]](/l${window.location.pathname}/${postId})`;
  });
  return transformedString;
}

// 默认环境配置
const defaultEnvConfig = {
  SCHEDULED_INTERVAL: Number({"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.SCHEDULED_INTERVAL) || 120,
  ANALYSIS_TYPE: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.ANALYSIS_TYPE || "filter",
  LLM_TYPE: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.LLM_TYPE || "dify",
  ANALYZE_BY_GROUP: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.ANALYZE_BY_GROUP === "true",
  OLLAMA_BASE_URL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OLLAMA_BASE_URL || "http://localhost:11434",
  OLLAMA_MODEL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OLLAMA_MODEL || "deepseek-r1",
  OLLAMA_REVIEW_MODEL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OLLAMA_REVIEW_MODEL || "llama3.1",
  OLLAMA_QUERY_MODEL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OLLAMA_QUERY_MODEL || "llama3.1",
  DIFY_API_KEY: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.DIFY_API_KEY || "",
  DIFY_REVIEW_API_KEY: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.DIFY_REVIEW_API_KEY || "",
  DIFY_API_BASE_URL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.DIFY_API_BASE_URL || "",
  OPENAI_API_KEY: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OPENAI_API_KEY || "",
  OPENAI_MODEL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OPENAI_MODEL || "",
  OPENAI_REVIEW_MODEL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OPENAI_REVIEW_MODEL || "",
  OPENAI_API_BASE_URL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.OPENAI_API_BASE_URL || "",
  GROQ_API_KEY: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.GROQ_API_KEY || "",
  GROQ_MODEL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.GROQ_MODEL || "",
  GROQ_REVIEW_MODEL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.GROQ_REVIEW_MODEL || "",
  BOT_API_BASE_URL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.BOT_API_BASE_URL || "https://botman.int.rclabenv.com/v2",
  BOT_TOKEN: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.BOT_TOKEN || "",
  BOT_ID: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.BOT_ID || "4700372020@37439510.bot.glip.net",
  BOT_TYPE: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.BOT_TYPE || "user",
  TEAM_ID: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.TEAM_ID || "",
  ENABLE_BOT: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.ENABLE_BOT === "true",
  LLM_REVIEW_BEFORE_SEND: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.LLM_REVIEW_BEFORE_SEND === "true",
  ENABLE_CHROMA: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.ENABLE_CHROMA === "true",
  CHROMA_API_URL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.CHROMA_API_URL || "http://localhost:8000",
  CHROMA_PORT: Number({"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.CHROMA_PORT) || 8000,
  CHROMA_COLLECTION_NAME: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.CHROMA_COLLECTION_NAME || "",
  JIRA_BASE_URL: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.JIRA_BASE_URL || "https://jira.ringcentral.com",
  JIRA_USERNAME: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.JIRA_USERNAME || "",
  JIRA_API_TOKEN: {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.JIRA_API_TOKEN || ""
};

// 获取环境配置，如果可能的话从 storage 获取，否则从 process.env 获取
async function getEnvConfig() {
  try {
    const {
      envConfig
    } = await chrome.storage.local.get(['envConfig']);
    if (envConfig) {
      // 将存储的配置与默认配置合并，确保新增的配置项也会被包含
      return {
        ...defaultEnvConfig,
        ...envConfig
      };
    }
  } catch (error) {
    console.error('获取配置失败:', error);
  }

  // 如果获取失败或没有保存的配置，返回默认值
  return defaultEnvConfig;
}
function getDefaultEnvConfig() {
  return defaultEnvConfig;
}
function getUserInfo() {
  const accountUD = getLocalStorageItem('global.account.UD', '');
  const accountInfoList = getLocalStorageItem('global.account.ACCOUNT_SESSION_DATA_LIST', {});
  const accountInfo = accountUD ? accountInfoList[accountUD] : accountInfoList.find(item => item.displayName != '');
  console.log('accountInfoList', accountInfoList, accountInfo);
  if (accountInfo) return {
    extensionId: accountInfo.extensionId,
    email: accountInfo.email,
    fullName: accountInfo.displayName,
    username: accountInfo.email ? accountInfo.email.trim().split('@')[0] : accountInfo.displayName.trim().split(' ').join('.').toLowerCase().replace(/[^a-z0-9_\-.]/g, '')
  };
  const userInfo = getCurrentUserInfo();
  return {
    extensionId: userInfo.extensionId,
    fullName: userInfo.username,
    username: userInfo.username.trim().split(' ').join('.').toLowerCase().replace(/[^a-z0-9_\-.]/g, ''),
    email: userInfo.username.trim().split(' ').join('.').toLowerCase().replace(/[^a-z0-9_\-.]/g, '') + '@ringcentral.com'
  };
}

/***/ }),

/***/ 9041:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Az: () => (/* binding */ naturalLanguageQuery)
});

// UNUSED EXPORTS: fuzzyMatchEntityName, fuzzyMatchPerson, getAllKnownPeople, getAllKnownProjects, getAllKnownTopics, getEmbedding, initChromaClient, storeMessage

// EXTERNAL MODULE: ./node_modules/isomorphic-fetch/fetch-npm-browserify.js
var fetch_npm_browserify = __webpack_require__(60328);
;// CONCATENATED MODULE: ./node_modules/chromadb/dist/chromadb.mjs
/* provided dependency */ var Buffer = __webpack_require__(48287)["Buffer"];
var __defProp = Object.defineProperty;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};

// src/generated/runtime.ts

var defaultFetch = fetch;
var BASE_PATH = "";
var BaseAPI = class {
  constructor(configuration, basePath = BASE_PATH, fetch2 = defaultFetch) {
    this.basePath = basePath;
    this.fetch = fetch2;
    if (configuration) {
      this.configuration = configuration;
      this.basePath = configuration.basePath || this.basePath;
    }
  }
};
var RequiredError = class _RequiredError extends Error {
  constructor(field, msg) {
    super(msg);
    this.field = field;
    Object.setPrototypeOf(this, _RequiredError.prototype);
    this.name = "RequiredError";
  }
};

// src/generated/api.ts
var ApiApiFetchParamCreator = function(configuration) {
  return {
    /**
     * @summary Add
     * @param {string} tenant
     * @param {string} databaseName
     * @param {string} collectionId
     * @param {Api.AddRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    add(tenant, databaseName, collectionId, request, options = {}) {
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling add.");
      }
      if (databaseName === null || databaseName === void 0) {
        throw new RequiredError("databaseName", "Required parameter databaseName was null or undefined when calling add.");
      }
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling add.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling add.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases/{database_name}/collections/{collection_id}/add`.replace("{tenant}", encodeURIComponent(String(tenant))).replace("{database_name}", encodeURIComponent(String(databaseName))).replace("{collection_id}", encodeURIComponent(String(collectionId)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Add V1
     * @param {string} collectionId
     * @param {Api.AddV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    addV1(collectionId, request, options = {}) {
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling addV1.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling addV1.");
      }
      let localVarPath = `/api/v1/collections/{collection_id}/add`.replace("{collection_id}", encodeURIComponent(String(collectionId)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Delete
     * @param {string} collectionId
     * @param {string} tenant
     * @param {string} databaseName
     * @param {Api.ADeleteRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    aDelete(collectionId, tenant, databaseName, request, options = {}) {
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling aDelete.");
      }
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling aDelete.");
      }
      if (databaseName === null || databaseName === void 0) {
        throw new RequiredError("databaseName", "Required parameter databaseName was null or undefined when calling aDelete.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling aDelete.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases/{database_name}/collections/{collection_id}/delete`.replace("{collection_id}", encodeURIComponent(String(collectionId))).replace("{tenant}", encodeURIComponent(String(tenant))).replace("{database_name}", encodeURIComponent(String(databaseName)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Get
     * @param {string} collectionId
     * @param {string} tenant
     * @param {string} databaseName
     * @param {Api.AGetRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    aGet(collectionId, tenant, databaseName, request, options = {}) {
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling aGet.");
      }
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling aGet.");
      }
      if (databaseName === null || databaseName === void 0) {
        throw new RequiredError("databaseName", "Required parameter databaseName was null or undefined when calling aGet.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling aGet.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases/{database_name}/collections/{collection_id}/get`.replace("{collection_id}", encodeURIComponent(String(collectionId))).replace("{tenant}", encodeURIComponent(String(tenant))).replace("{database_name}", encodeURIComponent(String(databaseName)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Count
     * @param {string} tenant
     * @param {string} databaseName
     * @param {string} collectionId
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    count(tenant, databaseName, collectionId, options = {}) {
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling count.");
      }
      if (databaseName === null || databaseName === void 0) {
        throw new RequiredError("databaseName", "Required parameter databaseName was null or undefined when calling count.");
      }
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling count.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases/{database_name}/collections/{collection_id}/count`.replace("{tenant}", encodeURIComponent(String(tenant))).replace("{database_name}", encodeURIComponent(String(databaseName))).replace("{collection_id}", encodeURIComponent(String(collectionId)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Count Collections
     * @param {string} tenant
     * @param {string} databaseName
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    countCollections(tenant, databaseName, options = {}) {
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling countCollections.");
      }
      if (databaseName === null || databaseName === void 0) {
        throw new RequiredError("databaseName", "Required parameter databaseName was null or undefined when calling countCollections.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases/{database_name}/collections_count`.replace("{tenant}", encodeURIComponent(String(tenant))).replace("{database_name}", encodeURIComponent(String(databaseName)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Count Collections V1
     * @param {string} [tenant]
     * @param {string} [database]
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    countCollectionsV1(tenant, database, options = {}) {
      let localVarPath = `/api/v1/count_collections`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      if (tenant !== void 0) {
        localVarQueryParameter.append("tenant", String(tenant));
      }
      if (database !== void 0) {
        localVarQueryParameter.append("database", String(database));
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Count V1
     * @param {string} collectionId
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    countV1(collectionId, options = {}) {
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling countV1.");
      }
      let localVarPath = `/api/v1/collections/{collection_id}/count`.replace("{collection_id}", encodeURIComponent(String(collectionId)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Create Collection
     * @param {string} tenant
     * @param {string} databaseName
     * @param {Api.CreateCollectionRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    createCollection(tenant, databaseName, request, options = {}) {
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling createCollection.");
      }
      if (databaseName === null || databaseName === void 0) {
        throw new RequiredError("databaseName", "Required parameter databaseName was null or undefined when calling createCollection.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling createCollection.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases/{database_name}/collections`.replace("{tenant}", encodeURIComponent(String(tenant))).replace("{database_name}", encodeURIComponent(String(databaseName)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Create Collection V1
     * @param {string} [tenant]
     * @param {string} [database]
     * @param {Api.CreateCollectionV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    createCollectionV1(tenant, database, request, options = {}) {
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling createCollectionV1.");
      }
      let localVarPath = `/api/v1/collections`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      if (tenant !== void 0) {
        localVarQueryParameter.append("tenant", String(tenant));
      }
      if (database !== void 0) {
        localVarQueryParameter.append("database", String(database));
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Create Database
     * @param {string} tenant
     * @param {Api.CreateDatabaseRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    createDatabase(tenant, request, options = {}) {
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling createDatabase.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling createDatabase.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases`.replace("{tenant}", encodeURIComponent(String(tenant)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Create Database V1
     * @param {string} [tenant]
     * @param {Api.CreateDatabaseV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    createDatabaseV1(tenant, request, options = {}) {
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling createDatabaseV1.");
      }
      let localVarPath = `/api/v1/databases`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      if (tenant !== void 0) {
        localVarQueryParameter.append("tenant", String(tenant));
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Create Tenant
     * @param {Api.CreateTenantRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    createTenant(request, options = {}) {
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling createTenant.");
      }
      let localVarPath = `/api/v2/tenants`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Create Tenant V1
     * @param {Api.CreateTenantV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    createTenantV1(request, options = {}) {
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling createTenantV1.");
      }
      let localVarPath = `/api/v1/tenants`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Delete Collection
     * @param {string} collectionName
     * @param {string} tenant
     * @param {string} databaseName
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    deleteCollection(collectionName, tenant, databaseName, options = {}) {
      if (collectionName === null || collectionName === void 0) {
        throw new RequiredError("collectionName", "Required parameter collectionName was null or undefined when calling deleteCollection.");
      }
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling deleteCollection.");
      }
      if (databaseName === null || databaseName === void 0) {
        throw new RequiredError("databaseName", "Required parameter databaseName was null or undefined when calling deleteCollection.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases/{database_name}/collections/{collection_name}`.replace("{collection_name}", encodeURIComponent(String(collectionName))).replace("{tenant}", encodeURIComponent(String(tenant))).replace("{database_name}", encodeURIComponent(String(databaseName)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "DELETE" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Delete Collection V1
     * @param {string} collectionName
     * @param {string} [tenant]
     * @param {string} [database]
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    deleteCollectionV1(collectionName, tenant, database, options = {}) {
      if (collectionName === null || collectionName === void 0) {
        throw new RequiredError("collectionName", "Required parameter collectionName was null or undefined when calling deleteCollectionV1.");
      }
      let localVarPath = `/api/v1/collections/{collection_name}`.replace("{collection_name}", encodeURIComponent(String(collectionName)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "DELETE" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      if (tenant !== void 0) {
        localVarQueryParameter.append("tenant", String(tenant));
      }
      if (database !== void 0) {
        localVarQueryParameter.append("database", String(database));
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Delete Database
     * @param {string} databaseName
     * @param {string} tenant
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    deleteDatabase(databaseName, tenant, options = {}) {
      if (databaseName === null || databaseName === void 0) {
        throw new RequiredError("databaseName", "Required parameter databaseName was null or undefined when calling deleteDatabase.");
      }
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling deleteDatabase.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases/{database_name}`.replace("{database_name}", encodeURIComponent(String(databaseName))).replace("{tenant}", encodeURIComponent(String(tenant)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "DELETE" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Delete V1
     * @param {string} collectionId
     * @param {Api.DeleteV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    deleteV1(collectionId, request, options = {}) {
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling deleteV1.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling deleteV1.");
      }
      let localVarPath = `/api/v1/collections/{collection_id}/delete`.replace("{collection_id}", encodeURIComponent(String(collectionId)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Get Collection
     * @param {string} tenant
     * @param {string} databaseName
     * @param {string} collectionName
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getCollection(tenant, databaseName, collectionName, options = {}) {
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling getCollection.");
      }
      if (databaseName === null || databaseName === void 0) {
        throw new RequiredError("databaseName", "Required parameter databaseName was null or undefined when calling getCollection.");
      }
      if (collectionName === null || collectionName === void 0) {
        throw new RequiredError("collectionName", "Required parameter collectionName was null or undefined when calling getCollection.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases/{database_name}/collections/{collection_name}`.replace("{tenant}", encodeURIComponent(String(tenant))).replace("{database_name}", encodeURIComponent(String(databaseName))).replace("{collection_name}", encodeURIComponent(String(collectionName)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Get Collection V1
     * @param {string} collectionName
     * @param {string} [tenant]
     * @param {string} [database]
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getCollectionV1(collectionName, tenant, database, options = {}) {
      if (collectionName === null || collectionName === void 0) {
        throw new RequiredError("collectionName", "Required parameter collectionName was null or undefined when calling getCollectionV1.");
      }
      let localVarPath = `/api/v1/collections/{collection_name}`.replace("{collection_name}", encodeURIComponent(String(collectionName)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      if (tenant !== void 0) {
        localVarQueryParameter.append("tenant", String(tenant));
      }
      if (database !== void 0) {
        localVarQueryParameter.append("database", String(database));
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Get Database
     * @param {string} databaseName
     * @param {string} tenant
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getDatabase(databaseName, tenant, options = {}) {
      if (databaseName === null || databaseName === void 0) {
        throw new RequiredError("databaseName", "Required parameter databaseName was null or undefined when calling getDatabase.");
      }
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling getDatabase.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases/{database_name}`.replace("{database_name}", encodeURIComponent(String(databaseName))).replace("{tenant}", encodeURIComponent(String(tenant)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Get Database V1
     * @param {string} database
     * @param {string} [tenant]
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getDatabaseV1(database, tenant, options = {}) {
      if (database === null || database === void 0) {
        throw new RequiredError("database", "Required parameter database was null or undefined when calling getDatabaseV1.");
      }
      let localVarPath = `/api/v1/databases/{database}`.replace("{database}", encodeURIComponent(String(database)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      if (tenant !== void 0) {
        localVarQueryParameter.append("tenant", String(tenant));
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Get Nearest Neighbors
     * @param {string} tenant
     * @param {string} databaseName
     * @param {string} collectionId
     * @param {Api.GetNearestNeighborsRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getNearestNeighbors(tenant, databaseName, collectionId, request, options = {}) {
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling getNearestNeighbors.");
      }
      if (databaseName === null || databaseName === void 0) {
        throw new RequiredError("databaseName", "Required parameter databaseName was null or undefined when calling getNearestNeighbors.");
      }
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling getNearestNeighbors.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling getNearestNeighbors.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases/{database_name}/collections/{collection_id}/query`.replace("{tenant}", encodeURIComponent(String(tenant))).replace("{database_name}", encodeURIComponent(String(databaseName))).replace("{collection_id}", encodeURIComponent(String(collectionId)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Get Nearest Neighbors V1
     * @param {string} collectionId
     * @param {Api.GetNearestNeighborsV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getNearestNeighborsV1(collectionId, request, options = {}) {
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling getNearestNeighborsV1.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling getNearestNeighborsV1.");
      }
      let localVarPath = `/api/v1/collections/{collection_id}/query`.replace("{collection_id}", encodeURIComponent(String(collectionId)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Get Tenant
     * @param {string} tenant
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getTenant(tenant, options = {}) {
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling getTenant.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}`.replace("{tenant}", encodeURIComponent(String(tenant)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Get Tenant V1
     * @param {string} tenant
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getTenantV1(tenant, options = {}) {
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling getTenantV1.");
      }
      let localVarPath = `/api/v1/tenants/{tenant}`.replace("{tenant}", encodeURIComponent(String(tenant)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Get User Identity
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getUserIdentity(options = {}) {
      let localVarPath = `/api/v2/auth/identity`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Root
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV11(options = {}) {
      let localVarPath = `/api/v1`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Get V1
     * @param {string} collectionId
     * @param {Api.GetV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV12(collectionId, request, options = {}) {
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling getV12.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling getV12.");
      }
      let localVarPath = `/api/v1/collections/{collection_id}/get`.replace("{collection_id}", encodeURIComponent(String(collectionId)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Heartbeat
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV1Heartbeat(options = {}) {
      let localVarPath = `/api/v1/heartbeat`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Pre Flight Checks
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV1PreFlightChecks(options = {}) {
      let localVarPath = `/api/v1/pre-flight-checks`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Version
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV1Version(options = {}) {
      let localVarPath = `/api/v1/version`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Root
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV2(options = {}) {
      let localVarPath = `/api/v2`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Heartbeat
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV2Heartbeat(options = {}) {
      let localVarPath = `/api/v2/heartbeat`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Pre Flight Checks
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV2PreFlightChecks(options = {}) {
      let localVarPath = `/api/v2/pre-flight-checks`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Version
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV2Version(options = {}) {
      let localVarPath = `/api/v2/version`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary List Collections
     * @param {string} tenant
     * @param {string} databaseName
     * @param {number | null} [limit]
     * @param {number | null} [offset]
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    listCollections(tenant, databaseName, limit, offset, options = {}) {
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling listCollections.");
      }
      if (databaseName === null || databaseName === void 0) {
        throw new RequiredError("databaseName", "Required parameter databaseName was null or undefined when calling listCollections.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases/{database_name}/collections`.replace("{tenant}", encodeURIComponent(String(tenant))).replace("{database_name}", encodeURIComponent(String(databaseName)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      if (limit !== void 0) {
        localVarQueryParameter.append("limit", String(limit));
      }
      if (offset !== void 0) {
        localVarQueryParameter.append("offset", String(offset));
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary List Collections V1
     * @param {number | null} [limit]
     * @param {number | null} [offset]
     * @param {string} [tenant]
     * @param {string} [database]
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    listCollectionsV1(limit, offset, tenant, database, options = {}) {
      let localVarPath = `/api/v1/collections`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      if (limit !== void 0) {
        localVarQueryParameter.append("limit", String(limit));
      }
      if (offset !== void 0) {
        localVarQueryParameter.append("offset", String(offset));
      }
      if (tenant !== void 0) {
        localVarQueryParameter.append("tenant", String(tenant));
      }
      if (database !== void 0) {
        localVarQueryParameter.append("database", String(database));
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary List Databases
     * @param {string} tenant
     * @param {number | null} [limit]
     * @param {number | null} [offset]
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    listDatabases(tenant, limit, offset, options = {}) {
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling listDatabases.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases`.replace("{tenant}", encodeURIComponent(String(tenant)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "GET" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      if (limit !== void 0) {
        localVarQueryParameter.append("limit", String(limit));
      }
      if (offset !== void 0) {
        localVarQueryParameter.append("offset", String(offset));
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Reset
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    postV1Reset(options = {}) {
      let localVarPath = `/api/v1/reset`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Reset
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    postV2Reset(options = {}) {
      let localVarPath = `/api/v2/reset`;
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarRequestOptions.headers = localVarHeaderParameter;
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Update
     * @param {string} tenant
     * @param {string} databaseName
     * @param {string} collectionId
     * @param {Api.UpdateRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    update(tenant, databaseName, collectionId, request, options = {}) {
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling update.");
      }
      if (databaseName === null || databaseName === void 0) {
        throw new RequiredError("databaseName", "Required parameter databaseName was null or undefined when calling update.");
      }
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling update.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling update.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases/{database_name}/collections/{collection_id}/update`.replace("{tenant}", encodeURIComponent(String(tenant))).replace("{database_name}", encodeURIComponent(String(databaseName))).replace("{collection_id}", encodeURIComponent(String(collectionId)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Update Collection
     * @param {string} tenant
     * @param {string} databaseName
     * @param {string} collectionId
     * @param {Api.UpdateCollectionRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    updateCollection(tenant, databaseName, collectionId, request, options = {}) {
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling updateCollection.");
      }
      if (databaseName === null || databaseName === void 0) {
        throw new RequiredError("databaseName", "Required parameter databaseName was null or undefined when calling updateCollection.");
      }
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling updateCollection.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling updateCollection.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases/{database_name}/collections/{collection_id}`.replace("{tenant}", encodeURIComponent(String(tenant))).replace("{database_name}", encodeURIComponent(String(databaseName))).replace("{collection_id}", encodeURIComponent(String(collectionId)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "PUT" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Update Collection V1
     * @param {string} collectionId
     * @param {Api.UpdateCollectionV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    updateCollectionV1(collectionId, request, options = {}) {
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling updateCollectionV1.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling updateCollectionV1.");
      }
      let localVarPath = `/api/v1/collections/{collection_id}`.replace("{collection_id}", encodeURIComponent(String(collectionId)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "PUT" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Update V1
     * @param {string} collectionId
     * @param {Api.UpdateV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    updateV1(collectionId, request, options = {}) {
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling updateV1.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling updateV1.");
      }
      let localVarPath = `/api/v1/collections/{collection_id}/update`.replace("{collection_id}", encodeURIComponent(String(collectionId)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Upsert
     * @param {string} tenant
     * @param {string} databaseName
     * @param {string} collectionId
     * @param {Api.UpsertRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    upsert(tenant, databaseName, collectionId, request, options = {}) {
      if (tenant === null || tenant === void 0) {
        throw new RequiredError("tenant", "Required parameter tenant was null or undefined when calling upsert.");
      }
      if (databaseName === null || databaseName === void 0) {
        throw new RequiredError("databaseName", "Required parameter databaseName was null or undefined when calling upsert.");
      }
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling upsert.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling upsert.");
      }
      let localVarPath = `/api/v2/tenants/{tenant}/databases/{database_name}/collections/{collection_id}/upsert`.replace("{tenant}", encodeURIComponent(String(tenant))).replace("{database_name}", encodeURIComponent(String(databaseName))).replace("{collection_id}", encodeURIComponent(String(collectionId)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    },
    /**
     * @summary Upsert V1
     * @param {string} collectionId
     * @param {Api.UpsertV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    upsertV1(collectionId, request, options = {}) {
      if (collectionId === null || collectionId === void 0) {
        throw new RequiredError("collectionId", "Required parameter collectionId was null or undefined when calling upsertV1.");
      }
      if (request === null || request === void 0) {
        throw new RequiredError("request", "Required parameter request was null or undefined when calling upsertV1.");
      }
      let localVarPath = `/api/v1/collections/{collection_id}/upsert`.replace("{collection_id}", encodeURIComponent(String(collectionId)));
      const localVarPathQueryStart = localVarPath.indexOf("?");
      const localVarRequestOptions = Object.assign({ method: "POST" }, options);
      const localVarHeaderParameter = options.headers ? new Headers(options.headers) : new Headers();
      const localVarQueryParameter = new URLSearchParams(localVarPathQueryStart !== -1 ? localVarPath.substring(localVarPathQueryStart + 1) : "");
      if (localVarPathQueryStart !== -1) {
        localVarPath = localVarPath.substring(0, localVarPathQueryStart);
      }
      localVarHeaderParameter.set("Content-Type", "application/json");
      localVarRequestOptions.headers = localVarHeaderParameter;
      if (request !== void 0) {
        localVarRequestOptions.body = JSON.stringify(request || {});
      }
      const localVarQueryParameterString = localVarQueryParameter.toString();
      if (localVarQueryParameterString) {
        localVarPath += "?" + localVarQueryParameterString;
      }
      return {
        url: localVarPath,
        options: localVarRequestOptions
      };
    }
  };
};
var ApiApiFp = function(configuration) {
  return {
    /**
     * @summary Add
     * @param {string} tenant
     * @param {string} databaseName
     * @param {string} collectionId
     * @param {Api.AddRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    add(tenant, databaseName, collectionId, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).add(tenant, databaseName, collectionId, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 201) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Add V1
     * @param {string} collectionId
     * @param {Api.AddV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    addV1(collectionId, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).addV1(collectionId, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 201) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Delete
     * @param {string} collectionId
     * @param {string} tenant
     * @param {string} databaseName
     * @param {Api.ADeleteRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    aDelete(collectionId, tenant, databaseName, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).aDelete(collectionId, tenant, databaseName, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Get
     * @param {string} collectionId
     * @param {string} tenant
     * @param {string} databaseName
     * @param {Api.AGetRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    aGet(collectionId, tenant, databaseName, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).aGet(collectionId, tenant, databaseName, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Count
     * @param {string} tenant
     * @param {string} databaseName
     * @param {string} collectionId
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    count(tenant, databaseName, collectionId, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).count(tenant, databaseName, collectionId, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Count Collections
     * @param {string} tenant
     * @param {string} databaseName
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    countCollections(tenant, databaseName, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).countCollections(tenant, databaseName, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Count Collections V1
     * @param {string} [tenant]
     * @param {string} [database]
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    countCollectionsV1(tenant, database, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).countCollectionsV1(tenant, database, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Count V1
     * @param {string} collectionId
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    countV1(collectionId, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).countV1(collectionId, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Create Collection
     * @param {string} tenant
     * @param {string} databaseName
     * @param {Api.CreateCollectionRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    createCollection(tenant, databaseName, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).createCollection(tenant, databaseName, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Create Collection V1
     * @param {string} [tenant]
     * @param {string} [database]
     * @param {Api.CreateCollectionV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    createCollectionV1(tenant, database, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).createCollectionV1(tenant, database, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Create Database
     * @param {string} tenant
     * @param {Api.CreateDatabaseRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    createDatabase(tenant, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).createDatabase(tenant, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Create Database V1
     * @param {string} [tenant]
     * @param {Api.CreateDatabaseV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    createDatabaseV1(tenant, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).createDatabaseV1(tenant, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Create Tenant
     * @param {Api.CreateTenantRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    createTenant(request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).createTenant(request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Create Tenant V1
     * @param {Api.CreateTenantV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    createTenantV1(request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).createTenantV1(request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Delete Collection
     * @param {string} collectionName
     * @param {string} tenant
     * @param {string} databaseName
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    deleteCollection(collectionName, tenant, databaseName, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).deleteCollection(collectionName, tenant, databaseName, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Delete Collection V1
     * @param {string} collectionName
     * @param {string} [tenant]
     * @param {string} [database]
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    deleteCollectionV1(collectionName, tenant, database, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).deleteCollectionV1(collectionName, tenant, database, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Delete Database
     * @param {string} databaseName
     * @param {string} tenant
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    deleteDatabase(databaseName, tenant, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).deleteDatabase(databaseName, tenant, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Delete V1
     * @param {string} collectionId
     * @param {Api.DeleteV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    deleteV1(collectionId, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).deleteV1(collectionId, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Get Collection
     * @param {string} tenant
     * @param {string} databaseName
     * @param {string} collectionName
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getCollection(tenant, databaseName, collectionName, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getCollection(tenant, databaseName, collectionName, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Get Collection V1
     * @param {string} collectionName
     * @param {string} [tenant]
     * @param {string} [database]
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getCollectionV1(collectionName, tenant, database, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getCollectionV1(collectionName, tenant, database, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Get Database
     * @param {string} databaseName
     * @param {string} tenant
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getDatabase(databaseName, tenant, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getDatabase(databaseName, tenant, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Get Database V1
     * @param {string} database
     * @param {string} [tenant]
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getDatabaseV1(database, tenant, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getDatabaseV1(database, tenant, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Get Nearest Neighbors
     * @param {string} tenant
     * @param {string} databaseName
     * @param {string} collectionId
     * @param {Api.GetNearestNeighborsRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getNearestNeighbors(tenant, databaseName, collectionId, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getNearestNeighbors(tenant, databaseName, collectionId, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Get Nearest Neighbors V1
     * @param {string} collectionId
     * @param {Api.GetNearestNeighborsV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getNearestNeighborsV1(collectionId, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getNearestNeighborsV1(collectionId, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Get Tenant
     * @param {string} tenant
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getTenant(tenant, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getTenant(tenant, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Get Tenant V1
     * @param {string} tenant
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getTenantV1(tenant, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getTenantV1(tenant, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Get User Identity
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getUserIdentity(options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getUserIdentity(options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Root
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV11(options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getV11(options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Get V1
     * @param {string} collectionId
     * @param {Api.GetV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV12(collectionId, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getV12(collectionId, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Heartbeat
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV1Heartbeat(options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getV1Heartbeat(options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Pre Flight Checks
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV1PreFlightChecks(options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getV1PreFlightChecks(options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Version
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV1Version(options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getV1Version(options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Root
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV2(options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getV2(options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Heartbeat
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV2Heartbeat(options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getV2Heartbeat(options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Pre Flight Checks
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV2PreFlightChecks(options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getV2PreFlightChecks(options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Version
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    getV2Version(options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).getV2Version(options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary List Collections
     * @param {string} tenant
     * @param {string} databaseName
     * @param {number | null} [limit]
     * @param {number | null} [offset]
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    listCollections(tenant, databaseName, limit, offset, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).listCollections(tenant, databaseName, limit, offset, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary List Collections V1
     * @param {number | null} [limit]
     * @param {number | null} [offset]
     * @param {string} [tenant]
     * @param {string} [database]
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    listCollectionsV1(limit, offset, tenant, database, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).listCollectionsV1(limit, offset, tenant, database, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary List Databases
     * @param {string} tenant
     * @param {number | null} [limit]
     * @param {number | null} [offset]
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    listDatabases(tenant, limit, offset, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).listDatabases(tenant, limit, offset, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Reset
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    postV1Reset(options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).postV1Reset(options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Reset
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    postV2Reset(options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).postV2Reset(options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Update
     * @param {string} tenant
     * @param {string} databaseName
     * @param {string} collectionId
     * @param {Api.UpdateRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    update(tenant, databaseName, collectionId, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).update(tenant, databaseName, collectionId, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Update Collection
     * @param {string} tenant
     * @param {string} databaseName
     * @param {string} collectionId
     * @param {Api.UpdateCollectionRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    updateCollection(tenant, databaseName, collectionId, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).updateCollection(tenant, databaseName, collectionId, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Update Collection V1
     * @param {string} collectionId
     * @param {Api.UpdateCollectionV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    updateCollectionV1(collectionId, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).updateCollectionV1(collectionId, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Update V1
     * @param {string} collectionId
     * @param {Api.UpdateV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    updateV1(collectionId, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).updateV1(collectionId, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Upsert
     * @param {string} tenant
     * @param {string} databaseName
     * @param {string} collectionId
     * @param {Api.UpsertRequest} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    upsert(tenant, databaseName, collectionId, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).upsert(tenant, databaseName, collectionId, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    },
    /**
     * @summary Upsert V1
     * @param {string} collectionId
     * @param {Api.UpsertV1Request} request
     * @param {RequestInit} [options] Override http request option.
     * @throws {RequiredError}
     */
    upsertV1(collectionId, request, options) {
      const localVarFetchArgs = ApiApiFetchParamCreator(configuration).upsertV1(collectionId, request, options);
      return (fetch2 = defaultFetch, basePath = BASE_PATH) => {
        return fetch2(basePath + localVarFetchArgs.url, localVarFetchArgs.options).then((response) => {
          const contentType = response.headers.get("Content-Type");
          const mimeType = contentType ? contentType.replace(/;.*/, "") : void 0;
          if (response.status === 200) {
            if (mimeType === "application/json") {
              return response.json();
            }
            throw response;
          }
          if (response.status === 422) {
            if (mimeType === "application/json") {
              throw response;
            }
            throw response;
          }
          throw response;
        });
      };
    }
  };
};
var ApiApi = class extends BaseAPI {
  /**
   * @summary Add
   * @param {string} tenant
   * @param {string} databaseName
   * @param {string} collectionId
   * @param {Api.AddRequest} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  add(tenant, databaseName, collectionId, request, options) {
    return ApiApiFp(this.configuration).add(tenant, databaseName, collectionId, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Add V1
   * @param {string} collectionId
   * @param {Api.AddV1Request} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  addV1(collectionId, request, options) {
    return ApiApiFp(this.configuration).addV1(collectionId, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Delete
   * @param {string} collectionId
   * @param {string} tenant
   * @param {string} databaseName
   * @param {Api.ADeleteRequest} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  aDelete(collectionId, tenant, databaseName, request, options) {
    return ApiApiFp(this.configuration).aDelete(collectionId, tenant, databaseName, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Get
   * @param {string} collectionId
   * @param {string} tenant
   * @param {string} databaseName
   * @param {Api.AGetRequest} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  aGet(collectionId, tenant, databaseName, request, options) {
    return ApiApiFp(this.configuration).aGet(collectionId, tenant, databaseName, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Count
   * @param {string} tenant
   * @param {string} databaseName
   * @param {string} collectionId
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  count(tenant, databaseName, collectionId, options) {
    return ApiApiFp(this.configuration).count(tenant, databaseName, collectionId, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Count Collections
   * @param {string} tenant
   * @param {string} databaseName
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  countCollections(tenant, databaseName, options) {
    return ApiApiFp(this.configuration).countCollections(tenant, databaseName, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Count Collections V1
   * @param {string} [tenant]
   * @param {string} [database]
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  countCollectionsV1(tenant, database, options) {
    return ApiApiFp(this.configuration).countCollectionsV1(tenant, database, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Count V1
   * @param {string} collectionId
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  countV1(collectionId, options) {
    return ApiApiFp(this.configuration).countV1(collectionId, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Create Collection
   * @param {string} tenant
   * @param {string} databaseName
   * @param {Api.CreateCollectionRequest} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  createCollection(tenant, databaseName, request, options) {
    return ApiApiFp(this.configuration).createCollection(tenant, databaseName, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Create Collection V1
   * @param {string} [tenant]
   * @param {string} [database]
   * @param {Api.CreateCollectionV1Request} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  createCollectionV1(tenant, database, request, options) {
    return ApiApiFp(this.configuration).createCollectionV1(tenant, database, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Create Database
   * @param {string} tenant
   * @param {Api.CreateDatabaseRequest} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  createDatabase(tenant, request, options) {
    return ApiApiFp(this.configuration).createDatabase(tenant, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Create Database V1
   * @param {string} [tenant]
   * @param {Api.CreateDatabaseV1Request} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  createDatabaseV1(tenant, request, options) {
    return ApiApiFp(this.configuration).createDatabaseV1(tenant, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Create Tenant
   * @param {Api.CreateTenantRequest} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  createTenant(request, options) {
    return ApiApiFp(this.configuration).createTenant(request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Create Tenant V1
   * @param {Api.CreateTenantV1Request} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  createTenantV1(request, options) {
    return ApiApiFp(this.configuration).createTenantV1(request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Delete Collection
   * @param {string} collectionName
   * @param {string} tenant
   * @param {string} databaseName
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  deleteCollection(collectionName, tenant, databaseName, options) {
    return ApiApiFp(this.configuration).deleteCollection(collectionName, tenant, databaseName, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Delete Collection V1
   * @param {string} collectionName
   * @param {string} [tenant]
   * @param {string} [database]
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  deleteCollectionV1(collectionName, tenant, database, options) {
    return ApiApiFp(this.configuration).deleteCollectionV1(collectionName, tenant, database, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Delete Database
   * @param {string} databaseName
   * @param {string} tenant
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  deleteDatabase(databaseName, tenant, options) {
    return ApiApiFp(this.configuration).deleteDatabase(databaseName, tenant, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Delete V1
   * @param {string} collectionId
   * @param {Api.DeleteV1Request} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  deleteV1(collectionId, request, options) {
    return ApiApiFp(this.configuration).deleteV1(collectionId, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Get Collection
   * @param {string} tenant
   * @param {string} databaseName
   * @param {string} collectionName
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getCollection(tenant, databaseName, collectionName, options) {
    return ApiApiFp(this.configuration).getCollection(tenant, databaseName, collectionName, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Get Collection V1
   * @param {string} collectionName
   * @param {string} [tenant]
   * @param {string} [database]
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getCollectionV1(collectionName, tenant, database, options) {
    return ApiApiFp(this.configuration).getCollectionV1(collectionName, tenant, database, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Get Database
   * @param {string} databaseName
   * @param {string} tenant
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getDatabase(databaseName, tenant, options) {
    return ApiApiFp(this.configuration).getDatabase(databaseName, tenant, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Get Database V1
   * @param {string} database
   * @param {string} [tenant]
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getDatabaseV1(database, tenant, options) {
    return ApiApiFp(this.configuration).getDatabaseV1(database, tenant, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Get Nearest Neighbors
   * @param {string} tenant
   * @param {string} databaseName
   * @param {string} collectionId
   * @param {Api.GetNearestNeighborsRequest} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getNearestNeighbors(tenant, databaseName, collectionId, request, options) {
    return ApiApiFp(this.configuration).getNearestNeighbors(tenant, databaseName, collectionId, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Get Nearest Neighbors V1
   * @param {string} collectionId
   * @param {Api.GetNearestNeighborsV1Request} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getNearestNeighborsV1(collectionId, request, options) {
    return ApiApiFp(this.configuration).getNearestNeighborsV1(collectionId, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Get Tenant
   * @param {string} tenant
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getTenant(tenant, options) {
    return ApiApiFp(this.configuration).getTenant(tenant, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Get Tenant V1
   * @param {string} tenant
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getTenantV1(tenant, options) {
    return ApiApiFp(this.configuration).getTenantV1(tenant, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Get User Identity
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getUserIdentity(options) {
    return ApiApiFp(this.configuration).getUserIdentity(options)(this.fetch, this.basePath);
  }
  /**
   * @summary Root
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getV11(options) {
    return ApiApiFp(this.configuration).getV11(options)(this.fetch, this.basePath);
  }
  /**
   * @summary Get V1
   * @param {string} collectionId
   * @param {Api.GetV1Request} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getV12(collectionId, request, options) {
    return ApiApiFp(this.configuration).getV12(collectionId, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Heartbeat
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getV1Heartbeat(options) {
    return ApiApiFp(this.configuration).getV1Heartbeat(options)(this.fetch, this.basePath);
  }
  /**
   * @summary Pre Flight Checks
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getV1PreFlightChecks(options) {
    return ApiApiFp(this.configuration).getV1PreFlightChecks(options)(this.fetch, this.basePath);
  }
  /**
   * @summary Version
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getV1Version(options) {
    return ApiApiFp(this.configuration).getV1Version(options)(this.fetch, this.basePath);
  }
  /**
   * @summary Root
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getV2(options) {
    return ApiApiFp(this.configuration).getV2(options)(this.fetch, this.basePath);
  }
  /**
   * @summary Heartbeat
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getV2Heartbeat(options) {
    return ApiApiFp(this.configuration).getV2Heartbeat(options)(this.fetch, this.basePath);
  }
  /**
   * @summary Pre Flight Checks
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getV2PreFlightChecks(options) {
    return ApiApiFp(this.configuration).getV2PreFlightChecks(options)(this.fetch, this.basePath);
  }
  /**
   * @summary Version
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  getV2Version(options) {
    return ApiApiFp(this.configuration).getV2Version(options)(this.fetch, this.basePath);
  }
  /**
   * @summary List Collections
   * @param {string} tenant
   * @param {string} databaseName
   * @param {number | null} [limit]
   * @param {number | null} [offset]
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  listCollections(tenant, databaseName, limit, offset, options) {
    return ApiApiFp(this.configuration).listCollections(tenant, databaseName, limit, offset, options)(this.fetch, this.basePath);
  }
  /**
   * @summary List Collections V1
   * @param {number | null} [limit]
   * @param {number | null} [offset]
   * @param {string} [tenant]
   * @param {string} [database]
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  listCollectionsV1(limit, offset, tenant, database, options) {
    return ApiApiFp(this.configuration).listCollectionsV1(limit, offset, tenant, database, options)(this.fetch, this.basePath);
  }
  /**
   * @summary List Databases
   * @param {string} tenant
   * @param {number | null} [limit]
   * @param {number | null} [offset]
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  listDatabases(tenant, limit, offset, options) {
    return ApiApiFp(this.configuration).listDatabases(tenant, limit, offset, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Reset
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  postV1Reset(options) {
    return ApiApiFp(this.configuration).postV1Reset(options)(this.fetch, this.basePath);
  }
  /**
   * @summary Reset
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  postV2Reset(options) {
    return ApiApiFp(this.configuration).postV2Reset(options)(this.fetch, this.basePath);
  }
  /**
   * @summary Update
   * @param {string} tenant
   * @param {string} databaseName
   * @param {string} collectionId
   * @param {Api.UpdateRequest} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  update(tenant, databaseName, collectionId, request, options) {
    return ApiApiFp(this.configuration).update(tenant, databaseName, collectionId, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Update Collection
   * @param {string} tenant
   * @param {string} databaseName
   * @param {string} collectionId
   * @param {Api.UpdateCollectionRequest} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  updateCollection(tenant, databaseName, collectionId, request, options) {
    return ApiApiFp(this.configuration).updateCollection(tenant, databaseName, collectionId, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Update Collection V1
   * @param {string} collectionId
   * @param {Api.UpdateCollectionV1Request} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  updateCollectionV1(collectionId, request, options) {
    return ApiApiFp(this.configuration).updateCollectionV1(collectionId, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Update V1
   * @param {string} collectionId
   * @param {Api.UpdateV1Request} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  updateV1(collectionId, request, options) {
    return ApiApiFp(this.configuration).updateV1(collectionId, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Upsert
   * @param {string} tenant
   * @param {string} databaseName
   * @param {string} collectionId
   * @param {Api.UpsertRequest} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  upsert(tenant, databaseName, collectionId, request, options) {
    return ApiApiFp(this.configuration).upsert(tenant, databaseName, collectionId, request, options)(this.fetch, this.basePath);
  }
  /**
   * @summary Upsert V1
   * @param {string} collectionId
   * @param {Api.UpsertV1Request} request
   * @param {RequestInit} [options] Override http request option.
   * @throws {RequiredError}
   */
  upsertV1(collectionId, request, options) {
    return ApiApiFp(this.configuration).upsertV1(collectionId, request, options)(this.fetch, this.basePath);
  }
};

// src/generated/models.ts
var Api;
((Api2) => {
  let IncludeEnum2;
  ((IncludeEnum3) => {
    IncludeEnum3["Documents"] = "documents";
    IncludeEnum3["Embeddings"] = "embeddings";
    IncludeEnum3["Metadatas"] = "metadatas";
    IncludeEnum3["Distances"] = "distances";
    IncludeEnum3["Uris"] = "uris";
    IncludeEnum3["Data"] = "data";
  })(IncludeEnum2 = Api2.IncludeEnum || (Api2.IncludeEnum = {}));
})(Api || (Api = {}));

// src/generated/configuration.ts
var Configuration = class {
  constructor(param = {}) {
    this.apiKey = param.apiKey;
    this.username = param.username;
    this.password = param.password;
    this.authorization = param.authorization;
    this.basePath = param.basePath;
  }
};

// src/Errors.ts
var ChromaError = class extends Error {
  constructor(name, message, cause) {
    super(message);
    this.cause = cause;
    this.name = name;
  }
};
var ChromaConnectionError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaConnectionError";
  }
};
var ChromaServerError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaServerError";
  }
};
var ChromaClientError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaClientError";
  }
};
var ChromaUnauthorizedError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaAuthError";
  }
};
var ChromaForbiddenError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaForbiddenError";
  }
};
var ChromaNotFoundError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaNotFoundError";
  }
};
var ChromaValueError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaValueError";
  }
};
var InvalidCollectionError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "InvalidCollectionError";
  }
};
var InvalidArgumentError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "InvalidArgumentError";
  }
};
var ChromaUniqueError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaUniqueError";
  }
};
function createErrorByType(type, message) {
  switch (type) {
    case "InvalidCollection":
      return new InvalidCollectionError(message);
    case "InvalidArgumentError":
      return new InvalidArgumentError(message);
    default:
      return void 0;
  }
}

// src/Collection.ts
var Collection = class {
  /**
   * @ignore
   */
  constructor(name, id, client, embeddingFunction, metadata) {
    this.name = name;
    this.id = id;
    this.metadata = metadata;
    this.client = client;
    this.embeddingFunction = embeddingFunction;
  }
  /**
   * Add items to the collection
   * @param {Object} params - The parameters for the query.
   * @param {ID | IDs} [params.ids] - IDs of the items to add.
   * @param {Embedding | Embeddings} [params.embeddings] - Optional embeddings of the items to add.
   * @param {Metadata | Metadatas} [params.metadatas] - Optional metadata of the items to add.
   * @param {Document | Documents} [params.documents] - Optional documents of the items to add.
   * @returns {Promise<AddResponse>} - The response from the API. True if successful.
   *
   * @example
   * ```typescript
   * const response = await collection.add({
   *   ids: ["id1", "id2"],
   *   embeddings: [[1, 2, 3], [4, 5, 6]],
   *   metadatas: [{ "key": "value" }, { "key": "value" }],
   *   documents: ["document1", "document2"]
   * });
   * ```
   */
  async add(params) {
    await this.client.init();
    await this.client.api.add(
      this.client.tenant,
      this.client.database,
      this.id,
      // TODO: For some reason the auto generated code requires metadata to be defined here.
      await prepareRecordRequest(
        params,
        this.embeddingFunction
      ),
      this.client.api.options
    );
  }
  /**
   * Upsert items to the collection
   * @param {Object} params - The parameters for the query.
   * @param {ID | IDs} [params.ids] - IDs of the items to add.
   * @param {Embedding | Embeddings} [params.embeddings] - Optional embeddings of the items to add.
   * @param {Metadata | Metadatas} [params.metadatas] - Optional metadata of the items to add.
   * @param {Document | Documents} [params.documents] - Optional documents of the items to add.
   * @returns {Promise<void>}
   *
   * @example
   * ```typescript
   * const response = await collection.upsert({
   *   ids: ["id1", "id2"],
   *   embeddings: [[1, 2, 3], [4, 5, 6]],
   *   metadatas: [{ "key": "value" }, { "key": "value" }],
   *   documents: ["document1", "document2"],
   * });
   * ```
   */
  async upsert(params) {
    await this.client.init();
    await this.client.api.upsert(
      this.client.tenant,
      this.client.database,
      this.id,
      // TODO: For some reason the auto generated code requires metadata to be defined here.
      await prepareRecordRequest(
        params,
        this.embeddingFunction
      ),
      this.client.api.options
    );
  }
  /**
   * Count the number of items in the collection
   * @returns {Promise<number>} - The number of items in the collection.
   *
   * @example
   * ```typescript
   * const count = await collection.count();
   * ```
   */
  async count() {
    await this.client.init();
    return await this.client.api.count(
      this.client.tenant,
      this.client.database,
      this.id,
      this.client.api.options
    );
  }
  /**
   * Get items from the collection
   * @param {Object} params - The parameters for the query.
   * @param {ID | IDs} [params.ids] - Optional IDs of the items to get.
   * @param {Where} [params.where] - Optional where clause to filter items by.
   * @param {PositiveInteger} [params.limit] - Optional limit on the number of items to get.
   * @param {PositiveInteger} [params.offset] - Optional offset on the items to get.
   * @param {IncludeEnum[]} [params.include] - Optional list of items to include in the response.
   * @param {WhereDocument} [params.whereDocument] - Optional where clause to filter items by.
   * @returns {Promise<GetResponse>} - The response from the server.
   *
   * @example
   * ```typescript
   * const response = await collection.get({
   *   ids: ["id1", "id2"],
   *   where: { "key": "value" },
   *   limit: 10,
   *   offset: 0,
   *   include: ["embeddings", "metadatas", "documents"],
   *   whereDocument: { $contains: "value" },
   * });
   * ```
   */
  async get({
    ids,
    where,
    limit,
    offset,
    include,
    whereDocument
  } = {}) {
    await this.client.init();
    const idsArray = ids ? toArray(ids) : void 0;
    const resp = await this.client.api.aGet(
      this.id,
      this.client.tenant,
      this.client.database,
      {
        ids: idsArray,
        where,
        limit,
        offset,
        include,
        where_document: whereDocument
      },
      this.client.api.options
    );
    return resp;
  }
  /**
   * Update items in the collection
   * @param {Object} params - The parameters for the query.
   * @param {ID | IDs} [params.ids] - IDs of the items to add.
   * @param {Embedding | Embeddings} [params.embeddings] - Optional embeddings of the items to add.
   * @param {Metadata | Metadatas} [params.metadatas] - Optional metadata of the items to add.
   * @param {Document | Documents} [params.documents] - Optional documents of the items to add.
   * @returns {Promise<void>}
   *
   * @example
   * ```typescript
   * const response = await collection.update({
   *   ids: ["id1", "id2"],
   *   embeddings: [[1, 2, 3], [4, 5, 6]],
   *   metadatas: [{ "key": "value" }, { "key": "value" }],
   *   documents: ["document1", "document2"],
   * });
   * ```
   */
  async update(params) {
    await this.client.init();
    await this.client.api.update(
      this.client.tenant,
      this.client.database,
      this.id,
      await prepareRecordRequest(params, this.embeddingFunction, true),
      this.client.api.options
    );
  }
  /**
   * Performs a query on the collection using the specified parameters.
   *
   * @param {Object} params - The parameters for the query.
   * @param {Embedding | Embeddings} [params.queryEmbeddings] - Optional query embeddings to use for the search.
   * @param {PositiveInteger} [params.nResults] - Optional number of results to return (default is 10).
   * @param {Where} [params.where] - Optional query condition to filter results based on metadata values.
   * @param {string | string[]} [params.queryTexts] - Optional query text(s) to search for in the collection.
   * @param {WhereDocument} [params.whereDocument] - Optional query condition to filter results based on document content.
   * @param {IncludeEnum[]} [params.include] - Optional array of fields to include in the result, such as "metadata" and "document".
   *
   * @returns {Promise<QueryResponse>} A promise that resolves to the query results.
   * @throws {Error} If there is an issue executing the query.
   * @example
   * // Query the collection using embeddings
   * const results = await collection.query({
   *   queryEmbeddings: [[0.1, 0.2, ...], ...],
   *   nResults: 10,
   *   where: {"name": {"$eq": "John Doe"}},
   *   include: ["metadata", "document"]
   * });
   * @example
   * ```js
   * // Query the collection using query text
   * const results = await collection.query({
   *   queryTexts: "some text",
   *   nResults: 10,
   *   where: {"name": {"$eq": "John Doe"}},
   *   include: ["metadata", "document"]
   * });
   * ```
   *
   */
  async query({
    nResults = 10,
    where,
    whereDocument,
    include,
    queryTexts,
    queryEmbeddings
  }) {
    if (queryTexts && queryEmbeddings || !queryTexts && !queryEmbeddings) {
      throw new Error(
        "You must supply exactly one of queryTexts or queryEmbeddings."
      );
    }
    await this.client.init();
    const arrayQueryEmbeddings = queryTexts !== void 0 ? await this.embeddingFunction.generate(toArray(queryTexts)) : toArrayOfArrays(queryEmbeddings);
    return await this.client.api.getNearestNeighbors(
      this.client.tenant,
      this.client.database,
      this.id,
      {
        query_embeddings: arrayQueryEmbeddings,
        where,
        n_results: nResults,
        where_document: whereDocument,
        include
      },
      this.client.api.options
    );
  }
  /**
   * Modify the collection name or metadata
   * @param {Object} params - The parameters for the query.
   * @param {string} [params.name] - Optional new name for the collection.
   * @param {CollectionMetadata} [params.metadata] - Optional new metadata for the collection.
   * @returns {Promise<void>} - The response from the API.
   *
   * @example
   * ```typescript
   * const response = await client.updateCollection({
   *   name: "new name",
   *   metadata: { "key": "value" },
   * });
   * ```
   */
  async modify({
    name,
    metadata
  }) {
    await this.client.init();
    return this.client.api.updateCollection(
      this.client.tenant,
      this.client.database,
      this.id,
      {
        new_name: name,
        new_metadata: metadata
      },
      this.client.api.options
    ).then(() => {
      if (name !== void 0) {
        this.name = name;
      }
      if (metadata !== void 0) {
        this.metadata = metadata;
      }
      return {
        name: this.name,
        metadata: this.metadata
      };
    });
  }
  /**
   * Peek inside the collection
   * @param {Object} params - The parameters for the query.
   * @param {PositiveInteger} [params.limit] - Optional number of results to return (default is 10).
   * @returns {Promise<GetResponse>} A promise that resolves to the query results.
   * @throws {Error} If there is an issue executing the query.
   *
   * @example
   * ```typescript
   * const results = await collection.peek({
   *   limit: 10
   * });
   * ```
   */
  async peek({ limit = 10 } = {}) {
    await this.client.init();
    return await this.client.api.aGet(
      this.id,
      this.client.tenant,
      this.client.database,
      {
        limit
      },
      this.client.api.options
    );
  }
  /**
   * Deletes items from the collection.
   * @param {Object} params - The parameters for deleting items from the collection.
   * @param {ID | IDs} [params.ids] - Optional ID or array of IDs of items to delete.
   * @param {Where} [params.where] - Optional query condition to filter items to delete based on metadata values.
   * @param {WhereDocument} [params.whereDocument] - Optional query condition to filter items to delete based on document content.
   * @returns {Promise<string[]>} A promise that resolves to the IDs of the deleted items.
   * @throws {Error} If there is an issue deleting items from the collection.
   *
   * @example
   * ```typescript
   * const results = await collection.delete({
   *   ids: "some_id",
   *   where: {"name": {"$eq": "John Doe"}},
   *   whereDocument: {"$contains":"search_string"}
   * });
   * ```
   */
  async delete({
    ids,
    where,
    whereDocument
  } = {}) {
    await this.client.init();
    let idsArray = void 0;
    if (ids !== void 0)
      idsArray = toArray(ids);
    await this.client.api.aDelete(
      this.id,
      this.client.tenant,
      this.client.database,
      { ids: idsArray, where, where_document: whereDocument },
      this.client.api.options
    );
  }
};

// src/utils.ts
function toArray(obj) {
  if (Array.isArray(obj)) {
    return obj;
  } else {
    return [obj];
  }
}
function toArrayOfArrays(obj) {
  if (obj.length === 0) {
    return [];
  }
  if (Array.isArray(obj[0])) {
    return obj;
  }
  if (obj[0] && typeof obj[0][Symbol.iterator] === "function") {
    return obj.map((el) => Array.from(el));
  }
  return [obj];
}
async function validateTenantDatabase(adminClient, tenant, database) {
  try {
    await adminClient.getTenant({ name: tenant });
  } catch (error) {
    if (error instanceof ChromaConnectionError) {
      throw error;
    }
    throw new Error(
      `Could not connect to tenant ${tenant}. Are you sure it exists? Underlying error:
${error}`
    );
  }
  try {
    await adminClient.getDatabase({ name: database, tenantName: tenant });
  } catch (error) {
    if (error instanceof ChromaConnectionError) {
      throw error;
    }
    throw new Error(
      `Could not connect to database ${database} for tenant ${tenant}. Are you sure it exists? Underlying error:
${error}`
    );
  }
}
function isBrowser() {
  return typeof window !== "undefined" && typeof window.document !== "undefined";
}
function arrayifyParams(params) {
  return {
    ids: toArray(params.ids),
    embeddings: params.embeddings ? toArrayOfArrays(params.embeddings) : void 0,
    metadatas: params.metadatas ? toArray(params.metadatas) : void 0,
    documents: params.documents ? toArray(params.documents) : void 0
  };
}
async function prepareRecordRequest(reqParams, embeddingFunction, update) {
  const { ids, embeddings, metadatas, documents } = arrayifyParams(reqParams);
  if (!embeddings && !documents && !update) {
    throw new Error("embeddings and documents cannot both be undefined");
  }
  const embeddingsArray = embeddings ? embeddings : documents ? await embeddingFunction.generate(documents) : void 0;
  if (!embeddingsArray && !update) {
    throw new Error("Failed to generate embeddings for your request.");
  }
  for (let i = 0; i < ids.length; i += 1) {
    if (typeof ids[i] !== "string") {
      throw new Error(
        `Expected ids to be strings, found ${typeof ids[i]} at index ${i}`
      );
    }
  }
  if (embeddingsArray !== void 0 && ids.length !== embeddingsArray.length || metadatas !== void 0 && ids.length !== metadatas.length || documents !== void 0 && ids.length !== documents.length) {
    throw new Error(
      "ids, embeddings, metadatas, and documents must all be the same length"
    );
  }
  const uniqueIds = new Set(ids);
  if (uniqueIds.size !== ids.length) {
    const duplicateIds = ids.filter(
      (item, index) => ids.indexOf(item) !== index
    );
    throw new Error(
      `ID's must be unique, found duplicates for: ${duplicateIds}`
    );
  }
  return {
    ids,
    metadatas,
    documents,
    embeddings: embeddingsArray
  };
}
function wrapCollection(api, collection) {
  return new Collection(
    collection.name,
    collection.id,
    api,
    collection.embeddingFunction,
    collection.metadata
  );
}

// src/auth.ts
var tokenHeaderTypeToHeaderKey = (headerType) => {
  if (headerType === "AUTHORIZATION") {
    return "Authorization";
  } else {
    return "X-Chroma-Token";
  }
};
var base64Encode = (str) => {
  return Buffer.from(str).toString("base64");
};
var BasicAuthClientProvider = class {
  /**
   * Creates a new BasicAuthClientProvider.
   * @param textCredentials - The credentials for the authentication provider. Must be of the form "username:password". If not supplied, the environment variable CHROMA_CLIENT_AUTH_CREDENTIALS will be used.
   * @throws {Error} If neither credentials provider or text credentials are supplied.
   */
  constructor(textCredentials) {
    const creds = textCredentials != null ? textCredentials : {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.CHROMA_CLIENT_AUTH_CREDENTIALS;
    if (creds === void 0) {
      throw new Error(
        "Credentials must be supplied via environment variable (CHROMA_CLIENT_AUTH_CREDENTIALS) or passed in as configuration."
      );
    }
    this.credentials = {
      Authorization: "Basic " + base64Encode(creds)
    };
  }
  authenticate() {
    return this.credentials;
  }
};
var TokenAuthClientProvider = class {
  constructor(textCredentials, headerType = "AUTHORIZATION") {
    const creds = textCredentials != null ? textCredentials : {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.CHROMA_CLIENT_AUTH_CREDENTIALS;
    if (creds === void 0) {
      throw new Error(
        "Credentials must be supplied via environment variable (CHROMA_CLIENT_AUTH_CREDENTIALS) or passed in as configuration."
      );
    }
    const headerKey = tokenHeaderTypeToHeaderKey(headerType);
    const headerVal = headerType === "AUTHORIZATION" ? `Bearer ${creds}` : creds;
    this.credentials = {};
    this.credentials[headerKey] = headerVal;
  }
  authenticate() {
    return this.credentials;
  }
};
var authOptionsToAuthProvider = (auth) => {
  if (auth.provider === void 0) {
    throw new Error("Auth provider not specified");
  }
  if (auth.credentials === void 0) {
    throw new Error("Auth credentials not specified");
  }
  switch (auth.provider) {
    case "basic":
      return new BasicAuthClientProvider(auth.credentials);
    case "token":
      return new TokenAuthClientProvider(
        auth.credentials,
        auth.tokenHeaderType
      );
      break;
    default:
      throw new Error("Invalid auth provider");
  }
};

// src/ChromaFetch.ts
function isOfflineError(error) {
  var _a, _b, _c;
  return Boolean(
    ((error == null ? void 0 : error.name) === "TypeError" || (error == null ? void 0 : error.name) === "FetchError") && (((_a = error.message) == null ? void 0 : _a.includes("fetch failed")) || ((_b = error.message) == null ? void 0 : _b.includes("Failed to fetch")) || ((_c = error.message) == null ? void 0 : _c.includes("ENOTFOUND")))
  );
}
function parseServerError(error) {
  const regex = /(\w+)\('(.+)'\)/;
  const match = error == null ? void 0 : error.match(regex);
  if (match) {
    const [, name, message] = match;
    switch (name) {
      case "ValueError":
        return new ChromaValueError(message);
      default:
        return new ChromaError(name, message);
    }
  }
  return new ChromaServerError(
    "The server encountered an error while handling the request."
  );
}
var chromaFetch = async (input, init) => {
  try {
    const resp = await fetch(input, init);
    const clonedResp = resp.clone();
    const respBody = await clonedResp.json();
    if (!clonedResp.ok) {
      const error = createErrorByType(respBody == null ? void 0 : respBody.error, respBody == null ? void 0 : respBody.message);
      if (error) {
        throw error;
      }
      switch (resp.status) {
        case 400:
          throw new ChromaClientError(
            `Bad request to ${input} with status: ${resp.statusText}`
          );
        case 401:
          throw new ChromaUnauthorizedError(`Unauthorized`);
        case 403:
          throw new ChromaForbiddenError(
            `You do not have permission to access the requested resource.`
          );
        case 404:
          throw new ChromaNotFoundError(
            `The requested resource could not be found: ${input}`
          );
        case 409:
          throw new ChromaUniqueError("The resource already exists");
        case 500:
          throw parseServerError(respBody == null ? void 0 : respBody.error);
        case 502:
        case 503:
        case 504:
          throw new ChromaConnectionError(
            `Unable to connect to the chromadb server. Please try again later.`
          );
      }
      throw new Error(
        `Failed to fetch ${input} with status ${resp.status}: ${resp.statusText}`
      );
    }
    if (respBody == null ? void 0 : respBody.error) {
      throw parseServerError(respBody.error);
    }
    return resp;
  } catch (error) {
    if (isOfflineError(error)) {
      throw new ChromaConnectionError(
        "Failed to connect to chromadb. Make sure your server is running and try again. If you are running from a browser, make sure that your chromadb instance is configured to allow requests from the current origin using the CHROMA_SERVER_CORS_ALLOW_ORIGINS environment variable.",
        error
      );
    }
    throw error;
  }
};

// src/AdminClient.ts
var DEFAULT_TENANT = "default_tenant";
var DEFAULT_DATABASE = "default_database";
var AdminClient = class {
  /**
   * Creates a new AdminClient instance.
   * @param {Object} params - The parameters for creating a new client
   * @param {string} [params.path] - The base path for the Chroma API.
   * @returns {AdminClient} A new AdminClient instance.
   *
   * @example
   * ```typescript
   * const client = new AdminClient({
   *   path: "http://localhost:8000"
   * });
   * ```
   */
  constructor({
    path,
    fetchOptions,
    auth,
    tenant = DEFAULT_TENANT,
    database = DEFAULT_DATABASE
  } = {}) {
    this.tenant = DEFAULT_TENANT;
    this.database = DEFAULT_DATABASE;
    if (path === void 0)
      path = "http://localhost:8000";
    this.tenant = tenant;
    this.database = database;
    this.authProvider = void 0;
    const apiConfig = new Configuration({
      basePath: path
    });
    this.api = new ApiApi(apiConfig, void 0, chromaFetch);
    this.api.options = fetchOptions != null ? fetchOptions : {};
    if (auth !== void 0) {
      this.authProvider = authOptionsToAuthProvider(auth);
      this.api.options.headers = __spreadValues(__spreadValues({}, this.api.options.headers), this.authProvider.authenticate());
    }
  }
  /**
   * Sets the tenant and database for the client.
   *
   * @param {Object} params - The parameters for setting tenant and database.
   * @param {string} params.tenant - The name of the tenant.
   * @param {string} params.database - The name of the database.
   *
   * @returns {Promise<void>} A promise that returns nothing
   * @throws {Error} Any issues
   *
   * @example
   * ```typescript
   * await adminClient.setTenant({
   *   tenant: "my_tenant",
   *   database: "my_database",
   * });
   * ```
   */
  async setTenant({
    tenant = DEFAULT_TENANT,
    database = DEFAULT_DATABASE
  }) {
    await validateTenantDatabase(this, tenant, database);
    this.tenant = tenant;
    this.database = database;
  }
  /**
   * Sets the database for the client.
   *
   * @param {Object} params - The parameters for setting the database.
   * @param {string} params.database - The name of the database.
   *
   * @returns {Promise<void>} A promise that returns nothing
   * @throws {Error} Any issues
   *
   * @example
   * ```typescript
   * await adminClient.setDatabase({
   *   database: "my_database",
   * });
   * ```
   */
  async setDatabase({
    database = DEFAULT_DATABASE
  }) {
    await validateTenantDatabase(this, this.tenant, database);
    this.database = database;
  }
  /**
   * Creates a new tenant with the specified properties.
   *
   * @param {Object} params - The parameters for creating a new tenant.
   * @param {string} params.name - The name of the tenant.
   *
   * @returns {Promise<Tenant>} A promise that resolves to the created tenant.
   * @throws {Error} If there is an issue creating the tenant.
   *
   * @example
   * ```typescript
   * await adminClient.createTenant({
   *   name: "my_tenant",
   * });
   * ```
   */
  async createTenant({ name }) {
    await this.api.createTenant({ name }, this.api.options);
    return { name };
  }
  /**
   * Gets a tenant with the specified properties.
   *
   * @param {Object} params - The parameters for getting a tenant.
   * @param {string} params.name - The name of the tenant.
   *
   * @returns {Promise<Tenant>} A promise that resolves to the tenant.
   * @throws {Error} If there is an issue getting the tenant.
   *
   * @example
   * ```typescript
   * await adminClient.getTenant({
   *   name: "my_tenant",
   * });
   * ```
   */
  async getTenant({ name }) {
    const getTenant = await this.api.getTenant(
      name,
      this.api.options
    );
    return { name: getTenant.name };
  }
  /**
   * Creates a new database with the specified properties.
   *
   * @param {Object} params - The parameters for creating a new database.
   * @param {string} params.name - The name of the database.
   * @param {string} params.tenantName - The name of the tenant.
   *
   * @returns {Promise<Database>} A promise that resolves to the created database.
   * @throws {Error} If there is an issue creating the database.
   *
   * @example
   * ```typescript
   * await adminClient.createDatabase({
   *   name: "my_database",
   *   tenantName: "my_tenant",
   * });
   * ```
   */
  async createDatabase({
    name,
    tenantName
  }) {
    await this.api.createDatabase(tenantName, { name }, this.api.options);
    return { name };
  }
  /**
   * Gets a database with the specified properties.
   *
   * @param {Object} params - The parameters for getting a database.
   * @param {string} params.name - The name of the database.
   * @param {string} params.tenantName - The name of the tenant.
   *
   * @returns {Promise<Database>} A promise that resolves to the database.
   * @throws {Error} If there is an issue getting the database.
   *
   * @example
   * ```typescript
   * await adminClient.getDatabase({
   *   name: "my_database",
   *   tenantName: "my_tenant",
   * });
   * ```
   */
  async getDatabase({
    name,
    tenantName
  }) {
    const result = await this.api.getDatabase(
      name,
      tenantName,
      this.api.options
    );
    return result;
  }
  /**
   * Deletes a database.
   *
   * @param {Object} params - The parameters for deleting a database.
   * @param {string} params.name - The name of the database.
   * @param {string} params.tenantName - The name of the tenant.
   *
   * @returns {Promise<void>} A promise that returns nothing.
   * @throws {Error} If there is an issue deleting the database.
   */
  async deleteDatabase({
    name,
    tenantName
  }) {
    await this.api.deleteDatabase(name, tenantName, this.api.options);
  }
  /**
   * Lists database for a specific tenant.
   *
   * @param {Object} params - The parameters for listing databases.
   * @param {number} [params.limit] - The maximum number of databases to return.
   * @param {number} [params.offset] - The number of databases to skip.
   *
   * @returns {Promise<Database[]>} A promise that resolves to a list of databases.
   * @throws {Error} If there is an issue listing the databases.
   */
  async listDatabases({
    limit,
    offset,
    tenantName
  }) {
    return await this.api.listDatabases(
      tenantName,
      limit,
      offset,
      this.api.options
    );
  }
};

// src/embeddings/DefaultEmbeddingFunction.ts
var TransformersApi;
var DefaultEmbeddingFunction = class _DefaultEmbeddingFunction {
  /**
   * DefaultEmbeddingFunction constructor.
   * @param options The configuration options.
   * @param options.model The model to use to calculate embeddings. Defaults to 'Xenova/all-MiniLM-L6-v2', which is an ONNX port of `sentence-transformers/all-MiniLM-L6-v2`.
   * @param options.revision The specific model version to use (can be a branch, tag name, or commit id). Defaults to 'main'.
   * @param options.quantized Whether to load the 8-bit quantized version of the model. Defaults to `false`.
   * @param options.progress_callback If specified, this function will be called during model construction, to provide the user with progress updates.
   */
  constructor({
    model = "Xenova/all-MiniLM-L6-v2",
    revision = "main",
    quantized = false,
    progress_callback = null
  } = {}) {
    this.model = model;
    this.revision = revision;
    this.quantized = quantized;
    this.progress_callback = progress_callback;
  }
  async generate(texts) {
    await this.loadClient();
    this.pipelinePromise = new Promise(async (resolve, reject) => {
      try {
        const pipeline = this.transformersApi;
        const quantized = this.quantized;
        const revision = this.revision;
        const progress_callback = this.progress_callback;
        resolve(
          await pipeline("feature-extraction", this.model, {
            quantized,
            revision,
            progress_callback
          })
        );
      } catch (e) {
        reject(e);
      }
    });
    let pipe = await this.pipelinePromise;
    let output = await pipe(texts, { pooling: "mean", normalize: true });
    return output.tolist();
  }
  async loadClient() {
    if (this.transformersApi)
      return;
    try {
      let { pipeline } = await _DefaultEmbeddingFunction.import();
      TransformersApi = pipeline;
    } catch (_a) {
      if (_a.code === "MODULE_NOT_FOUND") {
        throw new Error(
          "Please install the chromadb-default-embed package to use the DefaultEmbeddingFunction, `npm install chromadb-default-embed`"
        );
      }
      throw _a;
    }
    this.transformersApi = TransformersApi;
  }
  /** @ignore */
  static async import() {
    try {
      let importResult;
      if (isBrowser()) {
        importResult = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 66399));
      } else {
        importResult = await __webpack_require__.e(/* import() */ 871).then(__webpack_require__.bind(__webpack_require__, 38871));
      }
      const { pipeline, env } = importResult;
      env.allowLocalModels = false;
      return { pipeline };
    } catch (e) {
      throw new Error(
        "Please install chromadb-default-embed as a dependency with, e.g. `npm install chromadb-default-embed`"
      );
    }
  }
};

// src/ChromaClient.ts
var DEFAULT_TENANT2 = "default_tenant";
var DEFAULT_DATABASE2 = "default_database";
var ChromaClient = class {
  /**
   * Creates a new ChromaClient instance.
   * @param {Object} params - The parameters for creating a new client
   * @param {string} [params.path] - The base path for the Chroma API.
   * @returns {ChromaClient} A new ChromaClient instance.
   *
   * @example
   * ```typescript
   * const client = new ChromaClient({
   *   path: "http://localhost:8000"
   * });
   * ```
   */
  constructor({
    path = "http://localhost:8000",
    fetchOptions,
    auth,
    tenant = DEFAULT_TENANT2,
    database = DEFAULT_DATABASE2
  } = {}) {
    this.tenant = tenant;
    this.database = database;
    this.authProvider = void 0;
    const apiConfig = new Configuration({
      basePath: path
    });
    this.api = new ApiApi(apiConfig, void 0, chromaFetch);
    this.api.options = fetchOptions != null ? fetchOptions : {};
    if (auth !== void 0) {
      this.authProvider = authOptionsToAuthProvider(auth);
      this.api.options.headers = __spreadValues(__spreadValues({}, this.api.options.headers), this.authProvider.authenticate());
    }
    this._adminClient = new AdminClient({
      path,
      fetchOptions,
      auth,
      tenant,
      database
    });
  }
  /** @ignore */
  async init() {
    if (!this._initPromise) {
      if (this.authProvider !== void 0) {
        await this.getUserIdentity();
      }
      this._initPromise = validateTenantDatabase(
        this._adminClient,
        this.tenant,
        this.database
      );
    }
    return this._initPromise;
  }
  /**
   * Tries to set the tenant and database for the client.
   *
   * @returns {Promise<void>} A promise that resolves when the tenant/database is resolved.
   * @throws {Error} If there is an issue resolving the tenant and database.
   *
   */
  async getUserIdentity() {
    const user_identity = await this.api.getUserIdentity(
      this.api.options
    );
    const user_tenant = user_identity.tenant;
    const user_databases = user_identity.databases;
    if (user_tenant !== null && user_tenant !== void 0 && user_tenant !== "*" && this.tenant == DEFAULT_TENANT2) {
      this.tenant = user_tenant;
    }
    if (user_databases !== null && user_databases !== void 0 && user_databases.length == 1 && user_databases[0] !== "*" && this.database == DEFAULT_DATABASE2) {
      this.database = user_databases[0];
    }
  }
  /**
   * Resets the state of the object by making an API call to the reset endpoint.
   *
   * @returns {Promise<boolean>} A promise that resolves when the reset operation is complete.
   * @throws {ChromaConnectionError} If the client is unable to connect to the server.
   * @throws {ChromaServerError} If the server experienced an error while the state.
   *
   * @example
   * ```typescript
   * await client.reset();
   * ```
   */
  async reset() {
    await this.init();
    return await this.api.postV2Reset(this.api.options);
  }
  /**
   * Returns the version of the Chroma API.
   * @returns {Promise<string>} A promise that resolves to the version of the Chroma API.
   * @throws {ChromaConnectionError} If the client is unable to connect to the server.
   *
   * @example
   * ```typescript
   * const version = await client.version();
   * ```
   */
  async version() {
    return await this.api.getV2Version(this.api.options);
  }
  /**
   * Returns a heartbeat from the Chroma API.
   * @returns {Promise<number>} A promise that resolves to the heartbeat from the Chroma API.
   * @throws {ChromaConnectionError} If the client is unable to connect to the server.
   *
   * @example
   * ```typescript
   * const heartbeat = await client.heartbeat();
   * ```
   */
  async heartbeat() {
    const response = await this.api.getV2Heartbeat(this.api.options);
    return response["nanosecond heartbeat"];
  }
  /**
   * Creates a new collection with the specified properties.
   *
   * @param {Object} params - The parameters for creating a new collection.
   * @param {string} params.name - The name of the collection.
   * @param {CollectionMetadata} [params.metadata] - Optional metadata associated with the collection.
   * @param {IEmbeddingFunction} [params.embeddingFunction] - Optional custom embedding function for the collection.
   *
   * @returns {Promise<Collection>} A promise that resolves to the created collection.
   * @throws {ChromaConnectionError} If the client is unable to connect to the server.
   * @throws {ChromaServerError} If there is an issue creating the collection.
   *
   * @example
   * ```typescript
   * const collection = await client.createCollection({
   *   name: "my_collection",
   *   metadata: {
   *     "description": "My first collection"
   *   }
   * });
   * ```
   */
  async createCollection({
    name,
    metadata,
    embeddingFunction = new DefaultEmbeddingFunction()
  }) {
    await this.init();
    const newCollection = await this.api.createCollection(
      this.tenant,
      this.database,
      {
        name,
        // @ts-ignore: we need to generate the client libraries again
        configuration: null,
        //TODO: Configuration type in JavaScript
        metadata
      },
      this.api.options
    );
    return wrapCollection(this, {
      name: newCollection.name,
      id: newCollection.id,
      metadata: newCollection.metadata,
      embeddingFunction
    });
  }
  /**
   * Gets or creates a collection with the specified properties.
   *
   * @param {Object} params - The parameters for creating a new collection.
   * @param {string} params.name - The name of the collection.
   * @param {CollectionMetadata} [params.metadata] - Optional metadata associated with the collection.
   * @param {IEmbeddingFunction} [params.embeddingFunction] - Optional custom embedding function for the collection.
   *
   * @returns {Promise<Collection>} A promise that resolves to the got or created collection.
   * @throws {Error} If there is an issue getting or creating the collection.
   *
   * @example
   * ```typescript
   * const collection = await client.getOrCreateCollection({
   *   name: "my_collection",
   *   metadata: {
   *     "description": "My first collection"
   *   }
   * });
   * ```
   */
  async getOrCreateCollection({
    name,
    metadata,
    embeddingFunction = new DefaultEmbeddingFunction()
  }) {
    await this.init();
    const newCollection = await this.api.createCollection(
      this.tenant,
      this.database,
      {
        name,
        // @ts-ignore: we need to generate the client libraries again
        configuration: null,
        //TODO: Configuration type in JavaScript
        metadata,
        get_or_create: true
      },
      this.api.options
    );
    return wrapCollection(this, {
      name: newCollection.name,
      id: newCollection.id,
      metadata: newCollection.metadata,
      embeddingFunction
    });
  }
  /**
   * Get all collection names.
   *
   * @returns {Promise<string[]>} A promise that resolves to a list of collection names.
   * @param {PositiveInteger} [params.limit] - Optional limit on the number of items to get.
   * @param {PositiveInteger} [params.offset] - Optional offset on the items to get.
   * @throws {Error} If there is an issue listing the collections.
   *
   * @example
   * ```typescript
   * const collections = await client.listCollections({
   *     limit: 10,
   *     offset: 0,
   * });
   * ```
   */
  async listCollections({ limit, offset } = {}) {
    await this.init();
    const collections = await this.api.listCollections(
      this.tenant,
      this.database,
      limit,
      offset,
      this.api.options
    );
    return collections.map((collection) => collection.name);
  }
  /**
   * List collection names, IDs, and metadata.
   *
   * @param {PositiveInteger} [params.limit] - Optional limit on the number of items to get.
   * @param {PositiveInteger} [params.offset] - Optional offset on the items to get.
   * @throws {Error} If there is an issue listing the collections.
   * @returns {Promise<{ name: string, id: string, metadata?: CollectionMetadata }[]>} A promise that resolves to a list of collection names, IDs, and metadata.
   *
   * @example
   * ```typescript
   * const collections = await client.listCollectionsAndMetadata({
   *    limit: 10,
   *    offset: 0,
   * });
   */
  async listCollectionsAndMetadata({
    limit,
    offset
  } = {}) {
    await this.init();
    return await this.api.listCollections(
      this.tenant,
      this.database,
      limit,
      offset,
      this.api.options
    );
  }
  /**
   * Counts all collections.
   *
   * @returns {Promise<number>} A promise that resolves to the number of collections.
   * @throws {Error} If there is an issue counting the collections.
   *
   * @example
   * ```typescript
   * const collections = await client.countCollections();
   * ```
   */
  async countCollections() {
    await this.init();
    return await this.api.countCollections(
      this.tenant,
      this.database,
      this.api.options
    );
  }
  /**
   * Gets a collection with the specified name.
   * @param {Object} params - The parameters for getting a collection.
   * @param {string} params.name - The name of the collection.
   * @param {IEmbeddingFunction} [params.embeddingFunction] - Optional custom embedding function for the collection.
   * @returns {Promise<Collection>} A promise that resolves to the collection.
   * @throws {Error} If there is an issue getting the collection.
   *
   * @example
   * ```typescript
   * const collection = await client.getCollection({
   *   name: "my_collection"
   * });
   * ```
   */
  async getCollection({
    name,
    embeddingFunction
  }) {
    await this.init();
    const response = await this.api.getCollection(
      this.tenant,
      this.database,
      name,
      this.api.options
    );
    return wrapCollection(this, {
      name: response.name,
      id: response.id,
      metadata: response.metadata,
      embeddingFunction
    });
  }
  /**
   * Deletes a collection with the specified name.
   * @param {Object} params - The parameters for deleting a collection.
   * @param {string} params.name - The name of the collection.
   * @returns {Promise<void>} A promise that resolves when the collection is deleted.
   * @throws {Error} If there is an issue deleting the collection.
   *
   * @example
   * ```typescript
   * await client.deleteCollection({
   *  name: "my_collection"
   * });
   * ```
   */
  async deleteCollection({ name }) {
    await this.init();
    await this.api.deleteCollection(
      name,
      this.tenant,
      this.database,
      this.api.options
    );
  }
};

// src/CloudClient.ts
var CloudClient = class extends ChromaClient {
  constructor({
    apiKey,
    database,
    tenant,
    cloudHost,
    cloudPort
  }) {
    if (!apiKey) {
      apiKey = {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}.CHROMA_API_KEY;
    }
    if (!apiKey) {
      throw new Error("No API key provided");
    }
    cloudHost = cloudHost || "https://api.trychroma.com";
    cloudPort = cloudPort || "8000";
    const path = `${cloudHost}:${cloudPort}`;
    const auth = {
      provider: "token",
      credentials: apiKey,
      tokenHeaderType: "X_CHROMA_TOKEN"
    };
    return new ChromaClient({
      path,
      auth,
      database,
      tenant
    });
    super();
  }
};

// src/embeddings/OpenAIEmbeddingFunction.ts
var OpenAIApi;
var openAiVersion = null;
var openAiMajorVersion = null;
var OpenAIAPIv3 = class {
  constructor(configuration) {
    this.configuration = new OpenAIApi.Configuration({
      organization: configuration.organization,
      apiKey: configuration.apiKey
    });
    this.openai = new OpenAIApi.OpenAIApi(this.configuration);
  }
  async createEmbedding(params) {
    const embeddings = [];
    const response = await this.openai.createEmbedding({
      model: params.model,
      input: params.input
    }).catch((error) => {
      throw error;
    });
    const data = response.data["data"];
    for (let i = 0; i < data.length; i += 1) {
      embeddings.push(data[i]["embedding"]);
    }
    return embeddings;
  }
};
var OpenAIAPIv4 = class {
  constructor(apiKey) {
    this.apiKey = apiKey;
    this.openai = new OpenAIApi({
      apiKey: this.apiKey
    });
  }
  async createEmbedding(params) {
    const embeddings = [];
    const response = await this.openai.embeddings.create(params);
    const data = response["data"];
    for (let i = 0; i < data.length; i += 1) {
      embeddings.push(data[i]["embedding"]);
    }
    return embeddings;
  }
};
var OpenAIEmbeddingFunction = class _OpenAIEmbeddingFunction {
  constructor({
    openai_api_key,
    openai_model,
    openai_organization_id,
    openai_embedding_dimensions
  }) {
    this.api_key = openai_api_key;
    this.org_id = openai_organization_id || "";
    this.model = openai_model || "text-embedding-ada-002";
    this.dimensions = openai_embedding_dimensions;
  }
  async loadClient() {
    if (this.openaiApi)
      return;
    try {
      const { openai, version } = await _OpenAIEmbeddingFunction.import();
      OpenAIApi = openai;
      let versionVar = version;
      openAiVersion = versionVar.replace(/[^0-9.]/g, "");
      openAiMajorVersion = parseInt(openAiVersion.split(".")[0]);
    } catch (_a) {
      if (_a.code === "MODULE_NOT_FOUND") {
        throw new Error(
          "Please install the openai package to use the OpenAIEmbeddingFunction, e.g. `npm install openai`"
        );
      }
      throw _a;
    }
    if (openAiMajorVersion > 3) {
      this.openaiApi = new OpenAIAPIv4(this.api_key);
    } else {
      this.openaiApi = new OpenAIAPIv3({
        organization: this.org_id,
        apiKey: this.api_key
      });
    }
  }
  async generate(texts) {
    await this.loadClient();
    return await this.openaiApi.createEmbedding({
      model: this.model,
      input: texts,
      dimensions: this.dimensions
    }).catch((error) => {
      throw error;
    });
  }
  /** @ignore */
  static async import() {
    try {
      const { default: openai } = await __webpack_require__.e(/* import() */ 65).then(__webpack_require__.bind(__webpack_require__, 16065));
      const { VERSION } = await __webpack_require__.e(/* import() */ 797).then(__webpack_require__.bind(__webpack_require__, 797));
      return { openai, version: VERSION };
    } catch (e) {
      throw new Error(
        "Please install the openai package to use the OpenAIEmbeddingFunction, e.g. `npm install openai`"
      );
    }
  }
};

// src/embeddings/CohereEmbeddingFunction.ts
var CohereAISDK56 = class {
  constructor(configuration) {
    this.apiKey = configuration.apiKey;
  }
  async loadClient() {
    if (this.cohereClient)
      return;
    const { default: cohere } = await __webpack_require__.e(/* import() */ 998).then(__webpack_require__.t.bind(__webpack_require__, 7998, 19));
    cohere.init(this.apiKey);
    this.cohereClient = cohere;
  }
  async createEmbedding(params) {
    await this.loadClient();
    return await this.cohereClient.embed({
      texts: params.input,
      model: params.model
    }).then((response) => {
      return response.body.embeddings;
    });
  }
};
var CohereAISDK7 = class {
  constructor(configuration) {
    this.apiKey = configuration.apiKey;
  }
  async loadClient() {
    if (this.cohereClient)
      return;
    const cohere = await __webpack_require__.e(/* import() */ 998).then(__webpack_require__.t.bind(__webpack_require__, 7998, 19)).then((cohere2) => {
      return cohere2;
    });
    this.cohereClient = new cohere.CohereClient({
      token: this.apiKey
    });
  }
  async createEmbedding(params) {
    await this.loadClient();
    return await this.cohereClient.embed({ texts: params.input, model: params.model }).then((response) => {
      return response.embeddings;
    });
  }
};
var CohereEmbeddingFunction = class {
  constructor({
    cohere_api_key,
    model
  }) {
    this.model = model || "large";
    this.apiKey = cohere_api_key;
  }
  async initCohereClient() {
    if (this.cohereAiApi)
      return;
    try {
      this.cohereAiApi = await __webpack_require__.e(/* import() */ 998).then(__webpack_require__.t.bind(__webpack_require__, 7998, 19)).then((cohere) => {
        if (cohere.CohereClient) {
          return new CohereAISDK7({ apiKey: this.apiKey });
        } else {
          return new CohereAISDK56({ apiKey: this.apiKey });
        }
      });
    } catch (e) {
      if (e.code === "MODULE_NOT_FOUND") {
        throw new Error(
          "Please install the cohere-ai package to use the CohereEmbeddingFunction, `npm install -S cohere-ai`"
        );
      }
      throw e;
    }
  }
  async generate(texts) {
    await this.initCohereClient();
    return await this.cohereAiApi.createEmbedding({
      model: this.model,
      input: texts
    });
  }
};

// src/embeddings/TransformersEmbeddingFunction.ts
var TransformersApi2;
var TransformersEmbeddingFunction = class _TransformersEmbeddingFunction {
  /**
   * TransformersEmbeddingFunction constructor.
   * @param options The configuration options.
   * @param options.model The model to use to calculate embeddings. Defaults to 'Xenova/all-MiniLM-L6-v2', which is an ONNX port of `sentence-transformers/all-MiniLM-L6-v2`.
   * @param options.revision The specific model version to use (can be a branch, tag name, or commit id). Defaults to 'main'.
   * @param options.quantized Whether to load the 8-bit quantized version of the model. Defaults to `false`.
   * @param options.progress_callback If specified, this function will be called during model construction, to provide the user with progress updates.
   */
  constructor({
    model = "Xenova/all-MiniLM-L6-v2",
    revision = "main",
    quantized = false,
    progress_callback = null
  } = {}) {
    this.model = model;
    this.revision = revision;
    this.quantized = quantized;
    this.progress_callback = progress_callback;
  }
  async generate(texts) {
    await this.loadClient();
    this.pipelinePromise = new Promise(async (resolve, reject) => {
      try {
        const pipeline = this.transformersApi;
        const quantized = this.quantized;
        const revision = this.revision;
        const progress_callback = this.progress_callback;
        resolve(
          await pipeline("feature-extraction", this.model, {
            quantized,
            revision,
            progress_callback
          })
        );
      } catch (e) {
        reject(e);
      }
    });
    let pipe = await this.pipelinePromise;
    let output = await pipe(texts, { pooling: "mean", normalize: true });
    return output.tolist();
  }
  async loadClient() {
    if (this.transformersApi)
      return;
    try {
      let { pipeline } = await _TransformersEmbeddingFunction.import();
      TransformersApi2 = pipeline;
    } catch (_a) {
      if (_a.code === "MODULE_NOT_FOUND") {
        throw new Error(
          "Please install the @xenova/transformers package to use the TransformersEmbeddingFunction, `npm install @xenova/transformers`"
        );
      }
      throw _a;
    }
    this.transformersApi = TransformersApi2;
  }
  /** @ignore */
  static async import() {
    try {
      const { pipeline } = await __webpack_require__.e(/* import() */ 843).then(__webpack_require__.bind(__webpack_require__, 22319));
      return { pipeline };
    } catch (e) {
      throw new Error(
        "Please install @xenova/transformers as a dependency with, e.g. `npm install @xenova/transformers`"
      );
    }
  }
};

// src/embeddings/HuggingFaceEmbeddingServerFunction.ts
var HuggingFaceEmbeddingServerFunction = class {
  constructor({ url }) {
    this.url = url;
  }
  async generate(texts) {
    const response = await fetch(this.url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ inputs: texts })
    });
    if (!response.ok) {
      throw new Error(`Failed to generate embeddings: ${response.statusText}`);
    }
    const data = await response.json();
    return data;
  }
};

// src/embeddings/JinaEmbeddingFunction.ts
var JinaEmbeddingFunction = class {
  constructor({
    jinaai_api_key,
    model_name
  }) {
    this.model_name = model_name || "jina-embeddings-v2-base-en";
    this.api_url = "https://api.jina.ai/v1/embeddings";
    this.headers = {
      Authorization: `Bearer ${jinaai_api_key}`,
      "Accept-Encoding": "identity",
      "Content-Type": "application/json"
    };
  }
  async generate(texts) {
    try {
      const response = await fetch(this.api_url, {
        method: "POST",
        headers: this.headers,
        body: JSON.stringify({
          input: texts,
          model: this.model_name
        })
      });
      const data = await response.json();
      if (!data || !data.data) {
        throw new Error(data.detail);
      }
      const embeddings = data.data;
      const sortedEmbeddings = embeddings.sort((a, b) => a.index - b.index);
      return sortedEmbeddings.map((result) => result.embedding);
    } catch (error) {
      if (error instanceof Error) {
        throw new Error(`Error calling Jina AI API: ${error.message}`);
      } else {
        throw new Error(`Error calling Jina AI API: ${error}`);
      }
    }
  }
};

// src/embeddings/GoogleGeminiEmbeddingFunction.ts
var googleGenAiApi;
var GoogleGenerativeAiEmbeddingFunction = class _GoogleGenerativeAiEmbeddingFunction {
  constructor({
    googleApiKey,
    model,
    taskType
  }) {
    this.api_key = googleApiKey;
    this.model = model || "embedding-001";
    this.taskType = taskType || "RETRIEVAL_DOCUMENT";
  }
  async loadClient() {
    if (this.googleGenAiApi)
      return;
    try {
      const { googleGenAi } = await _GoogleGenerativeAiEmbeddingFunction.import();
      googleGenAiApi = googleGenAi;
      googleGenAiApi = new googleGenAiApi(this.api_key);
    } catch (_a) {
      if (_a.code === "MODULE_NOT_FOUND") {
        throw new Error(
          "Please install the @google/generative-ai package to use the GoogleGenerativeAiEmbeddingFunction, `npm install @google/generative-ai`"
        );
      }
      throw _a;
    }
    this.googleGenAiApi = googleGenAiApi;
  }
  async generate(texts) {
    await this.loadClient();
    const model = this.googleGenAiApi.getGenerativeModel({ model: this.model });
    const response = await model.batchEmbedContents({
      requests: texts.map((t) => ({
        content: { parts: [{ text: t }] },
        taskType: this.taskType
      }))
    });
    const embeddings = response.embeddings.map((e) => e.values);
    return embeddings;
  }
  /** @ignore */
  static async import() {
    try {
      const { GoogleGenerativeAI } = await __webpack_require__.e(/* import() */ 719).then(__webpack_require__.bind(__webpack_require__, 65719));
      const googleGenAi = GoogleGenerativeAI;
      return { googleGenAi };
    } catch (e) {
      throw new Error(
        "Please install @google/generative-ai as a dependency with, e.g. `npm install @google/generative-ai`"
      );
    }
  }
};

// src/embeddings/OllamaEmbeddingFunction.ts
var DEFAULT_MODEL = "chroma/all-minilm-l6-v2-f32";
var DEFAULT_LOCAL_URL = "http://localhost:11434";
var OllamaEmbeddingFunction = class _OllamaEmbeddingFunction {
  constructor({
    url = DEFAULT_LOCAL_URL,
    model = DEFAULT_MODEL
  } = {
    url: DEFAULT_LOCAL_URL,
    model: DEFAULT_MODEL
  }) {
    if (url && url.endsWith("/api/embeddings")) {
      this.url = url.slice(0, -"/api/embeddings".length);
    } else {
      this.url = url || DEFAULT_LOCAL_URL;
    }
    this.model = model || DEFAULT_MODEL;
  }
  async initClient() {
    if (this.ollamaClient)
      return;
    try {
      const { ollama } = await _OllamaEmbeddingFunction.import();
      this.ollamaClient = new ollama.Ollama({ host: this.url });
    } catch (e) {
      if (e.code === "MODULE_NOT_FOUND") {
        throw new Error(
          "Please install the ollama package to use the OllamaEmbeddingFunction, `npm install -S ollama`"
        );
      }
      throw e;
    }
  }
  /** @ignore */
  static async import() {
    try {
      const { ollama } = await Promise.resolve().then(function webpackMissingModule() { var e = new Error("Cannot find module 'ollama'"); e.code = 'MODULE_NOT_FOUND'; throw e; }).then((m) => ({ ollama: m }));
      return { ollama };
    } catch (e) {
      throw new Error(
        "Please install Ollama as a dependency with, e.g. `npm install ollama`"
      );
    }
  }
  async generate(texts) {
    await this.initClient();
    return await this.ollamaClient.embed({
      model: this.model,
      input: texts
    }).then((response) => {
      return response.embeddings;
    });
  }
};

// src/types.ts
var IncludeEnum = /* @__PURE__ */ ((IncludeEnum2) => {
  IncludeEnum2["Documents"] = "documents";
  IncludeEnum2["Embeddings"] = "embeddings";
  IncludeEnum2["Metadatas"] = "metadatas";
  IncludeEnum2["Distances"] = "distances";
  return IncludeEnum2;
})(IncludeEnum || {});

//# sourceMappingURL=chromadb.mjs.map
// EXTERNAL MODULE: ./src/embeddings.ts
var embeddings = __webpack_require__(81929);
// EXTERNAL MODULE: ./src/utils.ts
var utils = __webpack_require__(43922);
;// CONCATENATED MODULE: ./src/vectorStore.ts



let chromaClient = null;
let messageCollection = null;

// 获取嵌入向量
async function getEmbedding(text) {
  const envConfig = await (0,utils/* getEnvConfig */.Un)();
  if (!envConfig.ENABLE_CHROMA) {
    console.log('嵌入模型已禁用，返回空向量');
    return new Array(384).fill(0);
  }
  try {
    // 使用离屏文档获取嵌入向量
    return await (0,embeddings/* getEmbeddingViaOffscreen */.zP)(text);
  } catch (error) {
    console.error('获取嵌入向量失败:', error);
    return new Array(384).fill(0);
  }
}

// 初始化 Chroma 客户端
async function initChromaClient() {
  const envConfig = await (0,utils/* getEnvConfig */.Un)();
  if (!envConfig.ENABLE_CHROMA) {
    console.log('Chroma 向量数据库已禁用');
    return false;
  }
  try {
    chromaClient = new ChromaClient({
      path: envConfig.CHROMA_API_URL || 'http://localhost:8000'
    });
    console.log('正在连接向量数据库...');
    const collections = await chromaClient.listCollections();
    console.log('可用集合:', collections);

    // 创建一个空的 embeddingFunction，因为我们使用自定义的 getEmbedding 函数
    const embeddingFunction = {
      generate: async texts => {
        // 这个函数不会被调用，因为我们在添加文档前手动生成嵌入
        return new Array(texts.length).fill(new Array(1536).fill(0));
      }
    };
    let username = '';
    try {
      const {
        userinfo
      } = await chrome.storage.local.get('userinfo');
      username = userinfo.username || (userinfo.userEmail ? userinfo.userEmail.trim().split('@')[0] : userinfo.fullName.trim().split(' ').join('.').toLowerCase().replace(/[^a-z0-9_\-.]/g, ''));
      if (!username) throw new Error('username is empty');
    } catch (error) {
      envConfig.CHROMA_COLLECTION_NAME = 'messages';
    }
    const collectionName = envConfig.CHROMA_COLLECTION_NAME || username + '-messages';
    console.log('collectionName', collectionName, envConfig.CHROMA_COLLECTION_NAME, username);
    if (!collections.includes(collectionName)) {
      messageCollection = await chromaClient.createCollection({
        name: collectionName,
        metadata: {
          description: "存储与关注项匹配的消息"
        },
        embeddingFunction
      });
    } else {
      messageCollection = await chromaClient.getCollection({
        name: collectionName,
        embeddingFunction
      });
    }
    console.log('向量数据库集合已初始化', messageCollection);
    return true;
  } catch (error) {
    console.error('初始化 Chroma 客户端失败:', error);
    return false;
  }
}

// 存储消息到向量数据库
async function storeMessage(messageId, content, metadata) {
  const envConfig = await getEnvConfig();
  if (!envConfig.ENABLE_CHROMA) {
    console.log('Chroma 向量数据库已禁用，消息未存储');
    return false;
  }
  try {
    if (!messageCollection) {
      await initChromaClient();
    }
    if (!messageCollection) {
      throw new Error('向量数据库集合未初始化');
    }
    const embedding = await getEmbedding(content);

    // 简化元数据，确保它与 Chroma 兼容
    const simplifiedMetadata = {
      source: metadata.source,
      timestamp: metadata.timestamp,
      matchedRules: JSON.stringify(metadata.matchedRules),
      summary: metadata.summary,
      details: content
    };
    if (metadata.teamName) simplifiedMetadata.teamName = metadata.teamName;
    if (metadata.teamId) simplifiedMetadata.teamId = metadata.teamId;

    // 处理实体数据
    if (metadata.entities) {
      // 存储完整的实体数据
      simplifiedMetadata.entities = JSON.stringify(metadata.entities);

      // 为了便于搜索，单独存储实体名称列表
      if (metadata.entities.people) {
        simplifiedMetadata.people = JSON.stringify(metadata.entities.people.map(p => p.name));
      }
      if (metadata.entities.projects) {
        simplifiedMetadata.projects = JSON.stringify(metadata.entities.projects.map(p => p.name));
      }
      if (metadata.entities.topics) {
        simplifiedMetadata.topics = JSON.stringify(metadata.entities.topics.map(t => t.name));
      }
      if (metadata.entities.location) {
        simplifiedMetadata.locations = JSON.stringify(metadata.entities.location.map(l => l.name));
      }
    }

    // 处理元数据
    if (metadata.metadata) {
      if (metadata.metadata.sentiment) simplifiedMetadata.sentiment = metadata.metadata.sentiment;
      if (metadata.metadata.priority) simplifiedMetadata.priority = metadata.metadata.priority;
      if (metadata.metadata.category) simplifiedMetadata.category = JSON.stringify(metadata.metadata.category);
      if (metadata.metadata.tags) simplifiedMetadata.tags = JSON.stringify(metadata.metadata.tags);
    }

    // 处理关系数据
    if (metadata.relationships) {
      simplifiedMetadata.relationships = JSON.stringify(metadata.relationships);
    }

    // 处理行动项
    if (metadata.actions) {
      simplifiedMetadata.actions = JSON.stringify(metadata.actions);
    }

    // 生成搜索标签
    const allTags = new Set();

    // 添加所有实体名称到标签
    if (metadata.entities) {
      if (metadata.entities.people) {
        metadata.entities.people.forEach(p => allTags.add(p.name));
      }
      if (metadata.entities.projects) {
        metadata.entities.projects.forEach(p => allTags.add(p.name));
      }
      if (metadata.entities.topics) {
        metadata.entities.topics.forEach(t => allTags.add(t.name));
      }
      if (metadata.entities.location) {
        metadata.entities.location.forEach(l => allTags.add(l.name));
      }
    }

    // 添加分类和标签
    if (metadata.metadata?.category) {
      metadata.metadata.category.forEach(c => allTags.add(c));
    }
    if (metadata.metadata?.tags) {
      metadata.metadata.tags.forEach(t => allTags.add(t));
    }

    // 更新搜索标签
    simplifiedMetadata.searchTags = JSON.stringify(Array.from(allTags));
    await messageCollection.add({
      ids: [messageId],
      embeddings: [embedding],
      documents: [content],
      metadatas: [simplifiedMetadata]
    });
    console.log(`消息 ${messageId} 已存储到向量数据库`);
    return true;
  } catch (error) {
    console.error('存储消息到向量数据库失败:', error);
    return false;
  }
}

// 辅助函数：记录查询条件
function logQueryConditions(where) {
  console.log('完整查询条件:', JSON.stringify(where, null, 2));
  return where;
}

// 辅助函数：生成可能的 JSON 字符串模式
function generatePossibleJsonPatterns(value) {
  // 转义特殊字符，防止 JSON 注入
  const escapedValue = value.replace(/"/g, '\\"');

  // 基本模式，适用于单值数组和多值数组
  const patterns = [`["${escapedValue}"]`,
  // 精确匹配单个值 ["value"]
  `["${escapedValue}", `,
  // 数组开头 ["value", ...
  `, "${escapedValue}"]`,
  // 数组结尾 ..., "value"]
  `, "${escapedValue}", `,
  // 数组中间 ..., "value", ...
  `"${escapedValue}"` // 直接包含的值 "value"
  ];

  // 处理可能的空格变化
  patterns.push(`[ "${escapedValue}" ]`); // 带空格的数组 [ "value" ]
  patterns.push(`[ "${escapedValue}"]`); // 混合空格样式 [ "value"]
  patterns.push(`["${escapedValue}" ]`); // 混合空格样式 ["value" ]

  // 处理不同的引号格式（单引号）
  patterns.push(`['${escapedValue}']`); // 单引号格式 ['value']
  patterns.push(`'${escapedValue}'`); // 单引号直接值 'value'

  // 处理值本身包含的部分（用于子字符串搜索）
  if (escapedValue.includes(' ')) {
    // 如果值中包含空格，则提取关键部分
    const parts = escapedValue.split(' ');
    for (const part of parts) {
      if (part.length > 2) {
        // 只处理有意义的部分
        patterns.push(`"${part}"`); // 匹配部分关键词 "keyword"
        patterns.push(`'${part}'`); // 单引号格式 'keyword'
      }
    }
  }
  return patterns;
}

// 使用 $in 进行字符串模式匹配的更高级方法
function createJsonPatternFilters(field, values) {
  // 对每个值，生成可能的 JSON 模式
  const allPatterns = [];
  for (const value of values) {
    allPatterns.push(...generatePossibleJsonPatterns(value));
  }

  // 处理两种可能情况：
  // 1. 字段存储为JSON字符串数组  
  // 2. 字段直接存储为普通字符串（没有JSON格式化）
  return {
    "$or": [{
      [field]: {
        $in: allPatterns
      }
    },
    // 直接搜索原始值（针对可能未格式化为JSON的字段）
    ...values.map(value => ({
      [field]: value
    }))]
  };
}

// 修改：通用自然语言查询接口，添加 filters 参数
async function naturalLanguageQuery(userQuestion, filters, output) {
  const envConfig = await (0,utils/* getEnvConfig */.Un)();
  if (!envConfig.ENABLE_CHROMA) {
    console.log('Chroma 向量数据库已禁用，无法执行自然语言查询');
    return {
      question: userQuestion,
      results: {
        ids: [],
        documents: [],
        metadatas: [],
        distances: []
      }
    };
  }
  try {
    if (!messageCollection) {
      await initChromaClient();
    }
    if (!messageCollection) {
      throw new Error('向量数据库集合未初始化');
    }
    const queryEmbedding = await getEmbedding(userQuestion);
    const queryParams = {
      queryEmbeddings: [queryEmbedding],
      nResults: output?.limit || 20
    };
    if (filters && Object.keys(filters).length > 0) {
      const conditions = [];

      // 处理基础过滤条件
      if (filters.source) {
        conditions.push({
          source: filters.source
        });
      }
      if (filters.teamName) {
        conditions.push({
          teamName: filters.teamName
        });
      }

      // 处理时间范围过滤
      if (filters.time_range) {
        const {
          type,
          start,
          end
        } = filters.time_range;

        // 对于"all"类型，不添加时间过滤
        if (type === "all") {
          console.log(`时间范围类型为"all"，不应用时间过滤`);
        }
        // 如果具有明确的start和end时间
        else if (start && end) {
          // 修复：Chroma不支持多个操作符在同一个对象中的写法
          conditions.push({
            "$and": [{
              timestamp: {
                "$gte": start
              }
            }, {
              timestamp: {
                "$lte": end
              }
            }]
          });
          console.log(`应用时间范围过滤: ${new Date(start).toISOString()} 到 ${new Date(end).toISOString()}`);
        }
        // 如果只有start时间（从某时刻到现在）
        else if (start && !end) {
          conditions.push({
            timestamp: {
              "$gte": start
            }
          });
          console.log(`应用时间范围过滤: ${new Date(start).toISOString()} 到现在`);
        }
        // 如果只有end时间（到某个时刻为止）
        else if (!start && end) {
          conditions.push({
            timestamp: {
              "$lte": end
            }
          });
          console.log(`应用时间范围过滤: 从最早到 ${new Date(end).toISOString()}`);
        }
        // 如果是特定时间
        else if (type === "specific" && start) {
          // 为特定时间点添加一天的范围，以确保能捕获到该天的所有消息
          const nextDay = start + 24 * 60 * 60 * 1000;
          // 修复：Chroma不支持多个操作符在同一个对象中的写法
          conditions.push({
            "$and": [{
              timestamp: {
                "$gte": start
              }
            }, {
              timestamp: {
                "$lte": nextDay
              }
            }]
          });
          console.log(`应用特定时间过滤: ${new Date(start).toISOString()}`);
        }
        // 对于recent类型（如果走到这里，说明没有设置start和end）
        else if (type === "recent") {
          const now = new Date();
          const sevenDaysAgo = now.getTime() - 7 * 24 * 60 * 60 * 1000;
          conditions.push({
            "$and": [{
              timestamp: {
                "$gte": sevenDaysAgo
              }
            }, {
              timestamp: {
                "$lte": now.getTime()
              }
            }]
          });
          console.log(`应用最近时间范围过滤(7天): ${new Date(sevenDaysAgo).toISOString()} 到 ${new Date().toISOString()}`);
        }
      }

      // 处理实体过滤
      if (filters.entities) {
        // 处理人物过滤
        if (filters.entities.people?.length) {
          const peopleNames = filters.entities.people.map(p => p.name);

          // 增强人名匹配：同时检查 people 字段和 source 字段
          const peopleCondition = {
            "$or": [createJsonPatternFilters('people', peopleNames),
            // 同时检查source字段（发送者）
            ...peopleNames.map(name => ({
              source: name
            }))]
          };
          conditions.push(peopleCondition);
        }

        // 处理项目过滤
        if (filters.entities.projects?.length) {
          const projectNames = filters.entities.projects.map(p => p.name);
          conditions.push(createJsonPatternFilters('projects', projectNames));
        }

        // 处理话题过滤
        if (filters.entities.topics?.length) {
          const topicNames = filters.entities.topics.map(t => t.name);
          conditions.push(createJsonPatternFilters('topics', topicNames));
        }

        // 处理位置过滤
        if (filters.entities.location?.length) {
          const locationNames = filters.entities.location.map(l => l.name);
          conditions.push(createJsonPatternFilters('locations', locationNames));
        }
      }

      // 处理元数据过滤
      if (filters.metadata) {
        if (filters.metadata.sentiment) {
          conditions.push({
            sentiment: filters.metadata.sentiment
          });
        }
        if (filters.metadata.priority) {
          conditions.push({
            priority: filters.metadata.priority
          });
        }
        if (filters.metadata.category?.length) {
          conditions.push(createJsonPatternFilters('category', filters.metadata.category));
        }
        if (filters.metadata.tags?.length) {
          conditions.push(createJsonPatternFilters('searchTags', filters.metadata.tags));
        }
      }

      // 合并所有条件
      if (conditions.length > 0) {
        if (conditions.length === 1) {
          queryParams.where = logQueryConditions(conditions[0]);
        } else {
          queryParams.where = logQueryConditions({
            $and: conditions
          });
        }
      }
    }

    // 执行查询
    console.log('naturalLanguageQuery queryParams', queryParams);
    let results = await messageCollection.query(queryParams);

    // 记录结果
    console.log(`查询结果: 找到 ${results.ids[0]?.length || 0} 条匹配记录`);
    if (results.ids[0]?.length > 0) {
      console.log('第一条记录预览:', {
        id: results.ids[0][0],
        document: results.documents[0][0].substring(0, 100) + '...',
        metadata: results.metadatas[0][0]
      });
    } else {
      console.log('没有找到匹配记录，检查是否因为查询条件过于严格');
      // 尝试仅通过向量相似度查询
      console.log('尝试仅使用向量相似度查询，不添加过滤条件');
      try {
        results = await messageCollection.query({
          queryEmbeddings: [queryEmbedding],
          nResults: output?.limit || 20
        });
        console.log(`向量相似度查询结果: 找到 ${results.ids[0]?.length || 0} 条匹配记录`);
        if (results.ids[0]?.length > 0 && filters.entities.people?.length) {
          const simpleNames = filters.entities.people.map(p => p.name);
          // 找出匹配的索引位置
          const matchedIndices = results.metadatas[0].map((meta, index) => {
            const source = meta.source?.toString().toLowerCase() || '';
            return simpleNames.some(name => source.includes(name.toLowerCase())) ? index : -1;
          }).filter(i => i !== -1);

          // 根据匹配的索引过滤所有结果
          results.ids[0] = matchedIndices.map(i => results.ids[0][i]);
          results.metadatas[0] = matchedIndices.map(i => results.metadatas[0][i]);
          results.documents[0] = matchedIndices.map(i => results.documents[0][i]);
          results.distances[0] = matchedIndices.map(i => results.distances[0][i]);
          console.log(`其中有 ${matchedIndices.length} 条与 ${simpleNames.join(', ')} 相关的消息`);
        }
      } catch (error) {
        console.error('简单向量查询也失败了:', error);
      }
    }

    // 返回查询结果
    return {
      question: userQuestion,
      results: {
        ids: results.ids[0] || [],
        documents: results.documents[0] || [],
        metadatas: results.metadatas[0] || [],
        distances: results.distances[0] || []
      }
    };
  } catch (error) {
    console.error('自然语言查询失败:', error);
    return null;
  }
}

// 获取所有已知的人名
async function getAllKnownPeople() {
  const envConfig = await getEnvConfig();
  if (!envConfig.ENABLE_CHROMA) {
    console.log('Chroma 向量数据库已禁用，无法获取已知人名');
    return [];
  }
  try {
    if (!messageCollection) {
      await initChromaClient();
    }
    if (!messageCollection) {
      throw new Error('向量数据库集合未初始化');
    }

    // 获取所有消息的元数据
    const allMessages = await messageCollection.get();

    // 提取所有来源（发送者）
    const sources = new Set();
    if (allMessages && allMessages.metadatas) {
      allMessages.metadatas.forEach(metadata => {
        if (metadata.source) {
          sources.add(String(metadata.source));
        }
      });
    }

    // 提取所有提到的人物
    const mentionedPeople = new Set();
    if (allMessages && allMessages.metadatas) {
      allMessages.metadatas.forEach(metadata => {
        if (metadata.people) {
          try {
            const people = JSON.parse(String(metadata.people));
            if (Array.isArray(people)) {
              people.forEach(person => mentionedPeople.add(person));
            }
          } catch (e) {
            console.error('解析人物数据失败:', e);
          }
        }
      });
    }

    // 合并所有人名
    return Array.from(new Set([...Array.from(sources), ...Array.from(mentionedPeople)]));
  } catch (error) {
    console.error('获取已知人名失败:', error);
    return [];
  }
}

// 模糊匹配人名
function fuzzyMatchPerson(partialName, knownPeople) {
  if (!partialName || !knownPeople || knownPeople.length === 0) {
    return null;
  }

  // 转换为小写进行比较
  const lowerPartialName = partialName.toLowerCase();

  // 1. 精确匹配（忽略大小写）
  const exactMatch = knownPeople.find(person => person.toLowerCase() === lowerPartialName);
  if (exactMatch) return exactMatch;

  // 2. 开头匹配（例如 "Nelson" 匹配 "Nelson Wu"）
  const startsWithMatch = knownPeople.find(person => person.toLowerCase().startsWith(lowerPartialName));
  if (startsWithMatch) return startsWithMatch;

  // 3. 包含匹配（例如 "Wu" 匹配 "Nelson Wu"）
  const containsMatch = knownPeople.find(person => person.toLowerCase().includes(lowerPartialName));
  if (containsMatch) return containsMatch;

  // 4. 分词匹配（例如 "nelson" 匹配 "Nelson Wu"）
  const wordMatch = knownPeople.find(person => {
    const words = person.toLowerCase().split(/\s+/);
    return words.some(word => word === lowerPartialName);
  });
  if (wordMatch) return wordMatch;

  // 5. 首字母匹配（例如 "NW" 匹配 "Nelson Wu"）
  if (lowerPartialName.length >= 2) {
    const initialsMatch = knownPeople.find(person => {
      const initials = person.split(/\s+/).map(word => word[0]?.toLowerCase()).join('');
      return initials === lowerPartialName;
    });
    if (initialsMatch) return initialsMatch;
  }

  // 没有找到匹配
  return null;
}

// 获取所有已知的项目
async function getAllKnownProjects() {
  const envConfig = await getEnvConfig();
  if (!envConfig.ENABLE_CHROMA) {
    console.log('Chroma 向量数据库已禁用，无法获取已知项目');
    return [];
  }
  try {
    if (!messageCollection) {
      await initChromaClient();
    }
    if (!messageCollection) {
      throw new Error('向量数据库集合未初始化');
    }

    // 获取所有消息的元数据
    const allMessages = await messageCollection.get();

    // 提取所有项目
    const projects = new Set();
    if (allMessages && allMessages.metadatas) {
      allMessages.metadatas.forEach(metadata => {
        if (metadata.projects) {
          try {
            const projectsList = JSON.parse(String(metadata.projects));
            if (Array.isArray(projectsList)) {
              projectsList.forEach(project => projects.add(project));
            }
          } catch (e) {
            console.error('解析项目数据失败:', e);
          }
        }
      });
    }
    return Array.from(projects);
  } catch (error) {
    console.error('获取已知项目失败:', error);
    return [];
  }
}

// 获取所有已知的主题
async function getAllKnownTopics() {
  const envConfig = await getEnvConfig();
  if (!envConfig.ENABLE_CHROMA) {
    console.log('Chroma 向量数据库已禁用，无法获取已知主题');
    return [];
  }
  try {
    if (!messageCollection) {
      await initChromaClient();
    }
    if (!messageCollection) {
      throw new Error('向量数据库集合未初始化');
    }

    // 获取所有消息的元数据
    const allMessages = await messageCollection.get();

    // 提取所有主题
    const topics = new Set();
    if (allMessages && allMessages.metadatas) {
      allMessages.metadatas.forEach(metadata => {
        if (metadata.topics) {
          try {
            const topicsList = JSON.parse(String(metadata.topics));
            if (Array.isArray(topicsList)) {
              topicsList.forEach(topic => topics.add(topic));
            }
          } catch (e) {
            console.error('解析主题数据失败:', e);
          }
        }
      });
    }
    return Array.from(topics);
  } catch (error) {
    console.error('获取已知主题失败:', error);
    return [];
  }
}

// 模糊匹配项目或主题
function fuzzyMatchEntityName(partialName, knownNames) {
  if (!partialName || !knownNames || knownNames.length === 0) {
    return [];
  }

  // 转换为小写进行比较
  const lowerPartialName = partialName.toLowerCase();
  const matches = [];

  // 1. 精确匹配（忽略大小写）
  const exactMatches = knownNames.filter(name => name.toLowerCase() === lowerPartialName);
  matches.push(...exactMatches);

  // 如果找到精确匹配，直接返回
  if (matches.length > 0) return matches;

  // 2. 开头匹配（例如 "AI note" 匹配 "AI note 相关的规划进度"）
  const startsWithMatches = knownNames.filter(name => name.toLowerCase().startsWith(lowerPartialName));
  matches.push(...startsWithMatches);

  // 3. 包含匹配（例如 "note" 匹配 "AI note 相关的规划进度"）
  const containsMatches = knownNames.filter(name => name.toLowerCase().includes(lowerPartialName) && !matches.includes(name) // 避免重复
  );
  matches.push(...containsMatches);

  // 4. 词语匹配（例如 "AI" 和 "note" 都匹配 "AI note 相关的规划进度"）
  const words = lowerPartialName.split(/\s+/);
  if (words.length > 1) {
    const wordMatches = knownNames.filter(name => {
      const nameWords = name.toLowerCase().split(/\s+/);
      return words.every(word => nameWords.some(nameWord => nameWord.includes(word))) && !matches.includes(name); // 避免重复
    });
    matches.push(...wordMatches);
  }
  return matches;
}

/***/ }),

/***/ 67526:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports.byteLength = byteLength
exports.toByteArray = toByteArray
exports.fromByteArray = fromByteArray

var lookup = []
var revLookup = []
var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array

var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
for (var i = 0, len = code.length; i < len; ++i) {
  lookup[i] = code[i]
  revLookup[code.charCodeAt(i)] = i
}

// Support decoding URL-safe base64 strings, as Node.js does.
// See: https://en.wikipedia.org/wiki/Base64#URL_applications
revLookup['-'.charCodeAt(0)] = 62
revLookup['_'.charCodeAt(0)] = 63

function getLens (b64) {
  var len = b64.length

  if (len % 4 > 0) {
    throw new Error('Invalid string. Length must be a multiple of 4')
  }

  // Trim off extra bytes after placeholder bytes are found
  // See: https://github.com/beatgammit/base64-js/issues/42
  var validLen = b64.indexOf('=')
  if (validLen === -1) validLen = len

  var placeHoldersLen = validLen === len
    ? 0
    : 4 - (validLen % 4)

  return [validLen, placeHoldersLen]
}

// base64 is 4/3 + up to two characters of the original data
function byteLength (b64) {
  var lens = getLens(b64)
  var validLen = lens[0]
  var placeHoldersLen = lens[1]
  return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
}

function _byteLength (b64, validLen, placeHoldersLen) {
  return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
}

function toByteArray (b64) {
  var tmp
  var lens = getLens(b64)
  var validLen = lens[0]
  var placeHoldersLen = lens[1]

  var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen))

  var curByte = 0

  // if there are placeholders, only get up to the last complete 4 chars
  var len = placeHoldersLen > 0
    ? validLen - 4
    : validLen

  var i
  for (i = 0; i < len; i += 4) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 18) |
      (revLookup[b64.charCodeAt(i + 1)] << 12) |
      (revLookup[b64.charCodeAt(i + 2)] << 6) |
      revLookup[b64.charCodeAt(i + 3)]
    arr[curByte++] = (tmp >> 16) & 0xFF
    arr[curByte++] = (tmp >> 8) & 0xFF
    arr[curByte++] = tmp & 0xFF
  }

  if (placeHoldersLen === 2) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 2) |
      (revLookup[b64.charCodeAt(i + 1)] >> 4)
    arr[curByte++] = tmp & 0xFF
  }

  if (placeHoldersLen === 1) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 10) |
      (revLookup[b64.charCodeAt(i + 1)] << 4) |
      (revLookup[b64.charCodeAt(i + 2)] >> 2)
    arr[curByte++] = (tmp >> 8) & 0xFF
    arr[curByte++] = tmp & 0xFF
  }

  return arr
}

function tripletToBase64 (num) {
  return lookup[num >> 18 & 0x3F] +
    lookup[num >> 12 & 0x3F] +
    lookup[num >> 6 & 0x3F] +
    lookup[num & 0x3F]
}

function encodeChunk (uint8, start, end) {
  var tmp
  var output = []
  for (var i = start; i < end; i += 3) {
    tmp =
      ((uint8[i] << 16) & 0xFF0000) +
      ((uint8[i + 1] << 8) & 0xFF00) +
      (uint8[i + 2] & 0xFF)
    output.push(tripletToBase64(tmp))
  }
  return output.join('')
}

function fromByteArray (uint8) {
  var tmp
  var len = uint8.length
  var extraBytes = len % 3 // if we have 1 byte left, pad 2 bytes
  var parts = []
  var maxChunkLength = 16383 // must be multiple of 3

  // go through the array every three bytes, we'll deal with trailing stuff later
  for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
    parts.push(encodeChunk(uint8, i, (i + maxChunkLength) > len2 ? len2 : (i + maxChunkLength)))
  }

  // pad the end with zeros, but make sure to not forget the extra bytes
  if (extraBytes === 1) {
    tmp = uint8[len - 1]
    parts.push(
      lookup[tmp >> 2] +
      lookup[(tmp << 4) & 0x3F] +
      '=='
    )
  } else if (extraBytes === 2) {
    tmp = (uint8[len - 2] << 8) + uint8[len - 1]
    parts.push(
      lookup[tmp >> 10] +
      lookup[(tmp >> 4) & 0x3F] +
      lookup[(tmp << 2) & 0x3F] +
      '='
    )
  }

  return parts.join('')
}


/***/ }),

/***/ 48287:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */
/* eslint-disable no-proto */



const base64 = __webpack_require__(67526)
const ieee754 = __webpack_require__(251)
const customInspectSymbol =
  (typeof Symbol === 'function' && typeof Symbol['for'] === 'function') // eslint-disable-line dot-notation
    ? Symbol['for']('nodejs.util.inspect.custom') // eslint-disable-line dot-notation
    : null

exports.Buffer = Buffer
exports.SlowBuffer = SlowBuffer
exports.INSPECT_MAX_BYTES = 50

const K_MAX_LENGTH = 0x7fffffff
exports.kMaxLength = K_MAX_LENGTH

/**
 * If `Buffer.TYPED_ARRAY_SUPPORT`:
 *   === true    Use Uint8Array implementation (fastest)
 *   === false   Print warning and recommend using `buffer` v4.x which has an Object
 *               implementation (most compatible, even IE6)
 *
 * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
 * Opera 11.6+, iOS 4.2+.
 *
 * We report that the browser does not support typed arrays if the are not subclassable
 * using __proto__. Firefox 4-29 lacks support for adding new properties to `Uint8Array`
 * (See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438). IE 10 lacks support
 * for __proto__ and has a buggy typed array implementation.
 */
Buffer.TYPED_ARRAY_SUPPORT = typedArraySupport()

if (!Buffer.TYPED_ARRAY_SUPPORT && typeof console !== 'undefined' &&
    typeof console.error === 'function') {
  console.error(
    'This browser lacks typed array (Uint8Array) support which is required by ' +
    '`buffer` v5.x. Use `buffer` v4.x if you require old browser support.'
  )
}

function typedArraySupport () {
  // Can typed array instances can be augmented?
  try {
    const arr = new Uint8Array(1)
    const proto = { foo: function () { return 42 } }
    Object.setPrototypeOf(proto, Uint8Array.prototype)
    Object.setPrototypeOf(arr, proto)
    return arr.foo() === 42
  } catch (e) {
    return false
  }
}

Object.defineProperty(Buffer.prototype, 'parent', {
  enumerable: true,
  get: function () {
    if (!Buffer.isBuffer(this)) return undefined
    return this.buffer
  }
})

Object.defineProperty(Buffer.prototype, 'offset', {
  enumerable: true,
  get: function () {
    if (!Buffer.isBuffer(this)) return undefined
    return this.byteOffset
  }
})

function createBuffer (length) {
  if (length > K_MAX_LENGTH) {
    throw new RangeError('The value "' + length + '" is invalid for option "size"')
  }
  // Return an augmented `Uint8Array` instance
  const buf = new Uint8Array(length)
  Object.setPrototypeOf(buf, Buffer.prototype)
  return buf
}

/**
 * The Buffer constructor returns instances of `Uint8Array` that have their
 * prototype changed to `Buffer.prototype`. Furthermore, `Buffer` is a subclass of
 * `Uint8Array`, so the returned instances will have all the node `Buffer` methods
 * and the `Uint8Array` methods. Square bracket notation works as expected -- it
 * returns a single octet.
 *
 * The `Uint8Array` prototype remains unmodified.
 */

function Buffer (arg, encodingOrOffset, length) {
  // Common case.
  if (typeof arg === 'number') {
    if (typeof encodingOrOffset === 'string') {
      throw new TypeError(
        'The "string" argument must be of type string. Received type number'
      )
    }
    return allocUnsafe(arg)
  }
  return from(arg, encodingOrOffset, length)
}

Buffer.poolSize = 8192 // not used by this implementation

function from (value, encodingOrOffset, length) {
  if (typeof value === 'string') {
    return fromString(value, encodingOrOffset)
  }

  if (ArrayBuffer.isView(value)) {
    return fromArrayView(value)
  }

  if (value == null) {
    throw new TypeError(
      'The first argument must be one of type string, Buffer, ArrayBuffer, Array, ' +
      'or Array-like Object. Received type ' + (typeof value)
    )
  }

  if (isInstance(value, ArrayBuffer) ||
      (value && isInstance(value.buffer, ArrayBuffer))) {
    return fromArrayBuffer(value, encodingOrOffset, length)
  }

  if (typeof SharedArrayBuffer !== 'undefined' &&
      (isInstance(value, SharedArrayBuffer) ||
      (value && isInstance(value.buffer, SharedArrayBuffer)))) {
    return fromArrayBuffer(value, encodingOrOffset, length)
  }

  if (typeof value === 'number') {
    throw new TypeError(
      'The "value" argument must not be of type number. Received type number'
    )
  }

  const valueOf = value.valueOf && value.valueOf()
  if (valueOf != null && valueOf !== value) {
    return Buffer.from(valueOf, encodingOrOffset, length)
  }

  const b = fromObject(value)
  if (b) return b

  if (typeof Symbol !== 'undefined' && Symbol.toPrimitive != null &&
      typeof value[Symbol.toPrimitive] === 'function') {
    return Buffer.from(value[Symbol.toPrimitive]('string'), encodingOrOffset, length)
  }

  throw new TypeError(
    'The first argument must be one of type string, Buffer, ArrayBuffer, Array, ' +
    'or Array-like Object. Received type ' + (typeof value)
  )
}

/**
 * Functionally equivalent to Buffer(arg, encoding) but throws a TypeError
 * if value is a number.
 * Buffer.from(str[, encoding])
 * Buffer.from(array)
 * Buffer.from(buffer)
 * Buffer.from(arrayBuffer[, byteOffset[, length]])
 **/
Buffer.from = function (value, encodingOrOffset, length) {
  return from(value, encodingOrOffset, length)
}

// Note: Change prototype *after* Buffer.from is defined to workaround Chrome bug:
// https://github.com/feross/buffer/pull/148
Object.setPrototypeOf(Buffer.prototype, Uint8Array.prototype)
Object.setPrototypeOf(Buffer, Uint8Array)

function assertSize (size) {
  if (typeof size !== 'number') {
    throw new TypeError('"size" argument must be of type number')
  } else if (size < 0) {
    throw new RangeError('The value "' + size + '" is invalid for option "size"')
  }
}

function alloc (size, fill, encoding) {
  assertSize(size)
  if (size <= 0) {
    return createBuffer(size)
  }
  if (fill !== undefined) {
    // Only pay attention to encoding if it's a string. This
    // prevents accidentally sending in a number that would
    // be interpreted as a start offset.
    return typeof encoding === 'string'
      ? createBuffer(size).fill(fill, encoding)
      : createBuffer(size).fill(fill)
  }
  return createBuffer(size)
}

/**
 * Creates a new filled Buffer instance.
 * alloc(size[, fill[, encoding]])
 **/
Buffer.alloc = function (size, fill, encoding) {
  return alloc(size, fill, encoding)
}

function allocUnsafe (size) {
  assertSize(size)
  return createBuffer(size < 0 ? 0 : checked(size) | 0)
}

/**
 * Equivalent to Buffer(num), by default creates a non-zero-filled Buffer instance.
 * */
Buffer.allocUnsafe = function (size) {
  return allocUnsafe(size)
}
/**
 * Equivalent to SlowBuffer(num), by default creates a non-zero-filled Buffer instance.
 */
Buffer.allocUnsafeSlow = function (size) {
  return allocUnsafe(size)
}

function fromString (string, encoding) {
  if (typeof encoding !== 'string' || encoding === '') {
    encoding = 'utf8'
  }

  if (!Buffer.isEncoding(encoding)) {
    throw new TypeError('Unknown encoding: ' + encoding)
  }

  const length = byteLength(string, encoding) | 0
  let buf = createBuffer(length)

  const actual = buf.write(string, encoding)

  if (actual !== length) {
    // Writing a hex string, for example, that contains invalid characters will
    // cause everything after the first invalid character to be ignored. (e.g.
    // 'abxxcd' will be treated as 'ab')
    buf = buf.slice(0, actual)
  }

  return buf
}

function fromArrayLike (array) {
  const length = array.length < 0 ? 0 : checked(array.length) | 0
  const buf = createBuffer(length)
  for (let i = 0; i < length; i += 1) {
    buf[i] = array[i] & 255
  }
  return buf
}

function fromArrayView (arrayView) {
  if (isInstance(arrayView, Uint8Array)) {
    const copy = new Uint8Array(arrayView)
    return fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength)
  }
  return fromArrayLike(arrayView)
}

function fromArrayBuffer (array, byteOffset, length) {
  if (byteOffset < 0 || array.byteLength < byteOffset) {
    throw new RangeError('"offset" is outside of buffer bounds')
  }

  if (array.byteLength < byteOffset + (length || 0)) {
    throw new RangeError('"length" is outside of buffer bounds')
  }

  let buf
  if (byteOffset === undefined && length === undefined) {
    buf = new Uint8Array(array)
  } else if (length === undefined) {
    buf = new Uint8Array(array, byteOffset)
  } else {
    buf = new Uint8Array(array, byteOffset, length)
  }

  // Return an augmented `Uint8Array` instance
  Object.setPrototypeOf(buf, Buffer.prototype)

  return buf
}

function fromObject (obj) {
  if (Buffer.isBuffer(obj)) {
    const len = checked(obj.length) | 0
    const buf = createBuffer(len)

    if (buf.length === 0) {
      return buf
    }

    obj.copy(buf, 0, 0, len)
    return buf
  }

  if (obj.length !== undefined) {
    if (typeof obj.length !== 'number' || numberIsNaN(obj.length)) {
      return createBuffer(0)
    }
    return fromArrayLike(obj)
  }

  if (obj.type === 'Buffer' && Array.isArray(obj.data)) {
    return fromArrayLike(obj.data)
  }
}

function checked (length) {
  // Note: cannot use `length < K_MAX_LENGTH` here because that fails when
  // length is NaN (which is otherwise coerced to zero.)
  if (length >= K_MAX_LENGTH) {
    throw new RangeError('Attempt to allocate Buffer larger than maximum ' +
                         'size: 0x' + K_MAX_LENGTH.toString(16) + ' bytes')
  }
  return length | 0
}

function SlowBuffer (length) {
  if (+length != length) { // eslint-disable-line eqeqeq
    length = 0
  }
  return Buffer.alloc(+length)
}

Buffer.isBuffer = function isBuffer (b) {
  return b != null && b._isBuffer === true &&
    b !== Buffer.prototype // so Buffer.isBuffer(Buffer.prototype) will be false
}

Buffer.compare = function compare (a, b) {
  if (isInstance(a, Uint8Array)) a = Buffer.from(a, a.offset, a.byteLength)
  if (isInstance(b, Uint8Array)) b = Buffer.from(b, b.offset, b.byteLength)
  if (!Buffer.isBuffer(a) || !Buffer.isBuffer(b)) {
    throw new TypeError(
      'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
    )
  }

  if (a === b) return 0

  let x = a.length
  let y = b.length

  for (let i = 0, len = Math.min(x, y); i < len; ++i) {
    if (a[i] !== b[i]) {
      x = a[i]
      y = b[i]
      break
    }
  }

  if (x < y) return -1
  if (y < x) return 1
  return 0
}

Buffer.isEncoding = function isEncoding (encoding) {
  switch (String(encoding).toLowerCase()) {
    case 'hex':
    case 'utf8':
    case 'utf-8':
    case 'ascii':
    case 'latin1':
    case 'binary':
    case 'base64':
    case 'ucs2':
    case 'ucs-2':
    case 'utf16le':
    case 'utf-16le':
      return true
    default:
      return false
  }
}

Buffer.concat = function concat (list, length) {
  if (!Array.isArray(list)) {
    throw new TypeError('"list" argument must be an Array of Buffers')
  }

  if (list.length === 0) {
    return Buffer.alloc(0)
  }

  let i
  if (length === undefined) {
    length = 0
    for (i = 0; i < list.length; ++i) {
      length += list[i].length
    }
  }

  const buffer = Buffer.allocUnsafe(length)
  let pos = 0
  for (i = 0; i < list.length; ++i) {
    let buf = list[i]
    if (isInstance(buf, Uint8Array)) {
      if (pos + buf.length > buffer.length) {
        if (!Buffer.isBuffer(buf)) buf = Buffer.from(buf)
        buf.copy(buffer, pos)
      } else {
        Uint8Array.prototype.set.call(
          buffer,
          buf,
          pos
        )
      }
    } else if (!Buffer.isBuffer(buf)) {
      throw new TypeError('"list" argument must be an Array of Buffers')
    } else {
      buf.copy(buffer, pos)
    }
    pos += buf.length
  }
  return buffer
}

function byteLength (string, encoding) {
  if (Buffer.isBuffer(string)) {
    return string.length
  }
  if (ArrayBuffer.isView(string) || isInstance(string, ArrayBuffer)) {
    return string.byteLength
  }
  if (typeof string !== 'string') {
    throw new TypeError(
      'The "string" argument must be one of type string, Buffer, or ArrayBuffer. ' +
      'Received type ' + typeof string
    )
  }

  const len = string.length
  const mustMatch = (arguments.length > 2 && arguments[2] === true)
  if (!mustMatch && len === 0) return 0

  // Use a for loop to avoid recursion
  let loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'ascii':
      case 'latin1':
      case 'binary':
        return len
      case 'utf8':
      case 'utf-8':
        return utf8ToBytes(string).length
      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return len * 2
      case 'hex':
        return len >>> 1
      case 'base64':
        return base64ToBytes(string).length
      default:
        if (loweredCase) {
          return mustMatch ? -1 : utf8ToBytes(string).length // assume utf8
        }
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}
Buffer.byteLength = byteLength

function slowToString (encoding, start, end) {
  let loweredCase = false

  // No need to verify that "this.length <= MAX_UINT32" since it's a read-only
  // property of a typed array.

  // This behaves neither like String nor Uint8Array in that we set start/end
  // to their upper/lower bounds if the value passed is out of range.
  // undefined is handled specially as per ECMA-262 6th Edition,
  // Section 13.3.3.7 Runtime Semantics: KeyedBindingInitialization.
  if (start === undefined || start < 0) {
    start = 0
  }
  // Return early if start > this.length. Done here to prevent potential uint32
  // coercion fail below.
  if (start > this.length) {
    return ''
  }

  if (end === undefined || end > this.length) {
    end = this.length
  }

  if (end <= 0) {
    return ''
  }

  // Force coercion to uint32. This will also coerce falsey/NaN values to 0.
  end >>>= 0
  start >>>= 0

  if (end <= start) {
    return ''
  }

  if (!encoding) encoding = 'utf8'

  while (true) {
    switch (encoding) {
      case 'hex':
        return hexSlice(this, start, end)

      case 'utf8':
      case 'utf-8':
        return utf8Slice(this, start, end)

      case 'ascii':
        return asciiSlice(this, start, end)

      case 'latin1':
      case 'binary':
        return latin1Slice(this, start, end)

      case 'base64':
        return base64Slice(this, start, end)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return utf16leSlice(this, start, end)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = (encoding + '').toLowerCase()
        loweredCase = true
    }
  }
}

// This property is used by `Buffer.isBuffer` (and the `is-buffer` npm package)
// to detect a Buffer instance. It's not possible to use `instanceof Buffer`
// reliably in a browserify context because there could be multiple different
// copies of the 'buffer' package in use. This method works even for Buffer
// instances that were created from another copy of the `buffer` package.
// See: https://github.com/feross/buffer/issues/154
Buffer.prototype._isBuffer = true

function swap (b, n, m) {
  const i = b[n]
  b[n] = b[m]
  b[m] = i
}

Buffer.prototype.swap16 = function swap16 () {
  const len = this.length
  if (len % 2 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 16-bits')
  }
  for (let i = 0; i < len; i += 2) {
    swap(this, i, i + 1)
  }
  return this
}

Buffer.prototype.swap32 = function swap32 () {
  const len = this.length
  if (len % 4 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 32-bits')
  }
  for (let i = 0; i < len; i += 4) {
    swap(this, i, i + 3)
    swap(this, i + 1, i + 2)
  }
  return this
}

Buffer.prototype.swap64 = function swap64 () {
  const len = this.length
  if (len % 8 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 64-bits')
  }
  for (let i = 0; i < len; i += 8) {
    swap(this, i, i + 7)
    swap(this, i + 1, i + 6)
    swap(this, i + 2, i + 5)
    swap(this, i + 3, i + 4)
  }
  return this
}

Buffer.prototype.toString = function toString () {
  const length = this.length
  if (length === 0) return ''
  if (arguments.length === 0) return utf8Slice(this, 0, length)
  return slowToString.apply(this, arguments)
}

Buffer.prototype.toLocaleString = Buffer.prototype.toString

Buffer.prototype.equals = function equals (b) {
  if (!Buffer.isBuffer(b)) throw new TypeError('Argument must be a Buffer')
  if (this === b) return true
  return Buffer.compare(this, b) === 0
}

Buffer.prototype.inspect = function inspect () {
  let str = ''
  const max = exports.INSPECT_MAX_BYTES
  str = this.toString('hex', 0, max).replace(/(.{2})/g, '$1 ').trim()
  if (this.length > max) str += ' ... '
  return '<Buffer ' + str + '>'
}
if (customInspectSymbol) {
  Buffer.prototype[customInspectSymbol] = Buffer.prototype.inspect
}

Buffer.prototype.compare = function compare (target, start, end, thisStart, thisEnd) {
  if (isInstance(target, Uint8Array)) {
    target = Buffer.from(target, target.offset, target.byteLength)
  }
  if (!Buffer.isBuffer(target)) {
    throw new TypeError(
      'The "target" argument must be one of type Buffer or Uint8Array. ' +
      'Received type ' + (typeof target)
    )
  }

  if (start === undefined) {
    start = 0
  }
  if (end === undefined) {
    end = target ? target.length : 0
  }
  if (thisStart === undefined) {
    thisStart = 0
  }
  if (thisEnd === undefined) {
    thisEnd = this.length
  }

  if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
    throw new RangeError('out of range index')
  }

  if (thisStart >= thisEnd && start >= end) {
    return 0
  }
  if (thisStart >= thisEnd) {
    return -1
  }
  if (start >= end) {
    return 1
  }

  start >>>= 0
  end >>>= 0
  thisStart >>>= 0
  thisEnd >>>= 0

  if (this === target) return 0

  let x = thisEnd - thisStart
  let y = end - start
  const len = Math.min(x, y)

  const thisCopy = this.slice(thisStart, thisEnd)
  const targetCopy = target.slice(start, end)

  for (let i = 0; i < len; ++i) {
    if (thisCopy[i] !== targetCopy[i]) {
      x = thisCopy[i]
      y = targetCopy[i]
      break
    }
  }

  if (x < y) return -1
  if (y < x) return 1
  return 0
}

// Finds either the first index of `val` in `buffer` at offset >= `byteOffset`,
// OR the last index of `val` in `buffer` at offset <= `byteOffset`.
//
// Arguments:
// - buffer - a Buffer to search
// - val - a string, Buffer, or number
// - byteOffset - an index into `buffer`; will be clamped to an int32
// - encoding - an optional encoding, relevant is val is a string
// - dir - true for indexOf, false for lastIndexOf
function bidirectionalIndexOf (buffer, val, byteOffset, encoding, dir) {
  // Empty buffer means no match
  if (buffer.length === 0) return -1

  // Normalize byteOffset
  if (typeof byteOffset === 'string') {
    encoding = byteOffset
    byteOffset = 0
  } else if (byteOffset > 0x7fffffff) {
    byteOffset = 0x7fffffff
  } else if (byteOffset < -0x80000000) {
    byteOffset = -0x80000000
  }
  byteOffset = +byteOffset // Coerce to Number.
  if (numberIsNaN(byteOffset)) {
    // byteOffset: it it's undefined, null, NaN, "foo", etc, search whole buffer
    byteOffset = dir ? 0 : (buffer.length - 1)
  }

  // Normalize byteOffset: negative offsets start from the end of the buffer
  if (byteOffset < 0) byteOffset = buffer.length + byteOffset
  if (byteOffset >= buffer.length) {
    if (dir) return -1
    else byteOffset = buffer.length - 1
  } else if (byteOffset < 0) {
    if (dir) byteOffset = 0
    else return -1
  }

  // Normalize val
  if (typeof val === 'string') {
    val = Buffer.from(val, encoding)
  }

  // Finally, search either indexOf (if dir is true) or lastIndexOf
  if (Buffer.isBuffer(val)) {
    // Special case: looking for empty string/buffer always fails
    if (val.length === 0) {
      return -1
    }
    return arrayIndexOf(buffer, val, byteOffset, encoding, dir)
  } else if (typeof val === 'number') {
    val = val & 0xFF // Search for a byte value [0-255]
    if (typeof Uint8Array.prototype.indexOf === 'function') {
      if (dir) {
        return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset)
      } else {
        return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset)
      }
    }
    return arrayIndexOf(buffer, [val], byteOffset, encoding, dir)
  }

  throw new TypeError('val must be string, number or Buffer')
}

function arrayIndexOf (arr, val, byteOffset, encoding, dir) {
  let indexSize = 1
  let arrLength = arr.length
  let valLength = val.length

  if (encoding !== undefined) {
    encoding = String(encoding).toLowerCase()
    if (encoding === 'ucs2' || encoding === 'ucs-2' ||
        encoding === 'utf16le' || encoding === 'utf-16le') {
      if (arr.length < 2 || val.length < 2) {
        return -1
      }
      indexSize = 2
      arrLength /= 2
      valLength /= 2
      byteOffset /= 2
    }
  }

  function read (buf, i) {
    if (indexSize === 1) {
      return buf[i]
    } else {
      return buf.readUInt16BE(i * indexSize)
    }
  }

  let i
  if (dir) {
    let foundIndex = -1
    for (i = byteOffset; i < arrLength; i++) {
      if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
        if (foundIndex === -1) foundIndex = i
        if (i - foundIndex + 1 === valLength) return foundIndex * indexSize
      } else {
        if (foundIndex !== -1) i -= i - foundIndex
        foundIndex = -1
      }
    }
  } else {
    if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength
    for (i = byteOffset; i >= 0; i--) {
      let found = true
      for (let j = 0; j < valLength; j++) {
        if (read(arr, i + j) !== read(val, j)) {
          found = false
          break
        }
      }
      if (found) return i
    }
  }

  return -1
}

Buffer.prototype.includes = function includes (val, byteOffset, encoding) {
  return this.indexOf(val, byteOffset, encoding) !== -1
}

Buffer.prototype.indexOf = function indexOf (val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, true)
}

Buffer.prototype.lastIndexOf = function lastIndexOf (val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, false)
}

function hexWrite (buf, string, offset, length) {
  offset = Number(offset) || 0
  const remaining = buf.length - offset
  if (!length) {
    length = remaining
  } else {
    length = Number(length)
    if (length > remaining) {
      length = remaining
    }
  }

  const strLen = string.length

  if (length > strLen / 2) {
    length = strLen / 2
  }
  let i
  for (i = 0; i < length; ++i) {
    const parsed = parseInt(string.substr(i * 2, 2), 16)
    if (numberIsNaN(parsed)) return i
    buf[offset + i] = parsed
  }
  return i
}

function utf8Write (buf, string, offset, length) {
  return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length)
}

function asciiWrite (buf, string, offset, length) {
  return blitBuffer(asciiToBytes(string), buf, offset, length)
}

function base64Write (buf, string, offset, length) {
  return blitBuffer(base64ToBytes(string), buf, offset, length)
}

function ucs2Write (buf, string, offset, length) {
  return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length)
}

Buffer.prototype.write = function write (string, offset, length, encoding) {
  // Buffer#write(string)
  if (offset === undefined) {
    encoding = 'utf8'
    length = this.length
    offset = 0
  // Buffer#write(string, encoding)
  } else if (length === undefined && typeof offset === 'string') {
    encoding = offset
    length = this.length
    offset = 0
  // Buffer#write(string, offset[, length][, encoding])
  } else if (isFinite(offset)) {
    offset = offset >>> 0
    if (isFinite(length)) {
      length = length >>> 0
      if (encoding === undefined) encoding = 'utf8'
    } else {
      encoding = length
      length = undefined
    }
  } else {
    throw new Error(
      'Buffer.write(string, encoding, offset[, length]) is no longer supported'
    )
  }

  const remaining = this.length - offset
  if (length === undefined || length > remaining) length = remaining

  if ((string.length > 0 && (length < 0 || offset < 0)) || offset > this.length) {
    throw new RangeError('Attempt to write outside buffer bounds')
  }

  if (!encoding) encoding = 'utf8'

  let loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'hex':
        return hexWrite(this, string, offset, length)

      case 'utf8':
      case 'utf-8':
        return utf8Write(this, string, offset, length)

      case 'ascii':
      case 'latin1':
      case 'binary':
        return asciiWrite(this, string, offset, length)

      case 'base64':
        // Warning: maxLength not taken into account in base64Write
        return base64Write(this, string, offset, length)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return ucs2Write(this, string, offset, length)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}

Buffer.prototype.toJSON = function toJSON () {
  return {
    type: 'Buffer',
    data: Array.prototype.slice.call(this._arr || this, 0)
  }
}

function base64Slice (buf, start, end) {
  if (start === 0 && end === buf.length) {
    return base64.fromByteArray(buf)
  } else {
    return base64.fromByteArray(buf.slice(start, end))
  }
}

function utf8Slice (buf, start, end) {
  end = Math.min(buf.length, end)
  const res = []

  let i = start
  while (i < end) {
    const firstByte = buf[i]
    let codePoint = null
    let bytesPerSequence = (firstByte > 0xEF)
      ? 4
      : (firstByte > 0xDF)
          ? 3
          : (firstByte > 0xBF)
              ? 2
              : 1

    if (i + bytesPerSequence <= end) {
      let secondByte, thirdByte, fourthByte, tempCodePoint

      switch (bytesPerSequence) {
        case 1:
          if (firstByte < 0x80) {
            codePoint = firstByte
          }
          break
        case 2:
          secondByte = buf[i + 1]
          if ((secondByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0x1F) << 0x6 | (secondByte & 0x3F)
            if (tempCodePoint > 0x7F) {
              codePoint = tempCodePoint
            }
          }
          break
        case 3:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | (thirdByte & 0x3F)
            if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) {
              codePoint = tempCodePoint
            }
          }
          break
        case 4:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          fourthByte = buf[i + 3]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | (fourthByte & 0x3F)
            if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) {
              codePoint = tempCodePoint
            }
          }
      }
    }

    if (codePoint === null) {
      // we did not generate a valid codePoint so insert a
      // replacement char (U+FFFD) and advance only 1 byte
      codePoint = 0xFFFD
      bytesPerSequence = 1
    } else if (codePoint > 0xFFFF) {
      // encode to utf16 (surrogate pair dance)
      codePoint -= 0x10000
      res.push(codePoint >>> 10 & 0x3FF | 0xD800)
      codePoint = 0xDC00 | codePoint & 0x3FF
    }

    res.push(codePoint)
    i += bytesPerSequence
  }

  return decodeCodePointsArray(res)
}

// Based on http://stackoverflow.com/a/22747272/680742, the browser with
// the lowest limit is Chrome, with 0x10000 args.
// We go 1 magnitude less, for safety
const MAX_ARGUMENTS_LENGTH = 0x1000

function decodeCodePointsArray (codePoints) {
  const len = codePoints.length
  if (len <= MAX_ARGUMENTS_LENGTH) {
    return String.fromCharCode.apply(String, codePoints) // avoid extra slice()
  }

  // Decode in chunks to avoid "call stack size exceeded".
  let res = ''
  let i = 0
  while (i < len) {
    res += String.fromCharCode.apply(
      String,
      codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
    )
  }
  return res
}

function asciiSlice (buf, start, end) {
  let ret = ''
  end = Math.min(buf.length, end)

  for (let i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i] & 0x7F)
  }
  return ret
}

function latin1Slice (buf, start, end) {
  let ret = ''
  end = Math.min(buf.length, end)

  for (let i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i])
  }
  return ret
}

function hexSlice (buf, start, end) {
  const len = buf.length

  if (!start || start < 0) start = 0
  if (!end || end < 0 || end > len) end = len

  let out = ''
  for (let i = start; i < end; ++i) {
    out += hexSliceLookupTable[buf[i]]
  }
  return out
}

function utf16leSlice (buf, start, end) {
  const bytes = buf.slice(start, end)
  let res = ''
  // If bytes.length is odd, the last 8 bits must be ignored (same as node.js)
  for (let i = 0; i < bytes.length - 1; i += 2) {
    res += String.fromCharCode(bytes[i] + (bytes[i + 1] * 256))
  }
  return res
}

Buffer.prototype.slice = function slice (start, end) {
  const len = this.length
  start = ~~start
  end = end === undefined ? len : ~~end

  if (start < 0) {
    start += len
    if (start < 0) start = 0
  } else if (start > len) {
    start = len
  }

  if (end < 0) {
    end += len
    if (end < 0) end = 0
  } else if (end > len) {
    end = len
  }

  if (end < start) end = start

  const newBuf = this.subarray(start, end)
  // Return an augmented `Uint8Array` instance
  Object.setPrototypeOf(newBuf, Buffer.prototype)

  return newBuf
}

/*
 * Need to make sure that buffer isn't trying to write out of bounds.
 */
function checkOffset (offset, ext, length) {
  if ((offset % 1) !== 0 || offset < 0) throw new RangeError('offset is not uint')
  if (offset + ext > length) throw new RangeError('Trying to access beyond buffer length')
}

Buffer.prototype.readUintLE =
Buffer.prototype.readUIntLE = function readUIntLE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  let val = this[offset]
  let mul = 1
  let i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }

  return val
}

Buffer.prototype.readUintBE =
Buffer.prototype.readUIntBE = function readUIntBE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) {
    checkOffset(offset, byteLength, this.length)
  }

  let val = this[offset + --byteLength]
  let mul = 1
  while (byteLength > 0 && (mul *= 0x100)) {
    val += this[offset + --byteLength] * mul
  }

  return val
}

Buffer.prototype.readUint8 =
Buffer.prototype.readUInt8 = function readUInt8 (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 1, this.length)
  return this[offset]
}

Buffer.prototype.readUint16LE =
Buffer.prototype.readUInt16LE = function readUInt16LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  return this[offset] | (this[offset + 1] << 8)
}

Buffer.prototype.readUint16BE =
Buffer.prototype.readUInt16BE = function readUInt16BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  return (this[offset] << 8) | this[offset + 1]
}

Buffer.prototype.readUint32LE =
Buffer.prototype.readUInt32LE = function readUInt32LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return ((this[offset]) |
      (this[offset + 1] << 8) |
      (this[offset + 2] << 16)) +
      (this[offset + 3] * 0x1000000)
}

Buffer.prototype.readUint32BE =
Buffer.prototype.readUInt32BE = function readUInt32BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] * 0x1000000) +
    ((this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    this[offset + 3])
}

Buffer.prototype.readBigUInt64LE = defineBigIntMethod(function readBigUInt64LE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const lo = first +
    this[++offset] * 2 ** 8 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 24

  const hi = this[++offset] +
    this[++offset] * 2 ** 8 +
    this[++offset] * 2 ** 16 +
    last * 2 ** 24

  return BigInt(lo) + (BigInt(hi) << BigInt(32))
})

Buffer.prototype.readBigUInt64BE = defineBigIntMethod(function readBigUInt64BE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const hi = first * 2 ** 24 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    this[++offset]

  const lo = this[++offset] * 2 ** 24 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    last

  return (BigInt(hi) << BigInt(32)) + BigInt(lo)
})

Buffer.prototype.readIntLE = function readIntLE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  let val = this[offset]
  let mul = 1
  let i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readIntBE = function readIntBE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  let i = byteLength
  let mul = 1
  let val = this[offset + --i]
  while (i > 0 && (mul *= 0x100)) {
    val += this[offset + --i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readInt8 = function readInt8 (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 1, this.length)
  if (!(this[offset] & 0x80)) return (this[offset])
  return ((0xff - this[offset] + 1) * -1)
}

Buffer.prototype.readInt16LE = function readInt16LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  const val = this[offset] | (this[offset + 1] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt16BE = function readInt16BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  const val = this[offset + 1] | (this[offset] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt32LE = function readInt32LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset]) |
    (this[offset + 1] << 8) |
    (this[offset + 2] << 16) |
    (this[offset + 3] << 24)
}

Buffer.prototype.readInt32BE = function readInt32BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] << 24) |
    (this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    (this[offset + 3])
}

Buffer.prototype.readBigInt64LE = defineBigIntMethod(function readBigInt64LE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const val = this[offset + 4] +
    this[offset + 5] * 2 ** 8 +
    this[offset + 6] * 2 ** 16 +
    (last << 24) // Overflow

  return (BigInt(val) << BigInt(32)) +
    BigInt(first +
    this[++offset] * 2 ** 8 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 24)
})

Buffer.prototype.readBigInt64BE = defineBigIntMethod(function readBigInt64BE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const val = (first << 24) + // Overflow
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    this[++offset]

  return (BigInt(val) << BigInt(32)) +
    BigInt(this[++offset] * 2 ** 24 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    last)
})

Buffer.prototype.readFloatLE = function readFloatLE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, true, 23, 4)
}

Buffer.prototype.readFloatBE = function readFloatBE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, false, 23, 4)
}

Buffer.prototype.readDoubleLE = function readDoubleLE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, true, 52, 8)
}

Buffer.prototype.readDoubleBE = function readDoubleBE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, false, 52, 8)
}

function checkInt (buf, value, offset, ext, max, min) {
  if (!Buffer.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance')
  if (value > max || value < min) throw new RangeError('"value" argument is out of bounds')
  if (offset + ext > buf.length) throw new RangeError('Index out of range')
}

Buffer.prototype.writeUintLE =
Buffer.prototype.writeUIntLE = function writeUIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) {
    const maxBytes = Math.pow(2, 8 * byteLength) - 1
    checkInt(this, value, offset, byteLength, maxBytes, 0)
  }

  let mul = 1
  let i = 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUintBE =
Buffer.prototype.writeUIntBE = function writeUIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) {
    const maxBytes = Math.pow(2, 8 * byteLength) - 1
    checkInt(this, value, offset, byteLength, maxBytes, 0)
  }

  let i = byteLength - 1
  let mul = 1
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUint8 =
Buffer.prototype.writeUInt8 = function writeUInt8 (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0)
  this[offset] = (value & 0xff)
  return offset + 1
}

Buffer.prototype.writeUint16LE =
Buffer.prototype.writeUInt16LE = function writeUInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  this[offset] = (value & 0xff)
  this[offset + 1] = (value >>> 8)
  return offset + 2
}

Buffer.prototype.writeUint16BE =
Buffer.prototype.writeUInt16BE = function writeUInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  this[offset] = (value >>> 8)
  this[offset + 1] = (value & 0xff)
  return offset + 2
}

Buffer.prototype.writeUint32LE =
Buffer.prototype.writeUInt32LE = function writeUInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  this[offset + 3] = (value >>> 24)
  this[offset + 2] = (value >>> 16)
  this[offset + 1] = (value >>> 8)
  this[offset] = (value & 0xff)
  return offset + 4
}

Buffer.prototype.writeUint32BE =
Buffer.prototype.writeUInt32BE = function writeUInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  this[offset] = (value >>> 24)
  this[offset + 1] = (value >>> 16)
  this[offset + 2] = (value >>> 8)
  this[offset + 3] = (value & 0xff)
  return offset + 4
}

function wrtBigUInt64LE (buf, value, offset, min, max) {
  checkIntBI(value, min, max, buf, offset, 7)

  let lo = Number(value & BigInt(0xffffffff))
  buf[offset++] = lo
  lo = lo >> 8
  buf[offset++] = lo
  lo = lo >> 8
  buf[offset++] = lo
  lo = lo >> 8
  buf[offset++] = lo
  let hi = Number(value >> BigInt(32) & BigInt(0xffffffff))
  buf[offset++] = hi
  hi = hi >> 8
  buf[offset++] = hi
  hi = hi >> 8
  buf[offset++] = hi
  hi = hi >> 8
  buf[offset++] = hi
  return offset
}

function wrtBigUInt64BE (buf, value, offset, min, max) {
  checkIntBI(value, min, max, buf, offset, 7)

  let lo = Number(value & BigInt(0xffffffff))
  buf[offset + 7] = lo
  lo = lo >> 8
  buf[offset + 6] = lo
  lo = lo >> 8
  buf[offset + 5] = lo
  lo = lo >> 8
  buf[offset + 4] = lo
  let hi = Number(value >> BigInt(32) & BigInt(0xffffffff))
  buf[offset + 3] = hi
  hi = hi >> 8
  buf[offset + 2] = hi
  hi = hi >> 8
  buf[offset + 1] = hi
  hi = hi >> 8
  buf[offset] = hi
  return offset + 8
}

Buffer.prototype.writeBigUInt64LE = defineBigIntMethod(function writeBigUInt64LE (value, offset = 0) {
  return wrtBigUInt64LE(this, value, offset, BigInt(0), BigInt('0xffffffffffffffff'))
})

Buffer.prototype.writeBigUInt64BE = defineBigIntMethod(function writeBigUInt64BE (value, offset = 0) {
  return wrtBigUInt64BE(this, value, offset, BigInt(0), BigInt('0xffffffffffffffff'))
})

Buffer.prototype.writeIntLE = function writeIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    const limit = Math.pow(2, (8 * byteLength) - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  let i = 0
  let mul = 1
  let sub = 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
      sub = 1
    }
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeIntBE = function writeIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    const limit = Math.pow(2, (8 * byteLength) - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  let i = byteLength - 1
  let mul = 1
  let sub = 0
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
      sub = 1
    }
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeInt8 = function writeInt8 (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -0x80)
  if (value < 0) value = 0xff + value + 1
  this[offset] = (value & 0xff)
  return offset + 1
}

Buffer.prototype.writeInt16LE = function writeInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  this[offset] = (value & 0xff)
  this[offset + 1] = (value >>> 8)
  return offset + 2
}

Buffer.prototype.writeInt16BE = function writeInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  this[offset] = (value >>> 8)
  this[offset + 1] = (value & 0xff)
  return offset + 2
}

Buffer.prototype.writeInt32LE = function writeInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  this[offset] = (value & 0xff)
  this[offset + 1] = (value >>> 8)
  this[offset + 2] = (value >>> 16)
  this[offset + 3] = (value >>> 24)
  return offset + 4
}

Buffer.prototype.writeInt32BE = function writeInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  if (value < 0) value = 0xffffffff + value + 1
  this[offset] = (value >>> 24)
  this[offset + 1] = (value >>> 16)
  this[offset + 2] = (value >>> 8)
  this[offset + 3] = (value & 0xff)
  return offset + 4
}

Buffer.prototype.writeBigInt64LE = defineBigIntMethod(function writeBigInt64LE (value, offset = 0) {
  return wrtBigUInt64LE(this, value, offset, -BigInt('0x8000000000000000'), BigInt('0x7fffffffffffffff'))
})

Buffer.prototype.writeBigInt64BE = defineBigIntMethod(function writeBigInt64BE (value, offset = 0) {
  return wrtBigUInt64BE(this, value, offset, -BigInt('0x8000000000000000'), BigInt('0x7fffffffffffffff'))
})

function checkIEEE754 (buf, value, offset, ext, max, min) {
  if (offset + ext > buf.length) throw new RangeError('Index out of range')
  if (offset < 0) throw new RangeError('Index out of range')
}

function writeFloat (buf, value, offset, littleEndian, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 4, 3.4028234663852886e+38, -3.4028234663852886e+38)
  }
  ieee754.write(buf, value, offset, littleEndian, 23, 4)
  return offset + 4
}

Buffer.prototype.writeFloatLE = function writeFloatLE (value, offset, noAssert) {
  return writeFloat(this, value, offset, true, noAssert)
}

Buffer.prototype.writeFloatBE = function writeFloatBE (value, offset, noAssert) {
  return writeFloat(this, value, offset, false, noAssert)
}

function writeDouble (buf, value, offset, littleEndian, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 8, 1.7976931348623157E+308, -1.7976931348623157E+308)
  }
  ieee754.write(buf, value, offset, littleEndian, 52, 8)
  return offset + 8
}

Buffer.prototype.writeDoubleLE = function writeDoubleLE (value, offset, noAssert) {
  return writeDouble(this, value, offset, true, noAssert)
}

Buffer.prototype.writeDoubleBE = function writeDoubleBE (value, offset, noAssert) {
  return writeDouble(this, value, offset, false, noAssert)
}

// copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
Buffer.prototype.copy = function copy (target, targetStart, start, end) {
  if (!Buffer.isBuffer(target)) throw new TypeError('argument should be a Buffer')
  if (!start) start = 0
  if (!end && end !== 0) end = this.length
  if (targetStart >= target.length) targetStart = target.length
  if (!targetStart) targetStart = 0
  if (end > 0 && end < start) end = start

  // Copy 0 bytes; we're done
  if (end === start) return 0
  if (target.length === 0 || this.length === 0) return 0

  // Fatal error conditions
  if (targetStart < 0) {
    throw new RangeError('targetStart out of bounds')
  }
  if (start < 0 || start >= this.length) throw new RangeError('Index out of range')
  if (end < 0) throw new RangeError('sourceEnd out of bounds')

  // Are we oob?
  if (end > this.length) end = this.length
  if (target.length - targetStart < end - start) {
    end = target.length - targetStart + start
  }

  const len = end - start

  if (this === target && typeof Uint8Array.prototype.copyWithin === 'function') {
    // Use built-in when available, missing from IE11
    this.copyWithin(targetStart, start, end)
  } else {
    Uint8Array.prototype.set.call(
      target,
      this.subarray(start, end),
      targetStart
    )
  }

  return len
}

// Usage:
//    buffer.fill(number[, offset[, end]])
//    buffer.fill(buffer[, offset[, end]])
//    buffer.fill(string[, offset[, end]][, encoding])
Buffer.prototype.fill = function fill (val, start, end, encoding) {
  // Handle string cases:
  if (typeof val === 'string') {
    if (typeof start === 'string') {
      encoding = start
      start = 0
      end = this.length
    } else if (typeof end === 'string') {
      encoding = end
      end = this.length
    }
    if (encoding !== undefined && typeof encoding !== 'string') {
      throw new TypeError('encoding must be a string')
    }
    if (typeof encoding === 'string' && !Buffer.isEncoding(encoding)) {
      throw new TypeError('Unknown encoding: ' + encoding)
    }
    if (val.length === 1) {
      const code = val.charCodeAt(0)
      if ((encoding === 'utf8' && code < 128) ||
          encoding === 'latin1') {
        // Fast path: If `val` fits into a single byte, use that numeric value.
        val = code
      }
    }
  } else if (typeof val === 'number') {
    val = val & 255
  } else if (typeof val === 'boolean') {
    val = Number(val)
  }

  // Invalid ranges are not set to a default, so can range check early.
  if (start < 0 || this.length < start || this.length < end) {
    throw new RangeError('Out of range index')
  }

  if (end <= start) {
    return this
  }

  start = start >>> 0
  end = end === undefined ? this.length : end >>> 0

  if (!val) val = 0

  let i
  if (typeof val === 'number') {
    for (i = start; i < end; ++i) {
      this[i] = val
    }
  } else {
    const bytes = Buffer.isBuffer(val)
      ? val
      : Buffer.from(val, encoding)
    const len = bytes.length
    if (len === 0) {
      throw new TypeError('The value "' + val +
        '" is invalid for argument "value"')
    }
    for (i = 0; i < end - start; ++i) {
      this[i + start] = bytes[i % len]
    }
  }

  return this
}

// CUSTOM ERRORS
// =============

// Simplified versions from Node, changed for Buffer-only usage
const errors = {}
function E (sym, getMessage, Base) {
  errors[sym] = class NodeError extends Base {
    constructor () {
      super()

      Object.defineProperty(this, 'message', {
        value: getMessage.apply(this, arguments),
        writable: true,
        configurable: true
      })

      // Add the error code to the name to include it in the stack trace.
      this.name = `${this.name} [${sym}]`
      // Access the stack to generate the error message including the error code
      // from the name.
      this.stack // eslint-disable-line no-unused-expressions
      // Reset the name to the actual name.
      delete this.name
    }

    get code () {
      return sym
    }

    set code (value) {
      Object.defineProperty(this, 'code', {
        configurable: true,
        enumerable: true,
        value,
        writable: true
      })
    }

    toString () {
      return `${this.name} [${sym}]: ${this.message}`
    }
  }
}

E('ERR_BUFFER_OUT_OF_BOUNDS',
  function (name) {
    if (name) {
      return `${name} is outside of buffer bounds`
    }

    return 'Attempt to access memory outside buffer bounds'
  }, RangeError)
E('ERR_INVALID_ARG_TYPE',
  function (name, actual) {
    return `The "${name}" argument must be of type number. Received type ${typeof actual}`
  }, TypeError)
E('ERR_OUT_OF_RANGE',
  function (str, range, input) {
    let msg = `The value of "${str}" is out of range.`
    let received = input
    if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) {
      received = addNumericalSeparator(String(input))
    } else if (typeof input === 'bigint') {
      received = String(input)
      if (input > BigInt(2) ** BigInt(32) || input < -(BigInt(2) ** BigInt(32))) {
        received = addNumericalSeparator(received)
      }
      received += 'n'
    }
    msg += ` It must be ${range}. Received ${received}`
    return msg
  }, RangeError)

function addNumericalSeparator (val) {
  let res = ''
  let i = val.length
  const start = val[0] === '-' ? 1 : 0
  for (; i >= start + 4; i -= 3) {
    res = `_${val.slice(i - 3, i)}${res}`
  }
  return `${val.slice(0, i)}${res}`
}

// CHECK FUNCTIONS
// ===============

function checkBounds (buf, offset, byteLength) {
  validateNumber(offset, 'offset')
  if (buf[offset] === undefined || buf[offset + byteLength] === undefined) {
    boundsError(offset, buf.length - (byteLength + 1))
  }
}

function checkIntBI (value, min, max, buf, offset, byteLength) {
  if (value > max || value < min) {
    const n = typeof min === 'bigint' ? 'n' : ''
    let range
    if (byteLength > 3) {
      if (min === 0 || min === BigInt(0)) {
        range = `>= 0${n} and < 2${n} ** ${(byteLength + 1) * 8}${n}`
      } else {
        range = `>= -(2${n} ** ${(byteLength + 1) * 8 - 1}${n}) and < 2 ** ` +
                `${(byteLength + 1) * 8 - 1}${n}`
      }
    } else {
      range = `>= ${min}${n} and <= ${max}${n}`
    }
    throw new errors.ERR_OUT_OF_RANGE('value', range, value)
  }
  checkBounds(buf, offset, byteLength)
}

function validateNumber (value, name) {
  if (typeof value !== 'number') {
    throw new errors.ERR_INVALID_ARG_TYPE(name, 'number', value)
  }
}

function boundsError (value, length, type) {
  if (Math.floor(value) !== value) {
    validateNumber(value, type)
    throw new errors.ERR_OUT_OF_RANGE(type || 'offset', 'an integer', value)
  }

  if (length < 0) {
    throw new errors.ERR_BUFFER_OUT_OF_BOUNDS()
  }

  throw new errors.ERR_OUT_OF_RANGE(type || 'offset',
                                    `>= ${type ? 1 : 0} and <= ${length}`,
                                    value)
}

// HELPER FUNCTIONS
// ================

const INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g

function base64clean (str) {
  // Node takes equal signs as end of the Base64 encoding
  str = str.split('=')[0]
  // Node strips out invalid characters like \n and \t from the string, base64-js does not
  str = str.trim().replace(INVALID_BASE64_RE, '')
  // Node converts strings with length < 2 to ''
  if (str.length < 2) return ''
  // Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
  while (str.length % 4 !== 0) {
    str = str + '='
  }
  return str
}

function utf8ToBytes (string, units) {
  units = units || Infinity
  let codePoint
  const length = string.length
  let leadSurrogate = null
  const bytes = []

  for (let i = 0; i < length; ++i) {
    codePoint = string.charCodeAt(i)

    // is surrogate component
    if (codePoint > 0xD7FF && codePoint < 0xE000) {
      // last char was a lead
      if (!leadSurrogate) {
        // no lead yet
        if (codePoint > 0xDBFF) {
          // unexpected trail
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        } else if (i + 1 === length) {
          // unpaired lead
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        }

        // valid lead
        leadSurrogate = codePoint

        continue
      }

      // 2 leads in a row
      if (codePoint < 0xDC00) {
        if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
        leadSurrogate = codePoint
        continue
      }

      // valid surrogate pair
      codePoint = (leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00) + 0x10000
    } else if (leadSurrogate) {
      // valid bmp char, but last char was a lead
      if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
    }

    leadSurrogate = null

    // encode utf8
    if (codePoint < 0x80) {
      if ((units -= 1) < 0) break
      bytes.push(codePoint)
    } else if (codePoint < 0x800) {
      if ((units -= 2) < 0) break
      bytes.push(
        codePoint >> 0x6 | 0xC0,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x10000) {
      if ((units -= 3) < 0) break
      bytes.push(
        codePoint >> 0xC | 0xE0,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x110000) {
      if ((units -= 4) < 0) break
      bytes.push(
        codePoint >> 0x12 | 0xF0,
        codePoint >> 0xC & 0x3F | 0x80,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else {
      throw new Error('Invalid code point')
    }
  }

  return bytes
}

function asciiToBytes (str) {
  const byteArray = []
  for (let i = 0; i < str.length; ++i) {
    // Node's code seems to be doing this and not & 0x7F..
    byteArray.push(str.charCodeAt(i) & 0xFF)
  }
  return byteArray
}

function utf16leToBytes (str, units) {
  let c, hi, lo
  const byteArray = []
  for (let i = 0; i < str.length; ++i) {
    if ((units -= 2) < 0) break

    c = str.charCodeAt(i)
    hi = c >> 8
    lo = c % 256
    byteArray.push(lo)
    byteArray.push(hi)
  }

  return byteArray
}

function base64ToBytes (str) {
  return base64.toByteArray(base64clean(str))
}

function blitBuffer (src, dst, offset, length) {
  let i
  for (i = 0; i < length; ++i) {
    if ((i + offset >= dst.length) || (i >= src.length)) break
    dst[i + offset] = src[i]
  }
  return i
}

// ArrayBuffer or Uint8Array objects from other contexts (i.e. iframes) do not pass
// the `instanceof` check but they should be treated as of that type.
// See: https://github.com/feross/buffer/issues/166
function isInstance (obj, type) {
  return obj instanceof type ||
    (obj != null && obj.constructor != null && obj.constructor.name != null &&
      obj.constructor.name === type.name)
}
function numberIsNaN (obj) {
  // For IE11 support
  return obj !== obj // eslint-disable-line no-self-compare
}

// Create lookup table for `toString('hex')`
// See: https://github.com/feross/buffer/issues/219
const hexSliceLookupTable = (function () {
  const alphabet = '0123456789abcdef'
  const table = new Array(256)
  for (let i = 0; i < 16; ++i) {
    const i16 = i * 16
    for (let j = 0; j < 16; ++j) {
      table[i16 + j] = alphabet[i] + alphabet[j]
    }
  }
  return table
})()

// Return not function with Error if BigInt not supported
function defineBigIntMethod (fn) {
  return typeof BigInt === 'undefined' ? BufferBigIntNotDefined : fn
}

function BufferBigIntNotDefined () {
  throw new Error('BigInt not supported')
}


/***/ }),

/***/ 251:
/***/ ((__unused_webpack_module, exports) => {

/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
exports.read = function (buffer, offset, isLE, mLen, nBytes) {
  var e, m
  var eLen = (nBytes * 8) - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var nBits = -7
  var i = isLE ? (nBytes - 1) : 0
  var d = isLE ? -1 : 1
  var s = buffer[offset + i]

  i += d

  e = s & ((1 << (-nBits)) - 1)
  s >>= (-nBits)
  nBits += eLen
  for (; nBits > 0; e = (e * 256) + buffer[offset + i], i += d, nBits -= 8) {}

  m = e & ((1 << (-nBits)) - 1)
  e >>= (-nBits)
  nBits += mLen
  for (; nBits > 0; m = (m * 256) + buffer[offset + i], i += d, nBits -= 8) {}

  if (e === 0) {
    e = 1 - eBias
  } else if (e === eMax) {
    return m ? NaN : ((s ? -1 : 1) * Infinity)
  } else {
    m = m + Math.pow(2, mLen)
    e = e - eBias
  }
  return (s ? -1 : 1) * m * Math.pow(2, e - mLen)
}

exports.write = function (buffer, value, offset, isLE, mLen, nBytes) {
  var e, m, c
  var eLen = (nBytes * 8) - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var rt = (mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0)
  var i = isLE ? 0 : (nBytes - 1)
  var d = isLE ? 1 : -1
  var s = value < 0 || (value === 0 && 1 / value < 0) ? 1 : 0

  value = Math.abs(value)

  if (isNaN(value) || value === Infinity) {
    m = isNaN(value) ? 1 : 0
    e = eMax
  } else {
    e = Math.floor(Math.log(value) / Math.LN2)
    if (value * (c = Math.pow(2, -e)) < 1) {
      e--
      c *= 2
    }
    if (e + eBias >= 1) {
      value += rt / c
    } else {
      value += rt * Math.pow(2, 1 - eBias)
    }
    if (value * c >= 2) {
      e++
      c /= 2
    }

    if (e + eBias >= eMax) {
      m = 0
      e = eMax
    } else if (e + eBias >= 1) {
      m = ((value * c) - 1) * Math.pow(2, mLen)
      e = e + eBias
    } else {
      m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen)
      e = 0
    }
  }

  for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) {}

  e = (e << mLen) | m
  eLen += mLen
  for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) {}

  buffer[offset + i - d] |= s * 128
}


/***/ }),

/***/ 60328:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// the whatwg-fetch polyfill installs the fetch() function
// on the global object (window or self)
//
// Return that as the export for use in Webpack, Browserify etc.
__webpack_require__(78624);
module.exports = self.fetch.bind(self);


/***/ }),

/***/ 78624:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DOMException: () => (/* binding */ DOMException),
/* harmony export */   Headers: () => (/* binding */ Headers),
/* harmony export */   Request: () => (/* binding */ Request),
/* harmony export */   Response: () => (/* binding */ Response),
/* harmony export */   fetch: () => (/* binding */ fetch)
/* harmony export */ });
/* eslint-disable no-prototype-builtins */
var g =
  (typeof globalThis !== 'undefined' && globalThis) ||
  (typeof self !== 'undefined' && self) ||
  // eslint-disable-next-line no-undef
  (typeof __webpack_require__.g !== 'undefined' && __webpack_require__.g) ||
  {}

var support = {
  searchParams: 'URLSearchParams' in g,
  iterable: 'Symbol' in g && 'iterator' in Symbol,
  blob:
    'FileReader' in g &&
    'Blob' in g &&
    (function() {
      try {
        new Blob()
        return true
      } catch (e) {
        return false
      }
    })(),
  formData: 'FormData' in g,
  arrayBuffer: 'ArrayBuffer' in g
}

function isDataView(obj) {
  return obj && DataView.prototype.isPrototypeOf(obj)
}

if (support.arrayBuffer) {
  var viewClasses = [
    '[object Int8Array]',
    '[object Uint8Array]',
    '[object Uint8ClampedArray]',
    '[object Int16Array]',
    '[object Uint16Array]',
    '[object Int32Array]',
    '[object Uint32Array]',
    '[object Float32Array]',
    '[object Float64Array]'
  ]

  var isArrayBufferView =
    ArrayBuffer.isView ||
    function(obj) {
      return obj && viewClasses.indexOf(Object.prototype.toString.call(obj)) > -1
    }
}

function normalizeName(name) {
  if (typeof name !== 'string') {
    name = String(name)
  }
  if (/[^a-z0-9\-#$%&'*+.^_`|~!]/i.test(name) || name === '') {
    throw new TypeError('Invalid character in header field name: "' + name + '"')
  }
  return name.toLowerCase()
}

function normalizeValue(value) {
  if (typeof value !== 'string') {
    value = String(value)
  }
  return value
}

// Build a destructive iterator for the value list
function iteratorFor(items) {
  var iterator = {
    next: function() {
      var value = items.shift()
      return {done: value === undefined, value: value}
    }
  }

  if (support.iterable) {
    iterator[Symbol.iterator] = function() {
      return iterator
    }
  }

  return iterator
}

function Headers(headers) {
  this.map = {}

  if (headers instanceof Headers) {
    headers.forEach(function(value, name) {
      this.append(name, value)
    }, this)
  } else if (Array.isArray(headers)) {
    headers.forEach(function(header) {
      if (header.length != 2) {
        throw new TypeError('Headers constructor: expected name/value pair to be length 2, found' + header.length)
      }
      this.append(header[0], header[1])
    }, this)
  } else if (headers) {
    Object.getOwnPropertyNames(headers).forEach(function(name) {
      this.append(name, headers[name])
    }, this)
  }
}

Headers.prototype.append = function(name, value) {
  name = normalizeName(name)
  value = normalizeValue(value)
  var oldValue = this.map[name]
  this.map[name] = oldValue ? oldValue + ', ' + value : value
}

Headers.prototype['delete'] = function(name) {
  delete this.map[normalizeName(name)]
}

Headers.prototype.get = function(name) {
  name = normalizeName(name)
  return this.has(name) ? this.map[name] : null
}

Headers.prototype.has = function(name) {
  return this.map.hasOwnProperty(normalizeName(name))
}

Headers.prototype.set = function(name, value) {
  this.map[normalizeName(name)] = normalizeValue(value)
}

Headers.prototype.forEach = function(callback, thisArg) {
  for (var name in this.map) {
    if (this.map.hasOwnProperty(name)) {
      callback.call(thisArg, this.map[name], name, this)
    }
  }
}

Headers.prototype.keys = function() {
  var items = []
  this.forEach(function(value, name) {
    items.push(name)
  })
  return iteratorFor(items)
}

Headers.prototype.values = function() {
  var items = []
  this.forEach(function(value) {
    items.push(value)
  })
  return iteratorFor(items)
}

Headers.prototype.entries = function() {
  var items = []
  this.forEach(function(value, name) {
    items.push([name, value])
  })
  return iteratorFor(items)
}

if (support.iterable) {
  Headers.prototype[Symbol.iterator] = Headers.prototype.entries
}

function consumed(body) {
  if (body._noBody) return
  if (body.bodyUsed) {
    return Promise.reject(new TypeError('Already read'))
  }
  body.bodyUsed = true
}

function fileReaderReady(reader) {
  return new Promise(function(resolve, reject) {
    reader.onload = function() {
      resolve(reader.result)
    }
    reader.onerror = function() {
      reject(reader.error)
    }
  })
}

function readBlobAsArrayBuffer(blob) {
  var reader = new FileReader()
  var promise = fileReaderReady(reader)
  reader.readAsArrayBuffer(blob)
  return promise
}

function readBlobAsText(blob) {
  var reader = new FileReader()
  var promise = fileReaderReady(reader)
  var match = /charset=([A-Za-z0-9_-]+)/.exec(blob.type)
  var encoding = match ? match[1] : 'utf-8'
  reader.readAsText(blob, encoding)
  return promise
}

function readArrayBufferAsText(buf) {
  var view = new Uint8Array(buf)
  var chars = new Array(view.length)

  for (var i = 0; i < view.length; i++) {
    chars[i] = String.fromCharCode(view[i])
  }
  return chars.join('')
}

function bufferClone(buf) {
  if (buf.slice) {
    return buf.slice(0)
  } else {
    var view = new Uint8Array(buf.byteLength)
    view.set(new Uint8Array(buf))
    return view.buffer
  }
}

function Body() {
  this.bodyUsed = false

  this._initBody = function(body) {
    /*
      fetch-mock wraps the Response object in an ES6 Proxy to
      provide useful test harness features such as flush. However, on
      ES5 browsers without fetch or Proxy support pollyfills must be used;
      the proxy-pollyfill is unable to proxy an attribute unless it exists
      on the object before the Proxy is created. This change ensures
      Response.bodyUsed exists on the instance, while maintaining the
      semantic of setting Request.bodyUsed in the constructor before
      _initBody is called.
    */
    // eslint-disable-next-line no-self-assign
    this.bodyUsed = this.bodyUsed
    this._bodyInit = body
    if (!body) {
      this._noBody = true;
      this._bodyText = ''
    } else if (typeof body === 'string') {
      this._bodyText = body
    } else if (support.blob && Blob.prototype.isPrototypeOf(body)) {
      this._bodyBlob = body
    } else if (support.formData && FormData.prototype.isPrototypeOf(body)) {
      this._bodyFormData = body
    } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
      this._bodyText = body.toString()
    } else if (support.arrayBuffer && support.blob && isDataView(body)) {
      this._bodyArrayBuffer = bufferClone(body.buffer)
      // IE 10-11 can't handle a DataView body.
      this._bodyInit = new Blob([this._bodyArrayBuffer])
    } else if (support.arrayBuffer && (ArrayBuffer.prototype.isPrototypeOf(body) || isArrayBufferView(body))) {
      this._bodyArrayBuffer = bufferClone(body)
    } else {
      this._bodyText = body = Object.prototype.toString.call(body)
    }

    if (!this.headers.get('content-type')) {
      if (typeof body === 'string') {
        this.headers.set('content-type', 'text/plain;charset=UTF-8')
      } else if (this._bodyBlob && this._bodyBlob.type) {
        this.headers.set('content-type', this._bodyBlob.type)
      } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
        this.headers.set('content-type', 'application/x-www-form-urlencoded;charset=UTF-8')
      }
    }
  }

  if (support.blob) {
    this.blob = function() {
      var rejected = consumed(this)
      if (rejected) {
        return rejected
      }

      if (this._bodyBlob) {
        return Promise.resolve(this._bodyBlob)
      } else if (this._bodyArrayBuffer) {
        return Promise.resolve(new Blob([this._bodyArrayBuffer]))
      } else if (this._bodyFormData) {
        throw new Error('could not read FormData body as blob')
      } else {
        return Promise.resolve(new Blob([this._bodyText]))
      }
    }
  }

  this.arrayBuffer = function() {
    if (this._bodyArrayBuffer) {
      var isConsumed = consumed(this)
      if (isConsumed) {
        return isConsumed
      } else if (ArrayBuffer.isView(this._bodyArrayBuffer)) {
        return Promise.resolve(
          this._bodyArrayBuffer.buffer.slice(
            this._bodyArrayBuffer.byteOffset,
            this._bodyArrayBuffer.byteOffset + this._bodyArrayBuffer.byteLength
          )
        )
      } else {
        return Promise.resolve(this._bodyArrayBuffer)
      }
    } else if (support.blob) {
      return this.blob().then(readBlobAsArrayBuffer)
    } else {
      throw new Error('could not read as ArrayBuffer')
    }
  }

  this.text = function() {
    var rejected = consumed(this)
    if (rejected) {
      return rejected
    }

    if (this._bodyBlob) {
      return readBlobAsText(this._bodyBlob)
    } else if (this._bodyArrayBuffer) {
      return Promise.resolve(readArrayBufferAsText(this._bodyArrayBuffer))
    } else if (this._bodyFormData) {
      throw new Error('could not read FormData body as text')
    } else {
      return Promise.resolve(this._bodyText)
    }
  }

  if (support.formData) {
    this.formData = function() {
      return this.text().then(decode)
    }
  }

  this.json = function() {
    return this.text().then(JSON.parse)
  }

  return this
}

// HTTP methods whose capitalization should be normalized
var methods = ['CONNECT', 'DELETE', 'GET', 'HEAD', 'OPTIONS', 'PATCH', 'POST', 'PUT', 'TRACE']

function normalizeMethod(method) {
  var upcased = method.toUpperCase()
  return methods.indexOf(upcased) > -1 ? upcased : method
}

function Request(input, options) {
  if (!(this instanceof Request)) {
    throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.')
  }

  options = options || {}
  var body = options.body

  if (input instanceof Request) {
    if (input.bodyUsed) {
      throw new TypeError('Already read')
    }
    this.url = input.url
    this.credentials = input.credentials
    if (!options.headers) {
      this.headers = new Headers(input.headers)
    }
    this.method = input.method
    this.mode = input.mode
    this.signal = input.signal
    if (!body && input._bodyInit != null) {
      body = input._bodyInit
      input.bodyUsed = true
    }
  } else {
    this.url = String(input)
  }

  this.credentials = options.credentials || this.credentials || 'same-origin'
  if (options.headers || !this.headers) {
    this.headers = new Headers(options.headers)
  }
  this.method = normalizeMethod(options.method || this.method || 'GET')
  this.mode = options.mode || this.mode || null
  this.signal = options.signal || this.signal || (function () {
    if ('AbortController' in g) {
      var ctrl = new AbortController();
      return ctrl.signal;
    }
  }());
  this.referrer = null

  if ((this.method === 'GET' || this.method === 'HEAD') && body) {
    throw new TypeError('Body not allowed for GET or HEAD requests')
  }
  this._initBody(body)

  if (this.method === 'GET' || this.method === 'HEAD') {
    if (options.cache === 'no-store' || options.cache === 'no-cache') {
      // Search for a '_' parameter in the query string
      var reParamSearch = /([?&])_=[^&]*/
      if (reParamSearch.test(this.url)) {
        // If it already exists then set the value with the current time
        this.url = this.url.replace(reParamSearch, '$1_=' + new Date().getTime())
      } else {
        // Otherwise add a new '_' parameter to the end with the current time
        var reQueryString = /\?/
        this.url += (reQueryString.test(this.url) ? '&' : '?') + '_=' + new Date().getTime()
      }
    }
  }
}

Request.prototype.clone = function() {
  return new Request(this, {body: this._bodyInit})
}

function decode(body) {
  var form = new FormData()
  body
    .trim()
    .split('&')
    .forEach(function(bytes) {
      if (bytes) {
        var split = bytes.split('=')
        var name = split.shift().replace(/\+/g, ' ')
        var value = split.join('=').replace(/\+/g, ' ')
        form.append(decodeURIComponent(name), decodeURIComponent(value))
      }
    })
  return form
}

function parseHeaders(rawHeaders) {
  var headers = new Headers()
  // Replace instances of \r\n and \n followed by at least one space or horizontal tab with a space
  // https://tools.ietf.org/html/rfc7230#section-3.2
  var preProcessedHeaders = rawHeaders.replace(/\r?\n[\t ]+/g, ' ')
  // Avoiding split via regex to work around a common IE11 bug with the core-js 3.6.0 regex polyfill
  // https://github.com/github/fetch/issues/748
  // https://github.com/zloirock/core-js/issues/751
  preProcessedHeaders
    .split('\r')
    .map(function(header) {
      return header.indexOf('\n') === 0 ? header.substr(1, header.length) : header
    })
    .forEach(function(line) {
      var parts = line.split(':')
      var key = parts.shift().trim()
      if (key) {
        var value = parts.join(':').trim()
        try {
          headers.append(key, value)
        } catch (error) {
          console.warn('Response ' + error.message)
        }
      }
    })
  return headers
}

Body.call(Request.prototype)

function Response(bodyInit, options) {
  if (!(this instanceof Response)) {
    throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.')
  }
  if (!options) {
    options = {}
  }

  this.type = 'default'
  this.status = options.status === undefined ? 200 : options.status
  if (this.status < 200 || this.status > 599) {
    throw new RangeError("Failed to construct 'Response': The status provided (0) is outside the range [200, 599].")
  }
  this.ok = this.status >= 200 && this.status < 300
  this.statusText = options.statusText === undefined ? '' : '' + options.statusText
  this.headers = new Headers(options.headers)
  this.url = options.url || ''
  this._initBody(bodyInit)
}

Body.call(Response.prototype)

Response.prototype.clone = function() {
  return new Response(this._bodyInit, {
    status: this.status,
    statusText: this.statusText,
    headers: new Headers(this.headers),
    url: this.url
  })
}

Response.error = function() {
  var response = new Response(null, {status: 200, statusText: ''})
  response.ok = false
  response.status = 0
  response.type = 'error'
  return response
}

var redirectStatuses = [301, 302, 303, 307, 308]

Response.redirect = function(url, status) {
  if (redirectStatuses.indexOf(status) === -1) {
    throw new RangeError('Invalid status code')
  }

  return new Response(null, {status: status, headers: {location: url}})
}

var DOMException = g.DOMException
try {
  new DOMException()
} catch (err) {
  DOMException = function(message, name) {
    this.message = message
    this.name = name
    var error = Error(message)
    this.stack = error.stack
  }
  DOMException.prototype = Object.create(Error.prototype)
  DOMException.prototype.constructor = DOMException
}

function fetch(input, init) {
  return new Promise(function(resolve, reject) {
    var request = new Request(input, init)

    if (request.signal && request.signal.aborted) {
      return reject(new DOMException('Aborted', 'AbortError'))
    }

    var xhr = new XMLHttpRequest()

    function abortXhr() {
      xhr.abort()
    }

    xhr.onload = function() {
      var options = {
        statusText: xhr.statusText,
        headers: parseHeaders(xhr.getAllResponseHeaders() || '')
      }
      // This check if specifically for when a user fetches a file locally from the file system
      // Only if the status is out of a normal range
      if (request.url.indexOf('file://') === 0 && (xhr.status < 200 || xhr.status > 599)) {
        options.status = 200;
      } else {
        options.status = xhr.status;
      }
      options.url = 'responseURL' in xhr ? xhr.responseURL : options.headers.get('X-Request-URL')
      var body = 'response' in xhr ? xhr.response : xhr.responseText
      setTimeout(function() {
        resolve(new Response(body, options))
      }, 0)
    }

    xhr.onerror = function() {
      setTimeout(function() {
        reject(new TypeError('Network request failed'))
      }, 0)
    }

    xhr.ontimeout = function() {
      setTimeout(function() {
        reject(new TypeError('Network request timed out'))
      }, 0)
    }

    xhr.onabort = function() {
      setTimeout(function() {
        reject(new DOMException('Aborted', 'AbortError'))
      }, 0)
    }

    function fixUrl(url) {
      try {
        return url === '' && g.location.href ? g.location.href : url
      } catch (e) {
        return url
      }
    }

    xhr.open(request.method, fixUrl(request.url), true)

    if (request.credentials === 'include') {
      xhr.withCredentials = true
    } else if (request.credentials === 'omit') {
      xhr.withCredentials = false
    }

    if ('responseType' in xhr) {
      if (support.blob) {
        xhr.responseType = 'blob'
      } else if (
        support.arrayBuffer
      ) {
        xhr.responseType = 'arraybuffer'
      }
    }

    if (init && typeof init.headers === 'object' && !(init.headers instanceof Headers || (g.Headers && init.headers instanceof g.Headers))) {
      var names = [];
      Object.getOwnPropertyNames(init.headers).forEach(function(name) {
        names.push(normalizeName(name))
        xhr.setRequestHeader(name, normalizeValue(init.headers[name]))
      })
      request.headers.forEach(function(value, name) {
        if (names.indexOf(name) === -1) {
          xhr.setRequestHeader(name, value)
        }
      })
    } else {
      request.headers.forEach(function(value, name) {
        xhr.setRequestHeader(name, value)
      })
    }

    if (request.signal) {
      request.signal.addEventListener('abort', abortXhr)

      xhr.onreadystatechange = function() {
        // DONE (success or failure)
        if (xhr.readyState === 4) {
          request.signal.removeEventListener('abort', abortXhr)
        }
      }
    }

    xhr.send(typeof request._bodyInit === 'undefined' ? null : request._bodyInit)
  })
}

fetch.polyfill = true

if (!g.fetch) {
  g.fetch = fetch
  g.Headers = Headers
  g.Request = Request
  g.Response = Response
}


/***/ }),

/***/ 66399:
/***/ ((module) => {

"use strict";
module.exports = import("https://unpkg.com/chromadb-default-embed@2.14.0");;

/***/ }),

/***/ 57025:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Ay: () => (/* binding */ groq_sdk)
});

// UNUSED EXPORTS: APIConnectionError, APIConnectionTimeoutError, APIError, APIUserAbortError, AuthenticationError, BadRequestError, ConflictError, Groq, GroqError, InternalServerError, NotFoundError, PermissionDeniedError, RateLimitError, UnprocessableEntityError, fileFromPath, toFile

;// CONCATENATED MODULE: ./node_modules/groq-sdk/version.mjs
const VERSION = '0.15.0'; // x-release-please-version
//# sourceMappingURL=version.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/_shims/registry.mjs
let auto = false;
let kind = undefined;
let registry_fetch = undefined;
let registry_Request = (/* unused pure expression or super */ null && (undefined));
let registry_Response = (/* unused pure expression or super */ null && (undefined));
let registry_Headers = (/* unused pure expression or super */ null && (undefined));
let registry_FormData = undefined;
let registry_Blob = (/* unused pure expression or super */ null && (undefined));
let registry_File = undefined;
let registry_ReadableStream = undefined;
let registry_getMultipartRequestOptions = undefined;
let getDefaultAgent = undefined;
let fileFromPath = undefined;
let isFsReadStream = undefined;
function setShims(shims, options = { auto: false }) {
    if (auto) {
        throw new Error(`you must \`import 'groq-sdk/shims/${shims.kind}'\` before importing anything else from groq-sdk`);
    }
    if (kind) {
        throw new Error(`can't \`import 'groq-sdk/shims/${shims.kind}'\` after \`import 'groq-sdk/shims/${kind}'\``);
    }
    auto = options.auto;
    kind = shims.kind;
    registry_fetch = shims.fetch;
    registry_Request = shims.Request;
    registry_Response = shims.Response;
    registry_Headers = shims.Headers;
    registry_FormData = shims.FormData;
    registry_Blob = shims.Blob;
    registry_File = shims.File;
    registry_ReadableStream = shims.ReadableStream;
    registry_getMultipartRequestOptions = shims.getMultipartRequestOptions;
    getDefaultAgent = shims.getDefaultAgent;
    fileFromPath = shims.fileFromPath;
    isFsReadStream = shims.isFsReadStream;
}
//# sourceMappingURL=registry.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/_shims/MultipartBody.mjs
/**
 * Disclaimer: modules in _shims aren't intended to be imported by SDK users.
 */
class MultipartBody {
    constructor(body) {
        this.body = body;
    }
    get [Symbol.toStringTag]() {
        return 'MultipartBody';
    }
}
//# sourceMappingURL=MultipartBody.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/_shims/web-runtime.mjs

function getRuntime({ manuallyImported } = {}) {
    const recommendation = manuallyImported ?
        `You may need to use polyfills`
        : `Add one of these imports before your first \`import … from 'groq-sdk'\`:
- \`import 'groq-sdk/shims/node'\` (if you're running on Node)
- \`import 'groq-sdk/shims/web'\` (otherwise)
`;
    let _fetch, _Request, _Response, _Headers;
    try {
        // @ts-ignore
        _fetch = fetch;
        // @ts-ignore
        _Request = Request;
        // @ts-ignore
        _Response = Response;
        // @ts-ignore
        _Headers = Headers;
    }
    catch (error) {
        throw new Error(`this environment is missing the following Web Fetch API type: ${error.message}. ${recommendation}`);
    }
    return {
        kind: 'web',
        fetch: _fetch,
        Request: _Request,
        Response: _Response,
        Headers: _Headers,
        FormData: 
        // @ts-ignore
        typeof FormData !== 'undefined' ? FormData : (class FormData {
            // @ts-ignore
            constructor() {
                throw new Error(`file uploads aren't supported in this environment yet as 'FormData' is undefined. ${recommendation}`);
            }
        }),
        Blob: typeof Blob !== 'undefined' ? Blob : (class Blob {
            constructor() {
                throw new Error(`file uploads aren't supported in this environment yet as 'Blob' is undefined. ${recommendation}`);
            }
        }),
        File: 
        // @ts-ignore
        typeof File !== 'undefined' ? File : (class File {
            // @ts-ignore
            constructor() {
                throw new Error(`file uploads aren't supported in this environment yet as 'File' is undefined. ${recommendation}`);
            }
        }),
        ReadableStream: 
        // @ts-ignore
        typeof ReadableStream !== 'undefined' ? ReadableStream : (class ReadableStream {
            // @ts-ignore
            constructor() {
                throw new Error(`streaming isn't supported in this environment yet as 'ReadableStream' is undefined. ${recommendation}`);
            }
        }),
        getMultipartRequestOptions: async (
        // @ts-ignore
        form, opts) => ({
            ...opts,
            body: new MultipartBody(form),
        }),
        getDefaultAgent: (url) => undefined,
        fileFromPath: () => {
            throw new Error('The `fileFromPath` function is only supported in Node. See the README for more details: https://www.github.com/groq/groq-typescript#file-uploads');
        },
        isFsReadStream: (value) => false,
    };
}
//# sourceMappingURL=web-runtime.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/_shims/index.mjs
/**
 * Disclaimer: modules in _shims aren't intended to be imported by SDK users.
 */


if (!kind) setShims(getRuntime(), { auto: true });


;// CONCATENATED MODULE: ./node_modules/groq-sdk/error.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class error_GroqError extends Error {
}
class APIError extends error_GroqError {
    constructor(status, error, message, headers) {
        super(`${APIError.makeMessage(status, error, message)}`);
        this.status = status;
        this.headers = headers;
        this.error = error;
    }
    static makeMessage(status, error, message) {
        const msg = error?.message ?
            typeof error.message === 'string' ?
                error.message
                : JSON.stringify(error.message)
            : error ? JSON.stringify(error)
                : message;
        if (status && msg) {
            return `${status} ${msg}`;
        }
        if (status) {
            return `${status} status code (no body)`;
        }
        if (msg) {
            return msg;
        }
        return '(no status code or body)';
    }
    static generate(status, errorResponse, message, headers) {
        if (!status || !headers) {
            return new APIConnectionError({ message, cause: castToError(errorResponse) });
        }
        const error = errorResponse;
        if (status === 400) {
            return new BadRequestError(status, error, message, headers);
        }
        if (status === 401) {
            return new AuthenticationError(status, error, message, headers);
        }
        if (status === 403) {
            return new PermissionDeniedError(status, error, message, headers);
        }
        if (status === 404) {
            return new NotFoundError(status, error, message, headers);
        }
        if (status === 409) {
            return new ConflictError(status, error, message, headers);
        }
        if (status === 422) {
            return new UnprocessableEntityError(status, error, message, headers);
        }
        if (status === 429) {
            return new RateLimitError(status, error, message, headers);
        }
        if (status >= 500) {
            return new InternalServerError(status, error, message, headers);
        }
        return new APIError(status, error, message, headers);
    }
}
class APIUserAbortError extends APIError {
    constructor({ message } = {}) {
        super(undefined, undefined, message || 'Request was aborted.', undefined);
    }
}
class APIConnectionError extends APIError {
    constructor({ message, cause }) {
        super(undefined, undefined, message || 'Connection error.', undefined);
        // in some environments the 'cause' property is already declared
        // @ts-ignore
        if (cause)
            this.cause = cause;
    }
}
class APIConnectionTimeoutError extends APIConnectionError {
    constructor({ message } = {}) {
        super({ message: message ?? 'Request timed out.' });
    }
}
class BadRequestError extends APIError {
}
class AuthenticationError extends APIError {
}
class PermissionDeniedError extends APIError {
}
class NotFoundError extends APIError {
}
class ConflictError extends APIError {
}
class UnprocessableEntityError extends APIError {
}
class RateLimitError extends APIError {
}
class InternalServerError extends APIError {
}
//# sourceMappingURL=error.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/lib/streaming.mjs
/* provided dependency */ var Buffer = __webpack_require__(48287)["Buffer"];



class Stream {
    constructor(iterator, controller) {
        this.iterator = iterator;
        this.controller = controller;
    }
    static fromSSEResponse(response, controller) {
        let consumed = false;
        const decoder = new SSEDecoder();
        async function* iterMessages() {
            if (!response.body) {
                controller.abort();
                throw new error_GroqError(`Attempted to iterate over a response with no body`);
            }
            const lineDecoder = new LineDecoder();
            const iter = readableStreamAsyncIterable(response.body);
            for await (const chunk of iter) {
                for (const line of lineDecoder.decode(chunk)) {
                    const sse = decoder.decode(line);
                    if (sse)
                        yield sse;
                }
            }
            for (const line of lineDecoder.flush()) {
                const sse = decoder.decode(line);
                if (sse)
                    yield sse;
            }
        }
        async function* iterator() {
            if (consumed) {
                throw new Error('Cannot iterate over a consumed stream, use `.tee()` to split the stream.');
            }
            consumed = true;
            let done = false;
            try {
                for await (const sse of iterMessages()) {
                    if (done)
                        continue;
                    if (sse.data.startsWith('[DONE]')) {
                        done = true;
                        continue;
                    }
                    if (sse.event === null || sse.event === 'error') {
                        let data;
                        try {
                            data = JSON.parse(sse.data);
                        }
                        catch (e) {
                            console.error(`Could not parse message into JSON:`, sse.data);
                            console.error(`From chunk:`, sse.raw);
                            throw e;
                        }
                        if (data && data.error) {
                            throw new APIError(data.error.status_code, data.error, data.error.message, undefined);
                        }
                        yield data;
                    }
                }
                done = true;
            }
            catch (e) {
                // If the user calls `stream.controller.abort()`, we should exit without throwing.
                if (e instanceof Error && e.name === 'AbortError')
                    return;
                throw e;
            }
            finally {
                // If the user `break`s, abort the ongoing request.
                if (!done)
                    controller.abort();
            }
        }
        return new Stream(iterator, controller);
    }
    /**
     * Generates a Stream from a newline-separated ReadableStream
     * where each item is a JSON value.
     */
    static fromReadableStream(readableStream, controller) {
        let consumed = false;
        async function* iterLines() {
            const lineDecoder = new LineDecoder();
            const iter = readableStreamAsyncIterable(readableStream);
            for await (const chunk of iter) {
                for (const line of lineDecoder.decode(chunk)) {
                    yield line;
                }
            }
            for (const line of lineDecoder.flush()) {
                yield line;
            }
        }
        async function* iterator() {
            if (consumed) {
                throw new Error('Cannot iterate over a consumed stream, use `.tee()` to split the stream.');
            }
            consumed = true;
            let done = false;
            try {
                for await (const line of iterLines()) {
                    if (done)
                        continue;
                    if (line)
                        yield JSON.parse(line);
                }
                done = true;
            }
            catch (e) {
                // If the user calls `stream.controller.abort()`, we should exit without throwing.
                if (e instanceof Error && e.name === 'AbortError')
                    return;
                throw e;
            }
            finally {
                // If the user `break`s, abort the ongoing request.
                if (!done)
                    controller.abort();
            }
        }
        return new Stream(iterator, controller);
    }
    [Symbol.asyncIterator]() {
        return this.iterator();
    }
    /**
     * Splits the stream into two streams which can be
     * independently read from at different speeds.
     */
    tee() {
        const left = [];
        const right = [];
        const iterator = this.iterator();
        const teeIterator = (queue) => {
            return {
                next: () => {
                    if (queue.length === 0) {
                        const result = iterator.next();
                        left.push(result);
                        right.push(result);
                    }
                    return queue.shift();
                },
            };
        };
        return [
            new Stream(() => teeIterator(left), this.controller),
            new Stream(() => teeIterator(right), this.controller),
        ];
    }
    /**
     * Converts this stream to a newline-separated ReadableStream of
     * JSON stringified values in the stream
     * which can be turned back into a Stream with `Stream.fromReadableStream()`.
     */
    toReadableStream() {
        const self = this;
        let iter;
        const encoder = new TextEncoder();
        return new registry_ReadableStream({
            async start() {
                iter = self[Symbol.asyncIterator]();
            },
            async pull(ctrl) {
                try {
                    const { value, done } = await iter.next();
                    if (done)
                        return ctrl.close();
                    const bytes = encoder.encode(JSON.stringify(value) + '\n');
                    ctrl.enqueue(bytes);
                }
                catch (err) {
                    ctrl.error(err);
                }
            },
            async cancel() {
                await iter.return?.();
            },
        });
    }
}
class SSEDecoder {
    constructor() {
        this.event = null;
        this.data = [];
        this.chunks = [];
    }
    decode(line) {
        if (line.endsWith('\r')) {
            line = line.substring(0, line.length - 1);
        }
        if (!line) {
            // empty line and we didn't previously encounter any messages
            if (!this.event && !this.data.length)
                return null;
            const sse = {
                event: this.event,
                data: this.data.join('\n'),
                raw: this.chunks,
            };
            this.event = null;
            this.data = [];
            this.chunks = [];
            return sse;
        }
        this.chunks.push(line);
        if (line.startsWith(':')) {
            return null;
        }
        let [fieldname, _, value] = partition(line, ':');
        if (value.startsWith(' ')) {
            value = value.substring(1);
        }
        if (fieldname === 'event') {
            this.event = value;
        }
        else if (fieldname === 'data') {
            this.data.push(value);
        }
        return null;
    }
}
/**
 * A re-implementation of httpx's `LineDecoder` in Python that handles incrementally
 * reading lines from text.
 *
 * https://github.com/encode/httpx/blob/920333ea98118e9cf617f246905d7b202510941c/httpx/_decoders.py#L258
 */
class LineDecoder {
    constructor() {
        this.buffer = [];
        this.trailingCR = false;
    }
    decode(chunk) {
        let text = this.decodeText(chunk);
        if (this.trailingCR) {
            text = '\r' + text;
            this.trailingCR = false;
        }
        if (text.endsWith('\r')) {
            this.trailingCR = true;
            text = text.slice(0, -1);
        }
        if (!text) {
            return [];
        }
        const trailingNewline = LineDecoder.NEWLINE_CHARS.has(text[text.length - 1] || '');
        let lines = text.split(LineDecoder.NEWLINE_REGEXP);
        if (lines.length === 1 && !trailingNewline) {
            this.buffer.push(lines[0]);
            return [];
        }
        if (this.buffer.length > 0) {
            lines = [this.buffer.join('') + lines[0], ...lines.slice(1)];
            this.buffer = [];
        }
        if (!trailingNewline) {
            this.buffer = [lines.pop() || ''];
        }
        return lines;
    }
    decodeText(bytes) {
        if (bytes == null)
            return '';
        if (typeof bytes === 'string')
            return bytes;
        // Node:
        if (typeof Buffer !== 'undefined') {
            if (bytes instanceof Buffer) {
                return bytes.toString();
            }
            if (bytes instanceof Uint8Array) {
                return Buffer.from(bytes).toString();
            }
            throw new error_GroqError(`Unexpected: received non-Uint8Array (${bytes.constructor.name}) stream chunk in an environment with a global "Buffer" defined, which this library assumes to be Node. Please report this error.`);
        }
        // Browser
        if (typeof TextDecoder !== 'undefined') {
            if (bytes instanceof Uint8Array || bytes instanceof ArrayBuffer) {
                this.textDecoder ?? (this.textDecoder = new TextDecoder('utf8'));
                return this.textDecoder.decode(bytes);
            }
            throw new error_GroqError(`Unexpected: received non-Uint8Array/ArrayBuffer (${bytes.constructor.name}) in a web platform. Please report this error.`);
        }
        throw new error_GroqError(`Unexpected: neither Buffer nor TextDecoder are available as globals. Please report this error.`);
    }
    flush() {
        if (!this.buffer.length && !this.trailingCR) {
            return [];
        }
        const lines = [this.buffer.join('')];
        this.buffer = [];
        this.trailingCR = false;
        return lines;
    }
}
// prettier-ignore
LineDecoder.NEWLINE_CHARS = new Set(['\n', '\r', '\x0b', '\x0c', '\x1c', '\x1d', '\x1e', '\x85', '\u2028', '\u2029']);
LineDecoder.NEWLINE_REGEXP = /\r\n|[\n\r\x0b\x0c\x1c\x1d\x1e\x85\u2028\u2029]/g;
function partition(str, delimiter) {
    const index = str.indexOf(delimiter);
    if (index !== -1) {
        return [str.substring(0, index), delimiter, str.substring(index + delimiter.length)];
    }
    return [str, '', ''];
}
/**
 * Most browsers don't yet have async iterable support for ReadableStream,
 * and Node has a very different way of reading bytes from its "ReadableStream".
 *
 * This polyfill was pulled from https://github.com/MattiasBuelens/web-streams-polyfill/pull/122#issuecomment-1627354490
 */
function readableStreamAsyncIterable(stream) {
    if (stream[Symbol.asyncIterator])
        return stream;
    const reader = stream.getReader();
    return {
        async next() {
            try {
                const result = await reader.read();
                if (result?.done)
                    reader.releaseLock(); // release lock when stream becomes closed
                return result;
            }
            catch (e) {
                reader.releaseLock(); // release lock when stream becomes errored
                throw e;
            }
        },
        async return() {
            const cancelPromise = reader.cancel();
            reader.releaseLock();
            await cancelPromise;
            return { done: true, value: undefined };
        },
        [Symbol.asyncIterator]() {
            return this;
        },
    };
}
//# sourceMappingURL=streaming.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/uploads.mjs
/* provided dependency */ var uploads_Buffer = __webpack_require__(48287)["Buffer"];


const isResponseLike = (value) => value != null &&
    typeof value === 'object' &&
    typeof value.url === 'string' &&
    typeof value.blob === 'function';
const isFileLike = (value) => value != null &&
    typeof value === 'object' &&
    typeof value.name === 'string' &&
    typeof value.lastModified === 'number' &&
    isBlobLike(value);
/**
 * The BlobLike type omits arrayBuffer() because @types/node-fetch@^2.6.4 lacks it; but this check
 * adds the arrayBuffer() method type because it is available and used at runtime
 */
const isBlobLike = (value) => value != null &&
    typeof value === 'object' &&
    typeof value.size === 'number' &&
    typeof value.type === 'string' &&
    typeof value.text === 'function' &&
    typeof value.slice === 'function' &&
    typeof value.arrayBuffer === 'function';
const isUploadable = (value) => {
    return isFileLike(value) || isResponseLike(value) || isFsReadStream(value);
};
/**
 * Helper for creating a {@link File} to pass to an SDK upload method from a variety of different data formats
 * @param value the raw content of the file.  Can be an {@link Uploadable}, {@link BlobLikePart}, or {@link AsyncIterable} of {@link BlobLikePart}s
 * @param {string=} name the name of the file. If omitted, toFile will try to determine a file name from bits if possible
 * @param {Object=} options additional properties
 * @param {string=} options.type the MIME type of the content
 * @param {number=} options.lastModified the last modified timestamp
 * @returns a {@link File} with the given properties
 */
async function toFile(value, name, options) {
    // If it's a promise, resolve it.
    value = await value;
    // If we've been given a `File` we don't need to do anything
    if (isFileLike(value)) {
        return value;
    }
    if (isResponseLike(value)) {
        const blob = await value.blob();
        name || (name = new URL(value.url).pathname.split(/[\\/]/).pop() ?? 'unknown_file');
        // we need to convert the `Blob` into an array buffer because the `Blob` class
        // that `node-fetch` defines is incompatible with the web standard which results
        // in `new File` interpreting it as a string instead of binary data.
        const data = isBlobLike(blob) ? [(await blob.arrayBuffer())] : [blob];
        return new registry_File(data, name, options);
    }
    const bits = await getBytes(value);
    name || (name = getName(value) ?? 'unknown_file');
    if (!options?.type) {
        const type = bits[0]?.type;
        if (typeof type === 'string') {
            options = { ...options, type };
        }
    }
    return new registry_File(bits, name, options);
}
async function getBytes(value) {
    let parts = [];
    if (typeof value === 'string' ||
        ArrayBuffer.isView(value) || // includes Uint8Array, Buffer, etc.
        value instanceof ArrayBuffer) {
        parts.push(value);
    }
    else if (isBlobLike(value)) {
        parts.push(await value.arrayBuffer());
    }
    else if (isAsyncIterableIterator(value) // includes Readable, ReadableStream, etc.
    ) {
        for await (const chunk of value) {
            parts.push(chunk); // TODO, consider validating?
        }
    }
    else {
        throw new Error(`Unexpected data type: ${typeof value}; constructor: ${value?.constructor
            ?.name}; props: ${propsForError(value)}`);
    }
    return parts;
}
function propsForError(value) {
    const props = Object.getOwnPropertyNames(value);
    return `[${props.map((p) => `"${p}"`).join(', ')}]`;
}
function getName(value) {
    return (getStringFromMaybeBuffer(value.name) ||
        getStringFromMaybeBuffer(value.filename) ||
        // For fs.ReadStream
        getStringFromMaybeBuffer(value.path)?.split(/[\\/]/).pop());
}
const getStringFromMaybeBuffer = (x) => {
    if (typeof x === 'string')
        return x;
    if (typeof uploads_Buffer !== 'undefined' && x instanceof uploads_Buffer)
        return String(x);
    return undefined;
};
const isAsyncIterableIterator = (value) => value != null && typeof value === 'object' && typeof value[Symbol.asyncIterator] === 'function';
const isMultipartBody = (body) => body && typeof body === 'object' && body.body && body[Symbol.toStringTag] === 'MultipartBody';
/**
 * Returns a multipart/form-data request if any part of the given request body contains a File / Blob value.
 * Otherwise returns the request as is.
 */
const maybeMultipartFormRequestOptions = async (opts) => {
    if (!hasUploadableValue(opts.body))
        return opts;
    const form = await createForm(opts.body);
    return getMultipartRequestOptions(form, opts);
};
const multipartFormRequestOptions = async (opts) => {
    const form = await createForm(opts.body);
    return registry_getMultipartRequestOptions(form, opts);
};
const createForm = async (body) => {
    const form = new registry_FormData();
    await Promise.all(Object.entries(body || {}).map(([key, value]) => addFormValue(form, key, value)));
    return form;
};
const hasUploadableValue = (value) => {
    if (isUploadable(value))
        return true;
    if (Array.isArray(value))
        return value.some(hasUploadableValue);
    if (value && typeof value === 'object') {
        for (const k in value) {
            if (hasUploadableValue(value[k]))
                return true;
        }
    }
    return false;
};
const addFormValue = async (form, key, value) => {
    if (value === undefined)
        return;
    if (value == null) {
        throw new TypeError(`Received null for "${key}"; to pass null in FormData, you must use the string 'null'`);
    }
    // TODO: make nested formats configurable
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
        form.append(key, String(value));
    }
    else if (isUploadable(value)) {
        const file = await toFile(value);
        form.append(key, file);
    }
    else if (Array.isArray(value)) {
        await Promise.all(value.map((entry) => addFormValue(form, key + '[]', entry)));
    }
    else if (typeof value === 'object') {
        await Promise.all(Object.entries(value).map(([name, prop]) => addFormValue(form, `${key}[${name}]`, prop)));
    }
    else {
        throw new TypeError(`Invalid value given to form, expected a string, number, boolean, object, Array, File or Blob but got ${value} instead`);
    }
};
//# sourceMappingURL=uploads.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/core.mjs
/* provided dependency */ var core_Buffer = __webpack_require__(48287)["Buffer"];
var __classPrivateFieldSet = (undefined && undefined.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var __classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _AbstractPage_client;






async function defaultParseResponse(props) {
    const { response } = props;
    if (props.options.stream) {
        debug('response', response.status, response.url, response.headers, response.body);
        // Note: there is an invariant here that isn't represented in the type system
        // that if you set `stream: true` the response type must also be `Stream<T>`
        if (props.options.__streamClass) {
            return props.options.__streamClass.fromSSEResponse(response, props.controller);
        }
        return Stream.fromSSEResponse(response, props.controller);
    }
    // fetch refuses to read the body when the status code is 204.
    if (response.status === 204) {
        return null;
    }
    if (props.options.__binaryResponse) {
        return response;
    }
    const contentType = response.headers.get('content-type');
    const isJSON = contentType?.includes('application/json') || contentType?.includes('application/vnd.api+json');
    if (isJSON) {
        const json = await response.json();
        debug('response', response.status, response.url, response.headers, json);
        return json;
    }
    const text = await response.text();
    debug('response', response.status, response.url, response.headers, text);
    // TODO handle blob, arraybuffer, other content types, etc.
    return text;
}
/**
 * A subclass of `Promise` providing additional helper methods
 * for interacting with the SDK.
 */
class APIPromise extends Promise {
    constructor(responsePromise, parseResponse = defaultParseResponse) {
        super((resolve) => {
            // this is maybe a bit weird but this has to be a no-op to not implicitly
            // parse the response body; instead .then, .catch, .finally are overridden
            // to parse the response
            resolve(null);
        });
        this.responsePromise = responsePromise;
        this.parseResponse = parseResponse;
    }
    _thenUnwrap(transform) {
        return new APIPromise(this.responsePromise, async (props) => transform(await this.parseResponse(props), props));
    }
    /**
     * Gets the raw `Response` instance instead of parsing the response
     * data.
     *
     * If you want to parse the response body but still get the `Response`
     * instance, you can use {@link withResponse()}.
     *
     * 👋 Getting the wrong TypeScript type for `Response`?
     * Try setting `"moduleResolution": "NodeNext"` if you can,
     * or add one of these imports before your first `import … from 'groq-sdk'`:
     * - `import 'groq-sdk/shims/node'` (if you're running on Node)
     * - `import 'groq-sdk/shims/web'` (otherwise)
     */
    asResponse() {
        return this.responsePromise.then((p) => p.response);
    }
    /**
     * Gets the parsed response data and the raw `Response` instance.
     *
     * If you just want to get the raw `Response` instance without parsing it,
     * you can use {@link asResponse()}.
     *
     *
     * 👋 Getting the wrong TypeScript type for `Response`?
     * Try setting `"moduleResolution": "NodeNext"` if you can,
     * or add one of these imports before your first `import … from 'groq-sdk'`:
     * - `import 'groq-sdk/shims/node'` (if you're running on Node)
     * - `import 'groq-sdk/shims/web'` (otherwise)
     */
    async withResponse() {
        const [data, response] = await Promise.all([this.parse(), this.asResponse()]);
        return { data, response };
    }
    parse() {
        if (!this.parsedPromise) {
            this.parsedPromise = this.responsePromise.then(this.parseResponse);
        }
        return this.parsedPromise;
    }
    then(onfulfilled, onrejected) {
        return this.parse().then(onfulfilled, onrejected);
    }
    catch(onrejected) {
        return this.parse().catch(onrejected);
    }
    finally(onfinally) {
        return this.parse().finally(onfinally);
    }
}
class APIClient {
    constructor({ baseURL, maxRetries = 2, timeout = 60000, // 1 minute
    httpAgent, fetch: overriddenFetch, }) {
        this.baseURL = baseURL;
        this.maxRetries = validatePositiveInteger('maxRetries', maxRetries);
        this.timeout = validatePositiveInteger('timeout', timeout);
        this.httpAgent = httpAgent;
        this.fetch = overriddenFetch ?? registry_fetch;
    }
    authHeaders(opts) {
        return {};
    }
    /**
     * Override this to add your own default headers, for example:
     *
     *  {
     *    ...super.defaultHeaders(),
     *    Authorization: 'Bearer 123',
     *  }
     */
    defaultHeaders(opts) {
        return {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            'User-Agent': this.getUserAgent(),
            ...getPlatformHeaders(),
            ...this.authHeaders(opts),
        };
    }
    /**
     * Override this to add your own headers validation:
     */
    validateHeaders(headers, customHeaders) { }
    defaultIdempotencyKey() {
        return `stainless-node-retry-${uuid4()}`;
    }
    get(path, opts) {
        return this.methodRequest('get', path, opts);
    }
    post(path, opts) {
        return this.methodRequest('post', path, opts);
    }
    patch(path, opts) {
        return this.methodRequest('patch', path, opts);
    }
    put(path, opts) {
        return this.methodRequest('put', path, opts);
    }
    delete(path, opts) {
        return this.methodRequest('delete', path, opts);
    }
    methodRequest(method, path, opts) {
        return this.request(Promise.resolve(opts).then(async (opts) => {
            const body = opts && isBlobLike(opts?.body) ? new DataView(await opts.body.arrayBuffer())
                : opts?.body instanceof DataView ? opts.body
                    : opts?.body instanceof ArrayBuffer ? new DataView(opts.body)
                        : opts && ArrayBuffer.isView(opts?.body) ? new DataView(opts.body.buffer)
                            : opts?.body;
            return { method, path, ...opts, body };
        }));
    }
    getAPIList(path, Page, opts) {
        return this.requestAPIList(Page, { method: 'get', path, ...opts });
    }
    calculateContentLength(body) {
        if (typeof body === 'string') {
            if (typeof core_Buffer !== 'undefined') {
                return core_Buffer.byteLength(body, 'utf8').toString();
            }
            if (typeof TextEncoder !== 'undefined') {
                const encoder = new TextEncoder();
                const encoded = encoder.encode(body);
                return encoded.length.toString();
            }
        }
        else if (ArrayBuffer.isView(body)) {
            return body.byteLength.toString();
        }
        return null;
    }
    buildRequest(options, { retryCount = 0 } = {}) {
        const { method, path, query, headers: headers = {} } = options;
        const body = ArrayBuffer.isView(options.body) || (options.__binaryRequest && typeof options.body === 'string') ?
            options.body
            : isMultipartBody(options.body) ? options.body.body
                : options.body ? JSON.stringify(options.body, null, 2)
                    : null;
        const contentLength = this.calculateContentLength(body);
        const url = this.buildURL(path, query);
        if ('timeout' in options)
            validatePositiveInteger('timeout', options.timeout);
        const timeout = options.timeout ?? this.timeout;
        const httpAgent = options.httpAgent ?? this.httpAgent ?? getDefaultAgent(url);
        const minAgentTimeout = timeout + 1000;
        if (typeof httpAgent?.options?.timeout === 'number' &&
            minAgentTimeout > (httpAgent.options.timeout ?? 0)) {
            // Allow any given request to bump our agent active socket timeout.
            // This may seem strange, but leaking active sockets should be rare and not particularly problematic,
            // and without mutating agent we would need to create more of them.
            // This tradeoff optimizes for performance.
            httpAgent.options.timeout = minAgentTimeout;
        }
        if (this.idempotencyHeader && method !== 'get') {
            if (!options.idempotencyKey)
                options.idempotencyKey = this.defaultIdempotencyKey();
            headers[this.idempotencyHeader] = options.idempotencyKey;
        }
        const reqHeaders = this.buildHeaders({ options, headers, contentLength, retryCount });
        const req = {
            method,
            ...(body && { body: body }),
            headers: reqHeaders,
            ...(httpAgent && { agent: httpAgent }),
            // @ts-ignore node-fetch uses a custom AbortSignal type that is
            // not compatible with standard web types
            signal: options.signal ?? null,
        };
        return { req, url, timeout };
    }
    buildHeaders({ options, headers, contentLength, retryCount, }) {
        const reqHeaders = {};
        if (contentLength) {
            reqHeaders['content-length'] = contentLength;
        }
        const defaultHeaders = this.defaultHeaders(options);
        applyHeadersMut(reqHeaders, defaultHeaders);
        applyHeadersMut(reqHeaders, headers);
        // let builtin fetch set the Content-Type for multipart bodies
        if (isMultipartBody(options.body) && kind !== 'node') {
            delete reqHeaders['content-type'];
        }
        // Don't set the retry count header if it was already set or removed through default headers or by the
        // caller. We check `defaultHeaders` and `headers`, which can contain nulls, instead of `reqHeaders` to
        // account for the removal case.
        if (getHeader(defaultHeaders, 'x-stainless-retry-count') === undefined &&
            getHeader(headers, 'x-stainless-retry-count') === undefined) {
            reqHeaders['x-stainless-retry-count'] = String(retryCount);
        }
        this.validateHeaders(reqHeaders, headers);
        return reqHeaders;
    }
    /**
     * Used as a callback for mutating the given `FinalRequestOptions` object.
     */
    async prepareOptions(options) { }
    /**
     * Used as a callback for mutating the given `RequestInit` object.
     *
     * This is useful for cases where you want to add certain headers based off of
     * the request properties, e.g. `method` or `url`.
     */
    async prepareRequest(request, { url, options }) { }
    parseHeaders(headers) {
        return (!headers ? {}
            : Symbol.iterator in headers ?
                Object.fromEntries(Array.from(headers).map((header) => [...header]))
                : { ...headers });
    }
    makeStatusError(status, error, message, headers) {
        return APIError.generate(status, error, message, headers);
    }
    request(options, remainingRetries = null) {
        return new APIPromise(this.makeRequest(options, remainingRetries));
    }
    async makeRequest(optionsInput, retriesRemaining) {
        const options = await optionsInput;
        const maxRetries = options.maxRetries ?? this.maxRetries;
        if (retriesRemaining == null) {
            retriesRemaining = maxRetries;
        }
        await this.prepareOptions(options);
        const { req, url, timeout } = this.buildRequest(options, { retryCount: maxRetries - retriesRemaining });
        await this.prepareRequest(req, { url, options });
        debug('request', url, options, req.headers);
        if (options.signal?.aborted) {
            throw new APIUserAbortError();
        }
        const controller = new AbortController();
        const response = await this.fetchWithTimeout(url, req, timeout, controller).catch(castToError);
        if (response instanceof Error) {
            if (options.signal?.aborted) {
                throw new APIUserAbortError();
            }
            if (retriesRemaining) {
                return this.retryRequest(options, retriesRemaining);
            }
            if (response.name === 'AbortError') {
                throw new APIConnectionTimeoutError();
            }
            throw new APIConnectionError({ cause: response });
        }
        const responseHeaders = createResponseHeaders(response.headers);
        if (!response.ok) {
            if (retriesRemaining && this.shouldRetry(response)) {
                const retryMessage = `retrying, ${retriesRemaining} attempts remaining`;
                debug(`response (error; ${retryMessage})`, response.status, url, responseHeaders);
                return this.retryRequest(options, retriesRemaining, responseHeaders);
            }
            const errText = await response.text().catch((e) => castToError(e).message);
            const errJSON = safeJSON(errText);
            const errMessage = errJSON ? undefined : errText;
            const retryMessage = retriesRemaining ? `(error; no more retries left)` : `(error; not retryable)`;
            debug(`response (error; ${retryMessage})`, response.status, url, responseHeaders, errMessage);
            const err = this.makeStatusError(response.status, errJSON, errMessage, responseHeaders);
            throw err;
        }
        return { response, options, controller };
    }
    requestAPIList(Page, options) {
        const request = this.makeRequest(options, null);
        return new PagePromise(this, request, Page);
    }
    buildURL(path, query) {
        const url = isAbsoluteURL(path) ?
            new URL(path)
            : new URL(this.baseURL + (this.baseURL.endsWith('/') && path.startsWith('/') ? path.slice(1) : path));
        const defaultQuery = this.defaultQuery();
        if (!isEmptyObj(defaultQuery)) {
            query = { ...defaultQuery, ...query };
        }
        if (typeof query === 'object' && query && !Array.isArray(query)) {
            url.search = this.stringifyQuery(query);
        }
        return url.toString();
    }
    stringifyQuery(query) {
        return Object.entries(query)
            .filter(([_, value]) => typeof value !== 'undefined')
            .map(([key, value]) => {
            if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
                return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
            }
            if (value === null) {
                return `${encodeURIComponent(key)}=`;
            }
            throw new error_GroqError(`Cannot stringify type ${typeof value}; Expected string, number, boolean, or null. If you need to pass nested query parameters, you can manually encode them, e.g. { query: { 'foo[key1]': value1, 'foo[key2]': value2 } }, and please open a GitHub issue requesting better support for your use case.`);
        })
            .join('&');
    }
    async fetchWithTimeout(url, init, ms, controller) {
        const { signal, ...options } = init || {};
        if (signal)
            signal.addEventListener('abort', () => controller.abort());
        const timeout = setTimeout(() => controller.abort(), ms);
        const fetchOptions = {
            signal: controller.signal,
            ...options,
        };
        if (fetchOptions.method) {
            // Custom methods like 'patch' need to be uppercased
            // See https://github.com/nodejs/undici/issues/2294
            fetchOptions.method = fetchOptions.method.toUpperCase();
        }
        return (
        // use undefined this binding; fetch errors if bound to something else in browser/cloudflare
        this.fetch.call(undefined, url, fetchOptions).finally(() => {
            clearTimeout(timeout);
        }));
    }
    shouldRetry(response) {
        // Note this is not a standard header.
        const shouldRetryHeader = response.headers.get('x-should-retry');
        // If the server explicitly says whether or not to retry, obey.
        if (shouldRetryHeader === 'true')
            return true;
        if (shouldRetryHeader === 'false')
            return false;
        // Retry on request timeouts.
        if (response.status === 408)
            return true;
        // Retry on lock timeouts.
        if (response.status === 409)
            return true;
        // Retry on rate limits.
        if (response.status === 429)
            return true;
        // Retry internal errors.
        if (response.status >= 500)
            return true;
        return false;
    }
    async retryRequest(options, retriesRemaining, responseHeaders) {
        let timeoutMillis;
        // Note the `retry-after-ms` header may not be standard, but is a good idea and we'd like proactive support for it.
        const retryAfterMillisHeader = responseHeaders?.['retry-after-ms'];
        if (retryAfterMillisHeader) {
            const timeoutMs = parseFloat(retryAfterMillisHeader);
            if (!Number.isNaN(timeoutMs)) {
                timeoutMillis = timeoutMs;
            }
        }
        // About the Retry-After header: https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Retry-After
        const retryAfterHeader = responseHeaders?.['retry-after'];
        if (retryAfterHeader && !timeoutMillis) {
            const timeoutSeconds = parseFloat(retryAfterHeader);
            if (!Number.isNaN(timeoutSeconds)) {
                timeoutMillis = timeoutSeconds * 1000;
            }
            else {
                timeoutMillis = Date.parse(retryAfterHeader) - Date.now();
            }
        }
        // If the API asks us to wait a certain amount of time (and it's a reasonable amount),
        // just do what it says, but otherwise calculate a default
        if (!(timeoutMillis && 0 <= timeoutMillis && timeoutMillis < 60 * 1000)) {
            const maxRetries = options.maxRetries ?? this.maxRetries;
            timeoutMillis = this.calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries);
        }
        await sleep(timeoutMillis);
        return this.makeRequest(options, retriesRemaining - 1);
    }
    calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries) {
        const initialRetryDelay = 0.5;
        const maxRetryDelay = 8.0;
        const numRetries = maxRetries - retriesRemaining;
        // Apply exponential backoff, but not more than the max.
        const sleepSeconds = Math.min(initialRetryDelay * Math.pow(2, numRetries), maxRetryDelay);
        // Apply some jitter, take up to at most 25 percent of the retry time.
        const jitter = 1 - Math.random() * 0.25;
        return sleepSeconds * jitter * 1000;
    }
    getUserAgent() {
        return `${this.constructor.name}/JS ${VERSION}`;
    }
}
class AbstractPage {
    constructor(client, response, body, options) {
        _AbstractPage_client.set(this, void 0);
        __classPrivateFieldSet(this, _AbstractPage_client, client, "f");
        this.options = options;
        this.response = response;
        this.body = body;
    }
    hasNextPage() {
        const items = this.getPaginatedItems();
        if (!items.length)
            return false;
        return this.nextPageInfo() != null;
    }
    async getNextPage() {
        const nextInfo = this.nextPageInfo();
        if (!nextInfo) {
            throw new error_GroqError('No next page expected; please check `.hasNextPage()` before calling `.getNextPage()`.');
        }
        const nextOptions = { ...this.options };
        if ('params' in nextInfo && typeof nextOptions.query === 'object') {
            nextOptions.query = { ...nextOptions.query, ...nextInfo.params };
        }
        else if ('url' in nextInfo) {
            const params = [...Object.entries(nextOptions.query || {}), ...nextInfo.url.searchParams.entries()];
            for (const [key, value] of params) {
                nextInfo.url.searchParams.set(key, value);
            }
            nextOptions.query = undefined;
            nextOptions.path = nextInfo.url.toString();
        }
        return await __classPrivateFieldGet(this, _AbstractPage_client, "f").requestAPIList(this.constructor, nextOptions);
    }
    async *iterPages() {
        // eslint-disable-next-line @typescript-eslint/no-this-alias
        let page = this;
        yield page;
        while (page.hasNextPage()) {
            page = await page.getNextPage();
            yield page;
        }
    }
    async *[(_AbstractPage_client = new WeakMap(), Symbol.asyncIterator)]() {
        for await (const page of this.iterPages()) {
            for (const item of page.getPaginatedItems()) {
                yield item;
            }
        }
    }
}
/**
 * This subclass of Promise will resolve to an instantiated Page once the request completes.
 *
 * It also implements AsyncIterable to allow auto-paginating iteration on an unawaited list call, eg:
 *
 *    for await (const item of client.items.list()) {
 *      console.log(item)
 *    }
 */
class PagePromise extends APIPromise {
    constructor(client, request, Page) {
        super(request, async (props) => new Page(client, props.response, await defaultParseResponse(props), props.options));
    }
    /**
     * Allow auto-paginating iteration on an unawaited list call, eg:
     *
     *    for await (const item of client.items.list()) {
     *      console.log(item)
     *    }
     */
    async *[Symbol.asyncIterator]() {
        const page = await this;
        for await (const item of page) {
            yield item;
        }
    }
}
const createResponseHeaders = (headers) => {
    return new Proxy(Object.fromEntries(
    // @ts-ignore
    headers.entries()), {
        get(target, name) {
            const key = name.toString();
            return target[key.toLowerCase()] || target[key];
        },
    });
};
// This is required so that we can determine if a given object matches the RequestOptions
// type at runtime. While this requires duplication, it is enforced by the TypeScript
// compiler such that any missing / extraneous keys will cause an error.
const requestOptionsKeys = {
    method: true,
    path: true,
    query: true,
    body: true,
    headers: true,
    maxRetries: true,
    stream: true,
    timeout: true,
    httpAgent: true,
    signal: true,
    idempotencyKey: true,
    __binaryRequest: true,
    __binaryResponse: true,
    __streamClass: true,
};
const isRequestOptions = (obj) => {
    return (typeof obj === 'object' &&
        obj !== null &&
        !isEmptyObj(obj) &&
        Object.keys(obj).every((k) => hasOwn(requestOptionsKeys, k)));
};
const getPlatformProperties = () => {
    if (typeof Deno !== 'undefined' && Deno.build != null) {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': VERSION,
            'X-Stainless-OS': normalizePlatform(Deno.build.os),
            'X-Stainless-Arch': normalizeArch(Deno.build.arch),
            'X-Stainless-Runtime': 'deno',
            'X-Stainless-Runtime-Version': typeof Deno.version === 'string' ? Deno.version : Deno.version?.deno ?? 'unknown',
        };
    }
    if (typeof EdgeRuntime !== 'undefined') {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': VERSION,
            'X-Stainless-OS': 'Unknown',
            'X-Stainless-Arch': `other:${EdgeRuntime}`,
            'X-Stainless-Runtime': 'edge',
            'X-Stainless-Runtime-Version': process.version,
        };
    }
    // Check if Node.js
    if (Object.prototype.toString.call(typeof process !== 'undefined' ? process : 0) === '[object process]') {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': VERSION,
            'X-Stainless-OS': normalizePlatform(process.platform),
            'X-Stainless-Arch': normalizeArch(process.arch),
            'X-Stainless-Runtime': 'node',
            'X-Stainless-Runtime-Version': process.version,
        };
    }
    const browserInfo = getBrowserInfo();
    if (browserInfo) {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': VERSION,
            'X-Stainless-OS': 'Unknown',
            'X-Stainless-Arch': 'unknown',
            'X-Stainless-Runtime': `browser:${browserInfo.browser}`,
            'X-Stainless-Runtime-Version': browserInfo.version,
        };
    }
    // TODO add support for Cloudflare workers, etc.
    return {
        'X-Stainless-Lang': 'js',
        'X-Stainless-Package-Version': VERSION,
        'X-Stainless-OS': 'Unknown',
        'X-Stainless-Arch': 'unknown',
        'X-Stainless-Runtime': 'unknown',
        'X-Stainless-Runtime-Version': 'unknown',
    };
};
// Note: modified from https://github.com/JS-DevTools/host-environment/blob/b1ab79ecde37db5d6e163c050e54fe7d287d7c92/src/isomorphic.browser.ts
function getBrowserInfo() {
    if (typeof navigator === 'undefined' || !navigator) {
        return null;
    }
    // NOTE: The order matters here!
    const browserPatterns = [
        { key: 'edge', pattern: /Edge(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'ie', pattern: /MSIE(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'ie', pattern: /Trident(?:.*rv\:(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'chrome', pattern: /Chrome(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'firefox', pattern: /Firefox(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'safari', pattern: /(?:Version\W+(\d+)\.(\d+)(?:\.(\d+))?)?(?:\W+Mobile\S*)?\W+Safari/ },
    ];
    // Find the FIRST matching browser
    for (const { key, pattern } of browserPatterns) {
        const match = pattern.exec(navigator.userAgent);
        if (match) {
            const major = match[1] || 0;
            const minor = match[2] || 0;
            const patch = match[3] || 0;
            return { browser: key, version: `${major}.${minor}.${patch}` };
        }
    }
    return null;
}
const normalizeArch = (arch) => {
    // Node docs:
    // - https://nodejs.org/api/process.html#processarch
    // Deno docs:
    // - https://doc.deno.land/deno/stable/~/Deno.build
    if (arch === 'x32')
        return 'x32';
    if (arch === 'x86_64' || arch === 'x64')
        return 'x64';
    if (arch === 'arm')
        return 'arm';
    if (arch === 'aarch64' || arch === 'arm64')
        return 'arm64';
    if (arch)
        return `other:${arch}`;
    return 'unknown';
};
const normalizePlatform = (platform) => {
    // Node platforms:
    // - https://nodejs.org/api/process.html#processplatform
    // Deno platforms:
    // - https://doc.deno.land/deno/stable/~/Deno.build
    // - https://github.com/denoland/deno/issues/14799
    platform = platform.toLowerCase();
    // NOTE: this iOS check is untested and may not work
    // Node does not work natively on IOS, there is a fork at
    // https://github.com/nodejs-mobile/nodejs-mobile
    // however it is unknown at the time of writing how to detect if it is running
    if (platform.includes('ios'))
        return 'iOS';
    if (platform === 'android')
        return 'Android';
    if (platform === 'darwin')
        return 'MacOS';
    if (platform === 'win32')
        return 'Windows';
    if (platform === 'freebsd')
        return 'FreeBSD';
    if (platform === 'openbsd')
        return 'OpenBSD';
    if (platform === 'linux')
        return 'Linux';
    if (platform)
        return `Other:${platform}`;
    return 'Unknown';
};
let _platformHeaders;
const getPlatformHeaders = () => {
    return (_platformHeaders ?? (_platformHeaders = getPlatformProperties()));
};
const safeJSON = (text) => {
    try {
        return JSON.parse(text);
    }
    catch (err) {
        return undefined;
    }
};
// https://url.spec.whatwg.org/#url-scheme-string
const startsWithSchemeRegexp = /^[a-z][a-z0-9+.-]*:/i;
const isAbsoluteURL = (url) => {
    return startsWithSchemeRegexp.test(url);
};
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const validatePositiveInteger = (name, n) => {
    if (typeof n !== 'number' || !Number.isInteger(n)) {
        throw new error_GroqError(`${name} must be an integer`);
    }
    if (n < 0) {
        throw new error_GroqError(`${name} must be a positive integer`);
    }
    return n;
};
const castToError = (err) => {
    if (err instanceof Error)
        return err;
    if (typeof err === 'object' && err !== null) {
        try {
            return new Error(JSON.stringify(err));
        }
        catch { }
    }
    return new Error(err);
};
const ensurePresent = (value) => {
    if (value == null)
        throw new GroqError(`Expected a value to be given but received ${value} instead.`);
    return value;
};
/**
 * Read an environment variable.
 *
 * Trims beginning and trailing whitespace.
 *
 * Will return undefined if the environment variable doesn't exist or cannot be accessed.
 */
const readEnv = (env) => {
    if (typeof process !== 'undefined') {
        return {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}?.[env]?.trim() ?? undefined;
    }
    if (typeof Deno !== 'undefined') {
        return Deno.env?.get?.(env)?.trim();
    }
    return undefined;
};
const coerceInteger = (value) => {
    if (typeof value === 'number')
        return Math.round(value);
    if (typeof value === 'string')
        return parseInt(value, 10);
    throw new GroqError(`Could not coerce ${value} (type: ${typeof value}) into a number`);
};
const coerceFloat = (value) => {
    if (typeof value === 'number')
        return value;
    if (typeof value === 'string')
        return parseFloat(value);
    throw new GroqError(`Could not coerce ${value} (type: ${typeof value}) into a number`);
};
const coerceBoolean = (value) => {
    if (typeof value === 'boolean')
        return value;
    if (typeof value === 'string')
        return value === 'true';
    return Boolean(value);
};
const maybeCoerceInteger = (value) => {
    if (value === undefined) {
        return undefined;
    }
    return coerceInteger(value);
};
const maybeCoerceFloat = (value) => {
    if (value === undefined) {
        return undefined;
    }
    return coerceFloat(value);
};
const maybeCoerceBoolean = (value) => {
    if (value === undefined) {
        return undefined;
    }
    return coerceBoolean(value);
};
// https://stackoverflow.com/a/34491287
function isEmptyObj(obj) {
    if (!obj)
        return true;
    for (const _k in obj)
        return false;
    return true;
}
// https://eslint.org/docs/latest/rules/no-prototype-builtins
function hasOwn(obj, key) {
    return Object.prototype.hasOwnProperty.call(obj, key);
}
/**
 * Copies headers from "newHeaders" onto "targetHeaders",
 * using lower-case for all properties,
 * ignoring any keys with undefined values,
 * and deleting any keys with null values.
 */
function applyHeadersMut(targetHeaders, newHeaders) {
    for (const k in newHeaders) {
        if (!hasOwn(newHeaders, k))
            continue;
        const lowerKey = k.toLowerCase();
        if (!lowerKey)
            continue;
        const val = newHeaders[k];
        if (val === null) {
            delete targetHeaders[lowerKey];
        }
        else if (val !== undefined) {
            targetHeaders[lowerKey] = val;
        }
    }
}
function debug(action, ...args) {
    if (typeof process !== 'undefined' && {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}?.['DEBUG'] === 'true') {
        console.log(`Groq:DEBUG:${action}`, ...args);
    }
}
/**
 * https://stackoverflow.com/a/2117523
 */
const uuid4 = () => {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = (Math.random() * 16) | 0;
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    });
};
const isRunningInBrowser = () => {
    return (
    // @ts-ignore
    typeof window !== 'undefined' &&
        // @ts-ignore
        typeof window.document !== 'undefined' &&
        // @ts-ignore
        typeof navigator !== 'undefined');
};
const isHeadersProtocol = (headers) => {
    return typeof headers?.get === 'function';
};
const getRequiredHeader = (headers, header) => {
    const foundHeader = getHeader(headers, header);
    if (foundHeader === undefined) {
        throw new Error(`Could not find ${header} header`);
    }
    return foundHeader;
};
const getHeader = (headers, header) => {
    const lowerCasedHeader = header.toLowerCase();
    if (isHeadersProtocol(headers)) {
        // to deal with the case where the header looks like Stainless-Event-Id
        const intercapsHeader = header[0]?.toUpperCase() +
            header.substring(1).replace(/([^\w])(\w)/g, (_m, g1, g2) => g1 + g2.toUpperCase());
        for (const key of [header, lowerCasedHeader, header.toUpperCase(), intercapsHeader]) {
            const value = headers.get(key);
            if (value) {
                return value;
            }
        }
    }
    for (const [key, value] of Object.entries(headers)) {
        if (key.toLowerCase() === lowerCasedHeader) {
            if (Array.isArray(value)) {
                if (value.length <= 1)
                    return value[0];
                console.warn(`Received ${value.length} entries for the ${header} header, using the first entry.`);
                return value[0];
            }
            return value;
        }
    }
    return undefined;
};
/**
 * Encodes a string to Base64 format.
 */
const toBase64 = (str) => {
    if (!str)
        return '';
    if (typeof core_Buffer !== 'undefined') {
        return core_Buffer.from(str).toString('base64');
    }
    if (typeof btoa !== 'undefined') {
        return btoa(str);
    }
    throw new GroqError('Cannot generate b64 string; Expected `Buffer` or `btoa` to be defined');
};
function isObj(obj) {
    return obj != null && typeof obj === 'object' && !Array.isArray(obj);
}
//# sourceMappingURL=core.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resource.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
class APIResource {
    constructor(client) {
        this._client = client;
    }
}
//# sourceMappingURL=resource.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/completions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class Completions extends APIResource {
}
//# sourceMappingURL=completions.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/chat/completions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class completions_Completions extends APIResource {
    create(body, options) {
        return this._client.post('/openai/v1/chat/completions', {
            body,
            ...options,
            stream: body.stream ?? false,
        });
    }
}
//# sourceMappingURL=completions.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/chat/chat.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class Chat extends APIResource {
    constructor() {
        super(...arguments);
        this.completions = new completions_Completions(this._client);
    }
}
Chat.Completions = completions_Completions;
//# sourceMappingURL=chat.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/embeddings.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class Embeddings extends APIResource {
    /**
     * Creates an embedding vector representing the input text.
     */
    create(body, options) {
        return this._client.post('/openai/v1/embeddings', { body, ...options });
    }
}
//# sourceMappingURL=embeddings.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/audio/transcriptions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class Transcriptions extends APIResource {
    /**
     * Transcribes audio into the input language.
     */
    create(body, options) {
        return this._client.post('/openai/v1/audio/transcriptions', multipartFormRequestOptions({ body, ...options }));
    }
}
//# sourceMappingURL=transcriptions.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/audio/translations.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class Translations extends APIResource {
    /**
     * Translates audio into English.
     */
    create(body, options) {
        return this._client.post('/openai/v1/audio/translations', multipartFormRequestOptions({ body, ...options }));
    }
}
//# sourceMappingURL=translations.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/audio/audio.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.





class Audio extends APIResource {
    constructor() {
        super(...arguments);
        this.transcriptions = new Transcriptions(this._client);
        this.translations = new Translations(this._client);
    }
}
Audio.Transcriptions = Transcriptions;
Audio.Translations = Translations;
//# sourceMappingURL=audio.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/models.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class Models extends APIResource {
    /**
     * Get a specific model
     */
    retrieve(model, options) {
        return this._client.get(`/openai/v1/models/${model}`, options);
    }
    /**
     * get all available models
     */
    list(options) {
        return this._client.get('/openai/v1/models', options);
    }
    /**
     * Delete a model
     */
    delete(model, options) {
        return this._client.delete(`/openai/v1/models/${model}`, options);
    }
}
//# sourceMappingURL=models.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/batches.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class Batches extends APIResource {
    /**
     * Creates and executes a batch from an uploaded file of requests
     */
    create(body, options) {
        return this._client.post('/openai/v1/batches', { body, ...options });
    }
    /**
     * Retrieves a batch.
     */
    retrieve(batchId, options) {
        return this._client.get(`/openai/v1/batches/${batchId}`, options);
    }
    /**
     * List your organization's batches.
     */
    list(options) {
        return this._client.get('/openai/v1/batches', options);
    }
}
//# sourceMappingURL=batches.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/resources/files.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class Files extends APIResource {
    /**
     * Upload a file that can be used across various endpoints.
     *
     * The Batch API only supports `.jsonl` files up to 100 MB in size. The input also
     * has a specific required [format](/docs/batch).
     *
     * Please contact us if you need to increase these storage limits.
     */
    create(body, options) {
        return this._client.post('/openai/v1/files', multipartFormRequestOptions({ body, ...options }));
    }
    /**
     * Returns a list of files.
     */
    list(options) {
        return this._client.get('/openai/v1/files', options);
    }
    /**
     * Delete a file.
     */
    delete(fileId, options) {
        return this._client.delete(`/openai/v1/files/${fileId}`, options);
    }
    /**
     * Returns the contents of the specified file.
     */
    content(fileId, options) {
        return this._client.get(`/openai/v1/files/${fileId}/content`, options);
    }
    /**
     * Returns information about a file.
     */
    info(fileId, options) {
        return this._client.get(`/openai/v1/files/${fileId}`, options);
    }
}
//# sourceMappingURL=files.mjs.map
;// CONCATENATED MODULE: ./node_modules/groq-sdk/index.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
var _a;











/**
 * API Client for interfacing with the Groq API.
 */
class Groq extends APIClient {
    /**
     * API Client for interfacing with the Groq API.
     *
     * @param {string | undefined} [opts.apiKey=process.env['GROQ_API_KEY'] ?? undefined]
     * @param {string} [opts.baseURL=process.env['GROQ_BASE_URL'] ?? https://api.groq.com] - Override the default base URL for the API.
     * @param {number} [opts.timeout=1 minute] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {number} [opts.httpAgent] - An HTTP agent used to manage HTTP(s) connections.
     * @param {Core.Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {Core.Headers} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Core.DefaultQuery} opts.defaultQuery - Default query parameters to include with every request to the API.
     * @param {boolean} [opts.dangerouslyAllowBrowser=false] - By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
     */
    constructor({ baseURL = readEnv('GROQ_BASE_URL'), apiKey = readEnv('GROQ_API_KEY'), ...opts } = {}) {
        if (apiKey === undefined) {
            throw new error_GroqError("The GROQ_API_KEY environment variable is missing or empty; either provide it, or instantiate the Groq client with an apiKey option, like new Groq({ apiKey: 'My API Key' }).");
        }
        const options = {
            apiKey,
            ...opts,
            baseURL: baseURL || `https://api.groq.com`,
        };
        if (!options.dangerouslyAllowBrowser && isRunningInBrowser()) {
            throw new error_GroqError("It looks like you're running in a browser-like environment.\n\nThis is disabled by default, as it risks exposing your secret API credentials to attackers.\nIf you understand the risks and have appropriate mitigations in place,\nyou can set the `dangerouslyAllowBrowser` option to `true`, e.g.,\n\nnew Groq({ apiKey, dangerouslyAllowBrowser: true })");
        }
        super({
            baseURL: options.baseURL,
            timeout: options.timeout ?? 60000 /* 1 minute */,
            httpAgent: options.httpAgent,
            maxRetries: options.maxRetries,
            fetch: options.fetch,
        });
        this.completions = new Completions(this);
        this.chat = new Chat(this);
        this.embeddings = new Embeddings(this);
        this.audio = new Audio(this);
        this.models = new Models(this);
        this.batches = new Batches(this);
        this.files = new Files(this);
        this._options = options;
        this.apiKey = apiKey;
    }
    defaultQuery() {
        return this._options.defaultQuery;
    }
    defaultHeaders(opts) {
        return {
            ...super.defaultHeaders(opts),
            ...this._options.defaultHeaders,
        };
    }
    authHeaders(opts) {
        return { Authorization: `Bearer ${this.apiKey}` };
    }
}
_a = Groq;
Groq.Groq = _a;
Groq.DEFAULT_TIMEOUT = 60000; // 1 minute
Groq.GroqError = error_GroqError;
Groq.APIError = APIError;
Groq.APIConnectionError = APIConnectionError;
Groq.APIConnectionTimeoutError = APIConnectionTimeoutError;
Groq.APIUserAbortError = APIUserAbortError;
Groq.NotFoundError = NotFoundError;
Groq.ConflictError = ConflictError;
Groq.RateLimitError = RateLimitError;
Groq.BadRequestError = BadRequestError;
Groq.AuthenticationError = AuthenticationError;
Groq.InternalServerError = InternalServerError;
Groq.PermissionDeniedError = PermissionDeniedError;
Groq.UnprocessableEntityError = UnprocessableEntityError;
Groq.toFile = toFile;
Groq.fileFromPath = fileFromPath;
Groq.Completions = Completions;
Groq.Chat = Chat;
Groq.Embeddings = Embeddings;
Groq.Audio = Audio;
Groq.Models = Models;
Groq.Batches = Batches;
Groq.Files = Files;


/* harmony default export */ const groq_sdk = (Groq);
//# sourceMappingURL=index.mjs.map

/***/ }),

/***/ 16065:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ openai)
});

// UNUSED EXPORTS: APIConnectionError, APIConnectionTimeoutError, APIError, APIUserAbortError, AuthenticationError, AzureOpenAI, BadRequestError, ConflictError, InternalServerError, NotFoundError, OpenAI, OpenAIError, PermissionDeniedError, RateLimitError, UnprocessableEntityError, fileFromPath, toFile

;// CONCATENATED MODULE: ./node_modules/openai/internal/qs/formats.mjs
const default_format = 'RFC3986';
const formatters = {
    RFC1738: (v) => String(v).replace(/%20/g, '+'),
    RFC3986: (v) => String(v),
};
const RFC1738 = 'RFC1738';
const RFC3986 = 'RFC3986';
//# sourceMappingURL=formats.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/internal/qs/utils.mjs

const has = Object.prototype.hasOwnProperty;
const is_array = Array.isArray;
const hex_table = (() => {
    const array = [];
    for (let i = 0; i < 256; ++i) {
        array.push('%' + ((i < 16 ? '0' : '') + i.toString(16)).toUpperCase());
    }
    return array;
})();
function compact_queue(queue) {
    while (queue.length > 1) {
        const item = queue.pop();
        if (!item)
            continue;
        const obj = item.obj[item.prop];
        if (is_array(obj)) {
            const compacted = [];
            for (let j = 0; j < obj.length; ++j) {
                if (typeof obj[j] !== 'undefined') {
                    compacted.push(obj[j]);
                }
            }
            // @ts-ignore
            item.obj[item.prop] = compacted;
        }
    }
}
function array_to_object(source, options) {
    const obj = options && options.plainObjects ? Object.create(null) : {};
    for (let i = 0; i < source.length; ++i) {
        if (typeof source[i] !== 'undefined') {
            obj[i] = source[i];
        }
    }
    return obj;
}
function merge(target, source, options = {}) {
    if (!source) {
        return target;
    }
    if (typeof source !== 'object') {
        if (is_array(target)) {
            target.push(source);
        }
        else if (target && typeof target === 'object') {
            if ((options && (options.plainObjects || options.allowPrototypes)) ||
                !has.call(Object.prototype, source)) {
                target[source] = true;
            }
        }
        else {
            return [target, source];
        }
        return target;
    }
    if (!target || typeof target !== 'object') {
        return [target].concat(source);
    }
    let mergeTarget = target;
    if (is_array(target) && !is_array(source)) {
        // @ts-ignore
        mergeTarget = array_to_object(target, options);
    }
    if (is_array(target) && is_array(source)) {
        source.forEach(function (item, i) {
            if (has.call(target, i)) {
                const targetItem = target[i];
                if (targetItem && typeof targetItem === 'object' && item && typeof item === 'object') {
                    target[i] = merge(targetItem, item, options);
                }
                else {
                    target.push(item);
                }
            }
            else {
                target[i] = item;
            }
        });
        return target;
    }
    return Object.keys(source).reduce(function (acc, key) {
        const value = source[key];
        if (has.call(acc, key)) {
            acc[key] = merge(acc[key], value, options);
        }
        else {
            acc[key] = value;
        }
        return acc;
    }, mergeTarget);
}
function assign_single_source(target, source) {
    return Object.keys(source).reduce(function (acc, key) {
        acc[key] = source[key];
        return acc;
    }, target);
}
function decode(str, _, charset) {
    const strWithoutPlus = str.replace(/\+/g, ' ');
    if (charset === 'iso-8859-1') {
        // unescape never throws, no try...catch needed:
        return strWithoutPlus.replace(/%[0-9a-f]{2}/gi, unescape);
    }
    // utf-8
    try {
        return decodeURIComponent(strWithoutPlus);
    }
    catch (e) {
        return strWithoutPlus;
    }
}
const limit = 1024;
const encode = (str, _defaultEncoder, charset, _kind, format) => {
    // This code was originally written by Brian White for the io.js core querystring library.
    // It has been adapted here for stricter adherence to RFC 3986
    if (str.length === 0) {
        return str;
    }
    let string = str;
    if (typeof str === 'symbol') {
        string = Symbol.prototype.toString.call(str);
    }
    else if (typeof str !== 'string') {
        string = String(str);
    }
    if (charset === 'iso-8859-1') {
        return escape(string).replace(/%u[0-9a-f]{4}/gi, function ($0) {
            return '%26%23' + parseInt($0.slice(2), 16) + '%3B';
        });
    }
    let out = '';
    for (let j = 0; j < string.length; j += limit) {
        const segment = string.length >= limit ? string.slice(j, j + limit) : string;
        const arr = [];
        for (let i = 0; i < segment.length; ++i) {
            let c = segment.charCodeAt(i);
            if (c === 0x2d || // -
                c === 0x2e || // .
                c === 0x5f || // _
                c === 0x7e || // ~
                (c >= 0x30 && c <= 0x39) || // 0-9
                (c >= 0x41 && c <= 0x5a) || // a-z
                (c >= 0x61 && c <= 0x7a) || // A-Z
                (format === RFC1738 && (c === 0x28 || c === 0x29)) // ( )
            ) {
                arr[arr.length] = segment.charAt(i);
                continue;
            }
            if (c < 0x80) {
                arr[arr.length] = hex_table[c];
                continue;
            }
            if (c < 0x800) {
                arr[arr.length] = hex_table[0xc0 | (c >> 6)] + hex_table[0x80 | (c & 0x3f)];
                continue;
            }
            if (c < 0xd800 || c >= 0xe000) {
                arr[arr.length] =
                    hex_table[0xe0 | (c >> 12)] + hex_table[0x80 | ((c >> 6) & 0x3f)] + hex_table[0x80 | (c & 0x3f)];
                continue;
            }
            i += 1;
            c = 0x10000 + (((c & 0x3ff) << 10) | (segment.charCodeAt(i) & 0x3ff));
            arr[arr.length] =
                hex_table[0xf0 | (c >> 18)] +
                    hex_table[0x80 | ((c >> 12) & 0x3f)] +
                    hex_table[0x80 | ((c >> 6) & 0x3f)] +
                    hex_table[0x80 | (c & 0x3f)];
        }
        out += arr.join('');
    }
    return out;
};
function compact(value) {
    const queue = [{ obj: { o: value }, prop: 'o' }];
    const refs = [];
    for (let i = 0; i < queue.length; ++i) {
        const item = queue[i];
        // @ts-ignore
        const obj = item.obj[item.prop];
        const keys = Object.keys(obj);
        for (let j = 0; j < keys.length; ++j) {
            const key = keys[j];
            const val = obj[key];
            if (typeof val === 'object' && val !== null && refs.indexOf(val) === -1) {
                queue.push({ obj: obj, prop: key });
                refs.push(val);
            }
        }
    }
    compact_queue(queue);
    return value;
}
function is_regexp(obj) {
    return Object.prototype.toString.call(obj) === '[object RegExp]';
}
function is_buffer(obj) {
    if (!obj || typeof obj !== 'object') {
        return false;
    }
    return !!(obj.constructor && obj.constructor.isBuffer && obj.constructor.isBuffer(obj));
}
function combine(a, b) {
    return [].concat(a, b);
}
function maybe_map(val, fn) {
    if (is_array(val)) {
        const mapped = [];
        for (let i = 0; i < val.length; i += 1) {
            mapped.push(fn(val[i]));
        }
        return mapped;
    }
    return fn(val);
}
//# sourceMappingURL=utils.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/internal/qs/stringify.mjs


const stringify_has = Object.prototype.hasOwnProperty;
const array_prefix_generators = {
    brackets(prefix) {
        return String(prefix) + '[]';
    },
    comma: 'comma',
    indices(prefix, key) {
        return String(prefix) + '[' + key + ']';
    },
    repeat(prefix) {
        return String(prefix);
    },
};
const stringify_is_array = Array.isArray;
const push = Array.prototype.push;
const push_to_array = function (arr, value_or_array) {
    push.apply(arr, stringify_is_array(value_or_array) ? value_or_array : [value_or_array]);
};
const to_ISO = Date.prototype.toISOString;
const defaults = {
    addQueryPrefix: false,
    allowDots: false,
    allowEmptyArrays: false,
    arrayFormat: 'indices',
    charset: 'utf-8',
    charsetSentinel: false,
    delimiter: '&',
    encode: true,
    encodeDotInKeys: false,
    encoder: encode,
    encodeValuesOnly: false,
    format: default_format,
    formatter: formatters[default_format],
    /** @deprecated */
    indices: false,
    serializeDate(date) {
        return to_ISO.call(date);
    },
    skipNulls: false,
    strictNullHandling: false,
};
function is_non_nullish_primitive(v) {
    return (typeof v === 'string' ||
        typeof v === 'number' ||
        typeof v === 'boolean' ||
        typeof v === 'symbol' ||
        typeof v === 'bigint');
}
const sentinel = {};
function inner_stringify(object, prefix, generateArrayPrefix, commaRoundTrip, allowEmptyArrays, strictNullHandling, skipNulls, encodeDotInKeys, encoder, filter, sort, allowDots, serializeDate, format, formatter, encodeValuesOnly, charset, sideChannel) {
    let obj = object;
    let tmp_sc = sideChannel;
    let step = 0;
    let find_flag = false;
    while ((tmp_sc = tmp_sc.get(sentinel)) !== void undefined && !find_flag) {
        // Where object last appeared in the ref tree
        const pos = tmp_sc.get(object);
        step += 1;
        if (typeof pos !== 'undefined') {
            if (pos === step) {
                throw new RangeError('Cyclic object value');
            }
            else {
                find_flag = true; // Break while
            }
        }
        if (typeof tmp_sc.get(sentinel) === 'undefined') {
            step = 0;
        }
    }
    if (typeof filter === 'function') {
        obj = filter(prefix, obj);
    }
    else if (obj instanceof Date) {
        obj = serializeDate?.(obj);
    }
    else if (generateArrayPrefix === 'comma' && stringify_is_array(obj)) {
        obj = maybe_map(obj, function (value) {
            if (value instanceof Date) {
                return serializeDate?.(value);
            }
            return value;
        });
    }
    if (obj === null) {
        if (strictNullHandling) {
            return encoder && !encodeValuesOnly ?
                // @ts-expect-error
                encoder(prefix, defaults.encoder, charset, 'key', format)
                : prefix;
        }
        obj = '';
    }
    if (is_non_nullish_primitive(obj) || is_buffer(obj)) {
        if (encoder) {
            const key_value = encodeValuesOnly ? prefix
                // @ts-expect-error
                : encoder(prefix, defaults.encoder, charset, 'key', format);
            return [
                formatter?.(key_value) +
                    '=' +
                    // @ts-expect-error
                    formatter?.(encoder(obj, defaults.encoder, charset, 'value', format)),
            ];
        }
        return [formatter?.(prefix) + '=' + formatter?.(String(obj))];
    }
    const values = [];
    if (typeof obj === 'undefined') {
        return values;
    }
    let obj_keys;
    if (generateArrayPrefix === 'comma' && stringify_is_array(obj)) {
        // we need to join elements in
        if (encodeValuesOnly && encoder) {
            // @ts-expect-error values only
            obj = maybe_map(obj, encoder);
        }
        obj_keys = [{ value: obj.length > 0 ? obj.join(',') || null : void undefined }];
    }
    else if (stringify_is_array(filter)) {
        obj_keys = filter;
    }
    else {
        const keys = Object.keys(obj);
        obj_keys = sort ? keys.sort(sort) : keys;
    }
    const encoded_prefix = encodeDotInKeys ? String(prefix).replace(/\./g, '%2E') : String(prefix);
    const adjusted_prefix = commaRoundTrip && stringify_is_array(obj) && obj.length === 1 ? encoded_prefix + '[]' : encoded_prefix;
    if (allowEmptyArrays && stringify_is_array(obj) && obj.length === 0) {
        return adjusted_prefix + '[]';
    }
    for (let j = 0; j < obj_keys.length; ++j) {
        const key = obj_keys[j];
        const value = 
        // @ts-ignore
        typeof key === 'object' && typeof key.value !== 'undefined' ? key.value : obj[key];
        if (skipNulls && value === null) {
            continue;
        }
        // @ts-ignore
        const encoded_key = allowDots && encodeDotInKeys ? key.replace(/\./g, '%2E') : key;
        const key_prefix = stringify_is_array(obj) ?
            typeof generateArrayPrefix === 'function' ?
                generateArrayPrefix(adjusted_prefix, encoded_key)
                : adjusted_prefix
            : adjusted_prefix + (allowDots ? '.' + encoded_key : '[' + encoded_key + ']');
        sideChannel.set(object, step);
        const valueSideChannel = new WeakMap();
        valueSideChannel.set(sentinel, sideChannel);
        push_to_array(values, inner_stringify(value, key_prefix, generateArrayPrefix, commaRoundTrip, allowEmptyArrays, strictNullHandling, skipNulls, encodeDotInKeys, 
        // @ts-ignore
        generateArrayPrefix === 'comma' && encodeValuesOnly && stringify_is_array(obj) ? null : encoder, filter, sort, allowDots, serializeDate, format, formatter, encodeValuesOnly, charset, valueSideChannel));
    }
    return values;
}
function normalize_stringify_options(opts = defaults) {
    if (typeof opts.allowEmptyArrays !== 'undefined' && typeof opts.allowEmptyArrays !== 'boolean') {
        throw new TypeError('`allowEmptyArrays` option can only be `true` or `false`, when provided');
    }
    if (typeof opts.encodeDotInKeys !== 'undefined' && typeof opts.encodeDotInKeys !== 'boolean') {
        throw new TypeError('`encodeDotInKeys` option can only be `true` or `false`, when provided');
    }
    if (opts.encoder !== null && typeof opts.encoder !== 'undefined' && typeof opts.encoder !== 'function') {
        throw new TypeError('Encoder has to be a function.');
    }
    const charset = opts.charset || defaults.charset;
    if (typeof opts.charset !== 'undefined' && opts.charset !== 'utf-8' && opts.charset !== 'iso-8859-1') {
        throw new TypeError('The charset option must be either utf-8, iso-8859-1, or undefined');
    }
    let format = default_format;
    if (typeof opts.format !== 'undefined') {
        if (!stringify_has.call(formatters, opts.format)) {
            throw new TypeError('Unknown format option provided.');
        }
        format = opts.format;
    }
    const formatter = formatters[format];
    let filter = defaults.filter;
    if (typeof opts.filter === 'function' || stringify_is_array(opts.filter)) {
        filter = opts.filter;
    }
    let arrayFormat;
    if (opts.arrayFormat && opts.arrayFormat in array_prefix_generators) {
        arrayFormat = opts.arrayFormat;
    }
    else if ('indices' in opts) {
        arrayFormat = opts.indices ? 'indices' : 'repeat';
    }
    else {
        arrayFormat = defaults.arrayFormat;
    }
    if ('commaRoundTrip' in opts && typeof opts.commaRoundTrip !== 'boolean') {
        throw new TypeError('`commaRoundTrip` must be a boolean, or absent');
    }
    const allowDots = typeof opts.allowDots === 'undefined' ?
        !!opts.encodeDotInKeys === true ?
            true
            : defaults.allowDots
        : !!opts.allowDots;
    return {
        addQueryPrefix: typeof opts.addQueryPrefix === 'boolean' ? opts.addQueryPrefix : defaults.addQueryPrefix,
        // @ts-ignore
        allowDots: allowDots,
        allowEmptyArrays: typeof opts.allowEmptyArrays === 'boolean' ? !!opts.allowEmptyArrays : defaults.allowEmptyArrays,
        arrayFormat: arrayFormat,
        charset: charset,
        charsetSentinel: typeof opts.charsetSentinel === 'boolean' ? opts.charsetSentinel : defaults.charsetSentinel,
        commaRoundTrip: !!opts.commaRoundTrip,
        delimiter: typeof opts.delimiter === 'undefined' ? defaults.delimiter : opts.delimiter,
        encode: typeof opts.encode === 'boolean' ? opts.encode : defaults.encode,
        encodeDotInKeys: typeof opts.encodeDotInKeys === 'boolean' ? opts.encodeDotInKeys : defaults.encodeDotInKeys,
        encoder: typeof opts.encoder === 'function' ? opts.encoder : defaults.encoder,
        encodeValuesOnly: typeof opts.encodeValuesOnly === 'boolean' ? opts.encodeValuesOnly : defaults.encodeValuesOnly,
        filter: filter,
        format: format,
        formatter: formatter,
        serializeDate: typeof opts.serializeDate === 'function' ? opts.serializeDate : defaults.serializeDate,
        skipNulls: typeof opts.skipNulls === 'boolean' ? opts.skipNulls : defaults.skipNulls,
        // @ts-ignore
        sort: typeof opts.sort === 'function' ? opts.sort : null,
        strictNullHandling: typeof opts.strictNullHandling === 'boolean' ? opts.strictNullHandling : defaults.strictNullHandling,
    };
}
function stringify(object, opts = {}) {
    let obj = object;
    const options = normalize_stringify_options(opts);
    let obj_keys;
    let filter;
    if (typeof options.filter === 'function') {
        filter = options.filter;
        obj = filter('', obj);
    }
    else if (stringify_is_array(options.filter)) {
        filter = options.filter;
        obj_keys = filter;
    }
    const keys = [];
    if (typeof obj !== 'object' || obj === null) {
        return '';
    }
    const generateArrayPrefix = array_prefix_generators[options.arrayFormat];
    const commaRoundTrip = generateArrayPrefix === 'comma' && options.commaRoundTrip;
    if (!obj_keys) {
        obj_keys = Object.keys(obj);
    }
    if (options.sort) {
        obj_keys.sort(options.sort);
    }
    const sideChannel = new WeakMap();
    for (let i = 0; i < obj_keys.length; ++i) {
        const key = obj_keys[i];
        if (options.skipNulls && obj[key] === null) {
            continue;
        }
        push_to_array(keys, inner_stringify(obj[key], key, 
        // @ts-expect-error
        generateArrayPrefix, commaRoundTrip, options.allowEmptyArrays, options.strictNullHandling, options.skipNulls, options.encodeDotInKeys, options.encode ? options.encoder : null, options.filter, options.sort, options.allowDots, options.serializeDate, options.format, options.formatter, options.encodeValuesOnly, options.charset, sideChannel));
    }
    const joined = keys.join(options.delimiter);
    let prefix = options.addQueryPrefix === true ? '?' : '';
    if (options.charsetSentinel) {
        if (options.charset === 'iso-8859-1') {
            // encodeURIComponent('&#10003;'), the "numeric entity" representation of a checkmark
            prefix += 'utf8=%26%2310003%3B&';
        }
        else {
            // encodeURIComponent('✓')
            prefix += 'utf8=%E2%9C%93&';
        }
    }
    return joined.length > 0 ? prefix + joined : '';
}
//# sourceMappingURL=stringify.mjs.map
// EXTERNAL MODULE: ./node_modules/openai/version.mjs
var version = __webpack_require__(797);
;// CONCATENATED MODULE: ./node_modules/openai/_shims/registry.mjs
let auto = false;
let kind = undefined;
let registry_fetch = undefined;
let registry_Request = (/* unused pure expression or super */ null && (undefined));
let registry_Response = (/* unused pure expression or super */ null && (undefined));
let registry_Headers = (/* unused pure expression or super */ null && (undefined));
let registry_FormData = undefined;
let registry_Blob = (/* unused pure expression or super */ null && (undefined));
let registry_File = undefined;
let registry_ReadableStream = undefined;
let registry_getMultipartRequestOptions = undefined;
let getDefaultAgent = undefined;
let fileFromPath = undefined;
let isFsReadStream = undefined;
function setShims(shims, options = { auto: false }) {
    if (auto) {
        throw new Error(`you must \`import 'openai/shims/${shims.kind}'\` before importing anything else from openai`);
    }
    if (kind) {
        throw new Error(`can't \`import 'openai/shims/${shims.kind}'\` after \`import 'openai/shims/${kind}'\``);
    }
    auto = options.auto;
    kind = shims.kind;
    registry_fetch = shims.fetch;
    registry_Request = shims.Request;
    registry_Response = shims.Response;
    registry_Headers = shims.Headers;
    registry_FormData = shims.FormData;
    registry_Blob = shims.Blob;
    registry_File = shims.File;
    registry_ReadableStream = shims.ReadableStream;
    registry_getMultipartRequestOptions = shims.getMultipartRequestOptions;
    getDefaultAgent = shims.getDefaultAgent;
    fileFromPath = shims.fileFromPath;
    isFsReadStream = shims.isFsReadStream;
}
//# sourceMappingURL=registry.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/_shims/MultipartBody.mjs
/**
 * Disclaimer: modules in _shims aren't intended to be imported by SDK users.
 */
class MultipartBody {
    constructor(body) {
        this.body = body;
    }
    get [Symbol.toStringTag]() {
        return 'MultipartBody';
    }
}
//# sourceMappingURL=MultipartBody.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/_shims/web-runtime.mjs

function getRuntime({ manuallyImported } = {}) {
    const recommendation = manuallyImported ?
        `You may need to use polyfills`
        : `Add one of these imports before your first \`import … from 'openai'\`:
- \`import 'openai/shims/node'\` (if you're running on Node)
- \`import 'openai/shims/web'\` (otherwise)
`;
    let _fetch, _Request, _Response, _Headers;
    try {
        // @ts-ignore
        _fetch = fetch;
        // @ts-ignore
        _Request = Request;
        // @ts-ignore
        _Response = Response;
        // @ts-ignore
        _Headers = Headers;
    }
    catch (error) {
        throw new Error(`this environment is missing the following Web Fetch API type: ${error.message}. ${recommendation}`);
    }
    return {
        kind: 'web',
        fetch: _fetch,
        Request: _Request,
        Response: _Response,
        Headers: _Headers,
        FormData: 
        // @ts-ignore
        typeof FormData !== 'undefined' ? FormData : (class FormData {
            // @ts-ignore
            constructor() {
                throw new Error(`file uploads aren't supported in this environment yet as 'FormData' is undefined. ${recommendation}`);
            }
        }),
        Blob: typeof Blob !== 'undefined' ? Blob : (class Blob {
            constructor() {
                throw new Error(`file uploads aren't supported in this environment yet as 'Blob' is undefined. ${recommendation}`);
            }
        }),
        File: 
        // @ts-ignore
        typeof File !== 'undefined' ? File : (class File {
            // @ts-ignore
            constructor() {
                throw new Error(`file uploads aren't supported in this environment yet as 'File' is undefined. ${recommendation}`);
            }
        }),
        ReadableStream: 
        // @ts-ignore
        typeof ReadableStream !== 'undefined' ? ReadableStream : (class ReadableStream {
            // @ts-ignore
            constructor() {
                throw new Error(`streaming isn't supported in this environment yet as 'ReadableStream' is undefined. ${recommendation}`);
            }
        }),
        getMultipartRequestOptions: async (
        // @ts-ignore
        form, opts) => ({
            ...opts,
            body: new MultipartBody(form),
        }),
        getDefaultAgent: (url) => undefined,
        fileFromPath: () => {
            throw new Error('The `fileFromPath` function is only supported in Node. See the README for more details: https://www.github.com/openai/openai-node#file-uploads');
        },
        isFsReadStream: (value) => false,
    };
}
//# sourceMappingURL=web-runtime.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/_shims/index.mjs
/**
 * Disclaimer: modules in _shims aren't intended to be imported by SDK users.
 */


const init = () => {
  if (!kind) setShims(getRuntime(), { auto: true });
};


init();

;// CONCATENATED MODULE: ./node_modules/openai/error.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class error_OpenAIError extends Error {
}
class APIError extends error_OpenAIError {
    constructor(status, error, message, headers) {
        super(`${APIError.makeMessage(status, error, message)}`);
        this.status = status;
        this.headers = headers;
        this.request_id = headers?.['x-request-id'];
        this.error = error;
        const data = error;
        this.code = data?.['code'];
        this.param = data?.['param'];
        this.type = data?.['type'];
    }
    static makeMessage(status, error, message) {
        const msg = error?.message ?
            typeof error.message === 'string' ?
                error.message
                : JSON.stringify(error.message)
            : error ? JSON.stringify(error)
                : message;
        if (status && msg) {
            return `${status} ${msg}`;
        }
        if (status) {
            return `${status} status code (no body)`;
        }
        if (msg) {
            return msg;
        }
        return '(no status code or body)';
    }
    static generate(status, errorResponse, message, headers) {
        if (!status || !headers) {
            return new APIConnectionError({ message, cause: castToError(errorResponse) });
        }
        const error = errorResponse?.['error'];
        if (status === 400) {
            return new BadRequestError(status, error, message, headers);
        }
        if (status === 401) {
            return new AuthenticationError(status, error, message, headers);
        }
        if (status === 403) {
            return new PermissionDeniedError(status, error, message, headers);
        }
        if (status === 404) {
            return new NotFoundError(status, error, message, headers);
        }
        if (status === 409) {
            return new ConflictError(status, error, message, headers);
        }
        if (status === 422) {
            return new UnprocessableEntityError(status, error, message, headers);
        }
        if (status === 429) {
            return new RateLimitError(status, error, message, headers);
        }
        if (status >= 500) {
            return new InternalServerError(status, error, message, headers);
        }
        return new APIError(status, error, message, headers);
    }
}
class APIUserAbortError extends APIError {
    constructor({ message } = {}) {
        super(undefined, undefined, message || 'Request was aborted.', undefined);
    }
}
class APIConnectionError extends APIError {
    constructor({ message, cause }) {
        super(undefined, undefined, message || 'Connection error.', undefined);
        // in some environments the 'cause' property is already declared
        // @ts-ignore
        if (cause)
            this.cause = cause;
    }
}
class APIConnectionTimeoutError extends APIConnectionError {
    constructor({ message } = {}) {
        super({ message: message ?? 'Request timed out.' });
    }
}
class BadRequestError extends APIError {
}
class AuthenticationError extends APIError {
}
class PermissionDeniedError extends APIError {
}
class NotFoundError extends APIError {
}
class ConflictError extends APIError {
}
class UnprocessableEntityError extends APIError {
}
class RateLimitError extends APIError {
}
class InternalServerError extends APIError {
}
class LengthFinishReasonError extends error_OpenAIError {
    constructor() {
        super(`Could not parse response content as the length limit was reached`);
    }
}
class ContentFilterFinishReasonError extends error_OpenAIError {
    constructor() {
        super(`Could not parse response content as the request was rejected by the content filter`);
    }
}
//# sourceMappingURL=error.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/internal/decoders/line.mjs
/* provided dependency */ var Buffer = __webpack_require__(48287)["Buffer"];
var __classPrivateFieldSet = (undefined && undefined.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var __classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _LineDecoder_carriageReturnIndex;

/**
 * A re-implementation of httpx's `LineDecoder` in Python that handles incrementally
 * reading lines from text.
 *
 * https://github.com/encode/httpx/blob/920333ea98118e9cf617f246905d7b202510941c/httpx/_decoders.py#L258
 */
class LineDecoder {
    constructor() {
        _LineDecoder_carriageReturnIndex.set(this, void 0);
        this.buffer = new Uint8Array();
        __classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, null, "f");
    }
    decode(chunk) {
        if (chunk == null) {
            return [];
        }
        const binaryChunk = chunk instanceof ArrayBuffer ? new Uint8Array(chunk)
            : typeof chunk === 'string' ? new TextEncoder().encode(chunk)
                : chunk;
        let newData = new Uint8Array(this.buffer.length + binaryChunk.length);
        newData.set(this.buffer);
        newData.set(binaryChunk, this.buffer.length);
        this.buffer = newData;
        const lines = [];
        let patternIndex;
        while ((patternIndex = findNewlineIndex(this.buffer, __classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f"))) != null) {
            if (patternIndex.carriage && __classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") == null) {
                // skip until we either get a corresponding `\n`, a new `\r` or nothing
                __classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, patternIndex.index, "f");
                continue;
            }
            // we got double \r or \rtext\n
            if (__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") != null &&
                (patternIndex.index !== __classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") + 1 || patternIndex.carriage)) {
                lines.push(this.decodeText(this.buffer.slice(0, __classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") - 1)));
                this.buffer = this.buffer.slice(__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f"));
                __classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, null, "f");
                continue;
            }
            const endIndex = __classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") !== null ? patternIndex.preceding - 1 : patternIndex.preceding;
            const line = this.decodeText(this.buffer.slice(0, endIndex));
            lines.push(line);
            this.buffer = this.buffer.slice(patternIndex.index);
            __classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, null, "f");
        }
        return lines;
    }
    decodeText(bytes) {
        if (bytes == null)
            return '';
        if (typeof bytes === 'string')
            return bytes;
        // Node:
        if (typeof Buffer !== 'undefined') {
            if (bytes instanceof Buffer) {
                return bytes.toString();
            }
            if (bytes instanceof Uint8Array) {
                return Buffer.from(bytes).toString();
            }
            throw new error_OpenAIError(`Unexpected: received non-Uint8Array (${bytes.constructor.name}) stream chunk in an environment with a global "Buffer" defined, which this library assumes to be Node. Please report this error.`);
        }
        // Browser
        if (typeof TextDecoder !== 'undefined') {
            if (bytes instanceof Uint8Array || bytes instanceof ArrayBuffer) {
                this.textDecoder ?? (this.textDecoder = new TextDecoder('utf8'));
                return this.textDecoder.decode(bytes);
            }
            throw new error_OpenAIError(`Unexpected: received non-Uint8Array/ArrayBuffer (${bytes.constructor.name}) in a web platform. Please report this error.`);
        }
        throw new error_OpenAIError(`Unexpected: neither Buffer nor TextDecoder are available as globals. Please report this error.`);
    }
    flush() {
        if (!this.buffer.length) {
            return [];
        }
        return this.decode('\n');
    }
}
_LineDecoder_carriageReturnIndex = new WeakMap();
// prettier-ignore
LineDecoder.NEWLINE_CHARS = new Set(['\n', '\r']);
LineDecoder.NEWLINE_REGEXP = /\r\n|[\n\r]/g;
/**
 * This function searches the buffer for the end patterns, (\r or \n)
 * and returns an object with the index preceding the matched newline and the
 * index after the newline char. `null` is returned if no new line is found.
 *
 * ```ts
 * findNewLineIndex('abc\ndef') -> { preceding: 2, index: 3 }
 * ```
 */
function findNewlineIndex(buffer, startIndex) {
    const newline = 0x0a; // \n
    const carriage = 0x0d; // \r
    for (let i = startIndex ?? 0; i < buffer.length; i++) {
        if (buffer[i] === newline) {
            return { preceding: i, index: i + 1, carriage: false };
        }
        if (buffer[i] === carriage) {
            return { preceding: i, index: i + 1, carriage: true };
        }
    }
    return null;
}
function findDoubleNewlineIndex(buffer) {
    // This function searches the buffer for the end patterns (\r\r, \n\n, \r\n\r\n)
    // and returns the index right after the first occurrence of any pattern,
    // or -1 if none of the patterns are found.
    const newline = 0x0a; // \n
    const carriage = 0x0d; // \r
    for (let i = 0; i < buffer.length - 1; i++) {
        if (buffer[i] === newline && buffer[i + 1] === newline) {
            // \n\n
            return i + 2;
        }
        if (buffer[i] === carriage && buffer[i + 1] === carriage) {
            // \r\r
            return i + 2;
        }
        if (buffer[i] === carriage &&
            buffer[i + 1] === newline &&
            i + 3 < buffer.length &&
            buffer[i + 2] === carriage &&
            buffer[i + 3] === newline) {
            // \r\n\r\n
            return i + 4;
        }
    }
    return -1;
}
//# sourceMappingURL=line.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/internal/stream-utils.mjs
/**
 * Most browsers don't yet have async iterable support for ReadableStream,
 * and Node has a very different way of reading bytes from its "ReadableStream".
 *
 * This polyfill was pulled from https://github.com/MattiasBuelens/web-streams-polyfill/pull/122#issuecomment-1627354490
 */
function ReadableStreamToAsyncIterable(stream) {
    if (stream[Symbol.asyncIterator])
        return stream;
    const reader = stream.getReader();
    return {
        async next() {
            try {
                const result = await reader.read();
                if (result?.done)
                    reader.releaseLock(); // release lock when stream becomes closed
                return result;
            }
            catch (e) {
                reader.releaseLock(); // release lock when stream becomes errored
                throw e;
            }
        },
        async return() {
            const cancelPromise = reader.cancel();
            reader.releaseLock();
            await cancelPromise;
            return { done: true, value: undefined };
        },
        [Symbol.asyncIterator]() {
            return this;
        },
    };
}
//# sourceMappingURL=stream-utils.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/streaming.mjs






class Stream {
    constructor(iterator, controller) {
        this.iterator = iterator;
        this.controller = controller;
    }
    static fromSSEResponse(response, controller) {
        let consumed = false;
        async function* iterator() {
            if (consumed) {
                throw new Error('Cannot iterate over a consumed stream, use `.tee()` to split the stream.');
            }
            consumed = true;
            let done = false;
            try {
                for await (const sse of _iterSSEMessages(response, controller)) {
                    if (done)
                        continue;
                    if (sse.data.startsWith('[DONE]')) {
                        done = true;
                        continue;
                    }
                    if (sse.event === null ||
                        sse.event.startsWith('response.') ||
                        sse.event.startsWith('transcript.')) {
                        let data;
                        try {
                            data = JSON.parse(sse.data);
                        }
                        catch (e) {
                            console.error(`Could not parse message into JSON:`, sse.data);
                            console.error(`From chunk:`, sse.raw);
                            throw e;
                        }
                        if (data && data.error) {
                            throw new APIError(undefined, data.error, undefined, createResponseHeaders(response.headers));
                        }
                        yield data;
                    }
                    else {
                        let data;
                        try {
                            data = JSON.parse(sse.data);
                        }
                        catch (e) {
                            console.error(`Could not parse message into JSON:`, sse.data);
                            console.error(`From chunk:`, sse.raw);
                            throw e;
                        }
                        // TODO: Is this where the error should be thrown?
                        if (sse.event == 'error') {
                            throw new APIError(undefined, data.error, data.message, undefined);
                        }
                        yield { event: sse.event, data: data };
                    }
                }
                done = true;
            }
            catch (e) {
                // If the user calls `stream.controller.abort()`, we should exit without throwing.
                if (e instanceof Error && e.name === 'AbortError')
                    return;
                throw e;
            }
            finally {
                // If the user `break`s, abort the ongoing request.
                if (!done)
                    controller.abort();
            }
        }
        return new Stream(iterator, controller);
    }
    /**
     * Generates a Stream from a newline-separated ReadableStream
     * where each item is a JSON value.
     */
    static fromReadableStream(readableStream, controller) {
        let consumed = false;
        async function* iterLines() {
            const lineDecoder = new LineDecoder();
            const iter = ReadableStreamToAsyncIterable(readableStream);
            for await (const chunk of iter) {
                for (const line of lineDecoder.decode(chunk)) {
                    yield line;
                }
            }
            for (const line of lineDecoder.flush()) {
                yield line;
            }
        }
        async function* iterator() {
            if (consumed) {
                throw new Error('Cannot iterate over a consumed stream, use `.tee()` to split the stream.');
            }
            consumed = true;
            let done = false;
            try {
                for await (const line of iterLines()) {
                    if (done)
                        continue;
                    if (line)
                        yield JSON.parse(line);
                }
                done = true;
            }
            catch (e) {
                // If the user calls `stream.controller.abort()`, we should exit without throwing.
                if (e instanceof Error && e.name === 'AbortError')
                    return;
                throw e;
            }
            finally {
                // If the user `break`s, abort the ongoing request.
                if (!done)
                    controller.abort();
            }
        }
        return new Stream(iterator, controller);
    }
    [Symbol.asyncIterator]() {
        return this.iterator();
    }
    /**
     * Splits the stream into two streams which can be
     * independently read from at different speeds.
     */
    tee() {
        const left = [];
        const right = [];
        const iterator = this.iterator();
        const teeIterator = (queue) => {
            return {
                next: () => {
                    if (queue.length === 0) {
                        const result = iterator.next();
                        left.push(result);
                        right.push(result);
                    }
                    return queue.shift();
                },
            };
        };
        return [
            new Stream(() => teeIterator(left), this.controller),
            new Stream(() => teeIterator(right), this.controller),
        ];
    }
    /**
     * Converts this stream to a newline-separated ReadableStream of
     * JSON stringified values in the stream
     * which can be turned back into a Stream with `Stream.fromReadableStream()`.
     */
    toReadableStream() {
        const self = this;
        let iter;
        const encoder = new TextEncoder();
        return new registry_ReadableStream({
            async start() {
                iter = self[Symbol.asyncIterator]();
            },
            async pull(ctrl) {
                try {
                    const { value, done } = await iter.next();
                    if (done)
                        return ctrl.close();
                    const bytes = encoder.encode(JSON.stringify(value) + '\n');
                    ctrl.enqueue(bytes);
                }
                catch (err) {
                    ctrl.error(err);
                }
            },
            async cancel() {
                await iter.return?.();
            },
        });
    }
}
async function* _iterSSEMessages(response, controller) {
    if (!response.body) {
        controller.abort();
        throw new error_OpenAIError(`Attempted to iterate over a response with no body`);
    }
    const sseDecoder = new SSEDecoder();
    const lineDecoder = new LineDecoder();
    const iter = ReadableStreamToAsyncIterable(response.body);
    for await (const sseChunk of iterSSEChunks(iter)) {
        for (const line of lineDecoder.decode(sseChunk)) {
            const sse = sseDecoder.decode(line);
            if (sse)
                yield sse;
        }
    }
    for (const line of lineDecoder.flush()) {
        const sse = sseDecoder.decode(line);
        if (sse)
            yield sse;
    }
}
/**
 * Given an async iterable iterator, iterates over it and yields full
 * SSE chunks, i.e. yields when a double new-line is encountered.
 */
async function* iterSSEChunks(iterator) {
    let data = new Uint8Array();
    for await (const chunk of iterator) {
        if (chunk == null) {
            continue;
        }
        const binaryChunk = chunk instanceof ArrayBuffer ? new Uint8Array(chunk)
            : typeof chunk === 'string' ? new TextEncoder().encode(chunk)
                : chunk;
        let newData = new Uint8Array(data.length + binaryChunk.length);
        newData.set(data);
        newData.set(binaryChunk, data.length);
        data = newData;
        let patternIndex;
        while ((patternIndex = findDoubleNewlineIndex(data)) !== -1) {
            yield data.slice(0, patternIndex);
            data = data.slice(patternIndex);
        }
    }
    if (data.length > 0) {
        yield data;
    }
}
class SSEDecoder {
    constructor() {
        this.event = null;
        this.data = [];
        this.chunks = [];
    }
    decode(line) {
        if (line.endsWith('\r')) {
            line = line.substring(0, line.length - 1);
        }
        if (!line) {
            // empty line and we didn't previously encounter any messages
            if (!this.event && !this.data.length)
                return null;
            const sse = {
                event: this.event,
                data: this.data.join('\n'),
                raw: this.chunks,
            };
            this.event = null;
            this.data = [];
            this.chunks = [];
            return sse;
        }
        this.chunks.push(line);
        if (line.startsWith(':')) {
            return null;
        }
        let [fieldname, _, value] = partition(line, ':');
        if (value.startsWith(' ')) {
            value = value.substring(1);
        }
        if (fieldname === 'event') {
            this.event = value;
        }
        else if (fieldname === 'data') {
            this.data.push(value);
        }
        return null;
    }
}
function partition(str, delimiter) {
    const index = str.indexOf(delimiter);
    if (index !== -1) {
        return [str.substring(0, index), delimiter, str.substring(index + delimiter.length)];
    }
    return [str, '', ''];
}
//# sourceMappingURL=streaming.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/uploads.mjs
/* provided dependency */ var uploads_Buffer = __webpack_require__(48287)["Buffer"];


const isResponseLike = (value) => value != null &&
    typeof value === 'object' &&
    typeof value.url === 'string' &&
    typeof value.blob === 'function';
const isFileLike = (value) => value != null &&
    typeof value === 'object' &&
    typeof value.name === 'string' &&
    typeof value.lastModified === 'number' &&
    isBlobLike(value);
/**
 * The BlobLike type omits arrayBuffer() because @types/node-fetch@^2.6.4 lacks it; but this check
 * adds the arrayBuffer() method type because it is available and used at runtime
 */
const isBlobLike = (value) => value != null &&
    typeof value === 'object' &&
    typeof value.size === 'number' &&
    typeof value.type === 'string' &&
    typeof value.text === 'function' &&
    typeof value.slice === 'function' &&
    typeof value.arrayBuffer === 'function';
const isUploadable = (value) => {
    return isFileLike(value) || isResponseLike(value) || isFsReadStream(value);
};
/**
 * Helper for creating a {@link File} to pass to an SDK upload method from a variety of different data formats
 * @param value the raw content of the file.  Can be an {@link Uploadable}, {@link BlobLikePart}, or {@link AsyncIterable} of {@link BlobLikePart}s
 * @param {string=} name the name of the file. If omitted, toFile will try to determine a file name from bits if possible
 * @param {Object=} options additional properties
 * @param {string=} options.type the MIME type of the content
 * @param {number=} options.lastModified the last modified timestamp
 * @returns a {@link File} with the given properties
 */
async function toFile(value, name, options) {
    // If it's a promise, resolve it.
    value = await value;
    // If we've been given a `File` we don't need to do anything
    if (isFileLike(value)) {
        return value;
    }
    if (isResponseLike(value)) {
        const blob = await value.blob();
        name || (name = new URL(value.url).pathname.split(/[\\/]/).pop() ?? 'unknown_file');
        // we need to convert the `Blob` into an array buffer because the `Blob` class
        // that `node-fetch` defines is incompatible with the web standard which results
        // in `new File` interpreting it as a string instead of binary data.
        const data = isBlobLike(blob) ? [(await blob.arrayBuffer())] : [blob];
        return new registry_File(data, name, options);
    }
    const bits = await getBytes(value);
    name || (name = getName(value) ?? 'unknown_file');
    if (!options?.type) {
        const type = bits[0]?.type;
        if (typeof type === 'string') {
            options = { ...options, type };
        }
    }
    return new registry_File(bits, name, options);
}
async function getBytes(value) {
    let parts = [];
    if (typeof value === 'string' ||
        ArrayBuffer.isView(value) || // includes Uint8Array, Buffer, etc.
        value instanceof ArrayBuffer) {
        parts.push(value);
    }
    else if (isBlobLike(value)) {
        parts.push(await value.arrayBuffer());
    }
    else if (isAsyncIterableIterator(value) // includes Readable, ReadableStream, etc.
    ) {
        for await (const chunk of value) {
            parts.push(chunk); // TODO, consider validating?
        }
    }
    else {
        throw new Error(`Unexpected data type: ${typeof value}; constructor: ${value?.constructor
            ?.name}; props: ${propsForError(value)}`);
    }
    return parts;
}
function propsForError(value) {
    const props = Object.getOwnPropertyNames(value);
    return `[${props.map((p) => `"${p}"`).join(', ')}]`;
}
function getName(value) {
    return (getStringFromMaybeBuffer(value.name) ||
        getStringFromMaybeBuffer(value.filename) ||
        // For fs.ReadStream
        getStringFromMaybeBuffer(value.path)?.split(/[\\/]/).pop());
}
const getStringFromMaybeBuffer = (x) => {
    if (typeof x === 'string')
        return x;
    if (typeof uploads_Buffer !== 'undefined' && x instanceof uploads_Buffer)
        return String(x);
    return undefined;
};
const isAsyncIterableIterator = (value) => value != null && typeof value === 'object' && typeof value[Symbol.asyncIterator] === 'function';
const isMultipartBody = (body) => body && typeof body === 'object' && body.body && body[Symbol.toStringTag] === 'MultipartBody';
/**
 * Returns a multipart/form-data request if any part of the given request body contains a File / Blob value.
 * Otherwise returns the request as is.
 */
const maybeMultipartFormRequestOptions = async (opts) => {
    if (!hasUploadableValue(opts.body))
        return opts;
    const form = await createForm(opts.body);
    return getMultipartRequestOptions(form, opts);
};
const multipartFormRequestOptions = async (opts) => {
    const form = await createForm(opts.body);
    return registry_getMultipartRequestOptions(form, opts);
};
const createForm = async (body) => {
    const form = new registry_FormData();
    await Promise.all(Object.entries(body || {}).map(([key, value]) => addFormValue(form, key, value)));
    return form;
};
const hasUploadableValue = (value) => {
    if (isUploadable(value))
        return true;
    if (Array.isArray(value))
        return value.some(hasUploadableValue);
    if (value && typeof value === 'object') {
        for (const k in value) {
            if (hasUploadableValue(value[k]))
                return true;
        }
    }
    return false;
};
const addFormValue = async (form, key, value) => {
    if (value === undefined)
        return;
    if (value == null) {
        throw new TypeError(`Received null for "${key}"; to pass null in FormData, you must use the string 'null'`);
    }
    // TODO: make nested formats configurable
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
        form.append(key, String(value));
    }
    else if (isUploadable(value)) {
        const file = await toFile(value);
        form.append(key, file);
    }
    else if (Array.isArray(value)) {
        await Promise.all(value.map((entry) => addFormValue(form, key + '[]', entry)));
    }
    else if (typeof value === 'object') {
        await Promise.all(Object.entries(value).map(([name, prop]) => addFormValue(form, `${key}[${name}]`, prop)));
    }
    else {
        throw new TypeError(`Invalid value given to form, expected a string, number, boolean, object, Array, File or Blob but got ${value} instead`);
    }
};
//# sourceMappingURL=uploads.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/core.mjs
/* provided dependency */ var core_Buffer = __webpack_require__(48287)["Buffer"];
var core_classPrivateFieldSet = (undefined && undefined.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var core_classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _AbstractPage_client;




// try running side effects outside of _shims/index to workaround https://github.com/vercel/next.js/issues/76881
init();


async function defaultParseResponse(props) {
    const { response } = props;
    if (props.options.stream) {
        debug('response', response.status, response.url, response.headers, response.body);
        // Note: there is an invariant here that isn't represented in the type system
        // that if you set `stream: true` the response type must also be `Stream<T>`
        if (props.options.__streamClass) {
            return props.options.__streamClass.fromSSEResponse(response, props.controller);
        }
        return Stream.fromSSEResponse(response, props.controller);
    }
    // fetch refuses to read the body when the status code is 204.
    if (response.status === 204) {
        return null;
    }
    if (props.options.__binaryResponse) {
        return response;
    }
    const contentType = response.headers.get('content-type');
    const mediaType = contentType?.split(';')[0]?.trim();
    const isJSON = mediaType?.includes('application/json') || mediaType?.endsWith('+json');
    if (isJSON) {
        const json = await response.json();
        debug('response', response.status, response.url, response.headers, json);
        return _addRequestID(json, response);
    }
    const text = await response.text();
    debug('response', response.status, response.url, response.headers, text);
    // TODO handle blob, arraybuffer, other content types, etc.
    return text;
}
function _addRequestID(value, response) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
        return value;
    }
    return Object.defineProperty(value, '_request_id', {
        value: response.headers.get('x-request-id'),
        enumerable: false,
    });
}
/**
 * A subclass of `Promise` providing additional helper methods
 * for interacting with the SDK.
 */
class APIPromise extends Promise {
    constructor(responsePromise, parseResponse = defaultParseResponse) {
        super((resolve) => {
            // this is maybe a bit weird but this has to be a no-op to not implicitly
            // parse the response body; instead .then, .catch, .finally are overridden
            // to parse the response
            resolve(null);
        });
        this.responsePromise = responsePromise;
        this.parseResponse = parseResponse;
    }
    _thenUnwrap(transform) {
        return new APIPromise(this.responsePromise, async (props) => _addRequestID(transform(await this.parseResponse(props), props), props.response));
    }
    /**
     * Gets the raw `Response` instance instead of parsing the response
     * data.
     *
     * If you want to parse the response body but still get the `Response`
     * instance, you can use {@link withResponse()}.
     *
     * 👋 Getting the wrong TypeScript type for `Response`?
     * Try setting `"moduleResolution": "NodeNext"` if you can,
     * or add one of these imports before your first `import … from 'openai'`:
     * - `import 'openai/shims/node'` (if you're running on Node)
     * - `import 'openai/shims/web'` (otherwise)
     */
    asResponse() {
        return this.responsePromise.then((p) => p.response);
    }
    /**
     * Gets the parsed response data, the raw `Response` instance and the ID of the request,
     * returned via the X-Request-ID header which is useful for debugging requests and reporting
     * issues to OpenAI.
     *
     * If you just want to get the raw `Response` instance without parsing it,
     * you can use {@link asResponse()}.
     *
     *
     * 👋 Getting the wrong TypeScript type for `Response`?
     * Try setting `"moduleResolution": "NodeNext"` if you can,
     * or add one of these imports before your first `import … from 'openai'`:
     * - `import 'openai/shims/node'` (if you're running on Node)
     * - `import 'openai/shims/web'` (otherwise)
     */
    async withResponse() {
        const [data, response] = await Promise.all([this.parse(), this.asResponse()]);
        return { data, response, request_id: response.headers.get('x-request-id') };
    }
    parse() {
        if (!this.parsedPromise) {
            this.parsedPromise = this.responsePromise.then(this.parseResponse);
        }
        return this.parsedPromise;
    }
    then(onfulfilled, onrejected) {
        return this.parse().then(onfulfilled, onrejected);
    }
    catch(onrejected) {
        return this.parse().catch(onrejected);
    }
    finally(onfinally) {
        return this.parse().finally(onfinally);
    }
}
class APIClient {
    constructor({ baseURL, maxRetries = 2, timeout = 600000, // 10 minutes
    httpAgent, fetch: overriddenFetch, }) {
        this.baseURL = baseURL;
        this.maxRetries = validatePositiveInteger('maxRetries', maxRetries);
        this.timeout = validatePositiveInteger('timeout', timeout);
        this.httpAgent = httpAgent;
        this.fetch = overriddenFetch ?? registry_fetch;
    }
    authHeaders(opts) {
        return {};
    }
    /**
     * Override this to add your own default headers, for example:
     *
     *  {
     *    ...super.defaultHeaders(),
     *    Authorization: 'Bearer 123',
     *  }
     */
    defaultHeaders(opts) {
        return {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            'User-Agent': this.getUserAgent(),
            ...getPlatformHeaders(),
            ...this.authHeaders(opts),
        };
    }
    /**
     * Override this to add your own headers validation:
     */
    validateHeaders(headers, customHeaders) { }
    defaultIdempotencyKey() {
        return `stainless-node-retry-${uuid4()}`;
    }
    get(path, opts) {
        return this.methodRequest('get', path, opts);
    }
    post(path, opts) {
        return this.methodRequest('post', path, opts);
    }
    patch(path, opts) {
        return this.methodRequest('patch', path, opts);
    }
    put(path, opts) {
        return this.methodRequest('put', path, opts);
    }
    delete(path, opts) {
        return this.methodRequest('delete', path, opts);
    }
    methodRequest(method, path, opts) {
        return this.request(Promise.resolve(opts).then(async (opts) => {
            const body = opts && isBlobLike(opts?.body) ? new DataView(await opts.body.arrayBuffer())
                : opts?.body instanceof DataView ? opts.body
                    : opts?.body instanceof ArrayBuffer ? new DataView(opts.body)
                        : opts && ArrayBuffer.isView(opts?.body) ? new DataView(opts.body.buffer)
                            : opts?.body;
            return { method, path, ...opts, body };
        }));
    }
    getAPIList(path, Page, opts) {
        return this.requestAPIList(Page, { method: 'get', path, ...opts });
    }
    calculateContentLength(body) {
        if (typeof body === 'string') {
            if (typeof core_Buffer !== 'undefined') {
                return core_Buffer.byteLength(body, 'utf8').toString();
            }
            if (typeof TextEncoder !== 'undefined') {
                const encoder = new TextEncoder();
                const encoded = encoder.encode(body);
                return encoded.length.toString();
            }
        }
        else if (ArrayBuffer.isView(body)) {
            return body.byteLength.toString();
        }
        return null;
    }
    buildRequest(options, { retryCount = 0 } = {}) {
        options = { ...options };
        const { method, path, query, headers: headers = {} } = options;
        const body = ArrayBuffer.isView(options.body) || (options.__binaryRequest && typeof options.body === 'string') ?
            options.body
            : isMultipartBody(options.body) ? options.body.body
                : options.body ? JSON.stringify(options.body, null, 2)
                    : null;
        const contentLength = this.calculateContentLength(body);
        const url = this.buildURL(path, query);
        if ('timeout' in options)
            validatePositiveInteger('timeout', options.timeout);
        options.timeout = options.timeout ?? this.timeout;
        const httpAgent = options.httpAgent ?? this.httpAgent ?? getDefaultAgent(url);
        const minAgentTimeout = options.timeout + 1000;
        if (typeof httpAgent?.options?.timeout === 'number' &&
            minAgentTimeout > (httpAgent.options.timeout ?? 0)) {
            // Allow any given request to bump our agent active socket timeout.
            // This may seem strange, but leaking active sockets should be rare and not particularly problematic,
            // and without mutating agent we would need to create more of them.
            // This tradeoff optimizes for performance.
            httpAgent.options.timeout = minAgentTimeout;
        }
        if (this.idempotencyHeader && method !== 'get') {
            if (!options.idempotencyKey)
                options.idempotencyKey = this.defaultIdempotencyKey();
            headers[this.idempotencyHeader] = options.idempotencyKey;
        }
        const reqHeaders = this.buildHeaders({ options, headers, contentLength, retryCount });
        const req = {
            method,
            ...(body && { body: body }),
            headers: reqHeaders,
            ...(httpAgent && { agent: httpAgent }),
            // @ts-ignore node-fetch uses a custom AbortSignal type that is
            // not compatible with standard web types
            signal: options.signal ?? null,
        };
        return { req, url, timeout: options.timeout };
    }
    buildHeaders({ options, headers, contentLength, retryCount, }) {
        const reqHeaders = {};
        if (contentLength) {
            reqHeaders['content-length'] = contentLength;
        }
        const defaultHeaders = this.defaultHeaders(options);
        applyHeadersMut(reqHeaders, defaultHeaders);
        applyHeadersMut(reqHeaders, headers);
        // let builtin fetch set the Content-Type for multipart bodies
        if (isMultipartBody(options.body) && kind !== 'node') {
            delete reqHeaders['content-type'];
        }
        // Don't set theses headers if they were already set or removed through default headers or by the caller.
        // We check `defaultHeaders` and `headers`, which can contain nulls, instead of `reqHeaders` to account
        // for the removal case.
        if (getHeader(defaultHeaders, 'x-stainless-retry-count') === undefined &&
            getHeader(headers, 'x-stainless-retry-count') === undefined) {
            reqHeaders['x-stainless-retry-count'] = String(retryCount);
        }
        if (getHeader(defaultHeaders, 'x-stainless-timeout') === undefined &&
            getHeader(headers, 'x-stainless-timeout') === undefined &&
            options.timeout) {
            reqHeaders['x-stainless-timeout'] = String(options.timeout);
        }
        this.validateHeaders(reqHeaders, headers);
        return reqHeaders;
    }
    /**
     * Used as a callback for mutating the given `FinalRequestOptions` object.
     */
    async prepareOptions(options) { }
    /**
     * Used as a callback for mutating the given `RequestInit` object.
     *
     * This is useful for cases where you want to add certain headers based off of
     * the request properties, e.g. `method` or `url`.
     */
    async prepareRequest(request, { url, options }) { }
    parseHeaders(headers) {
        return (!headers ? {}
            : Symbol.iterator in headers ?
                Object.fromEntries(Array.from(headers).map((header) => [...header]))
                : { ...headers });
    }
    makeStatusError(status, error, message, headers) {
        return APIError.generate(status, error, message, headers);
    }
    request(options, remainingRetries = null) {
        return new APIPromise(this.makeRequest(options, remainingRetries));
    }
    async makeRequest(optionsInput, retriesRemaining) {
        const options = await optionsInput;
        const maxRetries = options.maxRetries ?? this.maxRetries;
        if (retriesRemaining == null) {
            retriesRemaining = maxRetries;
        }
        await this.prepareOptions(options);
        const { req, url, timeout } = this.buildRequest(options, { retryCount: maxRetries - retriesRemaining });
        await this.prepareRequest(req, { url, options });
        debug('request', url, options, req.headers);
        if (options.signal?.aborted) {
            throw new APIUserAbortError();
        }
        const controller = new AbortController();
        const response = await this.fetchWithTimeout(url, req, timeout, controller).catch(castToError);
        if (response instanceof Error) {
            if (options.signal?.aborted) {
                throw new APIUserAbortError();
            }
            if (retriesRemaining) {
                return this.retryRequest(options, retriesRemaining);
            }
            if (response.name === 'AbortError') {
                throw new APIConnectionTimeoutError();
            }
            throw new APIConnectionError({ cause: response });
        }
        const responseHeaders = createResponseHeaders(response.headers);
        if (!response.ok) {
            if (retriesRemaining && this.shouldRetry(response)) {
                const retryMessage = `retrying, ${retriesRemaining} attempts remaining`;
                debug(`response (error; ${retryMessage})`, response.status, url, responseHeaders);
                return this.retryRequest(options, retriesRemaining, responseHeaders);
            }
            const errText = await response.text().catch((e) => castToError(e).message);
            const errJSON = safeJSON(errText);
            const errMessage = errJSON ? undefined : errText;
            const retryMessage = retriesRemaining ? `(error; no more retries left)` : `(error; not retryable)`;
            debug(`response (error; ${retryMessage})`, response.status, url, responseHeaders, errMessage);
            const err = this.makeStatusError(response.status, errJSON, errMessage, responseHeaders);
            throw err;
        }
        return { response, options, controller };
    }
    requestAPIList(Page, options) {
        const request = this.makeRequest(options, null);
        return new PagePromise(this, request, Page);
    }
    buildURL(path, query) {
        const url = isAbsoluteURL(path) ?
            new URL(path)
            : new URL(this.baseURL + (this.baseURL.endsWith('/') && path.startsWith('/') ? path.slice(1) : path));
        const defaultQuery = this.defaultQuery();
        if (!isEmptyObj(defaultQuery)) {
            query = { ...defaultQuery, ...query };
        }
        if (typeof query === 'object' && query && !Array.isArray(query)) {
            url.search = this.stringifyQuery(query);
        }
        return url.toString();
    }
    stringifyQuery(query) {
        return Object.entries(query)
            .filter(([_, value]) => typeof value !== 'undefined')
            .map(([key, value]) => {
            if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
                return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
            }
            if (value === null) {
                return `${encodeURIComponent(key)}=`;
            }
            throw new error_OpenAIError(`Cannot stringify type ${typeof value}; Expected string, number, boolean, or null. If you need to pass nested query parameters, you can manually encode them, e.g. { query: { 'foo[key1]': value1, 'foo[key2]': value2 } }, and please open a GitHub issue requesting better support for your use case.`);
        })
            .join('&');
    }
    async fetchWithTimeout(url, init, ms, controller) {
        const { signal, ...options } = init || {};
        if (signal)
            signal.addEventListener('abort', () => controller.abort());
        const timeout = setTimeout(() => controller.abort(), ms);
        const fetchOptions = {
            signal: controller.signal,
            ...options,
        };
        if (fetchOptions.method) {
            // Custom methods like 'patch' need to be uppercased
            // See https://github.com/nodejs/undici/issues/2294
            fetchOptions.method = fetchOptions.method.toUpperCase();
        }
        return (
        // use undefined this binding; fetch errors if bound to something else in browser/cloudflare
        this.fetch.call(undefined, url, fetchOptions).finally(() => {
            clearTimeout(timeout);
        }));
    }
    shouldRetry(response) {
        // Note this is not a standard header.
        const shouldRetryHeader = response.headers.get('x-should-retry');
        // If the server explicitly says whether or not to retry, obey.
        if (shouldRetryHeader === 'true')
            return true;
        if (shouldRetryHeader === 'false')
            return false;
        // Retry on request timeouts.
        if (response.status === 408)
            return true;
        // Retry on lock timeouts.
        if (response.status === 409)
            return true;
        // Retry on rate limits.
        if (response.status === 429)
            return true;
        // Retry internal errors.
        if (response.status >= 500)
            return true;
        return false;
    }
    async retryRequest(options, retriesRemaining, responseHeaders) {
        let timeoutMillis;
        // Note the `retry-after-ms` header may not be standard, but is a good idea and we'd like proactive support for it.
        const retryAfterMillisHeader = responseHeaders?.['retry-after-ms'];
        if (retryAfterMillisHeader) {
            const timeoutMs = parseFloat(retryAfterMillisHeader);
            if (!Number.isNaN(timeoutMs)) {
                timeoutMillis = timeoutMs;
            }
        }
        // About the Retry-After header: https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Retry-After
        const retryAfterHeader = responseHeaders?.['retry-after'];
        if (retryAfterHeader && !timeoutMillis) {
            const timeoutSeconds = parseFloat(retryAfterHeader);
            if (!Number.isNaN(timeoutSeconds)) {
                timeoutMillis = timeoutSeconds * 1000;
            }
            else {
                timeoutMillis = Date.parse(retryAfterHeader) - Date.now();
            }
        }
        // If the API asks us to wait a certain amount of time (and it's a reasonable amount),
        // just do what it says, but otherwise calculate a default
        if (!(timeoutMillis && 0 <= timeoutMillis && timeoutMillis < 60 * 1000)) {
            const maxRetries = options.maxRetries ?? this.maxRetries;
            timeoutMillis = this.calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries);
        }
        await sleep(timeoutMillis);
        return this.makeRequest(options, retriesRemaining - 1);
    }
    calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries) {
        const initialRetryDelay = 0.5;
        const maxRetryDelay = 8.0;
        const numRetries = maxRetries - retriesRemaining;
        // Apply exponential backoff, but not more than the max.
        const sleepSeconds = Math.min(initialRetryDelay * Math.pow(2, numRetries), maxRetryDelay);
        // Apply some jitter, take up to at most 25 percent of the retry time.
        const jitter = 1 - Math.random() * 0.25;
        return sleepSeconds * jitter * 1000;
    }
    getUserAgent() {
        return `${this.constructor.name}/JS ${version.VERSION}`;
    }
}
class AbstractPage {
    constructor(client, response, body, options) {
        _AbstractPage_client.set(this, void 0);
        core_classPrivateFieldSet(this, _AbstractPage_client, client, "f");
        this.options = options;
        this.response = response;
        this.body = body;
    }
    hasNextPage() {
        const items = this.getPaginatedItems();
        if (!items.length)
            return false;
        return this.nextPageInfo() != null;
    }
    async getNextPage() {
        const nextInfo = this.nextPageInfo();
        if (!nextInfo) {
            throw new error_OpenAIError('No next page expected; please check `.hasNextPage()` before calling `.getNextPage()`.');
        }
        const nextOptions = { ...this.options };
        if ('params' in nextInfo && typeof nextOptions.query === 'object') {
            nextOptions.query = { ...nextOptions.query, ...nextInfo.params };
        }
        else if ('url' in nextInfo) {
            const params = [...Object.entries(nextOptions.query || {}), ...nextInfo.url.searchParams.entries()];
            for (const [key, value] of params) {
                nextInfo.url.searchParams.set(key, value);
            }
            nextOptions.query = undefined;
            nextOptions.path = nextInfo.url.toString();
        }
        return await core_classPrivateFieldGet(this, _AbstractPage_client, "f").requestAPIList(this.constructor, nextOptions);
    }
    async *iterPages() {
        // eslint-disable-next-line @typescript-eslint/no-this-alias
        let page = this;
        yield page;
        while (page.hasNextPage()) {
            page = await page.getNextPage();
            yield page;
        }
    }
    async *[(_AbstractPage_client = new WeakMap(), Symbol.asyncIterator)]() {
        for await (const page of this.iterPages()) {
            for (const item of page.getPaginatedItems()) {
                yield item;
            }
        }
    }
}
/**
 * This subclass of Promise will resolve to an instantiated Page once the request completes.
 *
 * It also implements AsyncIterable to allow auto-paginating iteration on an unawaited list call, eg:
 *
 *    for await (const item of client.items.list()) {
 *      console.log(item)
 *    }
 */
class PagePromise extends APIPromise {
    constructor(client, request, Page) {
        super(request, async (props) => new Page(client, props.response, await defaultParseResponse(props), props.options));
    }
    /**
     * Allow auto-paginating iteration on an unawaited list call, eg:
     *
     *    for await (const item of client.items.list()) {
     *      console.log(item)
     *    }
     */
    async *[Symbol.asyncIterator]() {
        const page = await this;
        for await (const item of page) {
            yield item;
        }
    }
}
const createResponseHeaders = (headers) => {
    return new Proxy(Object.fromEntries(
    // @ts-ignore
    headers.entries()), {
        get(target, name) {
            const key = name.toString();
            return target[key.toLowerCase()] || target[key];
        },
    });
};
// This is required so that we can determine if a given object matches the RequestOptions
// type at runtime. While this requires duplication, it is enforced by the TypeScript
// compiler such that any missing / extraneous keys will cause an error.
const requestOptionsKeys = {
    method: true,
    path: true,
    query: true,
    body: true,
    headers: true,
    maxRetries: true,
    stream: true,
    timeout: true,
    httpAgent: true,
    signal: true,
    idempotencyKey: true,
    __metadata: true,
    __binaryRequest: true,
    __binaryResponse: true,
    __streamClass: true,
};
const isRequestOptions = (obj) => {
    return (typeof obj === 'object' &&
        obj !== null &&
        !isEmptyObj(obj) &&
        Object.keys(obj).every((k) => hasOwn(requestOptionsKeys, k)));
};
const getPlatformProperties = () => {
    if (typeof Deno !== 'undefined' && Deno.build != null) {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': version.VERSION,
            'X-Stainless-OS': normalizePlatform(Deno.build.os),
            'X-Stainless-Arch': normalizeArch(Deno.build.arch),
            'X-Stainless-Runtime': 'deno',
            'X-Stainless-Runtime-Version': typeof Deno.version === 'string' ? Deno.version : Deno.version?.deno ?? 'unknown',
        };
    }
    if (typeof EdgeRuntime !== 'undefined') {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': version.VERSION,
            'X-Stainless-OS': 'Unknown',
            'X-Stainless-Arch': `other:${EdgeRuntime}`,
            'X-Stainless-Runtime': 'edge',
            'X-Stainless-Runtime-Version': process.version,
        };
    }
    // Check if Node.js
    if (Object.prototype.toString.call(typeof process !== 'undefined' ? process : 0) === '[object process]') {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': version.VERSION,
            'X-Stainless-OS': normalizePlatform(process.platform),
            'X-Stainless-Arch': normalizeArch(process.arch),
            'X-Stainless-Runtime': 'node',
            'X-Stainless-Runtime-Version': process.version,
        };
    }
    const browserInfo = getBrowserInfo();
    if (browserInfo) {
        return {
            'X-Stainless-Lang': 'js',
            'X-Stainless-Package-Version': version.VERSION,
            'X-Stainless-OS': 'Unknown',
            'X-Stainless-Arch': 'unknown',
            'X-Stainless-Runtime': `browser:${browserInfo.browser}`,
            'X-Stainless-Runtime-Version': browserInfo.version,
        };
    }
    // TODO add support for Cloudflare workers, etc.
    return {
        'X-Stainless-Lang': 'js',
        'X-Stainless-Package-Version': version.VERSION,
        'X-Stainless-OS': 'Unknown',
        'X-Stainless-Arch': 'unknown',
        'X-Stainless-Runtime': 'unknown',
        'X-Stainless-Runtime-Version': 'unknown',
    };
};
// Note: modified from https://github.com/JS-DevTools/host-environment/blob/b1ab79ecde37db5d6e163c050e54fe7d287d7c92/src/isomorphic.browser.ts
function getBrowserInfo() {
    if (typeof navigator === 'undefined' || !navigator) {
        return null;
    }
    // NOTE: The order matters here!
    const browserPatterns = [
        { key: 'edge', pattern: /Edge(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'ie', pattern: /MSIE(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'ie', pattern: /Trident(?:.*rv\:(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'chrome', pattern: /Chrome(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'firefox', pattern: /Firefox(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: 'safari', pattern: /(?:Version\W+(\d+)\.(\d+)(?:\.(\d+))?)?(?:\W+Mobile\S*)?\W+Safari/ },
    ];
    // Find the FIRST matching browser
    for (const { key, pattern } of browserPatterns) {
        const match = pattern.exec(navigator.userAgent);
        if (match) {
            const major = match[1] || 0;
            const minor = match[2] || 0;
            const patch = match[3] || 0;
            return { browser: key, version: `${major}.${minor}.${patch}` };
        }
    }
    return null;
}
const normalizeArch = (arch) => {
    // Node docs:
    // - https://nodejs.org/api/process.html#processarch
    // Deno docs:
    // - https://doc.deno.land/deno/stable/~/Deno.build
    if (arch === 'x32')
        return 'x32';
    if (arch === 'x86_64' || arch === 'x64')
        return 'x64';
    if (arch === 'arm')
        return 'arm';
    if (arch === 'aarch64' || arch === 'arm64')
        return 'arm64';
    if (arch)
        return `other:${arch}`;
    return 'unknown';
};
const normalizePlatform = (platform) => {
    // Node platforms:
    // - https://nodejs.org/api/process.html#processplatform
    // Deno platforms:
    // - https://doc.deno.land/deno/stable/~/Deno.build
    // - https://github.com/denoland/deno/issues/14799
    platform = platform.toLowerCase();
    // NOTE: this iOS check is untested and may not work
    // Node does not work natively on IOS, there is a fork at
    // https://github.com/nodejs-mobile/nodejs-mobile
    // however it is unknown at the time of writing how to detect if it is running
    if (platform.includes('ios'))
        return 'iOS';
    if (platform === 'android')
        return 'Android';
    if (platform === 'darwin')
        return 'MacOS';
    if (platform === 'win32')
        return 'Windows';
    if (platform === 'freebsd')
        return 'FreeBSD';
    if (platform === 'openbsd')
        return 'OpenBSD';
    if (platform === 'linux')
        return 'Linux';
    if (platform)
        return `Other:${platform}`;
    return 'Unknown';
};
let _platformHeaders;
const getPlatformHeaders = () => {
    return (_platformHeaders ?? (_platformHeaders = getPlatformProperties()));
};
const safeJSON = (text) => {
    try {
        return JSON.parse(text);
    }
    catch (err) {
        return undefined;
    }
};
// https://url.spec.whatwg.org/#url-scheme-string
const startsWithSchemeRegexp = /^[a-z][a-z0-9+.-]*:/i;
const isAbsoluteURL = (url) => {
    return startsWithSchemeRegexp.test(url);
};
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const validatePositiveInteger = (name, n) => {
    if (typeof n !== 'number' || !Number.isInteger(n)) {
        throw new error_OpenAIError(`${name} must be an integer`);
    }
    if (n < 0) {
        throw new error_OpenAIError(`${name} must be a positive integer`);
    }
    return n;
};
const castToError = (err) => {
    if (err instanceof Error)
        return err;
    if (typeof err === 'object' && err !== null) {
        try {
            return new Error(JSON.stringify(err));
        }
        catch { }
    }
    return new Error(err);
};
const ensurePresent = (value) => {
    if (value == null)
        throw new OpenAIError(`Expected a value to be given but received ${value} instead.`);
    return value;
};
/**
 * Read an environment variable.
 *
 * Trims beginning and trailing whitespace.
 *
 * Will return undefined if the environment variable doesn't exist or cannot be accessed.
 */
const readEnv = (env) => {
    if (typeof process !== 'undefined') {
        return {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}?.[env]?.trim() ?? undefined;
    }
    if (typeof Deno !== 'undefined') {
        return Deno.env?.get?.(env)?.trim();
    }
    return undefined;
};
const coerceInteger = (value) => {
    if (typeof value === 'number')
        return Math.round(value);
    if (typeof value === 'string')
        return parseInt(value, 10);
    throw new OpenAIError(`Could not coerce ${value} (type: ${typeof value}) into a number`);
};
const coerceFloat = (value) => {
    if (typeof value === 'number')
        return value;
    if (typeof value === 'string')
        return parseFloat(value);
    throw new OpenAIError(`Could not coerce ${value} (type: ${typeof value}) into a number`);
};
const coerceBoolean = (value) => {
    if (typeof value === 'boolean')
        return value;
    if (typeof value === 'string')
        return value === 'true';
    return Boolean(value);
};
const maybeCoerceInteger = (value) => {
    if (value === undefined) {
        return undefined;
    }
    return coerceInteger(value);
};
const maybeCoerceFloat = (value) => {
    if (value === undefined) {
        return undefined;
    }
    return coerceFloat(value);
};
const maybeCoerceBoolean = (value) => {
    if (value === undefined) {
        return undefined;
    }
    return coerceBoolean(value);
};
// https://stackoverflow.com/a/34491287
function isEmptyObj(obj) {
    if (!obj)
        return true;
    for (const _k in obj)
        return false;
    return true;
}
// https://eslint.org/docs/latest/rules/no-prototype-builtins
function hasOwn(obj, key) {
    return Object.prototype.hasOwnProperty.call(obj, key);
}
/**
 * Copies headers from "newHeaders" onto "targetHeaders",
 * using lower-case for all properties,
 * ignoring any keys with undefined values,
 * and deleting any keys with null values.
 */
function applyHeadersMut(targetHeaders, newHeaders) {
    for (const k in newHeaders) {
        if (!hasOwn(newHeaders, k))
            continue;
        const lowerKey = k.toLowerCase();
        if (!lowerKey)
            continue;
        const val = newHeaders[k];
        if (val === null) {
            delete targetHeaders[lowerKey];
        }
        else if (val !== undefined) {
            targetHeaders[lowerKey] = val;
        }
    }
}
const SENSITIVE_HEADERS = new Set(['authorization', 'api-key']);
function debug(action, ...args) {
    if (typeof process !== 'undefined' && {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}?.['DEBUG'] === 'true') {
        const modifiedArgs = args.map((arg) => {
            if (!arg) {
                return arg;
            }
            // Check for sensitive headers in request body 'headers' object
            if (arg['headers']) {
                // clone so we don't mutate
                const modifiedArg = { ...arg, headers: { ...arg['headers'] } };
                for (const header in arg['headers']) {
                    if (SENSITIVE_HEADERS.has(header.toLowerCase())) {
                        modifiedArg['headers'][header] = 'REDACTED';
                    }
                }
                return modifiedArg;
            }
            let modifiedArg = null;
            // Check for sensitive headers in headers object
            for (const header in arg) {
                if (SENSITIVE_HEADERS.has(header.toLowerCase())) {
                    // avoid making a copy until we need to
                    modifiedArg ?? (modifiedArg = { ...arg });
                    modifiedArg[header] = 'REDACTED';
                }
            }
            return modifiedArg ?? arg;
        });
        console.log(`OpenAI:DEBUG:${action}`, ...modifiedArgs);
    }
}
/**
 * https://stackoverflow.com/a/2117523
 */
const uuid4 = () => {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = (Math.random() * 16) | 0;
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    });
};
const isRunningInBrowser = () => {
    return (
    // @ts-ignore
    typeof window !== 'undefined' &&
        // @ts-ignore
        typeof window.document !== 'undefined' &&
        // @ts-ignore
        typeof navigator !== 'undefined');
};
const isHeadersProtocol = (headers) => {
    return typeof headers?.get === 'function';
};
const getRequiredHeader = (headers, header) => {
    const foundHeader = getHeader(headers, header);
    if (foundHeader === undefined) {
        throw new Error(`Could not find ${header} header`);
    }
    return foundHeader;
};
const getHeader = (headers, header) => {
    const lowerCasedHeader = header.toLowerCase();
    if (isHeadersProtocol(headers)) {
        // to deal with the case where the header looks like Stainless-Event-Id
        const intercapsHeader = header[0]?.toUpperCase() +
            header.substring(1).replace(/([^\w])(\w)/g, (_m, g1, g2) => g1 + g2.toUpperCase());
        for (const key of [header, lowerCasedHeader, header.toUpperCase(), intercapsHeader]) {
            const value = headers.get(key);
            if (value) {
                return value;
            }
        }
    }
    for (const [key, value] of Object.entries(headers)) {
        if (key.toLowerCase() === lowerCasedHeader) {
            if (Array.isArray(value)) {
                if (value.length <= 1)
                    return value[0];
                console.warn(`Received ${value.length} entries for the ${header} header, using the first entry.`);
                return value[0];
            }
            return value;
        }
    }
    return undefined;
};
/**
 * Encodes a string to Base64 format.
 */
const toBase64 = (str) => {
    if (!str)
        return '';
    if (typeof core_Buffer !== 'undefined') {
        return core_Buffer.from(str).toString('base64');
    }
    if (typeof btoa !== 'undefined') {
        return btoa(str);
    }
    throw new OpenAIError('Cannot generate b64 string; Expected `Buffer` or `btoa` to be defined');
};
/**
 * Converts a Base64 encoded string to a Float32Array.
 * @param base64Str - The Base64 encoded string.
 * @returns An Array of numbers interpreted as Float32 values.
 */
const toFloat32Array = (base64Str) => {
    if (typeof core_Buffer !== 'undefined') {
        // for Node.js environment
        return Array.from(new Float32Array(core_Buffer.from(base64Str, 'base64').buffer));
    }
    else {
        // for legacy web platform APIs
        const binaryStr = atob(base64Str);
        const len = binaryStr.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binaryStr.charCodeAt(i);
        }
        return Array.from(new Float32Array(bytes.buffer));
    }
};
function isObj(obj) {
    return obj != null && typeof obj === 'object' && !Array.isArray(obj);
}
//# sourceMappingURL=core.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resource.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
class APIResource {
    constructor(client) {
        this._client = client;
    }
}
//# sourceMappingURL=resource.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/completions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class Completions extends APIResource {
    create(body, options) {
        return this._client.post('/completions', { body, ...options, stream: body.stream ?? false });
    }
}
//# sourceMappingURL=completions.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/chat/completions/messages.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class Messages extends APIResource {
    list(completionId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(completionId, {}, query);
        }
        return this._client.getAPIList(`/chat/completions/${completionId}/messages`, ChatCompletionStoreMessagesPage, { query, ...options });
    }
}

//# sourceMappingURL=messages.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/pagination.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

/**
 * Note: no pagination actually occurs yet, this is for forwards-compatibility.
 */
class Page extends AbstractPage {
    constructor(client, response, body, options) {
        super(client, response, body, options);
        this.data = body.data || [];
        this.object = body.object;
    }
    getPaginatedItems() {
        return this.data ?? [];
    }
    // @deprecated Please use `nextPageInfo()` instead
    /**
     * This page represents a response that isn't actually paginated at the API level
     * so there will never be any next page params.
     */
    nextPageParams() {
        return null;
    }
    nextPageInfo() {
        return null;
    }
}
class CursorPage extends AbstractPage {
    constructor(client, response, body, options) {
        super(client, response, body, options);
        this.data = body.data || [];
        this.has_more = body.has_more || false;
    }
    getPaginatedItems() {
        return this.data ?? [];
    }
    hasNextPage() {
        if (this.has_more === false) {
            return false;
        }
        return super.hasNextPage();
    }
    // @deprecated Please use `nextPageInfo()` instead
    nextPageParams() {
        const info = this.nextPageInfo();
        if (!info)
            return null;
        if ('params' in info)
            return info.params;
        const params = Object.fromEntries(info.url.searchParams);
        if (!Object.keys(params).length)
            return null;
        return params;
    }
    nextPageInfo() {
        const data = this.getPaginatedItems();
        if (!data.length) {
            return null;
        }
        const id = data[data.length - 1]?.id;
        if (!id) {
            return null;
        }
        return { params: { after: id } };
    }
}
//# sourceMappingURL=pagination.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/chat/completions/completions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.





class completions_Completions extends APIResource {
    constructor() {
        super(...arguments);
        this.messages = new Messages(this._client);
    }
    create(body, options) {
        return this._client.post('/chat/completions', { body, ...options, stream: body.stream ?? false });
    }
    /**
     * Get a stored chat completion. Only Chat Completions that have been created with
     * the `store` parameter set to `true` will be returned.
     */
    retrieve(completionId, options) {
        return this._client.get(`/chat/completions/${completionId}`, options);
    }
    /**
     * Modify a stored chat completion. Only Chat Completions that have been created
     * with the `store` parameter set to `true` can be modified. Currently, the only
     * supported modification is to update the `metadata` field.
     */
    update(completionId, body, options) {
        return this._client.post(`/chat/completions/${completionId}`, { body, ...options });
    }
    list(query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list({}, query);
        }
        return this._client.getAPIList('/chat/completions', ChatCompletionsPage, { query, ...options });
    }
    /**
     * Delete a stored chat completion. Only Chat Completions that have been created
     * with the `store` parameter set to `true` can be deleted.
     */
    del(completionId, options) {
        return this._client.delete(`/chat/completions/${completionId}`, options);
    }
}
class ChatCompletionsPage extends CursorPage {
}
class ChatCompletionStoreMessagesPage extends CursorPage {
}
completions_Completions.ChatCompletionsPage = ChatCompletionsPage;
completions_Completions.Messages = Messages;
//# sourceMappingURL=completions.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/chat/chat.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class Chat extends APIResource {
    constructor() {
        super(...arguments);
        this.completions = new completions_Completions(this._client);
    }
}
Chat.Completions = completions_Completions;
Chat.ChatCompletionsPage = ChatCompletionsPage;
//# sourceMappingURL=chat.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/embeddings.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class Embeddings extends APIResource {
    /**
     * Creates an embedding vector representing the input text.
     */
    create(body, options) {
        const hasUserProvidedEncodingFormat = !!body.encoding_format;
        // No encoding_format specified, defaulting to base64 for performance reasons
        // See https://github.com/openai/openai-node/pull/1312
        let encoding_format = hasUserProvidedEncodingFormat ? body.encoding_format : 'base64';
        if (hasUserProvidedEncodingFormat) {
            debug('Request', 'User defined encoding_format:', body.encoding_format);
        }
        const response = this._client.post('/embeddings', {
            body: {
                ...body,
                encoding_format: encoding_format,
            },
            ...options,
        });
        // if the user specified an encoding_format, return the response as-is
        if (hasUserProvidedEncodingFormat) {
            return response;
        }
        // in this stage, we are sure the user did not specify an encoding_format
        // and we defaulted to base64 for performance reasons
        // we are sure then that the response is base64 encoded, let's decode it
        // the returned result will be a float32 array since this is OpenAI API's default encoding
        debug('response', 'Decoding base64 embeddings to float32 array');
        return response._thenUnwrap((response) => {
            if (response && response.data) {
                response.data.forEach((embeddingBase64Obj) => {
                    const embeddingBase64Str = embeddingBase64Obj.embedding;
                    embeddingBase64Obj.embedding = toFloat32Array(embeddingBase64Str);
                });
            }
            return response;
        });
    }
}
//# sourceMappingURL=embeddings.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/files.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.






class Files extends APIResource {
    /**
     * Upload a file that can be used across various endpoints. Individual files can be
     * up to 512 MB, and the size of all files uploaded by one organization can be up
     * to 100 GB.
     *
     * The Assistants API supports files up to 2 million tokens and of specific file
     * types. See the
     * [Assistants Tools guide](https://platform.openai.com/docs/assistants/tools) for
     * details.
     *
     * The Fine-tuning API only supports `.jsonl` files. The input also has certain
     * required formats for fine-tuning
     * [chat](https://platform.openai.com/docs/api-reference/fine-tuning/chat-input) or
     * [completions](https://platform.openai.com/docs/api-reference/fine-tuning/completions-input)
     * models.
     *
     * The Batch API only supports `.jsonl` files up to 200 MB in size. The input also
     * has a specific required
     * [format](https://platform.openai.com/docs/api-reference/batch/request-input).
     *
     * Please [contact us](https://help.openai.com/) if you need to increase these
     * storage limits.
     */
    create(body, options) {
        return this._client.post('/files', multipartFormRequestOptions({ body, ...options }));
    }
    /**
     * Returns information about a specific file.
     */
    retrieve(fileId, options) {
        return this._client.get(`/files/${fileId}`, options);
    }
    list(query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list({}, query);
        }
        return this._client.getAPIList('/files', FileObjectsPage, { query, ...options });
    }
    /**
     * Delete a file.
     */
    del(fileId, options) {
        return this._client.delete(`/files/${fileId}`, options);
    }
    /**
     * Returns the contents of the specified file.
     */
    content(fileId, options) {
        return this._client.get(`/files/${fileId}/content`, {
            ...options,
            headers: { Accept: 'application/binary', ...options?.headers },
            __binaryResponse: true,
        });
    }
    /**
     * Returns the contents of the specified file.
     *
     * @deprecated The `.content()` method should be used instead
     */
    retrieveContent(fileId, options) {
        return this._client.get(`/files/${fileId}/content`, options);
    }
    /**
     * Waits for the given file to be processed, default timeout is 30 mins.
     */
    async waitForProcessing(id, { pollInterval = 5000, maxWait = 30 * 60 * 1000 } = {}) {
        const TERMINAL_STATES = new Set(['processed', 'error', 'deleted']);
        const start = Date.now();
        let file = await this.retrieve(id);
        while (!file.status || !TERMINAL_STATES.has(file.status)) {
            await sleep(pollInterval);
            file = await this.retrieve(id);
            if (Date.now() - start > maxWait) {
                throw new APIConnectionTimeoutError({
                    message: `Giving up on waiting for file ${id} to finish processing after ${maxWait} milliseconds.`,
                });
            }
        }
        return file;
    }
}
class FileObjectsPage extends CursorPage {
}
Files.FileObjectsPage = FileObjectsPage;
//# sourceMappingURL=files.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/images.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class Images extends APIResource {
    /**
     * Creates a variation of a given image.
     */
    createVariation(body, options) {
        return this._client.post('/images/variations', multipartFormRequestOptions({ body, ...options }));
    }
    /**
     * Creates an edited or extended image given an original image and a prompt.
     */
    edit(body, options) {
        return this._client.post('/images/edits', multipartFormRequestOptions({ body, ...options }));
    }
    /**
     * Creates an image given a prompt.
     */
    generate(body, options) {
        return this._client.post('/images/generations', { body, ...options });
    }
}
//# sourceMappingURL=images.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/audio/speech.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class Speech extends APIResource {
    /**
     * Generates audio from the input text.
     */
    create(body, options) {
        return this._client.post('/audio/speech', {
            body,
            ...options,
            headers: { Accept: 'application/octet-stream', ...options?.headers },
            __binaryResponse: true,
        });
    }
}
//# sourceMappingURL=speech.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/audio/transcriptions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class Transcriptions extends APIResource {
    create(body, options) {
        return this._client.post('/audio/transcriptions', multipartFormRequestOptions({
            body,
            ...options,
            stream: body.stream ?? false,
            __metadata: { model: body.model },
        }));
    }
}
//# sourceMappingURL=transcriptions.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/audio/translations.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class Translations extends APIResource {
    create(body, options) {
        return this._client.post('/audio/translations', multipartFormRequestOptions({ body, ...options, __metadata: { model: body.model } }));
    }
}
//# sourceMappingURL=translations.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/audio/audio.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.







class Audio extends APIResource {
    constructor() {
        super(...arguments);
        this.transcriptions = new Transcriptions(this._client);
        this.translations = new Translations(this._client);
        this.speech = new Speech(this._client);
    }
}
Audio.Transcriptions = Transcriptions;
Audio.Translations = Translations;
Audio.Speech = Speech;
//# sourceMappingURL=audio.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/moderations.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class Moderations extends APIResource {
    /**
     * Classifies if text and/or image inputs are potentially harmful. Learn more in
     * the [moderation guide](https://platform.openai.com/docs/guides/moderation).
     */
    create(body, options) {
        return this._client.post('/moderations', { body, ...options });
    }
}
//# sourceMappingURL=moderations.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/models.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class Models extends APIResource {
    /**
     * Retrieves a model instance, providing basic information about the model such as
     * the owner and permissioning.
     */
    retrieve(model, options) {
        return this._client.get(`/models/${model}`, options);
    }
    /**
     * Lists the currently available models, and provides basic information about each
     * one such as the owner and availability.
     */
    list(options) {
        return this._client.getAPIList('/models', ModelsPage, options);
    }
    /**
     * Delete a fine-tuned model. You must have the Owner role in your organization to
     * delete a model.
     */
    del(model, options) {
        return this._client.delete(`/models/${model}`, options);
    }
}
/**
 * Note: no pagination actually occurs yet, this is for forwards-compatibility.
 */
class ModelsPage extends Page {
}
Models.ModelsPage = ModelsPage;
//# sourceMappingURL=models.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/fine-tuning/jobs/checkpoints.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class Checkpoints extends APIResource {
    list(fineTuningJobId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(fineTuningJobId, {}, query);
        }
        return this._client.getAPIList(`/fine_tuning/jobs/${fineTuningJobId}/checkpoints`, FineTuningJobCheckpointsPage, { query, ...options });
    }
}
class FineTuningJobCheckpointsPage extends CursorPage {
}
Checkpoints.FineTuningJobCheckpointsPage = FineTuningJobCheckpointsPage;
//# sourceMappingURL=checkpoints.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/fine-tuning/jobs/jobs.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.





class Jobs extends APIResource {
    constructor() {
        super(...arguments);
        this.checkpoints = new Checkpoints(this._client);
    }
    /**
     * Creates a fine-tuning job which begins the process of creating a new model from
     * a given dataset.
     *
     * Response includes details of the enqueued job including job status and the name
     * of the fine-tuned models once complete.
     *
     * [Learn more about fine-tuning](https://platform.openai.com/docs/guides/fine-tuning)
     */
    create(body, options) {
        return this._client.post('/fine_tuning/jobs', { body, ...options });
    }
    /**
     * Get info about a fine-tuning job.
     *
     * [Learn more about fine-tuning](https://platform.openai.com/docs/guides/fine-tuning)
     */
    retrieve(fineTuningJobId, options) {
        return this._client.get(`/fine_tuning/jobs/${fineTuningJobId}`, options);
    }
    list(query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list({}, query);
        }
        return this._client.getAPIList('/fine_tuning/jobs', FineTuningJobsPage, { query, ...options });
    }
    /**
     * Immediately cancel a fine-tune job.
     */
    cancel(fineTuningJobId, options) {
        return this._client.post(`/fine_tuning/jobs/${fineTuningJobId}/cancel`, options);
    }
    listEvents(fineTuningJobId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.listEvents(fineTuningJobId, {}, query);
        }
        return this._client.getAPIList(`/fine_tuning/jobs/${fineTuningJobId}/events`, FineTuningJobEventsPage, {
            query,
            ...options,
        });
    }
}
class FineTuningJobsPage extends CursorPage {
}
class FineTuningJobEventsPage extends CursorPage {
}
Jobs.FineTuningJobsPage = FineTuningJobsPage;
Jobs.FineTuningJobEventsPage = FineTuningJobEventsPage;
Jobs.Checkpoints = Checkpoints;
Jobs.FineTuningJobCheckpointsPage = FineTuningJobCheckpointsPage;
//# sourceMappingURL=jobs.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/fine-tuning/fine-tuning.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class FineTuning extends APIResource {
    constructor() {
        super(...arguments);
        this.jobs = new Jobs(this._client);
    }
}
FineTuning.Jobs = Jobs;
FineTuning.FineTuningJobsPage = FineTuningJobsPage;
FineTuning.FineTuningJobEventsPage = FineTuningJobEventsPage;
//# sourceMappingURL=fine-tuning.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/Util.mjs
/**
 * Like `Promise.allSettled()` but throws an error if any promises are rejected.
 */
const allSettledWithThrow = async (promises) => {
    const results = await Promise.allSettled(promises);
    const rejected = results.filter((result) => result.status === 'rejected');
    if (rejected.length) {
        for (const result of rejected) {
            console.error(result.reason);
        }
        throw new Error(`${rejected.length} promise(s) failed - see the above errors`);
    }
    // Note: TS was complaining about using `.filter().map()` here for some reason
    const values = [];
    for (const result of results) {
        if (result.status === 'fulfilled') {
            values.push(result.value);
        }
    }
    return values;
};
//# sourceMappingURL=Util.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/vector-stores/files.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class files_Files extends APIResource {
    /**
     * Create a vector store file by attaching a
     * [File](https://platform.openai.com/docs/api-reference/files) to a
     * [vector store](https://platform.openai.com/docs/api-reference/vector-stores/object).
     */
    create(vectorStoreId, body, options) {
        return this._client.post(`/vector_stores/${vectorStoreId}/files`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Retrieves a vector store file.
     */
    retrieve(vectorStoreId, fileId, options) {
        return this._client.get(`/vector_stores/${vectorStoreId}/files/${fileId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Update attributes on a vector store file.
     */
    update(vectorStoreId, fileId, body, options) {
        return this._client.post(`/vector_stores/${vectorStoreId}/files/${fileId}`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    list(vectorStoreId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(vectorStoreId, {}, query);
        }
        return this._client.getAPIList(`/vector_stores/${vectorStoreId}/files`, VectorStoreFilesPage, {
            query,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Delete a vector store file. This will remove the file from the vector store but
     * the file itself will not be deleted. To delete the file, use the
     * [delete file](https://platform.openai.com/docs/api-reference/files/delete)
     * endpoint.
     */
    del(vectorStoreId, fileId, options) {
        return this._client.delete(`/vector_stores/${vectorStoreId}/files/${fileId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Attach a file to the given vector store and wait for it to be processed.
     */
    async createAndPoll(vectorStoreId, body, options) {
        const file = await this.create(vectorStoreId, body, options);
        return await this.poll(vectorStoreId, file.id, options);
    }
    /**
     * Wait for the vector store file to finish processing.
     *
     * Note: this will return even if the file failed to process, you need to check
     * file.last_error and file.status to handle these cases
     */
    async poll(vectorStoreId, fileId, options) {
        const headers = { ...options?.headers, 'X-Stainless-Poll-Helper': 'true' };
        if (options?.pollIntervalMs) {
            headers['X-Stainless-Custom-Poll-Interval'] = options.pollIntervalMs.toString();
        }
        while (true) {
            const fileResponse = await this.retrieve(vectorStoreId, fileId, {
                ...options,
                headers,
            }).withResponse();
            const file = fileResponse.data;
            switch (file.status) {
                case 'in_progress':
                    let sleepInterval = 5000;
                    if (options?.pollIntervalMs) {
                        sleepInterval = options.pollIntervalMs;
                    }
                    else {
                        const headerInterval = fileResponse.response.headers.get('openai-poll-after-ms');
                        if (headerInterval) {
                            const headerIntervalMs = parseInt(headerInterval);
                            if (!isNaN(headerIntervalMs)) {
                                sleepInterval = headerIntervalMs;
                            }
                        }
                    }
                    await sleep(sleepInterval);
                    break;
                case 'failed':
                case 'completed':
                    return file;
            }
        }
    }
    /**
     * Upload a file to the `files` API and then attach it to the given vector store.
     *
     * Note the file will be asynchronously processed (you can use the alternative
     * polling helper method to wait for processing to complete).
     */
    async upload(vectorStoreId, file, options) {
        const fileInfo = await this._client.files.create({ file: file, purpose: 'assistants' }, options);
        return this.create(vectorStoreId, { file_id: fileInfo.id }, options);
    }
    /**
     * Add a file to a vector store and poll until processing is complete.
     */
    async uploadAndPoll(vectorStoreId, file, options) {
        const fileInfo = await this.upload(vectorStoreId, file, options);
        return await this.poll(vectorStoreId, fileInfo.id, options);
    }
    /**
     * Retrieve the parsed contents of a vector store file.
     */
    content(vectorStoreId, fileId, options) {
        return this._client.getAPIList(`/vector_stores/${vectorStoreId}/files/${fileId}/content`, FileContentResponsesPage, { ...options, headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers } });
    }
}
class VectorStoreFilesPage extends CursorPage {
}
/**
 * Note: no pagination actually occurs yet, this is for forwards-compatibility.
 */
class FileContentResponsesPage extends Page {
}
files_Files.VectorStoreFilesPage = VectorStoreFilesPage;
files_Files.FileContentResponsesPage = FileContentResponsesPage;
//# sourceMappingURL=files.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/vector-stores/file-batches.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.





class FileBatches extends APIResource {
    /**
     * Create a vector store file batch.
     */
    create(vectorStoreId, body, options) {
        return this._client.post(`/vector_stores/${vectorStoreId}/file_batches`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Retrieves a vector store file batch.
     */
    retrieve(vectorStoreId, batchId, options) {
        return this._client.get(`/vector_stores/${vectorStoreId}/file_batches/${batchId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Cancel a vector store file batch. This attempts to cancel the processing of
     * files in this batch as soon as possible.
     */
    cancel(vectorStoreId, batchId, options) {
        return this._client.post(`/vector_stores/${vectorStoreId}/file_batches/${batchId}/cancel`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Create a vector store batch and poll until all files have been processed.
     */
    async createAndPoll(vectorStoreId, body, options) {
        const batch = await this.create(vectorStoreId, body);
        return await this.poll(vectorStoreId, batch.id, options);
    }
    listFiles(vectorStoreId, batchId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.listFiles(vectorStoreId, batchId, {}, query);
        }
        return this._client.getAPIList(`/vector_stores/${vectorStoreId}/file_batches/${batchId}/files`, VectorStoreFilesPage, { query, ...options, headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers } });
    }
    /**
     * Wait for the given file batch to be processed.
     *
     * Note: this will return even if one of the files failed to process, you need to
     * check batch.file_counts.failed_count to handle this case.
     */
    async poll(vectorStoreId, batchId, options) {
        const headers = { ...options?.headers, 'X-Stainless-Poll-Helper': 'true' };
        if (options?.pollIntervalMs) {
            headers['X-Stainless-Custom-Poll-Interval'] = options.pollIntervalMs.toString();
        }
        while (true) {
            const { data: batch, response } = await this.retrieve(vectorStoreId, batchId, {
                ...options,
                headers,
            }).withResponse();
            switch (batch.status) {
                case 'in_progress':
                    let sleepInterval = 5000;
                    if (options?.pollIntervalMs) {
                        sleepInterval = options.pollIntervalMs;
                    }
                    else {
                        const headerInterval = response.headers.get('openai-poll-after-ms');
                        if (headerInterval) {
                            const headerIntervalMs = parseInt(headerInterval);
                            if (!isNaN(headerIntervalMs)) {
                                sleepInterval = headerIntervalMs;
                            }
                        }
                    }
                    await sleep(sleepInterval);
                    break;
                case 'failed':
                case 'cancelled':
                case 'completed':
                    return batch;
            }
        }
    }
    /**
     * Uploads the given files concurrently and then creates a vector store file batch.
     *
     * The concurrency limit is configurable using the `maxConcurrency` parameter.
     */
    async uploadAndPoll(vectorStoreId, { files, fileIds = [] }, options) {
        if (files == null || files.length == 0) {
            throw new Error(`No \`files\` provided to process. If you've already uploaded files you should use \`.createAndPoll()\` instead`);
        }
        const configuredConcurrency = options?.maxConcurrency ?? 5;
        // We cap the number of workers at the number of files (so we don't start any unnecessary workers)
        const concurrencyLimit = Math.min(configuredConcurrency, files.length);
        const client = this._client;
        const fileIterator = files.values();
        const allFileIds = [...fileIds];
        // This code is based on this design. The libraries don't accommodate our environment limits.
        // https://stackoverflow.com/questions/40639432/what-is-the-best-way-to-limit-concurrency-when-using-es6s-promise-all
        async function processFiles(iterator) {
            for (let item of iterator) {
                const fileObj = await client.files.create({ file: item, purpose: 'assistants' }, options);
                allFileIds.push(fileObj.id);
            }
        }
        // Start workers to process results
        const workers = Array(concurrencyLimit).fill(fileIterator).map(processFiles);
        // Wait for all processing to complete.
        await allSettledWithThrow(workers);
        return await this.createAndPoll(vectorStoreId, {
            file_ids: allFileIds,
        });
    }
}

//# sourceMappingURL=file-batches.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/vector-stores/vector-stores.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.







class VectorStores extends APIResource {
    constructor() {
        super(...arguments);
        this.files = new files_Files(this._client);
        this.fileBatches = new FileBatches(this._client);
    }
    /**
     * Create a vector store.
     */
    create(body, options) {
        return this._client.post('/vector_stores', {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Retrieves a vector store.
     */
    retrieve(vectorStoreId, options) {
        return this._client.get(`/vector_stores/${vectorStoreId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Modifies a vector store.
     */
    update(vectorStoreId, body, options) {
        return this._client.post(`/vector_stores/${vectorStoreId}`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    list(query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list({}, query);
        }
        return this._client.getAPIList('/vector_stores', VectorStoresPage, {
            query,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Delete a vector store.
     */
    del(vectorStoreId, options) {
        return this._client.delete(`/vector_stores/${vectorStoreId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Search a vector store for relevant chunks based on a query and file attributes
     * filter.
     */
    search(vectorStoreId, body, options) {
        return this._client.getAPIList(`/vector_stores/${vectorStoreId}/search`, VectorStoreSearchResponsesPage, {
            body,
            method: 'post',
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
}
class VectorStoresPage extends CursorPage {
}
/**
 * Note: no pagination actually occurs yet, this is for forwards-compatibility.
 */
class VectorStoreSearchResponsesPage extends Page {
}
VectorStores.VectorStoresPage = VectorStoresPage;
VectorStores.VectorStoreSearchResponsesPage = VectorStoreSearchResponsesPage;
VectorStores.Files = files_Files;
VectorStores.VectorStoreFilesPage = VectorStoreFilesPage;
VectorStores.FileContentResponsesPage = FileContentResponsesPage;
VectorStores.FileBatches = FileBatches;
//# sourceMappingURL=vector-stores.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/assistants.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class Assistants extends APIResource {
    /**
     * Create an assistant with a model and instructions.
     */
    create(body, options) {
        return this._client.post('/assistants', {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Retrieves an assistant.
     */
    retrieve(assistantId, options) {
        return this._client.get(`/assistants/${assistantId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Modifies an assistant.
     */
    update(assistantId, body, options) {
        return this._client.post(`/assistants/${assistantId}`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    list(query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list({}, query);
        }
        return this._client.getAPIList('/assistants', AssistantsPage, {
            query,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Delete an assistant.
     */
    del(assistantId, options) {
        return this._client.delete(`/assistants/${assistantId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
}
class AssistantsPage extends CursorPage {
}
Assistants.AssistantsPage = AssistantsPage;
//# sourceMappingURL=assistants.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/RunnableFunction.mjs
function isRunnableFunctionWithParse(fn) {
    return typeof fn.parse === 'function';
}
/**
 * This is helper class for passing a `function` and `parse` where the `function`
 * argument type matches the `parse` return type.
 *
 * @deprecated - please use ParsingToolFunction instead.
 */
class ParsingFunction {
    constructor(input) {
        this.function = input.function;
        this.parse = input.parse;
        this.parameters = input.parameters;
        this.description = input.description;
        this.name = input.name;
    }
}
/**
 * This is helper class for passing a `function` and `parse` where the `function`
 * argument type matches the `parse` return type.
 */
class ParsingToolFunction {
    constructor(input) {
        this.type = 'function';
        this.function = input;
    }
}
//# sourceMappingURL=RunnableFunction.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/chatCompletionUtils.mjs
const isAssistantMessage = (message) => {
    return message?.role === 'assistant';
};
const isFunctionMessage = (message) => {
    return message?.role === 'function';
};
const isToolMessage = (message) => {
    return message?.role === 'tool';
};
function isPresent(obj) {
    return obj != null;
}
//# sourceMappingURL=chatCompletionUtils.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/EventStream.mjs
var EventStream_classPrivateFieldSet = (undefined && undefined.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var EventStream_classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _EventStream_instances, _EventStream_connectedPromise, _EventStream_resolveConnectedPromise, _EventStream_rejectConnectedPromise, _EventStream_endPromise, _EventStream_resolveEndPromise, _EventStream_rejectEndPromise, _EventStream_listeners, _EventStream_ended, _EventStream_errored, _EventStream_aborted, _EventStream_catchingPromiseCreated, _EventStream_handleError;

class EventStream {
    constructor() {
        _EventStream_instances.add(this);
        this.controller = new AbortController();
        _EventStream_connectedPromise.set(this, void 0);
        _EventStream_resolveConnectedPromise.set(this, () => { });
        _EventStream_rejectConnectedPromise.set(this, () => { });
        _EventStream_endPromise.set(this, void 0);
        _EventStream_resolveEndPromise.set(this, () => { });
        _EventStream_rejectEndPromise.set(this, () => { });
        _EventStream_listeners.set(this, {});
        _EventStream_ended.set(this, false);
        _EventStream_errored.set(this, false);
        _EventStream_aborted.set(this, false);
        _EventStream_catchingPromiseCreated.set(this, false);
        EventStream_classPrivateFieldSet(this, _EventStream_connectedPromise, new Promise((resolve, reject) => {
            EventStream_classPrivateFieldSet(this, _EventStream_resolveConnectedPromise, resolve, "f");
            EventStream_classPrivateFieldSet(this, _EventStream_rejectConnectedPromise, reject, "f");
        }), "f");
        EventStream_classPrivateFieldSet(this, _EventStream_endPromise, new Promise((resolve, reject) => {
            EventStream_classPrivateFieldSet(this, _EventStream_resolveEndPromise, resolve, "f");
            EventStream_classPrivateFieldSet(this, _EventStream_rejectEndPromise, reject, "f");
        }), "f");
        // Don't let these promises cause unhandled rejection errors.
        // we will manually cause an unhandled rejection error later
        // if the user hasn't registered any error listener or called
        // any promise-returning method.
        EventStream_classPrivateFieldGet(this, _EventStream_connectedPromise, "f").catch(() => { });
        EventStream_classPrivateFieldGet(this, _EventStream_endPromise, "f").catch(() => { });
    }
    _run(executor) {
        // Unfortunately if we call `executor()` immediately we get runtime errors about
        // references to `this` before the `super()` constructor call returns.
        setTimeout(() => {
            executor().then(() => {
                this._emitFinal();
                this._emit('end');
            }, EventStream_classPrivateFieldGet(this, _EventStream_instances, "m", _EventStream_handleError).bind(this));
        }, 0);
    }
    _connected() {
        if (this.ended)
            return;
        EventStream_classPrivateFieldGet(this, _EventStream_resolveConnectedPromise, "f").call(this);
        this._emit('connect');
    }
    get ended() {
        return EventStream_classPrivateFieldGet(this, _EventStream_ended, "f");
    }
    get errored() {
        return EventStream_classPrivateFieldGet(this, _EventStream_errored, "f");
    }
    get aborted() {
        return EventStream_classPrivateFieldGet(this, _EventStream_aborted, "f");
    }
    abort() {
        this.controller.abort();
    }
    /**
     * Adds the listener function to the end of the listeners array for the event.
     * No checks are made to see if the listener has already been added. Multiple calls passing
     * the same combination of event and listener will result in the listener being added, and
     * called, multiple times.
     * @returns this ChatCompletionStream, so that calls can be chained
     */
    on(event, listener) {
        const listeners = EventStream_classPrivateFieldGet(this, _EventStream_listeners, "f")[event] || (EventStream_classPrivateFieldGet(this, _EventStream_listeners, "f")[event] = []);
        listeners.push({ listener });
        return this;
    }
    /**
     * Removes the specified listener from the listener array for the event.
     * off() will remove, at most, one instance of a listener from the listener array. If any single
     * listener has been added multiple times to the listener array for the specified event, then
     * off() must be called multiple times to remove each instance.
     * @returns this ChatCompletionStream, so that calls can be chained
     */
    off(event, listener) {
        const listeners = EventStream_classPrivateFieldGet(this, _EventStream_listeners, "f")[event];
        if (!listeners)
            return this;
        const index = listeners.findIndex((l) => l.listener === listener);
        if (index >= 0)
            listeners.splice(index, 1);
        return this;
    }
    /**
     * Adds a one-time listener function for the event. The next time the event is triggered,
     * this listener is removed and then invoked.
     * @returns this ChatCompletionStream, so that calls can be chained
     */
    once(event, listener) {
        const listeners = EventStream_classPrivateFieldGet(this, _EventStream_listeners, "f")[event] || (EventStream_classPrivateFieldGet(this, _EventStream_listeners, "f")[event] = []);
        listeners.push({ listener, once: true });
        return this;
    }
    /**
     * This is similar to `.once()`, but returns a Promise that resolves the next time
     * the event is triggered, instead of calling a listener callback.
     * @returns a Promise that resolves the next time given event is triggered,
     * or rejects if an error is emitted.  (If you request the 'error' event,
     * returns a promise that resolves with the error).
     *
     * Example:
     *
     *   const message = await stream.emitted('message') // rejects if the stream errors
     */
    emitted(event) {
        return new Promise((resolve, reject) => {
            EventStream_classPrivateFieldSet(this, _EventStream_catchingPromiseCreated, true, "f");
            if (event !== 'error')
                this.once('error', reject);
            this.once(event, resolve);
        });
    }
    async done() {
        EventStream_classPrivateFieldSet(this, _EventStream_catchingPromiseCreated, true, "f");
        await EventStream_classPrivateFieldGet(this, _EventStream_endPromise, "f");
    }
    _emit(event, ...args) {
        // make sure we don't emit any events after end
        if (EventStream_classPrivateFieldGet(this, _EventStream_ended, "f")) {
            return;
        }
        if (event === 'end') {
            EventStream_classPrivateFieldSet(this, _EventStream_ended, true, "f");
            EventStream_classPrivateFieldGet(this, _EventStream_resolveEndPromise, "f").call(this);
        }
        const listeners = EventStream_classPrivateFieldGet(this, _EventStream_listeners, "f")[event];
        if (listeners) {
            EventStream_classPrivateFieldGet(this, _EventStream_listeners, "f")[event] = listeners.filter((l) => !l.once);
            listeners.forEach(({ listener }) => listener(...args));
        }
        if (event === 'abort') {
            const error = args[0];
            if (!EventStream_classPrivateFieldGet(this, _EventStream_catchingPromiseCreated, "f") && !listeners?.length) {
                Promise.reject(error);
            }
            EventStream_classPrivateFieldGet(this, _EventStream_rejectConnectedPromise, "f").call(this, error);
            EventStream_classPrivateFieldGet(this, _EventStream_rejectEndPromise, "f").call(this, error);
            this._emit('end');
            return;
        }
        if (event === 'error') {
            // NOTE: _emit('error', error) should only be called from #handleError().
            const error = args[0];
            if (!EventStream_classPrivateFieldGet(this, _EventStream_catchingPromiseCreated, "f") && !listeners?.length) {
                // Trigger an unhandled rejection if the user hasn't registered any error handlers.
                // If you are seeing stack traces here, make sure to handle errors via either:
                // - runner.on('error', () => ...)
                // - await runner.done()
                // - await runner.finalChatCompletion()
                // - etc.
                Promise.reject(error);
            }
            EventStream_classPrivateFieldGet(this, _EventStream_rejectConnectedPromise, "f").call(this, error);
            EventStream_classPrivateFieldGet(this, _EventStream_rejectEndPromise, "f").call(this, error);
            this._emit('end');
        }
    }
    _emitFinal() { }
}
_EventStream_connectedPromise = new WeakMap(), _EventStream_resolveConnectedPromise = new WeakMap(), _EventStream_rejectConnectedPromise = new WeakMap(), _EventStream_endPromise = new WeakMap(), _EventStream_resolveEndPromise = new WeakMap(), _EventStream_rejectEndPromise = new WeakMap(), _EventStream_listeners = new WeakMap(), _EventStream_ended = new WeakMap(), _EventStream_errored = new WeakMap(), _EventStream_aborted = new WeakMap(), _EventStream_catchingPromiseCreated = new WeakMap(), _EventStream_instances = new WeakSet(), _EventStream_handleError = function _EventStream_handleError(error) {
    EventStream_classPrivateFieldSet(this, _EventStream_errored, true, "f");
    if (error instanceof Error && error.name === 'AbortError') {
        error = new APIUserAbortError();
    }
    if (error instanceof APIUserAbortError) {
        EventStream_classPrivateFieldSet(this, _EventStream_aborted, true, "f");
        return this._emit('abort', error);
    }
    if (error instanceof error_OpenAIError) {
        return this._emit('error', error);
    }
    if (error instanceof Error) {
        const openAIError = new error_OpenAIError(error.message);
        // @ts-ignore
        openAIError.cause = error;
        return this._emit('error', openAIError);
    }
    return this._emit('error', new error_OpenAIError(String(error)));
};
//# sourceMappingURL=EventStream.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/parser.mjs

function makeParseableResponseFormat(response_format, parser) {
    const obj = { ...response_format };
    Object.defineProperties(obj, {
        $brand: {
            value: 'auto-parseable-response-format',
            enumerable: false,
        },
        $parseRaw: {
            value: parser,
            enumerable: false,
        },
    });
    return obj;
}
function makeParseableTextFormat(response_format, parser) {
    const obj = { ...response_format };
    Object.defineProperties(obj, {
        $brand: {
            value: 'auto-parseable-response-format',
            enumerable: false,
        },
        $parseRaw: {
            value: parser,
            enumerable: false,
        },
    });
    return obj;
}
function isAutoParsableResponseFormat(response_format) {
    return response_format?.['$brand'] === 'auto-parseable-response-format';
}
function makeParseableTool(tool, { parser, callback, }) {
    const obj = { ...tool };
    Object.defineProperties(obj, {
        $brand: {
            value: 'auto-parseable-tool',
            enumerable: false,
        },
        $parseRaw: {
            value: parser,
            enumerable: false,
        },
        $callback: {
            value: callback,
            enumerable: false,
        },
    });
    return obj;
}
function isAutoParsableTool(tool) {
    return tool?.['$brand'] === 'auto-parseable-tool';
}
function maybeParseChatCompletion(completion, params) {
    if (!params || !hasAutoParseableInput(params)) {
        return {
            ...completion,
            choices: completion.choices.map((choice) => ({
                ...choice,
                message: {
                    ...choice.message,
                    parsed: null,
                    ...(choice.message.tool_calls ?
                        {
                            tool_calls: choice.message.tool_calls,
                        }
                        : undefined),
                },
            })),
        };
    }
    return parseChatCompletion(completion, params);
}
function parseChatCompletion(completion, params) {
    const choices = completion.choices.map((choice) => {
        if (choice.finish_reason === 'length') {
            throw new LengthFinishReasonError();
        }
        if (choice.finish_reason === 'content_filter') {
            throw new ContentFilterFinishReasonError();
        }
        return {
            ...choice,
            message: {
                ...choice.message,
                ...(choice.message.tool_calls ?
                    {
                        tool_calls: choice.message.tool_calls?.map((toolCall) => parseToolCall(params, toolCall)) ?? undefined,
                    }
                    : undefined),
                parsed: choice.message.content && !choice.message.refusal ?
                    parseResponseFormat(params, choice.message.content)
                    : null,
            },
        };
    });
    return { ...completion, choices };
}
function parseResponseFormat(params, content) {
    if (params.response_format?.type !== 'json_schema') {
        return null;
    }
    if (params.response_format?.type === 'json_schema') {
        if ('$parseRaw' in params.response_format) {
            const response_format = params.response_format;
            return response_format.$parseRaw(content);
        }
        return JSON.parse(content);
    }
    return null;
}
function parseToolCall(params, toolCall) {
    const inputTool = params.tools?.find((inputTool) => inputTool.function?.name === toolCall.function.name);
    return {
        ...toolCall,
        function: {
            ...toolCall.function,
            parsed_arguments: isAutoParsableTool(inputTool) ? inputTool.$parseRaw(toolCall.function.arguments)
                : inputTool?.function.strict ? JSON.parse(toolCall.function.arguments)
                    : null,
        },
    };
}
function shouldParseToolCall(params, toolCall) {
    if (!params) {
        return false;
    }
    const inputTool = params.tools?.find((inputTool) => inputTool.function?.name === toolCall.function.name);
    return isAutoParsableTool(inputTool) || inputTool?.function.strict || false;
}
function hasAutoParseableInput(params) {
    if (isAutoParsableResponseFormat(params.response_format)) {
        return true;
    }
    return (params.tools?.some((t) => isAutoParsableTool(t) || (t.type === 'function' && t.function.strict === true)) ?? false);
}
function validateInputTools(tools) {
    for (const tool of tools ?? []) {
        if (tool.type !== 'function') {
            throw new error_OpenAIError(`Currently only \`function\` tool types support auto-parsing; Received \`${tool.type}\``);
        }
        if (tool.function.strict !== true) {
            throw new error_OpenAIError(`The \`${tool.function.name}\` tool is not marked with \`strict: true\`. Only strict function tools can be auto-parsed`);
        }
    }
}
//# sourceMappingURL=parser.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/AbstractChatCompletionRunner.mjs
var AbstractChatCompletionRunner_classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _AbstractChatCompletionRunner_instances, _AbstractChatCompletionRunner_getFinalContent, _AbstractChatCompletionRunner_getFinalMessage, _AbstractChatCompletionRunner_getFinalFunctionCall, _AbstractChatCompletionRunner_getFinalFunctionCallResult, _AbstractChatCompletionRunner_calculateTotalUsage, _AbstractChatCompletionRunner_validateParams, _AbstractChatCompletionRunner_stringifyFunctionCallResult;





const DEFAULT_MAX_CHAT_COMPLETIONS = 10;
class AbstractChatCompletionRunner extends EventStream {
    constructor() {
        super(...arguments);
        _AbstractChatCompletionRunner_instances.add(this);
        this._chatCompletions = [];
        this.messages = [];
    }
    _addChatCompletion(chatCompletion) {
        this._chatCompletions.push(chatCompletion);
        this._emit('chatCompletion', chatCompletion);
        const message = chatCompletion.choices[0]?.message;
        if (message)
            this._addMessage(message);
        return chatCompletion;
    }
    _addMessage(message, emit = true) {
        if (!('content' in message))
            message.content = null;
        this.messages.push(message);
        if (emit) {
            this._emit('message', message);
            if ((isFunctionMessage(message) || isToolMessage(message)) && message.content) {
                // Note, this assumes that {role: 'tool', content: …} is always the result of a call of tool of type=function.
                this._emit('functionCallResult', message.content);
            }
            else if (isAssistantMessage(message) && message.function_call) {
                this._emit('functionCall', message.function_call);
            }
            else if (isAssistantMessage(message) && message.tool_calls) {
                for (const tool_call of message.tool_calls) {
                    if (tool_call.type === 'function') {
                        this._emit('functionCall', tool_call.function);
                    }
                }
            }
        }
    }
    /**
     * @returns a promise that resolves with the final ChatCompletion, or rejects
     * if an error occurred or the stream ended prematurely without producing a ChatCompletion.
     */
    async finalChatCompletion() {
        await this.done();
        const completion = this._chatCompletions[this._chatCompletions.length - 1];
        if (!completion)
            throw new error_OpenAIError('stream ended without producing a ChatCompletion');
        return completion;
    }
    /**
     * @returns a promise that resolves with the content of the final ChatCompletionMessage, or rejects
     * if an error occurred or the stream ended prematurely without producing a ChatCompletionMessage.
     */
    async finalContent() {
        await this.done();
        return AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalContent).call(this);
    }
    /**
     * @returns a promise that resolves with the the final assistant ChatCompletionMessage response,
     * or rejects if an error occurred or the stream ended prematurely without producing a ChatCompletionMessage.
     */
    async finalMessage() {
        await this.done();
        return AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalMessage).call(this);
    }
    /**
     * @returns a promise that resolves with the content of the final FunctionCall, or rejects
     * if an error occurred or the stream ended prematurely without producing a ChatCompletionMessage.
     */
    async finalFunctionCall() {
        await this.done();
        return AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalFunctionCall).call(this);
    }
    async finalFunctionCallResult() {
        await this.done();
        return AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalFunctionCallResult).call(this);
    }
    async totalUsage() {
        await this.done();
        return AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_calculateTotalUsage).call(this);
    }
    allChatCompletions() {
        return [...this._chatCompletions];
    }
    _emitFinal() {
        const completion = this._chatCompletions[this._chatCompletions.length - 1];
        if (completion)
            this._emit('finalChatCompletion', completion);
        const finalMessage = AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalMessage).call(this);
        if (finalMessage)
            this._emit('finalMessage', finalMessage);
        const finalContent = AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalContent).call(this);
        if (finalContent)
            this._emit('finalContent', finalContent);
        const finalFunctionCall = AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalFunctionCall).call(this);
        if (finalFunctionCall)
            this._emit('finalFunctionCall', finalFunctionCall);
        const finalFunctionCallResult = AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalFunctionCallResult).call(this);
        if (finalFunctionCallResult != null)
            this._emit('finalFunctionCallResult', finalFunctionCallResult);
        if (this._chatCompletions.some((c) => c.usage)) {
            this._emit('totalUsage', AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_calculateTotalUsage).call(this));
        }
    }
    async _createChatCompletion(client, params, options) {
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_validateParams).call(this, params);
        const chatCompletion = await client.chat.completions.create({ ...params, stream: false }, { ...options, signal: this.controller.signal });
        this._connected();
        return this._addChatCompletion(parseChatCompletion(chatCompletion, params));
    }
    async _runChatCompletion(client, params, options) {
        for (const message of params.messages) {
            this._addMessage(message, false);
        }
        return await this._createChatCompletion(client, params, options);
    }
    async _runFunctions(client, params, options) {
        const role = 'function';
        const { function_call = 'auto', stream, ...restParams } = params;
        const singleFunctionToCall = typeof function_call !== 'string' && function_call?.name;
        const { maxChatCompletions = DEFAULT_MAX_CHAT_COMPLETIONS } = options || {};
        const functionsByName = {};
        for (const f of params.functions) {
            functionsByName[f.name || f.function.name] = f;
        }
        const functions = params.functions.map((f) => ({
            name: f.name || f.function.name,
            parameters: f.parameters,
            description: f.description,
        }));
        for (const message of params.messages) {
            this._addMessage(message, false);
        }
        for (let i = 0; i < maxChatCompletions; ++i) {
            const chatCompletion = await this._createChatCompletion(client, {
                ...restParams,
                function_call,
                functions,
                messages: [...this.messages],
            }, options);
            const message = chatCompletion.choices[0]?.message;
            if (!message) {
                throw new error_OpenAIError(`missing message in ChatCompletion response`);
            }
            if (!message.function_call)
                return;
            const { name, arguments: args } = message.function_call;
            const fn = functionsByName[name];
            if (!fn) {
                const content = `Invalid function_call: ${JSON.stringify(name)}. Available options are: ${functions
                    .map((f) => JSON.stringify(f.name))
                    .join(', ')}. Please try again`;
                this._addMessage({ role, name, content });
                continue;
            }
            else if (singleFunctionToCall && singleFunctionToCall !== name) {
                const content = `Invalid function_call: ${JSON.stringify(name)}. ${JSON.stringify(singleFunctionToCall)} requested. Please try again`;
                this._addMessage({ role, name, content });
                continue;
            }
            let parsed;
            try {
                parsed = isRunnableFunctionWithParse(fn) ? await fn.parse(args) : args;
            }
            catch (error) {
                this._addMessage({
                    role,
                    name,
                    content: error instanceof Error ? error.message : String(error),
                });
                continue;
            }
            // @ts-expect-error it can't rule out `never` type.
            const rawContent = await fn.function(parsed, this);
            const content = AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_stringifyFunctionCallResult).call(this, rawContent);
            this._addMessage({ role, name, content });
            if (singleFunctionToCall)
                return;
        }
    }
    async _runTools(client, params, options) {
        const role = 'tool';
        const { tool_choice = 'auto', stream, ...restParams } = params;
        const singleFunctionToCall = typeof tool_choice !== 'string' && tool_choice?.function?.name;
        const { maxChatCompletions = DEFAULT_MAX_CHAT_COMPLETIONS } = options || {};
        // TODO(someday): clean this logic up
        const inputTools = params.tools.map((tool) => {
            if (isAutoParsableTool(tool)) {
                if (!tool.$callback) {
                    throw new error_OpenAIError('Tool given to `.runTools()` that does not have an associated function');
                }
                return {
                    type: 'function',
                    function: {
                        function: tool.$callback,
                        name: tool.function.name,
                        description: tool.function.description || '',
                        parameters: tool.function.parameters,
                        parse: tool.$parseRaw,
                        strict: true,
                    },
                };
            }
            return tool;
        });
        const functionsByName = {};
        for (const f of inputTools) {
            if (f.type === 'function') {
                functionsByName[f.function.name || f.function.function.name] = f.function;
            }
        }
        const tools = 'tools' in params ?
            inputTools.map((t) => t.type === 'function' ?
                {
                    type: 'function',
                    function: {
                        name: t.function.name || t.function.function.name,
                        parameters: t.function.parameters,
                        description: t.function.description,
                        strict: t.function.strict,
                    },
                }
                : t)
            : undefined;
        for (const message of params.messages) {
            this._addMessage(message, false);
        }
        for (let i = 0; i < maxChatCompletions; ++i) {
            const chatCompletion = await this._createChatCompletion(client, {
                ...restParams,
                tool_choice,
                tools,
                messages: [...this.messages],
            }, options);
            const message = chatCompletion.choices[0]?.message;
            if (!message) {
                throw new error_OpenAIError(`missing message in ChatCompletion response`);
            }
            if (!message.tool_calls?.length) {
                return;
            }
            for (const tool_call of message.tool_calls) {
                if (tool_call.type !== 'function')
                    continue;
                const tool_call_id = tool_call.id;
                const { name, arguments: args } = tool_call.function;
                const fn = functionsByName[name];
                if (!fn) {
                    const content = `Invalid tool_call: ${JSON.stringify(name)}. Available options are: ${Object.keys(functionsByName)
                        .map((name) => JSON.stringify(name))
                        .join(', ')}. Please try again`;
                    this._addMessage({ role, tool_call_id, content });
                    continue;
                }
                else if (singleFunctionToCall && singleFunctionToCall !== name) {
                    const content = `Invalid tool_call: ${JSON.stringify(name)}. ${JSON.stringify(singleFunctionToCall)} requested. Please try again`;
                    this._addMessage({ role, tool_call_id, content });
                    continue;
                }
                let parsed;
                try {
                    parsed = isRunnableFunctionWithParse(fn) ? await fn.parse(args) : args;
                }
                catch (error) {
                    const content = error instanceof Error ? error.message : String(error);
                    this._addMessage({ role, tool_call_id, content });
                    continue;
                }
                // @ts-expect-error it can't rule out `never` type.
                const rawContent = await fn.function(parsed, this);
                const content = AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_stringifyFunctionCallResult).call(this, rawContent);
                this._addMessage({ role, tool_call_id, content });
                if (singleFunctionToCall) {
                    return;
                }
            }
        }
        return;
    }
}
_AbstractChatCompletionRunner_instances = new WeakSet(), _AbstractChatCompletionRunner_getFinalContent = function _AbstractChatCompletionRunner_getFinalContent() {
    return AbstractChatCompletionRunner_classPrivateFieldGet(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalMessage).call(this).content ?? null;
}, _AbstractChatCompletionRunner_getFinalMessage = function _AbstractChatCompletionRunner_getFinalMessage() {
    let i = this.messages.length;
    while (i-- > 0) {
        const message = this.messages[i];
        if (isAssistantMessage(message)) {
            const { function_call, ...rest } = message;
            // TODO: support audio here
            const ret = {
                ...rest,
                content: message.content ?? null,
                refusal: message.refusal ?? null,
            };
            if (function_call) {
                ret.function_call = function_call;
            }
            return ret;
        }
    }
    throw new error_OpenAIError('stream ended without producing a ChatCompletionMessage with role=assistant');
}, _AbstractChatCompletionRunner_getFinalFunctionCall = function _AbstractChatCompletionRunner_getFinalFunctionCall() {
    for (let i = this.messages.length - 1; i >= 0; i--) {
        const message = this.messages[i];
        if (isAssistantMessage(message) && message?.function_call) {
            return message.function_call;
        }
        if (isAssistantMessage(message) && message?.tool_calls?.length) {
            return message.tool_calls.at(-1)?.function;
        }
    }
    return;
}, _AbstractChatCompletionRunner_getFinalFunctionCallResult = function _AbstractChatCompletionRunner_getFinalFunctionCallResult() {
    for (let i = this.messages.length - 1; i >= 0; i--) {
        const message = this.messages[i];
        if (isFunctionMessage(message) && message.content != null) {
            return message.content;
        }
        if (isToolMessage(message) &&
            message.content != null &&
            typeof message.content === 'string' &&
            this.messages.some((x) => x.role === 'assistant' &&
                x.tool_calls?.some((y) => y.type === 'function' && y.id === message.tool_call_id))) {
            return message.content;
        }
    }
    return;
}, _AbstractChatCompletionRunner_calculateTotalUsage = function _AbstractChatCompletionRunner_calculateTotalUsage() {
    const total = {
        completion_tokens: 0,
        prompt_tokens: 0,
        total_tokens: 0,
    };
    for (const { usage } of this._chatCompletions) {
        if (usage) {
            total.completion_tokens += usage.completion_tokens;
            total.prompt_tokens += usage.prompt_tokens;
            total.total_tokens += usage.total_tokens;
        }
    }
    return total;
}, _AbstractChatCompletionRunner_validateParams = function _AbstractChatCompletionRunner_validateParams(params) {
    if (params.n != null && params.n > 1) {
        throw new error_OpenAIError('ChatCompletion convenience helpers only support n=1 at this time. To use n>1, please use chat.completions.create() directly.');
    }
}, _AbstractChatCompletionRunner_stringifyFunctionCallResult = function _AbstractChatCompletionRunner_stringifyFunctionCallResult(rawContent) {
    return (typeof rawContent === 'string' ? rawContent
        : rawContent === undefined ? 'undefined'
            : JSON.stringify(rawContent));
};
//# sourceMappingURL=AbstractChatCompletionRunner.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/ChatCompletionRunner.mjs


class ChatCompletionRunner extends AbstractChatCompletionRunner {
    /** @deprecated - please use `runTools` instead. */
    static runFunctions(client, params, options) {
        const runner = new ChatCompletionRunner();
        const opts = {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'runFunctions' },
        };
        runner._run(() => runner._runFunctions(client, params, opts));
        return runner;
    }
    static runTools(client, params, options) {
        const runner = new ChatCompletionRunner();
        const opts = {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'runTools' },
        };
        runner._run(() => runner._runTools(client, params, opts));
        return runner;
    }
    _addMessage(message, emit = true) {
        super._addMessage(message, emit);
        if (isAssistantMessage(message) && message.content) {
            this._emit('content', message.content);
        }
    }
}
//# sourceMappingURL=ChatCompletionRunner.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/_vendor/partial-json-parser/parser.mjs
const STR = 0b000000001;
const NUM = 0b000000010;
const ARR = 0b000000100;
const OBJ = 0b000001000;
const NULL = 0b000010000;
const BOOL = 0b000100000;
const NAN = 0b001000000;
const INFINITY = 0b010000000;
const MINUS_INFINITY = 0b100000000;
const INF = INFINITY | MINUS_INFINITY;
const SPECIAL = NULL | BOOL | INF | NAN;
const ATOM = STR | NUM | SPECIAL;
const COLLECTION = ARR | OBJ;
const ALL = ATOM | COLLECTION;
const Allow = {
    STR,
    NUM,
    ARR,
    OBJ,
    NULL,
    BOOL,
    NAN,
    INFINITY,
    MINUS_INFINITY,
    INF,
    SPECIAL,
    ATOM,
    COLLECTION,
    ALL,
};
// The JSON string segment was unable to be parsed completely
class PartialJSON extends Error {
}
class MalformedJSON extends Error {
}
/**
 * Parse incomplete JSON
 * @param {string} jsonString Partial JSON to be parsed
 * @param {number} allowPartial Specify what types are allowed to be partial, see {@link Allow} for details
 * @returns The parsed JSON
 * @throws {PartialJSON} If the JSON is incomplete (related to the `allow` parameter)
 * @throws {MalformedJSON} If the JSON is malformed
 */
function parseJSON(jsonString, allowPartial = Allow.ALL) {
    if (typeof jsonString !== 'string') {
        throw new TypeError(`expecting str, got ${typeof jsonString}`);
    }
    if (!jsonString.trim()) {
        throw new Error(`${jsonString} is empty`);
    }
    return _parseJSON(jsonString.trim(), allowPartial);
}
const _parseJSON = (jsonString, allow) => {
    const length = jsonString.length;
    let index = 0;
    const markPartialJSON = (msg) => {
        throw new PartialJSON(`${msg} at position ${index}`);
    };
    const throwMalformedError = (msg) => {
        throw new MalformedJSON(`${msg} at position ${index}`);
    };
    const parseAny = () => {
        skipBlank();
        if (index >= length)
            markPartialJSON('Unexpected end of input');
        if (jsonString[index] === '"')
            return parseStr();
        if (jsonString[index] === '{')
            return parseObj();
        if (jsonString[index] === '[')
            return parseArr();
        if (jsonString.substring(index, index + 4) === 'null' ||
            (Allow.NULL & allow && length - index < 4 && 'null'.startsWith(jsonString.substring(index)))) {
            index += 4;
            return null;
        }
        if (jsonString.substring(index, index + 4) === 'true' ||
            (Allow.BOOL & allow && length - index < 4 && 'true'.startsWith(jsonString.substring(index)))) {
            index += 4;
            return true;
        }
        if (jsonString.substring(index, index + 5) === 'false' ||
            (Allow.BOOL & allow && length - index < 5 && 'false'.startsWith(jsonString.substring(index)))) {
            index += 5;
            return false;
        }
        if (jsonString.substring(index, index + 8) === 'Infinity' ||
            (Allow.INFINITY & allow && length - index < 8 && 'Infinity'.startsWith(jsonString.substring(index)))) {
            index += 8;
            return Infinity;
        }
        if (jsonString.substring(index, index + 9) === '-Infinity' ||
            (Allow.MINUS_INFINITY & allow &&
                1 < length - index &&
                length - index < 9 &&
                '-Infinity'.startsWith(jsonString.substring(index)))) {
            index += 9;
            return -Infinity;
        }
        if (jsonString.substring(index, index + 3) === 'NaN' ||
            (Allow.NAN & allow && length - index < 3 && 'NaN'.startsWith(jsonString.substring(index)))) {
            index += 3;
            return NaN;
        }
        return parseNum();
    };
    const parseStr = () => {
        const start = index;
        let escape = false;
        index++; // skip initial quote
        while (index < length && (jsonString[index] !== '"' || (escape && jsonString[index - 1] === '\\'))) {
            escape = jsonString[index] === '\\' ? !escape : false;
            index++;
        }
        if (jsonString.charAt(index) == '"') {
            try {
                return JSON.parse(jsonString.substring(start, ++index - Number(escape)));
            }
            catch (e) {
                throwMalformedError(String(e));
            }
        }
        else if (Allow.STR & allow) {
            try {
                return JSON.parse(jsonString.substring(start, index - Number(escape)) + '"');
            }
            catch (e) {
                // SyntaxError: Invalid escape sequence
                return JSON.parse(jsonString.substring(start, jsonString.lastIndexOf('\\')) + '"');
            }
        }
        markPartialJSON('Unterminated string literal');
    };
    const parseObj = () => {
        index++; // skip initial brace
        skipBlank();
        const obj = {};
        try {
            while (jsonString[index] !== '}') {
                skipBlank();
                if (index >= length && Allow.OBJ & allow)
                    return obj;
                const key = parseStr();
                skipBlank();
                index++; // skip colon
                try {
                    const value = parseAny();
                    Object.defineProperty(obj, key, { value, writable: true, enumerable: true, configurable: true });
                }
                catch (e) {
                    if (Allow.OBJ & allow)
                        return obj;
                    else
                        throw e;
                }
                skipBlank();
                if (jsonString[index] === ',')
                    index++; // skip comma
            }
        }
        catch (e) {
            if (Allow.OBJ & allow)
                return obj;
            else
                markPartialJSON("Expected '}' at end of object");
        }
        index++; // skip final brace
        return obj;
    };
    const parseArr = () => {
        index++; // skip initial bracket
        const arr = [];
        try {
            while (jsonString[index] !== ']') {
                arr.push(parseAny());
                skipBlank();
                if (jsonString[index] === ',') {
                    index++; // skip comma
                }
            }
        }
        catch (e) {
            if (Allow.ARR & allow) {
                return arr;
            }
            markPartialJSON("Expected ']' at end of array");
        }
        index++; // skip final bracket
        return arr;
    };
    const parseNum = () => {
        if (index === 0) {
            if (jsonString === '-' && Allow.NUM & allow)
                markPartialJSON("Not sure what '-' is");
            try {
                return JSON.parse(jsonString);
            }
            catch (e) {
                if (Allow.NUM & allow) {
                    try {
                        if ('.' === jsonString[jsonString.length - 1])
                            return JSON.parse(jsonString.substring(0, jsonString.lastIndexOf('.')));
                        return JSON.parse(jsonString.substring(0, jsonString.lastIndexOf('e')));
                    }
                    catch (e) { }
                }
                throwMalformedError(String(e));
            }
        }
        const start = index;
        if (jsonString[index] === '-')
            index++;
        while (jsonString[index] && !',]}'.includes(jsonString[index]))
            index++;
        if (index == length && !(Allow.NUM & allow))
            markPartialJSON('Unterminated number literal');
        try {
            return JSON.parse(jsonString.substring(start, index));
        }
        catch (e) {
            if (jsonString.substring(start, index) === '-' && Allow.NUM & allow)
                markPartialJSON("Not sure what '-' is");
            try {
                return JSON.parse(jsonString.substring(start, jsonString.lastIndexOf('e')));
            }
            catch (e) {
                throwMalformedError(String(e));
            }
        }
    };
    const skipBlank = () => {
        while (index < length && ' \n\r\t'.includes(jsonString[index])) {
            index++;
        }
    };
    return parseAny();
};
// using this function with malformed JSON is undefined behavior
const partialParse = (input) => parseJSON(input, Allow.ALL ^ Allow.NUM);

//# sourceMappingURL=parser.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/ChatCompletionStream.mjs
var ChatCompletionStream_classPrivateFieldSet = (undefined && undefined.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var ChatCompletionStream_classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _ChatCompletionStream_instances, _ChatCompletionStream_params, _ChatCompletionStream_choiceEventStates, _ChatCompletionStream_currentChatCompletionSnapshot, _ChatCompletionStream_beginRequest, _ChatCompletionStream_getChoiceEventState, _ChatCompletionStream_addChunk, _ChatCompletionStream_emitToolCallDoneEvent, _ChatCompletionStream_emitContentDoneEvents, _ChatCompletionStream_endRequest, _ChatCompletionStream_getAutoParseableResponseFormat, _ChatCompletionStream_accumulateChatCompletion;





class ChatCompletionStream extends AbstractChatCompletionRunner {
    constructor(params) {
        super();
        _ChatCompletionStream_instances.add(this);
        _ChatCompletionStream_params.set(this, void 0);
        _ChatCompletionStream_choiceEventStates.set(this, void 0);
        _ChatCompletionStream_currentChatCompletionSnapshot.set(this, void 0);
        ChatCompletionStream_classPrivateFieldSet(this, _ChatCompletionStream_params, params, "f");
        ChatCompletionStream_classPrivateFieldSet(this, _ChatCompletionStream_choiceEventStates, [], "f");
    }
    get currentChatCompletionSnapshot() {
        return ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_currentChatCompletionSnapshot, "f");
    }
    /**
     * Intended for use on the frontend, consuming a stream produced with
     * `.toReadableStream()` on the backend.
     *
     * Note that messages sent to the model do not appear in `.on('message')`
     * in this context.
     */
    static fromReadableStream(stream) {
        const runner = new ChatCompletionStream(null);
        runner._run(() => runner._fromReadableStream(stream));
        return runner;
    }
    static createChatCompletion(client, params, options) {
        const runner = new ChatCompletionStream(params);
        runner._run(() => runner._runChatCompletion(client, { ...params, stream: true }, { ...options, headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'stream' } }));
        return runner;
    }
    async _createChatCompletion(client, params, options) {
        super._createChatCompletion;
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_beginRequest).call(this);
        const stream = await client.chat.completions.create({ ...params, stream: true }, { ...options, signal: this.controller.signal });
        this._connected();
        for await (const chunk of stream) {
            ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_addChunk).call(this, chunk);
        }
        if (stream.controller.signal?.aborted) {
            throw new APIUserAbortError();
        }
        return this._addChatCompletion(ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_endRequest).call(this));
    }
    async _fromReadableStream(readableStream, options) {
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_beginRequest).call(this);
        this._connected();
        const stream = Stream.fromReadableStream(readableStream, this.controller);
        let chatId;
        for await (const chunk of stream) {
            if (chatId && chatId !== chunk.id) {
                // A new request has been made.
                this._addChatCompletion(ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_endRequest).call(this));
            }
            ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_addChunk).call(this, chunk);
            chatId = chunk.id;
        }
        if (stream.controller.signal?.aborted) {
            throw new APIUserAbortError();
        }
        return this._addChatCompletion(ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_endRequest).call(this));
    }
    [(_ChatCompletionStream_params = new WeakMap(), _ChatCompletionStream_choiceEventStates = new WeakMap(), _ChatCompletionStream_currentChatCompletionSnapshot = new WeakMap(), _ChatCompletionStream_instances = new WeakSet(), _ChatCompletionStream_beginRequest = function _ChatCompletionStream_beginRequest() {
        if (this.ended)
            return;
        ChatCompletionStream_classPrivateFieldSet(this, _ChatCompletionStream_currentChatCompletionSnapshot, undefined, "f");
    }, _ChatCompletionStream_getChoiceEventState = function _ChatCompletionStream_getChoiceEventState(choice) {
        let state = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_choiceEventStates, "f")[choice.index];
        if (state) {
            return state;
        }
        state = {
            content_done: false,
            refusal_done: false,
            logprobs_content_done: false,
            logprobs_refusal_done: false,
            done_tool_calls: new Set(),
            current_tool_call_index: null,
        };
        ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_choiceEventStates, "f")[choice.index] = state;
        return state;
    }, _ChatCompletionStream_addChunk = function _ChatCompletionStream_addChunk(chunk) {
        if (this.ended)
            return;
        const completion = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_accumulateChatCompletion).call(this, chunk);
        this._emit('chunk', chunk, completion);
        for (const choice of chunk.choices) {
            const choiceSnapshot = completion.choices[choice.index];
            if (choice.delta.content != null &&
                choiceSnapshot.message?.role === 'assistant' &&
                choiceSnapshot.message?.content) {
                this._emit('content', choice.delta.content, choiceSnapshot.message.content);
                this._emit('content.delta', {
                    delta: choice.delta.content,
                    snapshot: choiceSnapshot.message.content,
                    parsed: choiceSnapshot.message.parsed,
                });
            }
            if (choice.delta.refusal != null &&
                choiceSnapshot.message?.role === 'assistant' &&
                choiceSnapshot.message?.refusal) {
                this._emit('refusal.delta', {
                    delta: choice.delta.refusal,
                    snapshot: choiceSnapshot.message.refusal,
                });
            }
            if (choice.logprobs?.content != null && choiceSnapshot.message?.role === 'assistant') {
                this._emit('logprobs.content.delta', {
                    content: choice.logprobs?.content,
                    snapshot: choiceSnapshot.logprobs?.content ?? [],
                });
            }
            if (choice.logprobs?.refusal != null && choiceSnapshot.message?.role === 'assistant') {
                this._emit('logprobs.refusal.delta', {
                    refusal: choice.logprobs?.refusal,
                    snapshot: choiceSnapshot.logprobs?.refusal ?? [],
                });
            }
            const state = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_getChoiceEventState).call(this, choiceSnapshot);
            if (choiceSnapshot.finish_reason) {
                ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_emitContentDoneEvents).call(this, choiceSnapshot);
                if (state.current_tool_call_index != null) {
                    ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_emitToolCallDoneEvent).call(this, choiceSnapshot, state.current_tool_call_index);
                }
            }
            for (const toolCall of choice.delta.tool_calls ?? []) {
                if (state.current_tool_call_index !== toolCall.index) {
                    ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_emitContentDoneEvents).call(this, choiceSnapshot);
                    // new tool call started, the previous one is done
                    if (state.current_tool_call_index != null) {
                        ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_emitToolCallDoneEvent).call(this, choiceSnapshot, state.current_tool_call_index);
                    }
                }
                state.current_tool_call_index = toolCall.index;
            }
            for (const toolCallDelta of choice.delta.tool_calls ?? []) {
                const toolCallSnapshot = choiceSnapshot.message.tool_calls?.[toolCallDelta.index];
                if (!toolCallSnapshot?.type) {
                    continue;
                }
                if (toolCallSnapshot?.type === 'function') {
                    this._emit('tool_calls.function.arguments.delta', {
                        name: toolCallSnapshot.function?.name,
                        index: toolCallDelta.index,
                        arguments: toolCallSnapshot.function.arguments,
                        parsed_arguments: toolCallSnapshot.function.parsed_arguments,
                        arguments_delta: toolCallDelta.function?.arguments ?? '',
                    });
                }
                else {
                    assertNever(toolCallSnapshot?.type);
                }
            }
        }
    }, _ChatCompletionStream_emitToolCallDoneEvent = function _ChatCompletionStream_emitToolCallDoneEvent(choiceSnapshot, toolCallIndex) {
        const state = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_getChoiceEventState).call(this, choiceSnapshot);
        if (state.done_tool_calls.has(toolCallIndex)) {
            // we've already fired the done event
            return;
        }
        const toolCallSnapshot = choiceSnapshot.message.tool_calls?.[toolCallIndex];
        if (!toolCallSnapshot) {
            throw new Error('no tool call snapshot');
        }
        if (!toolCallSnapshot.type) {
            throw new Error('tool call snapshot missing `type`');
        }
        if (toolCallSnapshot.type === 'function') {
            const inputTool = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_params, "f")?.tools?.find((tool) => tool.type === 'function' && tool.function.name === toolCallSnapshot.function.name);
            this._emit('tool_calls.function.arguments.done', {
                name: toolCallSnapshot.function.name,
                index: toolCallIndex,
                arguments: toolCallSnapshot.function.arguments,
                parsed_arguments: isAutoParsableTool(inputTool) ? inputTool.$parseRaw(toolCallSnapshot.function.arguments)
                    : inputTool?.function.strict ? JSON.parse(toolCallSnapshot.function.arguments)
                        : null,
            });
        }
        else {
            assertNever(toolCallSnapshot.type);
        }
    }, _ChatCompletionStream_emitContentDoneEvents = function _ChatCompletionStream_emitContentDoneEvents(choiceSnapshot) {
        const state = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_getChoiceEventState).call(this, choiceSnapshot);
        if (choiceSnapshot.message.content && !state.content_done) {
            state.content_done = true;
            const responseFormat = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_getAutoParseableResponseFormat).call(this);
            this._emit('content.done', {
                content: choiceSnapshot.message.content,
                parsed: responseFormat ? responseFormat.$parseRaw(choiceSnapshot.message.content) : null,
            });
        }
        if (choiceSnapshot.message.refusal && !state.refusal_done) {
            state.refusal_done = true;
            this._emit('refusal.done', { refusal: choiceSnapshot.message.refusal });
        }
        if (choiceSnapshot.logprobs?.content && !state.logprobs_content_done) {
            state.logprobs_content_done = true;
            this._emit('logprobs.content.done', { content: choiceSnapshot.logprobs.content });
        }
        if (choiceSnapshot.logprobs?.refusal && !state.logprobs_refusal_done) {
            state.logprobs_refusal_done = true;
            this._emit('logprobs.refusal.done', { refusal: choiceSnapshot.logprobs.refusal });
        }
    }, _ChatCompletionStream_endRequest = function _ChatCompletionStream_endRequest() {
        if (this.ended) {
            throw new error_OpenAIError(`stream has ended, this shouldn't happen`);
        }
        const snapshot = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_currentChatCompletionSnapshot, "f");
        if (!snapshot) {
            throw new error_OpenAIError(`request ended without sending any chunks`);
        }
        ChatCompletionStream_classPrivateFieldSet(this, _ChatCompletionStream_currentChatCompletionSnapshot, undefined, "f");
        ChatCompletionStream_classPrivateFieldSet(this, _ChatCompletionStream_choiceEventStates, [], "f");
        return finalizeChatCompletion(snapshot, ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_params, "f"));
    }, _ChatCompletionStream_getAutoParseableResponseFormat = function _ChatCompletionStream_getAutoParseableResponseFormat() {
        const responseFormat = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_params, "f")?.response_format;
        if (isAutoParsableResponseFormat(responseFormat)) {
            return responseFormat;
        }
        return null;
    }, _ChatCompletionStream_accumulateChatCompletion = function _ChatCompletionStream_accumulateChatCompletion(chunk) {
        var _a, _b, _c, _d;
        let snapshot = ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_currentChatCompletionSnapshot, "f");
        const { choices, ...rest } = chunk;
        if (!snapshot) {
            snapshot = ChatCompletionStream_classPrivateFieldSet(this, _ChatCompletionStream_currentChatCompletionSnapshot, {
                ...rest,
                choices: [],
            }, "f");
        }
        else {
            Object.assign(snapshot, rest);
        }
        for (const { delta, finish_reason, index, logprobs = null, ...other } of chunk.choices) {
            let choice = snapshot.choices[index];
            if (!choice) {
                choice = snapshot.choices[index] = { finish_reason, index, message: {}, logprobs, ...other };
            }
            if (logprobs) {
                if (!choice.logprobs) {
                    choice.logprobs = Object.assign({}, logprobs);
                }
                else {
                    const { content, refusal, ...rest } = logprobs;
                    assertIsEmpty(rest);
                    Object.assign(choice.logprobs, rest);
                    if (content) {
                        (_a = choice.logprobs).content ?? (_a.content = []);
                        choice.logprobs.content.push(...content);
                    }
                    if (refusal) {
                        (_b = choice.logprobs).refusal ?? (_b.refusal = []);
                        choice.logprobs.refusal.push(...refusal);
                    }
                }
            }
            if (finish_reason) {
                choice.finish_reason = finish_reason;
                if (ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_params, "f") && hasAutoParseableInput(ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_params, "f"))) {
                    if (finish_reason === 'length') {
                        throw new LengthFinishReasonError();
                    }
                    if (finish_reason === 'content_filter') {
                        throw new ContentFilterFinishReasonError();
                    }
                }
            }
            Object.assign(choice, other);
            if (!delta)
                continue; // Shouldn't happen; just in case.
            const { content, refusal, function_call, role, tool_calls, ...rest } = delta;
            assertIsEmpty(rest);
            Object.assign(choice.message, rest);
            if (refusal) {
                choice.message.refusal = (choice.message.refusal || '') + refusal;
            }
            if (role)
                choice.message.role = role;
            if (function_call) {
                if (!choice.message.function_call) {
                    choice.message.function_call = function_call;
                }
                else {
                    if (function_call.name)
                        choice.message.function_call.name = function_call.name;
                    if (function_call.arguments) {
                        (_c = choice.message.function_call).arguments ?? (_c.arguments = '');
                        choice.message.function_call.arguments += function_call.arguments;
                    }
                }
            }
            if (content) {
                choice.message.content = (choice.message.content || '') + content;
                if (!choice.message.refusal && ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_getAutoParseableResponseFormat).call(this)) {
                    choice.message.parsed = partialParse(choice.message.content);
                }
            }
            if (tool_calls) {
                if (!choice.message.tool_calls)
                    choice.message.tool_calls = [];
                for (const { index, id, type, function: fn, ...rest } of tool_calls) {
                    const tool_call = ((_d = choice.message.tool_calls)[index] ?? (_d[index] = {}));
                    Object.assign(tool_call, rest);
                    if (id)
                        tool_call.id = id;
                    if (type)
                        tool_call.type = type;
                    if (fn)
                        tool_call.function ?? (tool_call.function = { name: fn.name ?? '', arguments: '' });
                    if (fn?.name)
                        tool_call.function.name = fn.name;
                    if (fn?.arguments) {
                        tool_call.function.arguments += fn.arguments;
                        if (shouldParseToolCall(ChatCompletionStream_classPrivateFieldGet(this, _ChatCompletionStream_params, "f"), tool_call)) {
                            tool_call.function.parsed_arguments = partialParse(tool_call.function.arguments);
                        }
                    }
                }
            }
        }
        return snapshot;
    }, Symbol.asyncIterator)]() {
        const pushQueue = [];
        const readQueue = [];
        let done = false;
        this.on('chunk', (chunk) => {
            const reader = readQueue.shift();
            if (reader) {
                reader.resolve(chunk);
            }
            else {
                pushQueue.push(chunk);
            }
        });
        this.on('end', () => {
            done = true;
            for (const reader of readQueue) {
                reader.resolve(undefined);
            }
            readQueue.length = 0;
        });
        this.on('abort', (err) => {
            done = true;
            for (const reader of readQueue) {
                reader.reject(err);
            }
            readQueue.length = 0;
        });
        this.on('error', (err) => {
            done = true;
            for (const reader of readQueue) {
                reader.reject(err);
            }
            readQueue.length = 0;
        });
        return {
            next: async () => {
                if (!pushQueue.length) {
                    if (done) {
                        return { value: undefined, done: true };
                    }
                    return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((chunk) => (chunk ? { value: chunk, done: false } : { value: undefined, done: true }));
                }
                const chunk = pushQueue.shift();
                return { value: chunk, done: false };
            },
            return: async () => {
                this.abort();
                return { value: undefined, done: true };
            },
        };
    }
    toReadableStream() {
        const stream = new Stream(this[Symbol.asyncIterator].bind(this), this.controller);
        return stream.toReadableStream();
    }
}
function finalizeChatCompletion(snapshot, params) {
    const { id, choices, created, model, system_fingerprint, ...rest } = snapshot;
    const completion = {
        ...rest,
        id,
        choices: choices.map(({ message, finish_reason, index, logprobs, ...choiceRest }) => {
            if (!finish_reason) {
                throw new error_OpenAIError(`missing finish_reason for choice ${index}`);
            }
            const { content = null, function_call, tool_calls, ...messageRest } = message;
            const role = message.role; // this is what we expect; in theory it could be different which would make our types a slight lie but would be fine.
            if (!role) {
                throw new error_OpenAIError(`missing role for choice ${index}`);
            }
            if (function_call) {
                const { arguments: args, name } = function_call;
                if (args == null) {
                    throw new error_OpenAIError(`missing function_call.arguments for choice ${index}`);
                }
                if (!name) {
                    throw new error_OpenAIError(`missing function_call.name for choice ${index}`);
                }
                return {
                    ...choiceRest,
                    message: {
                        content,
                        function_call: { arguments: args, name },
                        role,
                        refusal: message.refusal ?? null,
                    },
                    finish_reason,
                    index,
                    logprobs,
                };
            }
            if (tool_calls) {
                return {
                    ...choiceRest,
                    index,
                    finish_reason,
                    logprobs,
                    message: {
                        ...messageRest,
                        role,
                        content,
                        refusal: message.refusal ?? null,
                        tool_calls: tool_calls.map((tool_call, i) => {
                            const { function: fn, type, id, ...toolRest } = tool_call;
                            const { arguments: args, name, ...fnRest } = fn || {};
                            if (id == null) {
                                throw new error_OpenAIError(`missing choices[${index}].tool_calls[${i}].id\n${str(snapshot)}`);
                            }
                            if (type == null) {
                                throw new error_OpenAIError(`missing choices[${index}].tool_calls[${i}].type\n${str(snapshot)}`);
                            }
                            if (name == null) {
                                throw new error_OpenAIError(`missing choices[${index}].tool_calls[${i}].function.name\n${str(snapshot)}`);
                            }
                            if (args == null) {
                                throw new error_OpenAIError(`missing choices[${index}].tool_calls[${i}].function.arguments\n${str(snapshot)}`);
                            }
                            return { ...toolRest, id, type, function: { ...fnRest, name, arguments: args } };
                        }),
                    },
                };
            }
            return {
                ...choiceRest,
                message: { ...messageRest, content, role, refusal: message.refusal ?? null },
                finish_reason,
                index,
                logprobs,
            };
        }),
        created,
        model,
        object: 'chat.completion',
        ...(system_fingerprint ? { system_fingerprint } : {}),
    };
    return maybeParseChatCompletion(completion, params);
}
function str(x) {
    return JSON.stringify(x);
}
/**
 * Ensures the given argument is an empty object, useful for
 * asserting that all known properties on an object have been
 * destructured.
 */
function assertIsEmpty(obj) {
    return;
}
function assertNever(_x) { }
//# sourceMappingURL=ChatCompletionStream.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/ChatCompletionStreamingRunner.mjs

class ChatCompletionStreamingRunner extends ChatCompletionStream {
    static fromReadableStream(stream) {
        const runner = new ChatCompletionStreamingRunner(null);
        runner._run(() => runner._fromReadableStream(stream));
        return runner;
    }
    /** @deprecated - please use `runTools` instead. */
    static runFunctions(client, params, options) {
        const runner = new ChatCompletionStreamingRunner(null);
        const opts = {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'runFunctions' },
        };
        runner._run(() => runner._runFunctions(client, params, opts));
        return runner;
    }
    static runTools(client, params, options) {
        const runner = new ChatCompletionStreamingRunner(
        // @ts-expect-error TODO these types are incompatible
        params);
        const opts = {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'runTools' },
        };
        runner._run(() => runner._runTools(client, params, opts));
        return runner;
    }
}
//# sourceMappingURL=ChatCompletionStreamingRunner.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/chat/completions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.









class chat_completions_Completions extends APIResource {
    parse(body, options) {
        validateInputTools(body.tools);
        return this._client.chat.completions
            .create(body, {
            ...options,
            headers: {
                ...options?.headers,
                'X-Stainless-Helper-Method': 'beta.chat.completions.parse',
            },
        })
            ._thenUnwrap((completion) => parseChatCompletion(completion, body));
    }
    runFunctions(body, options) {
        if (body.stream) {
            return ChatCompletionStreamingRunner.runFunctions(this._client, body, options);
        }
        return ChatCompletionRunner.runFunctions(this._client, body, options);
    }
    runTools(body, options) {
        if (body.stream) {
            return ChatCompletionStreamingRunner.runTools(this._client, body, options);
        }
        return ChatCompletionRunner.runTools(this._client, body, options);
    }
    /**
     * Creates a chat completion stream
     */
    stream(body, options) {
        return ChatCompletionStream.createChatCompletion(this._client, body, options);
    }
}
//# sourceMappingURL=completions.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/chat/chat.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class chat_Chat extends APIResource {
    constructor() {
        super(...arguments);
        this.completions = new chat_completions_Completions(this._client);
    }
}
(function (Chat) {
    Chat.Completions = chat_completions_Completions;
})(chat_Chat || (chat_Chat = {}));
//# sourceMappingURL=chat.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/realtime/sessions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class Sessions extends APIResource {
    /**
     * Create an ephemeral API token for use in client-side applications with the
     * Realtime API. Can be configured with the same session parameters as the
     * `session.update` client event.
     *
     * It responds with a session object, plus a `client_secret` key which contains a
     * usable ephemeral API token that can be used to authenticate browser clients for
     * the Realtime API.
     */
    create(body, options) {
        return this._client.post('/realtime/sessions', {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
}
//# sourceMappingURL=sessions.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/realtime/transcription-sessions.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

class TranscriptionSessions extends APIResource {
    /**
     * Create an ephemeral API token for use in client-side applications with the
     * Realtime API specifically for realtime transcriptions. Can be configured with
     * the same session parameters as the `transcription_session.update` client event.
     *
     * It responds with a session object, plus a `client_secret` key which contains a
     * usable ephemeral API token that can be used to authenticate browser clients for
     * the Realtime API.
     */
    create(body, options) {
        return this._client.post('/realtime/transcription_sessions', {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
}
//# sourceMappingURL=transcription-sessions.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/realtime/realtime.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.





class Realtime extends APIResource {
    constructor() {
        super(...arguments);
        this.sessions = new Sessions(this._client);
        this.transcriptionSessions = new TranscriptionSessions(this._client);
    }
}
Realtime.Sessions = Sessions;
Realtime.TranscriptionSessions = TranscriptionSessions;
//# sourceMappingURL=realtime.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/AssistantStream.mjs
var AssistantStream_classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var AssistantStream_classPrivateFieldSet = (undefined && undefined.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var _AssistantStream_instances, _AssistantStream_events, _AssistantStream_runStepSnapshots, _AssistantStream_messageSnapshots, _AssistantStream_messageSnapshot, _AssistantStream_finalRun, _AssistantStream_currentContentIndex, _AssistantStream_currentContent, _AssistantStream_currentToolCallIndex, _AssistantStream_currentToolCall, _AssistantStream_currentEvent, _AssistantStream_currentRunSnapshot, _AssistantStream_currentRunStepSnapshot, _AssistantStream_addEvent, _AssistantStream_endRequest, _AssistantStream_handleMessage, _AssistantStream_handleRunStep, _AssistantStream_handleEvent, _AssistantStream_accumulateRunStep, _AssistantStream_accumulateMessage, _AssistantStream_accumulateContent, _AssistantStream_handleRun;




class AssistantStream extends EventStream {
    constructor() {
        super(...arguments);
        _AssistantStream_instances.add(this);
        //Track all events in a single list for reference
        _AssistantStream_events.set(this, []);
        //Used to accumulate deltas
        //We are accumulating many types so the value here is not strict
        _AssistantStream_runStepSnapshots.set(this, {});
        _AssistantStream_messageSnapshots.set(this, {});
        _AssistantStream_messageSnapshot.set(this, void 0);
        _AssistantStream_finalRun.set(this, void 0);
        _AssistantStream_currentContentIndex.set(this, void 0);
        _AssistantStream_currentContent.set(this, void 0);
        _AssistantStream_currentToolCallIndex.set(this, void 0);
        _AssistantStream_currentToolCall.set(this, void 0);
        //For current snapshot methods
        _AssistantStream_currentEvent.set(this, void 0);
        _AssistantStream_currentRunSnapshot.set(this, void 0);
        _AssistantStream_currentRunStepSnapshot.set(this, void 0);
    }
    [(_AssistantStream_events = new WeakMap(), _AssistantStream_runStepSnapshots = new WeakMap(), _AssistantStream_messageSnapshots = new WeakMap(), _AssistantStream_messageSnapshot = new WeakMap(), _AssistantStream_finalRun = new WeakMap(), _AssistantStream_currentContentIndex = new WeakMap(), _AssistantStream_currentContent = new WeakMap(), _AssistantStream_currentToolCallIndex = new WeakMap(), _AssistantStream_currentToolCall = new WeakMap(), _AssistantStream_currentEvent = new WeakMap(), _AssistantStream_currentRunSnapshot = new WeakMap(), _AssistantStream_currentRunStepSnapshot = new WeakMap(), _AssistantStream_instances = new WeakSet(), Symbol.asyncIterator)]() {
        const pushQueue = [];
        const readQueue = [];
        let done = false;
        //Catch all for passing along all events
        this.on('event', (event) => {
            const reader = readQueue.shift();
            if (reader) {
                reader.resolve(event);
            }
            else {
                pushQueue.push(event);
            }
        });
        this.on('end', () => {
            done = true;
            for (const reader of readQueue) {
                reader.resolve(undefined);
            }
            readQueue.length = 0;
        });
        this.on('abort', (err) => {
            done = true;
            for (const reader of readQueue) {
                reader.reject(err);
            }
            readQueue.length = 0;
        });
        this.on('error', (err) => {
            done = true;
            for (const reader of readQueue) {
                reader.reject(err);
            }
            readQueue.length = 0;
        });
        return {
            next: async () => {
                if (!pushQueue.length) {
                    if (done) {
                        return { value: undefined, done: true };
                    }
                    return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((chunk) => (chunk ? { value: chunk, done: false } : { value: undefined, done: true }));
                }
                const chunk = pushQueue.shift();
                return { value: chunk, done: false };
            },
            return: async () => {
                this.abort();
                return { value: undefined, done: true };
            },
        };
    }
    static fromReadableStream(stream) {
        const runner = new AssistantStream();
        runner._run(() => runner._fromReadableStream(stream));
        return runner;
    }
    async _fromReadableStream(readableStream, options) {
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        this._connected();
        const stream = Stream.fromReadableStream(readableStream, this.controller);
        for await (const event of stream) {
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_addEvent).call(this, event);
        }
        if (stream.controller.signal?.aborted) {
            throw new APIUserAbortError();
        }
        return this._addRun(AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_endRequest).call(this));
    }
    toReadableStream() {
        const stream = new Stream(this[Symbol.asyncIterator].bind(this), this.controller);
        return stream.toReadableStream();
    }
    static createToolAssistantStream(threadId, runId, runs, params, options) {
        const runner = new AssistantStream();
        runner._run(() => runner._runToolAssistantStream(threadId, runId, runs, params, {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'stream' },
        }));
        return runner;
    }
    async _createToolAssistantStream(run, threadId, runId, params, options) {
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        const body = { ...params, stream: true };
        const stream = await run.submitToolOutputs(threadId, runId, body, {
            ...options,
            signal: this.controller.signal,
        });
        this._connected();
        for await (const event of stream) {
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_addEvent).call(this, event);
        }
        if (stream.controller.signal?.aborted) {
            throw new APIUserAbortError();
        }
        return this._addRun(AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_endRequest).call(this));
    }
    static createThreadAssistantStream(params, thread, options) {
        const runner = new AssistantStream();
        runner._run(() => runner._threadAssistantStream(params, thread, {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'stream' },
        }));
        return runner;
    }
    static createAssistantStream(threadId, runs, params, options) {
        const runner = new AssistantStream();
        runner._run(() => runner._runAssistantStream(threadId, runs, params, {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'stream' },
        }));
        return runner;
    }
    currentEvent() {
        return AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentEvent, "f");
    }
    currentRun() {
        return AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentRunSnapshot, "f");
    }
    currentMessageSnapshot() {
        return AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshot, "f");
    }
    currentRunStepSnapshot() {
        return AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentRunStepSnapshot, "f");
    }
    async finalRunSteps() {
        await this.done();
        return Object.values(AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f"));
    }
    async finalMessages() {
        await this.done();
        return Object.values(AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshots, "f"));
    }
    async finalRun() {
        await this.done();
        if (!AssistantStream_classPrivateFieldGet(this, _AssistantStream_finalRun, "f"))
            throw Error('Final run was not received.');
        return AssistantStream_classPrivateFieldGet(this, _AssistantStream_finalRun, "f");
    }
    async _createThreadAssistantStream(thread, params, options) {
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        const body = { ...params, stream: true };
        const stream = await thread.createAndRun(body, { ...options, signal: this.controller.signal });
        this._connected();
        for await (const event of stream) {
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_addEvent).call(this, event);
        }
        if (stream.controller.signal?.aborted) {
            throw new APIUserAbortError();
        }
        return this._addRun(AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_endRequest).call(this));
    }
    async _createAssistantStream(run, threadId, params, options) {
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        const body = { ...params, stream: true };
        const stream = await run.create(threadId, body, { ...options, signal: this.controller.signal });
        this._connected();
        for await (const event of stream) {
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_addEvent).call(this, event);
        }
        if (stream.controller.signal?.aborted) {
            throw new APIUserAbortError();
        }
        return this._addRun(AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_endRequest).call(this));
    }
    static accumulateDelta(acc, delta) {
        for (const [key, deltaValue] of Object.entries(delta)) {
            if (!acc.hasOwnProperty(key)) {
                acc[key] = deltaValue;
                continue;
            }
            let accValue = acc[key];
            if (accValue === null || accValue === undefined) {
                acc[key] = deltaValue;
                continue;
            }
            // We don't accumulate these special properties
            if (key === 'index' || key === 'type') {
                acc[key] = deltaValue;
                continue;
            }
            // Type-specific accumulation logic
            if (typeof accValue === 'string' && typeof deltaValue === 'string') {
                accValue += deltaValue;
            }
            else if (typeof accValue === 'number' && typeof deltaValue === 'number') {
                accValue += deltaValue;
            }
            else if (isObj(accValue) && isObj(deltaValue)) {
                accValue = this.accumulateDelta(accValue, deltaValue);
            }
            else if (Array.isArray(accValue) && Array.isArray(deltaValue)) {
                if (accValue.every((x) => typeof x === 'string' || typeof x === 'number')) {
                    accValue.push(...deltaValue); // Use spread syntax for efficient addition
                    continue;
                }
                for (const deltaEntry of deltaValue) {
                    if (!isObj(deltaEntry)) {
                        throw new Error(`Expected array delta entry to be an object but got: ${deltaEntry}`);
                    }
                    const index = deltaEntry['index'];
                    if (index == null) {
                        console.error(deltaEntry);
                        throw new Error('Expected array delta entry to have an `index` property');
                    }
                    if (typeof index !== 'number') {
                        throw new Error(`Expected array delta entry \`index\` property to be a number but got ${index}`);
                    }
                    const accEntry = accValue[index];
                    if (accEntry == null) {
                        accValue.push(deltaEntry);
                    }
                    else {
                        accValue[index] = this.accumulateDelta(accEntry, deltaEntry);
                    }
                }
                continue;
            }
            else {
                throw Error(`Unhandled record type: ${key}, deltaValue: ${deltaValue}, accValue: ${accValue}`);
            }
            acc[key] = accValue;
        }
        return acc;
    }
    _addRun(run) {
        return run;
    }
    async _threadAssistantStream(params, thread, options) {
        return await this._createThreadAssistantStream(thread, params, options);
    }
    async _runAssistantStream(threadId, runs, params, options) {
        return await this._createAssistantStream(runs, threadId, params, options);
    }
    async _runToolAssistantStream(threadId, runId, runs, params, options) {
        return await this._createToolAssistantStream(runs, threadId, runId, params, options);
    }
}
_AssistantStream_addEvent = function _AssistantStream_addEvent(event) {
    if (this.ended)
        return;
    AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentEvent, event, "f");
    AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_handleEvent).call(this, event);
    switch (event.event) {
        case 'thread.created':
            //No action on this event.
            break;
        case 'thread.run.created':
        case 'thread.run.queued':
        case 'thread.run.in_progress':
        case 'thread.run.requires_action':
        case 'thread.run.completed':
        case 'thread.run.incomplete':
        case 'thread.run.failed':
        case 'thread.run.cancelling':
        case 'thread.run.cancelled':
        case 'thread.run.expired':
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_handleRun).call(this, event);
            break;
        case 'thread.run.step.created':
        case 'thread.run.step.in_progress':
        case 'thread.run.step.delta':
        case 'thread.run.step.completed':
        case 'thread.run.step.failed':
        case 'thread.run.step.cancelled':
        case 'thread.run.step.expired':
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_handleRunStep).call(this, event);
            break;
        case 'thread.message.created':
        case 'thread.message.in_progress':
        case 'thread.message.delta':
        case 'thread.message.completed':
        case 'thread.message.incomplete':
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_handleMessage).call(this, event);
            break;
        case 'error':
            //This is included for completeness, but errors are processed in the SSE event processing so this should not occur
            throw new Error('Encountered an error event in event processing - errors should be processed earlier');
        default:
            AssistantStream_assertNever(event);
    }
}, _AssistantStream_endRequest = function _AssistantStream_endRequest() {
    if (this.ended) {
        throw new error_OpenAIError(`stream has ended, this shouldn't happen`);
    }
    if (!AssistantStream_classPrivateFieldGet(this, _AssistantStream_finalRun, "f"))
        throw Error('Final run has not been received');
    return AssistantStream_classPrivateFieldGet(this, _AssistantStream_finalRun, "f");
}, _AssistantStream_handleMessage = function _AssistantStream_handleMessage(event) {
    const [accumulatedMessage, newContent] = AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_accumulateMessage).call(this, event, AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshot, "f"));
    AssistantStream_classPrivateFieldSet(this, _AssistantStream_messageSnapshot, accumulatedMessage, "f");
    AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshots, "f")[accumulatedMessage.id] = accumulatedMessage;
    for (const content of newContent) {
        const snapshotContent = accumulatedMessage.content[content.index];
        if (snapshotContent?.type == 'text') {
            this._emit('textCreated', snapshotContent.text);
        }
    }
    switch (event.event) {
        case 'thread.message.created':
            this._emit('messageCreated', event.data);
            break;
        case 'thread.message.in_progress':
            break;
        case 'thread.message.delta':
            this._emit('messageDelta', event.data.delta, accumulatedMessage);
            if (event.data.delta.content) {
                for (const content of event.data.delta.content) {
                    //If it is text delta, emit a text delta event
                    if (content.type == 'text' && content.text) {
                        let textDelta = content.text;
                        let snapshot = accumulatedMessage.content[content.index];
                        if (snapshot && snapshot.type == 'text') {
                            this._emit('textDelta', textDelta, snapshot.text);
                        }
                        else {
                            throw Error('The snapshot associated with this text delta is not text or missing');
                        }
                    }
                    if (content.index != AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentContentIndex, "f")) {
                        //See if we have in progress content
                        if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentContent, "f")) {
                            switch (AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentContent, "f").type) {
                                case 'text':
                                    this._emit('textDone', AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentContent, "f").text, AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshot, "f"));
                                    break;
                                case 'image_file':
                                    this._emit('imageFileDone', AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentContent, "f").image_file, AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshot, "f"));
                                    break;
                            }
                        }
                        AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentContentIndex, content.index, "f");
                    }
                    AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentContent, accumulatedMessage.content[content.index], "f");
                }
            }
            break;
        case 'thread.message.completed':
        case 'thread.message.incomplete':
            //We emit the latest content we were working on on completion (including incomplete)
            if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentContentIndex, "f") !== undefined) {
                const currentContent = event.data.content[AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentContentIndex, "f")];
                if (currentContent) {
                    switch (currentContent.type) {
                        case 'image_file':
                            this._emit('imageFileDone', currentContent.image_file, AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshot, "f"));
                            break;
                        case 'text':
                            this._emit('textDone', currentContent.text, AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshot, "f"));
                            break;
                    }
                }
            }
            if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_messageSnapshot, "f")) {
                this._emit('messageDone', event.data);
            }
            AssistantStream_classPrivateFieldSet(this, _AssistantStream_messageSnapshot, undefined, "f");
    }
}, _AssistantStream_handleRunStep = function _AssistantStream_handleRunStep(event) {
    const accumulatedRunStep = AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_accumulateRunStep).call(this, event);
    AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentRunStepSnapshot, accumulatedRunStep, "f");
    switch (event.event) {
        case 'thread.run.step.created':
            this._emit('runStepCreated', event.data);
            break;
        case 'thread.run.step.delta':
            const delta = event.data.delta;
            if (delta.step_details &&
                delta.step_details.type == 'tool_calls' &&
                delta.step_details.tool_calls &&
                accumulatedRunStep.step_details.type == 'tool_calls') {
                for (const toolCall of delta.step_details.tool_calls) {
                    if (toolCall.index == AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCallIndex, "f")) {
                        this._emit('toolCallDelta', toolCall, accumulatedRunStep.step_details.tool_calls[toolCall.index]);
                    }
                    else {
                        if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f")) {
                            this._emit('toolCallDone', AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f"));
                        }
                        AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentToolCallIndex, toolCall.index, "f");
                        AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentToolCall, accumulatedRunStep.step_details.tool_calls[toolCall.index], "f");
                        if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f"))
                            this._emit('toolCallCreated', AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f"));
                    }
                }
            }
            this._emit('runStepDelta', event.data.delta, accumulatedRunStep);
            break;
        case 'thread.run.step.completed':
        case 'thread.run.step.failed':
        case 'thread.run.step.cancelled':
        case 'thread.run.step.expired':
            AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentRunStepSnapshot, undefined, "f");
            const details = event.data.step_details;
            if (details.type == 'tool_calls') {
                if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f")) {
                    this._emit('toolCallDone', AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f"));
                    AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentToolCall, undefined, "f");
                }
            }
            this._emit('runStepDone', event.data, accumulatedRunStep);
            break;
        case 'thread.run.step.in_progress':
            break;
    }
}, _AssistantStream_handleEvent = function _AssistantStream_handleEvent(event) {
    AssistantStream_classPrivateFieldGet(this, _AssistantStream_events, "f").push(event);
    this._emit('event', event);
}, _AssistantStream_accumulateRunStep = function _AssistantStream_accumulateRunStep(event) {
    switch (event.event) {
        case 'thread.run.step.created':
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f")[event.data.id] = event.data;
            return event.data;
        case 'thread.run.step.delta':
            let snapshot = AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f")[event.data.id];
            if (!snapshot) {
                throw Error('Received a RunStepDelta before creation of a snapshot');
            }
            let data = event.data;
            if (data.delta) {
                const accumulated = AssistantStream.accumulateDelta(snapshot, data.delta);
                AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f")[event.data.id] = accumulated;
            }
            return AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f")[event.data.id];
        case 'thread.run.step.completed':
        case 'thread.run.step.failed':
        case 'thread.run.step.cancelled':
        case 'thread.run.step.expired':
        case 'thread.run.step.in_progress':
            AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f")[event.data.id] = event.data;
            break;
    }
    if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f")[event.data.id])
        return AssistantStream_classPrivateFieldGet(this, _AssistantStream_runStepSnapshots, "f")[event.data.id];
    throw new Error('No snapshot available');
}, _AssistantStream_accumulateMessage = function _AssistantStream_accumulateMessage(event, snapshot) {
    let newContent = [];
    switch (event.event) {
        case 'thread.message.created':
            //On creation the snapshot is just the initial message
            return [event.data, newContent];
        case 'thread.message.delta':
            if (!snapshot) {
                throw Error('Received a delta with no existing snapshot (there should be one from message creation)');
            }
            let data = event.data;
            //If this delta does not have content, nothing to process
            if (data.delta.content) {
                for (const contentElement of data.delta.content) {
                    if (contentElement.index in snapshot.content) {
                        let currentContent = snapshot.content[contentElement.index];
                        snapshot.content[contentElement.index] = AssistantStream_classPrivateFieldGet(this, _AssistantStream_instances, "m", _AssistantStream_accumulateContent).call(this, contentElement, currentContent);
                    }
                    else {
                        snapshot.content[contentElement.index] = contentElement;
                        // This is a new element
                        newContent.push(contentElement);
                    }
                }
            }
            return [snapshot, newContent];
        case 'thread.message.in_progress':
        case 'thread.message.completed':
        case 'thread.message.incomplete':
            //No changes on other thread events
            if (snapshot) {
                return [snapshot, newContent];
            }
            else {
                throw Error('Received thread message event with no existing snapshot');
            }
    }
    throw Error('Tried to accumulate a non-message event');
}, _AssistantStream_accumulateContent = function _AssistantStream_accumulateContent(contentElement, currentContent) {
    return AssistantStream.accumulateDelta(currentContent, contentElement);
}, _AssistantStream_handleRun = function _AssistantStream_handleRun(event) {
    AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentRunSnapshot, event.data, "f");
    switch (event.event) {
        case 'thread.run.created':
            break;
        case 'thread.run.queued':
            break;
        case 'thread.run.in_progress':
            break;
        case 'thread.run.requires_action':
        case 'thread.run.cancelled':
        case 'thread.run.failed':
        case 'thread.run.completed':
        case 'thread.run.expired':
            AssistantStream_classPrivateFieldSet(this, _AssistantStream_finalRun, event.data, "f");
            if (AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f")) {
                this._emit('toolCallDone', AssistantStream_classPrivateFieldGet(this, _AssistantStream_currentToolCall, "f"));
                AssistantStream_classPrivateFieldSet(this, _AssistantStream_currentToolCall, undefined, "f");
            }
            break;
        case 'thread.run.cancelling':
            break;
    }
};
function AssistantStream_assertNever(_x) { }
//# sourceMappingURL=AssistantStream.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/threads/messages.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class messages_Messages extends APIResource {
    /**
     * Create a message.
     */
    create(threadId, body, options) {
        return this._client.post(`/threads/${threadId}/messages`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Retrieve a message.
     */
    retrieve(threadId, messageId, options) {
        return this._client.get(`/threads/${threadId}/messages/${messageId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Modifies a message.
     */
    update(threadId, messageId, body, options) {
        return this._client.post(`/threads/${threadId}/messages/${messageId}`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    list(threadId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(threadId, {}, query);
        }
        return this._client.getAPIList(`/threads/${threadId}/messages`, MessagesPage, {
            query,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Deletes a message.
     */
    del(threadId, messageId, options) {
        return this._client.delete(`/threads/${threadId}/messages/${messageId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
}
class MessagesPage extends CursorPage {
}
messages_Messages.MessagesPage = MessagesPage;
//# sourceMappingURL=messages.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/threads/runs/steps.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class Steps extends APIResource {
    retrieve(threadId, runId, stepId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.retrieve(threadId, runId, stepId, {}, query);
        }
        return this._client.get(`/threads/${threadId}/runs/${runId}/steps/${stepId}`, {
            query,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    list(threadId, runId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(threadId, runId, {}, query);
        }
        return this._client.getAPIList(`/threads/${threadId}/runs/${runId}/steps`, RunStepsPage, {
            query,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
}
class RunStepsPage extends CursorPage {
}
Steps.RunStepsPage = RunStepsPage;
//# sourceMappingURL=steps.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/threads/runs/runs.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.







class Runs extends APIResource {
    constructor() {
        super(...arguments);
        this.steps = new Steps(this._client);
    }
    create(threadId, params, options) {
        const { include, ...body } = params;
        return this._client.post(`/threads/${threadId}/runs`, {
            query: { include },
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
            stream: params.stream ?? false,
        });
    }
    /**
     * Retrieves a run.
     */
    retrieve(threadId, runId, options) {
        return this._client.get(`/threads/${threadId}/runs/${runId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Modifies a run.
     */
    update(threadId, runId, body, options) {
        return this._client.post(`/threads/${threadId}/runs/${runId}`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    list(threadId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(threadId, {}, query);
        }
        return this._client.getAPIList(`/threads/${threadId}/runs`, RunsPage, {
            query,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Cancels a run that is `in_progress`.
     */
    cancel(threadId, runId, options) {
        return this._client.post(`/threads/${threadId}/runs/${runId}/cancel`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * A helper to create a run an poll for a terminal state. More information on Run
     * lifecycles can be found here:
     * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
     */
    async createAndPoll(threadId, body, options) {
        const run = await this.create(threadId, body, options);
        return await this.poll(threadId, run.id, options);
    }
    /**
     * Create a Run stream
     *
     * @deprecated use `stream` instead
     */
    createAndStream(threadId, body, options) {
        return AssistantStream.createAssistantStream(threadId, this._client.beta.threads.runs, body, options);
    }
    /**
     * A helper to poll a run status until it reaches a terminal state. More
     * information on Run lifecycles can be found here:
     * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
     */
    async poll(threadId, runId, options) {
        const headers = { ...options?.headers, 'X-Stainless-Poll-Helper': 'true' };
        if (options?.pollIntervalMs) {
            headers['X-Stainless-Custom-Poll-Interval'] = options.pollIntervalMs.toString();
        }
        while (true) {
            const { data: run, response } = await this.retrieve(threadId, runId, {
                ...options,
                headers: { ...options?.headers, ...headers },
            }).withResponse();
            switch (run.status) {
                //If we are in any sort of intermediate state we poll
                case 'queued':
                case 'in_progress':
                case 'cancelling':
                    let sleepInterval = 5000;
                    if (options?.pollIntervalMs) {
                        sleepInterval = options.pollIntervalMs;
                    }
                    else {
                        const headerInterval = response.headers.get('openai-poll-after-ms');
                        if (headerInterval) {
                            const headerIntervalMs = parseInt(headerInterval);
                            if (!isNaN(headerIntervalMs)) {
                                sleepInterval = headerIntervalMs;
                            }
                        }
                    }
                    await sleep(sleepInterval);
                    break;
                //We return the run in any terminal state.
                case 'requires_action':
                case 'incomplete':
                case 'cancelled':
                case 'completed':
                case 'failed':
                case 'expired':
                    return run;
            }
        }
    }
    /**
     * Create a Run stream
     */
    stream(threadId, body, options) {
        return AssistantStream.createAssistantStream(threadId, this._client.beta.threads.runs, body, options);
    }
    submitToolOutputs(threadId, runId, body, options) {
        return this._client.post(`/threads/${threadId}/runs/${runId}/submit_tool_outputs`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
            stream: body.stream ?? false,
        });
    }
    /**
     * A helper to submit a tool output to a run and poll for a terminal run state.
     * More information on Run lifecycles can be found here:
     * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
     */
    async submitToolOutputsAndPoll(threadId, runId, body, options) {
        const run = await this.submitToolOutputs(threadId, runId, body, options);
        return await this.poll(threadId, run.id, options);
    }
    /**
     * Submit the tool outputs from a previous run and stream the run to a terminal
     * state. More information on Run lifecycles can be found here:
     * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
     */
    submitToolOutputsStream(threadId, runId, body, options) {
        return AssistantStream.createToolAssistantStream(threadId, runId, this._client.beta.threads.runs, body, options);
    }
}
class RunsPage extends CursorPage {
}
Runs.RunsPage = RunsPage;
Runs.Steps = Steps;
Runs.RunStepsPage = RunStepsPage;
//# sourceMappingURL=runs.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/threads/threads.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.







class Threads extends APIResource {
    constructor() {
        super(...arguments);
        this.runs = new Runs(this._client);
        this.messages = new messages_Messages(this._client);
    }
    create(body = {}, options) {
        if (isRequestOptions(body)) {
            return this.create({}, body);
        }
        return this._client.post('/threads', {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Retrieves a thread.
     */
    retrieve(threadId, options) {
        return this._client.get(`/threads/${threadId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Modifies a thread.
     */
    update(threadId, body, options) {
        return this._client.post(`/threads/${threadId}`, {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    /**
     * Delete a thread.
     */
    del(threadId, options) {
        return this._client.delete(`/threads/${threadId}`, {
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
        });
    }
    createAndRun(body, options) {
        return this._client.post('/threads/runs', {
            body,
            ...options,
            headers: { 'OpenAI-Beta': 'assistants=v2', ...options?.headers },
            stream: body.stream ?? false,
        });
    }
    /**
     * A helper to create a thread, start a run and then poll for a terminal state.
     * More information on Run lifecycles can be found here:
     * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
     */
    async createAndRunPoll(body, options) {
        const run = await this.createAndRun(body, options);
        return await this.runs.poll(run.thread_id, run.id, options);
    }
    /**
     * Create a thread and stream the run back
     */
    createAndRunStream(body, options) {
        return AssistantStream.createThreadAssistantStream(body, this._client.beta.threads, options);
    }
}
Threads.Runs = Runs;
Threads.RunsPage = RunsPage;
Threads.Messages = messages_Messages;
Threads.MessagesPage = MessagesPage;
//# sourceMappingURL=threads.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/beta/beta.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.









class Beta extends APIResource {
    constructor() {
        super(...arguments);
        this.realtime = new Realtime(this._client);
        this.chat = new chat_Chat(this._client);
        this.assistants = new Assistants(this._client);
        this.threads = new Threads(this._client);
    }
}
Beta.Realtime = Realtime;
Beta.Assistants = Assistants;
Beta.AssistantsPage = AssistantsPage;
Beta.Threads = Threads;
//# sourceMappingURL=beta.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/batches.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class Batches extends APIResource {
    /**
     * Creates and executes a batch from an uploaded file of requests
     */
    create(body, options) {
        return this._client.post('/batches', { body, ...options });
    }
    /**
     * Retrieves a batch.
     */
    retrieve(batchId, options) {
        return this._client.get(`/batches/${batchId}`, options);
    }
    list(query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list({}, query);
        }
        return this._client.getAPIList('/batches', BatchesPage, { query, ...options });
    }
    /**
     * Cancels an in-progress batch. The batch will be in status `cancelling` for up to
     * 10 minutes, before changing to `cancelled`, where it will have partial results
     * (if any) available in the output file.
     */
    cancel(batchId, options) {
        return this._client.post(`/batches/${batchId}/cancel`, options);
    }
}
class BatchesPage extends CursorPage {
}
Batches.BatchesPage = BatchesPage;
//# sourceMappingURL=batches.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/uploads/parts.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


class Parts extends APIResource {
    /**
     * Adds a
     * [Part](https://platform.openai.com/docs/api-reference/uploads/part-object) to an
     * [Upload](https://platform.openai.com/docs/api-reference/uploads/object) object.
     * A Part represents a chunk of bytes from the file you are trying to upload.
     *
     * Each Part can be at most 64 MB, and you can add Parts until you hit the Upload
     * maximum of 8 GB.
     *
     * It is possible to add multiple Parts in parallel. You can decide the intended
     * order of the Parts when you
     * [complete the Upload](https://platform.openai.com/docs/api-reference/uploads/complete).
     */
    create(uploadId, body, options) {
        return this._client.post(`/uploads/${uploadId}/parts`, multipartFormRequestOptions({ body, ...options }));
    }
}
//# sourceMappingURL=parts.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/uploads/uploads.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class Uploads extends APIResource {
    constructor() {
        super(...arguments);
        this.parts = new Parts(this._client);
    }
    /**
     * Creates an intermediate
     * [Upload](https://platform.openai.com/docs/api-reference/uploads/object) object
     * that you can add
     * [Parts](https://platform.openai.com/docs/api-reference/uploads/part-object) to.
     * Currently, an Upload can accept at most 8 GB in total and expires after an hour
     * after you create it.
     *
     * Once you complete the Upload, we will create a
     * [File](https://platform.openai.com/docs/api-reference/files/object) object that
     * contains all the parts you uploaded. This File is usable in the rest of our
     * platform as a regular File object.
     *
     * For certain `purpose` values, the correct `mime_type` must be specified. Please
     * refer to documentation for the
     * [supported MIME types for your use case](https://platform.openai.com/docs/assistants/tools/file-search#supported-files).
     *
     * For guidance on the proper filename extensions for each purpose, please follow
     * the documentation on
     * [creating a File](https://platform.openai.com/docs/api-reference/files/create).
     */
    create(body, options) {
        return this._client.post('/uploads', { body, ...options });
    }
    /**
     * Cancels the Upload. No Parts may be added after an Upload is cancelled.
     */
    cancel(uploadId, options) {
        return this._client.post(`/uploads/${uploadId}/cancel`, options);
    }
    /**
     * Completes the
     * [Upload](https://platform.openai.com/docs/api-reference/uploads/object).
     *
     * Within the returned Upload object, there is a nested
     * [File](https://platform.openai.com/docs/api-reference/files/object) object that
     * is ready to use in the rest of the platform.
     *
     * You can specify the order of the Parts by passing in an ordered list of the Part
     * IDs.
     *
     * The number of bytes uploaded upon completion must match the number of bytes
     * initially specified when creating the Upload object. No Parts may be added after
     * an Upload is completed.
     */
    complete(uploadId, body, options) {
        return this._client.post(`/uploads/${uploadId}/complete`, { body, ...options });
    }
}
Uploads.Parts = Parts;
//# sourceMappingURL=uploads.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/ResponsesParser.mjs


function maybeParseResponse(response, params) {
    if (!params || !ResponsesParser_hasAutoParseableInput(params)) {
        return {
            ...response,
            output_parsed: null,
            output: response.output.map((item) => {
                if (item.type === 'function_call') {
                    return {
                        ...item,
                        parsed_arguments: null,
                    };
                }
                if (item.type === 'message') {
                    return {
                        ...item,
                        content: item.content.map((content) => ({
                            ...content,
                            parsed: null,
                        })),
                    };
                }
                else {
                    return item;
                }
            }),
        };
    }
    return parseResponse(response, params);
}
function parseResponse(response, params) {
    const output = response.output.map((item) => {
        if (item.type === 'function_call') {
            return {
                ...item,
                parsed_arguments: ResponsesParser_parseToolCall(params, item),
            };
        }
        if (item.type === 'message') {
            const content = item.content.map((content) => {
                if (content.type === 'output_text') {
                    return {
                        ...content,
                        parsed: parseTextFormat(params, content.text),
                    };
                }
                return content;
            });
            return {
                ...item,
                content,
            };
        }
        return item;
    });
    const parsed = Object.assign({}, response, { output });
    if (!Object.getOwnPropertyDescriptor(response, 'output_text')) {
        addOutputText(parsed);
    }
    Object.defineProperty(parsed, 'output_parsed', {
        enumerable: true,
        get() {
            for (const output of parsed.output) {
                if (output.type !== 'message') {
                    continue;
                }
                for (const content of output.content) {
                    if (content.type === 'output_text' && content.parsed !== null) {
                        return content.parsed;
                    }
                }
            }
            return null;
        },
    });
    return parsed;
}
function parseTextFormat(params, content) {
    if (params.text?.format?.type !== 'json_schema') {
        return null;
    }
    if ('$parseRaw' in params.text?.format) {
        const text_format = params.text?.format;
        return text_format.$parseRaw(content);
    }
    return JSON.parse(content);
}
function ResponsesParser_hasAutoParseableInput(params) {
    if (isAutoParsableResponseFormat(params.text?.format)) {
        return true;
    }
    return false;
}
function makeParseableResponseTool(tool, { parser, callback, }) {
    const obj = { ...tool };
    Object.defineProperties(obj, {
        $brand: {
            value: 'auto-parseable-tool',
            enumerable: false,
        },
        $parseRaw: {
            value: parser,
            enumerable: false,
        },
        $callback: {
            value: callback,
            enumerable: false,
        },
    });
    return obj;
}
function ResponsesParser_isAutoParsableTool(tool) {
    return tool?.['$brand'] === 'auto-parseable-tool';
}
function getInputToolByName(input_tools, name) {
    return input_tools.find((tool) => tool.type === 'function' && tool.name === name);
}
function ResponsesParser_parseToolCall(params, toolCall) {
    const inputTool = getInputToolByName(params.tools ?? [], toolCall.name);
    return {
        ...toolCall,
        ...toolCall,
        parsed_arguments: ResponsesParser_isAutoParsableTool(inputTool) ? inputTool.$parseRaw(toolCall.arguments)
            : inputTool?.strict ? JSON.parse(toolCall.arguments)
                : null,
    };
}
function ResponsesParser_shouldParseToolCall(params, toolCall) {
    if (!params) {
        return false;
    }
    const inputTool = getInputToolByName(params.tools ?? [], toolCall.name);
    return ResponsesParser_isAutoParsableTool(inputTool) || inputTool?.strict || false;
}
function ResponsesParser_validateInputTools(tools) {
    for (const tool of tools ?? []) {
        if (tool.type !== 'function') {
            throw new OpenAIError(`Currently only \`function\` tool types support auto-parsing; Received \`${tool.type}\``);
        }
        if (tool.function.strict !== true) {
            throw new OpenAIError(`The \`${tool.function.name}\` tool is not marked with \`strict: true\`. Only strict function tools can be auto-parsed`);
        }
    }
}
function addOutputText(rsp) {
    const texts = [];
    for (const output of rsp.output) {
        if (output.type !== 'message') {
            continue;
        }
        for (const content of output.content) {
            if (content.type === 'output_text') {
                texts.push(content.text);
            }
        }
    }
    rsp.output_text = texts.join('');
}
//# sourceMappingURL=ResponsesParser.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/responses/input-items.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



class InputItems extends APIResource {
    list(responseId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(responseId, {}, query);
        }
        return this._client.getAPIList(`/responses/${responseId}/input_items`, ResponseItemsPage, {
            query,
            ...options,
        });
    }
}

//# sourceMappingURL=input-items.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/lib/responses/ResponseStream.mjs
var ResponseStream_classPrivateFieldSet = (undefined && undefined.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var ResponseStream_classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _ResponseStream_instances, _ResponseStream_params, _ResponseStream_currentResponseSnapshot, _ResponseStream_finalResponse, _ResponseStream_beginRequest, _ResponseStream_addEvent, _ResponseStream_endRequest, _ResponseStream_accumulateResponse;



class ResponseStream extends EventStream {
    constructor(params) {
        super();
        _ResponseStream_instances.add(this);
        _ResponseStream_params.set(this, void 0);
        _ResponseStream_currentResponseSnapshot.set(this, void 0);
        _ResponseStream_finalResponse.set(this, void 0);
        ResponseStream_classPrivateFieldSet(this, _ResponseStream_params, params, "f");
    }
    static createResponse(client, params, options) {
        const runner = new ResponseStream(params);
        runner._run(() => runner._createResponse(client, params, {
            ...options,
            headers: { ...options?.headers, 'X-Stainless-Helper-Method': 'stream' },
        }));
        return runner;
    }
    async _createResponse(client, params, options) {
        const signal = options?.signal;
        if (signal) {
            if (signal.aborted)
                this.controller.abort();
            signal.addEventListener('abort', () => this.controller.abort());
        }
        ResponseStream_classPrivateFieldGet(this, _ResponseStream_instances, "m", _ResponseStream_beginRequest).call(this);
        const stream = await client.responses.create({ ...params, stream: true }, { ...options, signal: this.controller.signal });
        this._connected();
        for await (const event of stream) {
            ResponseStream_classPrivateFieldGet(this, _ResponseStream_instances, "m", _ResponseStream_addEvent).call(this, event);
        }
        if (stream.controller.signal?.aborted) {
            throw new APIUserAbortError();
        }
        return ResponseStream_classPrivateFieldGet(this, _ResponseStream_instances, "m", _ResponseStream_endRequest).call(this);
    }
    [(_ResponseStream_params = new WeakMap(), _ResponseStream_currentResponseSnapshot = new WeakMap(), _ResponseStream_finalResponse = new WeakMap(), _ResponseStream_instances = new WeakSet(), _ResponseStream_beginRequest = function _ResponseStream_beginRequest() {
        if (this.ended)
            return;
        ResponseStream_classPrivateFieldSet(this, _ResponseStream_currentResponseSnapshot, undefined, "f");
    }, _ResponseStream_addEvent = function _ResponseStream_addEvent(event) {
        if (this.ended)
            return;
        const response = ResponseStream_classPrivateFieldGet(this, _ResponseStream_instances, "m", _ResponseStream_accumulateResponse).call(this, event);
        this._emit('event', event);
        switch (event.type) {
            case 'response.output_text.delta': {
                const output = response.output[event.output_index];
                if (!output) {
                    throw new error_OpenAIError(`missing output at index ${event.output_index}`);
                }
                if (output.type === 'message') {
                    const content = output.content[event.content_index];
                    if (!content) {
                        throw new error_OpenAIError(`missing content at index ${event.content_index}`);
                    }
                    if (content.type !== 'output_text') {
                        throw new error_OpenAIError(`expected content to be 'output_text', got ${content.type}`);
                    }
                    this._emit('response.output_text.delta', {
                        ...event,
                        snapshot: content.text,
                    });
                }
                break;
            }
            case 'response.function_call_arguments.delta': {
                const output = response.output[event.output_index];
                if (!output) {
                    throw new error_OpenAIError(`missing output at index ${event.output_index}`);
                }
                if (output.type === 'function_call') {
                    this._emit('response.function_call_arguments.delta', {
                        ...event,
                        snapshot: output.arguments,
                    });
                }
                break;
            }
            default:
                // @ts-ignore
                this._emit(event.type, event);
                break;
        }
    }, _ResponseStream_endRequest = function _ResponseStream_endRequest() {
        if (this.ended) {
            throw new error_OpenAIError(`stream has ended, this shouldn't happen`);
        }
        const snapshot = ResponseStream_classPrivateFieldGet(this, _ResponseStream_currentResponseSnapshot, "f");
        if (!snapshot) {
            throw new error_OpenAIError(`request ended without sending any events`);
        }
        ResponseStream_classPrivateFieldSet(this, _ResponseStream_currentResponseSnapshot, undefined, "f");
        const parsedResponse = finalizeResponse(snapshot, ResponseStream_classPrivateFieldGet(this, _ResponseStream_params, "f"));
        ResponseStream_classPrivateFieldSet(this, _ResponseStream_finalResponse, parsedResponse, "f");
        return parsedResponse;
    }, _ResponseStream_accumulateResponse = function _ResponseStream_accumulateResponse(event) {
        let snapshot = ResponseStream_classPrivateFieldGet(this, _ResponseStream_currentResponseSnapshot, "f");
        if (!snapshot) {
            if (event.type !== 'response.created') {
                throw new error_OpenAIError(`When snapshot hasn't been set yet, expected 'response.created' event, got ${event.type}`);
            }
            snapshot = ResponseStream_classPrivateFieldSet(this, _ResponseStream_currentResponseSnapshot, event.response, "f");
            return snapshot;
        }
        switch (event.type) {
            case 'response.output_item.added': {
                snapshot.output.push(event.item);
                break;
            }
            case 'response.content_part.added': {
                const output = snapshot.output[event.output_index];
                if (!output) {
                    throw new error_OpenAIError(`missing output at index ${event.output_index}`);
                }
                if (output.type === 'message') {
                    output.content.push(event.part);
                }
                break;
            }
            case 'response.output_text.delta': {
                const output = snapshot.output[event.output_index];
                if (!output) {
                    throw new error_OpenAIError(`missing output at index ${event.output_index}`);
                }
                if (output.type === 'message') {
                    const content = output.content[event.content_index];
                    if (!content) {
                        throw new error_OpenAIError(`missing content at index ${event.content_index}`);
                    }
                    if (content.type !== 'output_text') {
                        throw new error_OpenAIError(`expected content to be 'output_text', got ${content.type}`);
                    }
                    content.text += event.delta;
                }
                break;
            }
            case 'response.function_call_arguments.delta': {
                const output = snapshot.output[event.output_index];
                if (!output) {
                    throw new error_OpenAIError(`missing output at index ${event.output_index}`);
                }
                if (output.type === 'function_call') {
                    output.arguments += event.delta;
                }
                break;
            }
            case 'response.completed': {
                ResponseStream_classPrivateFieldSet(this, _ResponseStream_currentResponseSnapshot, event.response, "f");
                break;
            }
        }
        return snapshot;
    }, Symbol.asyncIterator)]() {
        const pushQueue = [];
        const readQueue = [];
        let done = false;
        this.on('event', (event) => {
            const reader = readQueue.shift();
            if (reader) {
                reader.resolve(event);
            }
            else {
                pushQueue.push(event);
            }
        });
        this.on('end', () => {
            done = true;
            for (const reader of readQueue) {
                reader.resolve(undefined);
            }
            readQueue.length = 0;
        });
        this.on('abort', (err) => {
            done = true;
            for (const reader of readQueue) {
                reader.reject(err);
            }
            readQueue.length = 0;
        });
        this.on('error', (err) => {
            done = true;
            for (const reader of readQueue) {
                reader.reject(err);
            }
            readQueue.length = 0;
        });
        return {
            next: async () => {
                if (!pushQueue.length) {
                    if (done) {
                        return { value: undefined, done: true };
                    }
                    return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((event) => (event ? { value: event, done: false } : { value: undefined, done: true }));
                }
                const event = pushQueue.shift();
                return { value: event, done: false };
            },
            return: async () => {
                this.abort();
                return { value: undefined, done: true };
            },
        };
    }
    /**
     * @returns a promise that resolves with the final Response, or rejects
     * if an error occurred or the stream ended prematurely without producing a REsponse.
     */
    async finalResponse() {
        await this.done();
        const response = ResponseStream_classPrivateFieldGet(this, _ResponseStream_finalResponse, "f");
        if (!response)
            throw new error_OpenAIError('stream ended without producing a ChatCompletion');
        return response;
    }
}
function finalizeResponse(snapshot, params) {
    return maybeParseResponse(snapshot, params);
}
//# sourceMappingURL=ResponseStream.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/resources/responses/responses.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.







class Responses extends APIResource {
    constructor() {
        super(...arguments);
        this.inputItems = new InputItems(this._client);
    }
    create(body, options) {
        return this._client.post('/responses', { body, ...options, stream: body.stream ?? false })._thenUnwrap((rsp) => {
            if ('object' in rsp && rsp.object === 'response') {
                addOutputText(rsp);
            }
            return rsp;
        });
    }
    retrieve(responseId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.retrieve(responseId, {}, query);
        }
        return this._client.get(`/responses/${responseId}`, { query, ...options });
    }
    /**
     * Deletes a model response with the given ID.
     */
    del(responseId, options) {
        return this._client.delete(`/responses/${responseId}`, {
            ...options,
            headers: { Accept: '*/*', ...options?.headers },
        });
    }
    parse(body, options) {
        return this._client.responses
            .create(body, options)
            ._thenUnwrap((response) => parseResponse(response, body));
    }
    /**
     * Creates a chat completion stream
     */
    stream(body, options) {
        return ResponseStream.createResponse(this._client, body, options);
    }
}
class ResponseItemsPage extends CursorPage {
}
Responses.InputItems = InputItems;
//# sourceMappingURL=responses.mjs.map
;// CONCATENATED MODULE: ./node_modules/openai/index.mjs
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
var _a;





















/**
 * API Client for interfacing with the OpenAI API.
 */
class OpenAI extends APIClient {
    /**
     * API Client for interfacing with the OpenAI API.
     *
     * @param {string | undefined} [opts.apiKey=process.env['OPENAI_API_KEY'] ?? undefined]
     * @param {string | null | undefined} [opts.organization=process.env['OPENAI_ORG_ID'] ?? null]
     * @param {string | null | undefined} [opts.project=process.env['OPENAI_PROJECT_ID'] ?? null]
     * @param {string} [opts.baseURL=process.env['OPENAI_BASE_URL'] ?? https://api.openai.com/v1] - Override the default base URL for the API.
     * @param {number} [opts.timeout=10 minutes] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {number} [opts.httpAgent] - An HTTP agent used to manage HTTP(s) connections.
     * @param {Core.Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {Core.Headers} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Core.DefaultQuery} opts.defaultQuery - Default query parameters to include with every request to the API.
     * @param {boolean} [opts.dangerouslyAllowBrowser=false] - By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
     */
    constructor({ baseURL = readEnv('OPENAI_BASE_URL'), apiKey = readEnv('OPENAI_API_KEY'), organization = readEnv('OPENAI_ORG_ID') ?? null, project = readEnv('OPENAI_PROJECT_ID') ?? null, ...opts } = {}) {
        if (apiKey === undefined) {
            throw new error_OpenAIError("The OPENAI_API_KEY environment variable is missing or empty; either provide it, or instantiate the OpenAI client with an apiKey option, like new OpenAI({ apiKey: 'My API Key' }).");
        }
        const options = {
            apiKey,
            organization,
            project,
            ...opts,
            baseURL: baseURL || `https://api.openai.com/v1`,
        };
        if (!options.dangerouslyAllowBrowser && isRunningInBrowser()) {
            throw new error_OpenAIError("It looks like you're running in a browser-like environment.\n\nThis is disabled by default, as it risks exposing your secret API credentials to attackers.\nIf you understand the risks and have appropriate mitigations in place,\nyou can set the `dangerouslyAllowBrowser` option to `true`, e.g.,\n\nnew OpenAI({ apiKey, dangerouslyAllowBrowser: true });\n\nhttps://help.openai.com/en/articles/5112595-best-practices-for-api-key-safety\n");
        }
        super({
            baseURL: options.baseURL,
            timeout: options.timeout ?? 600000 /* 10 minutes */,
            httpAgent: options.httpAgent,
            maxRetries: options.maxRetries,
            fetch: options.fetch,
        });
        this.completions = new Completions(this);
        this.chat = new Chat(this);
        this.embeddings = new Embeddings(this);
        this.files = new Files(this);
        this.images = new Images(this);
        this.audio = new Audio(this);
        this.moderations = new Moderations(this);
        this.models = new Models(this);
        this.fineTuning = new FineTuning(this);
        this.vectorStores = new VectorStores(this);
        this.beta = new Beta(this);
        this.batches = new Batches(this);
        this.uploads = new Uploads(this);
        this.responses = new Responses(this);
        this._options = options;
        this.apiKey = apiKey;
        this.organization = organization;
        this.project = project;
    }
    defaultQuery() {
        return this._options.defaultQuery;
    }
    defaultHeaders(opts) {
        return {
            ...super.defaultHeaders(opts),
            'OpenAI-Organization': this.organization,
            'OpenAI-Project': this.project,
            ...this._options.defaultHeaders,
        };
    }
    authHeaders(opts) {
        return { Authorization: `Bearer ${this.apiKey}` };
    }
    stringifyQuery(query) {
        return stringify(query, { arrayFormat: 'brackets' });
    }
}
_a = OpenAI;
OpenAI.OpenAI = _a;
OpenAI.DEFAULT_TIMEOUT = 600000; // 10 minutes
OpenAI.OpenAIError = error_OpenAIError;
OpenAI.APIError = APIError;
OpenAI.APIConnectionError = APIConnectionError;
OpenAI.APIConnectionTimeoutError = APIConnectionTimeoutError;
OpenAI.APIUserAbortError = APIUserAbortError;
OpenAI.NotFoundError = NotFoundError;
OpenAI.ConflictError = ConflictError;
OpenAI.RateLimitError = RateLimitError;
OpenAI.BadRequestError = BadRequestError;
OpenAI.AuthenticationError = AuthenticationError;
OpenAI.InternalServerError = InternalServerError;
OpenAI.PermissionDeniedError = PermissionDeniedError;
OpenAI.UnprocessableEntityError = UnprocessableEntityError;
OpenAI.toFile = toFile;
OpenAI.fileFromPath = fileFromPath;
OpenAI.Completions = Completions;
OpenAI.Chat = Chat;
OpenAI.ChatCompletionsPage = ChatCompletionsPage;
OpenAI.Embeddings = Embeddings;
OpenAI.Files = Files;
OpenAI.FileObjectsPage = FileObjectsPage;
OpenAI.Images = Images;
OpenAI.Audio = Audio;
OpenAI.Moderations = Moderations;
OpenAI.Models = Models;
OpenAI.ModelsPage = ModelsPage;
OpenAI.FineTuning = FineTuning;
OpenAI.VectorStores = VectorStores;
OpenAI.VectorStoresPage = VectorStoresPage;
OpenAI.VectorStoreSearchResponsesPage = VectorStoreSearchResponsesPage;
OpenAI.Beta = Beta;
OpenAI.Batches = Batches;
OpenAI.BatchesPage = BatchesPage;
OpenAI.Uploads = Uploads;
OpenAI.Responses = Responses;
/** API Client for interfacing with the Azure OpenAI API. */
class AzureOpenAI extends OpenAI {
    /**
     * API Client for interfacing with the Azure OpenAI API.
     *
     * @param {string | undefined} [opts.apiVersion=process.env['OPENAI_API_VERSION'] ?? undefined]
     * @param {string | undefined} [opts.endpoint=process.env['AZURE_OPENAI_ENDPOINT'] ?? undefined] - Your Azure endpoint, including the resource, e.g. `https://example-resource.azure.openai.com/`
     * @param {string | undefined} [opts.apiKey=process.env['AZURE_OPENAI_API_KEY'] ?? undefined]
     * @param {string | undefined} opts.deployment - A model deployment, if given, sets the base client URL to include `/deployments/{deployment}`.
     * @param {string | null | undefined} [opts.organization=process.env['OPENAI_ORG_ID'] ?? null]
     * @param {string} [opts.baseURL=process.env['OPENAI_BASE_URL']] - Sets the base URL for the API, e.g. `https://example-resource.azure.openai.com/openai/`.
     * @param {number} [opts.timeout=10 minutes] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {number} [opts.httpAgent] - An HTTP agent used to manage HTTP(s) connections.
     * @param {Core.Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {Core.Headers} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Core.DefaultQuery} opts.defaultQuery - Default query parameters to include with every request to the API.
     * @param {boolean} [opts.dangerouslyAllowBrowser=false] - By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
     */
    constructor({ baseURL = readEnv('OPENAI_BASE_URL'), apiKey = readEnv('AZURE_OPENAI_API_KEY'), apiVersion = readEnv('OPENAI_API_VERSION'), endpoint, deployment, azureADTokenProvider, dangerouslyAllowBrowser, ...opts } = {}) {
        if (!apiVersion) {
            throw new error_OpenAIError("The OPENAI_API_VERSION environment variable is missing or empty; either provide it, or instantiate the AzureOpenAI client with an apiVersion option, like new AzureOpenAI({ apiVersion: 'My API Version' }).");
        }
        if (typeof azureADTokenProvider === 'function') {
            dangerouslyAllowBrowser = true;
        }
        if (!azureADTokenProvider && !apiKey) {
            throw new error_OpenAIError('Missing credentials. Please pass one of `apiKey` and `azureADTokenProvider`, or set the `AZURE_OPENAI_API_KEY` environment variable.');
        }
        if (azureADTokenProvider && apiKey) {
            throw new error_OpenAIError('The `apiKey` and `azureADTokenProvider` arguments are mutually exclusive; only one can be passed at a time.');
        }
        // define a sentinel value to avoid any typing issues
        apiKey ?? (apiKey = API_KEY_SENTINEL);
        opts.defaultQuery = { ...opts.defaultQuery, 'api-version': apiVersion };
        if (!baseURL) {
            if (!endpoint) {
                endpoint = {"SCHEDULED_INTERVAL":"180","ANALYSIS_TYPE":"filter","ANALYZE_BY_GROUP":"false","LLM_TYPE":"dify","OLLAMA_BASE_URL":"http://localhost:11434","OLLAMA_MODEL":"deepseek-r1","OLLAMA_REVIEW_MODEL":"llama3.1","OLLAMA_QUERY_MODEL":"llama3.1","DIFY_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_REVIEW_API_KEY":"app-EQhkmjfMxIiyWWbMj9vz5vM9","DIFY_API_BASE_URL":"https://lap2-api-dev.int.rclabenv.com/v1","OPENAI_API_KEY":"","OPENAI_MODEL":"deepseek-ai/deepseek-r1","OPENAI_REVIEW_MODEL":"deepseek-ai/deepseek-r1","OPENAI_API_BASE_URL":"https://integrate.api.nvidia.com/v1","GROQ_API_KEY":"","GROQ_MODEL":"llama-3.3-70b-versatile","GROQ_REVIEW_MODEL":"llama-3.1","BOT_API_BASE_URL":"https://botman.int.rclabenv.com/v2","BOT_TOKEN":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImVzb25lLnFpdUByaW5nY2VudHJhbC5jb20iLCJzZXJ2aWNlIjoiU01fYm90LnNlcnZpY2UiLCJyb2xlIjoiUk9MRV9VU0VSIiwiaWF0IjoxNzM5OTQyMjUyLCJleHAiOjIwNTUzMDIyNTJ9.ieSb3zGIwVhUTqZpkgJipK8ktH4FVJr3vDF0kyQ-4DI","BOT_ID":"4700372020@37439510.bot.glip.net","BOT_TYPE":"user","TEAM_ID":"1497300893698","ENABLE_BOT":"true","LLM_REVIEW_BEFORE_SEND":"true","ENABLE_CHROMA":"true","CHROMA_API_URL":"http://10.32.56.212:8000","CHROMA_PORT":"8000","CHROMA_COLLECTION_NAME":"","JIRA_BASE_URL":"https://jira.ringcentral.com","JIRA_USERNAME":"esone.qiu@ringcentral.com","JIRA_API_TOKEN":"","GOOGLE_CLIENT_ID":"850492875483-kmbu6or52oi6lsnapoqklbs5fo94jplv.apps.googleusercontent.com"}['AZURE_OPENAI_ENDPOINT'];
            }
            if (!endpoint) {
                throw new error_OpenAIError('Must provide one of the `baseURL` or `endpoint` arguments, or the `AZURE_OPENAI_ENDPOINT` environment variable');
            }
            baseURL = `${endpoint}/openai`;
        }
        else {
            if (endpoint) {
                throw new error_OpenAIError('baseURL and endpoint are mutually exclusive');
            }
        }
        super({
            apiKey,
            baseURL,
            ...opts,
            ...(dangerouslyAllowBrowser !== undefined ? { dangerouslyAllowBrowser } : {}),
        });
        this.apiVersion = '';
        this._azureADTokenProvider = azureADTokenProvider;
        this.apiVersion = apiVersion;
        this.deploymentName = deployment;
    }
    buildRequest(options, props = {}) {
        if (_deployments_endpoints.has(options.path) && options.method === 'post' && options.body !== undefined) {
            if (!isObj(options.body)) {
                throw new Error('Expected request body to be an object');
            }
            const model = this.deploymentName || options.body['model'] || options.__metadata?.['model'];
            if (model !== undefined && !this.baseURL.includes('/deployments')) {
                options.path = `/deployments/${model}${options.path}`;
            }
        }
        return super.buildRequest(options, props);
    }
    async _getAzureADToken() {
        if (typeof this._azureADTokenProvider === 'function') {
            const token = await this._azureADTokenProvider();
            if (!token || typeof token !== 'string') {
                throw new error_OpenAIError(`Expected 'azureADTokenProvider' argument to return a string but it returned ${token}`);
            }
            return token;
        }
        return undefined;
    }
    authHeaders(opts) {
        return {};
    }
    async prepareOptions(opts) {
        /**
         * The user should provide a bearer token provider if they want
         * to use Azure AD authentication. The user shouldn't set the
         * Authorization header manually because the header is overwritten
         * with the Azure AD token if a bearer token provider is provided.
         */
        if (opts.headers?.['api-key']) {
            return super.prepareOptions(opts);
        }
        const token = await this._getAzureADToken();
        opts.headers ?? (opts.headers = {});
        if (token) {
            opts.headers['Authorization'] = `Bearer ${token}`;
        }
        else if (this.apiKey !== API_KEY_SENTINEL) {
            opts.headers['api-key'] = this.apiKey;
        }
        else {
            throw new error_OpenAIError('Unable to handle auth');
        }
        return super.prepareOptions(opts);
    }
}
const _deployments_endpoints = new Set([
    '/completions',
    '/chat/completions',
    '/embeddings',
    '/audio/transcriptions',
    '/audio/translations',
    '/audio/speech',
    '/images/generations',
]);
const API_KEY_SENTINEL = '<Missing Key>';


/* harmony default export */ const openai = (OpenAI);
//# sourceMappingURL=index.mjs.map

/***/ }),

/***/ 797:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VERSION: () => (/* binding */ VERSION)
/* harmony export */ });
const VERSION = '4.91.0'; // x-release-please-version
//# sourceMappingURL=version.mjs.map

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/create fake namespace object */
/******/ 	(() => {
/******/ 		var getProto = Object.getPrototypeOf ? (obj) => (Object.getPrototypeOf(obj)) : (obj) => (obj.__proto__);
/******/ 		var leafPrototypes;
/******/ 		// create a fake namespace object
/******/ 		// mode & 1: value is a module id, require it
/******/ 		// mode & 2: merge all properties of value into the ns
/******/ 		// mode & 4: return value when already ns object
/******/ 		// mode & 16: return value when it's Promise-like
/******/ 		// mode & 8|1: behave like require
/******/ 		__webpack_require__.t = function(value, mode) {
/******/ 			if(mode & 1) value = this(value);
/******/ 			if(mode & 8) return value;
/******/ 			if(typeof value === 'object' && value) {
/******/ 				if((mode & 4) && value.__esModule) return value;
/******/ 				if((mode & 16) && typeof value.then === 'function') return value;
/******/ 			}
/******/ 			var ns = Object.create(null);
/******/ 			__webpack_require__.r(ns);
/******/ 			var def = {};
/******/ 			leafPrototypes = leafPrototypes || [null, getProto({}), getProto([]), getProto(getProto)];
/******/ 			for(var current = mode & 2 && value; typeof current == 'object' && !~leafPrototypes.indexOf(current); current = getProto(current)) {
/******/ 				Object.getOwnPropertyNames(current).forEach((key) => (def[key] = () => (value[key])));
/******/ 			}
/******/ 			def['default'] = () => (value);
/******/ 			__webpack_require__.d(ns, def);
/******/ 			return ns;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = (chunkId) => {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.u = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + ".js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/load script */
/******/ 	(() => {
/******/ 		var inProgress = {};
/******/ 		var dataWebpackPrefix = "personal-ai:";
/******/ 		// loadScript function to load a script via script tag
/******/ 		__webpack_require__.l = (url, done, key, chunkId) => {
/******/ 			if(inProgress[url]) { inProgress[url].push(done); return; }
/******/ 			var script, needAttach;
/******/ 			if(key !== undefined) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				for(var i = 0; i < scripts.length; i++) {
/******/ 					var s = scripts[i];
/******/ 					if(s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) { script = s; break; }
/******/ 				}
/******/ 			}
/******/ 			if(!script) {
/******/ 				needAttach = true;
/******/ 				script = document.createElement('script');
/******/ 		
/******/ 				script.charset = 'utf-8';
/******/ 				script.timeout = 120;
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.setAttribute("data-webpack", dataWebpackPrefix + key);
/******/ 		
/******/ 				script.src = url;
/******/ 			}
/******/ 			inProgress[url] = [done];
/******/ 			var onScriptComplete = (prev, event) => {
/******/ 				// avoid mem leaks in IE.
/******/ 				script.onerror = script.onload = null;
/******/ 				clearTimeout(timeout);
/******/ 				var doneFns = inProgress[url];
/******/ 				delete inProgress[url];
/******/ 				script.parentNode && script.parentNode.removeChild(script);
/******/ 				doneFns && doneFns.forEach((fn) => (fn(event)));
/******/ 				if(prev) return prev(event);
/******/ 			}
/******/ 			var timeout = setTimeout(onScriptComplete.bind(null, undefined, { type: 'timeout', target: script }), 120000);
/******/ 			script.onerror = onScriptComplete.bind(null, script.onerror);
/******/ 			script.onload = onScriptComplete.bind(null, script.onload);
/******/ 			needAttach && document.head.appendChild(script);
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		__webpack_require__.p = "/";
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			437: 0,
/******/ 			817: 0,
/******/ 			642: 0,
/******/ 			93: 0,
/******/ 			254: 0,
/******/ 			291: 0,
/******/ 			604: 0,
/******/ 			65: 0,
/******/ 			797: 0
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.f.j = (chunkId, promises) => {
/******/ 				// JSONP chunk loading for javascript
/******/ 				var installedChunkData = __webpack_require__.o(installedChunks, chunkId) ? installedChunks[chunkId] : undefined;
/******/ 				if(installedChunkData !== 0) { // 0 means "already installed".
/******/ 		
/******/ 					// a Promise means "currently loading".
/******/ 					if(installedChunkData) {
/******/ 						promises.push(installedChunkData[2]);
/******/ 					} else {
/******/ 						if(true) { // all chunks have JS
/******/ 							// setup Promise in chunk cache
/******/ 							var promise = new Promise((resolve, reject) => (installedChunkData = installedChunks[chunkId] = [resolve, reject]));
/******/ 							promises.push(installedChunkData[2] = promise);
/******/ 		
/******/ 							// start chunk loading
/******/ 							var url = __webpack_require__.p + __webpack_require__.u(chunkId);
/******/ 							// create error before stack unwound to get useful stacktrace later
/******/ 							var error = new Error();
/******/ 							var loadingEnded = (event) => {
/******/ 								if(__webpack_require__.o(installedChunks, chunkId)) {
/******/ 									installedChunkData = installedChunks[chunkId];
/******/ 									if(installedChunkData !== 0) installedChunks[chunkId] = undefined;
/******/ 									if(installedChunkData) {
/******/ 										var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 										var realSrc = event && event.target && event.target.src;
/******/ 										error.message = 'Loading chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 										error.name = 'ChunkLoadError';
/******/ 										error.type = errorType;
/******/ 										error.request = realSrc;
/******/ 										installedChunkData[1](error);
/******/ 									}
/******/ 								}
/******/ 							};
/******/ 							__webpack_require__.l(url, loadingEnded, "chunk-" + chunkId, chunkId);
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 		};
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var chunkIds = data[0];
/******/ 			var moreModules = data[1];
/******/ 			var runtime = data[2];
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 		
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkpersonal_ai"] = self["webpackChunkpersonal_ai"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";

// EXTERNAL MODULE: ./src/utils.ts
var utils = __webpack_require__(43922);
;// CONCATENATED MODULE: ./src/jira.ts


// 从 Jira 页面抓取数据
async function fetchJiraTickets(jql) {
  return new Promise((resolve, reject) => {
    const requestId = Math.random().toString(36).substring(7);

    // 监听来自 background script 的消息
    const messageListener = message => {
      if (message.type === 'JIRA_TICKETS_RESULT' && message.requestId === requestId) {
        chrome.runtime.onMessage.removeListener(messageListener);
        if (message.error) {
          reject(new Error(message.error));
        } else {
          resolve(message.tickets);
        }
      }
      return true;
    };
    chrome.runtime.onMessage.addListener(messageListener);

    // 发送消息给 background script 来创建新标签页
    chrome.runtime.sendMessage({
      type: 'FETCH_JIRA_TICKETS',
      jql,
      requestId
    });
  });
}

// 然后在 FETCH_JIRA_TICKETS 函数中使用 sourceTabId
async function FETCH_JIRA_TICKETS(jql, requestId, sourceTabId) {
  const envConfig = await getEnvConfig();
  const url = `${envConfig.JIRA_BASE_URL}/issues/?jql=${encodeURIComponent(jql)}`;

  // 创建新标签页
  chrome.tabs.create({
    url,
    active: false
  }, tab => {
    if (!tab.id) {
      chrome.tabs.sendMessage(sourceTabId, {
        type: 'JIRA_TICKETS_RESULT',
        requestId,
        error: '无法创建标签页'
      });
      return;
    }

    // 等待页面加载完成
    const checkPageLoad = () => {
      chrome.tabs.get(tab.id, updatedTab => {
        if (updatedTab.status === 'complete') {
          if (updatedTab.url.includes('login') || updatedTab.url.includes('okta')) {
            chrome.tabs.sendMessage(sourceTabId, {
              type: 'JIRA_TICKETS_RESULT',
              requestId,
              error: 'jira 需要登录，请登录后重新尝试'
            });
            setTimeout(() => chrome.tabs.update(tab.id, {
              active: true
            }), 3000);
            return;
          }
          // 注入内容脚本
          chrome.scripting.executeScript({
            target: {
              tabId: tab.id
            },
            func: () => {
              const tickets = [];

              // 判断是否是Jira Cloud版本，通过检查特定的DOM元素判断
              const isJiraCloud = !!document.querySelector('table[data-vc="issue-table"]') || !!document.querySelector('table[aria-label="Work"]');
              if (isJiraCloud) {
                // Jira Cloud 版本的选择器
                const rows = document.querySelectorAll('tr[data-testid="native-issue-table.ui.issue-row"]');
                if (rows && rows.length > 0) {
                  rows.forEach(row => {
                    // 获取key - a[data-testid="native-issue-table.common.ui.issue-cells.issue-key.issue-key-cell"]
                    const keyElement = row.querySelector('a[data-testid="native-issue-table.common.ui.issue-cells.issue-key.issue-key-cell"]');

                    // 获取summary - a[data-testid="native-issue-table.common.ui.issue-cells.issue-summary.issue-summary-cell"]
                    const summaryElement = row.querySelector('a[data-testid="native-issue-table.common.ui.issue-cells.issue-summary.issue-summary-cell"]');

                    // 获取status - 状态位于有特定class的span中
                    const statusContainer = row.querySelector('div[data-testid^="issue.fields.status.common.ui.status-lozenge"]');
                    const statusElement = statusContainer ? statusContainer.querySelector('div._4cvr1h6o') : null;

                    // 经办人、报告人和优先级通常位于相应的单元格中
                    const cells = row.querySelectorAll('td');
                    let assignee = '',
                      reporter = '',
                      priority = '',
                      created = '',
                      updated = '',
                      duedate = '';

                    // 通过位置判断各个字段
                    if (cells.length >= 11) {
                      // 假设第5个单元格是assignee
                      const assigneeText = cells[4].textContent?.trim();
                      assignee = assigneeText.match(/^(.+?)\1+$/)[1] || assigneeText;
                      assignee = assignee !== 'Unassigned' ? assignee || '' : '';

                      // 假设第6个单元格是reporter
                      reporter = cells[5].textContent?.trim() || '';
                      reporter = reporter.match(/^(.+?)\1+$/)[1] || reporter;

                      // 假设第7个单元格是priority
                      priority = cells[6].textContent?.trim() || '';

                      // 假设第9个单元格是created
                      created = cells[8].textContent?.trim() || '';

                      // 假设第10个单元格是updated
                      updated = cells[9].textContent?.trim() || '';

                      // 假设第11个单元格是duedate
                      const dueDateText = cells[10].textContent?.trim();
                      duedate = dueDateText !== 'None' ? dueDateText || '' : '';
                    }
                    const ticket = {
                      key: keyElement ? keyElement.textContent?.trim() || '' : '',
                      summary: summaryElement ? summaryElement.textContent?.trim() || '' : '',
                      status: statusElement ? statusElement.textContent?.trim() || '' : '',
                      assignee,
                      reporter,
                      priority,
                      created,
                      updated,
                      duedate,
                      description: '' // Cloud视图中通常不显示描述
                    };
                    tickets.push(ticket);
                  });
                }
              } else {
                // 原有的 Jira On-Premise 版本的选择器
                const rows = document.querySelectorAll('tr.issuerow');
                rows.forEach(row => {
                  const ticket = {};
                  const cells = row.querySelectorAll('td');
                  cells.forEach(cell => {
                    if (cell.classList && cell.classList.length > 0) {
                      let propertyName = cell.classList[0]; // Get the first class name
                      const img = cell.querySelector('img[alt]');
                      const value = cell.textContent?.trim() || (img ? img.getAttribute('alt') || '' : '');

                      // If the class name is 'issuekey', the property in our object should be 'key'
                      if (propertyName === 'issuekey') propertyName = 'key';
                      if (propertyName) {
                        // Ensure propertyName is not empty
                        ticket[propertyName] = value;
                      }
                    }
                  });

                  // Ensure essential non-optional fields from JiraTicket are present, even if empty
                  ticket.key = ticket.key || '';
                  ticket.summary = ticket.summary || '';
                  ticket.status = ticket.status || '';
                  tickets.push(ticket);
                });
              }
              return tickets;
            }
          }, results => {
            // 处理结果
            if (results && results[0] && results[0].result) {
              // 对summary字段进行额外处理，确保干净的文本
              results[0].result = results[0].result.map(ticket => ({
                ...ticket,
                summary: ticket.summary.split('\n').map(s => s.trim()).filter(Boolean).pop() || ticket.summary
              }));
              chrome.tabs.sendMessage(sourceTabId, {
                type: 'JIRA_TICKETS_RESULT',
                requestId,
                tickets: results[0].result
              });
            } else {
              // 如果没有结果
              chrome.tabs.sendMessage(sourceTabId, {
                type: 'JIRA_TICKETS_RESULT',
                requestId,
                tickets: []
              });
            }

            // 关闭 Jira 标签页
            chrome.tabs.remove(tab.id);
          });
        } else {
          setTimeout(checkPageLoad, 100);
        }
      });
    };
    checkPageLoad();
  });
}
// EXTERNAL MODULE: ./src/agentThinking.ts
var agentThinking = __webpack_require__(70378);
// EXTERNAL MODULE: ./src/analyzers/analyzerFactory.ts
var analyzers_analyzerFactory = __webpack_require__(42331);
// EXTERNAL MODULE: ./src/analyzers/llmAnalyzer.ts
var analyzers_llmAnalyzer = __webpack_require__(97254);
;// CONCATENATED MODULE: ./src/slide.ts
/**
 * Google Slides API操作工具
 * 用于读取和更新Google Slides内容
 */

// Google Slides API参考: https://developers.google.com/slides/api/reference/rest

// 静态导入分析器相关模块，避免动态加载问题



/**
 * 项目数据接口定义
 */

/**
 * 项目更新建议接口
 */

/**
 * 从URL获取演示文稿ID
 * @param url Google Slides URL
 * @returns 演示文稿ID
 */
function getPresentationIdFromUrl(url) {
  const match = url.match(/\/presentation\/d\/([a-zA-Z0-9-_]+)/);
  if (match && match[1]) {
    return match[1];
  }
  throw new Error('无法从URL获取演示文稿ID');
}

/**
 * 从URL获取当前幻灯片ID
 * @param url Google Slides URL
 * @returns 当前幻灯片ID或undefined
 */
function getCurrentSlideIdFromUrl(url) {
  // 例如：https://docs.google.com/presentation/d/1AbCdEfG123456/edit#slide=id.g123456abcde_0_123
  const match = url.match(/slide=id\.([a-zA-Z0-9_]+)/);
  if (match && match[1]) {
    return match[1];
  }
  return undefined;
}

/**
 * 从Google Slides获取表格数据
 * @param presentationId Google Slides演示文稿ID
 * @param token OAuth token
 * @param slideId 可选的特定幻灯片ID，不提供则获取当前幻灯片或所有幻灯片
 * @param currentUrl 当前URL，用于提取当前幻灯片ID
 * @param options 可选的配置选项
 * @returns 包含项目数据的数组
 */
async function getProjectsFromSlide(presentationId, token, slideId, currentUrl, options) {
  try {
    // 使用静态导入的工厂
    const analyzerFactory = new analyzers_analyzerFactory/* SlideAnalyzerFactoryImpl */.S({
      useLLMFallback: options?.useLLMFallback || false
    });

    // 首先获取演示文稿内容
    const presentationData = await fetchPresentationData(presentationId, token);

    // 如果没有提供slideId，尝试从URL获取当前幻灯片ID
    let currentSlideId;
    if (!slideId && currentUrl) {
      currentSlideId = getCurrentSlideIdFromUrl(currentUrl);
    }

    // 决定处理哪些幻灯片
    let slidesToProcess = presentationData.slides;

    // 优先使用传入的slideId
    if (slideId) {
      slidesToProcess = presentationData.slides.filter(slide => slide.objectId === slideId);
    }
    // 其次使用从URL解析的当前幻灯片ID
    else if (currentSlideId) {
      slidesToProcess = presentationData.slides.filter(slide => slide.objectId === currentSlideId);
    }
    if (!slidesToProcess || slidesToProcess.length === 0) {
      console.warn('未找到幻灯片内容');
      return [];
    }
    console.log('需要处理的目标slide数量: ', slidesToProcess.length);

    // 保存分析结果
    const allProjects = [];
    const warnings = [];

    // 设置最小置信度阈值
    const minConfidence = options?.minConfidence || 0.3;

    // 分析每个幻灯片
    for (const slide of slidesToProcess) {
      try {
        console.log(`开始分析幻灯片: ${slide.objectId}`);

        // 使用工厂创建合适的分析器
        const analyzer = analyzerFactory.createAnalyzer(slide);

        // 分析幻灯片
        const analysisResult = await analyzer.analyze(slide);
        console.log(`分析完成: 找到${analysisResult.projects.length}个项目，置信度${analysisResult.confidence.toFixed(2)}`);

        // 检查置信度是否达到阈值
        if (analysisResult.confidence < minConfidence) {
          warnings.push(`[幻灯片 ${slide.objectId}] 分析置信度(${analysisResult.confidence.toFixed(2)})低于阈值，结果可能不准确`);

          // 如果启用了LLM后备且当前不是LLM分析器，尝试使用LLM
          if (options?.useLLMFallback && !(analyzer instanceof analyzers_llmAnalyzer/* LLMContentAnalyzer */.j)) {
            try {
              console.log(`尝试使用LLM分析幻灯片: ${slide.objectId}`);
              const llmAnalyzer = new analyzers_llmAnalyzer/* LLMContentAnalyzer */.j();
              const llmResult = await llmAnalyzer.analyze(slide);

              // 如果LLM分析结果更好，使用LLM结果
              if (llmResult.confidence > analysisResult.confidence) {
                console.log(`LLM分析结果更好: 置信度${llmResult.confidence.toFixed(2)} > ${analysisResult.confidence.toFixed(2)}`);
                Object.assign(analysisResult, llmResult);
              }
            } catch (llmError) {
              console.error(`LLM分析失败: ${llmError instanceof Error ? llmError.message : String(llmError)}`);
            }
          }
        }

        // 添加幻灯片ID到项目数据
        const slideProjects = analysisResult.projects.map(project => ({
          ...project,
          slideId: slide.objectId
        }));

        // 合并项目数据
        allProjects.push(...slideProjects);

        // 收集警告
        if (analysisResult.warnings && analysisResult.warnings.length > 0) {
          warnings.push(...analysisResult.warnings.map(w => `[幻灯片 ${slide.objectId}] ${w}`));
        }
      } catch (error) {
        console.error(`分析幻灯片 ${slide.objectId} 时出错:`, error);
        warnings.push(`[幻灯片 ${slide.objectId}] 分析失败: ${error instanceof Error ? error.message : String(error)}`);

        // 如果启用了LLM后备，尝试使用LLM作为最后的补救措施
        if (options?.useLLMFallback) {
          try {
            console.log(`尝试使用LLM分析失败的幻灯片: ${slide.objectId}`);
            const llmAnalyzer = new analyzers_llmAnalyzer/* LLMContentAnalyzer */.j();
            const llmResult = await llmAnalyzer.analyze(slide);

            // 添加幻灯片ID到项目数据
            const slideProjects = llmResult.projects.map(project => ({
              ...project,
              slideId: slide.objectId
            }));

            // 添加LLM分析结果
            allProjects.push(...slideProjects);
            console.log(`LLM分析成功: 找到${llmResult.projects.length}个项目，置信度${llmResult.confidence.toFixed(2)}`);

            // 添加LLM警告
            if (llmResult.warnings && llmResult.warnings.length > 0) {
              warnings.push(...llmResult.warnings.map(w => `[幻灯片 ${slide.objectId}] ${w}`));
            }
          } catch (llmError) {
            console.error(`LLM分析也失败: ${llmError instanceof Error ? llmError.message : String(llmError)}`);
          }
        }
      }
    }

    // 输出警告（如果有）
    if (warnings.length > 0) {
      console.warn('幻灯片分析警告:', warnings);
    }
    return allProjects;
  } catch (error) {
    console.error('获取幻灯片项目数据失败:', error);
    throw error;
  }
}

/**
 * 应用项目更新到Google Slides
 * @param presentationId Google Slides演示文稿ID
 * @param token OAuth token
 * @param updates 要应用的更新数组
 * @returns 更新结果
 */
async function applyProjectUpdates(presentationId, token, updates) {
  try {
    // 准备批量更新请求
    const requests = [];
    const errors = [];
    let updatedFieldCount = 0;
    for (const update of updates) {
      // 确保有必要的定位信息
      if (!update.slideId || !update.tableId || update.rowIndex === undefined) {
        errors.push(`缺少更新位置信息: ${update.projectId} - ${update.projectName}`);
        continue;
      }

      // 添加状态更新请求
      if (update.suggestedStatus && update.columnIndices?.status !== undefined) {
        try {
          // 删除文本请求
          requests.push({
            deleteText: {
              objectId: update.tableId,
              cellLocation: {
                rowIndex: update.rowIndex,
                columnIndex: update.columnIndices.status
              }
            }
          });

          // 插入文本请求
          requests.push({
            insertText: {
              objectId: update.tableId,
              cellLocation: {
                rowIndex: update.rowIndex,
                columnIndex: update.columnIndices.status
              },
              text: update.suggestedStatus
            }
          });
          updatedFieldCount++;
          console.log(`准备更新项目 "${update.projectName}" 的状态: ${update.currentStatus} -> ${update.suggestedStatus}`);
        } catch (error) {
          const errorMsg = `更新状态失败 (${update.projectId}): ${error instanceof Error ? error.message : String(error)}`;
          console.error(errorMsg);
          errors.push(errorMsg);
        }
      }

      // 添加负责人更新请求
      if (update.suggestedOwner && update.columnIndices?.owner !== undefined) {
        try {
          // 删除文本请求
          requests.push({
            deleteText: {
              objectId: update.tableId,
              cellLocation: {
                rowIndex: update.rowIndex,
                columnIndex: update.columnIndices.owner
              }
            }
          });

          // 插入文本请求
          requests.push({
            insertText: {
              objectId: update.tableId,
              cellLocation: {
                rowIndex: update.rowIndex,
                columnIndex: update.columnIndices.owner
              },
              text: update.suggestedOwner
            }
          });
          updatedFieldCount++;
          console.log(`准备更新项目 "${update.projectName}" 的负责人: ${update.currentOwner} -> ${update.suggestedOwner}`);
        } catch (error) {
          const errorMsg = `更新负责人失败 (${update.projectId}): ${error instanceof Error ? error.message : String(error)}`;
          console.error(errorMsg);
          errors.push(errorMsg);
        }
      }

      // 添加赛道更新请求
      if (update.suggestedTrack && update.columnIndices?.track !== undefined) {
        try {
          // 删除文本请求
          requests.push({
            deleteText: {
              objectId: update.tableId,
              cellLocation: {
                rowIndex: update.rowIndex,
                columnIndex: update.columnIndices.track
              }
            }
          });

          // 插入文本请求
          requests.push({
            insertText: {
              objectId: update.tableId,
              cellLocation: {
                rowIndex: update.rowIndex,
                columnIndex: update.columnIndices.track
              },
              text: update.suggestedTrack
            }
          });
          updatedFieldCount++;
          console.log(`准备更新项目 "${update.projectName}" 的赛道: ${update.currentTrack || '空'} -> ${update.suggestedTrack}`);
        } catch (error) {
          const errorMsg = `更新赛道失败 (${update.projectId}): ${error instanceof Error ? error.message : String(error)}`;
          console.error(errorMsg);
          errors.push(errorMsg);
        }
      }

      // 添加备注更新请求
      if (update.suggestedComments && update.columnIndices?.comments !== undefined) {
        try {
          // 检查是否是添加而不是完全替换
          const finalText = update.currentComments ? `${update.currentComments}\n${update.suggestedComments}` : update.suggestedComments;

          // 删除文本请求
          requests.push({
            deleteText: {
              objectId: update.tableId,
              cellLocation: {
                rowIndex: update.rowIndex,
                columnIndex: update.columnIndices.comments
              }
            }
          });

          // 插入文本请求
          requests.push({
            insertText: {
              objectId: update.tableId,
              cellLocation: {
                rowIndex: update.rowIndex,
                columnIndex: update.columnIndices.comments
              },
              text: finalText
            }
          });
          updatedFieldCount++;
          console.log(`准备更新项目 "${update.projectName}" 的备注${update.currentComments ? '(附加)' : ''}`);
        } catch (error) {
          const errorMsg = `更新备注失败 (${update.projectId}): ${error instanceof Error ? error.message : String(error)}`;
          console.error(errorMsg);
          errors.push(errorMsg);
        }
      }
    }

    // 如果没有任何请求，直接返回
    if (requests.length === 0) {
      console.log('没有要应用的更新');
      return {
        success: true,
        updatedCount: 0,
        errors: errors.length > 0 ? errors : undefined
      };
    }
    console.log(`即将发送${requests.length}个请求(${updatedFieldCount}个字段更新)`);

    // 准备符合API规范的请求正文
    const requestBody = {
      requests: requests
    };

    // 发送批量更新请求
    const response = await fetch(`https://slides.googleapis.com/v1/presentations/${presentationId}:batchUpdate`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    });
    if (!response.ok) {
      const errorData = await response.json();
      const errorMsg = `Google Slides API错误: ${JSON.stringify(errorData)}`;
      console.error(errorMsg);
      throw new Error(errorMsg);
    }
    const result = await response.json();
    console.log('Slides API更新成功，响应:', JSON.stringify(result));
    return {
      success: true,
      updatedCount: updatedFieldCount,
      errors: errors.length > 0 ? errors : undefined
    };
  } catch (error) {
    console.error('应用项目更新失败:', error);
    return {
      success: false,
      updatedCount: 0,
      errors: [error instanceof Error ? error.message : String(error)]
    };
  }
}

/**
 * 获取Google API认证token
 * @returns OAuth token
 */
async function getAuthToken() {
  return new Promise(resolve => {
    chrome.identity.getAuthToken({
      interactive: true
    }, token => {
      if (chrome.runtime.lastError) {
        console.error('获取token失败:', chrome.runtime.lastError);
        resolve(null);
      } else {
        resolve(token);
      }
    });
  });
}

/**
 * 获取演示文稿数据
 * @param presentationId 演示文稿ID
 * @param token OAuth token
 * @returns 演示文稿数据
 */
async function fetchPresentationData(presentationId, token) {
  const response = await fetch(`https://slides.googleapis.com/v1/presentations/${presentationId}`, {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });
  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(`Google Slides API错误: ${JSON.stringify(errorData)}`);
  }
  return await response.json();
}
;// CONCATENATED MODULE: ./src/contentScriptGoogleSlide.tsx
// 在文件顶部添加全局声明





// 分析结果接口

// 不再需要扩展MessageProcessResult接口
// 使用ProjectAnalysisResult代替
// interface ExtendedMessageProcessResult extends MessageProcessResult {
//   enrichedData?: {
//     suggestedStatus?: string;
//     suggestedOwner?: string;
//     suggestedTrack?: string;
//     suggestedComments?: string;
//     [key: string]: any;
//   };
// }

// 主监听器
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('收到消息:', message, '发送者:', sender);
  if (!message || !message.type) {
    console.warn('收到无效消息格式');
    sendResponse({
      success: false,
      error: '无效消息格式'
    });
    return true;
  }
  const {
    type,
    token
  } = message;
  if (type === 'ANALYZE_SLIDES_PROJECTS') {
    if (!token) {
      console.error('未提供认证token');
      sendResponse({
        success: false,
        error: '未提供认证token'
      });
      return true;
    }
    analyzeSlideProjects(token).then(() => {
      sendResponse({
        success: true
      });
    });
  } else {
    console.log('未处理的消息类型:', type);
  }
  return true;
});

// 初始化，添加分析按钮
function initializeSlidesAnalyzer() {
  // 确认我们在Google Slides页面
  if (!window.location.href.includes('docs.google.com/presentation')) {
    return;
  }
  console.log('Google Slides项目分析器初始化');

  // 监听页面加载完成
  window.addEventListener('load', () => {
    // 添加分析按钮到Google Slides界面
    setTimeout(addAnalysisButton, 2000);
  });
}

// 添加分析按钮到Google Slides界面
function addAnalysisButton() {
  // 查找Google Slides工具栏
  const toolbar = document.querySelector('.goog-toolbar-horizontal');
  if (!toolbar) {
    console.warn('未找到Google Slides工具栏，尝试延迟添加');
    setTimeout(addAnalysisButton, 2000);
    return;
  }

  // 检查按钮是否已存在
  if (document.getElementById('analyze-projects-button')) {
    return;
  }

  // 创建按钮
  const button = document.createElement('div');
  button.id = 'analyze-projects-button';
  button.className = 'goog-toolbar-button';
  button.setAttribute('role', 'button');
  button.setAttribute('aria-disabled', 'false');
  button.style.display = 'inline-flex';
  button.style.alignItems = 'center';
  button.style.padding = '0 8px';
  button.style.cursor = 'pointer';
  button.style.color = '#444';
  button.style.fontWeight = 'bold';
  button.innerHTML = '📊 分析项目';

  // 添加事件监听
  button.addEventListener('click', () => {
    // 通知background脚本或popup我们需要token
    chrome.runtime.sendMessage({
      type: 'REQUEST_SLIDES_ANALYSIS'
    });
  });

  // 添加到工具栏
  toolbar.appendChild(button);
  console.log('已添加项目分析按钮');
}

// 分析幻灯片中的项目信息
async function analyzeSlideProjects(token) {
  try {
    showToast('正在分析项目信息...');

    // 获取当前URL
    const currentUrl = window.location.href;

    // 从URL获取演示文稿ID
    const presentationId = getPresentationIdFromUrl(currentUrl);

    // 获取幻灯片内容，传入当前URL以便只分析当前幻灯片
    const projectsData = await getProjectsFromSlide(presentationId, token, undefined, currentUrl, {
      useLLMFallback: true
    });
    if (!projectsData || projectsData.length === 0) {
      showToast('未找到项目信息', 'warning');
      return;
    }
    showToast(`找到 ${projectsData.length} 个项目，正在分析...`);
    console.log('需求处理的目标projects数据: ', projectsData);

    // 分析项目数据
    const analysisResult = await analyzeProjectsData(projectsData);

    // 显示分析结果
    showAnalysisResults(analysisResult, presentationId, token);
  } catch (error) {
    console.error('分析项目信息时出错:', error);
    showToast(`分析失败: ${error instanceof Error ? error.message : String(error)}`, 'error');
  }
}

// 分析项目数据
async function analyzeProjectsData(projectsData) {
  // 初始化分析结果
  const analysisResult = {
    projects: projectsData,
    updateSuggestions: [],
    summary: {
      totalProjects: projectsData.length,
      projectsNeedingUpdate: 0,
      normalProjects: 0,
      attentionProjects: 0,
      riskProjects: 0,
      keyFindings: []
    }
  };

  // 检查是否在 background script 环境中
  const isBackground = typeof window === 'undefined';

  // 准备批量处理项目数据
  const projectAnalysisRequests = [];

  // 逐个准备项目分析请求
  for (const project of projectsData) {
    // 获取Jira工单信息
    let jiraData = null;
    if (project.id && project.id.match(/[A-Z]+-\d+/)) {
      try {
        // 使用封装的Jira API获取数据
        const jiraTickets = await fetchJiraTickets(`key = ${project.id}`);
        if (jiraTickets && jiraTickets.length > 0) {
          jiraData = jiraTickets[0];
        }
      } catch (error) {
        console.warn(`获取Jira工单信息失败: ${project.id}`, error);
      }
    }

    // 直接构建结构化数据，不再构建具体的消息内容
    // agentThinking.ts中的buildProjectAnalysisPrompt将处理提示构建
    const analysisRequest = {
      name: project.name,
      project: project,
      jiraData: jiraData
    };
    projectAnalysisRequests.push(analysisRequest);
  }
  try {
    // 创建分析配置
    const config = {
      type: 'project',
      analysisDepth: 'normal',
      maxActions: 5,
      preferredTools: ['jiraQuery', 'historySearch']
    };

    // 创建分析上下文
    const context = {
      currentUser: 'system'
    };

    // 分析结果数组
    let analysisResults = [];

    // 使用agentThinking的批量分析功能
    if (isBackground) {
      // 在background环境使用新版API批量处理
      const agent = new agentThinking/* IntelligentAgent */.V();
      analysisResults = await agent.analyzeBatch(projectAnalysisRequests, config, context);
    } else {
      // 在content script环境通过message passing处理
      analysisResults = await Promise.all(projectAnalysisRequests.map(request => chrome.runtime.sendMessage({
        type: 'ANALYZE_PROJECT',
        data: {
          request,
          config,
          context
        }
      })));
    }

    // 处理分析结果
    for (let i = 0; i < projectsData.length; i++) {
      const project = projectsData[i];
      const result = analysisResults[i];
      if (result && result.suggestions) {
        // 获取建议更新值 - 简化结构，直接获取数组的第一个元素作为建议值
        // 注意: 新结构中suggestions中的每个字段应该直接是字符串数组

        // 只为存在的列创建建议
        const hasStatusColumn = project.columnIndices?.status !== undefined;
        const hasOwnerColumn = project.columnIndices?.owner !== undefined;
        const hasTrackColumn = project.columnIndices?.track !== undefined;
        const hasCommentsColumn = project.columnIndices?.comments !== undefined;

        // 根据实际存在的列获取建议值
        const suggestedStatus = hasStatusColumn && result.suggestions.status;
        const suggestedOwner = hasOwnerColumn && result.suggestions.owner;
        const suggestedTrack = hasTrackColumn && result.suggestions.track;
        const comments = Array.isArray(result.suggestions.highlights) && result.suggestions.highlights.length > 0 ? result.suggestions.highlights.join('\n') : result.suggestions.highlights;
        const actions = Array.isArray(result.suggestions.actionItems) && result.suggestions.actionItems.length > 0 ? result.suggestions.actionItems.join('\n') : result.suggestions.actionItems;
        const suggestedComments = hasCommentsColumn && comments + '\n' + actions;

        // 获取更新理由
        const reasons = Array.isArray(result.suggestions.risks) ? result.suggestions.risks : [];

        // 标记是否需要更新
        const needsUpdate = hasStatusColumn && suggestedStatus && suggestedStatus !== project.status || hasOwnerColumn && suggestedOwner && suggestedOwner !== project.owner || hasTrackColumn && suggestedTrack && suggestedTrack !== project.track || hasCommentsColumn && suggestedComments && !project.comments?.includes(suggestedComments);
        if (needsUpdate) {
          const suggestion = {
            projectId: project.id,
            projectName: project.name,
            currentStatus: project.status,
            currentOwner: project.owner,
            currentTrack: project.track,
            currentComments: project.comments,
            reason: reasons,
            sourceInfo: {
              jiraStatus: result.jiraData?.status || '',
              jiraComments: Array.isArray(result.jiraData?.comments) ? result.jiraData?.comments : [],
              chatHistory: []
            },
            confidence: result.confidence || 0.5,
            // 添加幻灯片位置信息
            slideId: project.slideId,
            tableId: project.tableId,
            rowIndex: project.row,
            columnIndices: {
              status: project.columnIndices?.status,
              owner: project.columnIndices?.owner,
              track: project.columnIndices?.track,
              comments: project.columnIndices?.comments
            }
          };

          // 只添加实际存在列的建议更新字段
          if (hasStatusColumn && suggestedStatus) {
            suggestion.suggestedStatus = suggestedStatus;
            suggestion.suggestedStatusReason = result.suggestions.statusReason || '';
          }
          if (hasOwnerColumn && suggestedOwner) {
            suggestion.suggestedOwner = suggestedOwner;
            suggestion.suggestedOwnerReason = result.suggestions.ownerReason || '';
          }
          if (hasTrackColumn && suggestedTrack) {
            suggestion.suggestedTrack = suggestedTrack;
          }
          if (hasCommentsColumn && suggestedComments) {
            suggestion.suggestedComments = suggestedComments;
            suggestion.suggestedCommentsReason = result.suggestions.highlightsReason || '';
            suggestion.suggestedCommentsReason += '\n' + (result.suggestions.actionItemsReason || '');
          }
          analysisResult.updateSuggestions.push(suggestion);
        }

        // 更新统计数据
        const statusHasRisk = project.status.toLowerCase().includes('risk');
        const suggestedStatusHasRisk = suggestedStatus && suggestedStatus.toLowerCase().includes('risk');
        if (statusHasRisk || needsUpdate && suggestedStatusHasRisk || result.riskLevel === 'critical' || result.riskLevel === 'high') {
          analysisResult.summary.riskProjects++;
        } else if (needsUpdate || result.riskLevel === 'normal') {
          analysisResult.summary.attentionProjects++;
        } else {
          analysisResult.summary.normalProjects++;
        }
      }
    }

    // 设置需要更新的项目总数
    analysisResult.summary.projectsNeedingUpdate = analysisResult.updateSuggestions.length;

    // 生成关键发现
    if (analysisResult.updateSuggestions.length > 0) {
      // 提取主要的发现点
      analysisResult.updateSuggestions.forEach(suggestion => {
        if (suggestion.suggestedStatus && suggestion.suggestedStatus !== suggestion.currentStatus) {
          analysisResult.summary.keyFindings.push(`${suggestion.projectName}(${suggestion.projectId})项目状态需要从"${suggestion.currentStatus}"更新为"${suggestion.suggestedStatus}"`);
        }

        // 添加其他重要发现
        if (suggestion.reason && suggestion.reason.length > 0) {
          const mainReason = suggestion.reason[0];
          if (mainReason && !analysisResult.summary.keyFindings.includes(mainReason)) {
            analysisResult.summary.keyFindings.push(mainReason);
          }
        }
      });
    }

    // 限制关键发现数量
    if (analysisResult.summary.keyFindings.length > 5) {
      analysisResult.summary.keyFindings = analysisResult.summary.keyFindings.slice(0, 5);
    }
    return analysisResult;
  } catch (error) {
    console.error('项目分析失败:', error);
    throw error;
  }
}

// 显示分析结果
function showAnalysisResults(result, presentationId, token) {
  // 准备要传递的数据
  const analysisData = {
    result,
    presentationId,
    token
  };

  // 将数据转为JSON字符串并编码
  const encodedData = encodeURIComponent(JSON.stringify(analysisData));

  // 获取扩展URL
  const extensionUrl = chrome.runtime.getURL('slides-analysis.html');

  // 打开新窗口，带上数据作为URL参数
  const newWindow = window.open(`${extensionUrl}?data=${encodedData}`, '_blank', 'width=800,height=800,resizable=yes,scrollbars=yes');
  if (!newWindow) {
    showToast('弹出窗口被阻止，请允许弹出窗口并重试', 'error');
    return;
  }

  // 保存弹窗引用到全局变量
  window.analysisPopupWindow = newWindow;
  console.log('保存分析窗口引用到全局变量');

  // 添加消息监听器，处理来自新窗口的消息
  const messageHandler = async event => {
    console.log('收到来自弹出窗口的消息:', event.data);
    if (event.data && event.data.type === 'APPLY_PROJECT_UPDATES') {
      console.log('处理项目更新请求', event.data.selectedUpdates?.length || 0);
      try {
        const {
          presentationId,
          token,
          selectedUpdates
        } = event.data;
        // 确保所有需要的字段都存在
        if (!presentationId || !token || !selectedUpdates || !Array.isArray(selectedUpdates)) {
          console.error('收到无效的更新请求', event.data);
          return;
        }
        await contentScriptGoogleSlide_applyProjectUpdates(presentationId, token, selectedUpdates);
      } catch (error) {
        console.error('处理项目更新请求时出错:', error);
        showToast(`处理更新失败: ${error instanceof Error ? error.message : String(error)}`, 'error');
      }
    } else if (event.data && event.data.type === 'POPUP_READY') {
      console.log('弹出窗口已准备好接收消息');
    }
  };

  // 移除任何现有的消息处理程序，以避免重复
  window.removeEventListener('message', messageHandler);
  window.addEventListener('message', messageHandler);
}

// 应用项目更新
async function contentScriptGoogleSlide_applyProjectUpdates(presentationId, token, selectedUpdates) {
  try {
    showToast('正在应用更新...');

    // 使用slide.ts中的函数应用更新
    const result = await applyProjectUpdates(presentationId, token, selectedUpdates);
    if (result.success) {
      showToast(`成功更新了 ${result.updatedCount} 个项目字段`, 'success');
      console.log('更新成功:', result);

      // 显示成功消息并通知弹出窗口
      showSuccessInPopup(selectedUpdates, result.updatedCount);
    } else {
      const errorMessage = result.errors && result.errors.length > 0 ? result.errors.join('; ') : '更新失败，请重试';
      showToast(`更新失败: ${errorMessage}`, 'error');
      console.error('更新失败:', result.errors);

      // 向弹出窗口发送错误消息
      if (window.analysisPopupWindow) {
        window.analysisPopupWindow.postMessage({
          type: 'UPDATE_ERROR',
          errorMessage
        }, '*');
      }
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    showToast(`更新处理错误: ${errorMessage}`, 'error');
    console.error('处理更新时出错:', error);

    // 向弹出窗口发送错误消息
    if (window.analysisPopupWindow) {
      window.analysisPopupWindow.postMessage({
        type: 'UPDATE_ERROR',
        errorMessage
      }, '*');
    }
  }
}

// 在弹出窗口中显示成功消息
function showSuccessInPopup(updates, updatedCount) {
  // 向所有打开的窗口发送消息
  const message = {
    type: 'UPDATE_SUCCESS',
    updatedCount,
    updates
  };

  // 尝试向弹出窗口发送消息
  try {
    console.log('准备发送UPDATE_SUCCESS消息给分析窗口');

    // 首先尝试使用已保存的窗口引用
    if (window.analysisPopupWindow) {
      console.log('使用已保存的分析窗口引用发送消息');
      window.analysisPopupWindow.postMessage(message, '*');
      return;
    }
    console.log('未找到已保存的分析窗口引用，尝试使用其他方法');

    // 如果没有保存的窗口引用，尝试其他方法
    // 检查当前窗口是否有子窗口
    if (window.frames && window.frames.length > 0) {
      console.log(`尝试向 ${window.frames.length} 个子窗口发送消息`);
      for (let i = 0; i < window.frames.length; i++) {
        try {
          window.frames[i].postMessage(message, '*');
          console.log(`向子窗口 ${i} 发送消息成功`);
        } catch (e) {
          console.warn(`向子窗口 ${i} 发送消息失败`, e);
        }
      }
    }

    // 尝试向opener窗口发送消息
    if (window.opener) {
      console.log('尝试向opener窗口发送消息');
      window.opener.postMessage(message, '*');
    }
  } catch (e) {
    console.warn('处理弹出窗口引用失败', e);
  }
}

// 显示通知提示
function showToast(message) {
  let type = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'info';
  // 移除任何已存在的toast
  const existingToast = document.getElementById('slides-analyzer-toast');
  if (existingToast) {
    document.body.removeChild(existingToast);
  }

  // 创建新的toast
  const toast = document.createElement('div');
  toast.id = 'slides-analyzer-toast';

  // 设置样式根据消息类型
  let backgroundColor = '#2196F3'; // 默认蓝色(info)
  if (type === 'success') backgroundColor = '#4CAF50'; // 绿色
  if (type === 'warning') backgroundColor = '#FF9800'; // 橙色
  if (type === 'error') backgroundColor = '#F44336'; // 红色

  toast.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background-color: ${backgroundColor};
    color: white;
    padding: 12px 20px;
    border-radius: 4px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    z-index: 10001;
    font-family: Arial, sans-serif;
    font-size: 14px;
    max-width: 300px;
  `;
  toast.textContent = message;
  document.body.appendChild(toast);

  // 5秒后自动移除
  setTimeout(() => {
    if (document.body.contains(toast)) {
      document.body.removeChild(toast);
    }
  }, 5000);
}

// 初始化
initializeSlidesAnalyzer();
})();

/******/ })()
;
//# sourceMappingURL=contentScriptGoogleSlide.js.map