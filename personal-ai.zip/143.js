"use strict";
(self["webpackChunkpersonal_ai"] = self["webpackChunkpersonal_ai"] || []).push([[143],{

/***/ 1929:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZN: () => (/* binding */ getEmbeddingInBackground),
/* harmony export */   bZ: () => (/* binding */ handleEmbeddingResult),
/* harmony export */   hd: () => (/* binding */ createOffscreenDocument),
/* harmony export */   zP: () => (/* binding */ getEmbeddingViaOffscreen)
/* harmony export */ });
// 创建新文件处理嵌入相关功能
const pendingEmbeddingRequests = new Map();

// 创建离屏文档
async function createOffscreenDocument() {
  try {
    // 检查是否已经存在离屏文档
    const existingContexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT']
    });
    if (existingContexts.length > 0) {
      // console.log('离屏文档已存在');
      return;
    }
    console.log('创建离屏文档...');
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['WORKERS'],
      justification: '需要使用 WebAssembly 来运行嵌入模型'
    });
    console.log('离屏文档创建成功');
  } catch (error) {
    console.error('创建离屏文档失败:', error);
  }
}

// 通过离屏文档获取嵌入向量
async function getEmbeddingViaOffscreen(text) {
  const isBackground = typeof ServiceWorkerGlobalScope !== 'undefined' && self instanceof ServiceWorkerGlobalScope;
  if (isBackground) {
    return await getEmbeddingInBackground(text);
  } else {
    const result = await chrome.runtime.sendMessage({
      type: 'EXEC_EMBEDDING_REQUEST',
      text
    });
    return result;
  }
}
async function getEmbeddingInBackground(text) {
  try {
    await createOffscreenDocument();

    // 生成唯一请求ID
    const requestId = Date.now().toString() + Math.random().toString().slice(2);

    // 创建Promise并存储
    const resultPromise = new Promise((resolve, reject) => {
      pendingEmbeddingRequests.set(requestId, {
        resolve,
        reject
      });

      // 设置超时
      setTimeout(() => {
        if (pendingEmbeddingRequests.has(requestId)) {
          pendingEmbeddingRequests.delete(requestId);
          reject(new Error('获取嵌入向量超时'));
        }
      }, 30000); // 30秒超时
    });

    // 发送消息到离屏文档
    chrome.runtime.sendMessage({
      type: 'GET_EMBEDDING',
      requestId,
      text
    });
    return resultPromise;
  } catch (error) {
    console.error('通过离屏文档获取嵌入向量失败:', error);
    return new Array(384).fill(0);
  }
}

// 处理嵌入结果
function handleEmbeddingResult(message) {
  if (message.type === 'EMBEDDING_RESULT') {
    const requestId = message.requestId;
    const pendingRequest = pendingEmbeddingRequests.get(requestId);
    if (pendingRequest) {
      pendingEmbeddingRequests.delete(requestId);
      pendingRequest.resolve(message.embedding);
    }
  }
}

/***/ }),

/***/ 6939:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  memorySystem: () => (/* binding */ memorySystem)
});

// UNUSED EXPORTS: CachedEntityDetail, MemoryEntity, MemorySystem

// EXTERNAL MODULE: ./src/storage/CloudStorage.ts
var CloudStorage = __webpack_require__(8143);
// EXTERNAL MODULE: ./src/storage/LocalStorage.ts
var LocalStorage = __webpack_require__(7997);
;// CONCATENATED MODULE: ./src/storage/EntitySimilarityTool.ts
/**
 * 实体相似性管理工具
 * 负责实体的相似性判断、自动合并和用户确认流程
 */

/**
 * 实体相似性管理器
 */
class EntitySimilarityTool {
  constructor() {
    this.pendingMerges = new Map();
    this.mergeCandidatesCache = new Map();
    // 相似性阈值配置
    this.THRESHOLDS = {
      AUTO_MERGE: 0.9,
      // 自动合并阈值
      CANDIDATE_MARK: 0.7,
      // 候选标记阈值
      DEEP_ANALYSIS: 0.75 // 深度分析确认阈值
    };
    this.loadPendingMerges();
  }

  /**
   * 处理新实体（主入口）
   */
  async processEntity(entity) {
    const now = Date.now();
    const fullEntity = {
      ...entity,
      id: entity.type + '_' + entity.name,
      created: now,
      updated: now,
      accessCount: 0,
      lastAccessed: now,
      importance: entity.importance || 0.5
    };

    // 进行相似性检查
    const similarityResult = await this.quickSimilarityCheck(fullEntity);
    const processedEntity = {
      ...fullEntity,
      action: similarityResult.action,
      targetId: similarityResult.targetEntity?.id,
      mergeReason: similarityResult.reasoning
    };
    return processedEntity;
  }

  /**
   * 批量处理实体
   */
  async processEntities(entities) {
    const results = [];
    for (const entity of entities) {
      try {
        const processed = await this.processEntity(entity);
        results.push(processed);
      } catch (error) {
        console.error('处理实体失败:', error);
        // 继续处理其他实体
      }
    }
    return results;
  }

  /**
   * 实时简单相似性判断
   */
  async quickSimilarityCheck(newEntity) {
    try {
      // 1. 查找候选实体
      const candidates = await this.findCandidateEntities(newEntity);
      if (candidates.length === 0) {
        return {
          action: 'create_new',
          confidence: 0
        };
      }

      // 2. 计算与每个候选的相似度
      let bestMatch = null;
      for (const candidate of candidates) {
        const similarity = this.calculateQuickSimilarity(newEntity, candidate);
        if (!bestMatch || similarity > bestMatch.similarity) {
          bestMatch = {
            entity: candidate,
            similarity
          };
        }
      }
      if (!bestMatch) {
        return {
          action: 'create_new',
          confidence: 0
        };
      }

      // 3. 根据阈值决定行动
      if (bestMatch.similarity > this.THRESHOLDS.AUTO_MERGE) {
        return {
          action: 'auto_merge',
          targetEntity: bestMatch.entity,
          confidence: bestMatch.similarity,
          reasoning: '高相似度自动合并'
        };
      } else if (bestMatch.similarity > this.THRESHOLDS.CANDIDATE_MARK) {
        return {
          action: 'mark_candidate',
          targetEntity: bestMatch.entity,
          confidence: bestMatch.similarity,
          reasoning: '中等相似度，标记为候选'
        };
      } else {
        return {
          action: 'create_new',
          confidence: bestMatch.similarity,
          reasoning: '相似度较低，创建新实体'
        };
      }
    } catch (error) {
      console.error('快速相似性检查失败:', error);
      return {
        action: 'create_new',
        confidence: 0,
        reasoning: '检查失败，创建新实体'
      };
    }
  }

  /**
   * 查找候选实体（简化版本）
   */
  async findCandidateEntities(entity) {
    // 这里是简化版本，实际实现中需要从缓存中查找相同类型的实体
    const cacheKey = `candidates_${entity.type}`;
    if (this.mergeCandidatesCache.has(cacheKey)) {
      return this.mergeCandidatesCache.get(cacheKey);
    }

    // 在实际实现中，这里应该从 LocalCache 中获取相同类型的实体
    // 暂时返回空数组
    return [];
  }

  /**
   * 计算快速相似度
   */
  calculateQuickSimilarity(entity1, entity2) {
    let similarity = 0;

    // 类型必须相同
    if (entity1.type !== entity2.type) {
      return 0;
    }

    // 名称相似度（权重50%）
    const nameSimilarity = this.stringSimilarity(entity1.name, entity2.name);
    similarity += nameSimilarity * 0.5;

    // 描述相似度（权重30%）
    if (entity1.description && entity2.description) {
      const descSimilarity = this.stringSimilarity(entity1.description, entity2.description);
      similarity += descSimilarity * 0.3;
    }

    // 属性相似度（权重20%）
    const propsSimilarity = this.propertiesSimilarity(entity1.properties, entity2.properties);
    similarity += propsSimilarity * 0.2;
    return similarity;
  }

  /**
   * 字符串相似度计算
   */
  stringSimilarity(str1, str2) {
    if (str1 === str2) return 1;
    if (!str1 || !str2) return 0;
    const longer = str1.length > str2.length ? str1 : str2;
    const shorter = str1.length > str2.length ? str2 : str1;
    if (longer.length === 0) return 1;

    // 简化的编辑距离算法
    const editDistance = this.levenshteinDistance(str1.toLowerCase(), str2.toLowerCase());
    return (longer.length - editDistance) / longer.length;
  }

  /**
   * 计算编辑距离
   */
  levenshteinDistance(str1, str2) {
    const matrix = [];
    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i];
    }
    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j;
    }
    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
        }
      }
    }
    return matrix[str2.length][str1.length];
  }

  /**
   * 属性相似度计算
   */
  propertiesSimilarity(props1, props2) {
    const keys1 = Object.keys(props1);
    const keys2 = Object.keys(props2);
    const allKeys = new Set([...keys1, ...keys2]);
    if (allKeys.size === 0) return 1;
    let matchingProps = 0;
    for (const key of allKeys) {
      const val1 = props1[key];
      const val2 = props2[key];
      if (val1 !== undefined && val2 !== undefined) {
        if (typeof val1 === 'string' && typeof val2 === 'string') {
          const similarity = this.stringSimilarity(val1, val2);
          if (similarity > 0.8) matchingProps++;
        } else if (val1 === val2) {
          matchingProps++;
        }
      }
    }
    return matchingProps / allKeys.size;
  }

  /**
   * 获取待处理的合并候选
   */
  async getPendingMerges() {
    return Array.from(this.pendingMerges.values());
  }

  /**
   * 确认合并
   */
  async confirmMerge(mergeId) {
    const mergePair = this.pendingMerges.get(mergeId);
    if (!mergePair) return false;
    try {
      mergePair.status = 'approved';
      await this.savePendingMerges();
      return true;
    } catch (error) {
      console.error('确认合并失败:', error);
      return false;
    }
  }

  /**
   * 拒绝合并
   */
  async rejectMerge(mergeId) {
    const mergePair = this.pendingMerges.get(mergeId);
    if (!mergePair) return false;
    try {
      mergePair.status = 'rejected';
      this.pendingMerges.delete(mergeId);
      await this.savePendingMerges();
      return true;
    } catch (error) {
      console.error('拒绝合并失败:', error);
      return false;
    }
  }

  /**
   * 保存待处理合并到存储
   */
  async savePendingMerges() {
    try {
      const data = Array.from(this.pendingMerges.entries());
      await chrome.storage.local.set({
        'pending_entity_merges': data
      });
    } catch (error) {
      console.error('保存待处理合并失败:', error);
    }
  }

  /**
   * 从存储加载待处理合并
   */
  async loadPendingMerges() {
    try {
      const result = await chrome.storage.local.get('pending_entity_merges');
      if (result.pending_entity_merges) {
        this.pendingMerges = new Map(result.pending_entity_merges);
      }
    } catch (error) {
      console.error('加载待处理合并失败:', error);
    }
  }

  /**
   * 调整阈值
   */
  adjustThresholds(newThresholds) {
    Object.assign(this.THRESHOLDS, newThresholds);
  }

  /**
   * 获取统计信息
   */
  getStatistics() {
    return {
      pendingMerges: this.pendingMerges.size,
      thresholds: {
        ...this.THRESHOLDS
      }
    };
  }
}

// 导出单例实例
const entitySimilarityTool = new EntitySimilarityTool();
;// CONCATENATED MODULE: ./src/storage/SystemMaintenanceTool.ts
/**
 * 系统维护工具
 * 负责健康监控、定时维护、数据清理等任务
 */

// 策略层接口定义（用于与 MemorySystem 交互）

/**
 * 系统维护工具
 */
class SystemMaintenanceTool {
  // 实体数量阈值

  constructor(cloudStorage, localStorage, strategyLayer) {
    this.isMonitoringActive = false;
    this.monitoringInterval = null;
    this.maintenanceInterval = null;
    this.MONITORING_INTERVAL = 5 * 60 * 1000;
    // 5分钟
    this.MAINTENANCE_INTERVAL = 6 * 60 * 60 * 1000;
    // 6小时
    this.CACHE_CLEANUP_THRESHOLD = 1000;
    this.cloudStorage = cloudStorage;
    this.localStorage = localStorage;
    this.strategyLayer = strategyLayer;
  }

  /**
   * 启动系统监控
   */
  startMonitoring() {
    if (this.isMonitoringActive) {
      console.log('⚠️ 系统监控已经在运行');
      return;
    }
    this.isMonitoringActive = true;

    // 启动健康监控
    this.monitoringInterval = setInterval(async () => {
      try {
        await this.performHealthCheck();
      } catch (error) {
        console.error('健康检查失败:', error);
      }
    }, this.MONITORING_INTERVAL);

    // 启动定期维护
    this.maintenanceInterval = setInterval(async () => {
      try {
        await this.performAutomaticMaintenance();
      } catch (error) {
        console.error('自动维护失败:', error);
      }
    }, this.MAINTENANCE_INTERVAL);
    console.log('🔍 系统监控已启动');
  }

  /**
   * 停止系统监控
   */
  stopMonitoring() {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
    if (this.maintenanceInterval) {
      clearInterval(this.maintenanceInterval);
      this.maintenanceInterval = null;
    }
    this.isMonitoringActive = false;
    console.log('🔍 系统监控已停止');
  }

  /**
   * 执行健康检查
   */
  async performHealthCheck() {
    const startTime = Date.now();
    const status = {
      timestamp: startTime,
      cloudStorage: {
        available: false,
        connected: false,
        entityCount: 0,
        lastSync: 0,
        errors: []
      },
      localCache: {
        available: false,
        entityCount: 0,
        relationshipCount: 0,
        cacheSize: 0,
        lastCleanup: 0,
        errors: []
      },
      overall: {
        status: 'offline',
        score: 0,
        issues: [],
        recommendations: []
      }
    };
    try {
      // 1. 检查云端存储
      await this.checkCloudStorageHealth(status);

      // 2. 检查本地缓存
      await this.checkLocalCacheHealth(status);

      // 3. 计算整体健康状态
      this.calculateOverallHealth(status);

      // 4. 生成建议
      this.generateRecommendations(status);

      // 5. 保存健康记录
      await this.saveHealthMetrics(status);
      console.log(`🏥 健康检查完成 - 状态: ${status.overall.status}, 评分: ${status.overall.score}`);
      return status;
    } catch (error) {
      console.error('❌ 健康检查失败:', error);
      status.overall.status = 'critical';
      status.overall.issues.push(`健康检查失败: ${error.message}`);
      return status;
    }
  }

  /**
   * 检查云端存储健康状态
   */
  async checkCloudStorageHealth(status) {
    try {
      status.cloudStorage.available = true;
      status.cloudStorage.connected = await this.cloudStorage.isConnected();
      if (status.cloudStorage.connected) {
        status.cloudStorage.entityCount = await this.cloudStorage.getEntityCount();
        status.cloudStorage.lastSync = await this.strategyLayer.getLastSyncTime();
      } else {
        status.cloudStorage.errors.push('云端存储连接失败');
      }
    } catch (error) {
      status.cloudStorage.errors.push(`云端存储检查失败: ${error.message}`);
    }
  }

  /**
   * 检查本地缓存健康状态
   */
  async checkLocalCacheHealth(status) {
    try {
      status.localCache.available = true;
      status.localCache.cacheSize = await this.localStorage.getCacheSize();

      // 获取实体统计
      const entityStats = await this.localStorage.getEntityStatistics();
      status.localCache.entityCount = entityStats.totalEntities;
      status.localCache.relationshipCount = entityStats.totalRelationships;

      // 检查缓存大小
      if (status.localCache.cacheSize > 4 * 1024 * 1024) {
        // 4MB
        status.localCache.errors.push('本地缓存大小超过4MB，建议清理');
      }

      // 检查实体数量
      if (status.localCache.entityCount > this.CACHE_CLEANUP_THRESHOLD) {
        status.localCache.errors.push(`实体数量过多(${status.localCache.entityCount})，建议清理`);
      }
    } catch (error) {
      status.localCache.errors.push(`本地缓存检查失败: ${error.message}`);
    }
  }

  /**
   * 计算整体健康状态
   */
  calculateOverallHealth(status) {
    let score = 100;
    const issues = [];

    // 云端存储健康度检查
    if (!status.cloudStorage.connected) {
      score -= 30;
      issues.push('云端存储连接异常');
    }

    // 本地缓存健康度检查
    if (status.localCache.errors.length > 0) {
      score -= 20;
      issues.push('本地缓存存在问题');
    }

    // 同步状态检查
    const lastSyncAge = Date.now() - status.cloudStorage.lastSync;
    if (lastSyncAge > 24 * 60 * 60 * 1000) {
      // 超过24小时
      score -= 25;
      issues.push('超过24小时未同步');
    }

    // 缓存大小检查
    if (status.localCache.cacheSize > 3 * 1024 * 1024) {
      // 3MB
      score -= 15;
      issues.push('本地缓存占用空间过大');
    }

    // 确定状态
    if (score >= 90) {
      status.overall.status = 'healthy';
    } else if (score >= 70) {
      status.overall.status = 'warning';
    } else if (score >= 40) {
      status.overall.status = 'critical';
    } else {
      status.overall.status = 'offline';
    }
    status.overall.score = Math.max(0, score);
    status.overall.issues = issues;
  }

  /**
   * 生成维护建议
   */
  generateRecommendations(status) {
    const recommendations = [];
    if (!status.cloudStorage.connected) {
      recommendations.push('检查网络连接，重新连接云端存储');
    }
    if (status.localCache.cacheSize > 3 * 1024 * 1024) {
      recommendations.push('执行缓存清理，释放本地存储空间');
    }
    if (status.localCache.entityCount > this.CACHE_CLEANUP_THRESHOLD) {
      recommendations.push('清理旧实体数据，保持缓存效率');
    }
    const lastSyncAge = Date.now() - status.cloudStorage.lastSync;
    if (lastSyncAge > 12 * 60 * 60 * 1000) {
      // 超过12小时
      recommendations.push('执行数据同步，保持数据一致性');
    }
    if (status.localCache.relationshipCount > 500) {
      recommendations.push('备份关系数据到云端，防止数据丢失');
    }
    status.overall.recommendations = recommendations;
  }

  /**
   * 执行自动维护
   */
  async performAutomaticMaintenance() {
    const startTime = Date.now();
    const result = {
      success: false,
      tasksCompleted: [],
      tasksFailed: [],
      cleanedEntities: 0,
      cleanedRelationships: 0,
      freedSpace: 0,
      totalTime: 0,
      nextMaintenanceTime: Date.now() + this.MAINTENANCE_INTERVAL
    };
    try {
      console.log('🔧 开始自动维护...');

      // 1. 清理过期缓存
      try {
        await this.localStorage.clearExpiredCache();
        result.tasksCompleted.push('清理过期缓存');
      } catch (error) {
        result.tasksFailed.push('清理过期缓存失败');
      }

      // 2. 检查并执行新设备同步
      try {
        const syncResult = await this.strategyLayer.performInitialSyncIfNeeded();
        if (syncResult.syncPerformed) {
          result.tasksCompleted.push(`新设备同步: ${syncResult.entitiesDownloaded} 个实体`);
        }
      } catch (error) {
        result.tasksFailed.push('新设备同步检查失败');
      }

      // 3. 备份关系数据（每天一次）
      try {
        const lastBackup = await this.getLastBackupTime();
        if (Date.now() - lastBackup > 24 * 60 * 60 * 1000) {
          const relationshipData = await this.localStorage.getRelationshipBackupData();
          if (relationshipData) {
            const backupSuccess = await this.cloudStorage.backupRelationships(relationshipData);
            if (backupSuccess) {
              result.tasksCompleted.push('备份关系数据');
              await this.setLastBackupTime(Date.now());
            } else {
              result.tasksFailed.push('备份关系数据失败');
            }
          }
        }
      } catch (error) {
        result.tasksFailed.push('关系数据备份失败');
      }

      // 4. 计算释放的空间
      const finalCacheSize = await this.localStorage.getCacheSize();
      result.freedSpace = Math.max(0, finalCacheSize);
      result.success = result.tasksFailed.length === 0;
      result.totalTime = Date.now() - startTime;
      console.log(`🔧 自动维护完成 - 成功: ${result.tasksCompleted.length}, 失败: ${result.tasksFailed.length}`);
      return result;
    } catch (error) {
      console.error('❌ 自动维护失败:', error);
      result.tasksFailed.push(`维护过程异常: ${error.message}`);
      result.totalTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 手动执行完整维护
   */
  async performFullMaintenance(options) {
    const startTime = Date.now();
    const opts = {
      cleanupEntities: true,
      cleanupRelationships: true,
      forceSync: false,
      backupData: true,
      cleanupExpiredConversations: true,
      // 🆕 默认启用
      ...options
    };
    const result = {
      success: false,
      tasksCompleted: [],
      tasksFailed: [],
      cleanedEntities: 0,
      cleanedRelationships: 0,
      freedSpace: 0,
      totalTime: 0,
      nextMaintenanceTime: Date.now() + this.MAINTENANCE_INTERVAL
    };
    try {
      console.log('🔧 开始完整维护...');
      const initialCacheSize = await this.localStorage.getCacheSize();

      // 1. 清理过期缓存
      try {
        await this.localStorage.clearExpiredCache();
        result.tasksCompleted.push('清理过期缓存');
      } catch (error) {
        result.tasksFailed.push('清理过期缓存失败');
      }

      // 2. 🆕 清理过期已读消息
      if (opts.cleanupExpiredConversations) {
        try {
          console.log('🧹 开始清理过期消息...');
          const cleanupResult = await this.cloudStorage.cleanExpiredReadConversations();
          result.tasksCompleted.push(`清理过期消息: ${cleanupResult.conversationsRemoved}条`);
          result.freedSpace += cleanupResult.spaceSaved;
          console.log(`✅ 清理完成: ${cleanupResult.conversationsRemoved}条消息, 节省${(cleanupResult.spaceSaved / 1024).toFixed(2)}KB`);
        } catch (error) {
          console.error('清理过期消息失败:', error);
          result.tasksFailed.push('清理过期消息失败');
        }
      }

      // 3. 强制同步（如果请求）
      if (opts.forceSync) {
        try {
          await this.strategyLayer.syncCache();
          result.tasksCompleted.push('强制同步缓存');
        } catch (error) {
          result.tasksFailed.push('强制同步失败');
        }
      }

      // 4. 备份数据（如果请求）
      if (opts.backupData) {
        try {
          const relationshipData = await this.localStorage.getRelationshipBackupData();
          if (relationshipData) {
            const backupSuccess = await this.cloudStorage.backupRelationships(relationshipData);
            if (backupSuccess) {
              result.tasksCompleted.push('备份关系数据');
            } else {
              result.tasksFailed.push('备份关系数据失败');
            }
          }
        } catch (error) {
          result.tasksFailed.push('数据备份失败');
        }
      }

      // 5. 计算释放的空间
      const finalCacheSize = await this.localStorage.getCacheSize();
      result.freedSpace += initialCacheSize - finalCacheSize;
      result.success = result.tasksFailed.length === 0;
      result.totalTime = Date.now() - startTime;
      console.log(`🔧 完整维护完成 - 成功: ${result.tasksCompleted.length}, 失败: ${result.tasksFailed.length}`);
      return result;
    } catch (error) {
      console.error('❌ 完整维护失败:', error);
      result.tasksFailed.push(`维护过程异常: ${error.message}`);
      result.totalTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 保存健康指标
   */
  async saveHealthMetrics(status) {
    try {
      await chrome.storage.local.set({
        'system_health_status': status,
        'system_health_timestamp': status.timestamp
      });
    } catch (error) {
      console.error('保存健康指标失败:', error);
    }
  }

  /**
   * 获取最后备份时间
   */
  async getLastBackupTime() {
    try {
      const result = await chrome.storage.local.get('last_backup_time');
      return result.last_backup_time || 0;
    } catch (error) {
      return 0;
    }
  }

  /**
   * 设置最后备份时间
   */
  async setLastBackupTime(time) {
    try {
      await chrome.storage.local.set({
        'last_backup_time': time
      });
    } catch (error) {
      console.error('设置备份时间失败:', error);
    }
  }

  /**
   * 获取系统状态
   */
  getSystemStatus() {
    return {
      isMonitoring: this.isMonitoringActive,
      monitoringInterval: this.MONITORING_INTERVAL,
      maintenanceInterval: this.MAINTENANCE_INTERVAL,
      nextMaintenance: Date.now() + this.MAINTENANCE_INTERVAL
    };
  }
}

// 创建工厂函数
function createSystemMaintenanceTool(cloudStorage, localStorage, strategyLayer) {
  return new SystemMaintenanceTool(cloudStorage, localStorage, strategyLayer);
}
// EXTERNAL MODULE: ./src/services/UserProfileManager.ts
var UserProfileManager = __webpack_require__(9857);
// EXTERNAL MODULE: ./src/services/entityExtraction.ts
var entityExtraction = __webpack_require__(8);
;// CONCATENATED MODULE: ./src/memory.ts
/**
 * 统一记忆系统接口层
 * 提供清晰的读取和存储接口，管理本地缓存和云端存储
 */







// 重新导出接口供其他模块使用



// 查询结果接口

// 存储结果接口

// 查询选项

// 向量搜索选项

// 实体类型信息接口

// 实体类型配置
const ENTITY_TYPE_CONFIG = {
  'Person': {
    name: '人物',
    icon: '👥',
    description: '团队成员、联系人、项目相关人员等'
  },
  'Project': {
    name: '项目',
    icon: '🚀',
    description: '工作项目、产品开发、研究项目等'
  },
  'Task': {
    name: '任务',
    icon: '📋',
    description: '具体工作任务、待办事项、行动项等'
  },
  'Organization': {
    name: '组织',
    icon: '🏢',
    description: '公司、部门、团队、客户组织等'
  },
  'Document': {
    name: '文档',
    icon: '📄',
    description: '文件、资料、规范、报告等'
  },
  'Technology': {
    name: '技术',
    icon: '🔧',
    description: '技术栈、工具、框架、平台等'
  },
  'Topic': {
    name: '主题',
    icon: '💡',
    description: '讨论话题、知识领域、专业概念等'
  }
};

// 策略配置

// 性能指标

/**
 * 统一记忆系统管理器 - 现在直接充当策略层
 */
class MemorySystem {
  constructor() {
    // 🔓 改为 public，供 llm.ts 等模块访问
    this.userProfileManager = null;
    this.isInitialized = false;
    this.alarmListenerAdded = false;
    this.backgroundSyncStarted = false;
    this.isSyncing = false;
    this.initializationPromise = null;
    // 添加初始化Promise
    // 🆕 智能检索配置（ask() 方法专用）
    this.ASK_CONFIG = {
      MIN_RELEVANCE_SCORE: 0.5,
      // 实体相关度阈值（可调整）
      MAX_CONTEXT_LENGTH: 100000,
      // 最大上下文长度（~25K tokens）
      ENABLE_2HOP_THRESHOLD: 5,
      // 当 1-hop 结果少于此值时触发 2-hop
      MIN_2HOP_RELEVANCE: 0.4,
      // 2-hop 实体的最低相关度
      ENTITY_LIMIT_PER_TYPE: 20,
      // 每种类型最多返回实体数
      CONTEXT_COMPRESSION_RATIO: 0.7 // 上下文压缩比例
    };
    this.cloudStorage = new CloudStorage/* CloudStorage */.f();
    this.localStorage = new LocalStorage/* LocalStorage */.D();
    this.entitySimilarityTool = new EntitySimilarityTool();
    // 暂时延迟初始化 systemMaintenanceTool，在 initialize 方法中初始化
    this.systemMaintenanceTool = null;

    // 初始化策略配置
    this.config = {
      preferLocalForEntityQueries: true,
      localSearchThreshold: 5,
      cloudFallbackTimeout: 5000,
      requireCloudSuccess: false,
      retryAttempts: 3,
      retryDelay: 1000,
      syncInterval: 30 * 60 * 1000,
      // 30分钟
      maxSyncBatchSize: 50,
      prioritizeRecentData: true
    };

    // 初始化性能指标
    this.metrics = {
      totalQueries: 0,
      localHits: 0,
      cloudHits: 0,
      averageLocalTime: 0,
      averageCloudTime: 0,
      cacheHitRate: 0,
      lastReset: Date.now()
    };
  }

  /**
   * 初始化记忆系统（纯粹的初始化逻辑）
   */
  async performInitialization() {
    try {
      console.log('🧠 初始化记忆系统...');

      // 并行初始化各组件
      const [cloudInit, localInit] = await Promise.all([this.cloudStorage.initialize(), this.localStorage.initialize()]);

      // 加载配置和指标
      await this.loadConfig();
      await this.loadMetrics();
      this.isInitialized = cloudInit && localInit;
      if (this.isInitialized) {
        console.log('✅ 记忆系统初始化完成');

        // 初始化系统维护工具（需要 memorySystem 实例，所以在这里初始化）
        this.systemMaintenanceTool = createSystemMaintenanceTool(this.cloudStorage, this.localStorage, this // 传入自身作为策略层
        );

        // 启动后台同步
        this.startBackgroundSync();
        // 启动系统监控
        this.systemMaintenanceTool.startMonitoring();

        // 初始化用户画像管理器
        await this.initializeUserProfile();
      } else {
        console.error('❌ 记忆系统初始化失败');
      }
      return this.isInitialized;
    } catch (error) {
      console.error('❌ 记忆系统初始化异常:', error);
      this.isInitialized = false; // 确保失败时重置状态
      return false;
    }
  }

  /**
   * 初始化记忆系统（公共接口）
   */
  async initialize() {
    // 如果已经在初始化中，返回现有的Promise
    if (this.initializationPromise) {
      console.log('⚠️ 记忆系统正在初始化中，等待完成...');
      return this.initializationPromise;
    }

    // 防止重复初始化
    if (this.isInitialized) {
      console.log('⚠️ 记忆系统已初始化，跳过重复初始化');
      return true;
    }

    // 创建并缓存初始化Promise
    this.initializationPromise = this.performInitialization().finally(() => {
      // 无论成功失败，都清除Promise缓存
      this.initializationPromise = null;
    });
    return this.initializationPromise;
  }

  // ==================== 读取接口 ====================

  /**
   * 查询实体（普通查询，智能策略）
   */
  async queryEntities(type, searchTerm) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const startTime = Date.now();
    this.metrics.totalQueries++;
    try {
      // 如果有搜索词且长度大于2，考虑使用向量搜索
      if (searchTerm && searchTerm.length > 2) {
        const cloudResult = await this.cloudStorage.searchByVector(searchTerm, type, options);
        // 缓存结果到本地
        await this.cacheCloudResults(cloudResult.data);
        // 扩展实体信息
        const extendedData = await this.extendEntitiesFromCache(cloudResult.data);
        return {
          ...cloudResult,
          data: extendedData
        };
      }

      // 设置默认分页参数（第一页30条数据）
      const queryOptions = {
        ...options,
        limit: options.limit || 30,
        offset: options.offset || 0
      };

      // 优先查询云端获取分页数据
      const cloudResult = await this.queryFromCloud(type, searchTerm, queryOptions);
      this.updateMetrics('cloud', Date.now() - startTime);

      // 缓存结果到本地
      await this.cacheCloudResults(cloudResult.data);

      // 扩展实体信息：合并recent data
      const extendedData = await this.extendEntitiesFromCache(cloudResult.data);
      console.log(`🎯 MemorySystem.queryEntities: 查询到 ${cloudResult.data.length} 个实体，扩展信息后 ${extendedData.length} 个`);
      return {
        ...cloudResult,
        data: extendedData
      };
    } catch (error) {
      console.error('查询实体失败:', error);

      // 出错时尝试返回本地结果
      if (type) {
        const fallbackResult = await this.queryFromLocal(type, searchTerm, options);
        const extendedData = await this.extendEntitiesFromCache(fallbackResult.data);
        return {
          ...fallbackResult,
          data: extendedData,
          source: 'local'
        };
      }
      return {
        data: [],
        total: 0,
        source: 'local',
        cached: true,
        queryTime: Date.now() - startTime
      };
    }
  }

  /**
   * 向量搜索（直接云端查询）
   */
  async searchByVector(query, type) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.cloudStorage.searchByVector(query, type, options);
  }

  /**
   * 获取实体详情（优先本地，包含详细信息补充）
   */
  async getEntityDetails(entityId) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      // 先从本地获取
      const localEntity = await this.localStorage.getEntity(entityId);
      if (localEntity) {
        this.metrics.localHits++;
        // 检查是否需要补充详细信息
        return await this.enrichEntityWithDetails(localEntity);
      }

      // 本地没有，从云端获取
      const entity = await this.cloudStorage.getEntity(entityId);
      if (entity) {
        // 缓存到本地并补充详细信息
        await this.localStorage.cacheEntity(entity);
        this.metrics.cloudHits++;
        return await this.enrichEntityWithDetails(entity);
      }
      return null;
    } catch (error) {
      console.error('获取实体详情失败:', error);
      return null;
    }
  }

  /**
   * 为实体补充详细信息（特别是 recent data）
   */
  async enrichEntityWithDetails(entity) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      // 首先尝试从本地缓存获取详细信息
      const cachedDetails = await this.localStorage.getEntity(entity.id);

      // 检查是否缺少 recent data（没有讨论、资源、项目）
      const hasRecentData = cachedDetails && (cachedDetails.recentDataDetails?.conversations && cachedDetails.recentDataDetails.conversations.length > 0 || cachedDetails.recentDataDetails?.resources && cachedDetails.recentDataDetails.resources.length > 0 || cachedDetails.recentDataDetails?.projects && cachedDetails.recentDataDetails.projects.length > 0);
      if (hasRecentData && cachedDetails) {
        return cachedDetails;
      }

      // 如果缺少详细信息，从云端扩展实体信息
      console.log(`🔍 为实体 ${entity.id} 补充详细信息...`);
      const extendedEntity = await this.cloudStorage.extendEntityToDetailCache(entity);

      // 更新本地缓存
      await this.localStorage.cacheEntity(extendedEntity);
      return extendedEntity;
    } catch (error) {
      console.error(`补充实体 ${entity.id} 详细信息失败:`, error);

      // 失败时返回基础扩展版本
      return {
        ...entity,
        cachedAt: Date.now(),
        recentDataDetails: {
          conversations: [],
          webpages: [],
          resources: [],
          projects: [],
          people: [],
          topics: [],
          jiraTickets: [],
          cooccurringEntities: []
        },
        relatedParticipants: []
      };
    }
  }

  /**
   * 批量为实体补充详细信息
   */
  async enrichEntitiesWithDetails(entities) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const enrichedEntities = [];
    for (const entity of entities) {
      const enrichedEntity = await this.enrichEntityWithDetails(entity);
      enrichedEntities.push(enrichedEntity);
    }
    return enrichedEntities;
  }

  /**
   * 获取实体类型统计
   */
  async getEntityStatistics() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.localStorage.getEntityStatistics();
  }

  /**
   * 获取实体类型信息列表
   */
  async getEntityTypes() {
    try {
      const entityTypes = [];

      // 获取实体统计信息，包含各类型的数量
      const statistics = await this.getEntityStatistics();
      const entityCounts = statistics.entityCounts;

      // 遍历所有已知的实体类型
      for (const [type, count] of Object.entries(entityCounts)) {
        const config = ENTITY_TYPE_CONFIG[type];
        if (config) {
          entityTypes.push({
            type,
            name: config.name,
            icon: config.icon,
            count,
            description: config.description
          });
        } else {
          // 未知类型，使用默认配置
          entityTypes.push({
            type,
            name: type,
            icon: '📂',
            count,
            description: `自定义类型: ${type}`
          });
        }
      }

      // 按数量排序
      entityTypes.sort((a, b) => b.count - a.count);
      console.log(`📋 获取实体类型列表: ${entityTypes.length}个类型`);
      return entityTypes;
    } catch (error) {
      console.error('获取实体类型失败:', error);
      return [];
    }
  }

  /**
   * 搜索实体
   */
  async searchEntities(query, entityType) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (query.length > 2) {
      // 使用向量搜索 - 确保返回实体格式
      const vectorOptions = {
        ...options,
        returnType: 'entities',
        // 确保返回实体格式
        sortBy: 'relevance' // 默认按相关度排序
      };
      return this.searchByVector(query, entityType, vectorOptions);
    } else {
      // 使用普通查询
      return this.queryEntities(entityType, query, options);
    }
  }

  /**
   * 获取关系网络
   */
  async getRelationships(entityId) {
    let depth = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.localStorage.getRelationshipNetwork(entityId, depth);
  }

  /**
   * 获取时间轴数据
   */
  async getTimeline() {
    let limit = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 50;
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.cloudStorage.getTimeline(limit);
  }

  /**
   * 查询实体相关的详细消息（包含contextMessages等完整数据）
   */
  async queryEntityMessages(entityName, options) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }

    // 使用增强的 searchByVector 方法，专门搜索消息并返回原始数据格式
    const result = await this.cloudStorage.searchByVector(entityName, undefined, {
      collections: ['messages'],
      // 只搜索消息集合
      returnType: 'messages',
      // 返回原始数据格式
      limit: options?.limit,
      sortBy: options?.sortBy,
      sortOrder: options?.sortOrder,
      timeRange: options?.timeRange,
      minRelevanceScore: options?.minRelevanceScore
    });
    return result.data || [];
  }

  // ==================== 🆕 高级查询接口 ====================

  /**
   * 🆕 通过关系查找相关实体
   * 例如：查找所有与 "alex" 相关的 Topic
   * 
   * @param targetName 目标实体名称，例如: "alex", "厦门"
   * @param targetType 目标实体类型
   * @param relatedType 要查找的相关实体类型
   * @param options 查询选项
   * @returns 相关实体列表，按相关度排序
   */
  async findRelatedEntitiesByName(targetName, targetType, relatedType) {
    let options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const {
      minRelevanceScore = 0.5,
      timeRange,
      limit = 20
    } = options;
    console.log(`🔗 查找与 "${targetName}" (${targetType}) 相关的所有 ${relatedType}`);
    try {
      // Step 1: 获取所有目标类型的实体（使用分批查询避免内存问题）
      const batchSize = 50;
      let offset = 0;
      const relatedEntities = [];
      let hasMore = true;
      while (hasMore && relatedEntities.length < limit * 2) {
        // 查询足够多以应对过滤
        const batch = await this.cloudStorage.queryEntities(relatedType, undefined, {
          limit: batchSize,
          offset: offset
        });
        if (batch.data.length === 0) {
          hasMore = false;
          break;
        }

        // Step 2: 过滤出包含目标实体的实体
        for (const entity of batch.data) {
          let isRelated = false;
          let relationScore = 0;

          // 检查 relatedData 中是否包含目标实体
          if (targetType === 'Person' && entity.relatedData?.people) {
            const match = entity.relatedData.people.find(p => p.name.toLowerCase().includes(targetName.toLowerCase()));
            if (match) {
              isRelated = true;
              relationScore = match.relevanceScore || 0.5;
            }
          } else if (targetType === 'Project' && entity.relatedData?.projects) {
            const match = entity.relatedData.projects.find(p => p.name.toLowerCase().includes(targetName.toLowerCase()));
            if (match) {
              isRelated = true;
              relationScore = match.relevanceScore || 0.5;
            }
          } else if (targetType === 'Topic' && entity.relatedData?.topics) {
            const match = entity.relatedData.topics.find(t => t.name.toLowerCase().includes(targetName.toLowerCase()));
            if (match) {
              isRelated = true;
              relationScore = match.relevanceScore || 0.5;
            }
          }

          // 检查共现实体
          if (!isRelated && entity.relatedData?.cooccurringEntities) {
            const match = entity.relatedData.cooccurringEntities.find(e => e.name.toLowerCase().includes(targetName.toLowerCase()));
            if (match) {
              isRelated = true;
              relationScore = match.relevanceScore || 0.3;
            }
          }

          // 如果相关且满足条件，加入结果
          if (isRelated && relationScore >= minRelevanceScore) {
            // 时间过滤
            if (timeRange) {
              const entityTime = entity.updated || entity.created;
              if (entityTime < timeRange.start || entityTime > timeRange.end) {
                continue;
              }
            }

            // 添加关系分数
            entity.relevanceScore = relationScore;
            relatedEntities.push(entity);
          }
        }
        offset += batchSize;
      }

      // Step 3: 按相关度排序
      relatedEntities.sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));

      // Step 4: 限制结果数量
      const results = limit ? relatedEntities.slice(0, limit) : relatedEntities;
      console.log(`✅ 找到 ${results.length} 个相关 ${relatedType}`);
      return results;
    } catch (error) {
      console.error(`🚨 关系查询失败:`, error);
      return [];
    }
  }

  /**
   * 🆕 知识查询 - 智能路由的高级查询接口
   * 
   * 这个方法是记忆系统的智能查询入口，它会：
   * 1. 使用 LLM 分析用户问题，提取查询意图和实体
   * 2. 执行实体模糊匹配，找到数据库中的准确实体
   * 3. 并行搜索：实体 + 消息 + 关系扩展
   * 4. 智能融合结果，优先使用实体信息
   * 5. 使用 LLM 生成最终答案
   * 
   * @param question 用户的自然语言问题
   * @returns 查询结果，包含分析答案和相关上下文
   */
  async ask(question) {
    const startTime = Date.now();
    const success = await this.initialize();
    if (!success) {
      return {
        success: false,
        message: '记忆系统初始化失败'
      };
    }
    console.log('🌟 MemorySystem.ask:', question, Date.now());
    try {
      // Step 1: 使用 LLM 分析查询意图
      const queryIntent = await (0,entityExtraction.extractEntitiesForQuery)(question);
      console.log('📊 查询意图:', queryIntent, Date.now());

      // Step 2: 时间范围处理和实体模糊匹配
      this.processTimeRange(queryIntent);
      await this.fuzzyMatchEntities(queryIntent);
      console.log('✅ 最终查询意图:', queryIntent);

      // Step 3: 🆕 混合检索策略 - 向量搜索实体
      let initialEntities = [];
      const hasEntities = queryIntent?.query?.filters?.entities && (queryIntent.query.filters.entities.people?.length > 0 || queryIntent.query.filters.entities.projects?.length > 0 || queryIntent.query.filters.entities.topics?.length > 0);
      if (hasEntities) {
        console.log('🔍 执行混合检索（向量 + 关系）...');

        // 方式A: 向量搜索各类实体
        const searchPromises = [];
        if (queryIntent.query.filters.entities.topics?.length > 0) {
          searchPromises.push(this.searchByVector(question, 'Topic', {
            collections: ['entities'],
            limit: 10,
            minRelevanceScore: this.ASK_CONFIG.MIN_RELEVANCE_SCORE,
            returnType: 'entities'
          }));
        }
        if (queryIntent.query.filters.entities.people?.length > 0) {
          searchPromises.push(this.searchByVector(question, 'Person', {
            collections: ['entities'],
            limit: 5,
            minRelevanceScore: this.ASK_CONFIG.MIN_RELEVANCE_SCORE,
            returnType: 'entities'
          }));
        }
        if (queryIntent.query.filters.entities.projects?.length > 0) {
          searchPromises.push(this.searchByVector(question, 'Project', {
            collections: ['entities'],
            limit: 5,
            minRelevanceScore: this.ASK_CONFIG.MIN_RELEVANCE_SCORE,
            returnType: 'entities'
          }));
        }

        // 并行执行所有搜索
        const searchResults = await Promise.all(searchPromises);

        // 合并所有搜索结果
        for (const result of searchResults) {
          initialEntities.push(...result.data);
        }
        console.log(`✅ 混合检索完成: 找到 ${initialEntities.length} 个初始实体`);
      } else {
        // 如果没有提取到实体，直接进行向量搜索
        console.log('🔍 执行通用向量搜索...');
        const result = await this.searchByVector(question, undefined, {
          collections: ['entities'],
          limit: 15,
          minRelevanceScore: this.ASK_CONFIG.MIN_RELEVANCE_SCORE - 0.1,
          returnType: 'entities'
        });
        initialEntities = result.data;
        console.log(`✅ 通用搜索完成: 找到 ${initialEntities.length} 个实体`);
      }

      // Step 4: 🆕 动态多跳扩展
      console.log('🔄 开始多跳实体扩展...');
      const entityMap = await this.expandEntitiesMultiHop(initialEntities, queryIntent);
      const expandDepth = entityMap.size > initialEntities.length + 10 ? 2 : 1;
      console.log(`✅ 实体扩展完成: ${entityMap.size} 个实体 (${expandDepth}-hop)`);

      // Step 5: 构建增强上下文
      const context = await this.buildAskContext(entityMap, queryIntent);
      console.log(`📄 上下文构建完成: ${context.length} 字符`);

      // Step 6: LLM 推理 - 返回结构化 JSON
      const {
        handleLLMRequest
      } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 1995));
      const prompt = this.buildAskPrompt(question, context);
      const llmResponse = await handleLLMRequest({
        prompt
      });

      // Step 7: 解析 LLM 返回的 JSON
      let parsedResponse;
      try {
        // 尝试提取 JSON（可能被包裹在代码块中）
        const jsonMatch = llmResponse.match(/```json\s*([\s\S]*?)\s*```/);
        const jsonStr = jsonMatch ? jsonMatch[1] : llmResponse;
        parsedResponse = JSON.parse(jsonStr.trim());
      } catch (error) {
        console.warn('⚠️  LLM 返回格式解析失败，使用默认格式:', error);
        parsedResponse = {
          answer: llmResponse,
          relatedEntityIds: {
            topics: [],
            people: [],
            projects: [],
            jiraTickets: [],
            organizations: [],
            documents: [],
            technologies: []
          }
        };
      }

      // Step 8: 根据 LLM 返回的 ID 匹配完整实体
      const entitiesByType = {
        topics: [],
        people: [],
        projects: [],
        jiraTickets: [],
        organizations: [],
        documents: [],
        technologies: []
      };

      // 构建ID到实体的映射
      const idToEntity = new Map();
      for (const entity of Array.from(entityMap.values())) {
        idToEntity.set(entity.id, entity);
      }

      // 匹配实体
      if (parsedResponse.relatedEntityIds) {
        for (const [typeKey, ids] of Object.entries(parsedResponse.relatedEntityIds)) {
          if (Array.isArray(ids)) {
            for (const id of ids) {
              const entity = idToEntity.get(id);
              if (entity) {
                entitiesByType[typeKey].push(entity);
              } else {
                console.warn(`⚠️  未找到实体 ID: ${id}`);
              }
            }
          }
        }
      }

      // Step 9: 按相关度排序并限制数量
      for (const typeKey of Object.keys(entitiesByType)) {
        entitiesByType[typeKey].sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));
        entitiesByType[typeKey] = entitiesByType[typeKey].slice(0, this.ASK_CONFIG.ENTITY_LIMIT_PER_TYPE);
      }
      const totalEntities = Object.values(entitiesByType).reduce((sum, arr) => sum + arr.length, 0);
      const processingTime = Date.now() - startTime;
      console.log(`✅ ask() 完成: ${totalEntities} 个相关实体, 耗时 ${processingTime}ms`);
      return {
        success: true,
        answer: parsedResponse.answer,
        structuredAnswer: parsedResponse.structuredAnswer,
        entitiesByType,
        metadata: {
          totalEntities: totalEntities,
          expandDepth,
          processingTime,
          queryIntent
        }
      };
    } catch (error) {
      console.error('💥 智能查询失败:', error);
      return {
        success: false,
        message: '查询时发生错误，请稍后再试。'
      };
    }
  }

  /**
   * @deprecated 请使用 ask() 方法代替
   * 
   * 🆕 高级知识查询接口（兼容旧接口）
   * 
   * 这个方法是记忆系统的智能查询入口，它会：
   * 1. 使用 LLM 分析用户问题，提取查询意图和实体
   * 2. 执行实体模糊匹配，找到数据库中的准确实体
   * 3. 并行搜索：实体 + 消息 + 关系扩展
   * 4. 智能融合结果，优先使用实体信息
   * 5. 使用 LLM 生成最终答案
   * 
   * @param question 用户的自然语言问题
   * @returns 查询结果，包含分析答案和相关上下文
   */
  async knowledgeQuery(question) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    console.log('🔍 MemorySystem.knowledgeQuery:', question, Date.now());
    try {
      // 导入必要的函数
      const {
        extractEntitiesForQuery
      } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 8));
      const {
        handleLLMRequest
      } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 1995));

      // Step 1: 使用 LLM 分析查询意图
      const queryIntent = await extractEntitiesForQuery(question);
      console.log('📊 查询意图:', queryIntent, Date.now());

      // Step 2: 时间范围处理（与原来的 knowledgeQuery 逻辑相同）
      this.processTimeRange(queryIntent);

      // Step 3: 实体模糊匹配
      await this.fuzzyMatchEntities(queryIntent);
      console.log('✅ 最终查询意图:', queryIntent);

      // Step 4: 🆕 并行搜索：实体 + 消息
      let entityResults = [];
      let messageResults = null;
      const hasEntities = queryIntent?.query?.filters?.entities && (queryIntent.query.filters.entities.people?.length > 0 || queryIntent.query.filters.entities.projects?.length > 0 || queryIntent.query.filters.entities.topics?.length > 0);
      if (hasEntities) {
        console.log('🔍 尝试直接搜索 Topic 实体...');

        // 🆕 方式A: 向量搜索 Topic 实体
        const topicSearchResult = await this.searchByVector(question, 'Topic', {
          collections: ['entities'],
          limit: 5,
          minRelevanceScore: 0.6,
          returnType: 'entities'
        });

        // 🆕 方式B: 关系扩展查询
        const relationResults = [];

        // 如果查询中包含人物，通过关系查找相关Topic
        if (queryIntent.query.filters.entities.people?.length > 0) {
          const personName = queryIntent.query.filters.entities.people[0].name;
          console.log(`🔗 通过关系查找 ${personName} 相关的 Topic...`);
          const timeRange = queryIntent.query.filters.time_range && queryIntent.query.filters.time_range.start && queryIntent.query.filters.time_range.end ? {
            start: queryIntent.query.filters.time_range.start,
            end: queryIntent.query.filters.time_range.end
          } : undefined;
          const relatedTopics = await this.findRelatedEntitiesByName(personName, 'Person', 'Topic', {
            timeRange,
            minRelevanceScore: 0.5,
            limit: 5
          });
          console.log(`  找到 ${relatedTopics.length} 个通过关系找到的Topic`);
          relationResults.push(...relatedTopics);
        }

        // 🆕 合并向量搜索和关系查询的结果
        const allTopics = [...topicSearchResult.data];

        // 去重合并（基于ID）
        const topicIds = new Set(allTopics.map(t => t.id));
        for (const topic of relationResults) {
          if (!topicIds.has(topic.id)) {
            allTopics.push(topic);
            topicIds.add(topic.id);
          }
        }

        // 按相关度重新排序
        allTopics.sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));
        entityResults = allTopics.slice(0, 5); // 取前5个
        console.log(`✅ 最终找到 ${entityResults.length} 个Topic实体`);
      }

      // Step 5: 搜索相关消息
      const filters = {};
      if (queryIntent?.query?.filters) {
        if (queryIntent.query.filters.entities) {
          filters.entities = queryIntent.query.filters.entities;
        }
        if (queryIntent.query.filters.time_range) {
          filters.time_range = queryIntent.query.filters.time_range;
        }
      }
      const output = queryIntent?.query?.output || {
        format: "list",
        limit: 20,
        sort: {
          field: "timestamp",
          order: "desc"
        }
      };
      try {
        const timeRange = filters.time_range && filters.time_range.start && filters.time_range.end ? {
          start: filters.time_range.start,
          end: filters.time_range.end
        } : undefined;
        const messages = await this.cloudStorage.getSimilarMessages(question, {
          limit: output.limit || 20,
          minRelevanceScore: 0.3,
          timeRange,
          sortBy: output.sort?.field === 'timestamp' ? 'time' : 'relevance',
          sortOrder: output.sort?.order || 'desc',
          filters: {
            entities: filters.entities
          }
        });
        messageResults = {
          question: question,
          results: {
            ids: messages.map(m => m.id),
            documents: messages.map(m => m.content),
            metadatas: messages.map(m => ({
              sender: m.sender,
              source: m.sender,
              groupName: m.groupName,
              groupUrl: m.groupUrl,
              datetime: m.datetime,
              summary: m.summary,
              matchedRules: m.matchedRules,
              contextMessages: m.contextMessages
            })),
            distances: messages.map(m => 1 - (m.relevanceScore || 0))
          }
        };
      } catch (error) {
        console.error('💥 消息查询失败:', error);
        messageResults = {
          question: question,
          results: {
            ids: [],
            documents: [],
            metadatas: [],
            distances: []
          }
        };
      }

      // Step 6: 🆕 智能融合结果
      const contextSources = await this.buildContextFromResults(entityResults, messageResults);
      if (contextSources.length === 0) {
        return {
          success: false,
          message: `没有找到关于"${question}"的相关信息。`
        };
      }

      // Step 7: 构建 LLM prompt 并生成答案
      const prompt = this.buildLLMPrompt(question, contextSources, queryIntent);
      const llmResponse = await handleLLMRequest({
        prompt
      });

      // Step 8: 返回结果
      return {
        success: true,
        analysis: llmResponse,
        relatedMessages: messageResults?.results?.documents?.length || 0,
        queryIntent: queryIntent,
        results: this.formatResults(messageResults?.results)
      };
    } catch (error) {
      console.error('💥 知识查询失败:', error);
      return {
        success: false,
        message: '查询时发生错误，请稍后再试。'
      };
    }
  }

  // ==================== 私有辅助方法 ====================

  /**
   * 处理时间范围
   */
  processTimeRange(queryIntent) {
    if (!queryIntent?.query?.filters?.time_range) return;
    const timeRange = queryIntent.query.filters.time_range;

    // 处理时间疑问词
    if (timeRange.type === 'specific' && typeof timeRange.start === 'string') {
      const timeQuestionWords = ["什么时候", "何时", "几点", "哪天", "什么日期", "什么时间", "几号", "什么时段", "几月", "哪一天", "什么季节"];
      if (timeQuestionWords.some(word => timeRange.start.includes(word))) {
        console.log(`检测到时间疑问词: "${timeRange.start}"，将time_range.type设为"all"`);
        timeRange.type = "all";
        timeRange.start = null;
        timeRange.end = null;
        return;
      }
    }

    // 根据时间描述设置具体的时间范围
    if (timeRange.type === 'range' && timeRange.description) {
      const now = new Date();
      const thisYear = now.getFullYear();
      const thisMonth = now.getMonth();
      if (/今年|本年|今年度|本年度/.test(timeRange.description)) {
        const startOfYear = new Date(thisYear, 0, 1).getTime();
        timeRange.start = startOfYear;
        timeRange.end = now.getTime();
      } else if (/这个月|本月|当月/.test(timeRange.description)) {
        const startOfMonth = new Date(thisYear, thisMonth, 1).getTime();
        timeRange.start = startOfMonth;
        timeRange.end = now.getTime();
      } else if (/过去(\d+)天|最近(\d+)天/.test(timeRange.description)) {
        const matches = timeRange.description.match(/过去(\d+)天|最近(\d+)天/);
        if (matches) {
          const days = parseInt(matches[1] || matches[2]);
          if (!isNaN(days)) {
            timeRange.start = now.getTime() - days * 24 * 60 * 60 * 1000;
            timeRange.end = now.getTime();
          }
        }
      }
    }

    // 如果是recent类型，设置默认为过去7天
    if (timeRange.type === 'recent') {
      const now = new Date();
      timeRange.start = now.getTime() - 7 * 24 * 60 * 60 * 1000;
      timeRange.end = now.getTime();
    }
  }

  /**
   * 实体模糊匹配
   */
  async fuzzyMatchEntities(queryIntent) {
    // 导入模糊匹配函数
    const fuzzyMatchPerson = (name, knownPeople) => {
      const normalizedName = name.toLowerCase().trim();
      for (const knownName of knownPeople) {
        if (knownName.toLowerCase().includes(normalizedName) || normalizedName.includes(knownName.toLowerCase())) {
          return knownName;
        }
      }
      return null;
    };
    const fuzzyMatchEntityName = (name, knownNames) => {
      return fuzzyMatchPerson(name, knownNames);
    };

    // 获取所有已知实体
    const [knownPeople, knownProjects, knownTopics] = await Promise.all([this.cloudStorage.getAllKnownPeople(), this.cloudStorage.getAllKnownProjects(), this.cloudStorage.getAllKnownTopics()]);
    console.log('📋 已知实体:', {
      people: knownPeople.length,
      projects: knownProjects.length,
      topics: knownTopics.length
    });

    // 人名模糊匹配
    if (queryIntent?.query?.filters?.entities?.people?.length > 0) {
      const matchedPeople = [];
      for (const person of queryIntent.query.filters.entities.people) {
        const matchedPerson = fuzzyMatchPerson(person.name, knownPeople);
        if (matchedPerson) {
          console.log(`人名匹配: "${person.name}" => "${matchedPerson}"`);
          matchedPeople.push({
            ...person,
            name: matchedPerson
          });
        } else {
          matchedPeople.push(person);
        }
      }
      queryIntent.query.filters.entities.people = matchedPeople;
    }

    // 项目和主题模糊匹配
    if (queryIntent?.query?.filters?.entities?.projects?.length > 0) {
      const matchedProjects = [];
      for (const project of queryIntent.query.filters.entities.projects) {
        const matchedName = fuzzyMatchEntityName(project.name, knownProjects);
        if (matchedName) {
          console.log(`项目匹配: "${project.name}" => "${matchedName}"`);
          matchedProjects.push({
            ...project,
            name: matchedName
          });
        } else {
          matchedProjects.push(project);
        }
      }
      queryIntent.query.filters.entities.projects = matchedProjects;
    }
    if (queryIntent?.query?.filters?.entities?.topics?.length > 0) {
      const matchedTopics = [];
      for (const topic of queryIntent.query.filters.entities.topics) {
        const matchedName = fuzzyMatchEntityName(topic.name, knownTopics);
        if (matchedName) {
          console.log(`主题匹配: "${topic.name}" => "${matchedName}"`);
          matchedTopics.push({
            ...topic,
            name: matchedName
          });
        } else {
          matchedTopics.push(topic);
        }
      }
      queryIntent.query.filters.entities.topics = matchedTopics;
    }
  }

  /**
   * 从实体和消息结果构建上下文
   */
  async buildContextFromResults(entityResults, messageResults) {
    const contextSources = [];

    // 🆕 优先使用 Topic 实体信息
    if (entityResults && entityResults.length > 0) {
      console.log('🎯 使用 Topic 实体作为主要上下文');
      for (const entity of entityResults) {
        let entityContext = `### Topic: ${entity.name}\n`;
        if (entity.description) {
          entityContext += `描述: ${entity.description}\n`;
        }

        // 🔑 从 relatedData 中提取信息
        if (entity.relatedData) {
          if (entity.relatedData.people && entity.relatedData.people.length > 0) {
            const peopleNames = entity.relatedData.people.map(p => p.name).join(', ');
            entityContext += `相关人员: ${peopleNames}\n`;
          }
          if (entity.relatedData.projects && entity.relatedData.projects.length > 0) {
            const projectNames = entity.relatedData.projects.map(p => p.name).join(', ');
            entityContext += `相关项目: ${projectNames}\n`;
          }

          // 🔑 最近的对话记录（前3条）
          if (entity.relatedData.conversations && entity.relatedData.conversations.length > 0) {
            entityContext += `\n最近讨论:\n`;
            entity.relatedData.conversations.slice(0, 3).forEach((conv, idx) => {
              entityContext += `  ${idx + 1}. [${conv.sender}] ${conv.summary}\n`;
              entityContext += `     时间: ${conv.datetime}\n`;
            });
          }
        }
        contextSources.push({
          type: 'topic_entity',
          priority: 1,
          content: entityContext,
          relevanceScore: entity.relevanceScore || 0
        });
      }
    }

    // 添加消息上下文
    if (messageResults?.results?.documents && messageResults.results.documents.length > 0) {
      for (let i = 0; i < messageResults.results.documents.length; i++) {
        const doc = messageResults.results.documents[i];
        const metadata = messageResults.results.metadatas[i];
        const distance = messageResults.results.distances[i] || 0;
        const relevanceScore = Math.max(0, 1 - distance);
        contextSources.push({
          type: 'message',
          priority: 2,
          content: `### 消息记录\n${doc}\n时间: ${metadata?.datetime || '未知'}\n发送者: ${metadata?.source || '未知'}`,
          relevanceScore
        });
      }
    }

    // 按优先级和相关度排序
    contextSources.sort((a, b) => {
      if (a.priority !== b.priority) return a.priority - b.priority;
      return b.relevanceScore - a.relevanceScore;
    });
    return contextSources;
  }

  /**
   * 构建 LLM prompt
   */
  buildLLMPrompt(question, contextSources, queryIntent) {
    // 构建上下文（限制总长度）
    const MAX_CONTEXT_LENGTH = 4000;
    let messagesContext = '';
    let currentLength = 0;
    for (const source of contextSources) {
      if (currentLength + source.content.length <= MAX_CONTEXT_LENGTH) {
        messagesContext += source.content + '\n\n---\n\n';
        currentLength += source.content.length;
      } else {
        break;
      }
    }
    console.log(`📊 上下文统计: 共${contextSources.length}个来源，使用了${messagesContext.length}字符`);

    // 根据查询类型选择模板
    const promptTemplate = `
以下是与问题"${question}"相关的信息:
{{context}}

请基于以上信息提供详细回答。仅使用提供的信息,不要添加额外知识。
如果信息不足,请明确指出。
    `;
    return promptTemplate.replace('{{context}}', messagesContext);
  }

  /**
   * 格式化结果
   */
  formatResults(results) {
    if (!results || !results.documents) return [];
    return results.documents.map((doc, idx) => {
      const metadata = results.metadatas[idx];
      const id = String(results.ids[idx]);
      const relevance = Math.max(0, 1 - results.distances[idx]);
      return {
        id: id,
        summary: String(metadata.summary) || doc.substring(0, 100) + '...',
        details: String(metadata.details || doc),
        timestamp: metadata.datetime || new Date().toISOString(),
        source: String(metadata.source),
        relevance: relevance,
        tags: metadata.tags || []
      };
    });
  }

  // ==================== ask() 专用辅助方法 ====================

  /**
   * 从 relatedData 中提取关联实体的 ID
   */
  extractRelatedEntityIds(relatedData, minScore) {
    const ids = new Set();
    if (!relatedData) return ids;

    // 提取 people
    if (relatedData.people && Array.isArray(relatedData.people)) {
      for (const item of relatedData.people) {
        if (item.id && (item.relevanceScore || 0) >= minScore) {
          ids.add(item.id);
        }
      }
    }

    // 提取 projects
    if (relatedData.projects && Array.isArray(relatedData.projects)) {
      for (const item of relatedData.projects) {
        if (item.id && (item.relevanceScore || 0) >= minScore) {
          ids.add(item.id);
        }
      }
    }

    // 提取 topics
    if (relatedData.topics && Array.isArray(relatedData.topics)) {
      for (const item of relatedData.topics) {
        if (item.id && (item.relevanceScore || 0) >= minScore) {
          ids.add(item.id);
        }
      }
    }

    // 提取 jiraTickets
    if (relatedData.jiraTickets && Array.isArray(relatedData.jiraTickets)) {
      for (const item of relatedData.jiraTickets) {
        if (item.id && (item.relevanceScore || 0) >= minScore) {
          ids.add(item.id);
        }
      }
    }

    // 提取 cooccurringEntities
    if (relatedData.cooccurringEntities && Array.isArray(relatedData.cooccurringEntities)) {
      for (const item of relatedData.cooccurringEntities) {
        if (item.id && (item.relevanceScore || 0) >= minScore) {
          ids.add(item.id);
        }
      }
    }
    return ids;
  }

  /**
   * 从实体的 relatedData 中提取并加载关联实体
   */
  async expandRelatedData(entities, entityMap) {
    let is2Hop = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
    const newEntityIds = new Set();
    const minScore = is2Hop ? this.ASK_CONFIG.MIN_2HOP_RELEVANCE : this.ASK_CONFIG.MIN_RELEVANCE_SCORE;
    for (const entity of entities) {
      if (!entity.relatedData) continue;

      // 提取所有关联实体 ID
      const relatedIds = this.extractRelatedEntityIds(entity.relatedData, minScore);
      for (const id of Array.from(relatedIds)) {
        if (!entityMap.has(id)) {
          newEntityIds.add(id);
        }
      }
    }

    // 批量加载新实体
    if (newEntityIds.size > 0) {
      console.log(`  🔍 发现 ${newEntityIds.size} 个新的关联实体`);
      const newEntities = await this.cloudStorage.getEntitiesByIds(Array.from(newEntityIds));
      for (const entity of newEntities) {
        entityMap.set(entity.id, entity);
      }
    }
    return newEntityIds;
  }

  /**
   * 判断是否需要进行 2-hop 扩展
   */
  shouldPerform2Hop(currentSize, initialEntities) {
    // 如果初始实体数量就很多，不需要 2-hop
    if (initialEntities.length >= 10) {
      console.log('  ℹ️  初始实体充足，跳过 2-hop');
      return false;
    }

    // 如果 1-hop 后实体数量少于阈值，触发 2-hop
    if (currentSize < this.ASK_CONFIG.ENABLE_2HOP_THRESHOLD) {
      console.log('  ⚠️  1-hop 结果不足，触发 2-hop 扩展');
      return true;
    }
    return false;
  }

  /**
   * 多跳实体扩展
   * 从初始实体集合出发，动态决定是否进行 2-hop 扩展
   */
  async expandEntitiesMultiHop(initialEntities, queryIntent) {
    const entityMap = new Map();

    // 1-hop: 添加初始实体
    console.log(`🌱 初始实体: ${initialEntities.length} 个`);
    for (const entity of initialEntities) {
      entityMap.set(entity.id, entity);
    }

    // 1-hop: 扩展 relatedData 中的关联实体
    await this.expandRelatedData(initialEntities, entityMap);
    console.log(`✅ 1-hop 扩展完成: ${entityMap.size} 个实体`);

    // 🔍 动态决策：是否需要 2-hop
    const need2Hop = this.shouldPerform2Hop(entityMap.size, initialEntities);
    if (need2Hop) {
      console.log('🔄 触发 2-hop 扩展...');
      await this.expandRelatedData(Array.from(entityMap.values()), entityMap, true);
      console.log(`✅ 2-hop 扩展完成: ${entityMap.size} 个实体`);
    }
    return entityMap;
  }

  /**
   * 按类型分组实体
   */
  groupEntitiesByType(entities) {
    const grouped = {
      Topic: [],
      Person: [],
      Project: [],
      Task: [],
      Organization: [],
      Document: [],
      Technology: []
    };
    for (const entity of entities) {
      if (grouped[entity.type]) {
        grouped[entity.type].push(entity);
      }
    }
    return grouped;
  }

  /**
   * 构建实体上下文字符串
   */
  buildEntityContext(entitiesByType) {
    let context = '# 知识库实体信息\n\n';

    // 按类型构建上下文
    const typeNames = {
      Topic: '主题',
      Person: '人员',
      Project: '项目',
      Task: 'Jira任务',
      Organization: '组织',
      Document: '文档',
      Technology: '技术'
    };
    for (const [type, entities] of Object.entries(entitiesByType)) {
      if (entities.length === 0) continue;
      context += `## ${typeNames[type] || type} (${entities.length}个)\n\n`;
      for (const entity of entities) {
        context += `### [${entity.type}] ${entity.name} (ID: ${entity.id})\n`;
        if (entity.description) {
          context += `**描述**: ${entity.description}\n`;
        }

        // 添加重要性和相关度
        if (entity.importance) {
          context += `**重要性**: ${(entity.importance * 100).toFixed(0)}%\n`;
        }
        if (entity.relevanceScore) {
          context += `**相关度**: ${(entity.relevanceScore * 100).toFixed(0)}%\n`;
        }

        // 添加关联信息摘要
        if (entity.relatedData) {
          const summaryParts = [];
          if (entity.relatedData.people?.length > 0) {
            summaryParts.push(`${entity.relatedData.people.length}个相关人员`);
          }
          if (entity.relatedData.projects?.length > 0) {
            summaryParts.push(`${entity.relatedData.projects.length}个相关项目`);
          }
          if (entity.relatedData.conversations?.length > 0) {
            summaryParts.push(`${entity.relatedData.conversations.length}条相关对话`);
          }
          if (summaryParts.length > 0) {
            context += `**关联**: ${summaryParts.join(', ')}\n`;
          }

          // 添加最近的对话摘要（最多3条）
          if (entity.relatedData.conversations && entity.relatedData.conversations.length > 0) {
            context += `**最近讨论**:\n`;
            entity.relatedData.conversations.slice(0, 3).forEach((conv, idx) => {
              context += `  ${idx + 1}. [${conv.sender}] ${conv.summary} (${conv.datetime})\n`;
            });
          }
        }
        context += '\n';
      }
    }
    return context;
  }

  /**
   * 智能压缩上下文
   * 当上下文超出限制时，优先保留高相关度实体
   */
  compressContext(context, entitiesByType) {
    console.log(`⚠️  上下文过长 (${context.length} 字符)，进行压缩...`);

    // 按相关度重新排序所有实体
    const allEntities = [];
    for (const entities of Object.values(entitiesByType)) {
      allEntities.push(...entities);
    }
    allEntities.sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));

    // 只保留最相关的实体，直到达到长度限制
    const targetLength = Math.floor(this.ASK_CONFIG.MAX_CONTEXT_LENGTH * this.ASK_CONFIG.CONTEXT_COMPRESSION_RATIO);
    const compressedEntitiesByType = this.groupEntitiesByType([]);
    let currentLength = 0;
    for (const entity of allEntities) {
      const entityText = this.buildEntityContext({
        [entity.type]: [entity]
      });
      if (currentLength + entityText.length <= targetLength) {
        compressedEntitiesByType[entity.type].push(entity);
        currentLength += entityText.length;
      } else {
        break;
      }
    }
    const compressedContext = this.buildEntityContext(compressedEntitiesByType);
    console.log(`✂️  压缩完成: ${context.length} → ${compressedContext.length} 字符`);
    return compressedContext;
  }

  /**
   * 构建增强型上下文
   * 包含实体摘要、关系网络、对话记录等
   */
  async buildAskContext(entities, queryIntent) {
    // 1. 按相关度排序所有实体
    const sortedEntities = Array.from(entities.values()).sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));
    console.log(`📝 构建上下文: ${sortedEntities.length} 个实体`);

    // 2. 按类型分组
    const entitiesByType = this.groupEntitiesByType(sortedEntities);

    // 3. 构建分层上下文
    let context = this.buildEntityContext(entitiesByType);

    // 4. 如果超出限制，进行智能压缩
    if (context.length > this.ASK_CONFIG.MAX_CONTEXT_LENGTH) {
      context = this.compressContext(context, entitiesByType);
    }
    return context;
  }

  /**
   * 构建 ask() 的 LLM prompt
   * 要求 LLM 返回结构化 JSON 格式
   */
  buildAskPrompt(question, context) {
    return `你是一个智能知识助手，基于提供的知识库信息回答用户问题。

# 知识库上下文

${context}

# 用户问题

${question}

# 任务要求

1. 基于上述知识库信息，准确回答用户的问题
2. 如果信息不足以完整回答，请明确说明
3. 列出与问题最相关的实体 ID（从上述知识库中提取）
4. 提供结构化的分析结果，包括关键发现、时间线和深度洞察

# 返回格式

请以 JSON 格式返回，包含以下字段：

\`\`\`json
{
  "answer": "详细的主要答案文本（必填，至少100字的完整回答）",
  "structuredAnswer": {
    "summary": "简要总结（1-2句话概括核心要点）",
    "keyFindings": [
      "关键发现1：具体的发现或结论",
      "关键发现2：重要的信息点"
    ],
    "timeline": [
      {"date": "相对时间描述（如：2小时前、昨天）", "event": "发生的事件描述"},
      {"date": "时间", "event": "事件"}
    ],
    "insights": [
      "深度洞察1：基于数据的分析和见解",
      "深度洞察2：趋势、模式或建议"
    ]
  },
  "relatedEntityIds": {
    "topics": ["topic_id_1", "topic_id_2"],
    "people": ["person_id_1"],
    "projects": ["project_id_1"],
    "jiraTickets": [],
    "organizations": [],
    "documents": [],
    "technologies": []
  }
}
\`\`\`

注意：
- answer 必须是完整、连贯的主要回答（这是用户最先看到的内容）
- structuredAnswer 是可选的增强信息，只在有足够信息时提供
  - summary: 用一两句话概括核心要点
  - keyFindings: 提炼2-5个关键发现，每个发现要具体明确
  - timeline: 如果问题涉及时间相关的事件，提供时间线（可选）
  - insights: 提供2-4个深度洞察，包括趋势分析、模式识别或可行建议
- relatedEntityIds 只包含与答案直接相关的实体 ID（必须是上述知识库中存在的ID）
- 如果某个类型没有相关实体，使用空数组 []
- 请确保返回的是有效的 JSON 格式`;
  }

  // ==================== 存储接口 ====================

  /**
   * 存储实体（先云端后本地）
   */
  async storeEntity(entity) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const startTime = Date.now();
    const result = {
      success: false,
      entityId: '',
      cloudStored: false,
      localCached: false,
      relationshipsCreated: 0,
      processingTime: 0,
      errors: []
    };
    try {
      // 构建完整实体
      const fullEntity = {
        ...entity,
        id: '',
        created: Date.now(),
        updated: Date.now(),
        accessCount: 0,
        lastAccessed: Date.now()
      };

      // 1. 先存储到云端
      let attempts = 0;
      while (attempts < this.config.retryAttempts) {
        try {
          const entityId = await this.cloudStorage.storeEntity(fullEntity);
          if (entityId) {
            fullEntity.id = entityId;
            result.entityId = entityId;
            result.cloudStored = true;
            break;
          }
        } catch (error) {
          console.warn(`云端存储尝试 ${attempts + 1} 失败:`, error);
          if (attempts < this.config.retryAttempts - 1) {
            await this.delay(this.config.retryDelay * (attempts + 1));
          }
        }
        attempts++;
      }

      // 2. 更新本地缓存
      try {
        await this.localStorage.cacheEntity(fullEntity);
        result.localCached = true;
      } catch (error) {
        console.warn('本地缓存失败:', error);
        result.errors?.push('本地缓存失败');
      }

      // 确定成功条件
      if (this.config.requireCloudSuccess) {
        result.success = result.cloudStored && result.localCached;
      } else {
        result.success = result.cloudStored || result.localCached;
      }
      result.processingTime = Date.now() - startTime;
      console.log(`💾 实体存储完成: ${result.entityId || fullEntity.id}`, {
        cloudStored: result.cloudStored,
        localCached: result.localCached,
        success: result.success
      });
      return result;
    } catch (error) {
      console.error('存储实体失败:', error);
      result.errors?.push(error.message);
      result.processingTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 存储消息（先云端后本地）- 🆕 统一接口，包含实体关联数据处理
   */
  async storeMessage(messageData) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const startTime = Date.now();
    const result = {
      success: false,
      entityId: messageData.id,
      cloudStored: false,
      localCached: false,
      relationshipsCreated: 0,
      processingTime: 0,
      errors: []
    };
    try {
      // 1. 存储消息到云端（实体数据已包含在metadata中）
      const cloudSuccess = await this.cloudStorage.storeMessage(messageData);
      result.cloudStored = cloudSuccess;

      // 2. 🆕 更新实体关联数据（从metadata中提取实体并更新关联信息）
      if (result.cloudStored) {
        try {
          await this.cloudStorage.updateEntitiesWithRelatedData(messageData.metadata, messageData.id);
          console.log(`🔗 实体关联数据更新完成: ${messageData.id}`);
        } catch (entityError) {
          console.error('🚨 更新实体关联数据失败:', entityError);
          result.errors?.push(`Entity update failed: ${entityError.message}`);
          // 不影响整体存储成功状态，仅记录错误
        }
      }
      result.success = result.cloudStored;
      result.processingTime = Date.now() - startTime;

      // 3. 同时更新用户画像
      if (result.success && this.userProfileManager && messageData.metadata?.entities) {
        try {
          // 将实体对象转换为数组格式
          const entitiesArray = this.cloudStorage.extractEntitiesFromMetadata(messageData.metadata, messageData.id);
          if (entitiesArray.length > 0) {
            // 根据消息匹配规则智能推断actionType
            const actionType = this.inferActionTypeFromMessageData(messageData);
            await this.updateUserProfileFromEntities(entitiesArray, {
              actionType,
              timestamp: Date.now(),
              context: 'message_analysis',
              metadata: {
                messageId: messageData.id,
                sender: messageData.metadata?.sender || 'unknown',
                matchedRules: messageData.metadata?.matchedRules,
                groupName: messageData.metadata?.groupName
              }
            });
          }
        } catch (profileError) {
          console.error('⚠️ 更新用户画像失败:', profileError);
          result.errors?.push(`Profile update failed: ${profileError.message}`);
          // 不影响整体存储成功状态，仅记录错误
        }
      }
      console.log(`✅ 消息完整存储完成: ${messageData.id}, 成功: ${result.success ? '✅' : '❌'}, 处理时间: ${result.processingTime}ms`);
      return result;
    } catch (error) {
      console.error('存储消息失败:', error);
      result.errors?.push(error.message);
      result.processingTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 存储网页数据
   */
  async storeWebpage(webpageData) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const startTime = Date.now();
    const result = {
      success: false,
      entityId: webpageData.id,
      cloudStored: false,
      localCached: false,
      relationshipsCreated: 0,
      processingTime: 0,
      errors: []
    };
    try {
      // 1. 存储网页到云端
      const cloudSuccess = await this.cloudStorage.storeWebpage(webpageData);
      result.cloudStored = cloudSuccess;

      // 2. 处理实体（如果有）
      if (webpageData.entities && webpageData.entities.length > 0) {
        for (const entityData of webpageData.entities) {
          const entityResult = await this.storeEntity(entityData);
          if (entityResult.success) {
            result.relationshipsCreated++;

            // 更新相关实体的最近数据缓存
            await this.localStorage.updateRecentData(entityResult.entityId, 'webpage', {
              id: webpageData.id,
              title: webpageData.title,
              url: webpageData.url,
              summary: webpageData.content.substring(0, 200),
              visitTime: Date.now(),
              domain: new URL(webpageData.url).hostname
            });
          }
        }
      }
      result.success = result.cloudStored;
      result.processingTime = Date.now() - startTime;

      // 同时更新用户画像
      if (result.success && this.userProfileManager && webpageData.entities) {
        await this.updateUserProfileFromEntities(webpageData.entities, {
          actionType: 'view',
          timestamp: Date.now(),
          context: 'webpage_analysis',
          metadata: {
            webpageId: webpageData.id,
            url: webpageData.url,
            title: webpageData.title,
            domain: new URL(webpageData.url).hostname
          }
        });
      }
      return result;
    } catch (error) {
      console.error('存储网页失败:', error);
      result.errors?.push(error.message);
      result.processingTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 更新实体（同步更新本地和云端）
   */
  async updateEntity(entityId, updates) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const startTime = Date.now();
    const result = {
      success: false,
      entityId,
      cloudStored: false,
      localCached: false,
      relationshipsCreated: 0,
      processingTime: 0,
      errors: []
    };
    try {
      // 添加更新时间
      const updatedData = {
        ...updates,
        updated: Date.now()
      };

      // 1. 更新云端
      const cloudSuccess = await this.cloudStorage.updateEntity(entityId, updatedData);
      result.cloudStored = cloudSuccess;

      // 2. 更新本地缓存
      const localEntity = await this.localStorage.getEntity(entityId);
      if (localEntity) {
        const updatedEntity = {
          ...localEntity,
          ...updatedData
        };

        // 🆕 同步更新 recentDataDetails.conversations
        // 保留策略：所有未读消息 + 最新5条已读消息
        if (updatedData.relatedData?.conversations) {
          const mergedConversations = this.mergeAndSortConversations(localEntity.recentDataDetails?.conversations || [], updatedData.relatedData.conversations);
          updatedEntity.recentDataDetails = {
            ...(updatedEntity.recentDataDetails || {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }),
            conversations: mergedConversations // 已在 mergeAndSortConversations 中应用保留策略
          };
        }
        await this.localStorage.cacheEntity(updatedEntity);
        result.localCached = true;
      }
      result.success = result.cloudStored || result.localCached;
      result.processingTime = Date.now() - startTime;
      return result;
    } catch (error) {
      console.error('更新实体失败:', error);
      result.errors?.push(error.message);
      result.processingTime = Date.now() - startTime;
      return result;
    }
  }

  /**
   * 删除实体（同步删除本地和云端）
   */
  async deleteEntity(entityId) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      // 并行删除云端和本地
      const [cloudSuccess, localSuccess] = await Promise.allSettled([this.cloudStorage.deleteEntity(entityId), this.removeFromLocalCache(entityId)]);
      return cloudSuccess.status === 'fulfilled' && cloudSuccess.value || localSuccess.status === 'fulfilled' && localSuccess.value;
    } catch (error) {
      console.error('删除实体失败:', error);
      return false;
    }
  }

  /**
   * 批量存储实体
   */
  async batchStoreEntities(entities) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    const results = [];
    let successCount = 0;
    let failedCount = 0;

    // 分批处理
    const batches = this.chunkArray(entities, this.config.maxSyncBatchSize);
    for (const batch of batches) {
      const batchPromises = batch.map(entity => this.storeEntity(entity));
      const batchResults = await Promise.allSettled(batchPromises);
      for (const settledResult of batchResults) {
        if (settledResult.status === 'fulfilled') {
          const result = settledResult.value;
          results.push(result);
          if (result.success) {
            successCount++;
          } else {
            failedCount++;
          }
        } else {
          failedCount++;
          results.push({
            success: false,
            entityId: `failed_${Date.now()}`,
            cloudStored: false,
            localCached: false,
            relationshipsCreated: 0,
            processingTime: 0,
            errors: [settledResult.reason?.message || '未知错误']
          });
        }
      }
    }
    return {
      success: successCount,
      failed: failedCount,
      results
    };
  }

  // ==================== 缓存管理接口 ====================

  /**
   * 更新实体的最近数据缓存
   */
  async updateRecentData(entityId, type, data) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.localStorage.updateRecentData(entityId, type, data);
  }

  /**
   * 🆕 同步实体类型统计数据到本地缓存
   */
  async syncEntityCountsToCache(entities) {
    try {
      // 统计各类型实体数量
      const entityCounts = {
        'Person': 0,
        'Project': 0,
        'Task': 0,
        'Organization': 0,
        'Document': 0,
        'Technology': 0,
        'Topic': 0
      };

      // 遍历实体并统计
      entities.forEach(entity => {
        if (Object.prototype.hasOwnProperty.call(entityCounts, entity.type)) {
          entityCounts[entity.type]++;
        } else {
          // 如果有新的类型，也记录下来
          entityCounts[entity.type] = (entityCounts[entity.type] || 0) + 1;
        }
      });

      // 保存到本地缓存
      const statistics = {
        entityCounts,
        lastUpdated: Date.now(),
        totalEntities: entities.length
      };
      await chrome.storage.local.set({
        'cache_statistics': statistics
      });
      console.log(`📊 实体统计数据已缓存:`, entityCounts);
    } catch (error) {
      console.error('📊 同步实体统计数据失败:', error);
    }
  }

  /**
   * 清理过期缓存
   */
  async clearExpiredCache() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.localStorage.clearExpiredCache();
  }

  /**
   * 强制同步缓存
   */
  async syncCache() {
    if (this.isSyncing) {
      console.log('⏭️ 同步程序还在进行，跳过本次同步');
      return;
    }
    this.isSyncing = true;
    console.log('🔄 执行定时同步...');
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      console.log('🔄 开始同步缓存...');

      // 执行云端到本地单向同步
      await this.performCloudToLocalSync();

      // 上传本地统计信息到云端
      await this.uploadLocalStatisticsToCloud();

      // 上传本地已读状态到云端
      await this.uploadLocalReadStatusToCloud();

      // 清理过期缓存
      await this.localStorage.clearExpiredCache();

      // 更新最后同步时间
      await chrome.storage.local.set({
        'cache_last_sync_time': Date.now()
      });
      console.log('✅ 缓存同步完成');
    } catch (error) {
      console.error('❌ 缓存同步失败:', error);
    }
    this.isSyncing = false;
  }

  /**
   * 新设备初始同步
   */
  async performInitialSyncIfNeeded() {
    const result = {
      isNewDevice: false,
      syncPerformed: false,
      entitiesDownloaded: 0,
      relationshipsRestored: 0
    };
    try {
      // 检查是否是新设备
      const lastSyncData = await chrome.storage.local.get(['cache_last_sync_time', 'cache_device_initialized']);
      const isNewDevice = !lastSyncData.cache_device_initialized;
      result.isNewDevice = isNewDevice;
      if (isNewDevice) {
        console.log('🆕 检测到新设备，开始初始同步...');

        // 从云端拉取实体
        const {
          data: cloudEntities
        } = await this.cloudStorage.queryEntities();
        result.entitiesDownloaded = cloudEntities.length;
        if (cloudEntities.length > 0) {
          await this.localStorage.batchCacheEntities(cloudEntities);
        }

        // 恢复关系数据
        const relationshipData = await this.cloudStorage.restoreRelationships();
        if (relationshipData) {
          await this.localStorage.restoreRelationshipData(relationshipData);
          result.relationshipsRestored = relationshipData.relationships.length;
        }

        // 标记设备已初始化
        await chrome.storage.local.set({
          cache_device_initialized: true,
          cache_last_sync_time: Date.now()
        });
        result.syncPerformed = true;
        console.log(`✅ 新设备初始同步完成: ${result.entitiesDownloaded} 个实体, ${result.relationshipsRestored} 个关系`);
      }
      return result;
    } catch (error) {
      console.error('新设备初始同步失败:', error);
      return result;
    }
  }

  /**
   * 备份关系数据到云端
   */
  async backupRelationships() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      // 获取本地关系数据
      const relationshipData = await this.localStorage.getRelationshipBackupData();
      if (!relationshipData) {
        console.log('⚠️ 没有关系数据需要备份');
        return false;
      }
      return await this.cloudStorage.backupRelationships(relationshipData);
    } catch (error) {
      console.error('备份关系数据失败:', error);
      return false;
    }
  }

  /**
   * 创建实体关系
   */
  async createRelationship(relationship) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      const fullRelationship = {
        id: `rel_${relationship.fromId}_${relationship.toId}_${relationship.type}_${Date.now()}`,
        type: relationship.type,
        fromId: relationship.fromId,
        toId: relationship.toId,
        properties: relationship.properties || {},
        strength: relationship.strength || 0.7,
        created: Date.now(),
        updated: Date.now()
      };
      await this.localStorage.cacheRelationship(fullRelationship);
      return true;
    } catch (error) {
      console.error('创建关系失败:', error);
      return false;
    }
  }

  /**
   * 实体时间轴
   */
  async getEntityTimeline(entityId, options) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }

    // 这里可以根据需要实现时间轴逻辑
    // 目前返回空数组，可以根据实际需求扩展
    return [];
  }

  /**
   * 获取系统状态
   */
  async getSystemStatus() {
    return {
      isInitialized: this.isInitialized,
      cloudConnected: await this.cloudStorage.isConnected(),
      localCacheSize: await this.localStorage.getCacheSize(),
      lastSyncTime: await this.getLastSyncTime(),
      performance: await this.getPerformanceMetrics()
    };
  }

  // ==================== 实体相似性管理接口 ====================

  /**
   * 处理实体相似性检测
   */
  async processEntitySimilarity(entity) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.entitySimilarityTool.processEntity(entity);
  }

  /**
   * 批量处理实体相似性
   */
  async processEntitiesSimilarity(entities) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.entitySimilarityTool.processEntities(entities);
  }

  /**
   * 获取待处理的实体合并候选
   */
  async getPendingEntityMerges() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.entitySimilarityTool.getPendingMerges();
  }

  /**
   * 确认实体合并
   */
  async confirmEntityMerge(mergeId) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.entitySimilarityTool.confirmMerge(mergeId);
  }

  /**
   * 拒绝实体合并
   */
  async rejectEntityMerge(mergeId) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.entitySimilarityTool.rejectMerge(mergeId);
  }

  /**
   * 获取实体相似性统计
   */
  getEntitySimilarityStats() {
    return this.entitySimilarityTool.getStatistics();
  }

  // ==================== 系统维护接口 ====================

  /**
   * 执行系统健康检查
   */
  async performHealthCheck() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.systemMaintenanceTool.performHealthCheck();
  }

  /**
   * 执行完整系统维护
   */
  async performSystemMaintenance(options) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.systemMaintenanceTool.performFullMaintenance(options);
  }

  /**
   * 🆕 单独清理实体的过期已读消息
   * @param entityId 可选，指定实体ID；不指定则清理所有实体
   */
  async cleanExpiredConversations(entityId) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    return this.cloudStorage.cleanExpiredReadConversations(entityId);
  }

  /**
   * 获取维护工具状态
   */
  getMaintenanceStatus() {
    return this.systemMaintenanceTool.getSystemStatus();
  }

  // ==================== 用户画像接口 ====================

  /**
   * 获取用户画像
   */
  async getUserProfile() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      return {
        profile: null,
        analysis: null
      };
    }
    try {
      const profile = await this.userProfileManager.getProfile();
      const analysis = await this.userProfileManager.generateAnalysis();
      return {
        profile,
        analysis
      };
    } catch (error) {
      console.error('获取用户画像失败:', error);
      return {
        profile: null,
        analysis: null
      };
    }
  }

  /**
   * 更新用户画像
   */
  async updateUserProfile(update) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      console.warn('用户画像管理器未初始化');
      return false;
    }
    try {
      await this.userProfileManager.updateProfile(update);
      return true;
    } catch (error) {
      console.error('更新用户画像失败:', error);
      return false;
    }
  }

  /**
   * 设置用户明确重要性
   */
  async setUserExplicitImportance(itemId, type, importance) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      return false;
    }
    try {
      await this.userProfileManager.setExplicitImportance(itemId, type, importance);
      return true;
    } catch (error) {
      console.error('设置用户重要性失败:', error);
      return false;
    }
  }

  /**
   * 应用用户画像权重衰变
   */
  async applyUserProfileDecay() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (this.userProfileManager) {
      await this.userProfileManager.applyWeightDecay();
    }
  }

  /**
   * 🆕 融合用户上下文配置到用户画像
   */
  async fuseUserContextConfig(userContextConfig) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      return false;
    }
    try {
      const success = await this.userProfileManager.fuseUserContextConfig(userContextConfig);
      if (success) {
        // 融合成功后执行自适应权重调整
        await this.userProfileManager.adaptiveWeightAdjustment();
      }
      return success;
    } catch (error) {
      console.error('融合用户上下文配置失败:', error);
      return false;
    }
  }

  /**
   * 🆕 执行权重自适应调整
   */
  async adaptiveWeightAdjustment() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (this.userProfileManager) {
      try {
        await this.userProfileManager.adaptiveWeightAdjustment();
      } catch (error) {
        console.error('权重自适应调整失败:', error);
      }
    }
  }

  /**
   * 🆕 生成主动推荐内容
   */
  async generateProactiveRecommendations() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      return [];
    }
    try {
      return await this.userProfileManager.generateProactiveRecommendations();
    } catch (error) {
      console.error('生成主动推荐失败:', error);
      return [];
    }
  }

  /**
   * 🆕 获取融合后的用户画像
   * 返回应用了加权融合算法的兴趣列表
   */
  async getFusedUserProfile() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    if (!this.userProfileManager) {
      return {
        profile: null,
        analysis: null,
        fusedInterests: null
      };
    }
    try {
      const {
        profile,
        analysis
      } = await this.getUserProfile();
      if (!profile) {
        return {
          profile: null,
          analysis: null,
          fusedInterests: null
        };
      }

      // 应用加权融合算法到各个兴趣类别
      const fusedInterests = {
        projects: this.userProfileManager.getFusedInterestItems(profile.interests.projects || []),
        people: this.userProfileManager.getFusedInterestItems(profile.interests.people || []),
        topics: this.userProfileManager.getFusedInterestItems(profile.interests.topics || []),
        jiraTickets: this.userProfileManager.getFusedInterestItems(profile.interests.jiraTickets || []),
        technologies: this.userProfileManager.getFusedInterestItems(profile.interests.technologies || []),
        documents: this.userProfileManager.getFusedInterestItems(profile.interests.documents || [])
      };
      return {
        profile: {
          ...profile,
          interests: fusedInterests
        },
        analysis,
        fusedInterests
      };
    } catch (error) {
      console.error('获取融合用户画像失败:', error);
      return {
        profile: null,
        analysis: null,
        fusedInterests: null
      };
    }
  }

  /**
   * 🆕 存储独立用户配置到云端
   */
  async storeIndependentUserConfig(config) {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      const success = await this.cloudStorage.storeIndependentUserConfig(config);
      return success;
    } catch (error) {
      console.error('存储独立用户配置失败:', error);
      return false;
    }
  }

  /**
   * 🆕 获取独立用户配置
   */
  async getIndependentUserConfig() {
    const success = await this.initialize();
    if (!success) {
      throw new Error('记忆系统初始化失败');
    }
    try {
      const config = await this.cloudStorage.getIndependentUserConfig();
      return config;
    } catch (error) {
      console.error('获取独立用户配置失败:', error);
      return null;
    }
  }

  /**
   * 获取最后同步时间
   */
  async getLastSyncTime() {
    try {
      const result = await chrome.storage.local.get('cache_last_sync_time');
      return result.cache_last_sync_time || 0;
    } catch (error) {
      return 0;
    }
  }

  /**
   * 获取性能指标
   */
  async getPerformanceMetrics() {
    return {
      averageQueryTime: (this.metrics.averageLocalTime + this.metrics.averageCloudTime) / 2,
      cacheHitRate: this.metrics.cacheHitRate
    };
  }

  // ==================== 私有方法 ====================

  /**
   * 启动后台同步 - 现在包含用户画像权重衰变逻辑
   */
  startBackgroundSync() {
    // 防止重复启动
    if (this.backgroundSyncStarted) {
      console.log('⚠️ 后台同步已启动，跳过重复启动');
      return;
    }

    // 检查是否在background script环境中
    const isBackground = typeof ServiceWorkerGlobalScope !== 'undefined' && self instanceof ServiceWorkerGlobalScope;
    if (!isBackground) {
      console.log('⚠️ 非background环境，跳过后台同步启动');
      return;
    }

    // 使用 Chrome alarms API 进行后台同步和权重衰变
    const syncAlarmName = 'memory-system-sync';
    const decayAlarmName = 'user-profile-decay';
    chrome.alarms.clear(syncAlarmName, () => {
      // 创建同步 alarm，每5分钟同步一次
      chrome.alarms.create(syncAlarmName, {
        periodInMinutes: this.config.syncInterval / (60 * 1000)
      });
      console.log(`🔄 后台同步已启动，间隔: ${this.config.syncInterval / (60 * 1000)} 分钟`);
    });
    chrome.alarms.clear(decayAlarmName, () => {
      // 创建权重衰变 alarm，每24小时执行一次
      chrome.alarms.create(decayAlarmName, {
        periodInMinutes: 24 * 60 // 24小时
      });
      console.log(`🧠 用户画像权重衰变已启动，间隔: 24小时`);
    });

    // 标记为已启动
    this.backgroundSyncStarted = true;

    // 在启动定时任务时直接运行一次，但添加防抖
    console.log('🔄 首次执行定时同步...');
    this.syncCache().catch(error => {
      console.error('后台同步失败:', error);
    });

    // 首次执行权重衰变
    console.log('🧠 首次执行权重衰变...');
    this.applyUserProfileDecay().catch(error => {
      console.error('权重衰变失败:', error);
    });

    // 监听 alarm 事件
    this.setupAlarmListener();
  }

  /**
   * 设置 alarm 监听器
   */
  setupAlarmListener() {
    // 避免重复添加监听器
    if (this.alarmListenerAdded) {
      return;
    }
    chrome.alarms.onAlarm.addListener(alarm => {
      if (alarm.name === 'memory-system-sync') {
        console.log('🔄 执行定时同步...');
        this.syncCache().catch(error => {
          console.error('后台同步失败:', error);
        });
      } else if (alarm.name === 'user-profile-decay') {
        console.log('🧠 执行定时权重衰变...');
        this.applyUserProfileDecay().catch(error => {
          console.error('定时权重衰变失败:', error);
        });
      }
    });
    this.alarmListenerAdded = true;
    console.log('🎯 alarm 监听器已设置（同步 + 权重衰变）');
  }

  /**
   * 执行用户画像权重衰变
   */

  /**
   * 清理实体名称，处理中文和特殊字符
   */
  sanitizeEntityName(name) {
    if (!name || name.trim() === '') {
      return 'entity';
    }

    // 简单的中文转拼音映射（部分常用字符）
    const chineseToPinyin = {
      '项目': 'xiangmu',
      '文档': 'wendang',
      '人员': 'renyuan',
      '主题': 'zhuti',
      '任务': 'renwu',
      '团队': 'tuandui',
      '公司': 'gongsi',
      '系统': 'xitong',
      '数据': 'shuju',
      '功能': 'gongneng',
      '需求': 'xuqiu',
      '设计': 'sheji',
      '开发': 'kaifa',
      '测试': 'ceshi',
      '部署': 'bushu',
      '维护': 'weihu',
      '管理': 'guanli',
      '分析': 'fenxi',
      '报告': 'baogao',
      '会议': 'huiyi'
    };
    let cleanName = name.trim();

    // 替换中文词汇为拼音
    for (const [chinese, pinyin] of Object.entries(chineseToPinyin)) {
      cleanName = cleanName.replace(new RegExp(chinese, 'g'), pinyin);
    }

    // 移除其他中文字符（通过Unicode范围）
    cleanName = cleanName.replace(/[\u4e00-\u9fff]/g, '');

    // 只保留字母、数字和连字符
    cleanName = cleanName.replace(/[^a-zA-Z0-9\-_]/g, '');

    // 移除多余的连字符和下划线
    cleanName = cleanName.replace(/[-_]+/g, '_');

    // 移除开头和结尾的连字符和下划线
    cleanName = cleanName.replace(/^[-_]+|[-_]+$/g, '');

    // 限制长度并确保不为空
    if (cleanName.length === 0) {
      cleanName = 'entity';
    } else if (cleanName.length > 20) {
      cleanName = cleanName.substring(0, 20);
    }

    // 确保以字母开头
    if (!/^[a-zA-Z]/.test(cleanName)) {
      cleanName = 'entity_' + cleanName;
    }
    return cleanName.toLowerCase();
  }
  async queryFromLocal(type, searchTerm) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    if (type) {
      return this.localStorage.queryEntitiesByType(type, options);
    } else if (searchTerm) {
      return this.localStorage.searchEntities(searchTerm, type, options);
    } else {
      // 返回所有实体（分页）
      return {
        data: [],
        total: 0,
        source: 'local',
        cached: true,
        queryTime: 0
      };
    }
  }
  async queryFromCloud(type, searchTerm) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    // 如果有搜索词且长度大于2，使用向量搜索获得更好的语义匹配
    if (searchTerm && searchTerm.length > 2 && !type) {
      // 转换为向量搜索选项
      const vectorOptions = {
        limit: options.limit,
        offset: options.offset,
        useCache: options.useCache,
        includeCounts: options.includeCounts,
        sortBy: options.sortBy === 'relevance' ? 'relevance' : options.sortBy === 'importance' ? 'importance' : 'relevance',
        sortOrder: options.sortOrder
      };
      return this.cloudStorage.searchByVector(searchTerm, type, vectorOptions);
    }

    // 使用新的云端实体查询接口，支持按type过滤
    return this.cloudStorage.queryEntities(type, searchTerm, options);
  }
  async cacheCloudResults(entities) {
    try {
      if (entities.length > 0) {
        await this.localStorage.batchCacheEntities(entities);
      }
    } catch (error) {
      console.error('缓存云端结果失败:', error);
    }
  }
  async removeFromLocalCache(entityId) {
    try {
      await chrome.storage.local.remove(`cache_entities_${entityId}`);
      // 这里还需要更新索引等，但为了简化暂时省略
      return true;
    } catch (error) {
      console.error('从本地缓存删除失败:', error);
      return false;
    }
  }
  updateMetrics(source, queryTime) {
    if (source === 'local' || source === 'hybrid') {
      this.metrics.localHits++;
      this.metrics.averageLocalTime = (this.metrics.averageLocalTime * (this.metrics.localHits - 1) + queryTime) / this.metrics.localHits;
    }
    if (source === 'cloud' || source === 'hybrid') {
      this.metrics.cloudHits++;
      this.metrics.averageCloudTime = (this.metrics.averageCloudTime * (this.metrics.cloudHits - 1) + queryTime) / this.metrics.cloudHits;
    }

    // 更新缓存命中率
    this.metrics.cacheHitRate = this.metrics.localHits / this.metrics.totalQueries;
  }
  async loadConfig() {
    try {
      const result = await chrome.storage.local.get('cache_strategy_config');
      if (result.cache_strategy_config) {
        this.config = {
          ...this.config,
          ...result.cache_strategy_config
        };
      }
    } catch (error) {
      console.warn('加载缓存策略配置失败，使用默认配置');
    }
  }
  async loadMetrics() {
    try {
      const result = await chrome.storage.local.get('cache_strategy_metrics');
      if (result.cache_strategy_metrics) {
        this.metrics = {
          ...this.metrics,
          ...result.cache_strategy_metrics
        };
      }
    } catch (error) {
      console.warn('加载性能指标失败，使用默认值');
    }
  }
  async delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

  /**
   * 从缓存扩展实体信息：直接合并缓存数据（简化版）
   */
  async extendEntitiesFromCache(entities) {
    const extendedEntities = [];
    for (const entity of entities) {
      const extendedEntity = {
        ...entity,
        cachedAt: Date.now(),
        // 初始化必要的数组字段
        recentDataDetails: {
          conversations: [],
          webpages: [],
          resources: [],
          projects: [],
          people: [],
          topics: [],
          jiraTickets: [],
          cooccurringEntities: []
        },
        relatedParticipants: []
      };
      try {
        // 获取扩展缓存数据
        const cacheData = await this.localStorage.getEntity(entity.id);
        if (cacheData) {
          // 直接合并缓存数据到实体对象
          Object.assign(extendedEntity, cacheData);
        } else {
          // 没有缓存数据时，设置默认值  
          this.setDefaultExtendedFields(extendedEntity, entity);
        }
      } catch (error) {
        console.error(`扩展实体 ${entity.id} 信息失败:`, error);
        // 设置默认值
        this.setDefaultExtendedFields(extendedEntity, entity);
      }
      extendedEntities.push(extendedEntity);
    }
    return extendedEntities;
  }

  /**
   * 设置扩展字段的默认值
   */
  setDefaultExtendedFields(extendedEntity, entity) {
    // 设置必要的数组字段默认值
    if (!extendedEntity.recentDataDetails) {
      extendedEntity.recentDataDetails = {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      };
    }

    // 确保统计字段存在
    if (!extendedEntity.statistic) {
      extendedEntity.statistic = {
        conversations: 0,
        projects: 0,
        participants: 1,
        resources: 0,
        documents: 0,
        webpages: 0,
        relationships: entity.properties?.relationshipsCount || 0,
        topics: 0,
        jiraTickets: 0
      };
    }

    // 根据实体类型设置特定默认值
    if (entity.type === 'Person') {
      extendedEntity.role = entity.properties?.role || '团队成员';
      extendedEntity.team = entity.properties?.team || '';
      extendedEntity.expertise = entity.properties?.expertise || entity.tags || [];
    }
    if (entity.type === 'Project') {
      extendedEntity.isHighlighted = entity.properties?.isHighlighted || false;
    }
  }

  /**
   * 执行云端到本地单向同步 - 只从云端拉取数据到本地缓存
   */
  async performCloudToLocalSync() {
    try {
      const lastSyncData = await chrome.storage.local.get('cache_last_sync_time');
      const lastSyncTime = lastSyncData.cache_last_sync_time || 0;

      // 如果距离上次同步不足5分钟，跳过同步
      if (Date.now() - lastSyncTime < 5 * 60 * 1000) {
        console.log('⏭️ 距离上次单向同步不足5分钟，跳过');
        return;
      }
      console.log('📥 开始云端到本地单向同步...');
      let syncedEntities = 0;
      let recentDataUpdated = 0;

      // 1. 从云端拉取所有实体
      const {
        data: cloudEntities
      } = await this.cloudStorage.queryEntities();

      // 2. 批量同步云端实体到本地
      const cloudBatches = this.chunkArray(cloudEntities, 20); // 每批最多20个
      const entitiesToUpdate = [];
      for (const batch of cloudBatches) {
        for (const entity of batch) {
          const localEntity = await this.localStorage.getEntity(entity.id);
          if (!localEntity || localEntity.updated < entity.updated) {
            // 🔄 缓存实体到本地
            await this.localStorage.cacheEntity(entity);
            syncedEntities++;
            entitiesToUpdate.push(entity);
          }
        }

        // 批间延迟，避免阻塞
        if (cloudBatches.length > 1) {
          await this.delay(100);
        }
      }

      // 3. 🆕 关联数据现在直接存储在 MemoryEntity.relatedData 中，无需单独同步关系
      console.log(`📊 实体关联数据已通过 MemoryEntity.relatedData 同步，无需额外关系处理`);
      if (entitiesToUpdate.length > 0) {
        recentDataUpdated = entitiesToUpdate.length;
      }

      // 4. 🆕 统计所有实体类型的数量并缓存到本地
      await this.syncEntityCountsToCache(cloudEntities);
      console.log(`✅ 单向同步完成: 同步了${syncedEntities}个实体，更新了${recentDataUpdated}个实体的最近数据缓存`);
    } catch (error) {
      console.error('❌ 云端到本地同步失败:', error);
    }
  }

  /**
   * 上传本地统计信息到云端
   */
  async uploadLocalStatisticsToCloud() {
    try {
      console.log('📊 开始上传本地统计信息到云端...');

      // 获取所有本地缓存的实体
      const recentDataEntries = await this.localStorage.getAllRecentDataEntries();
      if (!recentDataEntries || recentDataEntries.length === 0) {
        console.log('📊 没有本地统计信息需要上传');
        return;
      }

      // 收集需要更新的统计信息
      const statisticsUpdates = [];
      for (const entry of recentDataEntries) {
        try {
          // 计算当前统计信息
          const updatedStatistic = entry.statistic;
          statisticsUpdates.push({
            entityId: entry.id,
            statistic: updatedStatistic,
            lastUpdated: entry.lastUpdated || Date.now()
          });
        } catch (error) {
          console.error(`处理实体 ${entry.id} 统计信息失败:`, error);
        }
      }
      if (statisticsUpdates.length === 0) {
        console.log('📊 没有有效的统计信息需要上传');
        return;
      }

      // 批量更新云端实体的统计信息
      await this.cloudStorage.batchUpdateEntityStatistics(statisticsUpdates);
      console.log(`📊 成功上传 ${statisticsUpdates.length} 个实体的统计信息`);
    } catch (error) {
      console.error('📊 上传统计信息失败:', error);
    }
  }

  /**
   * 上传本地已读状态到云端
   */
  async uploadLocalReadStatusToCloud() {
    try {
      console.log('📖 开始上传本地已读状态到云端...');

      // 获取所有本地缓存的实体
      const recentDataEntries = await this.localStorage.getAllRecentDataEntries();
      if (!recentDataEntries || recentDataEntries.length === 0) {
        console.log('📖 没有本地已读状态需要上传');
        return;
      }

      // 收集需要更新的已读状态（只处理有 readStatus 的实体）
      const readStatusUpdates = [];
      for (const entry of recentDataEntries) {
        try {
          // 只上传有 readStatus 的实体（通常是 Topic 类型）
          if (entry.readStatus) {
            readStatusUpdates.push({
              entityId: entry.id,
              readStatus: entry.readStatus
            });
          }
        } catch (error) {
          console.error(`处理实体 ${entry.id} 已读状态失败:`, error);
        }
      }
      if (readStatusUpdates.length === 0) {
        console.log('📖 没有有效的已读状态需要上传');
        return;
      }

      // 批量更新云端实体的已读状态
      await this.cloudStorage.batchUpdateEntityReadStatus(readStatusUpdates);
      console.log(`📖 成功上传 ${readStatusUpdates.length} 个实体的已读状态`);
    } catch (error) {
      console.error('📖 上传已读状态失败:', error);
    }
  }

  /**
   * 初始化用户画像管理器
   */
  async initializeUserProfile() {
    try {
      // 重用现有的 CloudStorage 实例，避免重复初始化
      // UserProfileManager 现在会在 initialize() 时自动获取用户信息
      this.userProfileManager = new UserProfileManager/* UserProfileManager */.e(undefined, this.cloudStorage);
      await this.userProfileManager.initialize();
      console.log('✅ 用户画像管理器初始化成功');
    } catch (error) {
      console.error('❌ 用户画像管理器初始化失败:', error);
      // 不要抛出异常，允许记忆系统继续运行
    }
  }

  /**
   * 根据消息数据智能推断用户行为类型
   */
  inferActionTypeFromMessageData(messageData) {
    // 优先使用LLM分析提供的用户关系类型
    const userRelationType = messageData.metadata?.user_relation_type;
    if (userRelationType) {
      return this.mapUserRelationTypeToActionType(userRelationType);
    }
    const matchedRules = messageData.metadata?.matchedRules || [];
    const sender = messageData.metadata?.sender || '';
    const messageContent = messageData.content || '';

    // 检查是否明确提到用户
    const mentionKeywords = ['@我', '@你', '提到我', '需要你', '你来', '你的'];
    const hasMention = mentionKeywords.some(keyword => messageContent.includes(keyword));
    if (hasMention) {
      return 'mention';
    }

    // 根据匹配规则推断行为类型
    for (const rule of matchedRules) {
      const lowerRule = rule.toLowerCase();

      // 项目相关消息 - 通常是查看项目进展
      if (lowerRule.includes('recording') || lowerRule.includes('project') || lowerRule.includes('dependencies')) {
        return 'view';
      }

      // 政策消息 - 通常需要关注/查看
      if (lowerRule.includes('政策') || lowerRule.includes('policy') || lowerRule.includes('规定')) {
        return 'view';
      }

      // 特定人员消息 - 算作查看行为
      if (lowerRule.includes('sophia') || lowerRule.includes('jinmei') || lowerRule.includes('发送的所有消息')) {
        return 'view';
      }

      // 明确@我的消息
      if (lowerRule.includes('@我') || lowerRule.includes('mention')) {
        return 'mention';
      }
    }

    // 默认返回view（浏览/关注）
    return 'view';
  }

  /**
   * 将LLM分析的用户关系类型映射到actionType
   */
  mapUserRelationTypeToActionType(userRelationType) {
    const lowerType = userRelationType.toLowerCase();
    if (lowerType.includes('mention')) {
      return 'mention';
    } else if (lowerType.includes('project_related')) {
      return 'view';
    } else if (lowerType.includes('policy_related')) {
      return 'view';
    } else if (lowerType.includes('person_tracking')) {
      return 'view'; // 改为view而不是social
    } else if (lowerType.includes('general_interest')) {
      return 'view';
    }

    // 默认返回view
    return 'view';
  }

  /**
   * 🆕 合并并排序conversations，保持isRead状态
   * 保留策略：所有未读消息 + 最新5条已读消息
   */
  mergeAndSortConversations(existingConversations, newConversations) {
    const conversationsMap = new Map();

    // 先添加已存在的conversations（保持isRead状态）
    existingConversations.forEach(conv => {
      conversationsMap.set(conv.id, conv);
    });

    // 合并新的conversations
    newConversations.forEach(conv => {
      if (conversationsMap.has(conv.id)) {
        // 已存在的conversation，保持其isRead状态
        const existing = conversationsMap.get(conv.id);
        conversationsMap.set(conv.id, {
          ...conv,
          isRead: existing.isRead !== undefined ? existing.isRead : conv.isRead || false,
          readTimestamp: existing.readTimestamp
        });
      } else {
        // 新conversation
        conversationsMap.set(conv.id, {
          ...conv,
          isRead: conv.isRead !== undefined ? conv.isRead : false
        });
      }
    });

    // 🆕 智能保留策略：保留所有未读 + 最新5条已读
    const unreadConversations = Array.from(conversationsMap.values()).filter(c => !c.isRead);
    const readConversations = Array.from(conversationsMap.values()).filter(c => c.isRead);

    // 保留所有未读 + 补充已读到5条
    const needReadCount = Math.max(0, 5 - unreadConversations.length);
    const finalConversations = [...unreadConversations, ...readConversations.slice(0, needReadCount)];

    // 按时间排序（最新的在前）
    finalConversations.sort((a, b) => {
      const timeA = new Date(a.datetime || 0).getTime();
      const timeB = new Date(b.datetime || 0).getTime();
      return timeB - timeA;
    });
    return finalConversations;
  }

  /**
   * 从实体列表更新用户画像
   */
  async updateUserProfileFromEntities(entities, baseAction) {
    if (!this.userProfileManager) return;
    try {
      for (const entity of entities) {
        // 映射实体类型到用户画像类型
        let profileType;
        switch (entity.type) {
          case 'Person':
            profileType = 'person';
            break;
          case 'Project':
            profileType = 'project';
            break;
          case 'Task':
            profileType = 'jira';
            break;
          case 'Technology':
            profileType = 'technology';
            break;
          case 'Document':
            profileType = 'document';
            break;
          case 'Topic':
          default:
            profileType = 'topic';
            break;
        }

        // 根据实体类型调整权重
        let weight = 0.1; // 默认权重
        switch (profileType) {
          case 'project':
            weight *= 1.5; // 项目权重更高
            break;
          case 'person':
            weight *= 1.3; // 人员权重稍高
            break;
          case 'jira':
            weight *= 1.2; // JIRA 权重稍高
            break;
          default:
            break;
        }
        const action = {
          ...baseAction,
          weight
        };
        await this.userProfileManager.updateProfile({
          userId: this.userProfileManager.userId,
          action,
          targetItem: {
            id: entity.name.replace(/\s+/g, '_').toLowerCase(),
            type: profileType,
            name: entity.name,
            metadata: {
              entityType: entity.type,
              document: entity.document,
              importance: entity.importance,
              tags: entity.tags
            }
          }
        });
      }
    } catch (error) {
      console.error('从实体更新用户画像失败:', error);
    }
  }
}

// 导出单例实例
const memorySystem = new MemorySystem();

/***/ }),

/***/ 9857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   e: () => (/* binding */ UserProfileManager)
/* harmony export */ });
/* harmony import */ var _storage_CloudStorage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8143);
/**
 * 用户画像管理器
 * 负责分散式向量存储的用户画像管理
 */


class UserProfileManager {
  // 5分钟缓存过期

  constructor(userId, cloudStorage) {
    this.displayName = '';
    this.recordsCache = new Map();
    this.lastCacheUpdate = 0;
    this.cacheExpiryTime = 5 * 60 * 1000;
    this.userId = userId || 'default_user'; // 临时默认值，将在initialize中更新
    this.cloudStorage = cloudStorage || new _storage_CloudStorage__WEBPACK_IMPORTED_MODULE_0__/* .CloudStorage */ .f();
  }

  /**
   * 初始化管理器
   */
  async initialize() {
    try {
      // 获取真实的用户信息
      await this.loadUserInfo();

      // 确保CloudStorage已连接
      if (!(await this.cloudStorage.isConnected())) {
        await this.cloudStorage.initialize();
      }

      // 初始化缓存
      await this.refreshCache();
      console.log(`✅ 用户画像管理器初始化成功: ${this.userId} (${this.displayName})`);
      return true;
    } catch (error) {
      console.error('用户画像管理器初始化失败:', error);
      return false;
    }
  }

  /**
   * 从localStorage加载用户信息
   */
  async loadUserInfo() {
    try {
      const result = await chrome.storage.local.get(['userinfo']);
      const userinfo = result.userinfo;
      if (userinfo) {
        // 使用username作为userId，fullName作为显示名
        this.userId = userinfo.username || userinfo.extensionId || 'default_user';
        this.displayName = userinfo.fullName || userinfo.username || 'Unknown User';
        console.log(`📝 用户信息加载成功: ${this.userId} (${this.displayName})`);
      } else {
        console.warn('⚠️ 未找到用户信息，使用默认值');
        this.userId = 'default_user';
        this.displayName = 'Default User';
      }
    } catch (error) {
      console.error('获取用户信息失败:', error);
      // 保持默认值
      this.userId = 'default_user';
      this.displayName = 'Default User';
    }
  }

  /**
   * 更新用户画像（兼容旧接口）
   */
  async updateProfile(update) {
    try {
      // 1. 更新兴趣项
      const interestSuccess = await this.updateInterestItem(update);
      if (!interestSuccess) {
        console.warn(`Failed to update interest item for ${update.targetItem.name}`);
      }

      // 2. 更新行为模式
      await this.updateBehaviorPattern({
        userId: update.userId,
        actionType: update.action.actionType,
        timestamp: update.action.timestamp,
        context: update.action.context || '',
        targetType: update.targetItem.type,
        targetId: update.targetItem.id
      });

      // 3. 更新统计数据（通过行为记录自动统计）
      await this.updateUserStatistics(update.action);

      // 4. 重新计算衍生偏好（基于最新的向量化数据）
      await this.recalculateDerivedPreferences();
      console.log(`✅ Profile updated successfully for ${update.targetItem.name}`);
    } catch (error) {
      console.error('Failed to update profile:', error);
      throw new Error(`Failed to update profile for ${update.targetItem.name}: ${error.message}`);
    }
  }

  /**
   * 更新用户统计数据
   */
  async updateUserStatistics(action) {
    try {
      const statsRecordId = `${this.userId}_user_summary_statistics`;

      // 查找现有统计记录
      let existingStats = this.recordsCache.get(statsRecordId);
      if (!existingStats) {
        // 尝试从云端获取
        const queryResult = await this.cloudStorage.searchByVector('user statistics', undefined, {
          collections: ['userprofiles'],
          returnType: 'userprofiles',
          where: {
            user_id: this.userId,
            record_type: {
              $in: ['user_summary']
            },
            summary_type: 'statistics'
          },
          limit: 1
        });
        if (queryResult.data.length > 0) {
          existingStats = queryResult.data[0];
          this.recordsCache.set(statsRecordId, existingStats);
        }
      }
      if (!existingStats) {
        // 创建新的统计记录
        existingStats = {
          id: statsRecordId,
          document: `用户 ${this.userId} 的统计数据汇总`,
          metadata: {
            record_type: 'user_summary',
            user_id: this.userId,
            created_at: Date.now(),
            updated_at: Date.now(),
            summary_type: 'statistics',
            total_interactions: 1,
            daily_activity_average: 1,
            most_active_day: new Date().toISOString().split('T')[0],
            top_interaction_types: {
              [action.actionType]: 1
            },
            last_activity: action.timestamp
          }
        };
      } else {
        // 更新统计数据
        const metadata = existingStats.metadata;
        metadata.total_interactions = (metadata.total_interactions || 0) + 1;
        metadata.updated_at = Date.now();
        metadata.last_activity = action.timestamp;

        // 更新交互类型统计
        const topTypes = metadata.top_interaction_types || {};
        topTypes[action.actionType] = (topTypes[action.actionType] || 0) + 1;
        metadata.top_interaction_types = topTypes;

        // 计算日平均活动
        const daysSinceCreated = Math.max(1, Math.floor((Date.now() - metadata.created_at) / (24 * 60 * 60 * 1000)));
        metadata.daily_activity_average = metadata.total_interactions / daysSinceCreated;

        // 更新文档描述
        existingStats.document = `用户 ${this.userId} 的统计数据汇总：总交互${metadata.total_interactions}次，日均活动${metadata.daily_activity_average.toFixed(1)}次`;
      }

      // 存储更新后的统计记录
      await this.cloudStorage.storeUserprofilesRecord(existingStats);
      this.recordsCache.set(statsRecordId, existingStats);
    } catch (error) {
      console.error('Failed to update user statistics:', error);
    }
  }

  /**
   * 重新计算衍生偏好
   */
  async recalculateDerivedPreferences() {
    try {
      const preferencesRecordId = `${this.userId}_user_summary_preferences`;

      // 获取用户的所有兴趣项记录
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item' && record.metadata.user_id === this.userId);
      if (interestRecords.length === 0) return;

      // 分析偏好项目类型
      const projectTypes = new Map();
      const expertiseAreas = new Map();
      const collaborators = new Map();
      interestRecords.forEach(record => {
        const metadata = record.metadata;

        // 统计项目类型偏好
        if (metadata.interest_category === 'project' && metadata.project_type) {
          projectTypes.set(metadata.project_type, (projectTypes.get(metadata.project_type) || 0) + metadata.current_weight);
        }

        // 统计专业领域
        if (metadata.interest_category === 'technology' && metadata.technology_stack) {
          metadata.technology_stack.forEach(tech => {
            expertiseAreas.set(tech, (expertiseAreas.get(tech) || 0) + metadata.current_weight);
          });
        }

        // 统计协作者
        if (metadata.interest_category === 'person') {
          collaborators.set(metadata.name, (collaborators.get(metadata.name) || 0) + metadata.current_weight);
        }
      });

      // 生成偏好记录
      const preferencesRecord = {
        id: preferencesRecordId,
        document: `用户 ${this.userId} 的衍生偏好分析：` + `偏好项目类型${Array.from(projectTypes.keys()).slice(0, 3).join('、')}，` + `专业领域包括${Array.from(expertiseAreas.keys()).slice(0, 5).join('、')}，` + `主要协作者有${Array.from(collaborators.keys()).slice(0, 3).join('、')}`,
        metadata: {
          record_type: 'user_summary',
          user_id: this.userId,
          created_at: this.recordsCache.get(preferencesRecordId)?.metadata.created_at || Date.now(),
          updated_at: Date.now(),
          summary_type: 'derived_preferences',
          preferred_project_types: Array.from(projectTypes.entries()).sort((a, b) => b[1] - a[1]).slice(0, 5).map(_ref => {
            let [type] = _ref;
            return type;
          }),
          expertise_areas: Array.from(expertiseAreas.entries()).sort((a, b) => b[1] - a[1]).slice(0, 10).map(_ref2 => {
            let [area] = _ref2;
            return area;
          }),
          key_collaborators: Array.from(collaborators.entries()).sort((a, b) => b[1] - a[1]).slice(0, 10).map(_ref3 => {
            let [name] = _ref3;
            return name;
          }),
          risk_sensitivity: this.calculateRiskSensitivity(interestRecords),
          update_frequency: this.calculateUpdateFrequency(interestRecords)
        }
      };

      // 存储偏好记录
      await this.cloudStorage.storeUserprofilesRecord(preferencesRecord);
      this.recordsCache.set(preferencesRecordId, preferencesRecord);
    } catch (error) {
      console.error('Failed to recalculate derived preferences:', error);
    }
  }

  /**
   * 计算风险敏感度
   */
  calculateRiskSensitivity(interestRecords) {
    const totalWeight = interestRecords.reduce((sum, record) => sum + record.metadata.current_weight, 0);
    const diversityScore = new Set(interestRecords.map(r => r.metadata.interest_category)).size;
    if (diversityScore >= 4 && totalWeight > 5) return 'low';
    if (diversityScore >= 2 && totalWeight > 3) return 'medium';
    return 'high';
  }

  /**
   * 计算更新频率模式
   */
  calculateUpdateFrequency(interestRecords) {
    const now = Date.now();
    const recentUpdates = interestRecords.filter(record => now - record.metadata.last_accessed < 7 * 24 * 60 * 60 * 1000).length;
    if (recentUpdates >= 10) return 'daily';
    if (recentUpdates >= 3) return 'weekly';
    return 'monthly';
  }

  /**
   * 更新兴趣项
   */
  async updateInterestItem(update) {
    try {
      const {
        targetItem,
        action
      } = update;
      const recordId = `${this.userId}_interest_${targetItem.type}_${this.sanitizeId(targetItem.id)}`;

      // 查找现有记录
      let existingRecord = this.recordsCache.get(recordId);
      if (!existingRecord) {
        // 尝试从云端获取
        const queryResult = await this.cloudStorage.queryUserprofiles({
          user_id: this.userId,
          record_types: ['interest_item'],
          metadata_filters: {
            name: targetItem.name,
            interest_category: targetItem.type
          }
        });
        if (queryResult.records.length > 0) {
          existingRecord = queryResult.records[0];
          this.recordsCache.set(recordId, existingRecord);
        }
      }
      if (existingRecord) {
        // 更新现有记录
        await this.updateExistingInterestRecord(existingRecord, action);
      } else {
        // 创建新记录
        await this.createNewInterestRecord(recordId, targetItem, action);
      }
      return true;
    } catch (error) {
      console.error('更新兴趣项失败:', error);
      return false;
    }
  }

  /**
   * 更新行为模式
   */
  async updateBehaviorPattern(data) {
    try {
      const recordId = `${this.userId}_behavior_pattern_${data.actionType}_${Date.now()}`;

      // 创建行为模式记录
      const behaviorRecord = {
        id: recordId,
        document: this.generateBehaviorPatternDocument(data),
        metadata: {
          record_type: 'behavior_pattern',
          user_id: this.userId,
          created_at: data.timestamp,
          updated_at: data.timestamp,
          pattern_type: this.getPatternType(data.actionType),
          // 根据行为类型设置相应的元数据
          ...this.getBehaviorSpecificMetadata(data)
        }
      };

      // 存储记录
      await this.cloudStorage.storeUserprofilesRecord(behaviorRecord);
      this.recordsCache.set(recordId, behaviorRecord);
      return true;
    } catch (error) {
      console.error('更新行为模式失败:', error);
      return false;
    }
  }

  /**
   * 查询兴趣项
   */
  async queryInterestItems() {
    let options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    try {
      const {
        category,
        searchQuery = '',
        limit = 20,
        sortBy = 'weight'
      } = options;

      // 构建查询选项
      const queryOptions = {
        user_id: this.userId,
        record_types: ['interest_item'],
        limit
      };
      if (category) {
        queryOptions.metadata_filters = {
          interest_category: category
        };
      }

      // 执行查询
      const result = await this.cloudStorage.searchByVector(searchQuery, undefined, {
        collections: ['userprofiles'],
        returnType: 'userprofiles',
        where: queryOptions.metadata_filters || {},
        limit: queryOptions.limit || 20
      });

      // 类型转换和排序
      const interestRecords = result.data;
      return this.sortInterestItems(interestRecords, sortBy);
    } catch (error) {
      console.error('查询兴趣项失败:', error);
      return [];
    }
  }

  /**
   * 查找相似用户
   */
  async findSimilarUsers() {
    let options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    try {
      const {
        limit = 10,
        similarityThreshold = 0.3
      } = options;

      // 获取用户的主要兴趣描述
      const userInterests = await this.queryInterestItems({
        limit: 10,
        sortBy: 'weight'
      });
      const queryText = userInterests.map(item => item.document).join(' ');
      if (!queryText.trim()) {
        return [];
      }

      // 查找相似用户
      return await this.cloudStorage.findSimilarUsers(this.userId, queryText, {
        record_types: ['interest_item'],
        limit,
        similarity_threshold: similarityThreshold
      });
    } catch (error) {
      console.error('查找相似用户失败:', error);
      return [];
    }
  }

  /**
   * 根据行为模式查找用户
   */
  async findUsersByBehaviorPattern(patternType) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    // 占位符实现，后续可扩展
    return [];
  }

  /**
   * 查找话题相关兴趣
   */
  async findTopicRelatedInterests(topic) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    try {
      const {
        limit = 10
      } = options;
      const result = await this.cloudStorage.searchByVector(topic, undefined, {
        collections: ['userprofiles'],
        returnType: 'userprofiles',
        where: {
          user_id: this.userId,
          record_type: {
            $in: ['interest_item']
          }
        },
        limit
      });
      return result.data;
    } catch (error) {
      console.error('查找话题相关兴趣失败:', error);
      return [];
    }
  }

  /**
   * 生成用户画像分析
   */
  async generateAnalysis() {
    try {
      await this.refreshCacheIfNeeded();
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item');
      const behaviorRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'behavior_pattern');
      const topItemsByCategory = this.getTopItemsByCategory(interestRecords);
      const behaviorAnalysis = this.analyzeBehaviorPatterns(behaviorRecords);
      return {
        userId: this.userId,
        timestamp: Date.now(),
        // 当前最关注的内容
        topInterests: {
          projects: topItemsByCategory.project?.map(item => item.name) || [],
          people: topItemsByCategory.person?.map(item => item.name) || [],
          topics: topItemsByCategory.topic?.map(item => item.name) || []
        },
        // 预测的兴趣
        predictedInterests: this.predictInterests(interestRecords),
        // 行为洞察
        insights: {
          workingPattern: behaviorAnalysis.activeHours?.length > 0 ? `主要活跃时间：${behaviorAnalysis.activeHours.join('、')}点` : '暂无数据',
          collaborationStyle: behaviorAnalysis.communicationStyle || 'semi-formal',
          focusAreas: topItemsByCategory.technology?.map(item => item.name) || [],
          suggestedContent: this.generateContentSuggestions(interestRecords)
        }
      };
    } catch (error) {
      console.error('生成用户画像分析失败:', error);
      throw error;
    }
  }

  /**
   * 获取画像统计信息
   */
  async getProfileStats() {
    try {
      await this.refreshCacheIfNeeded();
      const records = Array.from(this.recordsCache.values());
      const recordsByType = {};
      let lastActivity = 0;
      records.forEach(record => {
        const type = record.metadata.record_type;
        recordsByType[type] = (recordsByType[type] || 0) + 1;
        if (record.metadata.last_accessed && record.metadata.last_accessed > lastActivity) {
          lastActivity = record.metadata.last_accessed;
        }
      });

      // 简单的健康度计算
      const healthScore = Math.min(records.length / 50, 1); // 假设50个记录为满分

      return {
        totalRecords: records.length,
        recordsByType,
        lastActivity,
        healthScore
      };
    } catch (error) {
      console.error('获取画像统计失败:', error);
      return {
        totalRecords: 0,
        recordsByType: {},
        lastActivity: 0,
        healthScore: 0
      };
    }
  }

  /**
   * 刷新缓存
   */
  async refreshCache() {
    try {
      const result = await this.cloudStorage.queryUserprofiles({
        user_id: this.userId,
        limit: 1000 // 获取用户的所有记录
      });
      this.recordsCache.clear();
      result.records.forEach(record => {
        this.recordsCache.set(record.id, record);
      });
      this.lastCacheUpdate = Date.now();
      console.log(`缓存已刷新，加载了 ${result.records.length} 条记录`);
    } catch (error) {
      console.error('刷新缓存失败:', error);
    }
  }

  /**
   * 按需刷新缓存
   */
  async refreshCacheIfNeeded() {
    if (Date.now() - this.lastCacheUpdate > this.cacheExpiryTime) {
      await this.refreshCache();
    }
  }

  // =================== 以下为兼容旧接口的方法 ===================

  /**
   * 获取用户画像（向后兼容）
   */
  async getProfile() {
    try {
      await this.refreshCacheIfNeeded();
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item');
      const behaviorRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'behavior_pattern');
      const summaryRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'user_summary');
      if (interestRecords.length === 0) {
        return null;
      }

      // 重构用户画像对象
      return {
        userId: this.userId,
        createdAt: Math.min(...interestRecords.map(r => r.metadata.created_at)),
        lastUpdated: Math.max(...interestRecords.map(r => r.metadata.updated_at)),
        interests: this.reconstructInterestItems(interestRecords),
        behaviorPatterns: this.reconstructBehaviorPatterns(behaviorRecords),
        derivedPreferences: this.reconstructDerivedPreferences(summaryRecords),
        statistics: this.calculateStatistics(interestRecords, summaryRecords)
      };
    } catch (error) {
      console.error('获取用户画像失败:', error);
      return null;
    }
  }

  /**
   * 设置明确重要性
   */
  async setExplicitImportance(itemId, type, importance) {
    try {
      const recordId = `${this.userId}_interest_${type}_${this.sanitizeId(itemId)}`;
      const record = this.recordsCache.get(recordId);
      if (record) {
        record.metadata.explicit_importance = importance;
        record.metadata.updated_at = Date.now();
        await this.cloudStorage.storeUserprofilesRecord(record);
        return true;
      }
      return false;
    } catch (error) {
      console.error('设置明确重要性失败:', error);
      return false;
    }
  }

  /**
   * 应用权重衰减
   */
  async applyWeightDecay() {
    try {
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item');
      const now = Date.now();
      const oneDay = 24 * 60 * 60 * 1000;
      for (const record of interestRecords) {
        const daysSinceLastAccess = (now - (record.metadata.last_accessed || record.metadata.created_at)) / oneDay;

        // 简单的衰减公式
        const decayFactor = Math.exp(-daysSinceLastAccess / 30); // 30天为衰减周期
        record.metadata.current_weight *= decayFactor;
        record.metadata.updated_at = now;
        await this.cloudStorage.storeUserprofilesRecord(record);
      }
      console.log(`权重衰减应用完成，更新了 ${interestRecords.length} 条记录`);
    } catch (error) {
      console.error('应用权重衰减失败:', error);
    }
  }

  /**
   * 融合用户上下文配置
   */
  async fuseUserContextConfig(userContextConfig) {
    try {
      const configRecordId = `${this.userId}_user_summary_context_config`;
      const configRecord = {
        id: configRecordId,
        document: `用户 ${this.userId} 的上下文配置：${JSON.stringify(userContextConfig)}`,
        metadata: {
          record_type: 'user_summary',
          user_id: this.userId,
          created_at: Date.now(),
          updated_at: Date.now(),
          summary_type: 'user_context_config',
          user_context_config: userContextConfig
        }
      };
      await this.cloudStorage.storeUserprofilesRecord(configRecord);
      this.recordsCache.set(configRecordId, configRecord);
      return true;
    } catch (error) {
      console.error('融合用户上下文配置失败:', error);
      return false;
    }
  }

  /**
   * 自适应权重调整
   */
  async adaptiveWeightAdjustment() {
    try {
      // 这是一个简化的实现，真实场景下会更复杂
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item');

      // 基于访问频率调整权重
      for (const record of interestRecords) {
        const accessFrequency = record.metadata.access_count / Math.max(1, (Date.now() - record.metadata.first_seen) / (24 * 60 * 60 * 1000));

        // 高频访问的项目增加权重
        if (accessFrequency > 1) {
          record.metadata.current_weight = Math.min(1, record.metadata.current_weight * 1.1);
        }
        record.metadata.updated_at = Date.now();
        await this.cloudStorage.storeUserprofilesRecord(record);
      }
    } catch (error) {
      console.error('自适应权重调整失败:', error);
    }
  }

  /**
   * 生成主动推荐
   */
  async generateProactiveRecommendations() {
    try {
      const interestRecords = Array.from(this.recordsCache.values()).filter(record => record.metadata.record_type === 'interest_item');

      // 简化的推荐算法
      const recommendations = [];

      // 基于技术栈推荐相关技术
      const techItems = interestRecords.filter(r => r.metadata.interest_category === 'technology');
      const topTech = techItems.sort((a, b) => b.metadata.current_weight - a.metadata.current_weight)[0];
      if (topTech) {
        recommendations.push({
          id: `tech_learning_${topTech.metadata.name}`,
          type: 'learning',
          title: `${topTech.metadata.name} 高级特性`,
          description: `学习更多关于 ${topTech.metadata.name} 的高级用法和最佳实践`,
          reason: `基于您对 ${topTech.metadata.name} 的高度关注`,
          confidence: 0.8,
          priority: 'medium'
        });
      }
      return recommendations.slice(0, 5);
    } catch (error) {
      console.error('生成主动推荐失败:', error);
      return [];
    }
  }

  /**
   * 融合兴趣项权重
   */
  getFusedInterestItems(items) {
    return items.map(item => {
      const explicitWeight = item.explicitImportance || 0;
      const implicitWeight = item.currentWeight || item.weight || 0;

      // 融合公式：明确重要性占40%，隐式权重占60%
      const fusedWeight = explicitWeight * 0.4 + implicitWeight * 0.6;
      return {
        ...item,
        weight: fusedWeight,
        currentWeight: fusedWeight
      };
    });
  }

  // =================== 私有辅助方法 ===================

  /**
   * 更新现有兴趣记录
   */
  async updateExistingInterestRecord(record, action) {
    const metadata = record.metadata;

    // 更新访问统计
    metadata.access_count += 1;
    metadata.last_accessed = action.timestamp;
    metadata.updated_at = action.timestamp;

    // 更新权重
    const actionWeight = this.getActionWeight(action.actionType);
    metadata.current_weight = Math.min(1, metadata.current_weight + actionWeight * 0.1);

    // 更新最近行为
    if (!metadata.recent_action_types.includes(action.actionType)) {
      metadata.recent_action_types.push(action.actionType);
      // 保持最近5种行为类型
      if (metadata.recent_action_types.length > 5) {
        metadata.recent_action_types.shift();
      }
    }

    // 更新交互模式
    metadata.interaction_patterns.view_frequency += action.actionType === 'view' ? 1 : 0;
    metadata.interaction_patterns.edit_frequency += action.actionType === 'edit' ? 1 : 0;
    metadata.interaction_patterns.share_frequency += action.actionType === 'mention' ? 1 : 0;

    // 重新生成文档描述
    record.document = this.generateInterestItemDocument(metadata);

    // 存储更新
    await this.cloudStorage.storeUserprofilesRecord(record);
    this.recordsCache.set(record.id, record);
  }

  /**
   * 创建新兴趣记录
   */
  async createNewInterestRecord(recordId, targetItem, action) {
    const actionWeight = this.getActionWeight(action.actionType);
    const newRecord = {
      id: recordId,
      document: '',
      // 将在下面生成
      metadata: {
        record_type: 'interest_item',
        user_id: this.userId,
        created_at: action.timestamp,
        updated_at: action.timestamp,
        last_accessed: action.timestamp,
        interest_category: targetItem.type,
        name: targetItem.name,
        current_weight: actionWeight,
        access_count: 1,
        first_seen: action.timestamp,
        recent_action_types: [action.actionType],
        interaction_patterns: {
          view_frequency: action.actionType === 'view' ? 1 : 0,
          edit_frequency: action.actionType === 'edit' ? 1 : 0,
          share_frequency: action.actionType === 'mention' ? 1 : 0
        },
        trend: 'stable',
        // 从targetItem.metadata复制特定字段
        ...(targetItem.metadata?.projectType && {
          project_type: targetItem.metadata.projectType
        }),
        ...(targetItem.metadata?.role && {
          person_role: targetItem.metadata.role
        }),
        ...(targetItem.metadata?.stack && {
          technology_stack: [targetItem.metadata.stack]
        }),
        ...(targetItem.metadata?.keywords && {
          topic_keywords: targetItem.metadata.keywords
        })
      }
    };

    // 生成文档描述
    newRecord.document = this.generateInterestItemDocument(newRecord.metadata);

    // 存储记录
    await this.cloudStorage.storeUserprofilesRecord(newRecord);
    this.recordsCache.set(recordId, newRecord);
  }

  /**
   * 生成兴趣项文档描述
   */
  generateInterestItemDocument(metadata) {
    const category = metadata.interest_category;
    const name = metadata.name;
    const weight = metadata.current_weight;
    let description = `${category}: ${name}`;

    // 添加类型特定信息
    if (category === 'project' && metadata.project_type) {
      description += ` (项目类型: ${metadata.project_type})`;
    } else if (category === 'person' && metadata.person_role) {
      description += ` (角色: ${metadata.person_role})`;
    } else if (category === 'technology' && metadata.technology_stack) {
      description += ` (技术栈: ${metadata.technology_stack.join(', ')})`;
    } else if (category === 'topic' && metadata.topic_keywords) {
      description += ` (关键词: ${metadata.topic_keywords.join(', ')})`;
    }
    description += ` - 权重: ${weight.toFixed(2)}, 访问次数: ${metadata.access_count}`;
    return description;
  }

  /**
   * 生成行为模式文档描述
   */
  generateBehaviorPatternDocument(data) {
    return `用户行为: ${data.actionType} 在 ${data.targetType} "${data.targetId}" 上，上下文: ${data.context}`;
  }

  /**
   * 获取行为模式类型
   */
  getPatternType(actionType) {
    // 简化的映射
    if (['view', 'edit', 'create'].includes(actionType)) return 'work_pattern';
    if (['mention', 'search'].includes(actionType)) return 'communication_style';
    return 'time_preference';
  }

  /**
   * 获取行为特定元数据
   */
  getBehaviorSpecificMetadata(data) {
    const hour = new Date(data.timestamp).getHours();
    return {
      active_hours: [hour],
      formality_level: 'semi-formal',
      response_speed: 'normal'
    };
  }

  /**
   * 排序兴趣项
   */
  sortInterestItems(records, sortBy) {
    return records.sort((a, b) => {
      switch (sortBy) {
        case 'weight':
          return b.metadata.current_weight - a.metadata.current_weight;
        case 'frequency':
          return b.metadata.access_count - a.metadata.access_count;
        case 'recent':
          return (b.metadata.last_accessed || 0) - (a.metadata.last_accessed || 0);
        default:
          return 0;
      }
    });
  }

  /**
   * 获取行为权重
   */
  getActionWeight(actionType) {
    const weights = {
      'view': 0.1,
      'edit': 0.3,
      'create': 0.5,
      'link': 0.2,
      'mention': 0.2,
      'search': 0.15,
      'favorite': 0.4
    };
    return weights[actionType] || 0.1;
  }

  /**
   * 按类别获取顶级项目
   */
  getTopItemsByCategory(records) {
    const byCategory = {};
    records.forEach(record => {
      const category = record.metadata.interest_category;
      if (!byCategory[category]) {
        byCategory[category] = [];
      }
      byCategory[category].push(record);
    });
    const result = {};
    Object.keys(byCategory).forEach(category => {
      result[category] = byCategory[category].sort((a, b) => b.metadata.current_weight - a.metadata.current_weight).slice(0, 5).map(record => ({
        name: record.metadata.name,
        weight: record.metadata.current_weight,
        accessCount: record.metadata.access_count
      }));
    });
    return result;
  }

  /**
   * 计算兴趣分布
   */
  calculateInterestDistribution(records) {
    const distribution = {};
    const total = records.length;
    records.forEach(record => {
      const category = record.metadata.interest_category;
      distribution[category] = (distribution[category] || 0) + 1;
    });

    // 转换为百分比
    Object.keys(distribution).forEach(key => {
      distribution[key] = distribution[key] / total;
    });
    return distribution;
  }

  /**
   * 分析行为模式
   */
  analyzeBehaviorPatterns(records) {
    // 简化的行为分析
    const timeData = records.filter(r => r.metadata.pattern_type === 'time_preference');
    const now = Date.now();
    const socialRecords = records.filter(r => r.metadata.pattern_type === 'communication_style');
    return {
      activeHours: timeData.length > 0 ? timeData[0].metadata.active_hours : [],
      communicationStyle: socialRecords.length > 0 ? socialRecords[0].metadata.formality_level : 'semi-formal',
      responseSpeed: socialRecords.length > 0 ? socialRecords[0].metadata.response_speed : 'normal'
    };
  }

  /**
   * 预测兴趣
   */
  predictInterests(records) {
    // 基于现有兴趣的简单预测
    const techRecords = records.filter(r => r.metadata.interest_category === 'technology');
    const topTech = techRecords.sort((a, b) => b.metadata.current_weight - a.metadata.current_weight)[0];
    if (topTech) {
      return [{
        item: `${topTech.metadata.name} 进阶应用`,
        type: 'technology',
        confidence: 0.8,
        reason: `基于您对 ${topTech.metadata.name} 的高度关注`
      }];
    }
    return [];
  }

  /**
   * 生成内容建议
   */
  generateContentSuggestions(records) {
    const suggestions = [];
    const topRecords = records.sort((a, b) => b.metadata.current_weight - a.metadata.current_weight).slice(0, 3);
    topRecords.forEach(record => {
      suggestions.push(`关于 ${record.metadata.name} 的深度内容`);
    });
    return suggestions;
  }

  /**
   * 计算分析置信度
   */
  calculateAnalysisConfidence(records) {
    if (records.length === 0) return 0;
    const totalInteractions = records.reduce((sum, r) => sum + r.metadata.access_count, 0);
    const avgWeight = records.reduce((sum, r) => sum + r.metadata.current_weight, 0) / records.length;

    // 简单的置信度计算
    return Math.min(1, totalInteractions / 100 * 0.5 + avgWeight * 0.5);
  }

  /**
   * 重构兴趣项（用于向后兼容）
   */
  reconstructInterestItems(records) {
    const interests = {
      projects: [],
      people: [],
      topics: [],
      technologies: [],
      documents: [],
      jiraTickets: []
    };
    records.forEach(record => {
      const metadata = record.metadata;
      const item = {
        id: record.id,
        type: metadata.interest_category,
        name: metadata.name,
        firstSeen: metadata.first_seen,
        lastAccessed: metadata.last_accessed || metadata.updated_at,
        accessCount: metadata.access_count,
        currentWeight: metadata.current_weight,
        decayFactor: 1.0,
        userActions: [],
        // 简化处理
        explicitImportance: metadata.explicit_importance,
        metadata: {
          projectType: metadata.project_type,
          role: metadata.person_role,
          stack: metadata.technology_stack?.[0],
          keywords: metadata.topic_keywords
        }
      };
      const categoryMap = {
        'project': 'projects',
        'person': 'people',
        'topic': 'topics',
        'technology': 'technologies',
        'document': 'documents',
        'jira': 'jiraTickets'
      };
      const category = categoryMap[metadata.interest_category];
      if (category && interests[category]) {
        interests[category].push(item);
      }
    });
    return interests;
  }

  /**
   * 重构行为模式（用于向后兼容）
   */
  reconstructBehaviorPatterns(records) {
    return {
      activeTimeZones: [],
      primaryWorkAreas: [],
      communicationStyle: {
        formality: 'semi-formal',
        detailLevel: 'medium',
        responseSpeed: 'normal',
        preferredChannels: ['email', 'chat']
      },
      toolUsageFrequency: []
    };
  }

  /**
   * 重构衍生偏好（用于向后兼容）
   */
  reconstructDerivedPreferences(summaryRecords) {
    const preferencesRecord = summaryRecords.find(r => r.metadata.summary_type === 'derived_preferences');
    if (preferencesRecord) {
      return {
        preferredProjectTypes: preferencesRecord.metadata.preferred_project_types || [],
        keyCollaborators: preferencesRecord.metadata.key_collaborators || [],
        expertiseAreas: preferencesRecord.metadata.expertise_areas || [],
        riskSensitivity: preferencesRecord.metadata.risk_sensitivity || 'medium',
        updateFrequency: preferencesRecord.metadata.update_frequency || 'weekly'
      };
    }
    return {
      preferredProjectTypes: [],
      keyCollaborators: [],
      expertiseAreas: [],
      riskSensitivity: 'medium',
      updateFrequency: 'weekly'
    };
  }

  /**
   * 计算统计信息（用于向后兼容）
   */
  calculateStatistics(interestRecords, summaryRecords) {
    const statsRecord = summaryRecords.find(r => r.metadata.summary_type === 'statistics');
    if (statsRecord) {
      return {
        totalInteractions: statsRecord.metadata.total_interactions || 0,
        averageDailyActivity: statsRecord.metadata.daily_activity_average || 0,
        mostActiveDay: statsRecord.metadata.most_active_day || '',
        topInteractionTypes: statsRecord.metadata.top_interaction_types || {}
      };
    }

    // 从兴趣记录计算基本统计
    const totalInteractions = interestRecords.reduce((sum, r) => sum + r.metadata.access_count, 0);
    return {
      totalInteractions,
      averageDailyActivity: totalInteractions / Math.max(1, interestRecords.length),
      mostActiveDay: new Date().toISOString().split('T')[0],
      topInteractionTypes: {
        view: totalInteractions
      }
    };
  }

  /**
   * 清理ID用于存储
   */
  sanitizeId(id) {
    return id.replace(/[^a-zA-Z0-9_-]/g, '_');
  }
}

/***/ }),

/***/ 8:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   M: () => (/* binding */ extractEntitiesFromMessage),
/* harmony export */   extractEntitiesForQuery: () => (/* binding */ extractEntitiesForQuery)
/* harmony export */ });
/* harmony import */ var _llm__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1995);
// 新文件：实体识别和提取


// 使用LLM提取消息中的实体
// 该格式与MemoryEntity的relatedData结构保持一致
async function extractEntitiesFromMessage(content) {
  let metadata = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  try {
    const prompt = `
    请分析以下消息，提取所有相关的实体信息和关系：
    
    消息内容：
    ${content}
    ${metadata.sender ? `消息发送者：${metadata.sender}` : ''}
    ${metadata.team_name ? `消息所在群组：${metadata.team_name}` : ''}
    ${metadata.summary ? `根据上下文得到的总结：${metadata.summary}` : ''}

    请严格按照以下 JSON 格式提取实体信息：
    {
      "entities": {
        "people": [
          {
            "name": "",
            "role": "", // 如果不知道可以留空
            "team": "", // 如果不知道可以留空
            "expertise": [], // 如果不知道可以留空
            "lastContact": null,
            "relevanceScore": 0.8
          }
        ],
        "projects": [
          {
            "name": "",
            "description": "",
            "status": "", // 如果不知道可以留空
            "relevanceScore": 0.8
          }
        ],
        "topics": [
          {
            "name": "",
            "summary": "",
            "category": "",
            "relevanceScore": 0.8
          }
        ],
        "resources": [ // 如果找到 wiki, docs, slides 等资源对应的 URL, 提取相关资源信息
          {
            "name": "",
            "summary": "",
            "type": "",
            "url": "wiki|docs|slides|...",
            "relevanceScore": 0.8
          }
        ],
        "webpages": [ // 如果找到非以上资源的其他网页，提取相关网页信息
          {
            "title": "",
            "summary": "",
            "url": "",
            "relevanceScore": 0.8
          }
        ],
        "jiraTickets": [
          {
            "key": "",
            "summary": "",
            "status": "",
            "assignee": "",
            "priority": "",
            "relevanceScore": 0.8
          }
        ]
      },
      "metadata": {
        "sentiment": "",
        "priority": "",
        "category": [],
        "tags": []
      },
      "actions": [
        {
          "type": "",
          "description": "",
          "assignee": "",
          "deadline": null,
          "status": ""
        }
      ]
    }
    
    仅返回JSON，不要有其他内容。如果某类实体不存在，返回空数组。
    注意：relevanceScore应该在0-1之间，表示与当前消息的相关性。
    `;
    const entityData = await (0,_llm__WEBPACK_IMPORTED_MODULE_0__/* .callLLMJsonAPI */ .sc)({
      prompt,
      type: 'query'
    });
    console.log('提取出的实体信息：', entityData);
    if (typeof entityData === 'object') {
      return {
        entities: {
          people: entityData.entities?.people || [],
          projects: entityData.entities?.projects || [],
          topics: entityData.entities?.topics || [],
          resources: entityData.entities?.resources || [],
          webpages: entityData.entities?.webpages || [],
          jiraTickets: entityData.entities?.jiraTickets || [],
          conversations: entityData.entities?.conversations || []
        },
        metadata: {
          sentiment: entityData.metadata?.sentiment || "neutral",
          priority: entityData.metadata?.priority || "medium",
          category: entityData.metadata?.category || [],
          tags: entityData.metadata?.tags || []
        },
        actions: entityData.actions || []
      };
    }
    return {
      entities: {
        people: [],
        projects: [],
        topics: [],
        resources: [],
        webpages: [],
        jiraTickets: [],
        conversations: []
      },
      metadata: {
        sentiment: "neutral",
        priority: "medium",
        category: [],
        tags: []
      },
      actions: []
    };
  } catch (error) {
    console.error('实体提取失败:', error);
    return {
      entities: {
        people: [],
        projects: [],
        topics: [],
        resources: [],
        webpages: [],
        jiraTickets: [],
        conversations: []
      },
      metadata: {
        sentiment: "neutral",
        priority: "medium",
        category: [],
        tags: []
      },
      actions: []
    };
  }
}
async function extractEntitiesForQuery(question) {
  try {
    const analysisPrompt = `
    分析以下问题，提取查询意图和关键实体。按JSON格式返回：
    
    问题: "${question}"
    
    {
      "query": {
        "intent": {
          "primary": "",     // search/analyze/summarize/compare
          "secondary": "",   // 具体查询类型，如project_status/person_info等
          "action_type": "" // retrieve/count/timeline/relationship
        },
        "filters": {
          "time_range": {
            "type": "recent|all|specific|range",
            "start": null,   // 时间戳
            "end": null,     // 时间戳
            "description": "" // 对时间范围的文字描述，如"今年"、"这个月"、"最近一周"等
          },
          "entities": {
            "people": [
              {
                "name": "",
                "role": "",
                "required": true  // 是否必须包含该人物
              }
            ],
            "projects": [
              {
                "name": "",
                "status": "",
                "required": true
              }
            ],
            "topics": [
              {
                "name": "",
                "category": "",
                "required": true
              }
            ],
            "location": [
              {
                "name": "",
                "type": "",
                "required": true
              }
            ]
          }
        },
        "output": {
          "format": "",     // list/timeline/summary/graph
          "fields": [],     // 需要返回的字段
          "sort": {
            "field": "",
            "order": "asc|desc"
          },
          "limit": null    // 结果数量限制
        }
      },
      "context": {
        "reference_time": null,  // 参考时间点
        "user_context": "",     // 用户查询上下文
        "priority": ""         // high/medium/low
      }
    }
    
    注意：
    1. time_range.type 必须是以下值之一：
       - "all"：表示所有时间，不指定则默认是 all
       - "recent"：仅表示最近几天，如"最近"、"近期"、"最近几天"
       - "specific"：表示具体时间点
       - "range"：表示时间范围
    2. 对于包含较长时间段的描述：
       - "这个月"、"本月"应设为range类型，而非recent
       - "今年"、"本年"应设为range类型，而非recent
       - "去年"、"上个月"等也应设为range类型
    3. 请在description字段中保留原始时间描述词，如"今年"、"这个月"等
    4. 所有时间戳必须是数字或null，不能是字符串
    5. 如果无法确定具体时间，相关时间字段设为null
    6. 时间疑问词表示查询事件发生时间，不是限制查询范围
    7. required 字段表示该实体是否为必需匹配项
    8. 重要：如果问题中没有明确的时间限定词（如"最近"、"今年"、"这个月"等），请将time_range.type设为"all"
    `;

    // 使用LLM分析问题
    const queryIntent = await (0,_llm__WEBPACK_IMPORTED_MODULE_0__/* .callLLMJsonAPI */ .sc)({
      prompt: analysisPrompt,
      type: 'query'
    });
    return queryIntent;
  } catch (error) {
    console.error('查询意图分析失败:', error);
    return {
      query: {
        intent: {
          primary: "search",
          secondary: "general",
          action_type: "retrieve"
        },
        filters: {
          time_range: {
            type: "all",
            start: null,
            end: null,
            description: ""
          },
          entities: {
            people: [],
            projects: [],
            topics: [],
            location: []
          }
        },
        output: {
          format: "list",
          fields: [],
          sort: {
            field: "",
            order: "desc"
          },
          limit: 10
        }
      },
      context: {
        reference_time: null,
        user_context: "",
        priority: "medium"
      }
    };
  }
}

/***/ }),

/***/ 8143:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   f: () => (/* binding */ CloudStorage)
/* harmony export */ });
/* harmony import */ var chromadb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9266);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5279);
/* harmony import */ var _embeddings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1929);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3922);
/* harmony import */ var _memory__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6939);
/**
 * 云端存储管理器
 * 专门管理 ChromaDB 操作，包括向量搜索和完整数据存储
 */







// GraphEntity 替换为 MemoryEntity，类型兼容

/**
 * 自定义空嵌入函数 - 禁用 ChromaDB v3 的默认嵌入
 * 实际嵌入计算通过离屏文档完成
 */
class NullEmbeddingFunction {
  async generate(texts) {
    // 不实际计算嵌入向量，因为我们使用离屏文档方案
    throw new Error('嵌入计算应通过离屏文档完成，不应调用此函数');
  }
}

/**
 * 云端存储管理器
 */
class CloudStorage {
  constructor() {
    this.client = null;
    this.collections = new Map();
    this.username = '';
    this.isInitialized = false;
    // 实体相似度阈值配置
    this.entitySimilarityThreshold = 0.85;
    // 相似度阈值，超过此值认为是同一实体
    // 用户档案维护配置
    this.userprofilesMaintenanceConfig = {
      cleanup_thresholds: {
        min_weight: 0.01,
        max_age_days: 180,
        min_access_count: 1
      },
      aggregation_rules: {
        combine_threshold: 0.8,
        max_records_per_category: 100,
        enable_auto_summary: true,
        summary_frequency_days: 7,
        max_records_per_user: 1000
      },
      update_frequency: {
        full_analysis_days: 7,
        incremental_hours: 24
      },
      vector_update: {
        enable_batch_update: true,
        batch_size: 50,
        update_frequency_hours: 24
      }
    };
    this.config = {
      collections: ['messages', 'webpages', 'projects', 'documents', 'graph-entities', 'userprofiles'],
      batchSize: 100,
      timeout: 10000
    };
  }

  /**
   * 初始化云端存储
   */
  async initialize() {
    try {
      console.log('☁️ 初始化云端存储...');
      const envConfig = await (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .getEnvConfig */ .Un)();
      if (!envConfig.ENABLE_CHROMA) {
        console.log('⚠️ ChromaDB 已禁用，云端存储功能不可用');
        return false;
      }

      // 获取用户信息
      const userinfo = await this.getUserInfo();
      this.username = userinfo.username;

      // 初始化 ChromaDB 客户端
      const chromaConfig = (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .parseChromaConfig */ .Wc)(envConfig);
      this.client = new chromadb__WEBPACK_IMPORTED_MODULE_0__.ChromaClient({
        host: chromaConfig.host,
        port: chromaConfig.port,
        ssl: chromaConfig.ssl
      });

      // 初始化集合
      await this.initializeCollections();
      this.isInitialized = true;
      console.log('✅ 云端存储初始化完成');
      return true;
    } catch (error) {
      console.error('❌ 云端存储初始化失败:', error);
      return false;
    }
  }

  /**
   * 检查连接状态
   */
  async isConnected() {
    if (!this.client) return false;
    try {
      await this.client.heartbeat();
      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * 确保已初始化
   */
  ensureInitialized() {
    if (!this.isInitialized) {
      throw new Error('云端存储未初始化');
    }
  }

  /**
   * 增强向量搜索 - 支持多种搜索模式和返回格式
   */
  // 函数重载：根据 returnType 返回不同类型

  // 实现
  async searchByVector(query, type) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    this.ensureInitialized();
    const startTime = Date.now();
    const {
      limit = 20,
      nResults = 20,
      collections = ['entities', 'messages', 'webpages'],
      returnType = 'entities',
      sortBy = 'relevance',
      sortOrder = 'desc',
      timeRange,
      minRelevanceScore,
      where: customWhere
    } = options;
    try {
      // 生成查询向量
      const queryEmbedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(query);

      // 确定搜索的集合
      const collectionMap = {
        'entities': `${this.username}-graph-entities`,
        'messages': `${this.username}-messages`,
        'webpages': `${this.username}-webpages`,
        'userprofiles': `${this.username}-userprofiles`
      };
      const collectionsToSearch = type ? [`${this.username}-graph-entities`] : collections.map(c => collectionMap[c]).filter(Boolean);
      const allResults = [];

      // 在多个集合中搜索
      for (const collectionName of collectionsToSearch) {
        const collection = this.collections.get(collectionName);
        if (!collection) continue;
        try {
          // 构建查询参数
          const queryParams = {
            queryEmbeddings: [queryEmbedding],
            nResults,
            include: ['metadatas', 'documents', 'distances']
          };

          // 构建where条件 - 使用 $and 操作符组合多个条件
          const conditions = [];

          // 1. 添加type过滤（对entities集合有效）
          if (type && collectionName.includes('graph-entities')) {
            conditions.push({
              type: type
            });
          }

          // 2. 添加时间范围过滤（对 messages、webpages 和 userprofiles 有效）
          if (timeRange && (collectionName.includes('messages') || collectionName.includes('webpages') || collectionName.includes('userprofiles'))) {
            let timeField = 'extractedAt';
            if (collectionName.includes('messages')) {
              timeField = 'timestamp';
            } else if (collectionName.includes('userprofiles')) {
              timeField = 'updated_at';
            }
            conditions.push({
              [timeField]: {
                $gte: timeRange.start,
                $lte: timeRange.end
              }
            });
          }

          // 3. 添加自定义过滤条件
          if (customWhere && typeof customWhere === 'object') {
            Object.entries(customWhere).forEach(_ref => {
              let [key, value] = _ref;
              conditions.push({
                [key]: value
              });
            });
          }

          // 4. 应用where条件（只有当有条件时才添加）
          if (conditions.length > 0) {
            if (conditions.length === 1) {
              queryParams.where = conditions[0];
            } else {
              queryParams.where = {
                $and: conditions
              };
            }
          }
          const searchResults = await collection.query(queryParams);

          // 处理搜索结果
          if (searchResults.metadatas?.[0]) {
            for (let i = 0; i < searchResults.metadatas[0].length; i++) {
              const metadata = searchResults.metadatas[0][i];
              const distance = searchResults.distances?.[0]?.[i] !== undefined ? Number(searchResults.distances?.[0]?.[i]) : 1;
              const relevanceScore = Math.max(0, 1 - distance); // 余弦距离：1-distance转换为0-1的相关度评分

              // 过滤低相关性结果
              if (minRelevanceScore && relevanceScore < minRelevanceScore) continue;
              if (returnType === 'entities') {
                // 返回实体格式
                const entity = await this.buildEntity({
                  metadata,
                  id: searchResults.ids?.[0]?.[i],
                  document: searchResults.documents?.[0]?.[i],
                  distance: Number(distance),
                  relevanceScore,
                  collectionName
                });
                if (entity) {
                  allResults.push(entity);
                }
              } else if (returnType === 'messages' || collectionName.includes('messages')) {
                // 返回消息格式
                const processedMetadata = this.deserializeChromaMetadata(metadata || {});
                allResults.push({
                  id: searchResults.ids?.[0]?.[i] || `result_${i}`,
                  messageId: searchResults.ids?.[0]?.[i],
                  content: searchResults.documents?.[0]?.[i] || '',
                  sender: metadata?.sender || metadata?.source || 'unknown',
                  datetime: metadata?.datetime || metadata?.extractedAt || Date.now(),
                  relevanceScore,
                  distance,
                  collectionType: this.getCollectionType(collectionName),
                  metadata: processedMetadata
                });
              } else {
                // 返回原始数据格式（用于用户档案查询等）
                allResults.push({
                  id: searchResults.ids?.[0]?.[i],
                  document: searchResults.documents?.[0]?.[i] || '',
                  metadata: metadata,
                  relevanceScore,
                  distance,
                  collectionType: this.getCollectionType(collectionName)
                });
              }
            }
          }
        } catch (error) {
          console.warn(`搜索集合 ${collectionName} 失败:`, error);
        }
      }

      // 应用排序
      allResults.sort((a, b) => {
        let valueA, valueB;
        switch (sortBy) {
          case 'relevance':
            valueA = a.relevanceScore || 0;
            valueB = b.relevanceScore || 0;
            break;
          case 'time':
            valueA = a.timestamp || a.updated || a.created || 0;
            valueB = b.timestamp || b.updated || b.created || 0;
            break;
          case 'importance':
            valueA = a.importance || 0;
            valueB = b.importance || 0;
            break;
          default:
            // 默认按相关度排序
            valueA = a.relevanceScore || 0;
            valueB = b.relevanceScore || 0;
        }
        return sortOrder === 'desc' ? valueB - valueA : valueA - valueB;
      });

      // 分页
      const paginatedResults = allResults.slice(0, limit);
      console.log(`🔍 向量搜索完成: "${query}" -> ${paginatedResults.length}/${allResults.length} 条结果 (${returnType}, 排序:${sortBy})`);
      return {
        data: paginatedResults,
        total: allResults.length,
        source: 'cloud',
        cached: false,
        queryTime: Date.now() - startTime
      };
    } catch (error) {
      console.error('向量搜索失败:', error);
      return {
        data: [],
        total: 0,
        source: 'cloud',
        cached: false,
        queryTime: Date.now() - startTime
      };
    }
  }

  /**
   * 获取单个实体
   */
  async getEntity(entityId) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return null;
      const result = await collection.get({
        ids: [entityId],
        include: ['metadatas', 'documents']
      });
      if (result.ids && result.ids.length > 0 && result.metadatas) {
        const metadata = result.metadatas[0];

        // 跳过备份数据
        if (metadata.type === 'graph_backup') return null;
        const entity = await this.buildEntity({
          metadata,
          id: result.ids[0],
          document: result.documents?.[0],
          collectionName: 'graph-entities'
        });
        return entity;
      }
      return null;
    } catch (error) {
      console.error(`获取实体 ${entityId} 失败:`, error);
      return null;
    }
  }

  /**
   * 从消息集合获取单个消息
   */
  async getMessage(messageId) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-messages`);
      if (!collection) return null;
      const result = await collection.get({
        ids: [messageId],
        include: ['metadatas', 'documents']
      });
      if (result.ids && result.ids.length > 0 && result.metadatas) {
        const metadata = result.metadatas[0];
        const document = result.documents?.[0];

        // 构建消息对象
        const processedMetadata = this.deserializeChromaMetadata(metadata || {});
        return {
          id: result.ids[0],
          content: document || '',
          sender: metadata?.sender || 'unknown',
          datetime: metadata?.datetime || Date.now(),
          metadata: processedMetadata,
          // 从 metadata 中提取常用字段
          groupName: metadata?.groupName || '未知群组',
          groupUrl: metadata?.groupUrl || metadata?.team_url || '#',
          groupId: metadata?.groupId || '',
          summary: metadata?.summary || (document ? document.substring(0, 100) + '...' : ''),
          matchedRules: metadata?.matchedRules || [],
          replyAdvice: metadata?.replyAdvice || '',
          contextMessages: processedMetadata?.contextMessages || []
        };
      }
      return null;
    } catch (error) {
      console.error(`获取消息 ${messageId} 失败:`, error);
      return null;
    }
  }

  /**
   * 通过 postId 查询消息是否已存在
   * @param postId 原始消息的 postId
   * @returns 如果存在返回消息对象，否则返回 null
   */
  async getMessageByPostId(postId) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-messages`);
      if (!collection) return null;

      // 使用 where 条件查询 metadata.postId
      const result = await collection.get({
        where: {
          postId: postId
        },
        include: ['metadatas', 'documents'],
        limit: 1 // 只需要第一条匹配的记录
      });
      if (result.ids && result.ids.length > 0 && result.metadatas) {
        const metadata = result.metadatas[0];
        const document = result.documents?.[0];

        // 构建消息对象
        const processedMetadata = this.deserializeChromaMetadata(metadata || {});
        return {
          id: result.ids[0],
          content: document || '',
          sender: metadata?.sender || 'unknown',
          datetime: metadata?.datetime || Date.now(),
          metadata: processedMetadata,
          // 从 metadata 中提取常用字段
          groupName: metadata?.groupName || '未知群组',
          groupUrl: metadata?.groupUrl || metadata?.team_url || '#',
          groupId: metadata?.groupId || '',
          summary: metadata?.summary || (document ? document.substring(0, 100) + '...' : ''),
          matchedRules: metadata?.matchedRules || [],
          replyAdvice: metadata?.replyAdvice || '',
          contextMessages: processedMetadata?.contextMessages || []
        };
      }
      return null;
    } catch (error) {
      console.error(`通过 postId ${postId} 查询消息失败:`, error);
      return null;
    }
  }

  /**
   * 查询云端实体（支持按type过滤和真正的分页）
   */
  async queryEntities(type, searchTerm) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    this.ensureInitialized();
    const startTime = Date.now();
    const limit = options.limit || 30; // 默认30条
    const offset = options.offset || 0;
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) {
        return {
          data: [],
          total: 0,
          source: 'cloud',
          cached: false,
          queryTime: Date.now() - startTime
        };
      }

      // 如果有搜索词，使用向量搜索
      if (searchTerm && searchTerm.length > 2) {
        // 转换 sortBy 参数为向量搜索支持的类型
        let vectorSortBy = 'relevance';
        if (options.sortBy === 'importance') {
          vectorSortBy = 'importance';
        } else if (options.sortBy === 'created' || options.sortBy === 'updated') {
          vectorSortBy = 'time';
        }
        return await this.searchByVector(searchTerm, type, {
          limit,
          nResults: limit * 2,
          // 获取更多结果以应对过滤
          collections: ['entities'],
          returnType: 'entities',
          sortBy: vectorSortBy,
          sortOrder: options.sortOrder
        });
      }

      // 构建 where 查询条件
      const conditions = [];

      // 排除备份数据
      conditions.push({
        type: {
          $ne: 'graph_backup'
        }
      });

      // 如果指定了实体类型，添加类型过滤
      if (type) {
        conditions.push({
          type: type
        });
      }

      // 构建最终的 where 条件
      const whereCondition = conditions.length === 1 ? conditions[0] : {
        $and: conditions
      };

      // 直接使用 where 查询，真正的分页
      const result = await collection.get({
        where: whereCondition,
        include: ['metadatas', 'documents'],
        limit,
        offset
      });
      if (!result.ids || result.ids.length === 0) {
        return {
          data: [],
          total: 0,
          source: 'cloud',
          cached: false,
          queryTime: Date.now() - startTime
        };
      }

      // 构建实体列表
      const entities = [];
      for (let i = 0; i < result.ids.length; i++) {
        const metadata = result.metadatas[i];
        const entity = await this.buildEntity({
          metadata,
          id: result.ids[i],
          document: result.documents?.[i],
          collectionName: 'graph-entities'
        });
        if (entity) {
          entities.push(entity);
        }
      }

      // 应用排序
      if (options.sortBy && entities.length > 0) {
        entities.sort((a, b) => {
          const order = options.sortOrder === 'desc' ? -1 : 1;
          switch (options.sortBy) {
            case 'name':
              return order * a.name.localeCompare(b.name);
            case 'created':
              return order * (a.created - b.created);
            case 'updated':
              return order * (a.updated - b.updated);
            case 'importance':
              return order * (a.importance - b.importance);
            default:
              return 0;
          }
        });
      }

      // 🆕 从本地缓存获取总数，避免实时查询
      let total = entities.length; // 当前查询到的数量作为默认值
      try {
        const cachedStats = await chrome.storage.local.get('cache_statistics');
        if (cachedStats.cache_statistics?.entityCounts) {
          if (type) {
            total = cachedStats.cache_statistics.entityCounts[type] || 0;
          } else {
            total = Object.values(cachedStats.cache_statistics.entityCounts).reduce((sum, count) => sum + count, 0);
          }
        }
      } catch (error) {
        console.warn('获取缓存统计数据失败，使用查询结果数量:', error);
      }
      console.log(`📥 从云端分页查询了 ${entities.length} 个实体 (offset: ${offset}, limit: ${limit}, type: ${type || '全部'})`);
      return {
        data: entities,
        total: total,
        source: 'cloud',
        cached: false,
        queryTime: Date.now() - startTime
      };
    } catch (error) {
      console.error('查询云端实体失败:', error);
      return {
        data: [],
        total: 0,
        source: 'cloud',
        cached: false,
        queryTime: Date.now() - startTime
      };
    }
  }

  /**
   * 🆕 批量获取实体（根据ID列表）
   * 用于实体扩展时批量加载关联实体
   */
  async getEntitiesByIds(ids) {
    this.ensureInitialized();
    if (!ids || ids.length === 0) {
      return [];
    }
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) {
        console.warn('graph-entities collection 未找到');
        return [];
      }

      // 使用 where 条件批量查询
      const result = await collection.get({
        ids: ids,
        include: ['metadatas', 'documents']
      });
      if (!result.ids || result.ids.length === 0) {
        return [];
      }

      // 构建实体列表
      const entities = [];
      for (let i = 0; i < result.ids.length; i++) {
        const metadata = result.metadatas[i];
        const entity = await this.buildEntity({
          metadata,
          id: result.ids[i],
          document: result.documents?.[i],
          collectionName: 'graph-entities'
        });
        if (entity) {
          entities.push(entity);
        }
      }
      console.log(`📥 批量获取了 ${entities.length}/${ids.length} 个实体`);
      return entities;
    } catch (error) {
      console.error('批量获取实体失败:', error);
      return [];
    }
  }

  /**
   * 查询用户档案记录（非向量搜索）
   * 用于根据元数据条件查询用户档案，不进行向量相似度计算
   */
  async queryUserprofiles() {
    let options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    this.ensureInitialized();
    const startTime = Date.now();
    const {
      record_types,
      user_id,
      limit = 20,
      time_range,
      metadata_filters = {},
      sort_by = 'time',
      sort_order = 'desc'
    } = options;
    try {
      const collectionName = `${this.username}-userprofiles`;
      const collection = this.collections.get(collectionName);
      if (!collection) {
        return {
          records: [],
          total_count: 0,
          query_metadata: {
            query_time: Date.now(),
            processing_time_ms: Date.now() - startTime
          }
        };
      }

      // 构建查询条件 - 使用 $and 操作符组合多个条件
      const conditions = [];

      // 添加 metadata_filters 中的条件
      Object.entries(metadata_filters).forEach(_ref2 => {
        let [key, value] = _ref2;
        conditions.push({
          [key]: value
        });
      });
      if (user_id) {
        conditions.push({
          user_id: user_id
        });
      }
      if (record_types && record_types.length > 0) {
        conditions.push({
          record_type: {
            $in: record_types
          }
        });
      }
      if (time_range) {
        conditions.push({
          updated_at: {
            $gte: time_range.start,
            $lte: time_range.end
          }
        });
      }

      // 构建最终的 where 条件
      let whereCondition = undefined;
      if (conditions.length > 0) {
        if (conditions.length === 1) {
          whereCondition = conditions[0];
        } else {
          whereCondition = {
            $and: conditions
          };
        }
      }

      // 执行查询（不使用向量搜索）
      const searchResult = await collection.get({
        where: whereCondition,
        limit: limit,
        include: ['documents', 'metadatas']
      });

      // 处理结果
      const records = [];
      if (searchResult.documents && searchResult.metadatas) {
        for (let i = 0; i < searchResult.documents.length; i++) {
          records.push({
            id: searchResult.ids[i],
            document: searchResult.documents[i],
            metadata: this.deserializeChromaMetadata(searchResult.metadatas[i])
          });
        }
      }

      // 排序
      if (sort_by === 'time') {
        records.sort((a, b) => {
          const timeA = a.metadata?.updated_at || a.metadata?.created_at || 0;
          const timeB = b.metadata?.updated_at || b.metadata?.created_at || 0;
          return sort_order === 'desc' ? timeB - timeA : timeA - timeB;
        });
      }
      return {
        records: records,
        total_count: records.length,
        query_metadata: {
          query_time: Date.now(),
          processing_time_ms: Date.now() - startTime
        }
      };
    } catch (error) {
      console.error('查询用户档案记录失败:', error);
      return {
        records: [],
        total_count: 0,
        query_metadata: {
          query_time: Date.now(),
          processing_time_ms: Date.now() - startTime
        }
      };
    }
  }

  /**
   * 查找相似实体
   */
  async getSimilarEntities(entity) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    this.ensureInitialized();
    const {
      limit = 1,
      minRelevanceScore = this.entitySimilarityThreshold
    } = options;
    try {
      // 为查询生成与存储时相同的自然语言描述
      const queryDocument = await this.generateSimpleDocument(entity);

      // 使用丰富的描述文本进行向量检索查找相似实体，确保type匹配
      const similarResults = await this.searchByVector(queryDocument, entity.type, {
        limit,
        minRelevanceScore,
        collections: ['entities'],
        returnType: 'entities'
      });
      if (similarResults.data.length > 0) {
        console.log(`🔍 找到 ${similarResults.data.length} 个相似实体 (阈值: ${minRelevanceScore}):`, similarResults.data.map(e => `${e.name}(${e.relevanceScore?.toFixed(3)})`).join(', '));
        return similarResults.data;
      } else {
        console.log(`📝 未找到相似实体: ${entity.name} (${entity.type}) - 阈值: ${minRelevanceScore}`);
        return [];
      }
    } catch (error) {
      console.error(`⚠️ 检查实体相似性时出错: ${entity.name}`, error);
      return [];
    }
  }

  /**
   * 查找相似消息（支持复杂过滤条件，替代 vectorStore.naturalLanguageQuery）
   */
  async getSimilarMessages(query) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    this.ensureInitialized();
    const {
      limit = 10,
      minRelevanceScore = 0.3,
      timeRange,
      sortBy = 'relevance',
      sortOrder = 'desc',
      filters
    } = options;
    try {
      // 构建 where 条件（如果有 filters）
      let whereCondition = undefined;
      if (filters) {
        const conditions = [];

        // 基础过滤
        if (filters.source) {
          conditions.push({
            source: filters.source
          });
        }
        if (filters.teamName) {
          conditions.push({
            teamName: filters.teamName
          });
        }

        // 实体过滤
        if (filters.entities) {
          if (filters.entities.people?.length) {
            const peopleNames = filters.entities.people.map(p => p.name);
            // 检查 source 字段（发送者）或 people 字段
            conditions.push({
              $or: [{
                source: {
                  $in: peopleNames
                }
              }, ...peopleNames.map(name => ({
                people: {
                  $contains: name
                }
              }))]
            });
          }
          if (filters.entities.projects?.length) {
            const projectNames = filters.entities.projects.map(p => p.name);
            conditions.push({
              $or: projectNames.map(name => ({
                projects: {
                  $contains: name
                }
              }))
            });
          }
          if (filters.entities.topics?.length) {
            const topicNames = filters.entities.topics.map(t => t.name);
            conditions.push({
              $or: topicNames.map(name => ({
                topics: {
                  $contains: name
                }
              }))
            });
          }
        }

        // 元数据过滤
        if (filters.metadata) {
          if (filters.metadata.sentiment) {
            conditions.push({
              sentiment: filters.metadata.sentiment
            });
          }
          if (filters.metadata.priority) {
            conditions.push({
              priority: filters.metadata.priority
            });
          }
          if (filters.metadata.category?.length) {
            conditions.push({
              $or: filters.metadata.category.map(cat => ({
                category: {
                  $contains: cat
                }
              }))
            });
          }
          if (filters.metadata.tags?.length) {
            conditions.push({
              $or: filters.metadata.tags.map(tag => ({
                searchTags: {
                  $contains: tag
                }
              }))
            });
          }
        }

        // 合并所有条件
        if (conditions.length > 0) {
          whereCondition = conditions.length === 1 ? conditions[0] : {
            $and: conditions
          };
        }
      }

      // 使用向量搜索获取相关消息
      const searchResults = await this.searchByVector(query, undefined, {
        collections: ['messages'],
        returnType: 'messages',
        limit,
        minRelevanceScore,
        timeRange,
        sortBy,
        sortOrder,
        where: whereCondition
      });
      if (searchResults.data.length > 0) {
        console.log(`💬 找到 ${searchResults.data.length} 个相似消息 (阈值: ${minRelevanceScore}):`, searchResults.data.map(m => `${m.source}(${m.relevanceScore?.toFixed(3)})`).join(', '));

        // 转换为前端需要的格式，包含完整的contextMessages
        const formattedMessages = searchResults.data.map(msg => {
          // 处理上下文消息：从metadata中提取contextMessages
          let contextMessages = [];
          if (msg.metadata?.contextMessages && Array.isArray(msg.metadata.contextMessages)) {
            contextMessages = msg.metadata.contextMessages.map(ctx => ({
              id: ctx.id,
              sender: ctx.sender,
              content: ctx.content,
              datetime: ctx.datetime,
              isMainMessage: ctx.isMainMessage || false
            }));
          }
          return {
            id: msg.messageId,
            sender: msg.source,
            groupName: msg.metadata?.groupName || '未知群组',
            groupUrl: msg.metadata?.groupUrl || msg.metadata?.team_url || '#',
            datetime: new Date(msg.timestamp).toISOString(),
            summary: msg.metadata?.summary || msg.content.substring(0, 100) + '...',
            content: msg.content,
            highlightText: msg.metadata?.highlightText || msg.content,
            matchedRules: msg.metadata?.matchedRules || [],
            relevanceScore: msg.relevanceScore,
            contextMessages: contextMessages
          };
        });
        return formattedMessages;
      } else {
        console.log(`📭 未找到相似消息: "${query}" - 阈值: ${minRelevanceScore}`);
        return [];
      }
    } catch (error) {
      console.error(`⚠️ 检查消息相似性时出错: "${query}"`, error);
      return [];
    }
  }

  /**
   * 获取所有已知人员（从 graph-entities 查询 Person 类型）
   * 替代 vectorStore.getAllKnownPeople()
   */
  async getAllKnownPeople() {
    this.ensureInitialized();
    try {
      const result = await this.queryEntities('Person', undefined, {
        limit: 1000,
        // 获取所有人员
        sortBy: 'name',
        sortOrder: 'asc'
      });
      const peopleNames = result.data.map(entity => entity.name);
      console.log(`📋 获取到 ${peopleNames.length} 个已知人员`);
      return peopleNames;
    } catch (error) {
      console.error('获取已知人员失败:', error);
      return [];
    }
  }

  /**
   * 获取所有已知项目（从 graph-entities 查询 Project 类型）
   * 替代 vectorStore.getAllKnownProjects()
   */
  async getAllKnownProjects() {
    this.ensureInitialized();
    try {
      const result = await this.queryEntities('Project', undefined, {
        limit: 1000,
        // 获取所有项目
        sortBy: 'name',
        sortOrder: 'asc'
      });
      const projectNames = result.data.map(entity => entity.name);
      console.log(`📋 获取到 ${projectNames.length} 个已知项目`);
      return projectNames;
    } catch (error) {
      console.error('获取已知项目失败:', error);
      return [];
    }
  }

  /**
   * 获取所有已知话题（从 graph-entities 查询 Topic 类型）
   * 替代 vectorStore.getAllKnownTopics()
   */
  async getAllKnownTopics() {
    this.ensureInitialized();
    try {
      const result = await this.queryEntities('Topic', undefined, {
        limit: 1000,
        // 获取所有话题
        sortBy: 'name',
        sortOrder: 'asc'
      });
      const topicNames = result.data.map(entity => entity.name);
      console.log(`📋 获取到 ${topicNames.length} 个已知话题`);
      return topicNames;
    } catch (error) {
      console.error('获取已知话题失败:', error);
      return [];
    }
  }

  /**
   * 获取集合类型
   */
  getCollectionType(collectionName) {
    if (collectionName.includes('messages')) return 'message';
    if (collectionName.includes('webpages')) return 'webpage';
    if (collectionName.includes('entities')) return 'entity';
    return 'unknown';
  }

  /**
   * 存储实体到云端 - 新的关联数据存储
   */
  async storeEntity(entity) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return '';

      // 生成实体ID
      if (!entity.id) entity.id = this.generateEntityId(entity.type, entity.name);

      // 🆕 方案E: 用精简文本生成embedding（仅name+tags）
      const simpleDocument = this.generateSimpleDocument(entity);
      const embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(simpleDocument);

      // 🆕 生成完整的自然语言描述，存入metadata.description
      const naturalDescription = await this.generateNaturalLanguageDescription(entity);

      // 转换关联数据为ChromaDB兼容格式，并添加description
      const chromaMetadata = this.serializeChromaMetadata({
        ...entity,
        description: naturalDescription // 完整描述存储在metadata中
      });
      await collection.add({
        ids: [entity.id],
        documents: [simpleDocument],
        // 精简文本用于向量搜索
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      console.log(`✅ 实体存储完成: ${entity.name} (${entity.type}), document长度: ${simpleDocument.length}字符, description长度: ${naturalDescription.length}字符`);
      return entity.id;
    } catch (error) {
      console.error('存储实体到云端失败:', error);
      return '';
    }
  }

  /**
   * 存储消息到云端
   */
  async storeMessage(messageData) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-messages`);
      if (!collection) return false;
      const embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(`sender: ${messageData.metadata.sender}\ncontent: ${messageData.content}\nsummary: ${messageData.metadata.summary}`);

      // 转换复杂元数据为 ChromaDB 兼容格式
      const chromaMetadata = this.serializeChromaMetadata(messageData.metadata);
      await collection.add({
        ids: [messageData.id],
        documents: [messageData.content],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      return true;
    } catch (error) {
      console.error('存储消息到云端失败:', error);
      return false;
    }
  }

  /**
   * 存储网页到云端
   */
  async storeWebpage(webpageData) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-webpages`);
      if (!collection) return false;
      const content = `${webpageData.title} ${webpageData.content}`;
      const embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(content);
      const chromaMetadata = this.serializeChromaMetadata({
        ...webpageData.metadata,
        title: webpageData.title,
        url: webpageData.url
      });
      await collection.add({
        ids: [webpageData.id],
        documents: [content],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      return true;
    } catch (error) {
      console.error('存储网页到云端失败:', error);
      return false;
    }
  }

  /**
   * 🆕 智能更新实体 - 支持关联数据和智能documents更新
   */
  async updateEntity(entityId, updates) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return false;

      // 获取现有实体
      const existing = await collection.get({
        ids: [entityId],
        include: ['metadatas', 'documents']
      });
      if (!existing.metadatas?.[0]) return false;

      // 反序列化现有实体数据
      const currentMetadata = existing.metadatas[0];
      const currentEntity = this.deserializeEntityFromMetadata(currentMetadata);

      // 🆕 智能合并更新：特别处理relatedData
      const mergedEntity = {
        ...currentEntity,
        ...updates,
        updated: Date.now(),
        // 🆕 智能合并关联数据
        relatedData: this.mergeRelatedData(currentEntity.relatedData, updates.relatedData),
        // 🆕 重新计算统计信息
        statistic: this.recalculateStatistics(currentEntity, updates)
      };

      // 🆕 判断是否需要立即更新documents和embedding
      // 特别处理：name改变时必须更新embedding
      const nameChanged = updates.name && updates.name !== currentEntity.name;
      const shouldUpdateDocuments = nameChanged || this.shouldUpdateDocuments(mergedEntity, updates);
      let documents = existing.documents?.[0] || '';
      let embedding = [];
      let naturalDescription = '';
      if (shouldUpdateDocuments) {
        console.log(`📝 重要实体${mergedEntity.name}立即更新documents和embedding...`);
        // 🆕 方案E: 用精简文本生成embedding
        documents = this.generateSimpleDocument(mergedEntity);
        embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(documents);
        // 🆕 生成完整描述
        naturalDescription = await this.generateNaturalLanguageDescription(mergedEntity);
        mergedEntity.lastDocumentUpdate = Date.now();
      } else {
        console.log(`⏳ 普通实体${mergedEntity.name}延迟更新documents`);
        // 保持原有embedding，不重新计算
        const existingResult = await collection.get({
          ids: [entityId],
          include: ['embeddings']
        });
        embedding = existingResult.embeddings?.[0] || [];
        // 保持原有description
        naturalDescription = currentEntity.description || '';
      }

      // 转换为ChromaDB格式，包含description
      const chromaMetadata = this.serializeChromaMetadata({
        ...mergedEntity,
        description: naturalDescription // 完整描述存储在metadata中
      });

      // 执行更新
      await collection.update({
        ids: [entityId],
        documents: [documents],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      console.log(`✅ 实体更新完成: ${mergedEntity.name}, documents更新: ${shouldUpdateDocuments ? '是' : '否'}`);
      return true;
    } catch (error) {
      console.error('更新实体失败:', error);
      return false;
    }
  }

  /**
   * 删除实体
   */
  async deleteEntity(entityId) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return false;
      await collection.delete({
        ids: [entityId]
      });
      return true;
    } catch (error) {
      console.error('删除实体失败:', error);
      return false;
    }
  }

  /**
   * 🆕 判断是否应该立即更新documents
   */
  shouldUpdateDocuments(entity, updates) {
    // 1. 高重要性实体 (importance > 0.7)
    if (entity.importance && entity.importance > 0.7) return true;

    // 2. 高热度实体 (hotness > 0.6)  
    if (entity.hotness && entity.hotness > 0.6) return true;

    // 3. 关键性评分高的实体 (criticalityScore > 0.8)
    if (entity.criticalityScore && entity.criticalityScore > 0.8) return true;

    // 4. 长时间未更新documents的实体 (超过24小时)
    const daysSinceLastUpdate = entity.lastDocumentUpdate ? (Date.now() - entity.lastDocumentUpdate) / (1000 * 60 * 60 * 24) : 999;
    if (daysSinceLastUpdate > 1) return true;

    // 5. 如果关联数据有重大变化（新增5条以上记录）
    const hasSignificantDataChanges = updates.relatedData && (updates.relatedData.conversations && updates.relatedData.conversations.length > 5 || updates.relatedData.projects && updates.relatedData.projects.length > 2 || updates.relatedData.jiraTickets && updates.relatedData.jiraTickets.length > 3);
    if (hasSignificantDataChanges) return true;
    return false;
  }

  /**
   * 🆕 智能合并关联数据
   */
  mergeRelatedData() {
    let current = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    let updates = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    const merged = {
      ...current
    };

    // 合并各类关联数据，保持最多50条记录
    const dataTypes = ['conversations', 'webpages', 'resources', 'projects', 'people', 'topics', 'jiraTickets', 'cooccurringEntities'];
    for (const type of dataTypes) {
      if (updates[type]) {
        // 合并并去重（基于id）
        const currentItems = merged[type] || [];
        const newItems = updates[type] || [];
        const allItems = [...currentItems];
        newItems.forEach(newItem => {
          const existingIndex = allItems.findIndex(item => item.id === newItem.id);
          if (existingIndex >= 0) {
            // 更新现有项目，但保护特定字段不被覆盖
            const existingItem = allItems[existingIndex];

            // 🆕 对于conversations类型，保护已读状态
            if (type === 'conversations') {
              allItems[existingIndex] = {
                ...existingItem,
                ...newItem,
                // 保护已读状态：如果已存在的是已读，则保持已读
                isRead: existingItem.isRead !== undefined ? existingItem.isRead : newItem.isRead || false,
                readTimestamp: existingItem.readTimestamp !== undefined ? existingItem.readTimestamp : newItem.readTimestamp
              };
            } else {
              allItems[existingIndex] = {
                ...existingItem,
                ...newItem
              };
            }
          } else {
            // 添加新项目
            // 🆕 对于conversations类型，确保新消息有isRead字段
            if (type === 'conversations') {
              allItems.push({
                ...newItem,
                isRead: newItem.isRead !== undefined ? newItem.isRead : false,
                readTimestamp: newItem.readTimestamp
              });
            } else {
              allItems.push(newItem);
            }
          }
        });

        // 按相关性和时间排序，保留最多50条
        allItems.sort((a, b) => {
          // 优先按相关性排序，然后按时间
          const scoreA = (a.relevanceScore || 0) * 100 + new Date(a.datetime || a.visitTime || Date.now()).getTime() / 1000000;
          const scoreB = (b.relevanceScore || 0) * 100 + new Date(b.datetime || b.visitTime || Date.now()).getTime() / 1000000;
          return scoreB - scoreA;
        });
        merged[type] = allItems.slice(0, 50);
      }
    }
    return merged;
  }

  /**
   * 🆕 重新计算统计信息
   */
  recalculateStatistics(current, updates) {
    const relatedData = updates.relatedData || current.relatedData || {
      conversations: [],
      webpages: [],
      resources: [],
      projects: [],
      people: [],
      topics: [],
      jiraTickets: [],
      cooccurringEntities: []
    };
    return {
      conversations: relatedData.conversations?.length || 0,
      projects: relatedData.projects?.length || 0,
      participants: relatedData.people?.length || 0,
      resources: relatedData.resources?.length || 0,
      documents: relatedData.resources?.filter(r => r.type === 'document')?.length || 0,
      webpages: relatedData.webpages?.length || 0,
      topics: relatedData.topics?.length || 0,
      jiraTickets: relatedData.jiraTickets?.length || 0,
      relationships: relatedData.cooccurringEntities?.length || 0
    };
  }

  /**
   * 获取时间轴数据
   */
  async getTimeline() {
    let limit = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 50;
    this.ensureInitialized();
    try {
      const results = [];

      // 从消息集合获取最近数据
      const messageCollection = this.collections.get(`${this.username}-messages`);
      if (messageCollection) {
        const messageResults = await messageCollection.get({
          limit: limit / 2,
          include: ['metadatas', 'documents']
        });
        if (messageResults.metadatas && messageResults.documents) {
          for (let i = 0; i < messageResults.metadatas.length; i++) {
            const metadata = messageResults.metadatas[i];
            const document = messageResults.documents[i];
            results.push({
              id: `msg_${i}`,
              type: 'message',
              title: metadata.summary || '消息记录',
              content: document.substring(0, 200) + '...',
              timestamp: metadata.timestamp || Date.now(),
              sender: metadata.sender || metadata.source || 'unknown',
              metadata
            });
          }
        }
      }

      // 从网页集合获取最近数据
      const webpageCollection = this.collections.get(`${this.username}-webpages`);
      if (webpageCollection) {
        const webpageResults = await webpageCollection.get({
          limit: limit / 2,
          include: ['metadatas', 'documents']
        });
        if (webpageResults.metadatas && webpageResults.documents) {
          for (let i = 0; i < webpageResults.metadatas.length; i++) {
            const metadata = webpageResults.metadatas[i];
            const document = webpageResults.documents[i];
            results.push({
              id: `web_${i}`,
              type: 'webpage',
              title: metadata.title || '网页访问',
              content: document.substring(0, 200) + '...',
              timestamp: metadata.extractedAt || Date.now(),
              source: metadata.domain || 'unknown',
              metadata
            });
          }
        }
      }

      // 按时间排序
      return results.sort((a, b) => b.timestamp - a.timestamp).slice(0, limit);
    } catch (error) {
      console.error('获取时间轴数据失败:', error);
      return [];
    }
  }

  /**
   * 反序列化 metadata 中的对象字段
   */
  deserializeMetadata(metadata) {
    const processed = {
      ...metadata
    };
    try {
      // 反序列化 contextMessages 字段
      if (processed.contextMessages && typeof processed.contextMessages === 'string') {
        processed.contextMessages = JSON.parse(processed.contextMessages);
      }
    } catch (error) {
      // 忽略解析错误
    }
    try {
      // 反序列化 matchedRules 字段
      if (processed.matchedRules && typeof processed.matchedRules === 'string') {
        processed.matchedRules = JSON.parse(processed.matchedRules);
      }
    } catch (error) {
      // 忽略解析错误
    }
    try {
      // 反序列化 entities 字段
      if (processed.entities && typeof processed.entities === 'string') {
        processed.entities = JSON.parse(processed.entities);
      }
    } catch (error) {
      // 忽略解析错误
    }
    try {
      // 反序列化 relationships 字段
      if (processed.relationships && typeof processed.relationships === 'string') {
        processed.relationships = JSON.parse(processed.relationships);
      }
    } catch (error) {
      // 忽略解析错误
    }
    try {
      // 反序列化 metadata 嵌套字段
      if (processed.metadata && typeof processed.metadata === 'string') {
        processed.metadata = JSON.parse(processed.metadata);
      }
    } catch (error) {
      // 忽略解析错误
    }
    try {
      // 反序列化 actions 字段
      if (processed.actions && typeof processed.actions === 'string') {
        processed.actions = JSON.parse(processed.actions);
      }
    } catch (error) {
      // 忽略解析错误
    }
    return processed;
  }

  /**
   * 获取云端实体数量
   */
  async getEntityCount() {
    if (!this.client) return 0;
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return 0;
      const result = await collection.get({
        limit: 1
      });
      return result.ids?.length || 0;
    } catch (error) {
      console.error('获取实体数量失败:', error);
      return 0;
    }
  }

  /**
   * 备份关系数据到云端
   */
  async backupRelationships(relationshipData) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return false;
      const backupId = `graph-backup-${Date.now()}`;
      const backupContent = JSON.stringify({
        ...relationshipData,
        backupTime: Date.now()
      });
      const embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(backupContent);
      const chromaMetadata = this.serializeChromaMetadata({
        type: 'graph_backup',
        backupTime: Date.now(),
        relationshipCount: relationshipData.relationships.length
      });
      await collection.add({
        ids: [backupId],
        documents: [backupContent],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      console.log(`☁️ 关系数据已备份: ${backupId}`);
      return true;
    } catch (error) {
      console.error('备份关系数据失败:', error);
      return false;
    }
  }

  /**
   * 从云端恢复关系数据
   */
  async restoreRelationships() {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) return null;

      // 查找最新备份
      const result = await collection.get({
        where: {
          type: 'graph_backup'
        },
        include: ['metadatas', 'documents']
      });
      if (!result.ids || result.ids.length === 0) {
        console.log('📭 云端没有找到关系数据备份');
        return null;
      }

      // 获取最新备份
      const latestBackupIndex = result.metadatas.map((meta, index) => ({
        meta,
        index
      })).sort((a, b) => (b.meta.backupTime || 0) - (a.meta.backupTime || 0))[0].index;
      const backupContent = result.documents[latestBackupIndex];
      const backupData = JSON.parse(backupContent);
      console.log(`📥 恢复关系数据: ${backupData.relationships?.length || 0} 个关系`);
      return {
        relationships: backupData.relationships || [],
        entityToRelations: backupData.entityToRelations || [],
        typeToEntities: backupData.typeToEntities || []
      };
    } catch (error) {
      console.error('恢复关系数据失败:', error);
      return null;
    }
  }

  /**
   * 批量操作
   */
  async batchStore(items) {
    this.ensureInitialized();
    let success = 0;
    let failed = 0;
    const batches = this.chunkArray(items, this.config.batchSize);
    for (const batch of batches) {
      try {
        await Promise.all(batch.map(async item => {
          try {
            switch (item.type) {
              case 'entity':
                await this.storeEntity(item.data);
                break;
              case 'message':
                await this.storeMessage(item.data);
                break;
              case 'webpage':
                await this.storeWebpage(item.data);
                break;
            }
            success++;
          } catch (error) {
            failed++;
            console.error(`批量存储失败 (${item.type}):`, error);
          }
        }));
      } catch (error) {
        failed += batch.length;
        console.error('批量存储失败:', error);
      }
    }
    return {
      success,
      failed
    };
  }

  // ==================== 私有方法 ====================

  /**
   * 🆕 生成实体ID - 移入内部方法
   */
  generateEntityId(type, name) {
    const sanitizedType = type.replace(/[^a-zA-Z0-9]/g, '');
    const sanitizedName = this.sanitizeName(name);
    const shortUuid = (0,uuid__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A)().substring(0, 8);
    return `${sanitizedType}_${sanitizedName}_${shortUuid}`;
  }

  /**
   * 清理实体名称，处理中文和特殊字符
   */
  sanitizeName(name) {
    if (!name || name.trim() === '') {
      return 'entity';
    }

    // 简单的中文转拼音映射（部分常用字符）
    const chineseToPinyin = {
      '项目': 'xiangmu',
      '文档': 'wendang',
      '人员': 'renyuan',
      '主题': 'zhuti',
      '任务': 'renwu',
      '团队': 'tuandui',
      '公司': 'gongsi',
      '系统': 'xitong',
      '数据': 'shuju',
      '功能': 'gongneng',
      '需求': 'xuqiu',
      '设计': 'sheji',
      '开发': 'kaifa',
      '测试': 'ceshi',
      '部署': 'bushu',
      '维护': 'weihu',
      '管理': 'guanli',
      '分析': 'fenxi',
      '报告': 'baogao',
      '会议': 'huiyi',
      '刘': 'liu',
      '陈': 'chen',
      '王': 'wang',
      '李': 'li',
      '张': 'zhang',
      '赵': 'zhao',
      '孙': 'sun',
      '周': 'zhou',
      '吴': 'wu',
      '郑': 'zheng'
    };
    let cleanName = name.trim();

    // 替换中文词汇为拼音
    for (const [chinese, pinyin] of Object.entries(chineseToPinyin)) {
      cleanName = cleanName.replace(new RegExp(chinese, 'g'), pinyin);
    }

    // 移除其他中文字符（通过Unicode范围）
    cleanName = cleanName.replace(/[\u4e00-\u9fff]/g, '');

    // 只保留字母、数字和连字符
    cleanName = cleanName.replace(/[^a-zA-Z0-9\-_]/g, '');

    // 移除多余的连字符和下划线
    cleanName = cleanName.replace(/[-_]+/g, '_');

    // 移除开头和结尾的连字符和下划线
    cleanName = cleanName.replace(/^[-_]+|[-_]+$/g, '');

    // 限制长度并确保不为空
    if (cleanName.length === 0) {
      cleanName = 'entity';
    } else if (cleanName.length > 15) {
      cleanName = cleanName.substring(0, 15);
    }

    // 确保以字母开头
    if (!/^[a-zA-Z]/.test(cleanName)) {
      cleanName = 'entity_' + cleanName;
    }
    return cleanName.toLowerCase();
  }
  async initializeCollections() {
    if (!this.client) throw new Error('ChromaDB 客户端未初始化');

    // ChromaDB v3: 显式指定嵌入函数，防止默认加载 @chroma-core/default-embed
    const nullEmbeddingFunction = new NullEmbeddingFunction();
    for (const collectionType of this.config.collections) {
      const collectionName = `${this.username}-${collectionType}`;
      try {
        const collection = await this.client.getOrCreateCollection({
          name: collectionName,
          embeddingFunction: nullEmbeddingFunction,
          metadata: {
            "hnsw:space": "cosine"
          } // 明确指定使用余弦距离
        });
        this.collections.set(collectionName, collection);
        console.log(`✅ 集合已初始化: ${collectionName}`);
      } catch (error) {
        console.error(`❌ 初始化集合失败: ${collectionName}`, error);
      }
    }
  }
  async getUserInfo() {
    try {
      const result = await chrome.storage.local.get(['userinfo']);
      return result.userinfo || {
        username: 'default-user'
      };
    } catch (error) {
      console.warn('获取用户信息失败，使用默认值');
      return {
        username: 'default-user'
      };
    }
  }
  async buildEntity(entityData) {
    try {
      const {
        id,
        document,
        distance,
        relevanceScore,
        collectionName
      } = entityData;
      const metadata = this.deserializeEntityFromMetadata(entityData.metadata);
      if (collectionName.includes('graph-entities')) {
        return {
          id,
          type: metadata.type || 'Document',
          name: metadata.name || '未知实体',
          document,
          description: metadata.description || '',
          properties: typeof metadata.properties === 'string' ? JSON.parse(metadata.properties || '{}') : metadata.properties || {},
          created: metadata.created || Date.now(),
          updated: metadata.updated || Date.now(),
          accessCount: metadata.accessCount || 0,
          lastAccessed: metadata.lastAccessed || Date.now(),
          importance: metadata.importance || 0.5,
          tags: metadata.tags || [],
          status: metadata.status || 'active',
          statistic: metadata.statistic || {
            conversations: 0,
            projects: 0,
            participants: 0,
            resources: 0,
            documents: 0,
            webpages: 0,
            relationships: 0,
            topics: 0,
            jiraTickets: 0
          },
          relatedData: metadata.relatedData || {
            conversations: [],
            webpages: [],
            resources: [],
            projects: [],
            people: [],
            topics: [],
            jiraTickets: [],
            cooccurringEntities: []
          },
          // 添加搜索相关信息
          ...(distance !== undefined && {
            searchDistance: distance
          }),
          ...(relevanceScore !== undefined && {
            relevanceScore
          })
        };
      }

      // 从其他集合构建虚拟实体
      return {
        id: id || `virtual_${Date.now()}_${Math.random()}`,
        type: 'Document',
        name: metadata.name || '相关内容',
        document: document || '相关内容',
        properties: {
          ...metadata,
          ...(document && {
            originalDocument: document
          }),
          collectionSource: collectionName
        },
        created: metadata.created || Date.now(),
        updated: metadata.updated || Date.now(),
        accessCount: metadata.accessCount || 1,
        lastAccessed: metadata.lastAccessed || Date.now(),
        importance: metadata.importance || 0.3,
        tags: metadata.tags || [],
        status: metadata.status || 'active',
        statistic: metadata.statistic || {
          conversations: 0,
          projects: 0,
          participants: 0,
          resources: 0,
          documents: 0,
          webpages: 0,
          relationships: 0,
          topics: 0,
          jiraTickets: 0
        },
        relatedData: metadata.relatedData || {
          conversations: [],
          webpages: [],
          resources: [],
          projects: [],
          people: [],
          topics: [],
          jiraTickets: [],
          cooccurringEntities: []
        },
        // 添加搜索相关信息
        ...(distance !== undefined && {
          searchDistance: distance
        }),
        ...(relevanceScore !== undefined && {
          relevanceScore
        })
      };
    } catch (error) {
      console.error('构建实体失败:', error);
      return null;
    }
  }
  chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

  /**
   * 存储用户画像到云端
   */
  async storeUserProfile(userId, profile) {
    this.ensureInitialized();
    try {
      // 获取或创建用户画像集合
      const collectionName = `${this.username}-userprofiles`;
      let collection = this.collections.get(collectionName);
      if (!collection) {
        collection = await this.client.getOrCreateCollection({
          name: collectionName,
          metadata: {
            type: 'user_profiles',
            "hnsw:space": "cosine"
          },
          embeddingFunction: new NullEmbeddingFunction()
        });
        this.collections.set(collectionName, collection);
      }

      // 为用户画像创建向量表示
      const profileText = this.createProfileText(profile);
      const embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(profileText);

      // 存储用户画像
      const chromaMetadata = this.serializeChromaMetadata({
        userId: userId,
        lastUpdated: profile.lastUpdated,
        createdAt: profile.createdAt,
        totalInteractions: profile.statistics.totalInteractions,
        profileData: JSON.stringify(profile)
      });
      await collection.upsert({
        ids: [userId],
        documents: [profileText],
        embeddings: [embedding],
        metadatas: [chromaMetadata]
      });
      console.log(`✅ 用户画像 ${userId} 已存储到云端`);
      return true;
    } catch (error) {
      console.error('存储用户画像到云端失败:', error);
      return false;
    }
  }

  /**
   * 从云端获取用户画像
   */
  async getUserProfile(userId) {
    this.ensureInitialized();
    try {
      const collectionName = `${this.username}-userprofiles`;
      const collection = this.collections.get(collectionName);
      if (!collection) {
        return null;
      }
      const result = await collection.get({
        ids: [userId],
        include: ['metadatas']
      });
      if (result.metadatas && result.metadatas.length > 0) {
        const metadata = this.deserializeChromaMetadata(result.metadatas[0]);
        if (metadata.profileData) {
          return JSON.parse(metadata.profileData);
        }
      }
      return null;
    } catch (error) {
      console.error('从云端获取用户画像失败:', error);
      return null;
    }
  }

  // =====================================
  // 🆕 用户档案存储方法
  // =====================================

  /**
   * 存储用户档案记录
   */
  async storeUserprofilesRecord(record) {
    this.ensureInitialized();
    try {
      const collectionName = `${this.username}-userprofiles`;
      let collection = this.collections.get(collectionName);
      if (!collection) {
        collection = await this.client.getOrCreateCollection({
          name: collectionName,
          metadata: {
            type: 'vectorized_user_profiles',
            "hnsw:space": "cosine"
          },
          embeddingFunction: new NullEmbeddingFunction()
        });
        this.collections.set(collectionName, collection);
      }

      // 生成嵌入向量（如果没有提供）
      let embedding = record.embedding;
      if (!embedding) {
        embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(record.document);
      }
      const metadata = this.serializeChromaMetadata(record.metadata);

      // 存储记录
      await collection.upsert({
        ids: [record.id],
        documents: [record.document],
        embeddings: [embedding],
        metadatas: [metadata]
      });

      // console.log(`✅ 用户档案记录 ${record.id} 已存储`);
      return true;
    } catch (error) {
      console.error('存储用户档案记录失败:', error);
      return false;
    }
  }

  /**
   * 批量存储用户档案记录
   */
  async storeUserprofilesRecordsBatch(records) {
    this.ensureInitialized();
    let successCount = 0;
    const batchSize = this.userprofilesMaintenanceConfig.vector_update.batch_size;
    for (let i = 0; i < records.length; i += batchSize) {
      const batch = records.slice(i, i + batchSize);
      try {
        const collectionName = `${this.username}-userprofiles`;
        let collection = this.collections.get(collectionName);
        if (!collection) {
          collection = await this.client.getOrCreateCollection({
            name: collectionName,
            metadata: {
              type: 'vectorized_user_profiles',
              "hnsw:space": "cosine"
            },
            embeddingFunction: new NullEmbeddingFunction()
          });
          this.collections.set(collectionName, collection);
        }

        // 准备批量数据
        const ids = batch.map(r => r.id);
        const documents = batch.map(r => r.document);
        const metadatas = batch.map(r => this.serializeChromaMetadata(r.metadata));

        // 生成嵌入向量
        const embeddings = await Promise.all(batch.map(r => r.embedding || (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(r.document)));

        // 批量存储
        await collection.upsert({
          ids,
          documents,
          embeddings,
          metadatas: metadatas
        });
        successCount += batch.length;
        console.log(`✅ 批量存储 ${batch.length} 条用户档案记录`);
      } catch (error) {
        console.error(`批量存储失败 (batch ${Math.floor(i / batchSize) + 1}):`, error);
      }
    }
    return successCount;
  }

  /**
   * 查找相似用户
   */
  async findSimilarUsers(currentUserId, query) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const {
      record_types,
      limit = 10,
      similarity_threshold = 0.6
    } = options;
    const queryResult = await this.searchByVector(query, undefined, {
      collections: ['userprofiles'],
      returnType: 'userprofiles',
      where: {
        record_type: {
          $in: record_types
        },
        user_id: {
          $ne: currentUserId
        }
      },
      minRelevanceScore: similarity_threshold,
      limit: 100
    });

    // 按用户聚合结果
    const userMatches = new Map();
    queryResult.data.forEach((record, index) => {
      const userId = record.metadata.user_id;
      const similarity = record.relevanceScore || 0;
      if (!userMatches.has(userId)) {
        userMatches.set(userId, {
          similarity_scores: [],
          matching_categories: new Set(),
          matching_items: []
        });
      }
      const userMatch = userMatches.get(userId);
      userMatch.similarity_scores.push(similarity);
      userMatch.matching_categories.add(record.metadata.record_type);
      if ('name' in record.metadata) {
        userMatch.matching_items.push(record.metadata.name);
      }
    });

    // 计算综合相似度并格式化结果
    const results = [];
    for (const [userId, matches] of Array.from(userMatches.entries())) {
      const avgSimilarity = matches.similarity_scores.reduce((sum, score) => sum + score, 0) / matches.similarity_scores.length;
      results.push({
        user_id: userId,
        similarity_score: avgSimilarity,
        matching_categories: Array.from(matches.matching_categories).map(category => ({
          category: category,
          similarity: avgSimilarity,
          matching_items: matches.matching_items
        })),
        total_matches: matches.similarity_scores.length
      });
    }
    return results.sort((a, b) => b.similarity_score - a.similarity_score).slice(0, limit);
  }

  /**
   * 删除用户的档案记录
   */
  async deleteUserProfilesRecords(userId) {
    this.ensureInitialized();
    try {
      const collectionName = `${this.username}-userprofiles`;
      const collection = this.collections.get(collectionName);
      if (!collection) {
        return true; // 集合不存在，认为删除成功
      }

      // 查找用户的所有记录
      const userRecords = await collection.get({
        where: {
          user_id: userId
        },
        include: ['metadatas']
      });
      if (userRecords.ids && userRecords.ids.length > 0) {
        // 批量删除
        await collection.delete({
          ids: userRecords.ids
        });
        console.log(`🗑️ 删除用户 ${userId} 的 ${userRecords.ids.length} 条用户档案记录`);
      }
      return true;
    } catch (error) {
      console.error('删除用户档案记录失败:', error);
      return false;
    }
  }

  /**
   * 获取用户档案存储统计信息
   */
  async getUserprofilesStorageStats() {
    this.ensureInitialized();
    try {
      const collectionName = `${this.username}-userprofiles`;
      const collection = this.collections.get(collectionName);
      if (!collection) {
        return {
          total_records: 0,
          records_by_type: {},
          records_by_user: {},
          storage_size_mb: 0,
          last_maintenance: 0,
          health_score: 1.0
        };
      }

      // 获取所有记录的元数据
      const allRecords = await collection.get({
        include: ['metadatas']
      });
      const stats = {
        total_records: allRecords.ids?.length || 0,
        records_by_type: {},
        records_by_user: {},
        storage_size_mb: 0,
        last_maintenance: 0,
        health_score: 1.0
      };
      if (allRecords.metadatas) {
        allRecords.metadatas.forEach(metadata => {
          const meta = metadata;

          // 按类型统计
          const recordType = meta.record_type || 'unknown';
          stats.records_by_type[recordType] = (stats.records_by_type[recordType] || 0) + 1;

          // 按用户统计
          const userId = meta.user_id || 'unknown';
          stats.records_by_user[userId] = (stats.records_by_user[userId] || 0) + 1;
        });
      }

      // 估算存储大小（简化计算）
      stats.storage_size_mb = Math.round(stats.total_records * 0.1); // 假设每条记录约0.1MB

      // 计算健康度（基于记录分布和完整性）
      const typeCount = Object.keys(stats.records_by_type).length;
      const userCount = Object.keys(stats.records_by_user).length;
      stats.health_score = Math.min(1.0, typeCount * userCount / (stats.total_records || 1));
      return stats;
    } catch (error) {
      console.error('获取用户档案存储统计失败:', error);
      return {
        total_records: 0,
        records_by_type: {},
        records_by_user: {},
        storage_size_mb: 0,
        last_maintenance: 0,
        health_score: 0
      };
    }
  }

  /**
   * 用户档案数据维护
   */
  async performUserprofilesMaintenance() {
    this.ensureInitialized();
    const result = {
      cleaned_records: 0,
      updated_records: 0,
      created_summaries: 0,
      errors: []
    };
    try {
      const collectionName = `${this.username}-userprofiles`;
      const collection = this.collections.get(collectionName);
      if (!collection) {
        return result;
      }
      console.log('🔧 开始用户档案数据维护...');

      // 1. 清理过期/低权重记录
      try {
        const cleanupThreshold = Date.now() - this.userprofilesMaintenanceConfig.cleanup_thresholds.max_age_days * 24 * 60 * 60 * 1000;
        const oldRecords = await collection.get({
          where: {
            $or: [{
              updated_at: {
                $lt: cleanupThreshold
              }
            }, {
              current_weight: {
                $lt: this.userprofilesMaintenanceConfig.cleanup_thresholds.min_weight
              }
            }]
          },
          include: ['metadatas']
        });
        if (oldRecords.ids && oldRecords.ids.length > 0) {
          await collection.delete({
            ids: oldRecords.ids
          });
          result.cleaned_records = oldRecords.ids.length;
          console.log(`🗑️ 清理了 ${result.cleaned_records} 条过期记录`);
        }
      } catch (error) {
        result.errors.push(`清理记录失败: ${error}`);
      }

      // 2. 更新向量表示（重新计算embedding）
      if (this.userprofilesMaintenanceConfig.vector_update.enable_batch_update) {
        try {
          // 找到需要更新的记录（这里简化为随机选择部分记录）
          const allRecords = await collection.get({
            limit: this.userprofilesMaintenanceConfig.vector_update.batch_size,
            include: ['documents', 'metadatas']
          });
          if (allRecords.documents && allRecords.metadatas && allRecords.ids) {
            const updatedEmbeddings = await Promise.all(allRecords.documents[0].map(doc => (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(doc)));
            await collection.upsert({
              ids: allRecords.ids,
              documents: allRecords.documents[0],
              embeddings: updatedEmbeddings,
              metadatas: allRecords.metadatas[0]
            });
            result.updated_records = allRecords.ids.length;
            console.log(`🔄 更新了 ${result.updated_records} 条记录的向量表示`);
          }
        } catch (error) {
          result.errors.push(`更新向量失败: ${error}`);
        }
      }

      // 3. 生成用户概要记录
      if (this.userprofilesMaintenanceConfig.aggregation_rules.enable_auto_summary) {
        try {
          const userStats = await this.getUserprofilesStorageStats();
          for (const userId of Object.keys(userStats.records_by_user)) {
            // 检查是否需要创建或更新概要
            const existingSummary = await collection.get({
              where: {
                user_id: userId,
                record_type: 'user_summary'
              },
              limit: 1
            });
            if (!existingSummary.ids || existingSummary.ids.length === 0) {
              // 创建新的用户概要
              const summaryRecord = await this.generateUserSummaryRecord(userId);
              if (summaryRecord) {
                await this.storeUserprofilesRecord(summaryRecord);
                result.created_summaries++;
              }
            }
          }
          console.log(`📊 创建了 ${result.created_summaries} 个用户概要记录`);
        } catch (error) {
          result.errors.push(`生成概要失败: ${error}`);
        }
      }
      console.log('✅ 用户档案数据维护完成');
      return result;
    } catch (error) {
      console.error('用户档案数据维护失败:', error);
      result.errors.push(`维护过程失败: ${error}`);
      return result;
    }
  }

  /**
   * 生成用户概要记录
   */
  async generateUserSummaryRecord(userId) {
    try {
      // 获取用户的所有记录
      const userRecords = await this.queryUserprofiles({
        user_id: userId,
        limit: 1000,
        record_types: ['interest_item', 'behavior_pattern', 'social_relationship', 'expertise_area']
      });
      if (userRecords.records.length === 0) {
        return null;
      }

      // 统计分析
      const recordsByType = userRecords.records.reduce((acc, record) => {
        const type = record.metadata.record_type;
        acc[type] = (acc[type] || 0) + 1;
        return acc;
      }, {});

      // 计算权重分布
      const weights = userRecords.records.map(r => r.metadata.current_weight).filter(w => typeof w === 'number');
      const weightDistribution = {
        high_weight_items: weights.filter(w => w > 0.7).length,
        medium_weight_items: weights.filter(w => w >= 0.3 && w <= 0.7).length,
        low_weight_items: weights.filter(w => w < 0.3).length
      };

      // 生成概要文本
      const summaryText = `用户 ${userId} 的画像概要：
        总记录数: ${userRecords.records.length}
        记录类型分布: ${Object.entries(recordsByType).map(_ref3 => {
        let [type, count] = _ref3;
        return `${type}: ${count}`;
      }).join(', ')}
        权重分布: 高权重${weightDistribution.high_weight_items}项, 中权重${weightDistribution.medium_weight_items}项, 低权重${weightDistribution.low_weight_items}项
        活跃领域: ${Object.keys(recordsByType).join(', ')}`;
      const summaryRecord = {
        id: `${userId}_summary_${Date.now()}`,
        document: summaryText,
        metadata: {
          record_type: 'user_summary',
          summary_type: 'overall',
          user_id: userId,
          created_at: Date.now(),
          updated_at: Date.now(),
          total_records: userRecords.records.length,
          summary_period: {
            start: Math.min(...userRecords.records.map(r => r.metadata.created_at)),
            end: Date.now()
          },
          weight_distribution: weightDistribution,
          activity_metrics: {
            avg_daily_interactions: weights.length / 30,
            // 简化计算
            peak_activity_hour: 9,
            // 简化为固定值
            active_days_count: Math.min(30, weights.length)
          },
          growth_trends: {
            new_interests_per_month: 0,
            skill_development_rate: 0,
            social_network_growth: 0
          },
          auto_generated: true,
          generation_algorithm: 'v1.0'
        }
      };
      return summaryRecord;
    } catch (error) {
      console.error('生成用户概要记录失败:', error);
      return null;
    }
  }

  /**
   * 创建用户画像的文本表示（用于向量化）
   */
  createProfileText(profile) {
    const parts = [];

    // 用户ID和基本信息
    parts.push(`用户: ${profile.userId}`);

    // 兴趣项目
    if (profile.interests.projects.length > 0) {
      parts.push('关注项目: ' + profile.interests.projects.slice(0, 5).map(p => `${p.name}(权重:${p.currentWeight.toFixed(2)})`).join(', '));
    }

    // 关注人员
    if (profile.interests.people.length > 0) {
      parts.push('关注人员: ' + profile.interests.people.slice(0, 5).map(p => `${p.name}(权重:${p.currentWeight.toFixed(2)})`).join(', '));
    }

    // 技术栈
    if (profile.interests.technologies.length > 0) {
      parts.push('技术栈: ' + profile.interests.technologies.slice(0, 5).map(t => `${t.name}(权重:${t.currentWeight.toFixed(2)})`).join(', '));
    }

    // 主题
    if (profile.interests.topics.length > 0) {
      parts.push('关注主题: ' + profile.interests.topics.slice(0, 5).map(t => `${t.name}(权重:${t.currentWeight.toFixed(2)})`).join(', '));
    }

    // 专业领域
    if (profile.derivedPreferences.expertiseAreas.length > 0) {
      parts.push('专业领域: ' + profile.derivedPreferences.expertiseAreas.join(', '));
    }

    // 统计信息
    parts.push(`总交互次数: ${profile.statistics.totalInteractions}`);
    parts.push(`日均活动: ${profile.statistics.averageDailyActivity.toFixed(1)}`);
    return parts.join('\n');
  }

  /**
   * 备份关系数据到独立的关系集合
   */
  async backupRelationshipsToCollection(relationshipData) {
    this.ensureInitialized();
    try {
      if (!relationshipData.relationships || relationshipData.relationships.length === 0) {
        console.log('📭 没有关系数据需要备份');
        return true;
      }
      const relationshipCollectionName = `${this.username}-graph-relationships`;

      // 获取或创建关系集合
      let relationshipCollection;
      try {
        relationshipCollection = await this.client.getOrCreateCollection({
          name: relationshipCollectionName,
          metadata: {
            type: 'relationships',
            "hnsw:space": "cosine"
          },
          embeddingFunction: new NullEmbeddingFunction()
        });
      } catch (error) {
        console.error('❌ 无法创建关系集合:', error);
        return false;
      }
      const relationships = relationshipData.relationships || [];
      let storedCount = 0;

      // 按实体类型和时间进行分组存储，减少数据量
      const groupedRelationships = this.groupRelationshipsForStorage(relationships);
      for (const [groupKey, groupData] of Object.entries(groupedRelationships)) {
        try {
          const groupDoc = {
            id: `rel-group-${groupKey}-${Date.now()}`,
            groupKey,
            relationshipCount: groupData.relationships.length,
            timeRange: groupData.timeRange,
            entityTypes: groupData.entityTypes,
            relationshipTypes: groupData.relationshipTypes,
            createdAt: Date.now(),
            data: JSON.stringify(groupData.relationships)
          };

          // 为文档内容生成向量（用于检索）
          const searchableContent = [`关系组 ${groupKey}`, `实体类型: ${groupData.entityTypes.join(', ')}`, `关系类型: ${groupData.relationshipTypes.join(', ')}`, `时间范围: ${new Date(groupData.timeRange.start).toLocaleDateString()} - ${new Date(groupData.timeRange.end).toLocaleDateString()}`].join('\n');
          const embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(searchableContent);
          await relationshipCollection.add({
            ids: [groupDoc.id],
            documents: [searchableContent],
            embeddings: [embedding],
            metadatas: [groupDoc]
          });
          storedCount += groupData.relationships.length;
        } catch (error) {
          console.error(`❌ 存储关系组 ${groupKey} 失败:`, error);
        }
      }
      console.log(`☁️ 关系数据已备份到独立集合: ${storedCount} 个关系，${Object.keys(groupedRelationships).length} 个分组`);
      return true;
    } catch (error) {
      console.error('❌ 云端备份关系数据失败:', error);
      return false;
    }
  }

  /**
   * 按类型和时间对关系进行分组，优化存储和检索
   */
  groupRelationshipsForStorage(relationships) {
    const groups = {};
    const timeSpan = 7 * 24 * 60 * 60 * 1000; // 7天为一组

    for (const [id, relationship] of relationships) {
      if (!relationship) continue;

      // 计算时间分组
      const timestamp = relationship.created || Date.now();
      const timeGroup = Math.floor(timestamp / timeSpan);

      // 获取实体类型（从 ID 推断）
      const fromType = this.getEntityTypeFromId(relationship.fromId);
      const toType = this.getEntityTypeFromId(relationship.toId);
      const entityTypesKey = [fromType, toType].sort().join('-');

      // 生成分组键：实体类型_关系类型_时间组
      const groupKey = `${entityTypesKey}_${relationship.type}_${timeGroup}`;
      if (!groups[groupKey]) {
        groups[groupKey] = {
          relationships: [],
          timeRange: {
            start: timeGroup * timeSpan,
            end: (timeGroup + 1) * timeSpan
          },
          entityTypes: [fromType, toType],
          relationshipTypes: new Set()
        };
      }
      groups[groupKey].relationships.push([id, relationship]);
      groups[groupKey].relationshipTypes.add(relationship.type);
    }

    // 转换 Set 为 Array
    Object.values(groups).forEach(group => {
      group.relationshipTypes = Array.from(group.relationshipTypes);
    });
    return groups;
  }

  /**
   * 从实体ID推断实体类型
   */
  getEntityTypeFromId(entityId) {
    if (!entityId) return 'Unknown';
    const parts = entityId.split('_');
    return parts[0] || 'Unknown';
  }

  /**
   * 将复杂元数据转换为 ChromaDB 兼容的格式
   * ChromaDB 只支持 string, number, boolean, null 类型
   */
  serializeChromaMetadata(metadata) {
    const converted = {};
    if (!metadata) return converted;

    // 递归处理函数
    const processValue = (key, value) => {
      if (value === null || value === undefined) {
        converted[key] = '';
      } else if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
        converted[key] = value;
      } else if (Array.isArray(value)) {
        // 数组转换为JSON字符串
        converted[key] = JSON.stringify(value);
      } else if (typeof value === 'object') {
        // 对象转换为JSON字符串
        converted[key] = JSON.stringify(value);
      } else {
        // 其他类型转换为字符串
        converted[key] = String(value);
      }
    };

    // 处理顶级字段
    for (const [key, value] of Object.entries(metadata)) {
      processValue(key, value);
    }
    return converted;
  }

  /**
   * 🆕 通用的ChromaDB metadata反序列化函数
   * 可以处理任意类型的metadata，自动判断字段类型并进行相应转换
   */
  deserializeChromaMetadata(metadata, defaultValues) {
    if (!metadata) return defaultValues || {};

    // 通用字段处理：自动判断字段类型并进行相应转换
    const processField = (value, fieldName, defaultValue) => {
      // 如果值为空，返回默认值
      if (value === null || value === undefined || value === '') {
        return defaultValue;
      }

      // 如果已经是正确类型，直接返回
      if (typeof value !== 'string') {
        return value;
      }

      // 尝试解析为 JSON（数组或对象）
      if (value.startsWith('{') && value.endsWith('}') || value.startsWith('[') && value.endsWith(']')) {
        try {
          return JSON.parse(value);
        } catch (error) {
          console.warn(`字段 ${fieldName} JSON解析失败:`, error);
          return defaultValue;
        }
      }

      // 判断是否为时间戳字段，如果是数字字符串且字段名包含时间相关词汇
      const timeFields = ['created', 'updated', 'lastAccessed', 'lastContact', 'lastDocumentUpdate', 'created_at', 'updated_at', 'timestamp', 'datetime', 'extractedAt'];
      if (timeFields.includes(fieldName) && /^\d+$/.test(value)) {
        return parseInt(value, 10);
      }

      // 判断是否为数字字段
      const numberFields = ['accessCount', 'importance', 'hotness', 'criticalityScore', 'current_weight', 'relevanceScore', 'total_interactions', 'total_records'];
      if (numberFields.includes(fieldName) && /^-?\d*\.?\d+$/.test(value)) {
        return parseFloat(value);
      }

      // 布尔字段处理
      if (value === 'true') return true;
      if (value === 'false') return false;

      // 其他情况保持字符串
      return value;
    };
    try {
      // 从默认值开始或创建新对象
      const result = defaultValues ? {
        ...defaultValues
      } : {};

      // 处理metadata中的所有字段
      for (const key in metadata) {
        if (metadata[key] !== undefined) {
          result[key] = processField(metadata[key], key, result[key]);
        }
      }
      return result;
    } catch (error) {
      console.error('反序列化ChromaDB metadata失败:', error);
      return defaultValues || {};
    }
  }

  /**
   * 🆕 从ChromaDB metadata反序列化实体（使用通用反序列化函数）
   */
  deserializeEntityFromMetadata(metadata) {
    // 默认值定义
    const defaults = {
      id: '',
      type: 'Document',
      name: '',
      document: '',
      properties: {},
      created: Date.now(),
      updated: Date.now(),
      accessCount: 0,
      lastAccessed: Date.now(),
      importance: 0.5,
      tags: [],
      status: 'active',
      statistic: {
        conversations: 0,
        projects: 0,
        participants: 0,
        resources: 0,
        documents: 0,
        webpages: 0,
        relationships: 0,
        topics: 0,
        jiraTickets: 0
      },
      relatedData: {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      },
      hotness: 0,
      criticalityScore: 0,
      lastDocumentUpdate: Date.now(),
      expertise: []
    };
    return this.deserializeChromaMetadata(metadata, defaults);
  }

  /**
   * 将基础 MemoryEntity 扩展为包含完整缓存数据的实体
   */
  async extendEntityToDetailCache(entity) {
    this.ensureInitialized();
    try {
      // 获取相关项目：优先使用 entity.relatedData.projects，否则向量搜索
      let relatedProjects = [];
      if (entity.relatedData?.projects && entity.relatedData.projects.length > 0) {
        // 使用现有的相关项目数据
        relatedProjects = entity.relatedData.projects.map(project => ({
          id: project.id || `project_${Date.now()}`,
          name: project.name || project.projectName || '未知项目',
          status: project.status || '开发中',
          description: project.document || `项目: ${project.name || project.projectName || '未命名项目'}`
        }));
        console.log(`📁 使用实体现有的项目数据: ${relatedProjects.length} 个`);
      } else {
        // 向量搜索相关项目
        try {
          const projectSearchResults = await this.searchByVector(`${entity.name} 项目`, 'Project', {
            limit: 5,
            returnType: 'entities'
          });
          relatedProjects = projectSearchResults.data.map(project => ({
            id: project.id,
            name: project.name || '未知项目',
            status: project.properties?.status || project.status || '开发中',
            description: project.document || `项目: ${project.name || '未命名项目'}`
          }));
          console.log(`🔍 通过向量搜索找到相关项目: ${relatedProjects.length} 个`);
        } catch (error) {
          console.warn('搜索相关项目失败:', error);
          relatedProjects = [];
        }
      }

      // 获取相关资源：优先使用 entity.relatedData.resources，否则向量搜索
      let relatedResources = [];
      if (entity.relatedData?.resources && entity.relatedData.resources.length > 0) {
        // 使用现有的相关资源数据
        relatedResources = entity.relatedData.resources.map(resource => ({
          id: resource.id || `resource_${Date.now()}`,
          name: resource.name || resource.title || '文档资源',
          type: resource.type || '文档',
          url: resource.url || '#'
        }));
        console.log(`📄 使用实体现有的资源数据: ${relatedResources.length} 个`);
      } else {
        // 向量搜索相关文档资源
        try {
          const resourceSearchResults = await this.searchByVector(`${entity.name} 文档 资源`, 'Document', {
            limit: 5,
            returnType: 'entities'
          });
          relatedResources = resourceSearchResults.data.map(doc => ({
            id: doc.id,
            name: doc.name || '文档资源',
            type: '文档',
            url: doc.properties?.url || '#'
          }));
          console.log(`🔍 通过向量搜索找到相关资源: ${relatedResources.length} 个`);
        } catch (error) {
          console.warn('搜索相关资源失败:', error);
          relatedResources = [];
        }
      }

      // 获取相关对话：优先使用 entity.relatedData.conversations，扩展缺失信息，否则使用 getSimilarMessages 搜索
      let latestConversations = [];
      if (entity.relatedData?.conversations && entity.relatedData.conversations.length > 0) {
        // 使用现有的对话数据，并扩展缺失的详细信息
        console.log(`💬 处理实体现有的对话数据: ${entity.relatedData.conversations.length} 个`);
        for (const conv of entity.relatedData.conversations) {
          const relatedDataConv = {
            ...conv
          };

          // 如果缺少 contextMessages 或 originalContent，尝试通过 getMessage 扩展
          if (!relatedDataConv.contextMessages || relatedDataConv.contextMessages.length === 0 || !relatedDataConv.content) {
            try {
              const messageData = await this.getMessage(relatedDataConv.id);
              if (messageData) {
                // 从检索到的文档中获取 content
                if (!relatedDataConv.content && messageData.content) {
                  relatedDataConv.content = messageData.content;
                }

                // 从 metadata 中获取 contextMessages
                if (!relatedDataConv.contextMessages || relatedDataConv.contextMessages.length === 0) {
                  if (messageData.contextMessages && messageData.contextMessages.length > 0) {
                    relatedDataConv.contextMessages = messageData.contextMessages;
                  } else {
                    relatedDataConv.contextMessages = [{
                      id: messageData.id,
                      sender: messageData.sender,
                      content: messageData.content,
                      datetime: messageData.datetime,
                      isMainMessage: true
                    }];
                  }
                }

                // 补充其他缺失字段
                relatedDataConv.summary = messageData.summary;
                relatedDataConv.groupName = messageData.groupName;
                relatedDataConv.groupUrl = messageData.groupUrl;
                relatedDataConv.groupId = messageData.groupId;
                relatedDataConv.matchedRules = messageData.matchedRules;
                relatedDataConv.replyAdvice = messageData.replyAdvice;
                console.log(`🔍 通过 getMessage 扩展了对话 ${relatedDataConv.id} 的详细信息`);
              }
            } catch (error) {
              console.warn(`扩展对话 ${relatedDataConv.id} 详细信息失败:`, error);
            }
          }
          latestConversations.push(relatedDataConv);
        }
        console.log(`💬 完成对话数据处理: ${latestConversations.length} 个，其中扩展了详细信息`);
      } else {
        // 使用新的 getSimilarMessages 方法搜索相关对话
        try {
          latestConversations = await this.getSimilarMessages(entity.name, {
            limit: 5,
            minRelevanceScore: 0.3,
            sortBy: 'relevance',
            sortOrder: 'desc'
          });
          console.log(`🔍 通过 getSimilarMessages 找到相关对话: ${latestConversations.length} 个`);
        } catch (error) {
          console.warn('搜索相关对话失败:', error);
          latestConversations = [];
        }
      }

      // 获取相关网页记录：优先使用 entity.relatedData.webpages，否则从对话中提取
      let latestWebpages = [];
      if (entity.relatedData?.webpages && entity.relatedData.webpages.length > 0) {
        // 使用现有的网页数据
        latestWebpages = entity.relatedData.webpages.map(webpage => ({
          id: webpage.id || `web_${Date.now()}`,
          title: webpage.title || webpage.name || `${entity.name}相关网页`,
          url: webpage.url || '#',
          type: webpage.type || 'webpage',
          datetime: webpage.datetime || webpage.visitTime || new Date().toISOString(),
          summary: webpage.summary || webpage.description || `与${entity.name}相关的内容`,
          tags: webpage.tags || [entity.name, '网页']
        }));
        console.log(`🌐 使用实体现有的网页数据: ${latestWebpages.length} 个`);
      } else {
        // 向量搜索相关网页记录
        try {
          const webpageSearchResults = await this.searchByVector(`${entity.name} 文档 资源`, 'Document', {
            limit: 5,
            returnType: 'entities'
          });
          latestWebpages = webpageSearchResults.data.map(webpage => ({
            id: webpage.id,
            name: webpage.name || '网页资源',
            type: '网页',
            url: webpage.properties?.url || '#'
          }));
          console.log(`🔍 通过向量搜索找到相关资源: ${latestWebpages.length} 个`);
        } catch (error) {
          console.warn('搜索相关资源失败:', error);
          latestWebpages = [];
        }
      }

      // 获取相关人员和主题：优先使用现有数据
      const relatedPeople = entity.relatedData?.people ? entity.relatedData.people.slice(0, 5) : [];
      const relatedTopics = entity.relatedData?.topics ? entity.relatedData.topics.slice(0, 5) : [];
      const jiraTickets = entity.relatedData?.jiraTickets ? entity.relatedData.jiraTickets.slice(0, 5) : [];
      const cooccurringEntities = entity.relatedData?.cooccurringEntities ? entity.relatedData.cooccurringEntities.slice(0, 10) : [];

      // 统计参与者：优先从 people 数据，否则从对话中统计
      let participantCount = 1;
      if (relatedPeople.length > 0) {
        participantCount = relatedPeople.length;
      } else {
        participantCount = new Set(latestConversations.map(conv => conv.sender)).size || 1;
      }

      // 构建扩展后的实体详情
      const result = {
        ...entity,
        statistic: {
          conversations: latestConversations.length,
          projects: relatedProjects.length,
          participants: participantCount,
          resources: relatedResources.length,
          documents: relatedResources.filter(r => r.type === '文档').length,
          webpages: latestWebpages.length,
          relationships: entity.properties?.relationshipsCount || 0,
          topics: relatedTopics.length,
          jiraTickets: jiraTickets.length
        },
        recentDataDetails: {
          conversations: latestConversations,
          webpages: latestWebpages,
          resources: relatedResources,
          projects: relatedProjects,
          people: relatedPeople,
          topics: relatedTopics,
          jiraTickets: jiraTickets,
          cooccurringEntities: cooccurringEntities
        },
        relatedParticipants: [],
        // 由 LocalStorage 在本地填充
        cachedAt: Date.now()
      };

      // 输出数据获取总结
      console.log(`✅ 实体详情扩展完成 [${entity.name}]:`, {
        conversations: `${latestConversations.length} 个`,
        projects: `${relatedProjects.length} 个`,
        resources: `${relatedResources.length} 个`,
        webpages: `${latestWebpages.length} 个`,
        people: `${relatedPeople.length} 个`,
        topics: `${relatedTopics.length} 个`,
        jiraTickets: `${jiraTickets.length} 个`,
        participants: `${participantCount} 人`
      });
      return result;
    } catch (error) {
      console.error('扩展实体详情失败:', error);
      // 返回基础实体和默认值
      return {
        ...entity,
        statistic: {
          conversations: 0,
          projects: 0,
          participants: 1,
          resources: 0,
          documents: 0,
          webpages: 0,
          relationships: 0,
          topics: 0,
          jiraTickets: 0
        },
        recentDataDetails: {
          conversations: [],
          webpages: [],
          resources: [],
          projects: [],
          people: [],
          topics: [],
          jiraTickets: [],
          cooccurringEntities: []
        },
        relatedParticipants: [],
        cachedAt: Date.now()
      };
    }
  }

  /**
   * 批量更新实体的统计信息
   */
  async batchUpdateEntityStatistics(updates) {
    this.ensureInitialized();
    if (!updates || updates.length === 0) {
      console.log('📊 没有统计信息需要更新');
      return;
    }
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) {
        throw new Error('graph-entities 集合未找到');
      }
      console.log(`📊 开始批量更新 ${updates.length} 个实体的统计信息...`);

      // 分批处理，避免一次性操作过多
      const batchSize = 50;
      for (let i = 0; i < updates.length; i += batchSize) {
        const batch = updates.slice(i, i + batchSize);
        try {
          // 获取当前批次的实体
          const entityIds = batch.map(u => u.entityId);
          const existingEntities = await collection.get({
            ids: entityIds,
            include: ['metadatas']
          });
          if (!existingEntities.ids || existingEntities.ids.length === 0) {
            console.log(`📊 批次 ${i / batchSize + 1}: 没有找到对应的实体`);
            continue;
          }

          // 准备更新的元数据
          const updateMetadatas = [];
          const updateIds = [];
          for (let j = 0; j < existingEntities.ids.length; j++) {
            const entityId = existingEntities.ids[j];
            const updateInfo = batch.find(u => u.entityId === entityId);
            if (updateInfo && existingEntities.metadatas) {
              const currentMetadata = existingEntities.metadatas[j];

              // 更新统计信息
              const updatedMetadata = {
                ...currentMetadata,
                statistic: JSON.stringify(updateInfo.statistic),
                lastStatisticUpdate: updateInfo.lastUpdated,
                updated: Date.now()
              };
              updateMetadatas.push(this.serializeChromaMetadata(updatedMetadata));
              updateIds.push(entityId);
            }
          }
          if (updateIds.length > 0) {
            // 执行批量更新
            await collection.update({
              ids: updateIds,
              metadatas: updateMetadatas
            });
            console.log(`📊 批次 ${i / batchSize + 1}: 成功更新 ${updateIds.length} 个实体的统计信息`);
          }
        } catch (batchError) {
          console.error(`📊 批次 ${i / batchSize + 1} 更新失败:`, batchError);
        }
      }
      console.log(`📊 批量统计信息更新完成`);
    } catch (error) {
      console.error('📊 批量更新实体统计信息失败:', error);
      throw error;
    }
  }

  /**
   * 批量更新实体的已读状态
   */
  async batchUpdateEntityReadStatus(updates) {
    this.ensureInitialized();
    if (!updates || updates.length === 0) {
      console.log('📖 没有已读状态需要更新');
      return;
    }
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) {
        throw new Error('graph-entities 集合未找到');
      }
      console.log(`📖 开始批量更新 ${updates.length} 个实体的已读状态...`);

      // 分批处理，避免一次性操作过多
      const batchSize = 50;
      for (let i = 0; i < updates.length; i += batchSize) {
        const batch = updates.slice(i, i + batchSize);
        try {
          // 获取当前批次的实体
          const entityIds = batch.map(u => u.entityId);
          const existingEntities = await collection.get({
            ids: entityIds,
            include: ['metadatas']
          });
          if (!existingEntities.ids || existingEntities.ids.length === 0) {
            console.log(`📖 批次 ${i / batchSize + 1}: 没有找到对应的实体`);
            continue;
          }

          // 准备更新的元数据
          const updateMetadatas = [];
          const updateIds = [];
          for (let j = 0; j < existingEntities.ids.length; j++) {
            const entityId = existingEntities.ids[j];
            const updateInfo = batch.find(u => u.entityId === entityId);
            if (updateInfo && existingEntities.metadatas) {
              const currentMetadata = existingEntities.metadatas[j];

              // 更新已读状态
              const updatedMetadata = {
                ...currentMetadata,
                readStatus: JSON.stringify(updateInfo.readStatus),
                lastReadStatusUpdate: Date.now(),
                updated: Date.now()
              };
              updateMetadatas.push(this.serializeChromaMetadata(updatedMetadata));
              updateIds.push(entityId);
            }
          }
          if (updateIds.length > 0) {
            // 执行批量更新
            await collection.update({
              ids: updateIds,
              metadatas: updateMetadatas
            });
            console.log(`📖 批次 ${i / batchSize + 1}: 成功更新 ${updateIds.length} 个实体的已读状态`);
          }
        } catch (batchError) {
          console.error(`📖 批次 ${i / batchSize + 1} 更新失败:`, batchError);
        }
      }
      console.log(`📖 批量已读状态更新完成`);
    } catch (error) {
      console.error('📖 批量更新实体已读状态失败:', error);
      throw error;
    }
  }

  /**
   * 🆕 生成自然语言描述 - 用于向量搜索的丰富上下文
   */
  /**
   * 🆕 方案E: 生成精简的document用于向量搜索
   * 策略：name + 关键tags（限制总长度不超过100字符）
   */
  generateSimpleDocument(entity) {
    // 基础：实体名称
    let doc = entity.name;

    // 增强：添加关键标签（最多3个，提升语义匹配能力）
    if (entity.tags && entity.tags.length > 0) {
      const tagText = entity.tags.slice(0, 3).join(' ');
      doc += ' ' + tagText;
    }

    // 限制总长度不超过100字符（避免过长影响匹配精度）
    if (doc.length > 100) {
      doc = doc.substring(0, 100);
    }
    return doc.trim();
  }

  /**
   * 生成完整的自然语言描述（用于存储在metadata.description中供LLM理解）
   */
  async generateNaturalLanguageDescription(entity) {
    const parts = [];

    // 基础信息
    parts.push(`${entity.name}是一个${entity.type}实体。`);

    // 类型特定信息
    switch (entity.type) {
      case 'Person':
        if (entity.role) parts.push(`担任${entity.role}角色。`);
        if (entity.team) parts.push(`属于${entity.team}团队。`);
        if (entity.expertise && entity.expertise.length > 0) {
          parts.push(`专业领域包括：${entity.expertise.join('、')}。`);
        }
        break;
      case 'Project':
        if (entity.properties?.status) parts.push(`项目状态：${entity.properties.status}。`);
        break;
      case 'Topic':
        if (entity.properties?.category) parts.push(`话题分类：${entity.properties.category}。`);
        break;
    }

    // 🆕 关联数据的自然语言描述
    const {
      relatedData
    } = entity;

    // 最近的对话情况
    if (relatedData?.conversations && relatedData.conversations.length > 0) {
      const recentConversations = relatedData.conversations.slice(0, 5); // 取最近5条
      parts.push(`最近的相关讨论包括：`);
      recentConversations.forEach(conv => {
        parts.push(`- ${conv.sender}在${conv.groupName || '聊天'}中提到：${conv.summary}`);
      });
    }

    // 关联的项目
    if (relatedData?.projects && relatedData.projects.length > 0) {
      const topProjects = relatedData.projects.slice(0, 3);
      parts.push(`与以下项目相关：${topProjects.map(p => `${p.name}(${p.status})`).join('、')}。`);
    }

    // 关联的人员
    if (relatedData?.people && relatedData.people.length > 0) {
      const topPeople = relatedData.people.slice(0, 5);
      parts.push(`经常与这些人员合作：${topPeople.map(p => `${p.name}(${p.role})`).join('、')}。`);
    }

    // 关联的话题
    if (relatedData?.topics && relatedData.topics.length > 0) {
      const topTopics = relatedData.topics.slice(0, 3);
      parts.push(`相关讨论话题：${topTopics.map(t => t.name).join('、')}。`);
    }

    // JIRA工作项
    if (relatedData?.jiraTickets && relatedData.jiraTickets.length > 0) {
      const activeTickets = relatedData.jiraTickets.filter(t => t.status !== 'Done').slice(0, 3);
      if (activeTickets.length > 0) {
        parts.push(`相关的工作项：${activeTickets.map(t => `${t.key}: ${t.summary}`).join('；')}。`);
      }
    }

    // 网页资源
    if (relatedData?.webpages && relatedData.webpages.length > 0) {
      const recentPages = relatedData.webpages.slice(0, 3);
      parts.push(`相关网页资源：${recentPages.map(w => w.title).join('、')}。`);
    }

    // 其他相关实体
    if (relatedData?.cooccurringEntities && relatedData.cooccurringEntities.length > 0) {
      const topEntities = relatedData.cooccurringEntities.slice(0, 5);
      parts.push(`经常与这些概念一起出现：${topEntities.map(e => e.name).join('、')}。`);
    }

    // 统计信息
    const stats = entity.statistic;
    if (stats) {
      const activeParts = [];
      if (stats.conversations > 0) activeParts.push(`${stats.conversations}次对话`);
      if (stats.projects > 0) activeParts.push(`${stats.projects}个项目`);
      if (stats.participants > 0) activeParts.push(`${stats.participants}位参与者`);
      if (stats.jiraTickets > 0) activeParts.push(`${stats.jiraTickets}个工作项`);
      if (activeParts.length > 0) {
        parts.push(`总体活跃度：${activeParts.join('、')}。`);
      }
    }

    // 重要性和标签
    if (entity.importance > 0.7) {
      parts.push(`这是一个高优先级项目。`);
    }
    if (entity.tags && entity.tags.length > 0) {
      parts.push(`标签：${entity.tags.join('、')}。`);
    }
    return parts.join(' ');
  }

  /**
   * 🆕 计算实体热度评分 (0-1)
   */
  calculateEntityHotness(entity) {
    const now = Date.now();
    const dayMs = 24 * 60 * 60 * 1000;

    // 1. 最近活动频率（权重40%）
    let recentActivityScore = 0;
    const recentConversations = entity.relatedData?.conversations?.filter(c => now - new Date(c.datetime).getTime() < 7 * dayMs).length || 0;
    recentActivityScore = Math.min(recentConversations / 10, 1); // 7天内10条消息=满分

    // 2. 访问频率（权重30%）
    const daysSinceCreated = Math.max(1, (now - entity.created) / dayMs);
    const accessFrequency = (entity.accessCount || 0) / daysSinceCreated;
    const accessScore = Math.min(accessFrequency * 5, 1); // 每天5次访问=满分

    // 3. 关联数据丰富度（权重20%）
    const totalRelations = (entity.relatedData?.conversations?.length || 0) + (entity.relatedData?.projects?.length || 0) * 2 + (entity.relatedData?.people?.length || 0) + (entity.relatedData?.jiraTickets?.length || 0);
    const richnessScore = Math.min(totalRelations / 30, 1); // 30个关联=满分

    // 4. 最近更新（权重10%）
    const daysSinceUpdate = (now - entity.updated) / dayMs;
    const freshnessScore = Math.max(0, 1 - daysSinceUpdate / 7); // 7天内=满分

    return recentActivityScore * 0.4 + accessScore * 0.3 + richnessScore * 0.2 + freshnessScore * 0.1;
  }

  /**
   * 🆕 计算实体关键性评分 (0-1)
   */
  calculateEntityCriticality(entity) {
    let userImportanceBoost = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
    // 1. 基础重要性（权重50%）
    const baseImportance = entity.importance || 0.5;

    // 2. 用户明确标记（权重30%）
    const userBoostScore = Math.min(userImportanceBoost, 1);

    // 3. 关联项目重要性（权重15%）
    let projectImportanceScore = 0;
    if (entity.relatedData?.projects && entity.relatedData.projects.length > 0) {
      const activeProjects = entity.relatedData.projects.filter(p => p.status !== 'Completed');
      projectImportanceScore = Math.min(activeProjects.length / 3, 1); // 3个活跃项目=满分
    }

    // 4. 关联人员重要性（权重5%）
    const peopleImportanceScore = Math.min((entity.relatedData?.people?.length || 0) / 10, 1);
    return baseImportance * 0.5 + userBoostScore * 0.3 + projectImportanceScore * 0.15 + peopleImportanceScore * 0.05;
  }

  /**
   * 🆕 从消息元数据构建实体关联数据
   * 🔧 修复：使用实体ID映射表，避免重复查询数据库
   */
  async buildEntityRelatedDataFromMessage(entityName, entityType, messageMetadata, extractedEntities, messageId, entityIdMap) {
    const entityKey = entityType + '_' + entityName;
    const relatedData = {
      conversations: [],
      webpages: [],
      resources: [],
      projects: [],
      people: [],
      topics: [],
      jiraTickets: [],
      cooccurringEntities: []
    };

    // 1. 添加当前消息
    if (messageMetadata) {
      relatedData.conversations.push({
        id: messageId,
        summary: messageMetadata.summary || messageMetadata.content?.substring(0, 100) + '...',
        sender: messageMetadata.sender || messageMetadata.source || 'unknown',
        groupId: messageMetadata.groupId || '',
        groupName: messageMetadata.groupName || '未知群组',
        groupUrl: messageMetadata.groupUrl || '#',
        datetime: messageMetadata.datetime || new Date().toISOString(),
        relevanceScore: 0.9,
        // 来源消息相关性最高
        isRead: false,
        // 🆕 新消息默认未读
        readTimestamp: undefined // 🆕 未阅读时为undefined
      });
    }

    // 2. 添加同消息中的其他实体作为共现实体
    // 🔧 优化：直接从映射表获取实体ID，避免重复查询数据库
    for (const otherEntity of extractedEntities) {
      const key = otherEntity.type + '_' + otherEntity.name;
      if (key !== entityKey) {
        // 🔧 从映射表中获取实体ID（阶段1已经确保所有实体都存在）
        const entityId = entityIdMap.get(key);
        if (!entityId) {
          // 理论上不应该发生，因为阶段1已经处理了所有实体
          console.warn(`⚠️ 映射表中未找到实体ID: ${otherEntity.name}(${otherEntity.type})`);
          continue;
        }
        relatedData.cooccurringEntities.push({
          id: entityId,
          name: otherEntity.name,
          type: otherEntity.type,
          relevanceScore: 0.8 // 同消息共现的相关性较高
        });

        // 根据类型添加到对应的关联数据中
        switch (otherEntity.type) {
          case 'Person':
            relatedData.people.push({
              id: entityId,
              name: otherEntity.name,
              role: otherEntity.properties?.role || '',
              team: otherEntity.properties?.team || '',
              expertise: otherEntity.properties?.expertise || [],
              lastContact: Date.now(),
              relevanceScore: 0.8
            });
            break;
          case 'Project':
            relatedData.projects.push({
              id: entityId,
              name: otherEntity.name,
              description: otherEntity.document || '',
              status: otherEntity.properties?.status || 'Active',
              relevanceScore: 0.8
            });
            break;
          case 'Topic':
            relatedData.topics.push({
              id: entityId,
              name: otherEntity.name,
              summary: otherEntity.document || `关于${otherEntity.name}的讨论`,
              category: otherEntity.properties?.category || '技术讨论',
              relevanceScore: 0.8
            });
            break;
          case 'Task':
            // 假设Task类型是JIRA ticket
            relatedData.jiraTickets.push({
              id: entityId,
              key: otherEntity.properties?.key || otherEntity.name,
              summary: otherEntity.document || otherEntity.name,
              status: otherEntity.properties?.status || 'In Progress',
              assignee: otherEntity.properties?.assignee || '',
              dueDate: otherEntity.properties?.dueDate || Date.now(),
              priority: otherEntity.properties?.priority || 'Medium',
              relevanceScore: 0.8
            });
            break;
          case 'Document':
            relatedData.resources.push({
              id: entityId,
              summary: otherEntity.document || `文档：${otherEntity.name}`,
              name: otherEntity.name,
              type: 'document',
              url: otherEntity.properties?.url,
              relevanceScore: 0.7
            });
            break;
        }
      }
    }
    return relatedData;
  }

  /**
   * 🆕 从消息元数据提取实体信息
   */
  extractEntitiesFromMetadata(metadata, messageId) {
    const entities = [];
    if (metadata.entities) {
      // 提取人员实体
      if (metadata.entities.people) {
        for (const person of metadata.entities.people) {
          entities.push({
            type: 'Person',
            name: person.name,
            document: `人员: ${person.name}`,
            role: person.role,
            team: person.team,
            expertise: person.expertise,
            properties: {
              mentioned_context: person.mentioned_context,
              source: 'message_analysis',
              groupName: metadata.groupName || '',
              messageId: messageId,
              datetime: metadata.datetime || Date.now()
            },
            importance: 0.7,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }

      // 提取项目实体
      if (metadata.entities.projects) {
        for (const project of metadata.entities.projects) {
          entities.push({
            type: 'Project',
            name: project.name,
            document: `项目: ${project.name}`,
            properties: {
              status: project.status,
              related_people: project.related_people,
              source: 'message_analysis',
              groupName: metadata.groupName || '',
              messageId: messageId,
              timestamp: metadata.timestamp || Date.now()
            },
            importance: 0.8,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }

      // 提取话题实体
      if (metadata.entities.topics) {
        for (const topic of metadata.entities.topics) {
          entities.push({
            type: 'Topic',
            name: topic.name,
            document: `话题: ${topic.name}`,
            properties: {
              category: topic.category,
              keywords: topic.keywords,
              source: 'message_analysis',
              groupName: metadata.groupName || '',
              messageId: messageId,
              timestamp: metadata.timestamp || Date.now()
            },
            importance: 0.5,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }

      // 提取文档/资源实体
      if (metadata.entities.documents || metadata.entities.resources) {
        const documentsList = [...(metadata.entities.documents || []), ...(metadata.entities.resources || [])];
        for (const doc of documentsList) {
          entities.push({
            type: 'Document',
            name: doc.name || doc.title,
            document: `文档: ${doc.name || doc.title}`,
            properties: {
              url: doc.url,
              type: doc.type || 'document',
              description: doc.description,
              source: 'message_analysis',
              groupName: metadata.groupName || '',
              messageId: messageId,
              timestamp: metadata.timestamp || Date.now()
            },
            importance: 0.6,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }

      // 提取技术实体
      if (metadata.entities.technologies || metadata.entities.tools) {
        const techList = [...(metadata.entities.technologies || []), ...(metadata.entities.tools || [])];
        for (const tech of techList) {
          entities.push({
            type: 'Technology',
            name: tech.name,
            document: `技术: ${tech.name}`,
            properties: {
              category: tech.category,
              version: tech.version,
              usage_context: tech.usage_context,
              source: 'message_analysis',
              groupName: metadata.groupName || '',
              type: 'technology',
              messageId: messageId,
              timestamp: metadata.timestamp || Date.now()
            },
            importance: 0.6,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }

      // 提取组织实体或个人实体（根据 groupName 格式判断）
      if (metadata.groupName && metadata.groupName !== 'SM AI') {
        // 检查是否是 firstName.lastName 组合形式的聊天（用 + 分隔）
        const participants = metadata.groupName.split('+').map(p => p.trim());
        const isPersonalChat = participants.every(p => /^[a-zA-Z]+\.[a-zA-Z]+$/.test(p));
        if (isPersonalChat && participants.length >= 2) {
          // 这是一个个人或多人聊天，提取除了 esone.qiu 之外的参与者
          const otherParticipants = participants.filter(p => p.toLowerCase() !== 'esone.qiu');
          for (const participant of otherParticipants) {
            // 将 firstName.lastName 转换为 Firstname Lastname
            const [firstName, lastName] = participant.split('.');
            const displayName = `${firstName.charAt(0).toUpperCase() + firstName.slice(1)} ${lastName.charAt(0).toUpperCase() + lastName.slice(1)}`;
            entities.push({
              type: 'Person',
              name: displayName,
              document: `人物: ${displayName}`,
              properties: {
                email: `${participant}@ringcentral.com`,
                // 可能的邮箱格式
                username: participant,
                source: 'message_analysis',
                messageId: messageId,
                timestamp: metadata.timestamp || Date.now()
              },
              importance: 0.7,
              accessCount: 1,
              lastAccessed: Date.now(),
              tags: [],
              statistic: {
                conversations: 0,
                projects: 0,
                participants: 0,
                resources: 0,
                documents: 0,
                webpages: 0,
                relationships: 0,
                topics: 0,
                jiraTickets: 0
              },
              relatedData: {
                conversations: [],
                webpages: [],
                resources: [],
                projects: [],
                people: [],
                topics: [],
                jiraTickets: [],
                cooccurringEntities: []
              }
            });
          }
        } else {
          // 这是一个正常的组织/团队聊天组
          entities.push({
            type: 'Organization',
            name: metadata.groupName,
            document: `组织: ${metadata.groupName}`,
            properties: {
              groupId: metadata.groupId,
              source: 'message_analysis',
              type: 'team',
              messageId: messageId,
              timestamp: metadata.timestamp || Date.now()
            },
            importance: 0.6,
            accessCount: 1,
            lastAccessed: Date.now(),
            tags: [],
            statistic: {
              conversations: 0,
              projects: 0,
              participants: 0,
              resources: 0,
              documents: 0,
              webpages: 0,
              relationships: 0,
              topics: 0,
              jiraTickets: 0
            },
            relatedData: {
              conversations: [],
              webpages: [],
              resources: [],
              projects: [],
              people: [],
              topics: [],
              jiraTickets: [],
              cooccurringEntities: []
            }
          });
        }
      }
    }
    return entities;
  }

  /**
   * 🆕 更新实体关联数据 - 从消息分析中提取实体并更新其关联信息
   * 🔧 修复：采用两阶段处理，先创建所有实体，再建立关联关系
   */
  async updateEntitiesWithRelatedData(messageMetadata, messageId) {
    console.log(`🔗 开始从消息 ${messageId} 更新实体关联数据...`);
    try {
      // 1. 从消息元数据提取实体
      const extractedEntities = this.extractEntitiesFromMetadata(messageMetadata, messageId);
      if (extractedEntities.length === 0) {
        console.log('📭 消息中未发现实体，跳过关联数据更新');
        return;
      }
      console.log(`📝 从消息中提取到 ${extractedEntities.length} 个实体: ${extractedEntities.map(e => `${e.name}(${e.type})`).join(', ')}`);

      // 🔧 阶段1：确保所有实体都存在于数据库中（不包含相互引用）
      const entityIdMap = new Map(); // key: type_name, value: entityId

      for (const entity of extractedEntities) {
        try {
          const entityKey = `${entity.type}_${entity.name}`;

          // 检查实体是否已存在
          const similarEntities = await this.getSimilarEntities({
            ...entity,
            created: Date.now(),
            updated: Date.now()
          });
          const existingEntity = similarEntities.length > 0 ? similarEntities[0] : null;
          if (existingEntity) {
            console.log(`✅ 实体已存在: ${entity.name}(${entity.type}) -> ${existingEntity.id}`);
            entityIdMap.set(entityKey, existingEntity.id);
          } else {
            // 创建新实体（暂不包含关联数据）
            const newEntity = {
              ...entity,
              created: Date.now(),
              updated: Date.now(),
              accessCount: 1,
              lastAccessed: Date.now(),
              hotness: 0.5,
              criticalityScore: entity.importance || 0.5,
              readStatus: {
                unreadCount: 1,
                // 初始有1条未读消息
                lastReadTime: null,
                lastUpdateTime: Date.now()
              }
            };
            const storeResult = await _memory__WEBPACK_IMPORTED_MODULE_3__.memorySystem.storeEntity(newEntity);
            if (storeResult.success && storeResult.entityId) {
              console.log(`🆕 新实体创建: ${entity.name}(${entity.type}) -> ${storeResult.entityId}`);
              entityIdMap.set(entityKey, storeResult.entityId);
            } else {
              console.error(`❌ 创建实体失败: ${entity.name}(${entity.type})`);
            }
          }
        } catch (error) {
          console.error(`❌ 处理实体 ${entity.name} 失败:`, error);
        }
      }
      console.log(`📊 实体ID映射表创建完成，共 ${entityIdMap.size} 个实体`);

      // 🔧 阶段2：为每个实体构建和更新关联数据（使用真实的实体ID）
      for (const entity of extractedEntities) {
        try {
          const entityKey = `${entity.type}_${entity.name}`;
          const currentEntityId = entityIdMap.get(entityKey);
          if (!currentEntityId) {
            console.warn(`⚠️ 未找到实体ID: ${entity.name}(${entity.type})`);
            continue;
          }

          // 构建关联数据（传入映射表，避免重复查询数据库）
          const relatedDataForEntity = await this.buildEntityRelatedDataFromMessage(entity.name, entity.type, messageMetadata, extractedEntities, messageId, entityIdMap // 🔧 传入映射表
          );

          // 计算实体热度和重要性
          const entityWithRelatedData = {
            ...entity,
            created: Date.now(),
            updated: Date.now(),
            relatedData: relatedDataForEntity
          };

          // 更新热度和关键性评分
          entityWithRelatedData.hotness = this.calculateEntityHotness(entityWithRelatedData);
          entityWithRelatedData.criticalityScore = this.calculateEntityCriticality(entityWithRelatedData, 0);

          // 获取现有实体
          const existingEntity = await this.getEntity(currentEntityId);
          if (!existingEntity) {
            console.error(`❌ 无法获取实体: ${currentEntityId}`);
            continue;
          }

          // 计算未读消息数
          const newUnreadCount = relatedDataForEntity.conversations?.filter(c => !c.isRead).length || 0;
          const currentUnreadCount = existingEntity.readStatus?.unreadCount || 0;
          const unreadCount = currentUnreadCount + newUnreadCount;

          // 更新实体的关联数据
          const updateData = {
            relatedData: relatedDataForEntity,
            hotness: entityWithRelatedData.hotness,
            criticalityScore: entityWithRelatedData.criticalityScore,
            lastAccessed: Date.now(),
            accessCount: (existingEntity.accessCount || 0) + 1,
            statistic: {
              conversations: relatedDataForEntity.conversations?.length || 0,
              projects: relatedDataForEntity.projects?.length || 0,
              participants: relatedDataForEntity.people?.length || 0,
              resources: relatedDataForEntity.resources?.length || 0,
              documents: relatedDataForEntity.resources?.filter(r => r.type === 'document')?.length || 0,
              webpages: relatedDataForEntity.webpages?.length || 0,
              topics: relatedDataForEntity.topics?.length || 0,
              jiraTickets: relatedDataForEntity.jiraTickets?.length || 0,
              relationships: relatedDataForEntity.cooccurringEntities?.length || 0
            },
            readStatus: {
              unreadCount: unreadCount,
              lastReadTime: existingEntity.readStatus?.lastReadTime || null,
              lastUpdateTime: Date.now()
            }
          };
          const updateResult = await _memory__WEBPACK_IMPORTED_MODULE_3__.memorySystem.updateEntity(currentEntityId, updateData);
          console.log(`🔄 实体关联数据更新: ${entity.name}, 成功: ${updateResult.success ? '✅' : '❌'}, 未读: ${unreadCount}`);
        } catch (entityError) {
          console.error(`❌ 更新实体 ${entity.name} 关联数据失败:`, entityError);
        }
      }
      console.log(`✅ 所有实体关联数据更新完成`);
    } catch (error) {
      console.error('🚨 更新实体关联数据过程中发生错误:', error);
    }
  }

  /**
   * 🆕 清理实体的过期消息
   * 清理策略：只保留1个月内的消息（不区分已读未读）
   */
  async cleanExpiredReadConversations(entityId) {
    this.ensureInitialized();
    const result = {
      entitiesProcessed: 0,
      conversationsRemoved: 0,
      spaceSaved: 0
    };
    try {
      const collection = this.collections.get(`${this.username}-graph-entities`);
      if (!collection) {
        console.warn('graph-entities 集合不存在');
        return result;
      }
      const oneMonthAgo = Date.now() - 30 * 24 * 60 * 60 * 1000; // 30天前

      // 如果指定了entityId，只清理该实体
      const entityIds = entityId ? [entityId] : [];

      // 如果没有指定，获取所有实体
      if (!entityId) {
        const allEntities = await collection.get({
          include: ['metadatas']
        });
        if (allEntities.ids) {
          entityIds.push(...allEntities.ids);
        }
      }
      console.log(`🧹 开始清理 ${entityIds.length} 个实体的过期消息...`);

      // 批量处理实体
      const batchSize = 50;
      for (let i = 0; i < entityIds.length; i += batchSize) {
        const batch = entityIds.slice(i, i + batchSize);
        const entities = await collection.get({
          ids: batch,
          include: ['metadatas', 'documents']
        });
        if (!entities.metadatas || entities.metadatas.length === 0) continue;
        const updateIds = [];
        const updateMetadatas = [];
        for (let j = 0; j < entities.ids.length; j++) {
          const entityId = entities.ids[j];
          const metadata = entities.metadatas[j];

          // 反序列化实体
          const entity = this.deserializeEntityFromMetadata(metadata);
          if (!entity.relatedData?.conversations || entity.relatedData.conversations.length === 0) {
            continue;
          }
          const originalCount = entity.relatedData.conversations.length;

          // 🆕 简化策略：只保留1个月内的消息（不区分已读未读）
          entity.relatedData.conversations = entity.relatedData.conversations.filter(conv => {
            const convTime = new Date(conv.datetime).getTime();
            return convTime > oneMonthAgo; // 保留1个月内的所有消息
          });
          const newCount = entity.relatedData.conversations.length;
          const removed = originalCount - newCount;
          if (removed > 0) {
            // 更新统计信息
            entity.statistic.conversations = entity.relatedData.conversations.length;

            // 🆕 重新计算 unreadCount（清理后可能有变化）
            if (entity.readStatus) {
              const unreadInRemaining = entity.relatedData.conversations.filter(c => !c.isRead).length;
              entity.readStatus.unreadCount = unreadInRemaining;
              entity.readStatus.lastUpdateTime = Date.now();
            }

            // 重新序列化
            const updatedMetadata = {
              ...metadata,
              relatedData: JSON.stringify(entity.relatedData),
              statistic: JSON.stringify(entity.statistic),
              readStatus: entity.readStatus ? JSON.stringify(entity.readStatus) : undefined,
              updated: Date.now()
            };
            updateIds.push(entityId);
            updateMetadatas.push(this.serializeChromaMetadata(updatedMetadata));
            result.conversationsRemoved += removed;
            result.spaceSaved += removed * 500; // 估算每条消息约500字节
          }
        }

        // 批量更新
        if (updateIds.length > 0) {
          await collection.update({
            ids: updateIds,
            metadatas: updateMetadatas
          });
          result.entitiesProcessed += updateIds.length;
        }
      }
      console.log(`✅ 清理完成: 处理${result.entitiesProcessed}个实体, 移除${result.conversationsRemoved}条过期消息, 节省${(result.spaceSaved / 1024).toFixed(2)}KB空间`);
      return result;
    } catch (error) {
      console.error('🚨 清理过期消息失败:', error);
      throw error;
    }
  }

  /**
   * 🆕 存储独立用户配置（自定义Prompt和分析偏好）
   */
  async storeIndependentUserConfig(config) {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-user-config`);
      if (!collection) {
        console.warn('用户配置集合不存在，尝试创建...');
        // 尝试创建集合
        try {
          await this.client.createCollection({
            name: `${this.username}-user-config`,
            metadata: {
              type: 'user-config'
            }
          });
          this.collections.set(`${this.username}-user-config`, await this.client.getCollection({
            name: `${this.username}-user-config`
          }));
        } catch (createError) {
          console.error('创建用户配置集合失败:', createError);
          return false;
        }
      }
      const configCollection = this.collections.get(`${this.username}-user-config`);
      const configId = `config-${this.username}`;
      const embedding = await (0,_embeddings__WEBPACK_IMPORTED_MODULE_1__/* .getEmbeddingViaOffscreen */ .zP)(`user config: ${JSON.stringify(config).substring(0, 100)}`);
      await configCollection.upsert({
        ids: [configId],
        documents: [`User configuration for ${this.username}`],
        embeddings: [embedding],
        metadatas: [{
          userId: this.username,
          configType: 'independent_user_config',
          lastUpdated: Date.now(),
          version: config.version || '1.0',
          configData: JSON.stringify(config)
        }]
      });
      console.log('独立用户配置已存储到云端');
      return true;
    } catch (error) {
      console.error('存储独立用户配置失败:', error);
      return false;
    }
  }

  /**
   * 🆕 获取独立用户配置
   */
  async getIndependentUserConfig() {
    this.ensureInitialized();
    try {
      const collection = this.collections.get(`${this.username}-user-config`);
      if (!collection) {
        console.log('用户配置集合不存在');
        return null;
      }
      const configId = `config-${this.username}`;
      const result = await collection.get({
        ids: [configId],
        include: ['metadatas']
      });
      if (result.metadatas && result.metadatas.length > 0) {
        const metadata = result.metadatas[0];
        if (metadata && metadata.configData) {
          console.log('从云端获取独立用户配置成功');
          return JSON.parse(metadata.configData);
        }
      }
      console.log('云端未找到独立用户配置');
      return null;
    } catch (error) {
      console.error('获取独立用户配置失败:', error);
      return null;
    }
  }

  // ==================== ChromaDB 包装方法(暂不启用) ====================

  /**
   * 包装 collection.get 方法，自动反序列化 metadata
   */
  async wrappedCollectionGet(collection, params) {
    const result = await collection.get(params);

    // 自动反序列化 metadata（创建新对象以避免只读属性错误）
    if (result.metadatas) {
      return {
        ...result,
        metadatas: result.metadatas.map(metadata => this.deserializeChromaMetadata(metadata))
      };
    }
    return result;
  }

  /**
   * 包装 collection.query 方法，自动反序列化 metadata
   */
  async wrappedCollectionQuery(collection, params) {
    const result = await collection.query(params);

    // 自动反序列化 metadata（创建新对象以避免只读属性错误）
    if (result.metadatas) {
      return {
        ...result,
        metadatas: result.metadatas.map(metadataArray => metadataArray.map(metadata => this.deserializeChromaMetadata(metadata)))
      };
    }
    return result;
  }

  /**
   * 包装 collection.add 方法，自动序列化 metadata
   */
  async wrappedCollectionAdd(collection, params) {
    const wrappedParams = {
      ...params
    };

    // 自动序列化 metadata
    if (wrappedParams.metadatas) {
      wrappedParams.metadatas = wrappedParams.metadatas.map(metadata => this.serializeChromaMetadata(metadata));
    }
    return await collection.add(wrappedParams);
  }

  /**
   * 包装 collection.update 方法，自动序列化 metadata
   */
  async wrappedCollectionUpdate(collection, params) {
    const wrappedParams = {
      ...params
    };

    // 自动序列化 metadata
    if (wrappedParams.metadatas) {
      wrappedParams.metadatas = wrappedParams.metadatas.map(metadata => this.serializeChromaMetadata(metadata));
    }
    return await collection.update(wrappedParams);
  }

  /**
   * 包装 collection.upsert 方法，自动序列化 metadata
   */
  async wrappedCollectionUpsert(collection, params) {
    const wrappedParams = {
      ...params
    };

    // 自动序列化 metadata
    if (wrappedParams.metadatas) {
      wrappedParams.metadatas = wrappedParams.metadatas.map(metadata => this.serializeChromaMetadata(metadata));
    }
    return await collection.upsert(wrappedParams);
  }

  /**
   * 包装 collection.delete 方法（不需要序列化/反序列化）
   */
  async wrappedCollectionDelete(collection, params) {
    return await collection.delete(params);
  }
}

/***/ }),

/***/ 7997:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   D: () => (/* binding */ LocalStorage)
/* harmony export */ });
/**
 * 本地缓存管理器
 * 专门管理 Chrome Storage 缓存，包括实体基础信息、关系索引和最近数据
 */

// 统一的缓存实体详情接口 - 包含所有本地缓存数据

// 关系类型定义

// 缓存键前缀
const CACHE_KEYS = {
  ENTITIES: 'cache_entities',
  // 统一存储 CachedEntityDetail 格式，移除 RECENT_DATA
  ENTITY_INDEX: 'cache_entity_index',
  TYPE_INDEX: 'cache_type_index',
  RELATIONSHIPS: 'cache_relationships',
  RELATIONSHIP_INDEX: 'cache_relationship_index',
  STATISTICS: 'cache_statistics'
};

// 缓存配置

// 实体索引

// 类型索引

// 关系索引

/**
 * 本地存储管理器
 */
class LocalStorage {
  constructor() {
    this.memoryEntities = new Map();
    this.memoryRelationships = new Map();
    this.isInitialized = false;
    this.config = {
      maxEntitiesInMemory: 1000,
      // 内存中最多保存1000个实体
      maxRecentDataPerEntity: 5,
      // 每个实体最多保存5条最近数据
      statisticsCacheDuration: 30 * 60 * 1000,
      // 30分钟
      recentDataCacheDuration: 6 * 60 * 60 * 1000,
      // 6小时
      // 新增：最近数据同步配置
      enableRecentDataSync: true,
      // 启用基于关系的最近数据同步
      recentDataSyncBatchSize: 10,
      // 每批处理10个实体的最近数据
      recentDataQueryLimit: 5 // 每个实体最多查询5条最近数据
    };
  }

  /**
   * 初始化本地缓存
   */
  async initialize() {
    try {
      console.log('💾 初始化本地缓存...');

      // 加载实体到内存
      await this.loadEntitiesToMemory();

      // 加载关系到内存
      await this.loadRelationshipsToMemory();

      // 启动定期清理
      this.startPeriodicCleanup();
      this.isInitialized = true;
      console.log('✅ 本地缓存初始化完成');
      return true;
    } catch (error) {
      console.error('❌ 本地缓存初始化失败:', error);
      return false;
    }
  }

  // ==================== 实体缓存管理 ====================

  /**
   * 获取实体详情（统一的CachedEntityDetail格式，先内存后存储）
   */
  async getEntity(entityId) {
    this.ensureInitialized();

    // 从存储获取完整的 CachedEntityDetail
    try {
      const result = await chrome.storage.local.get(`${CACHE_KEYS.ENTITIES}_${entityId}`);
      const entity = result[`${CACHE_KEYS.ENTITIES}_${entityId}`];
      if (entity) {
        // 更新访问时间
        entity.lastAccessed = Date.now();
        entity.accessCount = (entity.accessCount || 0) + 1;

        // 确保实体包含所有必要的字段
        this.ensureDetailEntityFields(entity);

        // 同步基础实体到内存（如果空间允许）
        if (this.memoryEntities.size < this.config.maxEntitiesInMemory) {
          const baseEntity = this.convertToBaseEntity(entity);
          this.memoryEntities.set(entityId, baseEntity);
        }
        return entity;
      }
    } catch (error) {
      console.error('从存储获取实体失败:', error);
    }
    return null;
  }

  /**
   * 按类型查询实体
   */
  async queryEntitiesByType(type) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    this.ensureInitialized();
    const startTime = Date.now();
    const {
      limit = 50,
      offset = 0,
      sortBy = 'lastAccessed',
      sortOrder = 'desc'
    } = options;
    try {
      // 获取类型索引
      const typeIndex = await this.getTypeIndex();
      const entityIds = typeIndex[type] || [];
      const entities = [];

      // 获取实体数据
      for (const entityId of entityIds) {
        const entity = await this.getEntity(entityId);
        if (entity) {
          entities.push(entity);
        }
      }

      // 排序
      entities.sort((a, b) => {
        const aValue = a[sortBy];
        const bValue = b[sortBy];
        return sortOrder === 'desc' ? bValue - aValue : aValue - bValue;
      });

      // 分页
      const paginatedEntities = entities.slice(offset, offset + limit);
      return {
        data: paginatedEntities,
        total: entities.length,
        source: 'local',
        cached: true,
        queryTime: Date.now() - startTime
      };
    } catch (error) {
      console.error('按类型查询实体失败:', error);
      return {
        data: [],
        total: 0,
        source: 'local',
        cached: true,
        queryTime: Date.now() - startTime
      };
    }
  }

  /**
   * 搜索实体（本地模糊搜索）
   */
  async searchEntities(searchTerm, type) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    this.ensureInitialized();
    const startTime = Date.now();
    const {
      limit = 20
    } = options;
    try {
      const entities = [];
      const searchLower = searchTerm.toLowerCase();

      // 从内存搜索
      for (const entity of Array.from(this.memoryEntities.values())) {
        if (type && entity.type !== type) continue;
        const matchesName = entity.name.toLowerCase().includes(searchLower);
        const matchesDescription = entity.description?.toLowerCase().includes(searchLower);
        const matchesTags = entity.tags?.some(tag => tag.toLowerCase().includes(searchLower));
        if (matchesName || matchesDescription || matchesTags) {
          entities.push(entity);
        }
      }

      // 如果内存中结果不够，从存储搜索
      if (entities.length < limit) {
        // 这里可以实现更复杂的存储搜索逻辑
        // 暂时先返回内存结果
      }

      // 按相关性排序（简单实现）
      entities.sort((a, b) => {
        const aScore = this.calculateRelevanceScore(a, searchTerm);
        const bScore = this.calculateRelevanceScore(b, searchTerm);
        return bScore - aScore;
      });
      return {
        data: entities.slice(0, limit),
        total: entities.length,
        source: 'local',
        cached: true,
        queryTime: Date.now() - startTime
      };
    } catch (error) {
      console.error('搜索实体失败:', error);
      return {
        data: [],
        total: 0,
        source: 'local',
        cached: true,
        queryTime: Date.now() - startTime
      };
    }
  }

  /**
   * 缓存实体（统一存储为CachedEntityDetail格式）
   */
  async cacheEntity(entity) {
    this.ensureInitialized();
    try {
      // 转换为 CachedEntityDetail 格式
      const detailEntity = this.isCachedEntityDetail(entity) ? entity : this.convertToDetailEntity(entity);

      // 确保包含所有必要字段
      this.ensureDetailEntityFields(detailEntity);

      // 存储到持久化存储（统一使用 CachedEntityDetail 格式）
      await chrome.storage.local.set({
        [`${CACHE_KEYS.ENTITIES}_${entity.id}`]: detailEntity
      });

      // 加载基础实体到内存（如果空间允许）
      const baseEntity = this.convertToBaseEntity(detailEntity);
      if (this.memoryEntities.size < this.config.maxEntitiesInMemory) {
        this.memoryEntities.set(entity.id, baseEntity);
      } else {
        // 移除最少使用的实体
        const lruEntity = this.findLRUEntity();
        if (lruEntity) {
          this.memoryEntities.delete(lruEntity.id);
        }
        this.memoryEntities.set(entity.id, baseEntity);
      }

      // 更新索引
      await this.updateEntityIndex(baseEntity);
    } catch (error) {
      console.error('缓存实体失败:', error);
    }
  }

  /**
   * 获取所有缓存的实体
   */
  async getAllEntities() {
    this.ensureInitialized();
    try {
      const entities = [];

      // 从内存获取所有实体
      for (const entity of Array.from(this.memoryEntities.values())) {
        entities.push(entity);
      }

      // 如果内存中没有实体，从存储中加载
      if (entities.length === 0) {
        const entityIndex = await this.getEntityIndex();
        for (const entityId of Object.keys(entityIndex)) {
          const entity = await this.getEntity(entityId);
          if (entity) {
            entities.push(entity);
          }
        }
      }
      console.log(`📦 从本地缓存获取了 ${entities.length} 个实体`);
      return entities;
    } catch (error) {
      console.error('获取所有本地实体失败:', error);
      return [];
    }
  }

  /**
   * 批量缓存实体
   */
  async batchCacheEntities(entities) {
    this.ensureInitialized();
    try {
      // 批量存储
      const storageData = {};
      for (const entity of entities) {
        storageData[`${CACHE_KEYS.ENTITIES}_${entity.id}`] = entity;
      }
      await chrome.storage.local.set(storageData);

      // 更新内存和索引
      for (const entity of entities) {
        if (this.memoryEntities.size < this.config.maxEntitiesInMemory) {
          this.memoryEntities.set(entity.id, entity);
        }
        await this.updateEntityIndex(entity);
      }
    } catch (error) {
      console.error('批量缓存实体失败:', error);
    }
  }

  // ==================== 关系缓存管理 ====================

  /**
   * 获取关系网络
   */
  async getRelationshipNetwork(entityId) {
    let depth = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
    this.ensureInitialized();
    try {
      const visitedEntities = new Set();
      const foundEntities = [];
      const foundRelationships = [];
      await this.traverseRelationships(entityId, depth, visitedEntities, foundEntities, foundRelationships);
      return {
        entities: foundEntities,
        relationships: foundRelationships
      };
    } catch (error) {
      console.error('获取关系网络失败:', error);
      return {
        entities: [],
        relationships: []
      };
    }
  }

  /**
   * 🆕 存储关系（对外接口）
   */
  async storeRelationship(relationship) {
    await this.cacheRelationship(relationship);
  }

  /**
   * 缓存关系
   */
  async cacheRelationship(relationship) {
    this.ensureInitialized();
    try {
      // 存储到持久化存储
      await chrome.storage.local.set({
        [`${CACHE_KEYS.RELATIONSHIPS}_${relationship.id}`]: relationship
      });

      // 加载到内存
      this.memoryRelationships.set(relationship.id, relationship);

      // 更新关系索引
      await this.updateRelationshipIndex(relationship);

      // 🆕 更新聚合关系数据（用于同步）
      await this.updateAggregatedRelationshipData();
    } catch (error) {
      console.error('缓存关系失败:', error);
    }
  }

  /**
   * 恢复关系数据（新设备同步）- 简化版
   */
  async restoreRelationshipData(relationshipData) {
    this.ensureInitialized();
    try {
      console.log('🔄 恢复关系数据到本地缓存...');

      // 1. 恢复关系数据
      const relationshipMap = new Map();
      const entityRelationsMap = new Map();
      for (const [id, relationship] of relationshipData.relationships) {
        relationshipMap.set(id, relationship);

        // 构建实体-关系映射
        if (!entityRelationsMap.has(relationship.fromId)) {
          entityRelationsMap.set(relationship.fromId, new Set());
        }
        if (!entityRelationsMap.has(relationship.toId)) {
          entityRelationsMap.set(relationship.toId, new Set());
        }
        entityRelationsMap.get(relationship.fromId).add(id);
        entityRelationsMap.get(relationship.toId).add(id);
      }

      // 2. 批量保存关系到存储
      const relationshipStorageData = {};
      for (const [id, relationship] of Array.from(relationshipMap.entries())) {
        relationshipStorageData[`${CACHE_KEYS.RELATIONSHIPS}_${id}`] = relationship;
      }
      await chrome.storage.local.set(relationshipStorageData);

      // 3. 更新内存中的关系
      this.memoryRelationships = relationshipMap;

      // 4. 保存关系索引
      const relationshipIndexData = {
        relationships: Array.from(relationshipMap.entries()),
        entityToRelations: Array.from(entityRelationsMap.entries()).map(_ref => {
          let [key, value] = _ref;
          return [key, Array.from(value)];
        })
      };
      await chrome.storage.local.set({
        [CACHE_KEYS.RELATIONSHIP_INDEX]: relationshipIndexData
      });
      console.log(`✅ 恢复了 ${relationshipMap.size} 个关系到本地缓存`);

      // 🆕 更新聚合关系数据（用于同步）
      await this.updateAggregatedRelationshipData();
    } catch (error) {
      console.error('恢复关系数据失败:', error);
    }
  }

  /**
   * 🆕 获取简化的关系数据备份
   */
  async getSimplifiedRelationshipData() {
    const fullData = await this.getRelationshipBackupData();
    if (!fullData) return null;
    return {
      relationships: fullData.relationships,
      typeToEntities: fullData.typeToEntities
    };
  }

  /**
   * 获取完整的关系数据备份（包含entityToRelations）
   */
  async getRelationshipBackupData() {
    this.ensureInitialized();
    try {
      // 1. 获取关系数据
      const relationships = Array.from(this.memoryRelationships.entries());
      if (relationships.length === 0) {
        return null;
      }

      // 2. 获取类型索引
      const typeIndex = await this.getTypeIndex();
      const typeToEntities = Array.from(Object.entries(typeIndex)).map(_ref2 => {
        let [key, value] = _ref2;
        return [key, Array.from(value)];
      });

      // 3. 获取关系索引（entityToRelations）
      const relationshipIndex = await this.getRelationshipIndex();
      const entityToRelations = Array.from(Object.entries(relationshipIndex));
      return {
        relationships,
        entityToRelations,
        typeToEntities
      };
    } catch (error) {
      console.error('获取关系备份数据失败:', error);
      return null;
    }
  }

  // ==================== 最近数据缓存 ====================

  /**
   * 更新实体的详细数据（统一存储到ENTITIES）
   */
  async updateRecentData(entityId, type, data) {
    this.ensureInitialized();
    try {
      let entityDetail = await this.getEntity(entityId);
      if (!entityDetail) {
        // 如果实体不存在，创建一个基础的 CachedEntityDetail
        entityDetail = {
          id: entityId,
          type: 'Topic',
          // 默认类型，后续可以根据需要调整
          name: entityId,
          document: '',
          properties: {},
          created: Date.now(),
          updated: Date.now(),
          accessCount: 0,
          lastAccessed: Date.now(),
          importance: 0.5,
          statistic: {
            conversations: 0,
            projects: 0,
            participants: 1,
            resources: 0,
            documents: 0,
            webpages: 0,
            relationships: 0,
            topics: 0,
            jiraTickets: 0
          },
          relatedData: {
            conversations: [],
            webpages: [],
            resources: [],
            projects: [],
            people: [],
            topics: [],
            jiraTickets: [],
            cooccurringEntities: []
          },
          cachedAt: Date.now(),
          recentDataDetails: {
            conversations: [],
            webpages: [],
            resources: [],
            projects: [],
            people: [],
            topics: [],
            jiraTickets: [],
            cooccurringEntities: []
          },
          relatedParticipants: [],
          lastUpdated: Date.now()
        };
      }

      // 添加新数据到对应数组的开头（只保留最近5条）
      if (type === 'conversation') {
        entityDetail.recentDataDetails.conversations.unshift(data);
        if (entityDetail.recentDataDetails.conversations.length > 5) {
          entityDetail.recentDataDetails.conversations = entityDetail.recentDataDetails.conversations.slice(0, 5);
        }
      } else if (type === 'resource') {
        entityDetail.recentDataDetails.resources.unshift(data);
        if (entityDetail.recentDataDetails.resources.length > 5) {
          entityDetail.recentDataDetails.resources = entityDetail.recentDataDetails.resources.slice(0, 5);
        }
      } else if (type === 'project') {
        entityDetail.recentDataDetails.projects.unshift(data);
        if (entityDetail.recentDataDetails.projects.length > 5) {
          entityDetail.recentDataDetails.projects = entityDetail.recentDataDetails.projects.slice(0, 5);
        }
      } else {
        // webpage
        entityDetail.recentDataDetails.webpages.unshift(data);
        if (entityDetail.recentDataDetails.webpages.length > 5) {
          entityDetail.recentDataDetails.webpages = entityDetail.recentDataDetails.webpages.slice(0, 5);
        }
      }
      entityDetail.lastUpdated = Date.now();
      entityDetail.updated = Date.now();

      // 重新计算统计字段
      this.recalculateUIFields(entityDetail);

      // 保存更新到统一的ENTITIES存储
      await this.cacheEntity(entityDetail);
    } catch (error) {
      console.error('更新实体详细数据失败:', error);
    }
  }

  /**
   * 🆕 基于本地关系数据批量更新实体的最近数据缓存
   */
  async batchUpdateRecentDataCacheFromRelations(entities) {
    if (!this.config.enableRecentDataSync) {
      return 0;
    }
    let updatedCount = 0;
    const batches = this.chunkArray(entities, this.config.recentDataSyncBatchSize);
    for (const batch of batches) {
      // 并行处理批内实体，但控制并发数量
      const promises = batch.map(entity => this.updateEntityRecentDataFromRelations(entity));
      const results = await Promise.allSettled(promises);

      // 统计成功更新的数量
      for (const result of results) {
        if (result.status === 'fulfilled' && result.value) {
          updatedCount++;
        }
      }

      // 批间延迟，避免过度负载
      if (batches.length > 1) {
        await this.delay(50); // 减少延迟，因为本地查询更快
      }
    }
    return updatedCount;
  }

  /**
   * 🆕 基于本地关系数据更新单个实体的最近数据缓存
   */
  async updateEntityRecentDataFromRelations(entity) {
    try {
      const entityName = entity.name;
      let hasUpdates = false;

      // 🔗 1. 获取实体的关系网络（深度1，只获取直接相关的实体）
      const relationshipNetwork = await this.getRelationshipNetwork(entity.id, 1);
      if (relationshipNetwork.relationships.length === 0) {
        // console.log(`实体 ${entityName} 没有发现关系数据`);
        return false;
      }

      // 📊 2. 按数据来源分类关系
      const relationshipsBySource = {
        conversations: [],
        webpages: [],
        projects: [],
        resources: []
      };
      for (const relationship of relationshipNetwork.relationships) {
        const properties = relationship.properties || {};
        const source = properties.source;
        const discoveredAt = properties.discoveredAt || relationship.created;

        // 构建基础数据对象
        const baseData = {
          id: properties.messageId || properties.webpageId || properties.projectId || relationship.id,
          relationshipId: relationship.id,
          timestamp: discoveredAt,
          relationType: relationship.type,
          strength: relationship.strength
        };

        // 根据数据来源分类
        switch (source) {
          case 'message':
            relationshipsBySource.conversations.push({
              ...baseData,
              content: `通过关系"${relationship.type}"发现的相关消息`,
              summary: `与${this.getRelatedEntityName(relationship, entity.id)}的关系`,
              sender: 'system',
              // 可以后续优化为从原始消息获取
              messageId: properties.messageId
            });
            break;
          case 'webpage':
            relationshipsBySource.webpages.push({
              ...baseData,
              title: `通过关系"${relationship.type}"发现的相关网页`,
              url: properties.url || '',
              summary: `与${this.getRelatedEntityName(relationship, entity.id)}的关系`,
              visitTime: discoveredAt,
              domain: properties.domain || 'unknown'
            });
            break;
          case 'project':
            relationshipsBySource.projects.push({
              ...baseData,
              name: `通过关系"${relationship.type}"发现的相关项目`,
              description: `与${this.getRelatedEntityName(relationship, entity.id)}的关系`,
              status: properties.status || 'active'
            });
            break;
          default:
            // 其他类型归类为资源
            relationshipsBySource.resources.push({
              ...baseData,
              name: `通过关系"${relationship.type}"发现的相关资源`,
              description: `与${this.getRelatedEntityName(relationship, entity.id)}的关系`,
              type: source || 'unknown'
            });
            break;
        }
      }

      // 📝 3. 批量更新最近数据缓存
      const updatePromises = [];

      // 更新conversations
      if (relationshipsBySource.conversations.length > 0) {
        const sortedConversations = relationshipsBySource.conversations.sort((a, b) => b.timestamp - a.timestamp).slice(0, this.config.recentDataQueryLimit);
        for (const conversation of sortedConversations) {
          updatePromises.push(this.updateRecentData(entity.id, 'conversation', conversation));
        }
        hasUpdates = true;
      }

      // 更新webpages
      if (relationshipsBySource.webpages.length > 0) {
        const sortedWebpages = relationshipsBySource.webpages.sort((a, b) => b.timestamp - a.timestamp).slice(0, this.config.recentDataQueryLimit);
        for (const webpage of sortedWebpages) {
          updatePromises.push(this.updateRecentData(entity.id, 'webpage', webpage));
        }
        hasUpdates = true;
      }

      // 更新projects
      if (relationshipsBySource.projects.length > 0) {
        const sortedProjects = relationshipsBySource.projects.sort((a, b) => b.timestamp - a.timestamp).slice(0, this.config.recentDataQueryLimit);
        for (const project of sortedProjects) {
          updatePromises.push(this.updateRecentData(entity.id, 'project', project));
        }
        hasUpdates = true;
      }

      // 更新resources
      if (relationshipsBySource.resources.length > 0) {
        const sortedResources = relationshipsBySource.resources.sort((a, b) => b.timestamp - a.timestamp).slice(0, this.config.recentDataQueryLimit);
        for (const resource of sortedResources) {
          updatePromises.push(this.updateRecentData(entity.id, 'resource', resource));
        }
        hasUpdates = true;
      }

      // 🚀 4. 并行执行所有更新
      if (updatePromises.length > 0) {
        await Promise.allSettled(updatePromises);
        console.log(`📝 基于${relationshipNetwork.relationships.length}个关系更新了实体 ${entityName} 的最近数据缓存`);
      }
      return hasUpdates;
    } catch (error) {
      console.error(`基于关系数据更新实体 ${entity.name} 的最近数据缓存失败:`, error);
      return false;
    }
  }

  /**
   * 🔗 获取关系中相关实体的名称
   */
  getRelatedEntityName(relationship, currentEntityId) {
    const relatedEntityId = relationship.fromId === currentEntityId ? relationship.toId : relationship.fromId;

    // 从实体ID中提取可读名称（简化版）
    const namePart = relatedEntityId.split('_').slice(1).join(' ');
    return namePart || relatedEntityId;
  }

  /**
   * 🆕 更新聚合关系数据到本地存储（用于云端同步）- 简化版
   */
  async updateAggregatedRelationshipData() {
    this.ensureInitialized();
    try {
      // 🆕 获取简化的关系数据
      const backupData = await this.getSimplifiedRelationshipData();
      if (backupData) {
        // 存储简化的关系数据
        await chrome.storage.local.set({
          'cache_graph_relationships': {
            relationships: backupData.relationships,
            typeToEntities: backupData.typeToEntities,
            lastUpdated: Date.now()
            // 🚫 移除冗余的 entityToRelations
          }
        });
        console.log(`📊 更新聚合关系数据: ${backupData.relationships.length} 个关系`);
      }
    } catch (error) {
      console.error('更新聚合关系数据失败:', error);
    }
  }

  // ==================== 主题详情缓存 ====================

  // ==================== 实体格式转换辅助方法 ====================

  /**
   * 确保 CachedEntityDetail 包含所有必要字段
   */
  ensureDetailEntityFields(entity) {
    if (!entity.recentDataDetails) {
      entity.recentDataDetails = {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      };
    }
    if (!entity.relatedParticipants) entity.relatedParticipants = [];
    if (!entity.statistic) {
      entity.statistic = {
        conversations: entity.recentDataDetails.conversations.length,
        projects: entity.recentDataDetails.projects.length,
        participants: entity.relatedParticipants.length,
        resources: entity.recentDataDetails.resources.length,
        documents: entity.recentDataDetails.resources.filter(r => r.type === '文档').length,
        webpages: entity.recentDataDetails.webpages.length,
        relationships: 0,
        topics: entity.recentDataDetails.topics.length,
        jiraTickets: entity.recentDataDetails.jiraTickets.length
      };
    }
    if (!entity.cachedAt) entity.cachedAt = Date.now();
    if (!entity.lastUpdated) entity.lastUpdated = Date.now();
  }

  /**
   * 将 CachedEntityDetail 转换为基础的 MemoryEntity（用于内存存储）
   */
  convertToBaseEntity(detailEntity) {
    return {
      id: detailEntity.id,
      type: detailEntity.type,
      name: detailEntity.name,
      description: detailEntity.description,
      properties: detailEntity.properties,
      created: detailEntity.created,
      updated: detailEntity.updated,
      accessCount: detailEntity.accessCount,
      lastAccessed: detailEntity.lastAccessed,
      importance: detailEntity.importance,
      tags: detailEntity.tags,
      status: detailEntity.status,
      searchDistance: detailEntity.searchDistance,
      relevanceScore: detailEntity.relevanceScore,
      statistic: detailEntity.statistic,
      relatedData: detailEntity.relatedData,
      readStatus: detailEntity.readStatus
    };
  }

  /**
   * 将基础 MemoryEntity 转换为 CachedEntityDetail
   */
  convertToDetailEntity(baseEntity) {
    const detailEntity = {
      ...baseEntity,
      cachedAt: Date.now(),
      recentDataDetails: {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      },
      relatedParticipants: [],
      lastUpdated: Date.now()
    };
    this.ensureDetailEntityFields(detailEntity);
    return detailEntity;
  }

  /**
   * 检查实体是否为 CachedEntityDetail 格式
   */
  isCachedEntityDetail(entity) {
    return 'recentDataDetails' in entity && 'cachedAt' in entity;
  }

  // ==================== 统计信息缓存 ====================

  /**
   * 获取实体统计信息
   */
  async getEntityStatistics() {
    this.ensureInitialized();
    try {
      const result = await chrome.storage.local.get(CACHE_KEYS.STATISTICS);
      const cached = result[CACHE_KEYS.STATISTICS];
      if (cached && Date.now() - cached.cachedAt < this.config.statisticsCacheDuration) {
        return cached.data;
      }

      // 重新计算统计信息
      return await this.calculateStatistics();
    } catch (error) {
      console.error('获取统计信息失败:', error);
      return {
        entityCounts: {},
        totalEntities: 0,
        totalRelationships: 0,
        entitiesCreatedToday: 0,
        entitiesCreatedThisWeek: 0,
        entitiesCreatedThisMonth: 0,
        topEntitiesByType: {}
      };
    }
  }

  // ==================== 缓存管理 ====================

  /**
   * 清理过期缓存
   */
  async clearExpiredCache() {
    this.ensureInitialized();
    try {
      const now = Date.now();
      const allKeys = await this.getAllCacheKeys();
      const keysToRemove = [];
      for (const key of allKeys) {
        if (key.startsWith(CACHE_KEYS.ENTITIES)) {
          const result = await chrome.storage.local.get(key);
          const data = result[key];

          // 只清理有 cachedAt 字段的 CachedEntityDetail 实体（表示有详细缓存数据）
          if (data && data.cachedAt && this.isCachedEntityDetail(data)) {
            const age = now - data.cachedAt;
            const maxAge = this.config.recentDataCacheDuration;
            if (age > maxAge) {
              keysToRemove.push(key);
            }
          }
        }
      }
      if (keysToRemove.length > 0) {
        await chrome.storage.local.remove(keysToRemove);
        console.log(`🧹 清理了 ${keysToRemove.length} 个过期缓存项`);
      }
    } catch (error) {
      console.error('清理过期缓存失败:', error);
    }
  }

  /**
   * 获取缓存大小
   */
  async getCacheSize() {
    try {
      const result = await chrome.storage.local.getBytesInUse();
      return result;
    } catch (error) {
      console.error('获取缓存大小失败:', error);
      return 0;
    }
  }

  // ==================== 私有方法 ====================

  async loadEntitiesToMemory() {
    try {
      const entityIndex = await this.getEntityIndex();
      const entityIds = Object.keys(entityIndex);
      let loadedCount = 0;
      for (const entityId of entityIds) {
        if (loadedCount >= this.config.maxEntitiesInMemory) break;
        const result = await chrome.storage.local.get(`${CACHE_KEYS.ENTITIES}_${entityId}`);
        const entity = result[`${CACHE_KEYS.ENTITIES}_${entityId}`];
        if (entity) {
          this.memoryEntities.set(entityId, entity);
          loadedCount++;
        }
      }
      console.log(`📥 加载了 ${loadedCount} 个实体到内存`);
    } catch (error) {
      console.error('加载实体到内存失败:', error);
    }
  }
  async loadRelationshipsToMemory() {
    try {
      const relationshipIndex = await this.getRelationshipIndex();
      const allRelationshipIds = Object.values(relationshipIndex).flat();
      for (const relationshipId of allRelationshipIds) {
        const result = await chrome.storage.local.get(`${CACHE_KEYS.RELATIONSHIPS}_${relationshipId}`);
        const relationship = result[`${CACHE_KEYS.RELATIONSHIPS}_${relationshipId}`];
        if (relationship) {
          this.memoryRelationships.set(relationshipId, relationship);
        }
      }
      console.log(`📥 加载了 ${this.memoryRelationships.size} 个关系到内存`);
    } catch (error) {
      console.error('加载关系到内存失败:', error);
    }
  }
  async getEntityIndex() {
    try {
      const result = await chrome.storage.local.get(CACHE_KEYS.ENTITY_INDEX);
      return result[CACHE_KEYS.ENTITY_INDEX] || {};
    } catch (error) {
      console.error('获取实体索引失败:', error);
      return {};
    }
  }
  async getTypeIndex() {
    try {
      const result = await chrome.storage.local.get(CACHE_KEYS.TYPE_INDEX);
      return result[CACHE_KEYS.TYPE_INDEX] || {};
    } catch (error) {
      console.error('获取类型索引失败:', error);
      return {};
    }
  }
  async getRelationshipIndex() {
    try {
      const result = await chrome.storage.local.get(CACHE_KEYS.RELATIONSHIP_INDEX);
      return result[CACHE_KEYS.RELATIONSHIP_INDEX] || {};
    } catch (error) {
      console.error('获取关系索引失败:', error);
      return {};
    }
  }
  async updateEntityIndex(entity) {
    try {
      const entityIndex = await this.getEntityIndex();
      const typeIndex = await this.getTypeIndex();

      // 更新实体索引
      entityIndex[entity.id] = {
        type: entity.type,
        name: entity.name,
        lastAccessed: entity.lastAccessed,
        inMemory: this.memoryEntities.has(entity.id)
      };

      // 更新类型索引
      if (!typeIndex[entity.type]) {
        typeIndex[entity.type] = [];
      }
      if (!typeIndex[entity.type].includes(entity.id)) {
        typeIndex[entity.type].push(entity.id);
      }
      await chrome.storage.local.set({
        [CACHE_KEYS.ENTITY_INDEX]: entityIndex,
        [CACHE_KEYS.TYPE_INDEX]: typeIndex
      });
    } catch (error) {
      console.error('更新实体索引失败:', error);
    }
  }
  async updateRelationshipIndex(relationship) {
    try {
      const relationshipIndex = await this.getRelationshipIndex();

      // 为源实体和目标实体添加关系引用
      if (!relationshipIndex[relationship.fromId]) {
        relationshipIndex[relationship.fromId] = [];
      }
      if (!relationshipIndex[relationship.fromId].includes(relationship.id)) {
        relationshipIndex[relationship.fromId].push(relationship.id);
      }
      if (!relationshipIndex[relationship.toId]) {
        relationshipIndex[relationship.toId] = [];
      }
      if (!relationshipIndex[relationship.toId].includes(relationship.id)) {
        relationshipIndex[relationship.toId].push(relationship.id);
      }
      await chrome.storage.local.set({
        [CACHE_KEYS.RELATIONSHIP_INDEX]: relationshipIndex
      });
    } catch (error) {
      console.error('更新关系索引失败:', error);
    }
  }
  findLRUEntity() {
    let lruEntity = null;
    let lruTime = Date.now();
    for (const entity of Array.from(this.memoryEntities.values())) {
      if (entity.lastAccessed < lruTime) {
        lruTime = entity.lastAccessed;
        lruEntity = entity;
      }
    }
    return lruEntity;
  }
  calculateRelevanceScore(entity, searchTerm) {
    let score = 0;
    const searchLower = searchTerm.toLowerCase();

    // 名称匹配（权重最高）
    if (entity.name.toLowerCase().includes(searchLower)) {
      score += 10;
      if (entity.name.toLowerCase().startsWith(searchLower)) {
        score += 5; // 前缀匹配加分
      }
    }

    // 描述匹配
    if (entity.description?.toLowerCase().includes(searchLower)) {
      score += 3;
    }

    // 标签匹配
    entity.tags?.forEach(tag => {
      if (tag.toLowerCase().includes(searchLower)) {
        score += 2;
      }
    });

    // 重要性加权
    score *= entity.importance || 0.5;
    return score;
  }
  async traverseRelationships(entityId, remainingDepth, visited, foundEntities, foundRelationships) {
    if (remainingDepth <= 0 || visited.has(entityId)) return;
    visited.add(entityId);

    // 获取当前实体（可能不存在）
    const entity = await this.getEntity(entityId);
    if (entity) {
      foundEntities.push(entity);
    } else {
      console.warn(`关系遍历中发现缺失实体: ${entityId}`);
    }

    // 获取相关关系
    const relationshipIndex = await this.getRelationshipIndex();
    const relationshipIds = relationshipIndex[entityId] || [];
    for (const relationshipId of relationshipIds) {
      const relationship = this.memoryRelationships.get(relationshipId);
      if (relationship) {
        // 🆕 优化：区分实体-实体关系和实体-消息关系
        const isEntityMessageRelation = relationship.type === 'discovered_in';
        if (isEntityMessageRelation) {
          // 对于实体-消息关系，只验证实体端
          const entitySideId = relationship.fromId === entityId ? relationship.fromId : relationship.toId;
          const messageSideId = relationship.fromId === entityId ? relationship.toId : relationship.fromId;
          if (await this.getEntity(entitySideId)) {
            foundRelationships.push(relationship);
            console.log(`🔗 发现实体-消息关系: ${entitySideId} -> ${messageSideId.slice(0, 8)}`);
          }

          // 实体-消息关系不继续递归遍历
        } else {
          // 对于实体-实体关系，验证两端实体
          const fromEntity = await this.getEntity(relationship.fromId);
          const toEntity = await this.getEntity(relationship.toId);
          if (fromEntity || toEntity) {
            foundRelationships.push(relationship);

            // 递归遍历相关实体
            const relatedEntityId = relationship.fromId === entityId ? relationship.toId : relationship.fromId;
            if (await this.getEntity(relatedEntityId)) {
              await this.traverseRelationships(relatedEntityId, remainingDepth - 1, visited, foundEntities, foundRelationships);
            }
          }
        }
      }
    }
  }
  async calculateStatistics() {
    const now = Date.now();
    const today = new Date().toDateString();
    const thisWeek = now - 7 * 24 * 60 * 60 * 1000;
    const thisMonth = now - 30 * 24 * 60 * 60 * 1000;
    const entityCounts = {};
    let totalEntities = 0;
    let entitiesCreatedToday = 0;
    let entitiesCreatedThisWeek = 0;
    let entitiesCreatedThisMonth = 0;
    const topEntitiesByType = {};

    // 统计内存中的实体
    for (const entity of Array.from(this.memoryEntities.values())) {
      totalEntities++;
      entityCounts[entity.type] = (entityCounts[entity.type] || 0) + 1;

      // 时间统计
      const entityDate = new Date(entity.created).toDateString();
      if (entityDate === today) entitiesCreatedToday++;
      if (entity.created >= thisWeek) entitiesCreatedThisWeek++;
      if (entity.created >= thisMonth) entitiesCreatedThisMonth++;

      // 顶级实体
      if (!topEntitiesByType[entity.type]) {
        topEntitiesByType[entity.type] = [];
      }
      topEntitiesByType[entity.type].push(entity);
    }

    // 对每种类型的实体按重要性排序，取前5个
    for (const type in topEntitiesByType) {
      topEntitiesByType[type] = topEntitiesByType[type].sort((a, b) => b.importance - a.importance).slice(0, 5);
    }
    const statistics = {
      entityCounts,
      totalEntities,
      totalRelationships: this.memoryRelationships.size,
      entitiesCreatedToday,
      entitiesCreatedThisWeek,
      entitiesCreatedThisMonth,
      topEntitiesByType
    };

    // 缓存统计信息
    await chrome.storage.local.set({
      [CACHE_KEYS.STATISTICS]: {
        data: statistics,
        cachedAt: now
      }
    });
    return statistics;
  }
  async getAllCacheKeys() {
    try {
      const allKeys = await chrome.storage.local.get();
      return Object.keys(allKeys).filter(key => key.startsWith('cache_'));
    } catch (error) {
      console.error('获取所有缓存键失败:', error);
      return [];
    }
  }
  startPeriodicCleanup() {
    // 每小时清理一次过期缓存
    setInterval(() => {
      this.clearExpiredCache();
    }, 60 * 60 * 1000);
  }
  chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }
  async delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * 创建空的扩展缓存对象
   */
  createEmptyExtendedCache(entityId) {
    return {
      lastUpdated: Date.now(),
      cachedAt: Date.now(),
      // 关联数据字段
      relatedData: {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      },
      recentDataDetails: {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      },
      expertise: [],
      // 统计字段
      statistic: {
        conversations: 0,
        projects: 0,
        participants: 0,
        resources: 0,
        documents: 0,
        webpages: 0,
        relationships: 0,
        topics: 0,
        jiraTickets: 0
      }
    };
  }

  /**
   * 确保缓存数据包含所有必要的UI字段
   */
  ensureUIFields(cache) {
    // 如果缺少UI字段，重新计算
    if (!cache.statistic || !cache.recentDataDetails) {
      this.recalculateUIFields(cache);
    }
  }

  /**
   * 重新计算UI字段
   */
  recalculateUIFields(cache) {
    // 确保缓存字段存在（使用正确的字段名）
    if (!cache.recentDataDetails) {
      cache.recentDataDetails = {
        conversations: [],
        webpages: [],
        resources: [],
        projects: [],
        people: [],
        topics: [],
        jiraTickets: [],
        cooccurringEntities: []
      };
    }

    // 更新统计字段到 statistic 对象中
    if (!cache.statistic) {
      cache.statistic = {
        conversations: 0,
        projects: 0,
        participants: 0,
        resources: 0,
        documents: 0,
        webpages: 0,
        relationships: 0,
        topics: 0,
        jiraTickets: 0
      };
    }

    // 重新计算统计字段
    cache.statistic.conversations = cache.recentDataDetails.conversations.length;
    cache.statistic.webpages = cache.recentDataDetails.webpages.length;
    cache.statistic.resources = cache.recentDataDetails.resources.length;
    cache.statistic.projects = cache.recentDataDetails.projects.length;
    cache.statistic.topics = cache.recentDataDetails.topics.length;
    cache.statistic.jiraTickets = cache.recentDataDetails.jiraTickets.length;

    // 确保必要字段存在
    if (!cache.expertise) cache.expertise = [];
    if (!cache.lastUpdated) cache.lastUpdated = Date.now();
  }

  /**
   * 获取所有本地缓存的实体数据（用于统计信息上传）
   */
  async getAllRecentDataEntries() {
    this.ensureInitialized();
    try {
      const entityEntries = [];

      // 获取所有键，然后过滤出 ENTITIES 相关的键
      const allKeys = await this.getAllCacheKeys();
      for (const key of allKeys) {
        if (key.startsWith(CACHE_KEYS.ENTITIES + '_')) {
          try {
            const result = await chrome.storage.local.get(key);
            const data = result[key];
            if (data && this.isCachedEntityDetail(data)) {
              // 检查数据是否过期
              const now = Date.now();
              if (data.cachedAt && now - data.cachedAt < this.config.recentDataCacheDuration) {
                entityEntries.push(data);
              }
            }
          } catch (error) {
            console.error(`解析缓存数据失败 (${key}):`, error);
          }
        }
      }
      console.log(`📊 找到 ${entityEntries.length} 个本地缓存实体`);
      return entityEntries;
    } catch (error) {
      console.error('获取所有本地缓存数据失败:', error);
      return [];
    }
  }
  ensureInitialized() {
    if (!this.isInitialized) {
      throw new Error('本地缓存未初始化');
    }
  }
}

/***/ }),

/***/ 9266:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  AdminClient: () => (/* binding */ AdminClient),
  AdminCloudClient: () => (/* binding */ AdminCloudClient),
  ChromaClient: () => (/* binding */ ChromaClient),
  ChromaClientError: () => (/* binding */ ChromaClientError),
  ChromaConnectionError: () => (/* binding */ ChromaConnectionError),
  ChromaError: () => (/* binding */ ChromaError),
  ChromaForbiddenError: () => (/* binding */ ChromaForbiddenError),
  ChromaNotFoundError: () => (/* binding */ ChromaNotFoundError),
  ChromaQuotaExceededError: () => (/* binding */ ChromaQuotaExceededError),
  ChromaRateLimitError: () => (/* binding */ ChromaRateLimitError),
  ChromaServerError: () => (/* binding */ ChromaServerError),
  ChromaUnauthorizedError: () => (/* binding */ ChromaUnauthorizedError),
  ChromaUniqueError: () => (/* binding */ ChromaUniqueError),
  ChromaValueError: () => (/* binding */ ChromaValueError),
  CloudClient: () => (/* binding */ CloudClient),
  GetResult: () => (/* binding */ GetResult),
  IncludeEnum: () => (/* binding */ IncludeEnum),
  InvalidArgumentError: () => (/* binding */ InvalidArgumentError),
  InvalidCollectionError: () => (/* binding */ InvalidCollectionError),
  QueryResult: () => (/* binding */ QueryResult),
  baseRecordSetFields: () => (/* binding */ baseRecordSetFields),
  createErrorByType: () => (/* binding */ createErrorByType),
  getDefaultEFConfig: () => (/* binding */ getDefaultEFConfig),
  getEmbeddingFunction: () => (/* binding */ getEmbeddingFunction),
  knownEmbeddingFunctions: () => (/* binding */ knownEmbeddingFunctions),
  processCreateCollectionConfig: () => (/* binding */ processCreateCollectionConfig),
  processUpdateCollectionConfig: () => (/* binding */ processUpdateCollectionConfig),
  recordSetFields: () => (/* binding */ recordSetFields),
  registerEmbeddingFunction: () => (/* binding */ registerEmbeddingFunction),
  serializeEmbeddingFunction: () => (/* binding */ serializeEmbeddingFunction),
  withChroma: () => (/* binding */ withChroma)
});

;// CONCATENATED MODULE: ./node_modules/chromadb/dist/chunk-NSSMTXJJ.mjs
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);


//# sourceMappingURL=chunk-NSSMTXJJ.mjs.map
// EXTERNAL MODULE: ./node_modules/process/browser.js
var browser = __webpack_require__(5606);
;// CONCATENATED MODULE: ./node_modules/chromadb/dist/chromadb.mjs


// src/deno.ts
if (typeof globalThis.Deno !== "undefined") {
  const OriginalRequest = globalThis.Request;
  const PatchedRequest = function(input, init) {
    if (init && typeof init === "object") {
      const cleanInit = { ...init };
      if ("client" in cleanInit) {
        delete cleanInit.client;
      }
      return new OriginalRequest(input, cleanInit);
    }
    return new OriginalRequest(input, init);
  };
  Object.setPrototypeOf(PatchedRequest, OriginalRequest);
  Object.defineProperty(PatchedRequest, "prototype", {
    value: OriginalRequest.prototype,
    writable: false
  });
  globalThis.Request = PatchedRequest;
}

// src/types.ts
var baseRecordSetFields = [
  "ids",
  "embeddings",
  "metadatas",
  "documents",
  "uris"
];
var recordSetFields = [...baseRecordSetFields, "ids"];
var IncludeEnum = /* @__PURE__ */ ((IncludeEnum2) => {
  IncludeEnum2["distances"] = "distances";
  IncludeEnum2["documents"] = "documents";
  IncludeEnum2["embeddings"] = "embeddings";
  IncludeEnum2["metadatas"] = "metadatas";
  IncludeEnum2["uris"] = "uris";
  return IncludeEnum2;
})(IncludeEnum || {});
var GetResult = class {
  /**
   * Creates a new GetResult instance.
   * @param data - The result data containing all fields
   */
  constructor({
    documents,
    embeddings,
    ids,
    include,
    metadatas,
    uris
  }) {
    this.documents = documents;
    this.embeddings = embeddings;
    this.ids = ids;
    this.include = include;
    this.metadatas = metadatas;
    this.uris = uris;
  }
  /**
   * Converts the result to a row-based format for easier iteration.
   * @returns Object containing include fields and array of record objects
   */
  rows() {
    return this.ids.map((id, index) => {
      return {
        id,
        document: this.include.includes("documents") ? this.documents[index] : void 0,
        embedding: this.include.includes("embeddings") ? this.embeddings[index] : void 0,
        metadata: this.include.includes("metadatas") ? this.metadatas[index] : void 0,
        uri: this.include.includes("uris") ? this.uris[index] : void 0
      };
    });
  }
};
var QueryResult = class {
  /**
   * Creates a new QueryResult instance.
   * @param data - The query result data containing all fields
   */
  constructor({
    distances,
    documents,
    embeddings,
    ids,
    include,
    metadatas,
    uris
  }) {
    this.distances = distances;
    this.documents = documents;
    this.embeddings = embeddings;
    this.ids = ids;
    this.include = include;
    this.metadatas = metadatas;
    this.uris = uris;
  }
  /**
   * Converts the query result to a row-based format for easier iteration.
   * @returns Object containing include fields and structured query results
   */
  rows() {
    const queries = [];
    for (let q2 = 0; q2 < this.ids.length; q2++) {
      const records = this.ids[q2].map((id, index) => {
        return {
          id,
          document: this.include.includes("documents") ? this.documents[q2][index] : void 0,
          embedding: this.include.includes("embeddings") ? this.embeddings[q2][index] : void 0,
          metadata: this.include.includes("metadatas") ? this.metadatas[q2][index] : void 0,
          uri: this.include.includes("uris") ? this.uris[q2][index] : void 0,
          distance: this.include.includes("distances") ? this.distances[q2][index] : void 0
        };
      });
      queries.push(records);
    }
    return queries;
  }
};

// ../../node_modules/.pnpm/@hey-api+client-fetch@0.10.0_@hey-api+openapi-ts@0.67.3_typescript@5.8.3_/node_modules/@hey-api/client-fetch/dist/index.js
var A = async (t, r) => {
  let e = typeof r == "function" ? await r(t) : r;
  if (e) return t.scheme === "bearer" ? `Bearer ${e}` : t.scheme === "basic" ? `Basic ${btoa(e)}` : e;
};
var R = { bodySerializer: (t) => JSON.stringify(t, (r, e) => typeof e == "bigint" ? e.toString() : e) };
var U = (t) => {
  switch (t) {
    case "label":
      return ".";
    case "matrix":
      return ";";
    case "simple":
      return ",";
    default:
      return "&";
  }
};
var _ = (t) => {
  switch (t) {
    case "form":
      return ",";
    case "pipeDelimited":
      return "|";
    case "spaceDelimited":
      return "%20";
    default:
      return ",";
  }
};
var D = (t) => {
  switch (t) {
    case "label":
      return ".";
    case "matrix":
      return ";";
    case "simple":
      return ",";
    default:
      return "&";
  }
};
var O = ({ allowReserved: t, explode: r, name: e, style: a, value: i }) => {
  if (!r) {
    let s = (t ? i : i.map((l) => encodeURIComponent(l))).join(_(a));
    switch (a) {
      case "label":
        return `.${s}`;
      case "matrix":
        return `;${e}=${s}`;
      case "simple":
        return s;
      default:
        return `${e}=${s}`;
    }
  }
  let o = U(a), n = i.map((s) => a === "label" || a === "simple" ? t ? s : encodeURIComponent(s) : y({ allowReserved: t, name: e, value: s })).join(o);
  return a === "label" || a === "matrix" ? o + n : n;
};
var y = ({ allowReserved: t, name: r, value: e }) => {
  if (e == null) return "";
  if (typeof e == "object") throw new Error("Deeply-nested arrays/objects aren\u2019t supported. Provide your own `querySerializer()` to handle these.");
  return `${r}=${t ? e : encodeURIComponent(e)}`;
};
var q = ({ allowReserved: t, explode: r, name: e, style: a, value: i }) => {
  if (i instanceof Date) return `${e}=${i.toISOString()}`;
  if (a !== "deepObject" && !r) {
    let s = [];
    Object.entries(i).forEach(([f, u]) => {
      s = [...s, f, t ? u : encodeURIComponent(u)];
    });
    let l = s.join(",");
    switch (a) {
      case "form":
        return `${e}=${l}`;
      case "label":
        return `.${l}`;
      case "matrix":
        return `;${e}=${l}`;
      default:
        return l;
    }
  }
  let o = D(a), n = Object.entries(i).map(([s, l]) => y({ allowReserved: t, name: a === "deepObject" ? `${e}[${s}]` : s, value: l })).join(o);
  return a === "label" || a === "matrix" ? o + n : n;
};
var H = /\{[^{}]+\}/g;
var B = ({ path: t, url: r }) => {
  let e = r, a = r.match(H);
  if (a) for (let i of a) {
    let o = false, n = i.substring(1, i.length - 1), s = "simple";
    n.endsWith("*") && (o = true, n = n.substring(0, n.length - 1)), n.startsWith(".") ? (n = n.substring(1), s = "label") : n.startsWith(";") && (n = n.substring(1), s = "matrix");
    let l = t[n];
    if (l == null) continue;
    if (Array.isArray(l)) {
      e = e.replace(i, O({ explode: o, name: n, style: s, value: l }));
      continue;
    }
    if (typeof l == "object") {
      e = e.replace(i, q({ explode: o, name: n, style: s, value: l }));
      continue;
    }
    if (s === "matrix") {
      e = e.replace(i, `;${y({ name: n, value: l })}`);
      continue;
    }
    let f = encodeURIComponent(s === "label" ? `.${l}` : l);
    e = e.replace(i, f);
  }
  return e;
};
var E = ({ allowReserved: t, array: r, object: e } = {}) => (i) => {
  let o = [];
  if (i && typeof i == "object") for (let n in i) {
    let s = i[n];
    if (s != null) {
      if (Array.isArray(s)) {
        o = [...o, O({ allowReserved: t, explode: true, name: n, style: "form", value: s, ...r })];
        continue;
      }
      if (typeof s == "object") {
        o = [...o, q({ allowReserved: t, explode: true, name: n, style: "deepObject", value: s, ...e })];
        continue;
      }
      o = [...o, y({ allowReserved: t, name: n, value: s })];
    }
  }
  return o.join("&");
};
var P = (t) => {
  if (!t) return "stream";
  let r = t.split(";")[0]?.trim();
  if (r) {
    if (r.startsWith("application/json") || r.endsWith("+json")) return "json";
    if (r === "multipart/form-data") return "formData";
    if (["application/", "audio/", "image/", "video/"].some((e) => r.startsWith(e))) return "blob";
    if (r.startsWith("text/")) return "text";
  }
};
var I = async ({ security: t, ...r }) => {
  for (let e of t) {
    let a = await A(e, r.auth);
    if (!a) continue;
    let i = e.name ?? "Authorization";
    switch (e.in) {
      case "query":
        r.query || (r.query = {}), r.query[i] = a;
        break;
      case "cookie":
        r.headers.append("Cookie", `${i}=${a}`);
        break;
      case "header":
      default:
        r.headers.set(i, a);
        break;
    }
    return;
  }
};
var S = (t) => W({ baseUrl: t.baseUrl, path: t.path, query: t.query, querySerializer: typeof t.querySerializer == "function" ? t.querySerializer : E(t.querySerializer), url: t.url });
var W = ({ baseUrl: t, path: r, query: e, querySerializer: a, url: i }) => {
  let o = i.startsWith("/") ? i : `/${i}`, n = (t ?? "") + o;
  r && (n = B({ path: r, url: n }));
  let s = e ? a(e) : "";
  return s.startsWith("?") && (s = s.substring(1)), s && (n += `?${s}`), n;
};
var C = (t, r) => {
  let e = { ...t, ...r };
  return e.baseUrl?.endsWith("/") && (e.baseUrl = e.baseUrl.substring(0, e.baseUrl.length - 1)), e.headers = x(t.headers, r.headers), e;
};
var x = (...t) => {
  let r = new Headers();
  for (let e of t) {
    if (!e || typeof e != "object") continue;
    let a = e instanceof Headers ? e.entries() : Object.entries(e);
    for (let [i, o] of a) if (o === null) r.delete(i);
    else if (Array.isArray(o)) for (let n of o) r.append(i, n);
    else o !== void 0 && r.set(i, typeof o == "object" ? JSON.stringify(o) : o);
  }
  return r;
};
var h = class {
  constructor() {
    __publicField(this, "_fns");
    this._fns = [];
  }
  clear() {
    this._fns = [];
  }
  exists(r) {
    return this._fns.indexOf(r) !== -1;
  }
  eject(r) {
    let e = this._fns.indexOf(r);
    e !== -1 && (this._fns = [...this._fns.slice(0, e), ...this._fns.slice(e + 1)]);
  }
  use(r) {
    this._fns = [...this._fns, r];
  }
};
var T = () => ({ error: new h(), request: new h(), response: new h() });
var N = E({ allowReserved: false, array: { explode: true, style: "form" }, object: { explode: true, style: "deepObject" } });
var Q = { "Content-Type": "application/json" };
var w = (t = {}) => ({ ...R, headers: Q, parseAs: "auto", querySerializer: N, ...t });
var J = (t = {}) => {
  let r = C(w(), t), e = () => ({ ...r }), a = (n) => (r = C(r, n), e()), i = T(), o = async (n) => {
    let s = { ...r, ...n, fetch: n.fetch ?? r.fetch ?? globalThis.fetch, headers: x(r.headers, n.headers) };
    s.security && await I({ ...s, security: s.security }), s.body && s.bodySerializer && (s.body = s.bodySerializer(s.body)), (s.body === void 0 || s.body === "") && s.headers.delete("Content-Type");
    let l = S(s), f = { redirect: "follow", ...s }, u = new Request(l, f);
    for (let p of i.request._fns) u = await p(u, s);
    let k = s.fetch, c = await k(u);
    for (let p of i.response._fns) c = await p(c, u, s);
    let m = { request: u, response: c };
    if (c.ok) {
      if (c.status === 204 || c.headers.get("Content-Length") === "0") return { data: {}, ...m };
      let p = (s.parseAs === "auto" ? P(c.headers.get("Content-Type")) : s.parseAs) ?? "json";
      if (p === "stream") return { data: c.body, ...m };
      let b = await c[p]();
      return p === "json" && (s.responseValidator && await s.responseValidator(b), s.responseTransformer && (b = await s.responseTransformer(b))), { data: b, ...m };
    }
    let g = await c.text();
    try {
      g = JSON.parse(g);
    } catch {
    }
    let d = g;
    for (let p of i.error._fns) d = await p(g, c, u, s);
    if (d = d || {}, s.throwOnError) throw d;
    return { error: d, ...m };
  };
  return { buildUrl: S, connect: (n) => o({ ...n, method: "CONNECT" }), delete: (n) => o({ ...n, method: "DELETE" }), get: (n) => o({ ...n, method: "GET" }), getConfig: e, head: (n) => o({ ...n, method: "HEAD" }), interceptors: i, options: (n) => o({ ...n, method: "OPTIONS" }), patch: (n) => o({ ...n, method: "PATCH" }), post: (n) => o({ ...n, method: "POST" }), put: (n) => o({ ...n, method: "PUT" }), request: o, setConfig: a, trace: (n) => o({ ...n, method: "TRACE" }) };
};

// src/api/client.gen.ts
var client = J(w({
  baseUrl: "http://localhost:8000",
  throwOnError: true
}));

// src/api/sdk.gen.ts
var DefaultService = class {
  /**
   * Retrieves the current user's identity, tenant, and databases.
   */
  static getUserIdentity(options) {
    return (options?.client ?? client).get({
      url: "/api/v2/auth/identity",
      ...options
    });
  }
  /**
   * Health check endpoint that returns 200 if the server and executor are ready
   */
  static healthcheck(options) {
    return (options?.client ?? client).get({
      url: "/api/v2/healthcheck",
      ...options
    });
  }
  /**
   * Heartbeat endpoint that returns a nanosecond timestamp of the current time.
   */
  static heartbeat(options) {
    return (options?.client ?? client).get({
      url: "/api/v2/heartbeat",
      ...options
    });
  }
  /**
   * Pre-flight checks endpoint reporting basic readiness info.
   */
  static preFlightChecks(options) {
    return (options?.client ?? client).get({
      url: "/api/v2/pre-flight-checks",
      ...options
    });
  }
  /**
   * Reset endpoint allowing authorized users to reset the database.
   */
  static reset(options) {
    return (options?.client ?? client).post({
      url: "/api/v2/reset",
      ...options
    });
  }
  /**
   * Creates a new tenant.
   */
  static createTenant(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Returns an existing tenant by name.
   */
  static getTenant(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant_name}",
      ...options
    });
  }
  /**
   * Updates an existing tenant by name.
   */
  static updateTenant(options) {
    return (options.client ?? client).patch({
      url: "/api/v2/tenants/{tenant_name}",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Lists all databases for a given tenant.
   */
  static listDatabases(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases",
      ...options
    });
  }
  /**
   * Creates a new database for a given tenant.
   */
  static createDatabase(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Deletes a specific database.
   */
  static deleteDatabase(options) {
    return (options.client ?? client).delete({
      url: "/api/v2/tenants/{tenant}/databases/{database}",
      ...options
    });
  }
  /**
   * Retrieves a specific database by name.
   */
  static getDatabase(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases/{database}",
      ...options
    });
  }
  /**
   * Lists all collections in the specified database.
   */
  static listCollections(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections",
      ...options
    });
  }
  /**
   * Creates a new collection under the specified database.
   */
  static createCollection(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Deletes a collection in a given database.
   */
  static deleteCollection(options) {
    return (options.client ?? client).delete({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}",
      ...options
    });
  }
  /**
   * Retrieves a collection by ID or name.
   */
  static getCollection(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}",
      ...options
    });
  }
  /**
   * Updates an existing collection's name or metadata.
   */
  static updateCollection(options) {
    return (options.client ?? client).put({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Adds records to a collection.
   */
  static collectionAdd(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/add",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Retrieves the number of records in a collection.
   */
  static collectionCount(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/count",
      ...options
    });
  }
  /**
   * Deletes records in a collection. Can filter by IDs or metadata.
   */
  static collectionDelete(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/delete",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Forks an existing collection.
   */
  static forkCollection(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/fork",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Retrieves records from a collection by ID or metadata filter.
   */
  static collectionGet(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/get",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Query a collection in a variety of ways, including vector search, metadata filtering, and full-text search
   */
  static collectionQuery(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/query",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Updates records in a collection by ID.
   */
  static collectionUpdate(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/update",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Upserts records in a collection (create if not exists, otherwise update).
   */
  static collectionUpsert(options) {
    return (options.client ?? client).post({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections/{collection_id}/upsert",
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers
      }
    });
  }
  /**
   * Retrieves the total number of collections in a given database.
   */
  static countCollections(options) {
    return (options.client ?? client).get({
      url: "/api/v2/tenants/{tenant}/databases/{database}/collections_count",
      ...options
    });
  }
  /**
   * Returns the version of the server.
   */
  static version(options) {
    return (options?.client ?? client).get({
      url: "/api/v2/version",
      ...options
    });
  }
};

// src/errors.ts
var ChromaError = class extends Error {
  constructor(name, message, cause) {
    super(message);
    this.cause = cause;
    this.name = name;
  }
};
var ChromaConnectionError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaConnectionError";
  }
};
var ChromaServerError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaServerError";
  }
};
var ChromaClientError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaClientError";
  }
};
var ChromaUnauthorizedError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaAuthError";
  }
};
var ChromaForbiddenError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaForbiddenError";
  }
};
var ChromaNotFoundError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaNotFoundError";
  }
};
var ChromaValueError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaValueError";
  }
};
var InvalidCollectionError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "InvalidCollectionError";
  }
};
var InvalidArgumentError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "InvalidArgumentError";
  }
};
var ChromaUniqueError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaUniqueError";
  }
};
var ChromaQuotaExceededError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaQuotaExceededError";
  }
};
var ChromaRateLimitError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "ChromaRateLimitError";
  }
};
function createErrorByType(type, message) {
  switch (type) {
    case "InvalidCollection":
      return new InvalidCollectionError(message);
    case "InvalidArgumentError":
      return new InvalidArgumentError(message);
    default:
      return void 0;
  }
}

// src/utils.ts
var DEFAULT_TENANT = "default_tenant";
var DEFAULT_DATABASE = "default_database";
var defaultAdminClientArgs = {
  host: "localhost",
  port: 8e3,
  ssl: false
};
var defaultChromaClientArgs = {
  ...defaultAdminClientArgs,
  tenant: DEFAULT_TENANT,
  database: DEFAULT_DATABASE
};
var normalizeMethod = (method) => {
  if (method) {
    switch (method.toUpperCase()) {
      case "GET":
        return "GET";
      case "POST":
        return "POST";
      case "PUT":
        return "PUT";
      case "DELETE":
        return "DELETE";
      case "HEAD":
        return "HEAD";
      case "CONNECT":
        return "CONNECT";
      case "OPTIONS":
        return "OPTIONS";
      case "PATCH":
        return "PATCH";
      case "TRACE":
        return "TRACE";
      default:
        return void 0;
    }
  }
  return void 0;
};
var validateRecordSetLengthConsistency = (recordSet) => {
  const lengths = Object.entries(recordSet).filter(
    ([field, value]) => recordSetFields.includes(field) && value !== void 0
  ).map(([field, value]) => [field, value.length]);
  if (lengths.length === 0) {
    throw new ChromaValueError(
      `At least one of ${recordSetFields.join(", ")} must be provided`
    );
  }
  const zeroLength = lengths.filter(([_2, length]) => length === 0).map(([field, _2]) => field);
  if (zeroLength.length > 0) {
    throw new ChromaValueError(
      `Non-empty lists are required for ${zeroLength.join(", ")}`
    );
  }
  if (new Set(lengths.map(([_2, length]) => length)).size > 1) {
    throw new ChromaValueError(
      `Unequal lengths for fields ${lengths.map(([field, _2]) => field).join(", ")}`
    );
  }
};
var validateEmbeddings = ({
  embeddings,
  fieldName = "embeddings"
}) => {
  if (!Array.isArray(embeddings)) {
    throw new ChromaValueError(
      `Expected '${fieldName}' to be an array, but got ${typeof embeddings}`
    );
  }
  if (embeddings.length === 0) {
    throw new ChromaValueError(
      "Expected embeddings to be an array with at least one item"
    );
  }
  if (!embeddings.filter((e) => e.every((n) => typeof n === "number"))) {
    throw new ChromaValueError(
      "Expected each embedding to be an array of numbers"
    );
  }
  embeddings.forEach((embedding, i) => {
    if (embedding.length === 0) {
      throw new ChromaValueError(
        `Expected each embedding to be a non-empty array of numbers, but got an empty array at index ${i}`
      );
    }
  });
};
var validateDocuments = ({
  documents,
  nullable = false,
  fieldName = "documents"
}) => {
  if (!Array.isArray(documents)) {
    throw new ChromaValueError(
      `Expected '${fieldName}' to be an array, but got ${typeof documents}`
    );
  }
  if (documents.length === 0) {
    throw new ChromaValueError(
      `Expected '${fieldName}' to be a non-empty list`
    );
  }
  documents.forEach((document) => {
    if (!nullable && typeof document !== "string" && !document) {
      throw new ChromaValueError(
        `Expected each document to be a string, but got ${typeof document}`
      );
    }
  });
};
var validateIDs = (ids) => {
  if (!Array.isArray(ids)) {
    throw new ChromaValueError(
      `Expected 'ids' to be an array, but got ${typeof ids}`
    );
  }
  if (ids.length === 0) {
    throw new ChromaValueError("Expected 'ids' to be a non-empty list");
  }
  const nonStrings = ids.map((id, i) => [id, i]).filter(([id, _2]) => typeof id !== "string").map(([_2, i]) => i);
  if (nonStrings.length > 0) {
    throw new ChromaValueError(
      `Found non-string IDs at ${nonStrings.join(", ")}`
    );
  }
  const seen = /* @__PURE__ */ new Set();
  const duplicates = ids.filter((id) => {
    if (seen.has(id)) {
      return id;
    }
    seen.add(id);
  });
  let message = "Expected IDs to be unique, but found duplicates of";
  if (duplicates.length > 0 && duplicates.length <= 5) {
    throw new ChromaValueError(`${message} ${duplicates.join(", ")}`);
  }
  if (duplicates.length > 0) {
    throw new ChromaValueError(
      `${message} ${duplicates.slice(0, 5).join(", ")}, ..., ${duplicates.slice(duplicates.length - 5).join(", ")}`
    );
  }
};
var validateMetadata = (metadata) => {
  if (!metadata) {
    return;
  }
  if (Object.keys(metadata).length === 0) {
    throw new ChromaValueError("Expected metadata to be non-empty");
  }
  if (!Object.values(metadata).every(
    (v) => v === null || v === void 0 || typeof v === "string" || typeof v === "number" || typeof v === "boolean"
  )) {
    throw new ChromaValueError(
      "Expected metadata to be a string, number, boolean, or nullable"
    );
  }
};
var validateMetadatas = (metadatas) => {
  if (!Array.isArray(metadatas)) {
    throw new ChromaValueError(
      `Expected metadatas to be an array, but got ${typeof metadatas}`
    );
  }
  metadatas.forEach((metadata) => validateMetadata(metadata));
};
var validateBaseRecordSet = ({
  recordSet,
  update = false,
  embeddingsField = "embeddings",
  documentsField = "documents"
}) => {
  if (!recordSet.embeddings && !recordSet.documents && !update) {
    throw new ChromaValueError(
      `At least one of '${embeddingsField}' and '${documentsField}' must be provided`
    );
  }
  if (recordSet.embeddings) {
    validateEmbeddings({
      embeddings: recordSet.embeddings,
      fieldName: embeddingsField
    });
  }
  if (recordSet.documents) {
    validateDocuments({
      documents: recordSet.documents,
      fieldName: documentsField
    });
  }
  if (recordSet.metadatas) {
    validateMetadatas(recordSet.metadatas);
  }
};
var validateMaxBatchSize = (recordSetLength, maxBatchSize) => {
  if (recordSetLength > maxBatchSize) {
    throw new ChromaValueError(
      `Record set length ${recordSetLength} exceeds max batch size ${maxBatchSize}`
    );
  }
};
var validateWhere = (where) => {
  if (typeof where !== "object") {
    throw new ChromaValueError("Expected where to be a non-empty object");
  }
  if (Object.keys(where).length != 1) {
    throw new ChromaValueError(
      `Expected 'where' to have exactly one operator, but got ${Object.keys(where).length}`
    );
  }
  Object.entries(where).forEach(([key, value]) => {
    if (key !== "$and" && key !== "$or" && key !== "$in" && key !== "$nin" && !["string", "number", "boolean", "object"].includes(typeof value)) {
      throw new ChromaValueError(
        `Expected 'where' value to be a string, number, boolean, or an operator expression, but got ${value}`
      );
    }
    if (key === "$and" || key === "$or") {
      if (Object.keys(value).length <= 1) {
        throw new ChromaValueError(
          `Expected 'where' value for $and or $or to be a list of 'where' expressions, but got ${value}`
        );
      }
      value.forEach((w2) => validateWhere(w2));
      return;
    }
    if (typeof value === "object") {
      if (Object.keys(value).length != 1) {
        throw new ChromaValueError(
          `Expected operator expression to have one operator, but got ${value}`
        );
      }
      const [operator, operand] = Object.entries(value)[0];
      if (["$gt", "$gte", "$lt", "$lte"].includes(operator) && typeof operand !== "number") {
        throw new ChromaValueError(
          `Expected operand value to be a number for ${operator}, but got ${typeof operand}`
        );
      }
      if (["$in", "$nin"].includes(operator) && !Array.isArray(operand)) {
        throw new ChromaValueError(
          `Expected operand value to be an array for ${operator}, but got ${operand}`
        );
      }
      if (!["$gt", "$gte", "$lt", "$lte", "$ne", "$eq", "$in", "$nin"].includes(
        operator
      )) {
        throw new ChromaValueError(
          `Expected operator to be one of $gt, $gte, $lt, $lte, $ne, $eq, $in, $nin, but got ${operator}`
        );
      }
      if (!["string", "number", "boolean"].includes(typeof operand) && !Array.isArray(operand)) {
        throw new ChromaValueError(
          "Expected operand value to be a string, number, boolean, or a list of those types"
        );
      }
      if (Array.isArray(operand) && (operand.length === 0 || !operand.every((item) => typeof item === typeof operand[0]))) {
        throw new ChromaValueError(
          "Expected 'where' operand value to be a non-empty list and all values to be of the same type"
        );
      }
    }
  });
};
var validateWhereDocument = (whereDocument) => {
  if (typeof whereDocument !== "object") {
    throw new ChromaValueError(
      "Expected 'whereDocument' to be a non-empty object"
    );
  }
  if (Object.keys(whereDocument).length != 1) {
    throw new ChromaValueError(
      `Expected 'whereDocument' to have exactly one operator, but got ${whereDocument}`
    );
  }
  const [operator, operand] = Object.entries(whereDocument)[0];
  if (![
    "$contains",
    "$not_contains",
    "$matches",
    "$not_matches",
    "$regex",
    "$not_regex",
    "$and",
    "$or"
  ].includes(operator)) {
    throw new ChromaValueError(
      `Expected 'whereDocument' operator to be one of $contains, $not_contains, $matches, $not_matches, $regex, $not_regex, $and, or $or, but got ${operator}`
    );
  }
  if (operator === "$and" || operator === "$or") {
    if (!Array.isArray(operand)) {
      throw new ChromaValueError(
        `Expected operand for ${operator} to be a list of 'whereDocument' expressions, but got ${operand}`
      );
    }
    if (operand.length <= 1) {
      throw new ChromaValueError(
        `Expected 'whereDocument' operand for ${operator} to be a list with at least two 'whereDocument' expressions`
      );
    }
    operand.forEach((item) => validateWhereDocument(item));
  }
  if ((operand === "$contains" || operand === "$not_contains" || operand === "$regex" || operand === "$not_regex") && (typeof operator !== "string" || operator.length === 0)) {
    throw new ChromaValueError(
      `Expected operand for ${operator} to be a non empty string, but got ${operand}`
    );
  }
};
var validateInclude = ({
  include,
  exclude
}) => {
  if (!Array.isArray(include)) {
    throw new ChromaValueError("Expected 'include' to be a non-empty array");
  }
  const validValues = Object.keys(IncludeEnum);
  include.forEach((item) => {
    if (typeof item !== "string") {
      throw new ChromaValueError("Expected 'include' items to be strings");
    }
    if (!validValues.includes(item)) {
      throw new ChromaValueError(
        `Expected 'include' items to be one of ${validValues.join(
          ", "
        )}, but got ${item}`
      );
    }
    if (exclude?.includes(item)) {
      throw new ChromaValueError(`${item} is not allowed for this operation`);
    }
  });
};
var validateNResults = (nResults) => {
  if (typeof nResults !== "number") {
    throw new ChromaValueError(
      `Expected 'nResults' to be a number, but got ${typeof nResults}`
    );
  }
  if (nResults <= 0) {
    throw new ChromaValueError("Number of requested results has to positive");
  }
};
var parseConnectionPath = (path) => {
  try {
    const url = new URL(path);
    const ssl = url.protocol === "https:";
    const host = url.hostname;
    const port = url.port;
    return {
      ssl,
      host,
      port: Number(port)
    };
  } catch {
    throw new ChromaValueError(`Invalid URL: ${path}`);
  }
};
var packEmbedding = (embedding) => {
  const buffer = new ArrayBuffer(embedding.length * 4);
  const view = new Float32Array(buffer);
  for (let i = 0; i < embedding.length; i++) {
    view[i] = embedding[i];
  }
  return buffer;
};
var embeddingsToBase64Bytes = (embeddings) => {
  return embeddings.map((embedding) => {
    const buffer = packEmbedding(embedding);
    const uint8Array = new Uint8Array(buffer);
    const binaryString = Array.from(
      uint8Array,
      (byte) => String.fromCharCode(byte)
    ).join("");
    return btoa(binaryString);
  });
};

// src/embedding-function.ts
var knownEmbeddingFunctions = /* @__PURE__ */ new Map();
var registerEmbeddingFunction = (name, fn) => {
  if (knownEmbeddingFunctions.has(name)) {
    throw new ChromaValueError(
      `Embedding function with name ${name} is already registered.`
    );
  }
  knownEmbeddingFunctions.set(name, fn);
};
var getEmbeddingFunction = async (collectionName, efConfig) => {
  if (!efConfig) {
    console.warn(
      `No embedding function configuration found for collection ${collectionName}. 'add' and 'query' will fail unless you provide them embeddings directly.`
    );
    return void 0;
  }
  if (efConfig.type === "legacy") {
    console.warn(
      `No embedding function configuration found for collection ${collectionName}. 'add' and 'query' will fail unless you provide them embeddings directly.`
    );
    return void 0;
  }
  const name = efConfig.name;
  const embeddingFunction = knownEmbeddingFunctions.get(name);
  if (!embeddingFunction) {
    console.warn(
      `Collection ${collectionName} was created with the ${embeddingFunction} embedding function. However, the @chroma-core/${embeddingFunction} package is not install. 'add' and 'query' will fail unless you provide them embeddings directly, or install the @chroma-core/${embeddingFunction} package.`
    );
    return void 0;
  }
  let constructorConfig = efConfig.type === "known" ? efConfig.config : {};
  try {
    if (embeddingFunction.buildFromConfig) {
      return embeddingFunction.buildFromConfig(constructorConfig);
    }
    console.warn(
      `Embedding function ${name} does not define a 'buildFromConfig' function. 'add' and 'query' will fail unless you provide them embeddings directly.`
    );
    return void 0;
  } catch (e) {
    console.warn(
      `Embedding function ${name} failed to build with config: ${constructorConfig}. 'add' and 'query' will fail unless you provide them embeddings directly. Error: ${e}`
    );
    return void 0;
  }
};
var serializeEmbeddingFunction = ({
  embeddingFunction,
  configEmbeddingFunction
}) => {
  if (embeddingFunction && configEmbeddingFunction) {
    throw new ChromaValueError(
      "Embedding function provided when already defined in the collection configuration"
    );
  }
  if (!embeddingFunction && !configEmbeddingFunction) {
    return void 0;
  }
  const ef = embeddingFunction || configEmbeddingFunction;
  if (!ef.getConfig || !ef.name || !ef.constructor.buildFromConfig) {
    return { type: "legacy" };
  }
  if (ef.validateConfig) ef.validateConfig(ef.getConfig());
  return {
    name: ef.name,
    type: "known",
    config: ef.getConfig()
  };
};
var getDefaultEFConfig = async () => {
  try {
    const { DefaultEmbeddingFunction } = await Promise.resolve().then(function webpackMissingModule() { var e = new Error("Cannot find module '@chroma-core/default-embed'"); e.code = 'MODULE_NOT_FOUND'; throw e; });
    if (!knownEmbeddingFunctions.has(new DefaultEmbeddingFunction().name)) {
      registerEmbeddingFunction("default", DefaultEmbeddingFunction);
    }
  } catch (e) {
    console.error(e);
    throw new Error(
      "Cannot instantiate a collection with the DefaultEmbeddingFunction. Please install @chroma-core/default-embed, or provide a different embedding function"
    );
  }
  return {
    name: "default",
    type: "known",
    config: {}
  };
};

// src/collection-configuration.ts
var processCreateCollectionConfig = async ({
  configuration,
  embeddingFunction,
  metadata
}) => {
  if (configuration?.hnsw && configuration?.spann) {
    throw new ChromaValueError(
      "Cannot specify both HNSW and SPANN configurations"
    );
  }
  let embeddingFunctionConfiguration = serializeEmbeddingFunction({
    embeddingFunction: embeddingFunction ?? void 0,
    configEmbeddingFunction: configuration?.embeddingFunction
  });
  if (!embeddingFunctionConfiguration && embeddingFunction !== null) {
    embeddingFunctionConfiguration = await getDefaultEFConfig();
  }
  const overallEf = embeddingFunction || configuration?.embeddingFunction;
  if (overallEf && overallEf.defaultSpace && overallEf.supportedSpaces) {
    if (configuration?.hnsw === void 0 && configuration?.spann === void 0) {
      if (metadata === void 0 || metadata?.["hnsw:space"] === void 0) {
        if (!configuration) configuration = {};
        configuration.hnsw = { space: overallEf.defaultSpace() };
      }
    }
    if (configuration?.hnsw && !configuration.hnsw.space && overallEf.defaultSpace) {
      configuration.hnsw.space = overallEf.defaultSpace();
    }
    if (configuration?.spann && !configuration.spann.space && overallEf.defaultSpace) {
      configuration.spann.space = overallEf.defaultSpace();
    }
    if (overallEf.supportedSpaces) {
      const supportedSpaces = overallEf.supportedSpaces();
      if (configuration?.hnsw?.space && !supportedSpaces.includes(configuration.hnsw.space)) {
        console.warn(
          `Space '${configuration.hnsw.space}' is not supported by embedding function '${overallEf.name || "unknown"}'. Supported spaces: ${supportedSpaces.join(", ")}`
        );
      }
      if (configuration?.spann?.space && !supportedSpaces.includes(configuration.spann.space)) {
        console.warn(
          `Space '${configuration.spann.space}' is not supported by embedding function '${overallEf.name || "unknown"}'. Supported spaces: ${supportedSpaces.join(", ")}`
        );
      }
      if (!configuration?.hnsw && !configuration?.spann && metadata && typeof metadata["hnsw:space"] === "string" && !supportedSpaces.includes(metadata["hnsw:space"])) {
        console.warn(
          `Space '${metadata["hnsw:space"]}' from metadata is not supported by embedding function '${overallEf.name || "unknown"}'. Supported spaces: ${supportedSpaces.join(", ")}`
        );
      }
    }
  }
  return {
    ...configuration || {},
    embedding_function: embeddingFunctionConfiguration
  };
};
var processUpdateCollectionConfig = async ({
  collectionName,
  currentConfiguration,
  currentEmbeddingFunction,
  newConfiguration
}) => {
  if (newConfiguration.hnsw && typeof newConfiguration.hnsw !== "object") {
    throw new ChromaValueError(
      "Invalid HNSW config provided in UpdateCollectionConfiguration"
    );
  }
  if (newConfiguration.spann && typeof newConfiguration.spann !== "object") {
    throw new ChromaValueError(
      "Invalid SPANN config provided in UpdateCollectionConfiguration"
    );
  }
  const embeddingFunction = currentEmbeddingFunction || await getEmbeddingFunction(
    collectionName,
    currentConfiguration.embeddingFunction ?? void 0
  );
  const newEmbeddingFunction = newConfiguration.embeddingFunction;
  if (embeddingFunction && embeddingFunction.validateConfigUpdate && newEmbeddingFunction && newEmbeddingFunction.getConfig) {
    embeddingFunction.validateConfigUpdate(newEmbeddingFunction.getConfig());
  }
  return {
    updateConfiguration: {
      hnsw: newConfiguration.hnsw,
      spann: newConfiguration.spann,
      embedding_function: newEmbeddingFunction && serializeEmbeddingFunction({ embeddingFunction: newEmbeddingFunction })
    },
    updateEmbeddingFunction: newEmbeddingFunction
  };
};

// src/collection.ts
var CollectionImpl = class _CollectionImpl {
  /**
   * Creates a new CollectionAPIImpl instance.
   * @param options - Configuration for the collection API
   */
  constructor({
    chromaClient,
    apiClient,
    id,
    name,
    metadata,
    configuration,
    embeddingFunction
  }) {
    this.chromaClient = chromaClient;
    this.apiClient = apiClient;
    this.id = id;
    this._name = name;
    this._metadata = metadata;
    this._configuration = configuration;
    this._embeddingFunction = embeddingFunction;
  }
  get name() {
    return this._name;
  }
  set name(name) {
    this._name = name;
  }
  get configuration() {
    return this._configuration;
  }
  set configuration(configuration) {
    this._configuration = configuration;
  }
  get metadata() {
    return this._metadata;
  }
  set metadata(metadata) {
    this._metadata = metadata;
  }
  get embeddingFunction() {
    return this._embeddingFunction;
  }
  set embeddingFunction(embeddingFunction) {
    this._embeddingFunction = embeddingFunction;
  }
  async path() {
    const clientPath = await this.chromaClient._path();
    return {
      ...clientPath,
      collection_id: this.id
    };
  }
  async embed(documents) {
    if (!this._embeddingFunction) {
      throw new ChromaValueError(
        "Embedding function must be defined for operations requiring embeddings."
      );
    }
    return await this._embeddingFunction.generate(documents);
  }
  async prepareRecords({
    recordSet,
    update = false
  }) {
    const maxBatchSize = await this.chromaClient.getMaxBatchSize();
    validateRecordSetLengthConsistency(recordSet);
    validateIDs(recordSet.ids);
    validateBaseRecordSet({ recordSet, update });
    validateMaxBatchSize(recordSet.ids.length, maxBatchSize);
    if (!recordSet.embeddings && recordSet.documents) {
      recordSet.embeddings = await this.embed(recordSet.documents);
    }
    const preparedRecordSet = { ...recordSet };
    const base64Supported = await this.chromaClient.supportsBase64Encoding();
    if (base64Supported && recordSet.embeddings) {
      preparedRecordSet.embeddings = embeddingsToBase64Bytes(
        recordSet.embeddings
      );
    }
    return preparedRecordSet;
  }
  validateGet(include, ids, where, whereDocument) {
    validateInclude({ include, exclude: ["distances"] });
    if (ids) validateIDs(ids);
    if (where) validateWhere(where);
    if (whereDocument) validateWhereDocument(whereDocument);
  }
  async prepareQuery(recordSet, include, ids, where, whereDocument, nResults) {
    validateBaseRecordSet({
      recordSet,
      embeddingsField: "queryEmbeddings",
      documentsField: "queryTexts"
    });
    validateInclude({ include });
    if (ids) validateIDs(ids);
    if (where) validateWhere(where);
    if (whereDocument) validateWhereDocument(whereDocument);
    if (nResults) validateNResults(nResults);
    let embeddings;
    if (!recordSet.embeddings) {
      embeddings = await this.embed(recordSet.documents);
    } else {
      embeddings = recordSet.embeddings;
    }
    return {
      ...recordSet,
      ids,
      embeddings
    };
  }
  validateDelete(ids, where, whereDocument) {
    if (ids) validateIDs(ids);
    if (where) validateWhere(where);
    if (whereDocument) validateWhereDocument(whereDocument);
  }
  async count() {
    const { data } = await DefaultService.collectionCount({
      client: this.apiClient,
      path: await this.path()
    });
    return data;
  }
  async add({
    ids,
    embeddings,
    metadatas,
    documents,
    uris
  }) {
    const recordSet = {
      ids,
      embeddings,
      documents,
      metadatas,
      uris
    };
    const preparedRecordSet = await this.prepareRecords({ recordSet });
    await DefaultService.collectionAdd({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids: preparedRecordSet.ids,
        embeddings: preparedRecordSet.embeddings,
        documents: preparedRecordSet.documents,
        metadatas: preparedRecordSet.metadatas,
        uris: preparedRecordSet.uris
      }
    });
  }
  async get(args = {}) {
    const {
      ids,
      where,
      limit,
      offset,
      whereDocument,
      include = ["documents", "metadatas"]
    } = args;
    this.validateGet(include, ids, where, whereDocument);
    const { data } = await DefaultService.collectionGet({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids,
        where,
        limit,
        offset,
        where_document: whereDocument,
        include
      }
    });
    return new GetResult({
      documents: data.documents ?? [],
      embeddings: data.embeddings ?? [],
      ids: data.ids,
      include: data.include,
      metadatas: data.metadatas ?? [],
      uris: data.uris ?? []
    });
  }
  async peek({ limit = 10 }) {
    return this.get({ limit });
  }
  async query({
    queryEmbeddings,
    queryTexts,
    queryURIs,
    ids,
    nResults = 10,
    where,
    whereDocument,
    include = ["metadatas", "documents", "distances"]
  }) {
    const recordSet = {
      embeddings: queryEmbeddings,
      documents: queryTexts,
      uris: queryURIs
    };
    const queryRecordSet = await this.prepareQuery(
      recordSet,
      include,
      ids,
      where,
      whereDocument,
      nResults
    );
    const { data } = await DefaultService.collectionQuery({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids: queryRecordSet.ids,
        include,
        n_results: nResults,
        query_embeddings: queryRecordSet.embeddings,
        where,
        where_document: whereDocument
      }
    });
    return new QueryResult({
      distances: data.distances ?? [],
      documents: data.documents ?? [],
      embeddings: data.embeddings ?? [],
      ids: data.ids ?? [],
      include: data.include,
      metadatas: data.metadatas ?? [],
      uris: data.uris ?? []
    });
  }
  async modify({
    name,
    metadata,
    configuration
  }) {
    if (name) this.name = name;
    if (metadata) {
      validateMetadata(metadata);
      this.metadata = metadata;
    }
    const { updateConfiguration, updateEmbeddingFunction } = configuration ? await processUpdateCollectionConfig({
      collectionName: this.name,
      currentConfiguration: this.configuration,
      newConfiguration: configuration,
      currentEmbeddingFunction: this.embeddingFunction
    }) : {};
    if (updateEmbeddingFunction) {
      this.embeddingFunction = updateEmbeddingFunction;
    }
    if (updateConfiguration) {
      this.configuration = {
        hnsw: { ...this.configuration.hnsw, ...updateConfiguration.hnsw },
        spann: { ...this.configuration.spann, ...updateConfiguration.spann },
        embeddingFunction: updateConfiguration.embedding_function
      };
    }
    await DefaultService.updateCollection({
      client: this.apiClient,
      path: await this.path(),
      body: {
        new_name: name,
        new_metadata: metadata,
        new_configuration: updateConfiguration
      }
    });
  }
  async fork({ name }) {
    const { data } = await DefaultService.forkCollection({
      client: this.apiClient,
      path: await this.path(),
      body: { new_name: name }
    });
    return new _CollectionImpl({
      chromaClient: this.chromaClient,
      apiClient: this.apiClient,
      name: data.name,
      id: data.id,
      embeddingFunction: this._embeddingFunction,
      metadata: data.metadata ?? void 0,
      configuration: data.configuration_json
    });
  }
  async update({
    ids,
    embeddings,
    metadatas,
    documents,
    uris
  }) {
    const recordSet = {
      ids,
      embeddings,
      documents,
      metadatas,
      uris
    };
    const preparedRecordSet = await this.prepareRecords({
      recordSet,
      update: true
    });
    await DefaultService.collectionUpdate({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids: preparedRecordSet.ids,
        embeddings: preparedRecordSet.embeddings,
        metadatas: preparedRecordSet.metadatas,
        uris: preparedRecordSet.uris,
        documents: preparedRecordSet.documents
      }
    });
  }
  async upsert({
    ids,
    embeddings,
    metadatas,
    documents,
    uris
  }) {
    const recordSet = {
      ids,
      embeddings,
      documents,
      metadatas,
      uris
    };
    const preparedRecordSet = await this.prepareRecords({
      recordSet
    });
    await DefaultService.collectionUpsert({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids: preparedRecordSet.ids,
        embeddings: preparedRecordSet.embeddings,
        metadatas: preparedRecordSet.metadatas,
        uris: preparedRecordSet.uris,
        documents: preparedRecordSet.documents
      }
    });
  }
  async delete({
    ids,
    where,
    whereDocument
  }) {
    this.validateDelete(ids, where, whereDocument);
    await DefaultService.collectionDelete({
      client: this.apiClient,
      path: await this.path(),
      body: {
        ids,
        where,
        where_document: whereDocument
      }
    });
  }
};

// src/next.ts
function withChroma(userNextConfig = {}) {
  const originalWebpackFunction = userNextConfig.webpack;
  const newWebpackFunction = (config, options) => {
    if (!Array.isArray(config.externals)) {
      config.externals = [];
    }
    const externalsToAdd = ["@huggingface/transformers", "chromadb"];
    for (const ext of externalsToAdd) {
      if (!config.externals.includes(ext)) {
        config.externals.push(ext);
      }
    }
    if (typeof originalWebpackFunction === "function") {
      return originalWebpackFunction(config, options);
    }
    return config;
  };
  return {
    ...userNextConfig,
    webpack: newWebpackFunction
  };
}

// src/chroma-fetch.ts
var offlineError = (error) => {
  return Boolean(
    (error?.name === "TypeError" || error?.name === "FetchError") && (error.message?.includes("fetch failed") || error.message?.includes("Failed to fetch") || error.message?.includes("ENOTFOUND"))
  );
};
var chromaFetch = async (input, init) => {
  let response;
  try {
    response = await fetch(input, init);
  } catch (err) {
    if (offlineError(err)) {
      throw new ChromaConnectionError(
        "Failed to connect to chromadb. Make sure your server is running and try again. If you are running from a browser, make sure that your chromadb instance is configured to allow requests from the current origin using the CHROMA_SERVER_CORS_ALLOW_ORIGINS environment variable."
      );
    }
    throw new ChromaConnectionError("Failed to connect to Chroma");
  }
  if (response.ok) {
    return response;
  }
  switch (response.status) {
    case 400:
      let status = "Bad Request";
      try {
        const responseBody = await response.json();
        status = responseBody.message || status;
      } catch {
      }
      throw new ChromaClientError(
        `Bad request to ${input.url || "Chroma"} with status: ${status}`
      );
    case 401:
      throw new ChromaUnauthorizedError(`Unauthorized`);
    case 403:
      throw new ChromaForbiddenError(
        `You do not have permission to access the requested resource.`
      );
    case 404:
      throw new ChromaNotFoundError(
        `The requested resource could not be found`
      );
    case 409:
      throw new ChromaUniqueError("The resource already exists");
    case 422:
      const body = await response.json();
      if (body && body.message && (body.message.startsWith("Quota exceeded") || body.message.startsWith("Billing limit exceeded"))) {
        throw new ChromaQuotaExceededError(body?.message);
      }
      break;
    case 429:
      throw new ChromaRateLimitError("Rate limit exceeded");
  }
  throw new ChromaConnectionError(
    `Unable to connect to the chromadb server (status: ${response.status}). Please try again later.`
  );
};

// src/admin-client.ts
var AdminClient = class {
  /**
   * Creates a new AdminClient instance.
   * @param args - Optional configuration for the admin client
   */
  constructor(args) {
    const { host, port, ssl, headers, fetchOptions } = args || defaultAdminClientArgs;
    const baseUrl = `${ssl ? "https" : "http"}://${host}:${port}`;
    const configOptions = {
      ...fetchOptions,
      method: normalizeMethod(fetchOptions?.method),
      baseUrl,
      headers
    };
    this.apiClient = J(w(configOptions));
    this.apiClient.setConfig({ fetch: chromaFetch });
  }
  /**
   * Creates a new database within a tenant.
   * @param options - Database creation options
   * @param options.name - Name of the database to create
   * @param options.tenant - Tenant that will own the database
   */
  async createDatabase({
    name,
    tenant
  }) {
    await DefaultService.createDatabase({
      client: this.apiClient,
      path: { tenant },
      body: { name }
    });
  }
  /**
   * Retrieves information about a specific database.
   * @param options - Database retrieval options
   * @param options.name - Name of the database to retrieve
   * @param options.tenant - Tenant that owns the database
   * @returns Promise resolving to database information
   */
  async getDatabase({
    name,
    tenant
  }) {
    const { data } = await DefaultService.getDatabase({
      client: this.apiClient,
      path: { tenant, database: name }
    });
    return data;
  }
  /**
   * Deletes a database and all its data.
   * @param options - Database deletion options
   * @param options.name - Name of the database to delete
   * @param options.tenant - Tenant that owns the database
   * @warning This operation is irreversible and will delete all data
   */
  async deleteDatabase({
    name,
    tenant
  }) {
    await DefaultService.deleteDatabase({
      client: this.apiClient,
      path: { tenant, database: name }
    });
  }
  /**
   * Lists all databases within a tenant.
   * @param args - Listing parameters including tenant and pagination
   * @returns Promise resolving to an array of database information
   */
  async listDatabases(args) {
    const { limit = 100, offset = 0, tenant } = args;
    const { data } = await DefaultService.listDatabases({
      client: this.apiClient,
      path: { tenant },
      query: { limit, offset }
    });
    return data;
  }
  /**
   * Creates a new tenant.
   * @param options - Tenant creation options
   * @param options.name - Name of the tenant to create
   */
  async createTenant({ name }) {
    await DefaultService.createTenant({
      client: this.apiClient,
      body: { name }
    });
  }
  /**
   * Retrieves information about a specific tenant.
   * @param options - Tenant retrieval options
   * @param options.name - Name of the tenant to retrieve
   * @returns Promise resolving to the tenant name
   */
  async getTenant({ name }) {
    const { data } = await DefaultService.getTenant({
      client: this.apiClient,
      path: { tenant_name: name }
    });
    return data.name;
  }
};

// src/chroma-client.ts

var ChromaClient = class {
  /**
   * Creates a new ChromaClient instance.
   * @param args - Configuration options for the client
   */
  constructor(args = {}) {
    let {
      host = defaultChromaClientArgs.host,
      port = defaultChromaClientArgs.port,
      ssl = defaultChromaClientArgs.ssl,
      tenant = defaultChromaClientArgs.tenant,
      database = defaultChromaClientArgs.database,
      headers = defaultChromaClientArgs.headers,
      fetchOptions = defaultChromaClientArgs.fetchOptions
    } = args;
    if (args.path) {
      console.warn(
        "The 'path' argument is deprecated. Please use 'ssl', 'host', and 'port' instead"
      );
      const parsedPath = parseConnectionPath(args.path);
      ssl = parsedPath.ssl;
      host = parsedPath.host;
      port = parsedPath.port;
    }
    if (args.auth) {
      console.warn(
        "The 'auth' argument is deprecated. Please use 'headers' instead"
      );
      if (!headers) {
        headers = {};
      }
      if (!headers["x-chroma-token"] && args.auth.tokenHeaderType === "X_CHROMA_TOKEN" && args.auth.credentials) {
        headers["x-chroma-token"] = args.auth.credentials;
      }
    }
    const baseUrl = `${ssl ? "https" : "http"}://${host}:${port}`;
    this._tenant = tenant || browser.env.CHROMA_TENANT;
    this._database = database || browser.env.CHROMA_DATABASE;
    const configOptions = {
      ...fetchOptions,
      method: normalizeMethod(fetchOptions?.method),
      baseUrl,
      headers
    };
    this.apiClient = J(w(configOptions));
    this.apiClient.setConfig({ fetch: chromaFetch });
  }
  /**
   * Gets the current tenant name.
   * @returns The tenant name or undefined if not set
   */
  get tenant() {
    return this._tenant;
  }
  set tenant(tenant) {
    this._tenant = tenant;
  }
  /**
   * Gets the current database name.
   * @returns The database name or undefined if not set
   */
  get database() {
    return this._database;
  }
  set database(database) {
    this._database = database;
  }
  /**
   * Gets the preflight checks
   * @returns The preflight checks or undefined if not set
   */
  get preflightChecks() {
    return this._preflightChecks;
  }
  set preflightChecks(preflightChecks) {
    this._preflightChecks = preflightChecks;
  }
  /** @ignore */
  async _path() {
    if (!this._tenant || !this._database) {
      const { tenant, databases } = await this.getUserIdentity();
      const uniqueDBs = [...new Set(databases)];
      this._tenant = tenant;
      if (uniqueDBs.length === 0) {
        throw new ChromaUnauthorizedError(
          `Your API key does not have access to any DBs for tenant ${this.tenant}`
        );
      }
      if (uniqueDBs.length > 1 || uniqueDBs[0] === "*") {
        throw new ChromaValueError(
          "Your API key is scoped to more than 1 DB. Please provide a DB name to the CloudClient constructor"
        );
      }
      this._database = uniqueDBs[0];
    }
    return { tenant: this._tenant, database: this._database };
  }
  /**
   * Gets the user identity information including tenant and accessible databases.
   * @returns Promise resolving to user identity data
   */
  async getUserIdentity() {
    const { data } = await DefaultService.getUserIdentity({
      client: this.apiClient
    });
    return data;
  }
  /**
   * Sends a heartbeat request to check server connectivity.
   * @returns Promise resolving to the server's nanosecond heartbeat timestamp
   */
  async heartbeat() {
    const { data } = await DefaultService.heartbeat({
      client: this.apiClient
    });
    return data["nanosecond heartbeat"];
  }
  /**
   * Lists all collections in the current database.
   * @param args - Optional pagination parameters
   * @param args.limit - Maximum number of collections to return (default: 100)
   * @param args.offset - Number of collections to skip (default: 0)
   * @returns Promise resolving to an array of Collection instances
   */
  async listCollections(args) {
    const { limit = 100, offset = 0 } = args || {};
    const { data } = await DefaultService.listCollections({
      client: this.apiClient,
      path: await this._path(),
      query: { limit, offset }
    });
    return Promise.all(
      data.map(
        async (collection) => new CollectionImpl({
          chromaClient: this,
          apiClient: this.apiClient,
          name: collection.name,
          id: collection.id,
          embeddingFunction: await getEmbeddingFunction(
            collection.name,
            collection.configuration_json.embedding_function ?? void 0
          ),
          configuration: collection.configuration_json,
          metadata: collection.metadata ?? void 0
        })
      )
    );
  }
  /**
   * Gets the total number of collections in the current database.
   * @returns Promise resolving to the collection count
   */
  async countCollections() {
    const { data } = await DefaultService.countCollections({
      client: this.apiClient,
      path: await this._path()
    });
    return data;
  }
  /**
   * Creates a new collection with the specified configuration.
   * @param options - Collection creation options
   * @param options.name - The name of the collection
   * @param options.configuration - Optional collection configuration
   * @param options.metadata - Optional metadata for the collection
   * @param options.embeddingFunction - Optional embedding function to use. Defaults to `DefaultEmbeddingFunction` from @chroma-core/default-embed
   * @returns Promise resolving to the created Collection instance
   * @throws Error if a collection with the same name already exists
   */
  async createCollection({
    name,
    configuration,
    metadata,
    embeddingFunction
  }) {
    const collectionConfig = await processCreateCollectionConfig({
      configuration,
      embeddingFunction,
      metadata
    });
    const { data } = await DefaultService.createCollection({
      client: this.apiClient,
      path: await this._path(),
      body: {
        name,
        configuration: collectionConfig,
        metadata,
        get_or_create: false
      }
    });
    return new CollectionImpl({
      chromaClient: this,
      apiClient: this.apiClient,
      name,
      configuration: data.configuration_json,
      metadata,
      embeddingFunction: embeddingFunction ?? await getEmbeddingFunction(
        data.name,
        data.configuration_json.embedding_function ?? void 0
      ),
      id: data.id
    });
  }
  /**
   * Retrieves an existing collection by name.
   * @param options - Collection retrieval options
   * @param options.name - The name of the collection to retrieve
   * @param options.embeddingFunction - Optional embedding function. Should match the one used to create the collection.
   * @returns Promise resolving to the Collection instance
   * @throws Error if the collection does not exist
   */
  async getCollection({
    name,
    embeddingFunction
  }) {
    const { data } = await DefaultService.getCollection({
      client: this.apiClient,
      path: { ...await this._path(), collection_id: name }
    });
    return new CollectionImpl({
      chromaClient: this,
      apiClient: this.apiClient,
      name,
      configuration: data.configuration_json,
      metadata: data.metadata ?? void 0,
      embeddingFunction: embeddingFunction ? embeddingFunction : await getEmbeddingFunction(
        data.name,
        data.configuration_json.embedding_function ?? void 0
      ),
      id: data.id
    });
  }
  /**
   * Retrieves multiple collections by name.
   * @param items - Array of collection names or objects with name and optional embedding function (should match the ones used to create the collections)
   * @returns Promise resolving to an array of Collection instances
   */
  async getCollections(items) {
    if (items.length === 0) return [];
    let requestedCollections = items;
    if (typeof items[0] === "string") {
      requestedCollections = items.map((item) => {
        return { name: item, embeddingFunction: void 0 };
      });
    }
    let collections = requestedCollections;
    return Promise.all(
      collections.map(async (collection) => {
        return this.getCollection({ ...collection });
      })
    );
  }
  /**
   * Gets an existing collection or creates it if it doesn't exist.
   * @param options - Collection options
   * @param options.name - The name of the collection
   * @param options.configuration - Optional collection configuration (used only if creating)
   * @param options.metadata - Optional metadata for the collection (used only if creating)
   * @param options.embeddingFunction - Optional embedding function to use
   * @returns Promise resolving to the Collection instance
   */
  async getOrCreateCollection({
    name,
    configuration,
    metadata,
    embeddingFunction
  }) {
    const collectionConfig = await processCreateCollectionConfig({
      configuration,
      embeddingFunction,
      metadata
    });
    const { data } = await DefaultService.createCollection({
      client: this.apiClient,
      path: await this._path(),
      body: {
        name,
        configuration: collectionConfig,
        metadata,
        get_or_create: true
      }
    });
    return new CollectionImpl({
      chromaClient: this,
      apiClient: this.apiClient,
      name,
      configuration: data.configuration_json,
      metadata: data.metadata ?? void 0,
      embeddingFunction: embeddingFunction ?? await getEmbeddingFunction(
        name,
        data.configuration_json.embedding_function ?? void 0
      ),
      id: data.id
    });
  }
  /**
   * Deletes a collection and all its data.
   * @param options - Deletion options
   * @param options.name - The name of the collection to delete
   */
  async deleteCollection({ name }) {
    await DefaultService.deleteCollection({
      client: this.apiClient,
      path: { ...await this._path(), collection_id: name }
    });
  }
  /**
   * Resets the entire database, deleting all collections and data.
   * @returns Promise that resolves when the reset is complete
   * @warning This operation is irreversible and will delete all data
   */
  async reset() {
    await DefaultService.reset({
      client: this.apiClient
    });
  }
  /**
   * Gets the version of the Chroma server.
   * @returns Promise resolving to the server version string
   */
  async version() {
    const { data } = await DefaultService.version({
      client: this.apiClient
    });
    return data;
  }
  /**
   * Gets the preflight checks
   * @returns Promise resolving to the preflight checks
   */
  async getPreflightChecks() {
    if (!this.preflightChecks) {
      const { data } = await DefaultService.preFlightChecks({
        client: this.apiClient
      });
      this.preflightChecks = data;
      return this.preflightChecks;
    }
    return this.preflightChecks;
  }
  /**
   * Gets the max batch size
   * @returns Promise resolving to the max batch size
   */
  async getMaxBatchSize() {
    const preflightChecks = await this.getPreflightChecks();
    return preflightChecks.max_batch_size ?? -1;
  }
  /**
   * Gets whether base64_encoding is supported by the connected server
   * @returns Promise resolving to whether base64_encoding is supported
   */
  async supportsBase64Encoding() {
    const preflightChecks = await this.getPreflightChecks();
    return preflightChecks.supports_base64_encoding ?? false;
  }
};

// src/cloud-client.ts

var CloudClient = class extends ChromaClient {
  /**
   * Creates a new CloudClient instance for Chroma Cloud.
   * @param args - Cloud client configuration options
   */
  constructor(args = {}) {
    const apiKey = args.apiKey || browser.env.CHROMA_API_KEY;
    if (!apiKey) {
      throw new ChromaValueError(
        "Missing API key. Please provide it to the CloudClient constructor or set your CHROMA_API_KEY environment variable"
      );
    }
    const tenant = args.tenant || browser.env.CHROMA_TENANT;
    const database = args.database || browser.env.CHROMA_DATABASE;
    super({
      host: "api.trychroma.com",
      port: 8e3,
      ssl: true,
      tenant,
      database,
      headers: { "x-chroma-token": apiKey },
      fetchOptions: args.fetchOptions
    });
    this.tenant = tenant;
    this.database = database;
  }
};
var AdminCloudClient = class extends AdminClient {
  /**
   * Creates a new AdminCloudClient instance for cloud admin operations.
   * @param args - Admin cloud client configuration options
   */
  constructor(args = {}) {
    const apiKey = args.apiKey || browser.env.CHROMA_API_KEY;
    if (!apiKey) {
      throw new ChromaValueError(
        "Missing API key. Please provide it to the CloudClient constructor or set your CHROMA_API_KEY environment variable"
      );
    }
    super({
      host: "api.trychroma.com",
      port: 8e3,
      ssl: true,
      headers: { "x-chroma-token": apiKey },
      fetchOptions: args.fetchOptions
    });
  }
};

//# sourceMappingURL=chromadb.mjs.map

/***/ }),

/***/ 5279:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  A: () => (/* binding */ esm_browser_v4)
});

;// CONCATENATED MODULE: ./node_modules/uuid/dist/esm-browser/native.js
const randomUUID = typeof crypto !== 'undefined' && crypto.randomUUID && crypto.randomUUID.bind(crypto);
/* harmony default export */ const esm_browser_native = ({ randomUUID });

;// CONCATENATED MODULE: ./node_modules/uuid/dist/esm-browser/rng.js
let getRandomValues;
const rnds8 = new Uint8Array(16);
function rng() {
    if (!getRandomValues) {
        if (typeof crypto === 'undefined' || !crypto.getRandomValues) {
            throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
        }
        getRandomValues = crypto.getRandomValues.bind(crypto);
    }
    return getRandomValues(rnds8);
}

;// CONCATENATED MODULE: ./node_modules/uuid/dist/esm-browser/stringify.js

const byteToHex = [];
for (let i = 0; i < 256; ++i) {
    byteToHex.push((i + 0x100).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
    return (byteToHex[arr[offset + 0]] +
        byteToHex[arr[offset + 1]] +
        byteToHex[arr[offset + 2]] +
        byteToHex[arr[offset + 3]] +
        '-' +
        byteToHex[arr[offset + 4]] +
        byteToHex[arr[offset + 5]] +
        '-' +
        byteToHex[arr[offset + 6]] +
        byteToHex[arr[offset + 7]] +
        '-' +
        byteToHex[arr[offset + 8]] +
        byteToHex[arr[offset + 9]] +
        '-' +
        byteToHex[arr[offset + 10]] +
        byteToHex[arr[offset + 11]] +
        byteToHex[arr[offset + 12]] +
        byteToHex[arr[offset + 13]] +
        byteToHex[arr[offset + 14]] +
        byteToHex[arr[offset + 15]]).toLowerCase();
}
function stringify(arr, offset = 0) {
    const uuid = unsafeStringify(arr, offset);
    if (!validate(uuid)) {
        throw TypeError('Stringified UUID is invalid');
    }
    return uuid;
}
/* harmony default export */ const esm_browser_stringify = ((/* unused pure expression or super */ null && (stringify)));

;// CONCATENATED MODULE: ./node_modules/uuid/dist/esm-browser/v4.js



function v4(options, buf, offset) {
    if (esm_browser_native.randomUUID && !buf && !options) {
        return esm_browser_native.randomUUID();
    }
    options = options || {};
    const rnds = options.random ?? options.rng?.() ?? rng();
    if (rnds.length < 16) {
        throw new Error('Random bytes length must be >= 16');
    }
    rnds[6] = (rnds[6] & 0x0f) | 0x40;
    rnds[8] = (rnds[8] & 0x3f) | 0x80;
    if (buf) {
        offset = offset || 0;
        if (offset < 0 || offset + 16 > buf.length) {
            throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
        for (let i = 0; i < 16; ++i) {
            buf[offset + i] = rnds[i];
        }
        return buf;
    }
    return unsafeStringify(rnds);
}
/* harmony default export */ const esm_browser_v4 = (v4);


/***/ })

}]);
//# sourceMappingURL=143.js.map